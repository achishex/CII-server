package mavlink

import (
	"bytes"
	"encoding/binary"
	"fmt"
	"strconv"
	"strings"
	"sync"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
)

const (
	AEAGMsgGetSn              = 0x81
	AEAGMsgGetChannel         = 0x10
	AEAGMsgHeartbeat          = 0x11
	AEAGMsgGetSoftVer         = 0xAB
	AEAGMsgGetAddress         = 0x21
	AEAGMsgSetWhiteList       = 0x22
	AEAGMsgHit                = 0x23
	AEAGGetAllWhiteList       = 0x24
	AEAGGetLogList            = 0x28
	AEAGGetLog                = 0x29
	AEAGDeleteLog             = 0x2A
	DeviceLogDownload         = 0x33
	LocalLogUpload            = 0x34
	CloudLogDownload          = 0x35
	GunIdResetSystem          = 0xA1 // 系统复位
	GunIdGetUpdateWriteStatus = 0xA6 // 获取固件写入状态
	GunIdRequestUpgrade       = 0xA7 // 请求固件升级
	GunIdSendUpdatePkg        = 0xA8 // 发送升级固件数据
	GunIdWriteUpdateData      = 0xA9 // 写入固件数据
	GunIdRunApp               = 0xAD // 运行固件App
	GunIdVerifyImage          = 0xAC // 校验固件镜像
	GunIdGetTimeoutRetryTime  = 0xAE // 获取运行超时重试时间
	GunIdBootToAppMod         = 0xAF // 程序处于boot时设置是否可跳转APP

	GunOtaReSetCode = 0x55AA
)

const (
	GunDistanceRed uint16 = 10       //枪的距离上报扩大值
	GunGeoReduce          = 100000.0 //枪的经纬度上报扩大值
)

type GunGetChannelRequest struct {
	Sn      [14]uint8
	GunIp   [4]uint8
	GunPort uint16
	Proxy   uint8
}

func (g *GunGetChannelRequest) ID() uint8 {
	return 0x10
}

func (g *GunGetChannelRequest) Size() uint16 {
	return 21
}

func (g *GunGetChannelRequest) IsNeedAns() uint8 {
	return 1
}

func (g *GunGetChannelRequest) SnToString() string {
	var bs []byte
	for _, v := range g.Sn {
		if v == 0x00 {
			break
		}
		bs = append(bs, v)
	}
	return string(bs)
}

type GunGetChannelResponse struct {
	GunIp   [4]uint8
	GunPort uint16
	Proxy   uint8
}

func (g *GunGetChannelResponse) ID() uint8 {
	return 16
}

func (g *GunGetChannelResponse) Size() uint16 {
	return 7
}

func (g *GunGetChannelResponse) IsNeedAns() uint8 {
	return 0
}

func (g *GunGetChannelResponse) CreateGetChannelResponse(ip string, port uint16) []byte {
	if ip == "" {
		return nil
	}
	ipSegArr := strings.Split(ip, ".")
	var uIps [4]uint8
	for i, v := range ipSegArr {
		tmp, _ := strconv.Atoi(v)
		uIps[i] = uint8(tmp)
	}
	g.GunIp = uIps
	g.GunPort = port
	g.Proxy = 1
	p, err := NewPacket(uint8(common.DEV_AEAG), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type AeagHeartbeat struct {
	ScreenStatus   uint8
	Electricity    uint8
	SignalStrength uint8
	WorkStatus     uint8
	AlarmLevel     uint8
	HitFreq        uint8
	DetectFreq     uint32
	X              uint16
	Y              uint16
	Z              uint16
	GunLongitude   uint32
	GunLatitude    uint32
	GunAltitude    uint16
	SatellitesNum  uint16
	GunDirection   uint16
	TimeStamp      uint32
	UUAVNum        uint8
}

func (g *AeagHeartbeat) DeserializeUav(d []byte) []*common.Uav {
	uavs := make([]*common.Uav, 0)
	packageLen := 38 //无人机数据包长
	for i := 0; i < int(g.UUAVNum) && len(d)/packageLen == int(g.UUAVNum); i++ {
		var tmp common.Uav
		buff := &bytes.Buffer{}
		err := binary.Write(buff, binary.LittleEndian, d[i*packageLen:(i+1)*packageLen])
		if err != nil {
			logger.Error("deserialize AeagHeartbeat err:", err)
			return nil
		}
		err = binary.Read(buff, binary.LittleEndian, &tmp)
		if err != nil {
			logger.Error("反制枪心跳包反序列化uav错误:", err)
			continue
		}
		uavs = append(uavs, &tmp)
	}
	return uavs
}

func (g *AeagHeartbeat) ID() uint8 {
	return 0x11
}

func (g *AeagHeartbeat) Size() uint16 {
	return 35
}

func (g *AeagHeartbeat) IsNeedAns() uint8 {
	return 0
}

type GetAEAGVersionRequest struct {
}

func (g *GetAEAGVersionRequest) ID() uint8 {
	return 0xAB
}

func (g *GetAEAGVersionRequest) Size() uint16 {
	return 0
}

func (g *GetAEAGVersionRequest) IsNeedAns() uint8 {
	return 1
}

func (g *GetAEAGVersionRequest) CreateGetAEAGVersionRequest() []byte {
	p, err := NewPacket(uint8(common.DEV_AEAG), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type GetAEAGVersionResponse struct {
	RunVersion      uint32   //当前运行版 0-boot1-app
	AppVersion      [64]byte //软件版本号
	BootVersion     [32]byte //Bootloader
	HwVersion       [32]byte //硬件版本号
	ProtocolVersion [32]byte //协议版本号
}

func (g *GetAEAGVersionResponse) ID() uint8 {
	return 0xAB
}

func (g *GetAEAGVersionResponse) Size() uint16 {
	return 164
}

func (g *GetAEAGVersionResponse) IsNeedAns() uint8 {
	return 0
}

type GetAEAGAddressRequest struct {
}

func (g *GetAEAGAddressRequest) ID() uint8 {
	return 0x21
}

func (g *GetAEAGAddressRequest) Size() uint16 {
	return 0
}
func (g *GetAEAGAddressRequest) IsNeedAns() uint8 {
	return 1
}

func (g *GetAEAGAddressRequest) CreateGetAEAGAddressRequest() []byte {
	p, err := NewPacket(uint8(common.DEV_AEAG), uint8(common.DEV_C2_WIFI), &GetAEAGAddressRequest{})
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type GetAEAGAddressResponse struct {
	Ip   [4]uint8
	Port [2]uint8
}

func (g *GetAEAGAddressResponse) ID() uint8 {
	return 0x21
}

func (g *GetAEAGAddressResponse) Size() uint16 {
	return 6
}

func (g *GetAEAGAddressResponse) IsNeedAns() uint8 {
	return 0
}

func (g *GetAEAGAddressResponse) ToAddress() string {
	addr := fmt.Sprintf("%d.%d.%d.%d:%d", g.Ip[0], g.Ip[1], g.Ip[2], g.Ip[3], g.Port)
	return addr
}

type SetGunWhiteListRequest struct {
	Name [20]uint8
}

func (g *SetGunWhiteListRequest) ID() uint8 {
	return 0x22
}

func (g *SetGunWhiteListRequest) Size() uint16 {
	return 20
}
func (g *SetGunWhiteListRequest) IsNeedAns() uint8 {
	return 1
}

func (g *SetGunWhiteListRequest) CreateSetGunWhiteListRequest(name string) []byte {
	var tmp [20]byte
	for i, v := range []byte(name) {
		tmp[i] = v
	}
	g.Name = tmp
	p, err := NewPacket(uint8(common.DEV_AEAG), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type SetGunWhiteListResponse struct {
	Status uint8
}

func (g *SetGunWhiteListResponse) ID() uint8 {
	return 0x22
}

func (g *SetGunWhiteListResponse) Size() uint16 {
	return 1
}

func (g *SetGunWhiteListResponse) IsNeedAns() uint8 {
	return 0
}

type GetAEAGWhiteListRequest struct {
}

func (g *GetAEAGWhiteListRequest) ID() uint8 {
	return 0x24
}

func (g *GetAEAGWhiteListRequest) Size() uint16 {
	return 0
}

func (g *GetAEAGWhiteListRequest) IsNeedAns() uint8 {
	return 1
}

func (g *GetAEAGWhiteListRequest) CreateGetAEAGWhiteListRequest() []byte {
	p, err := NewPacket(uint8(common.DEV_AEAG), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type GetAEAGWhiteListResponse struct {
	Cnt      uint8
	NameList [200]byte //应该是二维数组来着
}

func (g *GetAEAGWhiteListResponse) ID() uint8 {
	return 0x24
}

func (g *GetAEAGWhiteListResponse) Size() uint16 {
	return 0
}

func (g *GetAEAGWhiteListResponse) IsNeedAns() uint8 {
	return 0
}

type SetGunHitRequest struct {
	Mode           uint8
	HitFreq        uint8
	DroneLongitude uint16
	DroneLatitude  uint16
	DroneAltitude  uint16
	HitTime        uint16 //打击时长，单位s ,默认10
}

func (g *SetGunHitRequest) ID() uint8 {
	return 0x23
}

func (g *SetGunHitRequest) Size() uint16 {
	return 10
}

func (g *SetGunHitRequest) IsNeedAns() uint8 {
	return 1
}

func (g *SetGunHitRequest) CreateHitRequest() []byte {
	p, err := NewPacket(uint8(common.DEV_AEAG), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type SetGunHitResponse struct {
	Status uint8
}

func (g *SetGunHitResponse) ID() uint8 {
	return 0x23
}

func (g *SetGunHitResponse) Size() uint16 {
	return 1
}

func (g *SetGunHitResponse) IsNeedAns() uint8 {
	return 0
}

type GunHeartbeatExtRequest struct {
	Sum uint8
}

func (r *GunHeartbeatExtRequest) ID() uint8 {
	return 0x25
}

func (r *GunHeartbeatExtRequest) Size() uint16 {
	return 1
}

func (g *GunHeartbeatExtRequest) IsNeedAns() uint8 {
	return 0
}

func (g *GunHeartbeatExtRequest) CreateGunHeartbeatExt() []byte {
	p, err := NewPacket(uint8(common.DEV_AEAG), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type GetAEAGSnRequest struct {
}

func (g *GetAEAGSnRequest) ID() uint8 {
	return AEAGMsgGetSn
}

func (g *GetAEAGSnRequest) Size() uint16 {
	return 0
}

func (g *GetAEAGSnRequest) IsNeedAns() uint8 {
	return 1
}

func (g *GetAEAGSnRequest) CreateGetSnRequest() []byte {
	p, err := NewPacket(uint8(common.DEV_AEAG), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type GetAEAGSnResponse struct {
	Name []byte
}

func (g *GetAEAGSnResponse) ID() uint8 {
	return AEAGMsgGetSn
}

func (g *GetAEAGSnResponse) Size() uint16 {
	return 0
}

func (g *GetAEAGSnResponse) IsNeedAns() uint8 {
	return 0
}

// 向反制枪  获取日志列表
type GunGetLogListRequest struct {
}

func (p *GunGetLogListRequest) ID() uint8 {
	return 0x28
}

func (p *GunGetLogListRequest) Size() uint16 {
	return 0
}

func (p *GunGetLogListRequest) IsNeedAns() uint8 {
	return 1
}

func (p *GunGetLogListRequest) CreateGunGetLogList() []byte {
	pac, err := NewPacket(uint8(common.DEV_AEAG), uint8(common.DEV_C2_WIFI), p)
	if err != nil {
		return nil
	}
	genBuff := pac.StructToSlice()
	return genBuff
}

var GunResAll GunGetLogListResponseAll

type GunGetLogListResponseAll struct {
	LogListAll []GunGetLogListResponse
	DataLock   sync.Mutex
}

func (this *GunGetLogListResponseAll) SetData(data interface{}) {
	this.DataLock.Lock()
	defer this.DataLock.Unlock()
	logger.Info("LogList load data:%v", data)
	data1 := data.(*GunGetLogListResponse)
	this.LogListAll = append(this.LogListAll, *data1)
}
func (this *GunGetLogListResponseAll) GetData() []GunGetLogListResponse {
	this.DataLock.Lock()
	defer this.DataLock.Unlock()
	logger.Info("Get LogList data")
	return this.LogListAll
}
func (this *GunGetLogListResponseAll) DeleteData() {
	this.DataLock.Lock()
	defer this.DataLock.Unlock()
	logger.Info("Del LogList data")
	this.LogListAll = this.LogListAll[:0]
}

var GunLogMsgAll GunGetLogMsgResponse

type GunGetLogMsgResponse struct {
	//LogMsgAll GunGetLogResponse
	LogMsgAll []string
	DataLock  sync.Mutex
}

func (this *GunGetLogMsgResponse) SetData(data string) {
	this.DataLock.Lock()
	defer this.DataLock.Unlock()
	logger.Debug("LogMsg load data:%v", data)
	this.LogMsgAll = append(this.LogMsgAll, data)
}
func (this *GunGetLogMsgResponse) GetData() []string {
	this.DataLock.Lock()
	defer this.DataLock.Unlock()
	logger.Info("Get LogMsg data")
	return this.LogMsgAll
}
func (this *GunGetLogMsgResponse) DeleteData() {
	this.DataLock.Lock()
	defer this.DataLock.Unlock()
	logger.Info("Del LogMsg data")
	this.LogMsgAll = this.LogMsgAll[:0]
}

// 获取日志列表响应
type GunGetLogListResponse struct {
	PkgTotalNum uint32
	PkgCurNum   uint32
	LogInfo     []LogInfo
}

type LogInfo struct {
	LogNameLen uint32
	LogDataLen uint32
	LogName    []byte
}

func (p *GunGetLogListResponse) Len() int {
	//TODO implement me
	templen := 0
	//for i := 0; i < int(p.LogDataLen); i++ {
	//	templen += len(p.LogInfo[i].LogName)
	//}
	for _, v := range p.LogInfo {
		templen = templen + 8 + len(v.LogName)
	}
	return int(8 + templen*len(p.LogInfo))
}
func (p *GunGetLogListResponse) ID() uint8 {
	return 0x28
}

func (p *GunGetLogListResponse) IsNeedAns() uint8 {
	return 0
}

type GunGetLogRequestAll struct {
}
type GunGetLogRequest struct {
	LogNum      uint32
	LogFileInfo [1]GunLogFileInfo
}
type GunLogFileInfo struct {
	LogId      uint32
	LogNameLen uint32
	LogName    []byte
}

func (p *GunGetLogRequestAll) ID() uint8 {
	return 0x29
}

func (p *GunGetLogRequestAll) Size() uint16 {

	return 4
}

func (p *GunGetLogRequestAll) IsNeedAns() uint8 {
	return 1
}

func (p *GunGetLogRequestAll) CreateGunGetLog(key uint32, logInfo []*GunGetLogRequest) []byte {
	size := uint16(4 + len(logInfo)*(8+len(logInfo[0].LogFileInfo[0].LogName)))
	logger.Info("size is : ", size)
	rowLength := uint8(size & 0x00FF)
	highLength := uint8((size & 0xFF00) >> 8)
	mavPackage1 := &MavPacket{
		Header: MavHeader{
			FrameStart:        FrameStart,
			PayloadLowLength:  rowLength,
			PayloadHighLength: highLength,
			PacketSequence:    PackageSeq,
			ReceiveID:         uint8(common.DEV_AEAG),
			SendID:            uint8(common.DEV_C2_WIFI),
			MessageID:         p.ID(),
			Ans:               p.IsNeedAns(),
		},
		Msg: p,
	}
	var r1 bytes.Buffer
	if err := binary.Write(&r1, binary.LittleEndian, mavPackage1.Header); err != nil {
		logger.Error("Header binary Write err : ", err)
		return []byte{}
	}
	mavPackage1.GunGetLogChecksum(r1)
	mavPackage := &MavPacket{
		Header: MavHeader{
			FrameStart:        FrameStart,
			PayloadLowLength:  rowLength,
			PayloadHighLength: highLength,
			PacketSequence:    PackageSeq,
			ReceiveID:         uint8(common.DEV_AEAG),
			SendID:            uint8(common.DEV_C2_WIFI),
			MessageID:         p.ID(),
			Ans:               p.IsNeedAns(),
			Checksum:          mavPackage1.GunGetLogChecksum(r1),
		},
		Msg: p,
	}
	var r bytes.Buffer
	if err := binary.Write(&r, binary.LittleEndian, mavPackage.Header); err != nil {
		logger.Error("Header binary Write err : ", err)
		return []byte{}
	}

	if err := binary.Write(&r, binary.LittleEndian, p); err != nil {
		logger.Error("p binary Write err : ", err)
		return []byte{}
	}
	for _, v := range logInfo {
		if err := binary.Write(&r, binary.LittleEndian, v.LogNum); err != nil {
			logger.Error("range binary Write err : ", err)
			return []byte{}
		}
		for _, v2 := range v.LogFileInfo {
			if err := binary.Write(&r, binary.LittleEndian, v2.LogId); err != nil {
				logger.Error("LogId binary Write err : ", err)
				return []byte{}
			}
			if err := binary.Write(&r, binary.LittleEndian, v2.LogNameLen); err != nil {
				logger.Error("LogNameLen binary Write err : ", err)
				return []byte{}
			}
			if err := binary.Write(&r, binary.LittleEndian, v2.LogName); err != nil {
				logger.Error("LogName binary Write err : ", err)
				return []byte{}
			}
		}

	}

	dataBuff := r.Bytes()
	crc16 := CRC(dataBuff[CrcStartLoc:])
	crcArr := make([]byte, CrcLen)
	binary.BigEndian.PutUint16(crcArr, crc16)
	genBuff := make([]byte, 0)
	genBuff = append(genBuff, dataBuff...)
	genBuff = append(genBuff, crcArr[1])
	genBuff = append(genBuff, crcArr[0])
	logger.Info("send msg is:%v", genBuff)
	logger.Info("send msg is:%v", string(genBuff))
	return genBuff
}

// 获取日志文件响应
type GunGetLogResponse struct {
	LogId       uint32
	PkgTotalNum uint32
	PkgCurNum   uint32
	DataLen     uint32
	Data        []byte
}

func (p *GunGetLogResponse) ID() uint8 {
	return 0x29
}

func (p *GunGetLogResponse) Size() uint8 {

	return uint8(len(p.Data) + 16)
}

func (p *GunGetLogResponse) IsNeedAns() uint8 {
	return 0
}

// 向反制枪  发删除日志文件
type GunDelLogRequest struct {
}

func (p *GunDelLogRequest) ID() uint8 {
	return 0x2a
}

func (p *GunDelLogRequest) Size() uint16 {

	return 0
}

func (p *GunDelLogRequest) IsNeedAns() uint8 {
	return 1
}

func (p *GunDelLogRequest) CreateGunDelLog() []byte {
	pac, err := NewPacket(uint8(common.DEV_AEAG), uint8(common.DEV_C2_WIFI), p)
	if err != nil {
		return nil
	}
	genBuff := pac.StructToSlice()
	return genBuff
}

// 删除日志文件响应
type GunDelLogResponse struct {
	Status bool
}

func (p *GunDelLogResponse) ID() uint8 {
	return 0x2a
}

func (p *GunDelLogResponse) Size() uint16 {

	return 1
}

func (p *GunDelLogResponse) IsNeedAns() uint8 {
	return 0
}

// GunResetSystemRequest 雷达复位请求
type GunResetSystemRequest struct {
	ResetCode uint16 `json:"reset_code"`
	Type      uint16 `json:"type"`
}

func (g *GunResetSystemRequest) ID() uint8 {
	return 0xA1
}

func (g *GunResetSystemRequest) Size() uint16 {
	return 4
}

func (g *GunResetSystemRequest) IsNeedAns() uint8 {
	return 0
}

func (g *GunResetSystemRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_AEAG), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type GunResetSystemResponse struct {
	Status uint8 `json:"status"`
}

func (g *GunResetSystemResponse) ID() uint8 {
	return 0xA1
}

func (g *GunResetSystemResponse) Size() uint16 {
	return 1
}

func (g *GunResetSystemResponse) IsNeedAns() uint8 {
	return 0
}

// GunGetUpdateWriteStatusRequest 获取固件更新写入状态请求
type GunGetUpdateWriteStatusRequest struct {
}

func (g *GunGetUpdateWriteStatusRequest) ID() uint8 {
	return 0xA6
}

func (g *GunGetUpdateWriteStatusRequest) Size() uint16 {
	return 0
}

func (g *GunGetUpdateWriteStatusRequest) IsNeedAns() uint8 {
	return 1
}

func (g *GunGetUpdateWriteStatusRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_AEAG), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type GunGetUpdateWriteStatusResponse struct {
	Status uint8  `json:"status"`
	Permil uint16 `json:"permil"`
}

func (g *GunGetUpdateWriteStatusResponse) ID() uint8 {
	return 0xA6
}

func (g *GunGetUpdateWriteStatusResponse) Size() uint16 {
	return 3
}

func (g *GunGetUpdateWriteStatusResponse) IsNeedAns() uint8 {
	return 0
}

// GunGetUpdateTimeoutRetryTimeRequest 获取固件升级超时重试时间
type GunGetUpdateTimeoutRetryTimeRequest struct {
}

func (g *GunGetUpdateTimeoutRetryTimeRequest) ID() uint8 {
	return 0xAE
}

func (g *GunGetUpdateTimeoutRetryTimeRequest) Size() uint16 {
	return 0
}

func (g *GunGetUpdateTimeoutRetryTimeRequest) IsNeedAns() uint8 {
	return 1
}

func (g *GunGetUpdateTimeoutRetryTimeRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_AEAG), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type GunGetUpdateTimeoutRetryTimeResponse struct {
	ImagePkgLenMax uint16 `json:"image_pkg_len_max"`
	CmdTimeoutMs   uint16 `json:"cmd_timeout_ms"`
	CheckTimeoutS  uint16 `json:"check_timeout_s"`
	WriteTimeoutS  uint16 `json:"write_timeout_s"`
}

func (g *GunGetUpdateTimeoutRetryTimeResponse) ID() uint8 {
	return 0xAE
}

func (g *GunGetUpdateTimeoutRetryTimeResponse) Size() uint16 {
	return 8
}

func (g *GunGetUpdateTimeoutRetryTimeResponse) IsNeedAns() uint8 {
	return 0
}

// GunRequestUpgradeRequest 请求固件升级
type GunRequestUpgradeRequest struct {
	Data [256]uint8 `json:"data"`
}

func (g *GunRequestUpgradeRequest) ID() uint8 {
	return 0xA7
}

func (g *GunRequestUpgradeRequest) Size() uint16 {
	return 256
}

func (g *GunRequestUpgradeRequest) IsNeedAns() uint8 {
	return 1
}

func (g *GunRequestUpgradeRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_AEAG), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type GunRequestUpgradeResponse struct {
	Status uint8 `json:"status"`
}

func (g *GunRequestUpgradeResponse) ID() uint8 {
	return 0xA7
}

func (g *GunRequestUpgradeResponse) Size() uint16 {
	return 8
}

func (g *GunRequestUpgradeResponse) IsNeedAns() uint8 {
	return 0
}

// GunVerifyImageRequest 请求校验固件
type GunVerifyImageRequest struct {
}

func (g *GunVerifyImageRequest) ID() uint8 {
	return 0xAC
}

func (g *GunVerifyImageRequest) Size() uint16 {
	return 0
}

func (g *GunVerifyImageRequest) IsNeedAns() uint8 {
	return 1
}

func (g *GunVerifyImageRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_AEAG), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type GunVerifyImageResponse struct {
	Status uint8 `json:"status"`
}

func (g *GunVerifyImageResponse) ID() uint8 {
	return 0xAC
}

func (g *GunVerifyImageResponse) Size() uint16 {
	return 1
}

func (g *GunVerifyImageResponse) IsNeedAns() uint8 {
	return 0
}

// GunRunAppRequest 请求运行固件App
type GunRunAppRequest struct {
}

func (g *GunRunAppRequest) ID() uint8 {
	return 0xAD
}

func (g *GunRunAppRequest) Size() uint16 {
	return 0
}

func (g *GunRunAppRequest) IsNeedAns() uint8 {
	return 1
}

func (g *GunRunAppRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_AEAG), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type GunRunAppResponse struct {
	Status uint8 `json:"status"`
}

func (g *GunRunAppResponse) ID() uint8 {
	return 0xAD
}

func (g *GunRunAppResponse) Size() uint16 {
	return 1
}

func (g *GunRunAppResponse) IsNeedAns() uint8 {
	return 0
}

// GunWriteUpdateDataRequest 写入固件数据
type GunWriteUpdateDataRequest struct {
}

func (g *GunWriteUpdateDataRequest) ID() uint8 {
	return 0xA9
}

func (g *GunWriteUpdateDataRequest) Size() uint16 {
	return 0
}

func (g *GunWriteUpdateDataRequest) IsNeedAns() uint8 {
	return 1
}

func (g *GunWriteUpdateDataRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_AEAG), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type GunWriteUpdateDataResponse struct {
	Status uint8 `json:"status"`
}

func (g *GunWriteUpdateDataResponse) ID() uint8 {
	return 0xA9
}

func (g *GunWriteUpdateDataResponse) Size() uint16 {
	return 1
}

func (g *GunWriteUpdateDataResponse) IsNeedAns() uint8 {
	return 0
}

// GunSendUpdatePkgRequest 发送升级固件数据
type GunSendUpdatePkgRequest struct {
	ImageOffset uint32  `json:"image_offset"` // 数据偏移位置
	ImageLength uint32  `json:"image_length"` // 数据长度
	ImageData   []uint8 `json:"image_data"`   // 升级数据流，最大4096字节
}

func (g *GunSendUpdatePkgRequest) ID() uint8 {
	return 0xA8
}

func (g *GunSendUpdatePkgRequest) Size() uint16 {
	return uint16(g.Len())
}

func (g *GunSendUpdatePkgRequest) IsNeedAns() uint8 {
	return 1
}

func (g *GunSendUpdatePkgRequest) Len() int {
	return 8 + len(g.ImageData)
}

// Create 元素长度不固定使用protocols下的message进行编码
func (g *GunSendUpdatePkgRequest) Create() ([]byte, error) {

	size := g.Size()
	rowLength := uint8(size & 0x00FF)
	highLength := uint8((size & 0xFF00) >> 8)
	var header MavHeader
	header = MavHeader{
		FrameStart:        FrameStart,
		PayloadLowLength:  rowLength,
		PayloadHighLength: highLength,
		PacketSequence:    PackageSeq,
		ReceiveID:         uint8(common.DEV_AEAG),
		SendID:            uint8(common.DEV_C2_WIFI),
		MessageID:         g.ID(),
		Ans:               g.IsNeedAns(),
	}
	header.Checksum = g.computeChecksum(header)
	genBuff := g.structToSlice(header)

	return genBuff, nil
}

func (g *GunSendUpdatePkgRequest) bytes(header MavHeader) []byte {
	var r bytes.Buffer
	var err error
	if err = binary.Write(&r, binary.LittleEndian, header); err != nil {
		return []byte{}
	}
	if err = binary.Write(&r, binary.LittleEndian, g.ImageOffset); err != nil {
		return []byte{}
	}
	if err = binary.Write(&r, binary.LittleEndian, g.ImageLength); err != nil {
		return []byte{}
	}
	if err = binary.Write(&r, binary.LittleEndian, g.ImageData); err != nil {
		return []byte{}
	}
	return r.Bytes()
}

func (g *GunSendUpdatePkgRequest) computeChecksum(header MavHeader) uint8 {
	var sum uint32
	buff := g.bytes(header)
	if buff == nil || len(buff) < CheckSumLen {
		return 0
	}
	sumData := buff[:CheckSumLen]
	for _, v := range sumData {
		sum += uint32(v)
	}
	return uint8(sum & 0xFF)
}

func (g *GunSendUpdatePkgRequest) structToSlice(header MavHeader) []byte {
	dataBuff := g.bytes(header)
	if len(dataBuff) <= 0 {
		return dataBuff
	}
	crc16 := CRC(dataBuff[CrcStartLoc:])
	crcArr := make([]byte, CrcLen)
	binary.BigEndian.PutUint16(crcArr, crc16)
	genBuff := make([]byte, 0)
	genBuff = append(genBuff, dataBuff...)
	genBuff = append(genBuff, crcArr[1])
	genBuff = append(genBuff, crcArr[0])
	return genBuff
}

type GunSendUpdatePkgResponse struct {
	Status uint8 `json:"status"`
}

func (g *GunSendUpdatePkgResponse) ID() uint8 {
	return 0xA8
}

func (g *GunSendUpdatePkgResponse) Size() uint16 {
	return 1
}

func (g *GunSendUpdatePkgResponse) IsNeedAns() uint8 {
	return 0
}

// GunBootToAppModRequest 设置是否可跳转APP
type GunBootToAppModRequest struct {
	Able uint8 `json:"able"` // 0:可跳转，1：不可跳转
}

func (g *GunBootToAppModRequest) ID() uint8 {
	return 0xAF
}

func (g *GunBootToAppModRequest) Size() uint16 {
	return 0
}

func (g *GunBootToAppModRequest) IsNeedAns() uint8 {
	return 1
}

func (g *GunBootToAppModRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_AEAG), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

// GunBootToAppModResponse 设置是否可跳转APP响应
type GunBootToAppModResponse struct {
	Status uint8 `json:"status"` // 0:成功 1：请求失败 10：状态错误 10：状态错误
}

func (g *GunBootToAppModResponse) ID() uint8 {
	return 0xAF
}

func (g *GunBootToAppModResponse) Size() uint16 {
	return 1
}

func (g *GunBootToAppModResponse) IsNeedAns() uint8 {
	return 0
}

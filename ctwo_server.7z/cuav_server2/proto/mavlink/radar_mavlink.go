package mavlink

import (
	"bytes"
	"encoding/binary"
	"strconv"
	"strings"
	"sync"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
)

const (
	RadarIdHeartbeat                = 0xD0
	RadarIdSetSystemStatus          = 0xD1
	RadarIdGetSystemInfo            = 0xD2
	RadarIdHeartbeatExt             = 0xD3
	RadarIdSetSn                    = 0xD4
	RadarIdGetCryptKey              = 0xA0
	RadarIdSetWifiConnInfo          = 0xB0
	RadarIdSetWifiDisConn           = 0xB1
	RadarIdUploadWifiStatus         = 0xB2
	RadarIdRequestWifiChannel       = 0xB3
	RadarIdUploadDetectInfo         = 0x10
	RadarIdSetUploadMode            = 0x11
	RadarIdUploadTrackInfo          = 0x12
	RadarIdUploadControlInfo        = 0x14
	RadarIdUploadPosture            = 0x13
	RadarIdGetBeamSteerInfo         = 0x15
	RadarIdStartDetect              = 0xC1
	RadarIdEndDetect                = 0xC2
	RadarIdSetBeamPos               = 0xC3
	RadarIdSetBeamSize              = 0xC4
	RadarIdPostureCalibration       = 0xCB
	RadarIdPostureCalibrationResult = 0xCC
	RadarIdPostureCalibrationManual = 0xCD
	RadarIdGetVersionInfo           = 0xAB // 获取版本信息
	RadarIdResetSystem              = 0xA1 // 系统复位
	RadarIdGetUpdateWriteStatus     = 0xA6 // 获取固件写入状态
	RadarIdRequestUpgrade           = 0xA7 // 请求固件升级
	RadarIdSendUpdatePkg            = 0xA8 // 发送升级固件数据
	RadarIdWriteUpdateData          = 0xA9 // 写入固件数据
	RadarIdRunApp                   = 0xAD // 运行固件App
	RadarIdVerifyImage              = 0xAC // 校验固件镜像
	RadarIdGetTimeoutRetryTime      = 0xAE // 获取运行超时重试时间
	RadarGetLogList                 = 0x28
	RadarGetLog                     = 0x29
	RadarDeleteLog                  = 0x2A
	V2RadarIdRequestWifiChannel     = 0xB4
	RadarUdpBroadcastResponse       = 0xBB
	RadarOtaReSetCode               = 0x55AA
)

var RadarHbFaultMap = map[uint32]string{
	0x01000001: "寄存器读写异常",
	0x02000001: "PLL失锁",
	0x02000002: "寄存器读写异常",
	0x03000001: " U09(awmf0165)寄存器读写异常",
	0x03000002: " U10(awmf0165)寄存器读写异常",
	0x03000003: " U11(awmf0165)寄存器读写异常",
	0x03000004: " U12(awmf0165)寄存器读写异常",
	0x03000005: " U13(awmf0165)寄存器读写异常",
	0x03000006: " U14(awmf0165)寄存器读写异常",
	0x03000007: " U15(awmf0165)寄存器读写异常",
	0x03000008: " U16(awmf0165)寄存器读写异常",
	0x03000009: " U17(awmf0165)寄存器读写异常",
	0x0300000a: " U18(awmf0165)寄存器读写异常",
	0x0300000b: " U19(awmf0165)寄存器读写异常",
	0x0300000c: " U20(awmf0165)寄存器读写异常",
	0x0300000d: " U21(awmf0165)寄存器读写异常",
	0x0300000e: "U22(awmf0165)寄存器读写异常",
	0x0300000f: " U23(awmf0165)寄存器读写异常",
	0x03000011: " U24(awmf0165)寄存器读写异常",
	0x03000021: " U09(awmf0165)寄存器读写异常",
	0x03000022: " U10(awmf0165)温度超限",
	0x03000023: " U11(awmf0165)温度超限",
	0x03000024: " U12(awmf0165)温度超限",
	0x03000025: " U13(awmf0165)温度超限",
	0x03000026: " U14(awmf0165)温度超限",
	0x03000027: " U15(awmf0165)温度超限",
	0x03000028: " U16(awmf0165)温度超限",
	0x03000029: " U17(awmf0165)温度超限",
	0x0300002a: " U18(awmf0165)温度超限",
	0x0300002b: " U19(awmf0165)温度超限",
	0x0300002c: " U20(awmf0165)温度超限",
	0x0300002d: " U21(awmf0165)温度超限",
	0x0300002e: " U22(awmf0165)温度超限",
	0x0300002f: " U23(awmf0165)温度超限",
	0x03000030: " U24(awmf0165)温度超限",
	0x04000001: " ADC回波数据饱和",
	0x05000001: " DMA Not Idle",
	0x05000002: " DMA Internal Error",
	0x05000003: " DMA Slave Error",
	0x05000004: " DMA Decode Error",
	0x05000005: " Scatter Gather Internal Error",
	0x05000006: " Scatter Gather Slave Error",
	0x05000007: " Scatter Gather Decode Error",
	0x05000008: " Interrupt on Error",
	0x06000001: " 目标检测任务数据处理异常",
	0x07000001: " 目标跟踪任务数据处理异常",
	0x08000001: " 处理板与上位机通信异常",
	0x08000002: " 处理板与电池组通信异常",
	0x0a000001: "处理板与GPS模块通信异常",
	0x0b000001: "处理板与陀螺传感器通信异常",
	0x0c000001: "处理板与加速度计传感器通信异常",
}

type RadarHeartbeat struct {
	Electricity uint8 `json:"electricity"` //0~100% 电量百分比
	Status      uint8 `json:"status"`      //系统状态0：正常工作	1：待机
	FaultNum    uint8 `json:"fault_num"`   //故障数量
}

func (heart *RadarHeartbeat) ID() uint8 {
	return 0xD0
}

func (heart *RadarHeartbeat) Size() uint16 {
	return 3
}
func (heart *RadarHeartbeat) FaultSize() int {
	return 4
}

func (heart *RadarHeartbeat) IsNeedAns() uint8 {
	return 0
}

func (heart *RadarHeartbeat) GetFaultMsg(faultBuff []byte) []string {
	faultLen := heart.FaultSize()
	faults := make([]string, 0)
	for i := 0; i < int(heart.FaultNum); i++ {
		key := binary.BigEndian.Uint32(faultBuff[i*faultLen : (i+1)*faultLen])
		if msg, ok := RadarHbFaultMap[key]; ok {
			faults = append(faults, msg)
		}
	}
	return faults
}

type RadarSetSystemStatusReq struct {
	StatusType uint8
	WorkMode   uint8
	Other      uint8
}

func (g *RadarSetSystemStatusReq) ID() uint8 {
	return 0xD1
}

func (g *RadarSetSystemStatusReq) Size() uint16 {
	return 3
}

func (g *RadarSetSystemStatusReq) IsNeedAns() uint8 {
	return 1
}

func (g *RadarSetSystemStatusReq) CreateRadarSetSystemStatus(sourceId uint8) []byte {
	p, err := NewPacket(sourceId, uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type RadarSetSystemStatusResponse struct {
	Status uint8
}

func (g *RadarSetSystemStatusResponse) ID() uint8 {
	return 0xD1
}
func (g *RadarSetSystemStatusResponse) Size() uint16 {
	return 1
}
func (g *RadarSetSystemStatusResponse) IsNeedAns() uint8 {
	return 0
}

type RadarGetSystemInfoRequest struct {
	DataType uint8
}

func (g *RadarGetSystemInfoRequest) ID() uint8 {
	return 0xD2
}

func (g *RadarGetSystemInfoRequest) Size() uint16 {
	return 1
}

func (g *RadarGetSystemInfoRequest) IsNeedAns() uint8 {
	return 1
}

func (g *RadarGetSystemInfoRequest) CreateRadarGetSystemInfo(sourceId uint8) []byte {
	p, err := NewPacket(sourceId, uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type RadarGetSystemInfoResponse struct {
	DataType  byte
	DataValue [16]uint8
}

func (g *RadarGetSystemInfoResponse) ID() uint8 {
	return 0xD1
}

func (g *RadarGetSystemInfoResponse) Size() uint16 {
	return 16
}

func (g *RadarGetSystemInfoResponse) IsNeedAns() uint8 {
	return 0
}

type RadarUploadSystemInfo struct {
	WorkMode uint8
	DataType uint8
	Version  uint32
	Sn       string
}

func (r *RadarGetSystemInfoResponse) GetSystemInfo() *RadarUploadSystemInfo {
	info := &RadarUploadSystemInfo{
		DataType: r.DataType,
	}
	switch r.DataType {
	case 0:
		info.WorkMode = r.DataValue[0]
		break
	case 1:
		status := r.DataValue[0]
		if status == 0 {
			var bs []byte
			for _, v := range r.DataValue[1:16] {
				if v == 0x00 {
					break
				}
				bs = append(bs, v)
			}
			info.Sn = string(bs)
		}
		break
	case 2:
		info.Version = binary.LittleEndian.Uint32(r.DataValue[:4])
		break
	}
	return info
}

type RadarHeartbeatExtRequest struct {
	Sum uint8
}

func (r *RadarHeartbeatExtRequest) ID() uint8 {
	return 0xD3
}

func (r *RadarHeartbeatExtRequest) Size() uint16 {
	return 1
}

func (g *RadarHeartbeatExtRequest) IsNeedAns() uint8 {
	return 0
}

func (g *RadarHeartbeatExtRequest) CreateRadarHeartbeatExt(sourceId uint8) []byte {
	g.Sum = 1
	p, err := NewPacket(sourceId, uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type RadarSetSnRequest struct {
	Sn [15]byte
}

func (g *RadarSetSnRequest) ID() uint8 {
	return 0xD4
}

func (g *RadarSetSnRequest) Size() uint16 {
	return 15
}

func (g *RadarSetSnRequest) IsNeedAns() uint8 {
	return 1
}

func (g *RadarSetSnRequest) CreateRadarSetSn(sn string, sourceId uint8) []byte {
	snBuff := []byte(sn)
	var snArr [15]byte
	for i := 0; i < len(snBuff) && i < 15; i++ {
		snArr[i] = snBuff[i]
	}

	g.Sn = snArr
	p, err := NewPacket(sourceId, uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type RadarSetSnResponse struct {
	Status uint8
}

func (g *RadarSetSnResponse) ID() uint8 {
	return 0xD4
}

func (g *RadarSetSnResponse) Size() uint16 {
	return 1
}

func (g *RadarSetSnResponse) IsNeedAns() uint8 {
	return 0
}

type RadarGetCommSecretRequest struct {
	Sn [15]uint8
}

func (g *RadarGetCommSecretRequest) ID() uint8 {
	return 0xA0
}

func (g *RadarGetCommSecretRequest) Size() uint16 {
	return 15
}

func (g *RadarGetCommSecretRequest) IsNeedAns() uint8 {
	return 1
}

func (g *RadarGetCommSecretRequest) CreateRadarGetCommSecret(sn string, sourceId uint8) []byte {
	snBuff := []byte(sn)
	var snArr [15]byte
	for i := 0; i < len(snBuff) && i < 15; i++ {
		snArr[i] = snBuff[i]
	}
	g.Sn = snArr
	p, err := NewPacket(sourceId, uint8(common.DEV_C2_WIFI), &RadarGetCommSecretRequest{
		Sn: snArr,
	})
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type RadarGetCommSecretResponse struct {
	Status  uint8
	MsgType uint8
	Len     uint8
	Key     [64]uint8
}

func (r *RadarGetCommSecretResponse) GetSecret() string {
	return string(r.Key[:r.Len])
}

func (g *RadarGetCommSecretResponse) ID() uint8 {
	return 0xA0
}

func (g *RadarGetCommSecretResponse) Size() uint16 {
	return 15
}

func (g *RadarGetCommSecretResponse) IsNeedAns() uint8 {
	return 0
}

type RadarSetWifiConnRequest struct {
	NameLen     uint8
	Name        []byte
	PasswordLen uint8
	Password    []byte
	Ip          [4]uint8
	Port        uint16
}

func (g *RadarSetWifiConnRequest) ID() uint8 {
	return 0xD4
}

func (g *RadarSetWifiConnRequest) Size() uint16 {
	//固定长度
	return 8
}

func (g *RadarSetWifiConnRequest) IsNeedAns() uint8 {
	return 1
}

type RadarSetWifiConnResponse struct {
	Status uint8
}

func (g *RadarSetWifiConnResponse) ID() uint8 {
	return 0xB0
}

func (g *RadarSetWifiConnResponse) Size() uint16 {
	return 1
}

func (g *RadarSetWifiConnResponse) IsNeedAns() uint8 {
	return 0
}

type RadarSetWifiOffRequest struct {
	Status uint8
}

func (g *RadarSetWifiOffRequest) ID() uint8 {
	return 0xB1
}

func (g *RadarSetWifiOffRequest) Size() uint16 {
	return 1
}

func (g *RadarSetWifiOffRequest) IsNeedAns() uint8 {
	return 1
}

func (g *RadarSetWifiOffRequest) CreateRadarSetWifiOff(sourceId uint8) []byte {
	g.Status = 1
	p, err := NewPacket(sourceId, uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type RadarSetWifiOffResponse struct {
	Status uint8
}

func (g *RadarSetWifiOffResponse) ID() uint8 {
	return 0xB1
}

func (g *RadarSetWifiOffResponse) Size() uint16 {
	return 1
}

func (g *RadarSetWifiOffResponse) IsNeedAns() uint8 {
	return 0
}

type RadarUploadWifiStatus struct {
	Status uint8
}

func (g *RadarUploadWifiStatus) ID() uint8 {
	return 0xB2
}

func (g *RadarUploadWifiStatus) Size() uint16 {
	return 1
}

func (g *RadarUploadWifiStatus) IsNeedAns() uint8 {
	return 1
}

type RadarGetChannelRequest struct {
	Sn        [15]uint8
	RadarIp   [4]uint8
	RadarPort uint16
	Proxy     uint8
}

func (g *RadarGetChannelRequest) ID() uint8 {
	return 0xB3
}

func (g *RadarGetChannelRequest) Size() uint16 {
	return 22
}

func (g *RadarGetChannelRequest) IsNeedAns() uint8 {
	return 1
}

func (g *RadarGetChannelRequest) SnToString() string {
	var bs []byte
	for _, v := range g.Sn {
		if v == 0x00 {
			break
		}
		bs = append(bs, v)
	}
	return string(bs)
}

type RadarGetChannelResponse struct {
	Proxy   uint8
	GunIp   [4]uint8
	GunPort uint16
}

func (g *RadarGetChannelResponse) ID() uint8 {
	return 0xB3
}

func (g *RadarGetChannelResponse) Size() uint16 {
	return 7
}

func (g *RadarGetChannelResponse) IsNeedAns() uint8 {
	return 0
}

func (g *RadarGetChannelResponse) CreateGetChannelResponse(sourceId uint8, ip string, port uint16) []byte {
	if ip == "" {
		return nil
	}
	ipSegArr := strings.Split(ip, ".")
	var uIps [4]uint8
	for i, v := range ipSegArr {
		tmp, _ := strconv.Atoi(v)
		uIps[i] = uint8(tmp)
	}
	g.GunIp = uIps
	g.GunPort = port
	g.Proxy = 1
	p, err := NewPacket(sourceId, uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type RadarUploadDetectInfo struct {
	DetectObjNum    uint8 //检测目标个数，最大目标个数64
	TrackTwsTasFlag uint8 //跟踪标识
	DetectObjByte   uint8
	AziBeamID       uint8
	EleBeamID       uint8
}

type Detect struct {
	Id              uint8  `json:"id"`                //
	Reserved        uint8  `json:"reserved"`          //保留字
	Ambiguous       uint8  `json:"ambiguous"`         //目标速度模糊标记
	Classification  uint8  `json:"classification"`    //目标类别
	ClassifyProb    uint8  `json:"classify_prob"`     //目标类别概率
	CohesionOkFlag  uint8  `json:"cohesion_ok_flag"`  //凝聚完成标记
	CohesionPntNum  uint8  `json:"cohesion_pnt_num"`  //凝聚点数
	CohesionBeamNum uint8  `json:"cohesion_beam_num"` //凝聚波位个数
	Azimuth         int16  `json:"azimuth"`           //目标方位角
	Elevation       int16  `json:"elevation"`         //目标俯仰角
	Velocity        int16  `json:"velocity"`          //目标径向运动速度（m/s）
	DopplerChn      int16  `json:"doppler_chn"`       //目标多普勒滤波器插值结果
	Mag             uint16 `json:"mag"`               //目标幅度值(dB)
	ObjConfidence   uint16 `json:"obj_confidence"`    //目标置信值
	DtRange         uint32 `json:"dt_range"`          //目标距离插值结果（m）
}

func (g *RadarUploadDetectInfo) DetectSize() int {
	return 24
}
func (g *RadarUploadDetectInfo) ID() uint8 {
	return 0x10
}

func (g *RadarUploadDetectInfo) Size() uint16 {
	return 5
}

func (g *RadarUploadDetectInfo) IsNeedAns() uint8 {
	return 1
}

func (g *RadarUploadDetectInfo) DeserializeDetect(d []byte) []*Detect {
	detects := make([]*Detect, 0)
	dLen := g.DetectSize()
	for i := 0; i < int(g.DetectObjNum); i++ {
		var tmp Detect
		buff := &bytes.Buffer{}
		err := binary.Write(buff, binary.LittleEndian, d[i*dLen:(i+1)*dLen])
		if err != nil {
			logger.Error("deserialize RadarUploadDetectInfo err:", err)
			return nil
		}
		err = binary.Read(buff, binary.LittleEndian, &tmp)
		if err != nil {
			continue
		}
		detects = append(detects, &tmp)
	}
	return detects
}

func (g *RadarUploadDetectInfo) GetDetect() []*Detect {
	return nil
}

type RadarUploadDetectInfoResponse struct {
	UploadType uint8 //	上报类型
	Reserved   uint8 //保留字	字节对齐
	Status     uint8 //关闭上报
	Route      uint8 //wifi
	Cycle      uint8 //	上报周期时间（ms）

}

func (g *RadarUploadDetectInfoResponse) ID() uint8 {
	return 0x10
}

func (g *RadarUploadDetectInfoResponse) Size() uint16 {
	return 5
}

func (g *RadarUploadDetectInfoResponse) IsNeedAns() uint8 {
	return 1
}

func (g *RadarUploadDetectInfoResponse) CreateRadarUploadDetectInfoResponse(checkType, status, route, cycle uint8) []byte {
	g.UploadType = checkType
	g.Reserved = 0
	g.Status = status
	g.Route = route
	g.Cycle = cycle
	p, err := NewPacket(uint8(common.DEV_RADAR), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type RadarSetUploadMode struct {
	CheckType uint8
	Reserved  uint8
	Status    uint8
	Route     uint8
	Cycle     uint8
}

func (g *RadarSetUploadMode) ID() uint8 {
	return 0x11
}

func (g *RadarSetUploadMode) Size() uint16 {
	return 5
}

func (g *RadarSetUploadMode) IsNeedAns() uint8 {
	return 1
}

func (g *RadarSetUploadMode) CreateSetUploadMode(sourceId, checkType, status, route, cycle uint8) []byte {
	g.CheckType = checkType
	g.Reserved = 0
	g.Status = status
	g.Route = route
	g.Cycle = cycle
	p, err := NewPacket(sourceId, uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type RadarSetUploadModeResponse struct {
	Status uint8
}

func (g *RadarSetUploadModeResponse) ID() uint8 {
	return 0x11
}

func (g *RadarSetUploadModeResponse) Size() uint16 {
	return 1
}

func (g *RadarSetUploadModeResponse) IsNeedAns() uint8 {
	return 0
}

type RadarUploadTrackInfo struct {
	Reserved     uint8 `json:"reserved"`       //保留字
	TrackObjNum  uint8 `json:"track_obj_num"`  //跟踪目标个数，最大目标个数64(MaxObjNum)
	TrackTwsNum  uint8 `json:"track_tws_num"`  //TWS跟踪目标个数
	TrackTasNum  uint8 `json:"track_tas_num"`  //TAS跟踪目标个数
	TrackObjByte uint8 `json:"track_obj_byte"` // 单个跟踪目标数据长度，由跟踪点数据定义决定
}

type RadarTrack struct {
	Id               uint8  `json:"id"`                //最大目标个数64
	Classification   uint8  `json:"classification"`    //0x00：未识别  0x01：无人机  0x02：单兵  0x03：车辆  0x04：鸟类  0x05：直升机  其他无效。
	ClassifyProb     uint8  `json:"classify_prob"`     //目标类别概率
	ExistingProb     uint8  `json:"existing_prob"`     //目标存在概率
	Ambiguous        uint8  `json:"ambiguous"`         //目标速度模糊标记 0x00代表速度无模糊 0x01代表速度存在模糊
	TwsTasFlag       uint8  `json:"tws_tas_flag"`      //跟踪标识 0：TWS跟踪 1：TAS跟踪
	StateType        uint8  `json:"state_type"`        //目标航迹类型 0：暂态航迹 1：稳态航迹
	MotionType       uint8  `json:"motion_type"`       //运动类型： 0：未知 1：静止 2：悬停 3：靠近 4：远离  其他待定义
	Azimuth          int16  `json:"azimuth"`           //目标方位角（°）
	TRange           uint32 `json:"t_range"`           //目标距离插值结果（m）
	Elevation        int16  `json:"elevation"`         //目标俯仰角（°）
	Velocity         int16  `json:"velocity"`          //目标径向运动速度（m/s）
	DopplerChn       int16  `json:"doppler_chn"`       //目标多普勒滤波器插值结果
	Mag              uint16 `json:"mag"`               //目标幅度值(dB)
	AbsVel           int16  `json:"abs_vel"`           //目标位移速度（m/s）
	OrientationAngle int16  `json:"orientation_angle"` //目标航向,目标运动方向与真北夹角(°)
	Alive            uint16 `json:"alive"`             //目标周期数
	X                int32  `json:"x"`                 //x相对坐标（m）
	Y                int32  `json:"y"`                 //y相对坐标（m）
	Z                int32  `json:"z"`                 //z相对坐标（m）
	Vx               int16  `json:"vx"`                //x方向相对速度（m/s）
	Vy               int16  `json:"vy"`                //y方向相对速度（m/s）
	Vz               int16  `json:"vz"`                //z方向相对速度（m/s）
	Ax               int16  `json:"ax"`                //x方向相对加速度（m/s²）
	Ay               int16  `json:"ay"`                //y方向相对加速度（m/s²）
	Az               int16  `json:"az"`                //z方向相对加速度（m/s²）
	XVariance        uint16 `json:"x_variance"`        //x相对坐标方差
	YVariance        uint16 `json:"y_variance"`        //y相对坐标方差
	ZVariance        uint16 `json:"z_variance"`        //z相对坐标方差
	VxVariance       uint16 `json:"vx_variance"`       //x方向相对速度方差
	VyVariance       uint16 `json:"vy_variance"`       //y方向相对速度方差
	VzVariance       uint16 `json:"vz_variance"`       //z方向相对速度方差
	AxVariance       uint16 `json:"ax_variance"`       //x方向相对加速度方差
	AyVariance       uint16 `json:"ay_variance"`       //y方向相对加速度方差
	AzVariance       uint16 `json:"az_variance"`       //z方向相对加速度方差
	ForcastFrameNum  uint16 `json:"forcast_frame_num"` //目标预测帧数
	AssociationNum   uint16 `json:"association_num"`   //目标关联的检测点个数
	AssocBit0        uint32 `json:"assoc_bit_0"`       //关联检测点ID，bit位对应检测目标ID，0bit对应ID 0，31bit对应ID 31，位值为0时表示未关联对应ID目标，值为1时表示关联对应ID目标
	AssocBit1        uint32 `json:"assoc_bit_1"`       //关联检测点ID，bit位对应检测目标ID，0bit对应ID 32，31bit对应ID 63，位值为0时表示未关联对应ID目标，值为1时表示关联对应ID目标
}

func (g *RadarUploadTrackInfo) DeserializeTrack(d []byte) []*RadarTrack {
	tracks := make([]*RadarTrack, 0)
	tLen := g.TrackSize()
	for i := 0; i < int(g.TrackObjNum); i++ {
		var tmp RadarTrack

		buff := &bytes.Buffer{}
		err := binary.Write(buff, binary.LittleEndian, d[i*tLen:(i+1)*tLen])
		if err != nil {
			logger.Error("deserialize RadarUploadDetectInfo err:", err)
			return nil
		}
		err = binary.Read(buff, binary.LittleEndian, &tmp)
		if err != nil {
			continue
		}
		tracks = append(tracks, &tmp)
	}
	return tracks
}

func (g *RadarUploadTrackInfo) TrackSize() int {
	return 82
}

func (g *RadarUploadTrackInfo) ID() uint8 {
	return 0x12
}

func (g *RadarUploadTrackInfo) Size() uint16 {
	return 5
}

func (g *RadarUploadTrackInfo) IsNeedAns() uint8 {
	return 1
}

func (g *RadarUploadTrackInfo) GetTrack() []*RadarTrack {
	return nil
}

type RadarUploadControlInfo struct {
	Reserved               uint8  `json:"reserved"`                   //保留字
	AziBeamID              uint8  `json:"azi_beam_id"`                //方位波束号，0~29，共30个，分别对应-58°：4°：58°
	EleBeamID              uint8  `json:"ele_beam_id"`                //俯仰波束号，0~3，共4个，分别对应-15°：10°：15°
	TrackTwsTasFlag        uint8  `json:"track_tws_tas_flag"`         //跟踪标识
	TasObjId               uint8  `json:"tas_obj_id"`                 //0：TWS跟踪
	TasBeamTotal           uint8  `json:"tas_beam_total"`             //1：TAS跟踪
	TasBeamCntCur          uint8  `json:"tas_beam_cnt_cur"`           //TAS目标编号，仅TAS跟踪模式有效
	AziBeamSin             uint8  `json:"azi_beam_sin"`               //TAS波位扫描总个数，仅TAS跟踪模式有效
	EleBeamSin             uint8  `json:"ele_beam_sin"`               //TAS波位扫描当前个数，仅TAS跟踪模式有效
	TasObjFilterNum        uint8  `json:"tas_obj_filter_num"`         //方位波束指向的正弦值
	TasObjRange            uint16 `json:"tas_obj_range"`              //俯仰波束指向的正弦值
	SamplePntStart         uint16 `json:"sample_pnt_start"`           //TAS目标滤波器，TAS滤波器波门中心，TWS时无效 （滤波器号）
	SamplePntDepth         uint16 `json:"sample_pnt_depth"`           //TAS目标距离单元数,目标距离单元数=（目标实际距离÷距离单元）
	BeamSwitchTime         uint16 `json:"beam_switch_time"`           //起始采样点，起始采样位置，从PRI的上升沿开始计时，单位：0.2us
	WholeSpaceScanCycleCnt uint32 `json:"whole_space_scan_cycle_cnt"` //采样深度，从起始采样点开始计数，默认4096
}

func (g *RadarUploadControlInfo) ID() uint8 {
	return 0x14
}

func (g *RadarUploadControlInfo) Size() uint16 {
	return 25
}

func (g *RadarUploadControlInfo) IsNeedAns() uint8 {
	return 0
}

type RadarUploadPostureInfo struct {
	Reserved            uint8     `json:"reserved"`               //保留字
	Heading             int32     `json:"heading"`                //航线角度
	Pitching            int32     `json:"pitching"`               //纵摇角度
	Rolling             int32     `json:"rolling"`                //横滚角度
	Longitude           int32     `json:"longitude"`              //地球椭圆体格林子午面与平台所在点子午面之间不大于180°的夹角
	Latitude            int32     `json:"latitude"`               //地球椭圆体子午线上平台所在点的法线与赤道面的夹角
	Altitude            int32     `json:"altitude"`               //海拔高度（m）
	VelocityNavi        int32     `json:"velocity_navi"`          //导航速度（m/s）
	TargetTimeMark      [6]uint16 `json:"target_time_mark"`       //目标时标
	SigProcRelativeTime uint32    `json:"sig_proc_relative_time"` //目标时标（绝对时间）
}

func (g *RadarUploadPostureInfo) ID() uint8 {
	return 0x13
}

func (g *RadarUploadPostureInfo) Size() uint16 {
	return 45
}

func (g *RadarUploadPostureInfo) IsNeedAns() uint8 {
	return 0
}

func (g *RadarUploadPostureInfo) CreateUploadPosture(sourceId uint8) []byte {
	g.Reserved = 0
	g.Heading = 32
	g.Pitching = 11200
	g.Rolling = 11900
	g.Longitude = 119
	g.Latitude = 39
	g.Altitude = 11300
	g.VelocityNavi = 334
	//g.TargetTimeMark = 312
	g.SigProcRelativeTime = 11245350
	p, err := NewPacket(sourceId, uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type RadarGetBeamSteerRequest struct {
	Reserved uint8 `json:"reserved"` //保留字
}

func (g *RadarGetBeamSteerRequest) ID() uint8 {
	return 0x15
}

func (g *RadarGetBeamSteerRequest) Size() uint16 {
	return 1
}

func (g *RadarGetBeamSteerRequest) IsNeedAns() uint8 {
	return 1
}

func (g *RadarGetBeamSteerRequest) CreateGetBeamSteer(sourceId uint8) []byte {
	p, err := NewPacket(sourceId, uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	//fmt.Println("打印创建姿态信息完成")
	return genBuff
}

type RadarGetBeamSteerResponse struct {
	TrSwitchCtrl         uint8  `json:"tr_switch_ctrl"`          //组件开关控制，FF：全开，00：全关；01：只打开中间1/8个通道；02：打开中间1/4个通道；04：打开1/2个通道；08：打开所有通道；其他：全关；
	WorkMode             uint8  `json:"work_mode"`               //	工作方式，0x00：搜索模式， 0x01：跟踪模式；
	WorkWaveCode         uint8  `json:"work_wave_code"`          //工作波形码，不同模式波形要求见下表
	WorkFreqCode         uint8  `json:"work_freq_code"`          //工作频点，0-2，共计三个频率点；
	PrfPeriod            uint8  `json:"prf_period"`              //	PRF周期，0x00：1#PRF号；0x01：2#PRF号
	AccuNum              uint8  `json:"accu_num"`                //	积累点数控制，0为64点，1为32点，默认1
	CohesionVelThre      uint8  `json:"cohesion_vel_thre"`       //	凝聚速度门限，信处凝聚速度滤波器门限，值域范围[0,63]
	CohesionRgnThre      uint8  `json:"cohesion_rgn_thre"`       //	凝聚距离门限，信处距离凝聚门限，单位：距离单元；
	ClutterMapSwitch     uint8  `json:"clutter_map_switch"`      //杂波图开关，0为打开，1为关闭，默认1
	ClutterMapUpdateCoef uint8  `json:"clutter_map_update_coef"` //杂波图更新系数，无符号数，值域范围[0,255]
	AziCalcSlope         int8   `json:"azi_calc_slope"`          //方位测角斜率，值域范围[-128,127]
	AziCalcPhase         int8   `json:"azi_calc_phase"`          //方位测角相位，值域范围[0,36]
	EleCalcSlope         int8   `json:"ele_calc_slope"`          //俯仰测角斜率，值域范围[-128,127]
	EleCalcPhase         int8   `json:"ele_calc_phase"`          //俯仰测角相位，值域范围[0,36]
	AziScanCenter        int8   `json:"azi_scan_center"`         //方位扫描中心， -60°～+60°，默认为0
	AziScanScope         uint8  `json:"azi_scan_scope"`          //	方位扫描范围， 0、20、40、90、120，默认为120
	EleScanCenter        int8   `json:"ele_scan_center"`         //俯仰扫描中心，-20°～+20°，默认为0
	EleScanScope         uint8  `json:"ele_scan_scope"`          //	俯仰扫描范围，0、10、20、40，默认为40
	CoherentDetectSwitch uint16 `json:"coherent_detect_switch"`  //相关检测开关，小目标相关检测开关： 1代表开（相关后上报），0代表关（不相关，直接上报），默认为0
	NoiseCoef            uint16 `json:"noise_coef"`              //噪声门限系数
	ClutterCoef          uint16 `json:"clutter_coef"`            //杂波图门限系数
	CfarCoef             uint16 `json:"cfar_coef"`               //恒虚警门限系数
	FocusRangeMin        uint16 `json:"focus_range_min"`         //重点关注距离范围下限，最小作用距离单元
	FocusRangeMax        uint16 `json:"focus_range_max"`         //	重点关注距离范围上限，最大作用距离单元
	ClutterCurveNum      int16  `json:"clutter_curve_num"`       //抠杂波点数，值域范围[0,63]
	LobeCompCoef         int16  `json:"lobe_comp_coef"`          //	波瓣压缩，输入最小0.5，最大4
	WaveFrequencyChannel uint8  `json:"wave_frequency_channel"`  // 波形频分通道
}

func (g *RadarGetBeamSteerResponse) ID() uint8 {
	return 0x15
}

func (g *RadarGetBeamSteerResponse) Size() uint16 {
	return 34
}

func (g *RadarGetBeamSteerResponse) IsNeedAns() uint8 {
	return 0
}

type RadarStartDetectRequest struct {
	WaveFrequencyChannel uint8
}

func (g *RadarStartDetectRequest) ID() uint8 {
	return 0xC1
}

func (g *RadarStartDetectRequest) Size() uint16 {
	return 0
}

func (g *RadarStartDetectRequest) IsNeedAns() uint8 {
	return 1
}

func (g *RadarStartDetectRequest) Create(sourceId uint8) []byte {
	p, err := NewPacket(sourceId, uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type RadarStartDetectResponse struct {
	Status uint8
}

func (g *RadarStartDetectResponse) ID() uint8 {
	return 0xC1
}

func (g *RadarStartDetectResponse) Size() uint16 {
	return 1
}

func (g *RadarStartDetectResponse) IsNeedAns() uint8 {
	return 0
}

type RadarEndDetectRequest struct {
}

func (g *RadarEndDetectRequest) ID() uint8 {
	return 0xC2
}

func (g *RadarEndDetectRequest) Size() uint16 {
	return 0
}

func (g *RadarEndDetectRequest) IsNeedAns() uint8 {
	return 1
}

func (g *RadarEndDetectRequest) Create(sourceId uint8) []byte {
	p, err := NewPacket(sourceId, uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type RadarEndDetectResponse struct {
	Status uint8
}

func (g *RadarEndDetectResponse) ID() uint8 {
	return 0xC2
}

func (g *RadarEndDetectResponse) Size() uint16 {
	return 1
}

func (g *RadarEndDetectResponse) IsNeedAns() uint8 {
	return 0
}

type RadarSetBeamPosRequest struct {
	EleScanCenter int8
	AziScanCenter int8
}

func (g *RadarSetBeamPosRequest) ID() uint8 {
	return 0xC3
}

func (g *RadarSetBeamPosRequest) Size() uint16 {
	return 2
}

func (g *RadarSetBeamPosRequest) IsNeedAns() uint8 {
	return 1
}

func (g *RadarSetBeamPosRequest) Create(sourceId uint8, eleScan, aziScan int8) []byte {
	g.EleScanCenter = eleScan
	g.AziScanCenter = aziScan
	p, err := NewPacket(sourceId, uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type RadarSetBeamPosResponse struct {
	Status uint8
}

func (g *RadarSetBeamPosResponse) ID() uint8 {
	return 0xC3
}

func (g *RadarSetBeamPosResponse) Size() uint16 {
	return 1
}

func (g *RadarSetBeamPosResponse) IsNeedAns() uint8 {
	return 0
}

type RadarSetBeamSizeRequest struct {
	EleScanCenter        int8  //俯仰扫描中心位置
	EleScanScope         uint8 //俯仰扫描范围
	AziScanCenter        int8  //方位扫描中心位置
	AziScanScope         uint8 //	方位扫描范围
	WaveFrequencyChannel uint8 // 波形频分通道
}

func (g *RadarSetBeamSizeRequest) ID() uint8 {
	return 0xC4
}

func (g *RadarSetBeamSizeRequest) Size() uint16 {
	return 5
}

func (g *RadarSetBeamSizeRequest) IsNeedAns() uint8 {
	return 1
}

func (g *RadarSetBeamSizeRequest) Create(sourceId uint8, eleScan, aziScan int8, eleScanScope, aziScanScope, waveFrequencyChannel uint8) []byte {
	g.EleScanCenter = eleScan
	g.AziScanCenter = aziScan
	g.EleScanScope = eleScanScope
	g.AziScanScope = aziScanScope
	g.WaveFrequencyChannel = waveFrequencyChannel
	p, err := NewPacket(sourceId, uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type RadarSetBeamSizeResponse struct {
	Status uint8
}

func (g *RadarSetBeamSizeResponse) ID() uint8 {
	return 0xC4
}

func (g *RadarSetBeamSizeResponse) Size() uint16 {
	return 1
}

func (g *RadarSetBeamSizeResponse) IsNeedAns() uint8 {
	return 0
}

type PostureCalibrationRequest struct {
}

func (g *PostureCalibrationRequest) ID() uint8 {
	return 0xCB
}

func (g *PostureCalibrationRequest) Size() uint16 {
	return 0
}

func (g *PostureCalibrationRequest) IsNeedAns() uint8 {
	return 1
}

func (g *PostureCalibrationRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_RADAR), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type PostureCalibrationResponse struct {
	Status uint8 `json:"status"`
}

func (g *PostureCalibrationResponse) ID() uint8 {
	return 0xCB
}

func (g *PostureCalibrationResponse) Size() uint16 {
	return 1
}

func (g *PostureCalibrationResponse) IsNeedAns() uint8 {
	return 0
}

type PostureCalibrationResultResponse struct {
	ULongitude int32 `json:"u_longitude"` //经度（单位为度）
	ULatitude  int32 `json:"u_latitude"`  //纬度（单位为度）
	UAltitude  int32 `json:"u_altitude"`  //海拔（单位为米）
	UHeading   int32 `json:"u_heading"`   //方位（单位为度）
	UPitching  int32 `json:"u_pitching"`  //俯仰（单位为度）
	URolling   int32 `json:"u_rolling"`   //横滚（单位为度）
}

func (g *PostureCalibrationResultResponse) ID() uint8 {
	return 0xCC
}

func (g *PostureCalibrationResultResponse) Size() uint16 {
	return 24
}

func (g *PostureCalibrationResultResponse) IsNeedAns() uint8 {
	return 0
}

type PostureCalibrationManualRequest struct {
	ULongitude int32 `json:"u_longitude"` //经度（单位为度）
	ULatitude  int32 `json:"u_latitude"`  //纬度（单位为度）
	UAltitude  int32 `json:"u_altitude"`  //海拔（单位为米）
	UHeading   int32 `json:"u_heading"`   //方位（单位为度）
	UPitching  int32 `json:"u_pitching"`  //俯仰（单位为度）
	URolling   int32 `json:"u_rolling"`   //横滚（单位为度）
}

func (g *PostureCalibrationManualRequest) ID() uint8 {
	return 0xCD
}

func (g *PostureCalibrationManualRequest) Size() uint16 {
	return 24
}

func (g *PostureCalibrationManualRequest) IsNeedAns() uint8 {
	return 1
}

func (g *PostureCalibrationManualRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_RADAR), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type PostureCalibrationManualResponse struct {
	Status uint8 `json:"status"`
}

func (g *PostureCalibrationManualResponse) ID() uint8 {
	return 0xCD
}

func (g *PostureCalibrationManualResponse) Size() uint16 {
	return 1
}

func (g *PostureCalibrationManualResponse) IsNeedAns() uint8 {
	return 0
}

type GetVersionInfoRequest struct {
}

func (g *GetVersionInfoRequest) ID() uint8 {
	return 0xAB
}

func (g *GetVersionInfoRequest) Size() uint16 {
	return 0
}

func (g *GetVersionInfoRequest) IsNeedAns() uint8 {
	return 1
}

func (g *GetVersionInfoRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_RADAR), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type GetVersionInfoResponse struct {
	RunVersion      uint32    `json:"run_version"`
	AppVersion      [64]uint8 `json:"app_version"`
	BootVersion     [32]uint8 `json:"boot_version"`
	HwVersion       [32]uint8 `json:"hw_version"`
	ProtocolVersion [32]uint8 `json:"protocol_version"`
}

func (g *GetVersionInfoResponse) ID() uint8 {
	return 0xAB
}

func (g *GetVersionInfoResponse) Size() uint16 {
	return 164
}

func (g *GetVersionInfoResponse) IsNeedAns() uint8 {
	return 0
}

// 向雷达  获取日志列表
type RadarGetLogListRequest struct {
}

func (p *RadarGetLogListRequest) ID() uint8 {
	return 0x28
}

func (p *RadarGetLogListRequest) Size() uint16 {
	return 0
}

func (p *RadarGetLogListRequest) IsNeedAns() uint8 {
	return 1
}

func (p *RadarGetLogListRequest) CreateRadarGetLogList() []byte {
	pac, err := NewPacket(uint8(common.DEV_RADAR), uint8(common.DEV_C2_WIFI), p)
	if err != nil {
		return nil
	}
	genBuff := pac.StructToSlice()
	return genBuff
}

var RadarResAll RadarGetLogListResponseAll

type RadarGetLogListResponseAll struct {
	LogListAll []RadarGetLogListResponse
	DataLock   sync.Mutex
}

func (this *RadarGetLogListResponseAll) SetData(data interface{}) {
	this.DataLock.Lock()
	defer this.DataLock.Unlock()
	logger.Debug("LogList load data:%v", data)
	data1 := data.(*RadarGetLogListResponse)
	this.LogListAll = append(this.LogListAll, *data1)
}
func (this *RadarGetLogListResponseAll) GetData() []RadarGetLogListResponse {
	this.DataLock.Lock()
	defer this.DataLock.Unlock()
	logger.Info("Get LogList data")
	return this.LogListAll
}
func (this *RadarGetLogListResponseAll) DeleteData() {
	this.DataLock.Lock()
	defer this.DataLock.Unlock()
	logger.Info("Del LogList data")
	this.LogListAll = this.LogListAll[:0]
}

// 获取日志列表响应
type RadarGetLogListResponse struct {
	PkgTotalNum  uint32
	PkgCurNum    uint32
	RadarLogInfo []RadarLogInfo
}

type RadarLogInfo struct {
	LogNameLen uint32
	LogDataLen uint32
	LogName    []byte
}

func (p *RadarGetLogListResponse) Len() int {
	//TODO implement me
	templen := 0
	for _, v := range p.RadarLogInfo {
		templen = templen + 8 + len(v.LogName)
	}
	return 8 + +templen
}
func (p *RadarGetLogListResponse) ID() uint8 {
	return 0x28
}

//func (p *GunGetLogListResponse) Size() uint8 {
//	var size int
//	for _, v := range p.LogInfo {
//		size += len(v.LogName) + 8
//	}
//	return uint8(size + 16)
//}

func (p *RadarGetLogListResponse) IsNeedAns() uint8 {
	return 0
}

type RadarGetLogRequestAll struct {
}

// 向雷达  获取日志文件
type RadarGetLogRequest struct {
	LogNum      uint32
	LogFileInfo [1]RadarLogFileInfo
}
type RadarLogFileInfo struct {
	LogId      uint32
	LogNameLen uint32
	LogName    []byte
}

func (p *RadarGetLogRequestAll) ID() uint8 {
	return 0x29
}

func (p *RadarGetLogRequestAll) Size() uint16 {
	return 4
}

func (p *RadarGetLogRequestAll) IsNeedAns() uint8 {
	return 1
}

func (p *RadarGetLogRequestAll) CreateRadarGetLog(logInfo []*RadarGetLogRequest) []byte {
	size := uint16(4 + len(logInfo)*(8+len(logInfo[0].LogFileInfo[0].LogName)))
	logger.Info("size is : ", size)
	rowLength := uint8(size & 0x00FF)
	highLength := uint8((size & 0xFF00) >> 8)
	mavPackage1 := &MavPacket{
		Header: MavHeader{
			FrameStart:        FrameStart,
			PayloadLowLength:  rowLength,
			PayloadHighLength: highLength,
			PacketSequence:    PackageSeq,
			ReceiveID:         uint8(common.DEV_RADAR),
			SendID:            uint8(common.DEV_C2_WIFI),
			MessageID:         p.ID(),
			Ans:               p.IsNeedAns(),
		},
		Msg: p,
	}
	var r1 bytes.Buffer
	if err := binary.Write(&r1, binary.LittleEndian, mavPackage1.Header); err != nil {
		logger.Error("Header binary Write err : ", err)
		return []byte{}
	}
	mavPackage1.RadarGetLogChecksum(r1)
	mavPackage := &MavPacket{
		Header: MavHeader{
			FrameStart:        FrameStart,
			PayloadLowLength:  rowLength,
			PayloadHighLength: highLength,
			PacketSequence:    PackageSeq,
			ReceiveID:         uint8(common.DEV_RADAR),
			SendID:            uint8(common.DEV_C2_WIFI),
			MessageID:         p.ID(),
			Ans:               p.IsNeedAns(),
			Checksum:          mavPackage1.RadarGetLogChecksum(r1),
		},
		Msg: p,
	}
	var r bytes.Buffer
	if err := binary.Write(&r, binary.LittleEndian, mavPackage.Header); err != nil {
		logger.Error("Header binary Write err : ", err)
		return []byte{}
	}

	if err := binary.Write(&r, binary.LittleEndian, p); err != nil {
		logger.Error("p binary Write err : ", err)
		return []byte{}
	}
	for _, v := range logInfo {
		if err := binary.Write(&r, binary.LittleEndian, v.LogNum); err != nil {
			logger.Error("range binary Write err : ", err)
			return []byte{}
		}
		for _, v2 := range v.LogFileInfo {
			if err := binary.Write(&r, binary.LittleEndian, v2.LogId); err != nil {
				logger.Error("LogId binary Write err : ", err)
				return []byte{}
			}
			if err := binary.Write(&r, binary.LittleEndian, v2.LogNameLen); err != nil {
				logger.Error("LogNameLen binary Write err : ", err)
				return []byte{}
			}
			if err := binary.Write(&r, binary.LittleEndian, v2.LogName); err != nil {
				logger.Error("LogName binary Write err : ", err)
				return []byte{}
			}
		}

	}

	dataBuff := r.Bytes()
	crc16 := CRC(dataBuff[CrcStartLoc:])
	crcArr := make([]byte, CrcLen)
	binary.BigEndian.PutUint16(crcArr, crc16)
	genBuff := make([]byte, 0)
	genBuff = append(genBuff, dataBuff...)
	genBuff = append(genBuff, crcArr[1])
	genBuff = append(genBuff, crcArr[0])
	logger.Info("send msg is:%v", genBuff)
	logger.Info("send msg is:%v", string(genBuff))
	return genBuff

}

var RadarLogMsgAll RadarGetLogMsgResponse

type RadarGetLogMsgResponse struct {
	//LogMsgAll GunGetLogResponse
	LogMsgAll []string
	DataLock  sync.Mutex
}

func (this *RadarGetLogMsgResponse) SetData(data string) {
	this.DataLock.Lock()
	defer this.DataLock.Unlock()
	logger.Debug("LogMsg load data:%v", data)
	this.LogMsgAll = append(this.LogMsgAll, data)
}
func (this *RadarGetLogMsgResponse) GetData() []string {
	this.DataLock.Lock()
	defer this.DataLock.Unlock()
	logger.Info("Get LogMsg data")
	return this.LogMsgAll
}
func (this *RadarGetLogMsgResponse) DeleteData() {
	this.DataLock.Lock()
	defer this.DataLock.Unlock()
	logger.Info("Del LogMsg data")
	this.LogMsgAll = this.LogMsgAll[:0]
}

// 删除日志文件响应
type RadarDelLogResponse struct {
	Status bool
}

func (r RadarDelLogResponse) ID() uint8 {
	return 0x2a
}

func (r RadarDelLogResponse) Size() uint16 {
	return 1
}

func (r RadarDelLogResponse) IsNeedAns() uint8 {
	return 0
}

// 向雷达  获取日志文件
type RadarDelLogRequestAll struct {
}
type RadarDelLogRequest struct {
	FolderNameLen uint32
	FolderName    []byte
}

func (p *RadarDelLogRequestAll) ID() uint8 {
	return 0x2A
}

func (p *RadarDelLogRequestAll) Size() uint16 {
	return 4
}

func (p *RadarDelLogRequestAll) IsNeedAns() uint8 {
	return 1
}

func (p *RadarDelLogRequestAll) CreateRadarDelLog(logDir string) []byte {
	logNameLen := len(logDir)

	size := uint16(4 + logNameLen)
	logger.Info("size is : ", size)
	rowLength := uint8(size & 0x00FF)
	highLength := uint8((size & 0xFF00) >> 8)
	mavPackage1 := &MavPacket{
		Header: MavHeader{
			FrameStart:        FrameStart,
			PayloadLowLength:  rowLength,
			PayloadHighLength: highLength,
			PacketSequence:    PackageSeq,
			ReceiveID:         uint8(common.DEV_RADAR),
			SendID:            uint8(common.DEV_C2_WIFI),
			MessageID:         p.ID(),
			Ans:               p.IsNeedAns(),
		},
		Msg: p,
	}
	var r1 bytes.Buffer
	if err := binary.Write(&r1, binary.LittleEndian, mavPackage1.Header); err != nil {
		logger.Error("Header binary Write err:", err)
		return []byte{}
	}
	mavPackage1.RadarGetLogChecksum(r1)
	mavPackage := &MavPacket{
		Header: MavHeader{
			FrameStart:        FrameStart,
			PayloadLowLength:  rowLength,
			PayloadHighLength: highLength,
			PacketSequence:    PackageSeq,
			ReceiveID:         uint8(common.DEV_RADAR),
			SendID:            uint8(common.DEV_C2_WIFI),
			MessageID:         p.ID(),
			Ans:               p.IsNeedAns(),
			Checksum:          mavPackage1.RadarGetLogChecksum(r1),
		},
		Msg: p,
	}
	var r bytes.Buffer
	if err := binary.Write(&r, binary.LittleEndian, mavPackage.Header); err != nil {
		logger.Error("Header binary Write err:", err)
		return []byte{}
	}

	if err := binary.Write(&r, binary.LittleEndian, p); err != nil {
		logger.Error("p binary Write err:", err)
		return []byte{}
	}
	if err := binary.Write(&r, binary.LittleEndian, uint32(logNameLen)); err != nil {
		logger.Error("logNameLen binary Write err:", err)
		return []byte{}
	}
	if err := binary.Write(&r, binary.LittleEndian, []byte(logDir)); err != nil {
		logger.Error("logDir binary Write err:", err)
		return []byte{}
	}
	dataBuff := r.Bytes()
	crc16 := CRC(dataBuff[CrcStartLoc:])
	crcArr := make([]byte, CrcLen)
	binary.BigEndian.PutUint16(crcArr, crc16)
	genBuff := make([]byte, 0)
	genBuff = append(genBuff, dataBuff...)
	genBuff = append(genBuff, crcArr[1])
	genBuff = append(genBuff, crcArr[0])
	logger.Info("send msg is:%v", genBuff)
	logger.Info("send msg is:%v", string(genBuff))
	return genBuff
}

type CommonGetChannelRequest struct {
	Sn         [32]uint8
	Company    [32]uint8
	DeviceName [32]uint8
	DeviceType uint16
	Version    [16]byte
}

func (d *CommonGetChannelRequest) ID() uint8 {
	return V2RadarIdRequestWifiChannel
}

func (d *CommonGetChannelRequest) Size() uint16 {
	return uint16(binary.Size(d))
}

func (d *CommonGetChannelRequest) IsNeedAns() uint8 {
	return 1
}

type CommonGetChannelResponse struct {
	Proxy       uint8
	GunIp       [4]uint8
	GunPort     uint16
	NewSourceID uint16
}

func (d *CommonGetChannelResponse) ID() uint8 {
	return V2RadarIdRequestWifiChannel
}

func (d *CommonGetChannelResponse) Size() uint16 {
	return uint16(binary.Size(d))
}

func (d *CommonGetChannelResponse) IsNeedAns() uint8 {
	return 0
}

func (d *CommonGetChannelResponse) CreateGetChannelResponse(sourceId uint8, ip string, port uint16) []byte {
	if ip == "" {
		return nil
	}
	ipSegArr := strings.Split(ip, ".")
	var uIps [4]uint8
	for i, v := range ipSegArr {
		tmp, _ := strconv.Atoi(v)
		uIps[i] = uint8(tmp)
	}
	d.GunIp = uIps
	d.GunPort = port
	d.Proxy = 1
	d.NewSourceID = uint16(sourceId)
	p, err := NewPacket(sourceId, uint8(common.DEV_C2_WIFI), d)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

// RadarResetSystemRequest 雷达复位请求
type RadarResetSystemRequest struct {
	ResetCode uint16 `json:"reset_code"`
	Type      uint16 `json:"type"`
}

func (g *RadarResetSystemRequest) ID() uint8 {
	return 0xA1
}

func (g *RadarResetSystemRequest) Size() uint16 {
	return 4
}

func (g *RadarResetSystemRequest) IsNeedAns() uint8 {
	return 0
}

func (g *RadarResetSystemRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_RADAR), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type RadarResetSystemResponse struct {
	Status uint8 `json:"status"`
}

func (g *RadarResetSystemResponse) ID() uint8 {
	return 0xA1
}

func (g *RadarResetSystemResponse) Size() uint16 {
	return 1
}

func (g *RadarResetSystemResponse) IsNeedAns() uint8 {
	return 0
}

// RadarGetUpdateWriteStatusRequest 获取固件更新写入状态请求
type RadarGetUpdateWriteStatusRequest struct {
}

func (g *RadarGetUpdateWriteStatusRequest) ID() uint8 {
	return 0xA6
}

func (g *RadarGetUpdateWriteStatusRequest) Size() uint16 {
	return 0
}

func (g *RadarGetUpdateWriteStatusRequest) IsNeedAns() uint8 {
	return 1
}

func (g *RadarGetUpdateWriteStatusRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_RADAR), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type RadarGetUpdateWriteStatusResponse struct {
	Status uint8  `json:"status"`
	Permil uint16 `json:"permil"`
}

func (g *RadarGetUpdateWriteStatusResponse) ID() uint8 {
	return 0xA6
}

func (g *RadarGetUpdateWriteStatusResponse) Size() uint16 {
	return 3
}

func (g *RadarGetUpdateWriteStatusResponse) IsNeedAns() uint8 {
	return 0
}

// RadarGetUpdateTimeoutRetryTimeRequest 获取固件升级超时重试时间
type RadarGetUpdateTimeoutRetryTimeRequest struct {
}

func (g *RadarGetUpdateTimeoutRetryTimeRequest) ID() uint8 {
	return 0xAE
}

func (g *RadarGetUpdateTimeoutRetryTimeRequest) Size() uint16 {
	return 0
}

func (g *RadarGetUpdateTimeoutRetryTimeRequest) IsNeedAns() uint8 {
	return 1
}

func (g *RadarGetUpdateTimeoutRetryTimeRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_RADAR), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type RadarGetUpdateTimeoutRetryTimeResponse struct {
	ImagePkgLenMax uint16 `json:"image_pkg_len_max"`
	CmdTimeoutMs   uint16 `json:"cmd_timeout_ms"`
	CheckTimeoutS  uint16 `json:"check_timeout_s"`
	WriteTimeoutS  uint16 `json:"write_timeout_s"`
}

func (g *RadarGetUpdateTimeoutRetryTimeResponse) ID() uint8 {
	return 0xAE
}

func (g *RadarGetUpdateTimeoutRetryTimeResponse) Size() uint16 {
	return 8
}

func (g *RadarGetUpdateTimeoutRetryTimeResponse) IsNeedAns() uint8 {
	return 0
}

// RadarRequestUpgradeRequest 请求固件升级
type RadarRequestUpgradeRequest struct {
	Data [256]uint8 `json:"data"`
}

func (g *RadarRequestUpgradeRequest) ID() uint8 {
	return 0xA7
}

func (g *RadarRequestUpgradeRequest) Size() uint16 {
	return 256
}

func (g *RadarRequestUpgradeRequest) IsNeedAns() uint8 {
	return 1
}

func (g *RadarRequestUpgradeRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_RADAR), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type RadarRequestUpgradeResponse struct {
	Status uint8 `json:"status"`
}

func (g *RadarRequestUpgradeResponse) ID() uint8 {
	return 0xA7
}

func (g *RadarRequestUpgradeResponse) Size() uint16 {
	return 8
}

func (g *RadarRequestUpgradeResponse) IsNeedAns() uint8 {
	return 0
}

// RadarVerifyImageRequest 请求固件升级
type RadarVerifyImageRequest struct {
}

func (g *RadarVerifyImageRequest) ID() uint8 {
	return 0xAC
}

func (g *RadarVerifyImageRequest) Size() uint16 {
	return 0
}

func (g *RadarVerifyImageRequest) IsNeedAns() uint8 {
	return 1
}

func (g *RadarVerifyImageRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_RADAR), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type RadarVerifyImageResponse struct {
	Status uint8 `json:"status"`
}

func (g *RadarVerifyImageResponse) ID() uint8 {
	return 0xAC
}

func (g *RadarVerifyImageResponse) Size() uint16 {
	return 1
}

func (g *RadarVerifyImageResponse) IsNeedAns() uint8 {
	return 0
}

// RadarRunAppRequest 请求运行固件App
type RadarRunAppRequest struct {
}

func (g *RadarRunAppRequest) ID() uint8 {
	return 0xAD
}

func (g *RadarRunAppRequest) Size() uint16 {
	return 0
}

func (g *RadarRunAppRequest) IsNeedAns() uint8 {
	return 1
}

func (g *RadarRunAppRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_RADAR), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type RadarRunAppResponse struct {
	Status uint8 `json:"status"`
}

func (g *RadarRunAppResponse) ID() uint8 {
	return 0xAD
}

func (g *RadarRunAppResponse) Size() uint16 {
	return 1
}

func (g *RadarRunAppResponse) IsNeedAns() uint8 {
	return 0
}

// RadarWriteUpdateDataRequest 写入固件数据
type RadarWriteUpdateDataRequest struct {
}

func (g *RadarWriteUpdateDataRequest) ID() uint8 {
	return 0xA9
}

func (g *RadarWriteUpdateDataRequest) Size() uint16 {
	return 0
}

func (g *RadarWriteUpdateDataRequest) IsNeedAns() uint8 {
	return 1
}

func (g *RadarWriteUpdateDataRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_RADAR), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type RadarWriteUpdateDataResponse struct {
	Status uint8 `json:"status"`
}

func (g *RadarWriteUpdateDataResponse) ID() uint8 {
	return 0xA9
}

func (g *RadarWriteUpdateDataResponse) Size() uint16 {
	return 1
}

func (g *RadarWriteUpdateDataResponse) IsNeedAns() uint8 {
	return 0
}

// RadarSendUpdatePkgRequest 发送升级固件数据
type RadarSendUpdatePkgRequest struct {
	ImageOffset uint32  `json:"image_offset"` // 数据偏移位置
	ImageLength uint32  `json:"image_length"` // 数据长度
	ImageData   []uint8 `json:"image_data"`   // 升级数据流，最大4096字节
}

func (g *RadarSendUpdatePkgRequest) ID() uint8 {
	return 0xA8
}

func (g *RadarSendUpdatePkgRequest) Size() uint16 {
	return uint16(g.Len())
}

func (g *RadarSendUpdatePkgRequest) IsNeedAns() uint8 {
	return 1
}

func (g *RadarSendUpdatePkgRequest) Len() int {
	return 8 + len(g.ImageData)
}

// Create 元素长度不固定使用protocols下的message进行编码
func (g *RadarSendUpdatePkgRequest) Create() ([]byte, error) {

	size := g.Size()
	rowLength := uint8(size & 0x00FF)
	highLength := uint8((size & 0xFF00) >> 8)
	var header MavHeader
	header = MavHeader{
		FrameStart:        FrameStart,
		PayloadLowLength:  rowLength,
		PayloadHighLength: highLength,
		PacketSequence:    PackageSeq,
		ReceiveID:         uint8(common.DEV_RADAR),
		SendID:            uint8(common.DEV_C2_WIFI),
		MessageID:         g.ID(),
		Ans:               g.IsNeedAns(),
	}
	header.Checksum = g.computeChecksum(header)
	genBuff := g.structToSlice(header)

	return genBuff, nil
}

func (g *RadarSendUpdatePkgRequest) bytes(header MavHeader) []byte {
	var r bytes.Buffer
	var err error
	if err = binary.Write(&r, binary.LittleEndian, header); err != nil {
		return []byte{}
	}
	if err = binary.Write(&r, binary.LittleEndian, g.ImageOffset); err != nil {
		return []byte{}
	}
	if err = binary.Write(&r, binary.LittleEndian, g.ImageLength); err != nil {
		return []byte{}
	}
	if err = binary.Write(&r, binary.LittleEndian, g.ImageData); err != nil {
		return []byte{}
	}
	return r.Bytes()
}

func (g *RadarSendUpdatePkgRequest) computeChecksum(header MavHeader) uint8 {
	var sum uint32
	buff := g.bytes(header)
	if buff == nil || len(buff) < CheckSumLen {
		return 0
	}
	sumData := buff[:CheckSumLen]
	for _, v := range sumData {
		sum += uint32(v)
	}
	return uint8(sum & 0xFF)
}

func (g *RadarSendUpdatePkgRequest) structToSlice(header MavHeader) []byte {
	dataBuff := g.bytes(header)
	if len(dataBuff) <= 0 {
		return dataBuff
	}
	crc16 := CRC(dataBuff[CrcStartLoc:])
	crcArr := make([]byte, CrcLen)
	binary.BigEndian.PutUint16(crcArr, crc16)
	genBuff := make([]byte, 0)
	genBuff = append(genBuff, dataBuff...)
	genBuff = append(genBuff, crcArr[1])
	genBuff = append(genBuff, crcArr[0])
	return genBuff
}

type RadarSendUpdatePkgResponse struct {
	Status uint8 `json:"status"`
}

func (g *RadarSendUpdatePkgResponse) ID() uint8 {
	return 0xA8
}

func (g *RadarSendUpdatePkgResponse) Size() uint16 {
	return 1
}

func (g *RadarSendUpdatePkgResponse) IsNeedAns() uint8 {
	return 0
}

package mavlink

import (
	"bytes"
	"encoding/binary"
	"fmt"

	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
)

const (
	AgxUdpBroadcastResponse = 0xBB
	C2SendHeartbeatToAgx    = 0x25

	AgxSelectUav = 0x81

	AgxMsgDetect            = 0xE8
	AgxMsgPerception        = 0xE9
	AgxMsgHeartBeat         = 0xEA
	AgxMsgDeviceStatus      = 0xEB
	AgxMsgPTZStatus         = 0xEC
	AgxCalibration          = 0xED
	AgxCalibrationResult    = 0xEF
	AgxEventOnLine          = 0xE0
	AgxEventOffOnLine       = 0xE1
	AgxEventDetectAppear    = 0xE2
	AgxEventDetectDisappear = 0xE3
	AgxEventPtzLockUavSucc  = 0xE4
	AgxEventPtzLockUavFail  = 0xE5
	AgxEventPushVideoDone   = 0xE6

	//sfl
	AgxTransferDevMsg = 0xFE //AGX转发其他设备的消息
	AgxSendMsgSfl     = 0xFD //Agx下发命令给SFL

	AgxOtaReSetCode = 0x55AA
)

type AgxSendSelectUavRequest struct {
	Type      uint8
	ObjId     uint32
	X         int32
	Y         int32
	Z         int32
	DroneName [25]byte
	Latitude  int32
	Longitude int32
}

func (g *AgxSendSelectUavRequest) ID() uint8 {
	return AgxSelectUav
}

func (g *AgxSendSelectUavRequest) Size() uint16 {
	return 50
}

func (g *AgxSendSelectUavRequest) IsNeedAns() uint8 {
	return 0
}

func (g *AgxSendSelectUavRequest) Create(req *client.AgxSelectUavRequest) []byte {
	g.Type = uint8(req.Type)
	g.X = int32(req.X * 1e6)
	g.Y = int32(req.Y * 1e6)
	g.Z = int32(req.Z * 1e6)
	g.Longitude = int32(req.Longitude * 1e7)
	g.Latitude = int32(req.Latitude * 1e7)
	g.ObjId = uint32(req.ObjId)
	var tmp [25]byte
	for i, v := range []byte(req.Sn) {
		tmp[i] = v
	}
	g.DroneName = tmp
	p, err := NewPacket(uint8(common.DEV_AGX), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type AgxSendSelectSflUavRequest struct {
	SlaveDevId         uint8
	SflSn              [25]byte
	TransferCmd        uint8
	CmdLen             uint32
	ProductType        uint8
	DroneName          [25]byte
	SerialNum          [32]byte
	DroneLongitude     int32
	DroneLatitude      int32
	DroneHeight        int16
	DroneYawAngle      int16
	DroneSpeed         int16
	DroneVerticalSpeed int16
	Speedderection     uint8
	DroneSailLongitude int32
	DroneSailLatitude  int32
	PilotLongitude     int32
	PilotLatitude      int32
	DroneHorizon       int32
	DronePitch         int32
	UFreq              uint32
	UDistance          uint16
	UDangerLevels      uint16
	UZC                uint16
	Reserve            [51]byte
}

func (g *AgxSendSelectSflUavRequest) ID() uint8 {
	return AgxSendMsgSfl
}

func (g *AgxSendSelectSflUavRequest) Size() uint16 {
	return 191
}

func (g *AgxSendSelectSflUavRequest) IsNeedAns() uint8 {
	return 1
}

func (g *AgxSendSelectSflUavRequest) Create(req *client.AgxSelectSflUavRequest) []byte {
	g.SlaveDevId = uint8(common.DEV_SFL)
	var tmp [25]byte
	for i, v := range []byte(req.AgxSn) {
		tmp[i] = v
	}
	g.SflSn = tmp
	g.CmdLen = 150
	var droneName [25]byte
	for i, v := range []byte(req.DroneName) {
		droneName[i] = v
	}
	g.DroneName = droneName
	var droneSn [32]byte
	for i, v := range []byte(req.DroneSn) {
		droneSn[i] = v
	}
	var reserve [51]byte
	g.Reserve = reserve
	g.SerialNum = droneSn
	g.DroneHorizon = int32(req.DroneHorizon * 100)
	g.DronePitch = int32(req.DronePitch * 100)
	g.DroneHeight = int16(req.DroneHeight * 10)
	g.TransferCmd = SflSendHitUav
	p, err := NewPacket(uint8(common.DEV_AGX), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type AgxSendSelectSflUavResponse struct {
	Status      uint8    //  1成功   2失败
	SlaveDevId  uint8    //转发设备类型，参考设备ID
	Sn          [25]byte //转发设备的SN
	TransferCmd uint8
}

func (g *AgxSendSelectSflUavResponse) ID() uint8 {
	return AgxSendMsgSfl
}

func (g *AgxSendSelectSflUavResponse) Size() uint16 {
	return 28
}

func (g *AgxSendSelectSflUavResponse) IsNeedAns() uint8 {
	return 0
}

type AgxSendCalibrationRequest struct {
	Status uint8
}

func (g *AgxSendCalibrationRequest) ID() uint8 {
	return AgxCalibration
}

func (g *AgxSendCalibrationRequest) Size() uint16 {
	return 1
}

func (g *AgxSendCalibrationRequest) IsNeedAns() uint8 {
	return 0
}
func (g *AgxSendCalibrationRequest) Create(req *client.AgxCalibrationRequest) []byte {
	g.Status = uint8(req.Status)

	p, err := NewPacket(uint8(common.DEV_AGX), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type AgxPerceptionResult struct {
	Info        AgxPerceptionInfo
	Description []*AgxPerceptionDescription
}

type AgxPerceptionInfo struct {
	TimeStamp uint64
	ObjNum    uint8
	TargetId  uint32
	Zoom      float32
	HFov      float32
	VFov      float32
	Reserve   int64
}
type AgxPerceptionDescription struct {
	Id             uint32
	Classification uint8
	RectX          uint16
	RectY          uint16
	RectW          uint16
	RectH          uint16
	RectXV         int16
	RectYV         int16
	ClassFvProb    float32
	Type           uint8
	TypeProb       float32
	LoadLever      uint8
	DangerLever    uint8
	Azimuth        float32
	Elevation      float32
	Range          float32
	MotionType     uint8
	BTracked       uint8
	Reserve        int64
}

func (d *AgxPerceptionResult) DeserializeDrone(msg []byte) error {
	buff := &bytes.Buffer{}
	if err := binary.Write(buff, binary.LittleEndian, msg); err != nil {
		return fmt.Errorf("DeserializeDrone write buff err: %v", err)
	}

	for i := 0; i < int(d.Info.ObjNum); i++ {
		var agxInfo AgxPerceptionDescription
		if err := binary.Read(buff, binary.LittleEndian, &agxInfo); err != nil {
			return fmt.Errorf("DeserializeDrone read buff err: %v", err)
		}
		d.Description = append(d.Description, &agxInfo)
	}

	return nil
}

type AgxHeart struct {
	Electricity uint8
	Status      uint8
	FaultNum    uint8
}

func (heart *AgxHeart) ID() uint8 {
	return AgxMsgHeartBeat
}

func (heart *AgxHeart) Size() uint16 {
	return 3
}
func (heart *AgxHeart) IsNeedAns() uint8 {
	return 0
}

type AgxDetectResult struct {
	Info        AgxDetectInfo
	Description []*AgxDetectDescription
}

type AgxDetectInfo struct {
	Status       uint8
	TrackObjNum  uint8
	TrackTwsNum  uint8
	TrackTasNum  uint8
	TrackObjByte uint8
	TimeStamp    uint64
}
type AgxDetectDescription struct {
	Id               uint16
	Classification   uint8
	ClassifyProb     uint8
	ExistingProb     uint8
	Ambiguous        uint8
	TwsTasFlag       uint8
	StateType        uint8
	MotionType       uint8
	Azimuth          int16
	TRange           uint32
	Elevation        int16
	Velocity         int16
	DopplerChn       int16
	Mag              uint16
	AbsVel           int16
	OrientationAngle int16
	Alive            uint16
	X                int32
	Y                int32
	Z                int32
	Vx               int16
	Vy               int16
	Vz               int16
	Ax               int16
	Ay               int16
	Az               int16
	XVariance        uint16
	YVariance        uint16
	ZVariance        uint16
	VxVariance       uint16
	VyVariance       uint16
	VzVariance       uint16
	AxVariance       uint16
	AyVariance       uint16
	AzVariance       uint16
	ForcastFrameNum  uint16
	AssociationNum   uint16
	AssocBit0        uint32
	AssocBit1        uint32 // 0: 就代表没有被PTZ锁定过，1就是有被锁定过; (temp definition)
}

func (d *AgxDetectResult) DeserializeDrone(msg []byte) error {
	buff := &bytes.Buffer{}
	if err := binary.Write(buff, binary.LittleEndian, msg); err != nil {
		return fmt.Errorf("DeserializeDrone write buff err: %v", err)
	}

	for i := 0; i < int(d.Info.TrackObjNum); i++ {
		var agxInfo AgxDetectDescription
		if err := binary.Read(buff, binary.LittleEndian, &agxInfo); err != nil {
			return fmt.Errorf("DeserializeDrone read buff err: %v", err)
		}
		d.Description = append(d.Description, &agxInfo)
	}

	return nil
}

type AgxTransferMsg struct {
	SlaveDevId  uint8
	Sn          [25]byte
	TransferCmd byte
	CmdLen      uint32
	Content     []byte
}

type AgxDevStateResult struct {
	Info        AgxDevStateInfo
	Description []*AgxDevStateDescription
}

type AgxDevStateInfo struct {
	ObjNumber uint8
}
type AgxDevStateDescription struct {
	DevType uint8 //设备类型  01雷达    02ptz    04tracer  05无线电设备
	DevSn   [25]byte
}

func (d *AgxDevStateResult) DeserializeDrone(msg []byte) error {
	buff := &bytes.Buffer{}
	if err := binary.Write(buff, binary.LittleEndian, msg); err != nil {
		return fmt.Errorf("DeserializeDrone write buff err: %v", err)
	}

	for i := 0; i < int(d.Info.ObjNumber); i++ {
		var agxInfo AgxDevStateDescription
		if err := binary.Read(buff, binary.LittleEndian, &agxInfo); err != nil {
			return fmt.Errorf("DeserializeDrone read buff err: %v", err)
		}
		d.Description = append(d.Description, &agxInfo)
	}

	return nil
}

type AgxPTZStateResultData struct {
	Info AgxPTZStateResult
}

type AgxPTZStateResult struct {
	SnName       [25]uint8
	TimeStamp    uint64
	PtzLongitude float32
	PtzLatitude  float32
	PtzHeight    float32
	Azimuth      float32
	Elevation    float32
	OmegaAz      float32
	OmegaEl      float32
	Zoom         float32
	Reserve      [40]byte
}

type ReceiveAgxCalibrationResultData struct {
	Info ReceiveAgxCalibrationResult
}
type ReceiveAgxCalibrationResult struct {
	Flag         int32
	AzimuthOff   float32
	ElevationOff float32
}

type AgxHeartbeatExtRequest struct {
	Sum uint8
}

func (d *AgxHeartbeatExtRequest) ID() uint8 {
	return C2SendHeartbeatToAgx
}

func (d *AgxHeartbeatExtRequest) Size() uint16 {
	return 1
}

func (d *AgxHeartbeatExtRequest) IsNeedAns() uint8 {
	return 0
}

func (d *AgxHeartbeatExtRequest) CreateAgxHeartbeatExt() []byte {
	p, err := NewPacket(uint8(common.DEV_AGX), uint8(common.DEV_C2_WIFI), d)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

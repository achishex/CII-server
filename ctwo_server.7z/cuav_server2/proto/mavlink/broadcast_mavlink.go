package mavlink

import (
	"bytes"
	"encoding/binary"
	"errors"
	"fmt"
	"strconv"
	"strings"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
)

const (
	UdpBroadCastDiscoverMsgId   = 0xBA
	UdpBroadCastConfirmRspMsgId = 0xBC
)

type UdpBroadCastMessage struct {
	Protocol uint32   //协议版本
	Sn       [32]byte //
}

func (g *UdpBroadCastMessage) ID() uint8 {
	return uint8(UdpBroadCastDiscoverMsgId)
}

func (g *UdpBroadCastMessage) Size() uint16 {
	return uint16(binary.Size(g))
}

func (g *UdpBroadCastMessage) IsNeedAns() uint8 {
	return 0
}

func (g *UdpBroadCastMessage) CreateUdpBoardMessage(sourceId uint8, ip string, port uint16) []byte {
	if ip == "" {
		return nil
	}
	ipSegArr := strings.Split(ip, ".")
	var uIps [4]uint8
	for i, v := range ipSegArr {
		tmp, _ := strconv.Atoi(v)
		uIps[i] = uint8(tmp)
	}
	sourceId = 0xFF
	g.Protocol = 2
	p, err := NewPacket(sourceId, uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type UdpBroadcastConfirmRequest struct {
	Protocol     uint32    //协议版本：数值越大版本越高
	Sn           [32]uint8 //设备唯一标识
	DeviceType   uint16    //设备类型
	DeviceStatus uint16    // 设备状态：等待连接、已连接
	Version      [64]byte  //版本信息
}

func (d *UdpBroadcastConfirmRequest) Decode(buff []byte) error {
	if buff == nil {
		return errors.New("buff empty")
	}
	if err := binary.Read(bytes.NewBuffer(buff), binary.LittleEndian, d); err != nil {
		return err
	}
	return nil
}

func (d *UdpBroadcastConfirmRequest) GetSn() string {
	return strings.TrimRight(string(d.Sn[:]), string(rune(0)))
}

func (d *UdpBroadcastConfirmRequest) ID() uint8 {
	return RadarUdpBroadcastResponse
}

func (d *UdpBroadcastConfirmRequest) Size() uint16 {
	return uint16(binary.Size(d))
}

func (d *UdpBroadcastConfirmRequest) IsNeedAns() uint8 {
	return 1
}

func (g *UdpBroadcastConfirmRequest) CreateUdpBoardMessage() []byte {
	g.Sn = [32]uint8{30, 31, 32}
	g.DeviceType = 2
	g.DeviceStatus = 2
	g.Protocol = 2
	p, err := NewPacket(2, uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	fmt.Println(genBuff)
	return genBuff
}

type UdpBroadcastConfirmResponse struct {
	Sn       [32]uint8
	Addr     [4]uint8
	Port     uint16
	ConnType uint16
}

func (d *UdpBroadcastConfirmResponse) Encode() []byte {
	buf := new(bytes.Buffer)
	if err := binary.Write(buf, binary.LittleEndian, d); err != nil {
		logger.Errorf("UdpBroadcastConfirmResponse Encode error")
		return nil
	}
	return buf.Bytes()
}

func (d *UdpBroadcastConfirmResponse) ID() uint8 {
	return uint8(UdpBroadCastConfirmRspMsgId)
}

func (d *UdpBroadcastConfirmResponse) Size() uint16 {
	return uint16(binary.Size(d))
}

func (d *UdpBroadcastConfirmResponse) IsNeedAns() uint8 {
	return 1
}

func (g *UdpBroadcastConfirmResponse) CreateUdpBoardMessage(devSn string, sourceId uint8, ip string, port uint16) []byte {
	if ip == "" {
		return nil
	}
	ipSegArr := strings.Split(ip, ".")
	var uIps [4]uint8
	for i, v := range ipSegArr {
		tmp, _ := strconv.Atoi(v)
		// 会有数组越界问题先这样解决
		if i < 4 {
			uIps[i] = uint8(tmp)
		}
	}
	var tmpSn [32]byte
	for i, v := range []byte(devSn) {
		tmpSn[i] = v
	}
	g.Sn = tmpSn
	sourceId = 0xFF
	g.Addr = uIps
	g.Port = port
	g.ConnType = 1
	p, err := NewPacket(sourceId, uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

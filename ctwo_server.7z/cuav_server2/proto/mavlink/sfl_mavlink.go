package mavlink

import (
	"bytes"
	"encoding/binary"
	"fmt"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
)

const (
	SflUdpBroadcastResponse = 0xBB
	C2SendHeartbeatToSfl    = 0x25

	SflDetectMsg    = 0xED
	SflHitStatusMsg = 0xEE
	SflHeartMsg     = 0xEF
	SflSetWhiteList = 0xC5

	SflHitTurn        = 0xCC
	SflHorizontalTurn = 0xCD
	SflVerticalTurn   = 0xCE

	SflGetVersion = 0x82
	SFLSetGNSS    = 0x83
	SFLGetGNSS    = 0x84
	SflSetPith    = 0x90
	SflSetAngle   = 0x92
	SflStopHit    = 0x99
	SflSetHitMode = 0xC6
	SflSetOnOff   = 0x9B
	SflReset      = 0x9D
	SflSendHitUav = 0x9E

	SflGetHitPith  = 0x91
	SflGetHitAngle = 0x93
	SflGetOnOff    = 0x9C
	SflGetHitMode  = 0xCB

	SflSetAutoHitMode = 0x97
	SflGetAutoHitMode = 0x98

	SflDetectMsgReport      = 300
	SflHitStatusMsgReport   = 301
	SflHeartMsgReport       = 302
	SflEventMsgOnline       = 401
	SflEventMsgOffLine      = 402
	SflEventDetectDisappear = 403
	SflEventDetectAppear    = 404
	SflEventHitSucc         = 405
	SflEventHitFail         = 406

	SflIdUpgradeF1 = 0xF1
	SflIdUpgradeF2 = 0xF2
	SflIdUpgradeF3 = 0xF3

	SflOtaReSetCode = 0x55AA
)

// SflHit 上传打击信息
type SflHit struct {
	Info SflHitInfo
}

type SflHitInfo struct {
	SN                 [25]uint8
	HitState           uint8     //  打击状态  1：打击中  2：打击结束
	ProductType        uint8     //无人机类型
	DroneName          [25]uint8 //字符串 无人机名称
	SerialNum          [32]uint8 //字符串 无人机SN
	DroneLongitude     int32     //无人机经度(/1e7/pi*180)
	DroneLatitude      int32     //无人机纬度(/1e7/pi*180)
	DroneHeight        int16     //无人机相对地面高度(0.1m)
	DroneYawAngle      int16     //无人机角度(0.01deg)
	DroneSpeed         int16     //无人机绝对速度(0.01m/s)
	DroneVerticalSpeed int16     //无人机垂直速度(0.01m/s)
	SpeedDerection     uint8     //0：无人机水平向前  lite 1：无人机水平向后  lite 2：无人机水平向左  lite 3：无人机水平向右  lite 4：无人机垂直 无效值为0xFF
	DroneSailLongitude int32     //无人机航点经度(/1e7)
	DroneSailLatitude  int32     //无人机航点经度(/1e7)
	PilotLongitude     int32     //飞手经度(/1e7/pi*180)
	PilotLatitude      int32     //飞手纬度(/1e7/pi*180)
	DroneHorizon       int32     //目标水平角(0.01°)
	DronePitch         int32     //目标俯仰角(0.01°)
	UFreq              uint32    //无人机信号频率(MHz)
	UDistance          uint16    //无人机与本设备的距离(m)
	UDangerLevels      uint16    //危险等级
	Uzc                uint16    //ZC序列值
	Reserve            [51]uint8 //保留值
}

type SflHitReport struct {
	SN                 string  `json:"sn"`
	HitState           int32   `json:"hit_state"`
	ProductType        int32   `json:"product_type"`         //无人机类型
	DroneName          string  `json:"drone_name"`           //字符串 无人机名称
	SerialNum          string  `json:"serial_num"`           //字符串 无人机SN
	DroneLongitude     float64 `json:"drone_longitude"`      //无人机经度(/1e7/pi*180)
	DroneLatitude      float64 `json:"drone_latitude"`       //无人机纬度(/1e7/pi*180)
	DroneHeight        float64 `json:"drone_height"`         //无人机相对地面高度(0.1m)
	DroneYawAngle      float64 `json:"drone_yaw_angle"`      //无人机角度(0.01deg)
	DroneSpeed         float64 `json:"drone_speed"`          //无人机绝对速度(0.01m/s)
	DroneVerticalSpeed float64 `json:"drone_vertical_speed"` //无人机垂直速度(0.01m/s)
	SpeedDirection     int32   `json:"speed_direction"`      //0：无人机水平向前  lite 1：无人机水平向后  lite 2：无人机水平向左  lite 3：无人机水平向右  lite 4：无人机垂直 无效值为0xFF
	DroneSailLongitude float64 `json:"drone_sail_longitude"` //无人机航点经度(/1e7)
	DroneSailLatitude  float64 `json:"drone_sail_latitude"`  //无人机航点经度(/1e7)
	PilotLongitude     float64 `json:"pilot_longitude"`      //飞手经度(/1e7/pi*180)
	PilotLatitude      float64 `json:"pilot_latitude"`       //飞手纬度(/1e7/pi*180)
	DroneHorizon       float64 `json:"drone_horizon"`        //目标水平角(0.01°)
	DronePitch         float64 `json:"drone_pitch"`          //目标俯仰角(0.01°)
	UFreq              float64 `json:"u_freq"`               //无人机信号频率(MHz)
	UDistance          int32   `json:"u_distance"`           //无人机与本设备的距离(m)
	UDangerLevels      int32   `json:"u_danger_levels"`      //危险等级
	Role               int32   `json:"role"`                 //无人机角色
}

type SflDetect struct {
	Info        SflDetectInfo
	Description []*SflDetectDescription
}
type SflDetectInfo struct {
	SN           [25]uint8
	DetectionNum uint8 //侦测信息个数
}
type SflDetectDescription struct {
	Source             uint8     //侦测源 0. 无 （为融合类型的信息时） 1．反制枪 2. tracer DroneID 3. tracer RemoteID n保留
	ProductType        uint8     //无人机类型
	DroneName          [25]uint8 //字符串 无人机名称
	SerialNum          [32]uint8 //字符串 无人机SN
	DroneLongitude     int32     //无人机经度(/1e7/pi*180)
	DroneLatitude      int32     //无人机纬度(/1e7/pi*180)
	DroneHeight        int16     //无人机相对地面高度(0.1m)
	DroneYawAngle      int16     //无人机角度(0.01deg)
	DroneSpeed         int16     //无人机绝对速度(0.01m/s)
	DroneVerticalSpeed int16     //无人机垂直速度(0.01m/s)
	SpeedDerection     uint8     //0：无人机水平向前  lite 1：无人机水平向后  lite 2：无人机水平向左  lite 3：无人机水平向右  lite 4：无人机垂直 无效值为0xFF
	DroneSailLongitude int32     //无人机航点经度(/1e7)
	DroneSailLatitude  int32     //无人机航点经度(/1e7)
	PilotLongitude     int32     //飞手经度(/1e7/pi*180)
	PilotLatitude      int32     //飞手纬度(/1e7/pi*180)
	DroneHorizon       int32     //目标水平角(0.01°)
	DronePitch         int32     //目标俯仰角(0.01°)
	UFreq              uint32    //无人机信号频率(MHz)
	UDistance          uint16    //无人机与本设备的距离(m)
	UDangerLevels      uint16    //危险等级
	Uzc                uint16    //ZC序列值
	Reserve            [51]uint8 //保留值
}

func (d *SflDetect) DeserializeDrone(msg []byte) error {
	buff := &bytes.Buffer{}
	if err := binary.Write(buff, binary.LittleEndian, msg); err != nil {
		return fmt.Errorf("SflDetectDescription write buff err: %v", err)
	}

	logger.Debug("Detect Num is :", d.Info.DetectionNum)
	for i := 0; i < int(d.Info.DetectionNum); i++ {
		var drone SflDetectDescription
		if err := binary.Read(buff, binary.LittleEndian, &drone); err != nil {
			return fmt.Errorf("SflDetectDescription read buff err: %v", err)
		}
		d.Description = append(d.Description, &drone)
	}
	return nil
}
func (d *SflDetect) checkDroneMsg(msg []byte) error {
	packageLen := binary.Size(SflDetectDescription{})
	if len(msg)/packageLen != int(d.Info.DetectionNum) || len(msg)%packageLen != 0 {
		return fmt.Errorf("sfl drone data len err: {msg len:%v, packageLen:%v, DroneNum:%v}", len(msg), packageLen, d.Info.DetectionNum)
	}
	return nil
}

// SflHeart Sfl 心跳消息
type SflHeart struct {
	Info SflHeartInfo
}
type SflHeartInfo struct {
	Sn              [25]uint8
	TimeStamp       uint32
	WorkStatus      uint8
	HitFreq         uint8
	DetectFreq      uint16
	Elevation       int32
	GunDirection    int32
	GunLongitude    int32
	GunLatitude     int32
	GunAltitude     int32
	SatellitesNum   uint16
	FaultLevel      uint8
	CtrlFault       uint8
	AeagFault       uint8
	TracerFault     uint8
	OthersFault     [4]byte
	WorkStatusParam uint8
}
type SflHeartReport struct {
	Sn            string  `json:"sn"`
	TimeStamp     int64   `json:"time_stamp"`
	WorkStatus    int     `json:"work_status"`
	IsOnline      int     `json:"is_online"`      //1 在线   2离线
	HitFreq       int8    `json:"hit_freq"`       //0：打击所有范围 1：打击小于2G 2：打击2-4G 3：打击4-6G 4：打击2G、2-4G 5：打击2-4G 、4-6G 6：打击2G、4-6G
	DetectFreq    float64 `json:"detect_freq"`    //侦测扫描频率（MHz）
	Elevation     float64 `json:"elevation"`      //枪俯仰角（0.00001°）
	GunDirection  float64 `json:"gun_direction"`  //枪方位（0.00001°）
	GunLongitude  float64 `json:"gun_longitude"`  //经度（0.00001°）
	GunLatitude   float64 `json:"gun_latitude"`   //纬度（0.00001°）
	GunAltitude   int     `json:"gun_altitude"`   //海拔高度（m）
	SatellitesNum int     `json:"satellites_num"` //GNSS卫星数量
	FaultLevel    int     `json:"fault_level"`    //异常等级 0：无异常 1:   1级异常，功能受限 2:   2级异常，无法使用 其他保留
	CtrlFault     int     `json:"ctrl_fault"`     //控制模块异常 0为正常    大于0为故障码
	AeagFault     int     `json:"aeag_fault"`     //反制模块异常   0为正常    大于0为故障码
	TracerFault   int     `json:"tracer_fault"`   //Tracer模块异常   0为正常    大于0为故障码
}

type SflGetChannelRequest struct {
	Sn         [32]uint8
	Company    [32]uint8
	DeviceName [32]uint8
	DeviceType uint16
	Version    [16]byte
}

func (d *SflGetChannelRequest) ID() uint8 {
	return DRONEIDMsgGetChannel
}

func (d *SflGetChannelRequest) Size() uint16 {
	return uint16(binary.Size(d))
}

func (d *SflGetChannelRequest) IsNeedAns() uint8 {
	return 1
}

type SflHeartbeatExtRequest struct {
	Sum uint8
}

func (d *SflHeartbeatExtRequest) ID() uint8 {
	return C2SendHeartbeatToSfl
}

func (d *SflHeartbeatExtRequest) Size() uint16 {
	return 1
}

func (d *SflHeartbeatExtRequest) IsNeedAns() uint8 {
	return 0
}

func (d *SflHeartbeatExtRequest) CreateSflHeartbeatExt() []byte {
	p, err := NewPacket(uint8(common.DEV_SFL), uint8(common.DEV_C2_WIFI), d)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

// SflGetVersionRequest Sfl获取版本信息请求
type SflGetVersionRequest struct {
}

func (g *SflGetVersionRequest) ID() uint8 {
	return SflGetVersion
}

func (g *SflGetVersionRequest) Size() uint16 {
	return 0
}

func (g *SflGetVersionRequest) IsNeedAns() uint8 {
	return 1
}

func (g *SflGetVersionRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_SFL), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type SflGetVersionResponse struct {
	AppVersion []byte //软件版本号
}

func (g *SflGetVersionResponse) ID() uint8 {
	return SflGetVersion
}

func (g *SflGetVersionResponse) Size() uint16 {
	return uint16(len(g.AppVersion))
}

func (g *SflGetVersionResponse) IsNeedAns() uint8 {
	return 0
}

// SflStopHitRequest Sfl获取版本信息请求
type SflStopHitRequest struct {
}

func (g *SflStopHitRequest) ID() uint8 {
	return SflStopHit
}

func (g *SflStopHitRequest) Size() uint16 {
	return 0
}

func (g *SflStopHitRequest) IsNeedAns() uint8 {
	return 1
}

func (g *SflStopHitRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_SFL), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type SflGNSSSetRequest struct {
	Type      uint8
	Longitude int32
	Latitude  int32
	Altitude  int32
}

func (g *SflGNSSSetRequest) ID() uint8 {
	return SFLSetGNSS
}

func (g *SflGNSSSetRequest) Size() uint16 {
	return 13
}

func (g *SflGNSSSetRequest) IsNeedAns() uint8 {
	return 1
}
func (g *SflGNSSSetRequest) Create(request *client.SflSetGNSSRequest) []byte {
	g.Type = uint8(request.Type)
	toFloat := 1e7
	g.Altitude = request.Altitude
	g.Longitude = int32(request.Longitude * toFloat)
	g.Latitude = int32(request.Latitude * toFloat)
	p, err := NewPacket(uint8(common.DEV_SFL), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type SflGNSSGetRequest struct {
}

func (g *SflGNSSGetRequest) ID() uint8 {
	return SFLGetGNSS
}

func (g *SflGNSSGetRequest) Size() uint16 {
	return 0
}

func (g *SflGNSSGetRequest) IsNeedAns() uint8 {
	return 1
}
func (g *SflGNSSGetRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_SFL), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type SflGNSSGetResponse struct {
	Type      uint8
	Longitude int32
	Latitude  int32
	Altitude  int32
}

func (g *SflGNSSGetResponse) ID() uint8 {
	return SFLGetGNSS
}

func (g *SflGNSSGetResponse) Size() uint16 {
	return 13
}

func (g *SflGNSSGetResponse) IsNeedAns() uint8 {
	return 0
}

type SflGNSSSetResponse struct {
	Status int8
}

func (g *SflGNSSSetResponse) ID() uint8 {
	return SFLSetGNSS
}

func (g *SflGNSSSetResponse) Size() uint16 {
	return 1
}

func (g *SflGNSSSetResponse) IsNeedAns() uint8 {
	return 0
}

type SflStopHitResponse struct {
	Status uint8
}

func (g *SflStopHitResponse) ID() uint8 {
	return SflStopHit
}

func (g *SflStopHitResponse) Size() uint16 {
	return 1
}

func (g *SflStopHitResponse) IsNeedAns() uint8 {
	return 0
}

// SflSetHitInfoRequest Sfl设置打击点信息   SflSetPith
type SflSetHitInfoRequest struct {
	HitCnt    uint8
	HitTime1  uint8
	HitPitch1 uint8
	HitTime2  uint8
	HitPitch2 uint8
}

func (g *SflSetHitInfoRequest) ID() uint8 {
	return SflSetPith
}

func (g *SflSetHitInfoRequest) Size() uint16 {
	return 5
}

func (g *SflSetHitInfoRequest) IsNeedAns() uint8 {
	return 1
}

func (g *SflSetHitInfoRequest) Create(request *client.SflHitAngleRequest) []byte {
	g.HitCnt = 2
	g.HitTime1 = uint8(request.HitTime)
	g.HitPitch1 = uint8(request.HitPitchBegin)
	g.HitTime2 = uint8(request.HitTime)
	g.HitPitch2 = uint8(request.HitPitchEnd)
	p, err := NewPacket(uint8(common.DEV_SFL), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type SflSetHitInfoResponse struct {
	Status uint8
}

func (g *SflSetHitInfoResponse) ID() uint8 {
	return SflSetPith
}

func (g *SflSetHitInfoResponse) Size() uint16 {
	return 1
}

func (g *SflSetHitInfoResponse) IsNeedAns() uint8 {
	return 0
}

// SflSetHitAngleRequest Sfl设置打击角度范围   SflSetAngle
type SflSetHitAngleRequest struct {
	HitAngleBegin uint16
	HitAngleEnd   uint16
}

func (g *SflSetHitAngleRequest) ID() uint8 {
	return SflSetAngle
}

func (g *SflSetHitAngleRequest) Size() uint16 {
	return 4
}

func (g *SflSetHitAngleRequest) IsNeedAns() uint8 {
	return 1
}

func (g *SflSetHitAngleRequest) Create(request *client.SflHitAngleRequest) []byte {
	g.HitAngleBegin = uint16(request.HitAngleBegin)
	g.HitAngleEnd = uint16(request.HitAngleEnd)

	p, err := NewPacket(uint8(common.DEV_SFL), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type SflSetHitAngleResponse struct {
	Status uint8
}

func (g *SflSetHitAngleResponse) ID() uint8 {
	return SflSetAngle
}

func (g *SflSetHitAngleResponse) Size() uint16 {
	return 1
}

func (g *SflSetHitAngleResponse) IsNeedAns() uint8 {
	return 0
}

// SflSetHitModeRequest Sfl设置打击模式
type SflSetHitModeRequest struct {
	Status uint8 //2：打击飞控图传 3：打击GNSS 4：打击飞控图传 + 打击GNSS 1DEV_SFL
}

func (g *SflSetHitModeRequest) ID() uint8 {
	return SflSetHitMode
}

func (g *SflSetHitModeRequest) Size() uint16 {
	return 1
}

func (g *SflSetHitModeRequest) IsNeedAns() uint8 {
	return 1
}

func (g *SflSetHitModeRequest) Create(request *client.SflHitAngleRequest) []byte {
	g.Status = uint8(request.HitMode)
	p, err := NewPacket(uint8(common.DEV_SFL), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type SflSetHitModeResponse struct {
	Status uint8
}

func (g *SflSetHitModeResponse) ID() uint8 {
	return SflSetHitMode
}

func (g *SflSetHitModeResponse) Size() uint16 {
	return 1
}

func (g *SflSetHitModeResponse) IsNeedAns() uint8 {
	return 0
}

// SflSetOnOffRequest Sfl设置开关机
type SflSetOnOffRequest struct {
	Status uint8
}

func (g *SflSetOnOffRequest) ID() uint8 {
	return SflSetOnOff
}

func (g *SflSetOnOffRequest) Size() uint16 {
	return 1
}

func (g *SflSetOnOffRequest) IsNeedAns() uint8 {
	return 1
}

func (g *SflSetOnOffRequest) Create(request *client.SflOnOffRequest) []byte {
	if request.Switch == 1 {
		g.Status = 0x0A
	}
	if request.Switch == 2 {
		g.Status = 0xF5
	}
	p, err := NewPacket(uint8(common.DEV_SFL), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type SflSetOnOffResponse struct {
	Status uint8
}

func (g *SflSetOnOffResponse) ID() uint8 {
	return SflSetOnOff
}

func (g *SflSetOnOffResponse) Size() uint16 {
	return 1
}

func (g *SflSetOnOffResponse) IsNeedAns() uint8 {
	return 0
}

// SflResetRequest Sfl复位
type SflResetRequest struct {
}

func (g *SflResetRequest) ID() uint8 {
	return SflReset
}

func (g *SflResetRequest) Size() uint16 {
	return 0
}

func (g *SflResetRequest) IsNeedAns() uint8 {
	return 1
}

func (g *SflResetRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_SFL), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type SflResetResponse struct {
	Status uint8
}

func (g *SflResetResponse) ID() uint8 {
	return SflReset
}

func (g *SflResetResponse) Size() uint16 {
	return 1
}

func (g *SflResetResponse) IsNeedAns() uint8 {
	return 0
}

// SflGetPitchRequest Sfl获取打击点参数
type SflGetPitchRequest struct {
}

func (g *SflGetPitchRequest) ID() uint8 {
	return SflGetHitPith
}

func (g *SflGetPitchRequest) Size() uint16 {
	return 0
}

func (g *SflGetPitchRequest) IsNeedAns() uint8 {
	return 1
}

func (g *SflGetPitchRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_SFL), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type SflGetPitchResponse struct {
	HitCnt         uint8
	HitDescription []*SflHitDescription
}
type SflHitDescription struct {
	HitTime  uint8
	HitPitch int8
}

func (d *SflGetPitchResponse) DeserializeDrone(msg []byte) error {
	buff := &bytes.Buffer{}
	if err := binary.Write(buff, binary.LittleEndian, msg); err != nil {
		return fmt.Errorf("SflDetectDescription write buff err: %v", err)
	}

	for i := 0; i < int(d.HitCnt); i++ {
		var drone SflHitDescription
		if err := binary.Read(buff, binary.LittleEndian, &drone); err != nil {
			return fmt.Errorf("SflDetectDescription read buff err: %v", err)
		}
		d.HitDescription = append(d.HitDescription, &drone)
	}
	return nil
}

// SflGetAngleRequest Sfl获取打击范围
type SflGetAngleRequest struct {
}

func (g *SflGetAngleRequest) ID() uint8 {
	return SflGetHitAngle
}

func (g *SflGetAngleRequest) Size() uint16 {
	return 0
}

func (g *SflGetAngleRequest) IsNeedAns() uint8 {
	return 1
}

func (g *SflGetAngleRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_SFL), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type SflGetAngleResponse struct {
	HitAngleBegin uint16
	HitAngleEnd   uint16
}

func (g *SflGetAngleResponse) ID() uint8 {
	return SflGetHitAngle
}

func (g *SflGetAngleResponse) Size() uint16 {
	return 4
}

func (g *SflGetAngleResponse) IsNeedAns() uint8 {
	return 0
}

// SflGetHitModeRequest Sfl获取打击范围
type SflGetHitModeRequest struct {
}

func (g *SflGetHitModeRequest) ID() uint8 {
	return SflGetHitMode
}

func (g *SflGetHitModeRequest) Size() uint16 {
	return 0
}

func (g *SflGetHitModeRequest) IsNeedAns() uint8 {
	return 1
}

func (g *SflGetHitModeRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_SFL), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type SflGetHitModeResponse struct {
	ModeStatus uint8 //2：打击飞控图传 3：打击GNSS 4：打击飞控图传 + 打击GNSS 1DEV_SFL

}

func (g *SflGetHitModeResponse) ID() uint8 {
	return SflGetHitMode
}

func (g *SflGetHitModeResponse) Size() uint16 {
	return 1
}

func (g *SflGetHitModeResponse) IsNeedAns() uint8 {
	return 0
}

// SflGetPowerRequest Sfl获取开关机状态
type SflGetPowerRequest struct {
}

func (g *SflGetPowerRequest) ID() uint8 {
	return SflGetOnOff
}

func (g *SflGetPowerRequest) Size() uint16 {
	return 0
}

func (g *SflGetPowerRequest) IsNeedAns() uint8 {
	return 1
}

func (g *SflGetPowerRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_SFL), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type SflGetPowerResponse struct {
	Status      uint8 //1成功   0失败
	PowerStatus uint8 //0xF5:关机    0x0A:开机
}

func (g *SflGetPowerResponse) ID() uint8 {
	return SflGetOnOff
}

func (g *SflGetPowerResponse) Size() uint16 {
	return 2
}

func (g *SflGetPowerResponse) IsNeedAns() uint8 {
	return 0
}

// SflSetAutoModeRequest
type SflSetAutoModeRequest struct {
	AutoHit uint8 //0 不自动打击    1  自动打击
}

func (g *SflSetAutoModeRequest) ID() uint8 {
	return SflSetAutoHitMode
}

func (g *SflSetAutoModeRequest) Size() uint16 {
	return 1
}

func (g *SflSetAutoModeRequest) IsNeedAns() uint8 {
	return 1
}

func (g *SflSetAutoModeRequest) Create(hitMode int32) []byte {
	if hitMode == 1 {
		g.AutoHit = 1
	}
	if hitMode == 2 {
		g.AutoHit = 0
	}
	p, err := NewPacket(uint8(common.DEV_SFL), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type SflSetAutoModeResponse struct {
	Status uint8 //0 失败  1 成功
}

func (g *SflSetAutoModeResponse) ID() uint8 {
	return SflSetAutoHitMode
}

func (g *SflSetAutoModeResponse) Size() uint16 {
	return 1
}

func (g *SflSetAutoModeResponse) IsNeedAns() uint8 {
	return 0
}

// SflGetAutoModeRequest
type SflGetAutoModeRequest struct {
}

func (g *SflGetAutoModeRequest) ID() uint8 {
	return SflGetAutoHitMode
}

func (g *SflGetAutoModeRequest) Size() uint16 {
	return 0
}

func (g *SflGetAutoModeRequest) IsNeedAns() uint8 {
	return 1
}

func (g *SflGetAutoModeRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_SFL), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type SflGetAutoModeResponse struct {
	AutoStatus uint8 //0 不自动打击  1 自动打击
}

func (g *SflGetAutoModeResponse) ID() uint8 {
	return SflGetAutoHitMode
}

func (g *SflGetAutoModeResponse) Size() uint16 {
	return 1
}

func (g *SflGetAutoModeResponse) IsNeedAns() uint8 {
	return 0
}

// SflSendHitUavRequest Sfl打击无人机
type SflSendHitUavRequest struct {
	ProductType        uint8
	DroneName          [25]byte
	SerialNum          [32]byte
	DroneLongitude     int32
	DroneLatitude      int32
	DroneHeight        int16
	DroneYawAngle      int16
	DroneSpeed         int16
	DroneVerticalSpeed int16
	Speedderection     uint8
	DroneSailLongitude int32
	DroneSailLatitude  int32
	PilotLongitude     int32
	PilotLatitude      int32
	DroneHorizon       int32
	DronePitch         int32
	UFreq              uint32
	UDistance          uint16
	UDangerLevels      uint16
	UZC                uint16 //zc序列值
	Reserve            [51]byte
}

func (g *SflSendHitUavRequest) ID() uint8 {
	return SflSendHitUav
}

func (g *SflSendHitUavRequest) Size() uint16 {
	return 160
}

func (g *SflSendHitUavRequest) IsNeedAns() uint8 {
	return 1
}

func (g *SflSendHitUavRequest) Create(request *client.SflSendHitUavRequest) []byte {
	var droneName [25]byte
	g.DroneName = droneName
	var droneSn [32]byte
	for i, v := range []byte(request.DroneSn) {
		droneSn[i] = v
	}
	g.SerialNum = droneSn
	g.DroneHorizon = int32(request.DroneHorizon * 100)
	g.DronePitch = int32(request.DronePitch * 100)
	g.DroneHeight = int16(request.DroneHeight * 10)
	var reserve [51]byte
	g.Reserve = reserve
	p, err := NewPacket(uint8(common.DEV_SFL), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type SflSendHitUavResponse struct {
	Status uint8 //  1成功   2失败
}

func (g *SflSendHitUavResponse) ID() uint8 {
	return SflSendHitUav
}

func (g *SflSendHitUavResponse) Size() uint16 {
	return 1
}

func (g *SflSendHitUavResponse) IsNeedAns() uint8 {
	return 0
}

// SflSetWhiteRequest 设置告警白名单
type SflSetWhiteRequestAll struct {
}
type SflSetWhiteRequest struct {
	WhiteNum  uint16
	WhiteList []SflWhiteInfo
}
type SflWhiteInfo struct {
	Serial [32]byte
}

func (g *SflSetWhiteRequestAll) ID() uint8 {
	return SflSetWhiteList
}

func (g *SflSetWhiteRequestAll) Size() uint16 {
	return 0
}

func (g *SflSetWhiteRequestAll) IsNeedAns() uint8 {
	return 1
}

func (g *SflSetWhiteRequestAll) Create(info *SflSetWhiteRequest) []byte {
	size := 2 + 32*info.WhiteNum
	logger.Info("Sfl SetWhite size is : ", size)
	rowLength := uint8(size & 0x00FF)
	highLength := uint8((size & 0xFF00) >> 8)
	mavPackage1 := &MavPacket{
		Header: MavHeader{
			FrameStart:        FrameStart,
			PayloadLowLength:  rowLength,
			PayloadHighLength: highLength,
			PacketSequence:    PackageSeq,
			ReceiveID:         uint8(common.DEV_SFL),
			SendID:            uint8(common.DEV_C2_WIFI),
			MessageID:         g.ID(),
			Ans:               g.IsNeedAns(),
		},
		Msg: g,
	}
	var r1 bytes.Buffer
	if err := binary.Write(&r1, binary.LittleEndian, mavPackage1.Header); err != nil {
		logger.Error("Header binary Write err : ", err)
		return []byte{}
	}
	mavPackage1.SflGetLogChecksum(r1)
	mavPackage := &MavPacket{
		Header: MavHeader{
			FrameStart:        FrameStart,
			PayloadLowLength:  rowLength,
			PayloadHighLength: highLength,
			PacketSequence:    PackageSeq,
			ReceiveID:         uint8(common.DEV_SFL),
			SendID:            uint8(common.DEV_C2_WIFI),
			MessageID:         g.ID(),
			Ans:               g.IsNeedAns(),
			Checksum:          mavPackage1.SflGetLogChecksum(r1),
		},
		Msg: g,
	}
	var r bytes.Buffer
	if err := binary.Write(&r, binary.LittleEndian, mavPackage.Header); err != nil {
		logger.Error("Header binary Write err : ", err)
		return []byte{}
	}
	if err := binary.Write(&r, binary.LittleEndian, g); err != nil {
		logger.Error("g binary Write err : ", err)
		return []byte{}
	}
	if err := binary.Write(&r, binary.LittleEndian, info.WhiteNum); err != nil {
		logger.Error("g binary Write err : ", err)
		return []byte{}
	}
	for _, v := range info.WhiteList {
		if err := binary.Write(&r, binary.LittleEndian, v.Serial); err != nil {
			logger.Error("DroneHorizon binary Write err : ", err)
			return []byte{}
		}
	}

	dataBuff := r.Bytes()
	crc16 := CRC(dataBuff[CrcStartLoc:])
	crcArr := make([]byte, CrcLen)
	binary.BigEndian.PutUint16(crcArr, crc16)
	genBuff := make([]byte, 0)
	genBuff = append(genBuff, dataBuff...)
	genBuff = append(genBuff, crcArr[1])
	genBuff = append(genBuff, crcArr[0])
	logger.Info("Sfl SetWhite send msg is:%v", genBuff)
	logger.Info("Sfl SetWhite send msg is:%v", string(genBuff))
	return genBuff
}
func (m *MavPacket) SflGetLogChecksum(r bytes.Buffer) uint8 {
	var sum uint32
	buff := r.Bytes()
	if buff == nil || len(buff) < CheckSumLen {
		return 0
	}
	sumData := buff[:CheckSumLen]

	for _, v := range sumData {
		sum += uint32(v)
	}
	m.Header.Checksum = uint8(sum & 0xFF)
	return m.Header.Checksum
}

// SflSetWhiteResponse 设置告警白名单  返回
type SflSetWhiteResponse struct {
	Status uint8 `json:"status"`
}

func (g *SflSetWhiteResponse) ID() uint8 {
	return SflSetWhiteList
}

func (g *SflSetWhiteResponse) Size() uint16 {
	return 1
}

func (g *SflSetWhiteResponse) IsNeedAns() uint8 {
	return 0
}

// SflUpdateF1Request 写入固件数据
type SflUpdateF1Request struct {
	Url           [256]byte //镜像文件的URL
	Authorization uint8     //0-无需验证，1-需要验证用户名密码
	UserName      [32]byte  //用户名
	Password      [32]byte  //密码
	Reserve       [4]byte
}

func (g *SflUpdateF1Request) ID() uint8 {
	return SflIdUpgradeF1
}

func (g *SflUpdateF1Request) Size() uint16 {
	return 325
}

func (g *SflUpdateF1Request) IsNeedAns() uint8 {
	return 1
}

func (g *SflUpdateF1Request) Create(fileName string, c2Ip string) []byte {
	url := " http://" + c2Ip + ":8081" + "/" + fileName
	logger.Info("send url is:", url)
	var tmp [256]byte
	for i, v := range []byte(url) {
		tmp[i] = v
	}
	g.Url = tmp
	g.Authorization = 0
	p, err := NewPacket(uint8(common.DEV_SFL), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type SflUpdateF1Response struct {
	Status uint8 `json:"status"` //0:成功    1：请求失败    10：状态错误    其他错误
}

func (g *SflUpdateF1Response) ID() uint8 {
	return SflIdUpgradeF1
}

func (g *SflUpdateF1Response) Size() uint16 {
	return 1
}

func (g *SflUpdateF1Response) IsNeedAns() uint8 {
	return 0
}

// SflUpdateF2Request 写入固件数据
type SflUpdateF2Request struct {
}

func (g *SflUpdateF2Request) ID() uint8 {
	return SflIdUpgradeF2
}

func (g *SflUpdateF2Request) Size() uint16 {
	return 0
}

func (g *SflUpdateF2Request) IsNeedAns() uint8 {
	return 1
}

func (g *SflUpdateF2Request) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_SFL), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type SflUpdateF2Response struct {
	Progress uint8 `json:"Progress"` //下载进度百分比 0~100
}

func (g *SflUpdateF2Response) ID() uint8 {
	return SflIdUpgradeF2
}

func (g *SflUpdateF2Response) Size() uint16 {
	return 1
}

func (g *SflUpdateF2Response) IsNeedAns() uint8 {
	return 0
}

type SflUpdateF3Response struct {
	UpgradeResult uint8 `json:"upgrade_result"` //0-成功 1-下载镜像失败 2-无效的镜像文件 3-Emmc不可写 4-其他原因
}

func (g *SflUpdateF3Response) ID() uint8 {
	return SflIdUpgradeF3
}

func (g *SflUpdateF3Response) Size() uint16 {
	return 1
}

func (g *SflUpdateF3Response) IsNeedAns() uint8 {
	return 0
}

// SflTurnHitRequest Sfl启动/停止打击
type SflTurnHitRequest struct {
	StartStop uint8 //0:停止打击   1:开启打击
}

func (g *SflTurnHitRequest) ID() uint8 {
	return SflHitTurn
}

func (g *SflTurnHitRequest) Size() uint16 {
	return 1
}

func (g *SflTurnHitRequest) IsNeedAns() uint8 {
	return 1
}

func (g *SflTurnHitRequest) Create(startStop uint8) []byte {
	g.StartStop = startStop
	if startStop == 2 {
		g.StartStop = 0 //停止打击
	}
	p, err := NewPacket(uint8(common.DEV_SFL), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type SflTurnHitResponse struct {
	Status uint8 //    0失败1成功
}

func (g *SflTurnHitResponse) ID() uint8 {
	return SflHitTurn
}

func (g *SflTurnHitResponse) Size() uint16 {
	return 1
}

func (g *SflTurnHitResponse) IsNeedAns() uint8 {
	return 0
}

// SflHorizontalTurnRequest Sfl水平转动
type SflHorizontalTurnRequest struct {
	StartStop uint8  //0:停止打击   1:开启打击
	Direction uint8  //1:顺时针转动   2:逆时针转动
	Angle     uint16 //转动角度 有效值范围 0-36000
	Speed     uint16 //转动速度  0表示最大速度转动
}

func (g *SflHorizontalTurnRequest) ID() uint8 {
	return SflHorizontalTurn
}

func (g *SflHorizontalTurnRequest) Size() uint16 {
	return 6
}

func (g *SflHorizontalTurnRequest) IsNeedAns() uint8 {
	return 1
}

func (g *SflHorizontalTurnRequest) Create(request *client.SflHorizontalTurnRequest) []byte {
	g.StartStop = uint8(request.StartStopTurn)
	if request.StartStopTurn == 2 {
		g.StartStop = 0
	}
	g.Direction = uint8(request.Direction)
	g.Angle = uint16(request.Angle)
	g.Speed = uint16(request.Speed)

	p, err := NewPacket(uint8(common.DEV_SFL), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type SflHorizontalTurnResponse struct {
	Status uint8 //    0失败  1成功
}

func (g *SflHorizontalTurnResponse) ID() uint8 {
	return SflHorizontalTurn
}

func (g *SflHorizontalTurnResponse) Size() uint16 {
	return 1
}

func (g *SflHorizontalTurnResponse) IsNeedAns() uint8 {
	return 0
}

// SflVerticalTurnRequest Sfl水平转动
type SflVerticalTurnRequest struct {
	StartStop uint8  //0:停止打击   1:开启打击
	Direction uint8  //1:向上转动   2:向下转动
	Angle     uint16 //转动角度 有效值范围 -4800-4800
	Speed     uint16 //转动速度  0表示最大速度转动
}

func (g *SflVerticalTurnRequest) ID() uint8 {
	return SflVerticalTurn
}

func (g *SflVerticalTurnRequest) Size() uint16 {
	return 6
}

func (g *SflVerticalTurnRequest) IsNeedAns() uint8 {
	return 1
}

func (g *SflVerticalTurnRequest) Create(request *client.SflVerticalTurnRequest) []byte {
	g.StartStop = uint8(request.StartStopTurn)
	if request.StartStopTurn == 2 {
		g.StartStop = 0
	}
	g.Direction = uint8(request.Direction)
	g.Angle = uint16(request.Angle)
	g.Speed = uint16(request.Speed)

	p, err := NewPacket(uint8(common.DEV_SFL), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type SflVerticalTurnResponse struct {
	Status uint8 //    0失败  1成功
}

func (g *SflVerticalTurnResponse) ID() uint8 {
	return SflVerticalTurn
}

func (g *SflVerticalTurnResponse) Size() uint16 {
	return 1
}

func (g *SflVerticalTurnResponse) IsNeedAns() uint8 {
	return 0
}

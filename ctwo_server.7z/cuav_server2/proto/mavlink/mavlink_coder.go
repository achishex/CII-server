package mavlink

import (
	"bytes"
	"encoding/binary"
	"errors"
	"fmt"

	"github.com/sigurn/crc16"
)

const (
	CheckSumLen = 8 //checksum 位校验长度
	HeaderLen   = 9 //header 的长度
	CrcLen      = 2 //CRC 校验位长度
	CrcStartLoc = 1 //CRC 开始位
	MsgIdLoc    = 6 //消息id在数组中的下标
	FrameLoc    = 0 //帧头在数组中的下标
	FrameStart  = uint8(0xFD)
	PackageSeq  = 0
	SenderLoc   = 5 //发送端id
)

// MavHeader Mavlink包头
type MavHeader struct {
	FrameStart        uint8
	PayloadLowLength  uint8
	PayloadHighLength uint8
	PacketSequence    uint8
	ReceiveID         uint8
	SendID            uint8
	MessageID         uint8
	Ans               uint8 //是否需要应答；0 不需要， 1 需要
	Checksum          uint8
}

// MavPacket Mavlink包
type MavPacket struct {
	Header MavHeader
	Msg    Message
}

// MavPacket Mavlink包体
type Message interface {
	ID() uint8
	Size() uint16
	IsNeedAns() uint8
}

func NewNullPacket(message Message) *MavPacket {
	packet := &MavPacket{
		Header: MavHeader{},
		Msg:    message,
	}
	return packet
}

func NewPacket(receiveID, sendID uint8, message Message) (*MavPacket, error) {
	size := uint16(message.Size())
	rowLength := uint8(size & 0x00FF)
	highLength := uint8((size & 0xFF00) >> 8)
	packet := &MavPacket{
		Header: MavHeader{
			FrameStart:        FrameStart,
			PayloadLowLength:  rowLength,
			PayloadHighLength: highLength,
			PacketSequence:    PackageSeq,
			ReceiveID:         receiveID,
			SendID:            sendID,
			MessageID:         message.ID(),
			Ans:               message.IsNeedAns(),
		},
		Msg: message,
	}
	//计算checkSum
	packet.ComputeChecksum()
	return packet, nil
}

func (m *MavHeader) Size() uint8 {
	return HeaderLen
}

func (m *MavPacket) ComputeChecksum() uint8 {
	var sum uint32
	buff := m.Bytes()
	if buff == nil || len(buff) < CheckSumLen {
		return 0
	}
	sumData := buff[:CheckSumLen]
	for _, v := range sumData {
		sum += uint32(v)
	}
	m.Header.Checksum = uint8(sum & 0xFF)
	return m.Header.Checksum
}
func (m *MavPacket) RadarGetLogChecksum(r bytes.Buffer) uint8 {
	var sum uint32
	buff := r.Bytes()
	if buff == nil || len(buff) < CheckSumLen {
		return 0
	}
	sumData := buff[:CheckSumLen]

	for _, v := range sumData {
		sum += uint32(v)
	}
	m.Header.Checksum = uint8(sum & 0xFF)
	return m.Header.Checksum
}
func (m *MavPacket) GunGetLogChecksum(r bytes.Buffer) uint8 {
	var sum uint32
	buff := r.Bytes()
	if buff == nil || len(buff) < CheckSumLen {
		return 0
	}
	sumData := buff[:CheckSumLen]

	for _, v := range sumData {
		sum += uint32(v)
	}
	m.Header.Checksum = uint8(sum & 0xFF)
	return m.Header.Checksum
}

func (m *MavPacket) Bytes() []byte {
	var r bytes.Buffer
	var err error

	if err = binary.Write(&r, binary.LittleEndian, m.Header); err != nil {
		return []byte{}
	}

	if err = binary.Write(&r, binary.LittleEndian, m.Msg); err != nil {
		return []byte{}
	}

	return r.Bytes()
}

func (m *MavPacket) StructToSlice() []byte {
	dataBuff := m.Bytes()
	if len(dataBuff) <= 0 {
		return dataBuff
	}
	crc16 := CRC(dataBuff[CrcStartLoc:])
	crcArr := make([]byte, CrcLen)
	binary.BigEndian.PutUint16(crcArr, crc16)
	genBuff := make([]byte, 0)
	genBuff = append(genBuff, dataBuff...)
	genBuff = append(genBuff, crcArr[1])
	genBuff = append(genBuff, crcArr[0])
	return genBuff
}

func GetDataLen(data []byte) int {
	if len(data) < 3 {
		return 0
	}
	var tmp = uint16(data[2])
	num := (tmp << 8) | uint16(data[1])
	return int(num)
}

func GetPacketLen(data []byte) int {
	return GetDataLen(data) + HeaderLen + CrcLen
}

func CheckChecksum(buff []byte) error {
	var tmp uint32
	//0-6字节的和校验
	if buff == nil || len(buff) < HeaderLen {
		return errors.New("长度不符合")
	}
	for _, v := range buff[:CheckSumLen] {
		tmp += uint32(v)
	}
	sum := uint8(tmp & 0xFF)
	if buff[CheckSumLen] != sum {
		return errors.New("checksum err")
	}
	return nil
}

func CRC(data []byte) uint16 {
	table := crc16.MakeTable(crc16.CRC16_MCRF4XX)
	crc := crc16.Checksum(data, table)
	return crc
}

func CheckFrame(data []byte) error {
	if data[FrameLoc] != FrameStart {
		return errors.New("帧头错误")
	}
	return nil
}

func CheckCrc(data []byte) error {
	dataLen := len(data)
	crc16 := CRC(data[CrcStartLoc : dataLen-CrcLen])
	crcArr := make([]byte, CrcLen)
	binary.BigEndian.PutUint16(crcArr, crc16)
	if data[dataLen-1] != crcArr[0] || data[dataLen-2] != crcArr[1] {
		return fmt.Errorf("CRC数据错误, cmd: %x", data[MsgIdLoc])
	}
	return nil
}

package mavlink

import (
	"bytes"
	"encoding/binary"
	"fmt"
	"math"
	"strconv"
	"strings"
	"sync"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
)

const (
	DroneIDGetVersionInfo        = 0x20
	DRONEIDMsgGetChannel         = 0xB3
	DRONEIDMsgHeartbeat          = 0xEF
	TracerIdGetDetectRes         = 0xE0
	TracerIdGetRemoteIdDetectRes = 0xE1
	TracerIdGetFreqDetectRes     = 0xE2
	TracerIdGetNewFreqDetectRes  = 0xE4
	TracerIdGetFreqDataRes       = 0xE6 //上报频谱数据
	TracerIdGetFreqDetectResExp  = 0xE8 // 上传频谱侦测结果0xE2扩展 (0xE8)
	C2MsgHeartbeat               = 0x25
	TracerIdGetVersionInfo       = 0xAB // 获取版本信息
	TracerIdResetSystem          = 0xA1 // 系统复位
	TracerIdGetUpdateWriteStatus = 0xA6 // 获取固件写入状态
	TracerIdRequestUpgrade       = 0xA7 // 请求固件升级
	TracerIdSendUpdatePkg        = 0xA8 // 发送升级固件数据
	TracerIdWriteUpdateData      = 0xA9 // 写入固件数据
	TracerIdRunApp               = 0xAD // 运行固件App
	TracerIdVerifyImage          = 0xAC // 校验固件镜像
	TracerIdGetTimeoutRetryTime  = 0xAE // 获取运行超时重试时间
	TracerIdGetLogList           = 0x28 //获取日志列表
	TracerIdGetLog               = 0x29 //获取日志文件
	TracerIdDeleteLog            = 0x2A //删除日志文件
	TracerIdGetTime              = 0xE3 //Tracer获取时间
	TracerSetOrientationMode     = 0x21 //设置定向模式
	TracerGetWorkMode            = 0x22 //获取工作模式
	TracerCliSend                = 0x2F //下发tracer指令
	TracerSetWhiteList           = 0xC5 //设置告警白名单
	TracerSetAlarmLevel          = 0xC6 //设置告警等级
	TracerSetHideMode            = 0xC7 //设置隐蔽模式
	TracerControlVideo           = 0xC8 //控制进入、退出视频流
	TracerGetDevTypeInfo         = 0x36 //获取Tracer设备类型

	TracerIdUpgradeF1 = 0xF1
	TracerIdUpgradeF2 = 0xF2
	TracerIdUpgradeF3 = 0xF3

	TracerEventOnLine          = 0xE0
	TracerEventOffLine         = 0xE1
	TracerEventDetectAppear    = 0xE2
	TracerEventDetectDisappear = 0xE3

	TracerOtaReSetCode = 0x55AA
)

type DroneIDHeartbeatOld struct {
	Info DeviceInfoOld
}

type DeviceInfoOld struct {
	TimeStamp     uint32
	Electricity   uint8
	BatteryStatus uint8 //0：电池 1：电池 + 适配器（充电） 2：适配器
	WorkMode      uint8 //工作模式 1:Droneid模式  2:全向侦测模式  3:定向侦测模式
	WorkStatus    uint8 //TRACER工作状态 0：待机 1: 侦测 2：打击中 3：水平扫描中 4：水平瞄准中 5：俯仰扫描中 6：俯仰瞄准中 7：瞄准完成
	AlarmLevel    uint8 //0: 拨码开关关闭，无告警 1: 低档告警 2: 中档告警 3: 高档告警
	SN            [25]uint8
}
type DroneIDHeartbeat struct {
	Info DeviceInfo
}

type DeviceInfo struct {
	TimeStamp     uint32
	Electricity   uint8
	BatteryStatus uint8 //0：电池 1：电池 + 适配器（充电） 2：适配器
	WorkMode      uint8 //工作模式 1:Droneid模式  2:全向侦测模式  3:定向侦测模式
	WorkStatus    uint8 //TRACER工作状态 0：待机 1: 侦测 2：打击中 3：水平扫描中 4：水平瞄准中 5：俯仰扫描中 6：俯仰瞄准中 7：瞄准完成
	Fault         uint8 //0：没有故障 1：有故障 2：其他故障依次添加
	AlarmLevel    uint8 //0: 拨码开关关闭，无告警 1: 低档告警 2: 中档告警 3: 高档告警
	Buzzer        uint8 //0: 蜂鸣器不响 1：蜂鸣器响
	Vibration     uint8 //0: 马达震动关闭 1：马达震动打开
	StealthMode   uint8 //0: 隐蔽模式关闭 1：隐蔽模式打开
	Recerve       int32 //保留
	SN            [25]uint8
}

func (d *DeviceInfo) Size() uint16 {
	return uint16(binary.Size(d))
}

type DroneIDReport struct {
	TimeStamp     uint32 `json:"timeStamp"`
	Electricity   uint8  `json:"electricity"`
	Sn            string `json:"sn"`
	IsOnline      int    `json:"is_online"`
	BatteryStatus uint8  `json:"batteryStatus"`   //0：电池 1：电池 + 适配器（充电） 2：适配器
	WorkMode      uint8  `json:"workMode"`        //工作模式 1:Droneid模式  2:全向侦测模式  3:定向侦测模式
	WorkStatus    uint8  `json:"workStatus"`      //TRACER工作状态 0：待机 1: 侦测 2：打击中 3：水平扫描中 4：水平瞄准中 5：俯仰扫描中 6：俯仰瞄准中 7：瞄准完成
	Fault         uint8  `json:"fault"`           //0：没有故障 1：有故障 2：其他故障依次添加
	AlarmLevel    uint8  `json:"alarmLevel"`      //0: 拨码开关关闭，无告警 1: 低档告警 2: 中档告警 3: 高档告警
	BuzzerOn      uint8  `json:"buzzer_on"`       //0: 蜂鸣器不响 1：蜂鸣器响
	VibrationOn   uint8  `json:"vibration_on"`    //0: 马达震动关闭 1：马达震动打开
	StealthModeOn uint8  `json:"stealth_mode_on"` //0: 隐蔽模式关闭 1：隐蔽模式打开
}

type DroneInfo struct {
	Name               string  `json:"name"`
	ProductType        uint8   `json:"product_type"`
	DroneName          string  `json:"drone_name"`
	SerialNum          string  `json:"serial_num"`
	DroneLongitude     float64 `json:"drone_longitude"`
	DroneLatitude      float64 `json:"drone_latitude"`
	DroneHeight        float64 `json:"drone_height"`
	DroneYawAngle      float64 `json:"drone_yaw_angle"`
	DroneSpeed         float64 `json:"drone_speed"`
	DroneVerticalSpeed float64 `json:"drone_vertical_speed"`
	OperatorLongitude  float64 `json:"operator_longitude"`
	OperatorLatitude   float64 `json:"operator_latitude"`
	DroneHorizon       float64 `json:"drone_horizon"`
	DronePitch         float64 `json:"drone_pitch"`
	Freq               float64 `json:"freq"`
	Distance           uint16  `json:"distance"`
	DangerLevels       uint16  `json:"danger_levels"`
	WaypointLongitude  float64 `json:"waypoint_longitude"`
	WaypointLatitude   float64 `json:"waypoint_latitude"`
}

func (d *TracerDetectResult) DroneCoordinateConvert(x float64) float64 {
	return x / 1e7 / math.Pi * 180
}

// 上传DroneID侦测结果
type TracerDetectResult struct {
	Info        TracerDetectInfo
	Description []*TracerDetectDescription
}
type TracerDetectInfo struct {
	SN       [25]uint8
	DroneNum uint8
}
type TracerDetectDescription struct {
	ProductType        uint8     //无人机类型
	DroneName          [25]uint8 //无人机品牌+机型
	SerialNum          [32]uint8 //无人机Sn码
	DroneLongitude     int32     //经度
	DroneLatitude      int32     //纬度
	DroneHeight        int16     //高度
	DroneYawAngle      int16     //偏航角
	DroneSpeed         int16     //速度
	DroneVerticalSpeed int16     //垂直速度
	OperatorLongitude  int32     //飞手经度
	OperatorLatitude   int32     //飞手纬度
	Freq               uint32    //频率
	Distance           uint16    //距离
	DangerLevels       uint16    //危险等级
}
type TracerDetectReport struct {
	Sn          string                           `json:"sn"`
	Description []*TracerDetectDescriptionReport `json:"info"`
}
type TracerDetectDescriptionReport struct {
	ProductType        uint8   `json:"product_type"`         //无人机类型
	DroneName          string  `json:"drone_name"`           //无人机品牌+机型
	SerialNum          string  `json:"serial_num"`           //无人机Sn码
	DroneLongitude     float64 `json:"drone_longitude"`      //经度
	DroneLatitude      float64 `json:"drone_latitude"`       //纬度
	DroneHeight        float64 `json:"drone_height"`         //高度
	DroneYawAngle      float64 `json:"drone_yaw_angle"`      //偏航角
	DroneSpeed         float64 `json:"drone_speed"`          //速度
	DroneVerticalSpeed float64 `json:"drone_vertical_speed"` //垂直速度
	OperatorLongitude  float64 `json:"operator_longitude"`   //飞手经度
	OperatorLatitude   float64 `json:"operator_latitude"`    //飞手纬度
	Freq               float64 `json:"freq"`                 //频率
	Distance           uint16  `json:"distance"`             //距离
	DangerLevels       uint16  `json:"danger_levels"`        //危险等级
	Role               int32   `json:"role"`                 //无人机角色
}

func (d *TracerDetectResult) DeserializeDrone(msg []byte) error {
	if err := d.checkDroneMsg(msg); err != nil {
		d.Info.DroneNum = 0
		return nil
	}

	//drones := make([]*Drone, 0)
	//packageLen := binary.Size(DroneID{})
	buff := &bytes.Buffer{}
	if err := binary.Write(buff, binary.LittleEndian, msg); err != nil {
		return fmt.Errorf("DeserializeDrone write buff err: %v", err)
	}

	for i := 0; i < int(d.Info.DroneNum); i++ {
		var drone TracerDetectDescription
		if err := binary.Read(buff, binary.LittleEndian, &drone); err != nil {
			return fmt.Errorf("DeserializeDrone read buff err: %v", err)
		}
		d.Description = append(d.Description, &drone)
	}

	return nil
}
func (d *TracerDetectResult) checkDroneMsg(msg []byte) error {
	packageLen := binary.Size(TracerDetectDescription{})
	if len(msg)/packageLen != int(d.Info.DroneNum) || len(msg)%packageLen != 0 {
		return fmt.Errorf("drone data len err: {msg len:%v, packageLen:%v, DroneNum:%v}", len(msg), packageLen, d.Info.DroneNum)
	}
	return nil
}

// 上传RemoteID侦测结果
func (d *TracerRemoteDetectResult) DroneCoordinateConvert(x float64) float64 {
	return x / 1e7
}

type TracerRemoteDetectResult struct {
	Info        TracerRemoteDetectInfo
	Description []*TracerRemoteDetectDescription
}
type TracerRemoteDetectInfo struct {
	SN       [25]uint8
	DroneNum uint8
}
type TracerRemoteDetectDescription struct {
	ProductType         uint8     //无人机类型
	DroneName           [25]uint8 //无人机 厂商 品牌+机型
	SerialNum           [32]uint8 //无人机Sn码
	DroneLongitude      int32     //经度
	DroneLatitude       int32     //纬度
	DroneHeight         int16     //高度
	DroneDirection      int16     //无人机角度
	DroneSpeed          int16     //速度
	DroneSpeedderection uint8     //0:无人机向前 1:向后  2:向左  3:向右 4:垂直
	DroneVerticalSpeed  int16     //垂直速度
	OperatorLongitude   int32     //飞手经度
	OperatorLatitude    int32     //飞手纬度
	Freq                uint32    //频率
	Distance            uint16    //距离
	DangerLevels        uint16    //危险等级
}
type TracerRemoteDetectReport struct {
	Sn          string                                 `json:"sn"`
	Description []*TracerRemoteDetectDescriptionReport `json:"info"`
}
type TracerRemoteDetectDescriptionReport struct {
	ProductType         uint8   `json:"product_type"`         //无人机类型
	DroneName           string  `json:"drone_name"`           //无人机品牌+机型
	SerialNum           string  `json:"serial_num"`           //无人机Sn码
	DroneLongitude      float64 `json:"drone_longitude"`      //经度
	DroneLatitude       float64 `json:"drone_latitude"`       //纬度
	DroneHeight         float64 `json:"drone_height"`         //高度
	DroneDirection      float64 `json:"drone_direction"`      //无人机角度
	DroneYawAngle       float64 `json:"drone_yaw_angle"`      //偏航角
	DroneSpeed          float64 `json:"drone_speed"`          //速度
	DroneSpeedderection uint8   `json:"drone_speedderection"` //0:无人机向前 1:向后  2:向左  3:向右 4:垂直
	DroneVerticalSpeed  float64 `json:"drone_vertical_speed"` //垂直速度
	OperatorLongitude   float64 `json:"operator_longitude"`   //飞手经度
	OperatorLatitude    float64 `json:"operator_latitude"`    //飞手纬度
	Freq                float64 `json:"freq"`                 //频率
	Distance            uint16  `json:"distance"`             //距离
	DangerLevels        uint16  `json:"danger_levels"`        //危险等级
	Role                int32   `json:"role"`                 //无人机角色
}

func (d *TracerRemoteDetectResult) DeserializeDrone(msg []byte) error {
	if err := d.checkDroneMsg(msg); err != nil {
		d.Info.DroneNum = 0
		return nil
	}

	//drones := make([]*Drone, 0)
	//packageLen := binary.Size(DroneID{})
	buff := &bytes.Buffer{}
	if err := binary.Write(buff, binary.LittleEndian, msg); err != nil {
		return fmt.Errorf("DeserializeDrone write buff err: %v", err)
	}

	for i := 0; i < int(d.Info.DroneNum); i++ {
		var drone TracerRemoteDetectDescription
		if err := binary.Read(buff, binary.LittleEndian, &drone); err != nil {
			return fmt.Errorf("DeserializeDrone read buff err: %v", err)
		}
		d.Description = append(d.Description, &drone)
	}

	return nil
}
func (d *TracerRemoteDetectResult) checkDroneMsg(msg []byte) error {
	packageLen := binary.Size(TracerRemoteDetectDescription{})
	if len(msg)/packageLen != int(d.Info.DroneNum) || len(msg)%packageLen != 0 {
		return fmt.Errorf("drone data len err: {msg len:%v, packageLen:%v, DroneNum:%v}", len(msg), packageLen, d.Info.DroneNum)
	}
	return nil
}

// 上传TracerS 上报的频谱仪数据
type TracerSFreqDataResult struct {
	Info        TracerSFreqDataInfo
	Description []*TracerSFreqDataDescription
}
type TracerSFreqDataInfo struct {
	SN      [25]uint8
	FreqNum uint32
}
type TracerSFreqDataDescription struct {
	AmpValue float32
}

func (d *TracerSFreqDataResult) DeserializeFreqData(msg []byte) error {
	buff := &bytes.Buffer{}
	if err := binary.Write(buff, binary.LittleEndian, msg); err != nil {
		return fmt.Errorf("DeserializeFreqData Drone write buff err: %v", err)
	}

	for i := 0; i < int(d.Info.FreqNum*10); i++ {
		dataInfo := TracerSFreqDataDescription{}
		if err := binary.Read(buff, binary.LittleEndian, &dataInfo); err != nil {
			return fmt.Errorf("DeserializeFreqData read buff err: %v", err)
		}
		d.Description = append(d.Description, &dataInfo)
	}

	return nil
}

type TracerSFreqDetectExpDesc struct {
	UavNumber     uint32    //无人机编号
	DroneName     [25]uint8 //无人机品牌+机型
	DroneHorizon  int32     //lsb 目标水平角（0.01°），无效值0x7fffffff
	UFreq         uint32    //频率
	UDangerLevels uint16    //危险等级
	Reserve1      uint8     //保留 uMoving
	Reserve4      float32   //dist
	//保留（上报模拟图像制式）
	Reserve42 int32
	//是否支持定向：
	//0：不支持
	//1：支持
	IsSptOrient uint8
	//定向状态，是否识别到无人机：
	//1: 侦测
	//2：预留
	//3：预留
	//4：预留
	//5：水平扫描中
	//6：水平瞄准中
	//7：俯仰扫描中
	//8：俯仰瞄准中
	//9：瞄准完成
	//0xa：允许进入定向
	//0xb：频率不在范围不允许进入定向
	//0xFF：无效值（全向时不使用这个字段，上报无效值）
	OrientState uint8
	//保留字段
	Reserve41 uint32
}

// 定向上报扩展 0xE8
type TracerFreqDetectInfoExp struct {
	SN         [25]uint8
	QxPower    uint16 //全向功率
	DxPower    uint16 //定向功率
	DxHorizon  int32  //定向天线水平角(0.01°)
	StartAngle int32  //模式6水平瞄准中的起始方位角
	EndAngle   int32  //模式6水平瞄准中的结束方位角
	DroneNum   uint8
}

type TracerSFreqDetectExp struct {
	Info TracerFreqDetectInfoExp
	Desc []*TracerSFreqDetectExpDesc
}

func (d *TracerSFreqDetectExp) checkDroneMsg(msg []byte) error {
	packageLen := binary.Size(TracerSFreqDetectExpDesc{})
	if len(msg)/packageLen != int(d.Info.DroneNum) || len(msg)%packageLen != 0 {
		return fmt.Errorf("Fpv data len err: {msg len:%v, packageLen:%v, DroneNum:%v}", len(msg), packageLen, d.Info.DroneNum)
	}
	return nil
}
func (d *TracerSFreqDetectExp) DeserializeFreqData(msg []byte) error {
	if err := d.checkDroneMsg(msg); err != nil {
		d.Info.DroneNum = 0
		return nil
	}

	buff := &bytes.Buffer{}
	if err := binary.Write(buff, binary.LittleEndian, msg); err != nil {
		return fmt.Errorf("DeserializeDrone write buff err: %v", err)
	}

	for i := 0; i < int(d.Info.DroneNum); i++ {
		var drone TracerSFreqDetectExpDesc
		if err := binary.Read(buff, binary.LittleEndian, &drone); err != nil {
			return fmt.Errorf("DeserializeDrone read buff err: %v", err)
		}
		d.Desc = append(d.Desc, &drone)
	}
	return nil
}

// 上传频谱（定向）侦测结果
type TracerFreqDetectResult struct {
	Info        TracerFreqDetectInfo
	Description []*TracerFreqDetectDescription
}
type TracerFreqDetectInfo struct {
	SN        [25]uint8
	QxPower   uint16 //全向功率
	DxPower   uint16 //定向功率
	DxHorizon int32  //定向天线水平角(0.01°)
	DroneNum  uint8
}
type TracerFreqDetectDescription struct {
	UavNumber     uint8     //无人机编号
	DroneName     [25]uint8 //无人机品牌+机型
	DroneHorizon  int32     //lsb 目标水平角（0.01°），无效值0x7fffffff
	UFreq         uint32    //频率
	UDangerLevels uint16    //危险等级
	Recerve       int32     //保留
}
type TracerFreqDetectReport struct {
	Sn          string                               `json:"sn"`
	QxPower     float64                              `json:"qx_power"`    //全向功率
	DxPower     float64                              `json:"dx_power"`    //定向功率
	DxHorizon   float64                              `json:"dx_horizon"`  //定向天线水平角(0.01°)
	StartAngle  float64                              `json:"start_angle"` //模式6水平瞄准中的起始方位角(0.01°)
	EndAngle    float64                              `json:"end_angle"`   //模式6水平瞄准中的结束方位角(0.01°)
	Description []*TracerFreqDetectDescriptionReport `json:"info"`
}
type TracerFreqDetectDescriptionReport struct {
	UavNumber     uint32  `json:"uav_number"`      //无人机编号
	DroneName     string  `json:"drone_name"`      //无人机品牌+机型
	DroneHorizon  float64 `json:"drone_horizon"`   //lsb 目标水平角（0.01°），无效值0x7fffffff
	UFreq         float64 `json:"u_freq"`          //频率
	UDangerLevels uint16  `json:"u_danger_levels"` //危险等级
	UMoving       int32   `json:"u_moving"`        //目标状态 0：悬停  1：靠近   2：远离
	Dist          float64 `json:"dist"`            //单位：米
	Recerve       int32   `json:"recerve"`         //保留 （上报模拟图像制式）
	//
	IsSptOrient  uint8  `json:"isSptOrient"`   //是否支持定向：0：不支持；1：支持
	OrientState  uint8  `json:"orientState"`   //定向状态，是否识别到无人机
	ReserveOther uint32 `json:"reserve_other"` //保留字段
}

func (d *TracerFreqDetectResult) DeserializeDrone(msg []byte) error {
	if err := d.checkDroneMsg(msg); err != nil {
		d.Info.DroneNum = 0
		return nil
	}

	//drones := make([]*Drone, 0)
	//packageLen := binary.Size(DroneID{})
	buff := &bytes.Buffer{}
	if err := binary.Write(buff, binary.LittleEndian, msg); err != nil {
		return fmt.Errorf("DeserializeDrone write buff err: %v", err)
	}

	for i := 0; i < int(d.Info.DroneNum); i++ {
		var drone TracerFreqDetectDescription
		if err := binary.Read(buff, binary.LittleEndian, &drone); err != nil {
			return fmt.Errorf("DeserializeDrone read buff err: %v", err)
		}
		d.Description = append(d.Description, &drone)
	}

	return nil
}

func (d *TracerFreqDetectResult) checkDroneMsg(msg []byte) error {
	packageLen := binary.Size(TracerFreqDetectDescription{})
	if len(msg)/packageLen != int(d.Info.DroneNum) || len(msg)%packageLen != 0 {
		return fmt.Errorf("drone data len err: {msg len:%v, packageLen:%v, DroneNum:%v}", len(msg), packageLen, d.Info.DroneNum)
	}
	return nil
}

// 上传频谱（定向）侦测结果  新协议
type TracerNewFreqDetectResult struct {
	Info        TracerNewFreqDetectInfo
	Description []*TracerNewFreqDetectDescription
}
type TracerNewFreqDetectInfo struct {
	SN        [25]uint8
	QxPower   uint16 //全向功率
	DxPower   uint16 //定向功率
	DxHorizon int32  //定向天线水平角(0.01°)
	DroneNum  uint8
}
type TracerNewFreqDetectDescription struct {
	UavNumber     uint8     //无人机编号
	DroneName     [25]uint8 //无人机品牌+机型
	DroneHorizon  int32     //lsb 目标水平角（0.01°），无效值0x7fffffff
	UFreq         uint32    //频率
	UDangerLevels uint16    //危险等级
	UMoving       uint8     //目标状态 0：悬停  1：靠近   2：远离
	Dist          float32
	Recerve       int32 //保留
}

func (d *TracerNewFreqDetectResult) DeserializeDrone(msg []byte) error {
	if err := d.checkDroneMsg(msg); err != nil {
		d.Info.DroneNum = 0
		return nil
	}

	//drones := make([]*Drone, 0)
	//packageLen := binary.Size(DroneID{})
	buff := &bytes.Buffer{}
	if err := binary.Write(buff, binary.LittleEndian, msg); err != nil {
		return fmt.Errorf("Deserialize Drone write buff err: %v", err)
	}

	for i := 0; i < int(d.Info.DroneNum); i++ {
		var drone TracerNewFreqDetectDescription
		if err := binary.Read(buff, binary.LittleEndian, &drone); err != nil {
			return fmt.Errorf("Deserialize Drone read buff err: %v", err)
		}
		d.Description = append(d.Description, &drone)
	}

	return nil
}

func (d *TracerNewFreqDetectResult) checkDroneMsg(msg []byte) error {
	packageLen := binary.Size(TracerNewFreqDetectDescription{})
	if len(msg)/packageLen != int(d.Info.DroneNum) || len(msg)%packageLen != 0 {
		return fmt.Errorf("drone New data len err: {msg len:%v, packageLen:%v, DroneNum:%v}", len(msg), packageLen, d.Info.DroneNum)
	}
	return nil
}

type DroneIDGetChannelRequest struct {
	Sn         [32]uint8
	Company    [32]uint8
	DeviceName [32]uint8
	DeviceType uint16
	Version    [16]byte
}

func (d *DroneIDGetChannelRequest) ID() uint8 {
	return DRONEIDMsgGetChannel
}

func (d *DroneIDGetChannelRequest) Size() uint16 {
	return uint16(binary.Size(d))
}

func (d *DroneIDGetChannelRequest) IsNeedAns() uint8 {
	return 1
}

type DroneIDGetChannelResponse struct {
	Proxy       uint8
	GunIp       [4]uint8
	GunPort     uint16
	NewSourceID uint16
}

func (d *DroneIDGetChannelResponse) ID() uint8 {
	return DRONEIDMsgGetChannel
}

func (d *DroneIDGetChannelResponse) Size() uint16 {
	return uint16(binary.Size(d))
}

func (d *DroneIDGetChannelResponse) IsNeedAns() uint8 {
	return 0
}

func (d *DroneIDGetChannelResponse) CreateGetChannelResponse(ip string, port uint16) []byte {
	if ip == "" {
		return nil
	}
	ipSegArr := strings.Split(ip, ".")
	var uIps [4]uint8
	for i, v := range ipSegArr {
		tmp, _ := strconv.Atoi(v)
		uIps[i] = uint8(tmp)
	}
	d.GunIp = uIps
	d.GunPort = port
	d.Proxy = 1
	d.NewSourceID = uint16(common.DEV_V2DRONEID)
	p, err := NewPacket(uint8(common.DEV_V2DRONEID), uint8(common.DEV_C2_WIFI), d)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type DroneIDGetVersionInfoRequest struct {
}

func (g *DroneIDGetVersionInfoRequest) ID() uint8 {
	return DroneIDGetVersionInfo
}

func (g *DroneIDGetVersionInfoRequest) Size() uint16 {
	return 0
}

func (g *DroneIDGetVersionInfoRequest) IsNeedAns() uint8 {
	return 1
}

func (g *DroneIDGetVersionInfoRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_V2DRONEID), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type DroneIDGetVersionInfoResponse struct {
	CompanyName [16]byte
	DeviceName  [16]byte
	PsVersion   [32]byte
	PlVersion   [32]byte
	DeviceSn    [32]byte
	DeviceIP    [16]byte
}

func (g *DroneIDGetVersionInfoResponse) ID() uint8 {
	return DroneIDGetVersionInfo
}

func (g *DroneIDGetVersionInfoResponse) Size() uint16 {
	return uint16(binary.Size(g))
}

func (g *DroneIDGetVersionInfoResponse) IsNeedAns() uint8 {
	return 0
}

type TracerGetDevTypeInfoRequest struct {
}

func (g *TracerGetDevTypeInfoRequest) ID() uint8 {
	return TracerGetDevTypeInfo
}

func (g *TracerGetDevTypeInfoRequest) Size() uint16 {
	return 0
}

func (g *TracerGetDevTypeInfoRequest) IsNeedAns() uint8 {
	return 1
}

func (g *TracerGetDevTypeInfoRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_V2DRONEID), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type TracerGetDevTypeInfoResponse struct {
	DevType uint16
	Reserve uint16
}

func (g *TracerGetDevTypeInfoResponse) ID() uint8 {
	return DroneIDGetVersionInfo
}

func (g *TracerGetDevTypeInfoResponse) Size() uint16 {
	return uint16(binary.Size(g))
}

func (g *TracerGetDevTypeInfoResponse) IsNeedAns() uint8 {
	return 0
}

type DroneIDHeartbeatExtRequest struct {
	Sum uint8
}

func (d *DroneIDHeartbeatExtRequest) ID() uint8 {
	return C2MsgHeartbeat
}

func (d *DroneIDHeartbeatExtRequest) Size() uint16 {
	return 1
}

func (d *DroneIDHeartbeatExtRequest) IsNeedAns() uint8 {
	return 0
}

func (d *DroneIDHeartbeatExtRequest) CreateScreenHeartbeatExt() []byte {
	p, err := NewPacket(uint8(common.DEV_V2DRONEID), uint8(common.DEV_C2_WIFI), d)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

// TracerGetVersionRequest Tracer获取版本信息请求
type TracerGetVersionRequest struct {
}

func (g *TracerGetVersionRequest) ID() uint8 {
	return TracerIdGetVersionInfo
}

func (g *TracerGetVersionRequest) Size() uint16 {
	return 0
}

func (g *TracerGetVersionRequest) IsNeedAns() uint8 {
	return 1
}

func (g *TracerGetVersionRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_V2DRONEID), uint8(common.DEV_SCREEN), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type TracerGetVersionResponse struct {
	RunVersion      uint32   //当前运行版 0-boot1-app
	AppVersion      [64]byte //软件版本号
	BootVersion     [32]byte //Bootloader
	HwVersion       [32]byte //硬件版本号
	ProtocolVersion [32]byte //协议版本号
}

func (g *TracerGetVersionResponse) ID() uint8 {
	return TracerIdGetVersionInfo
}

func (g *TracerGetVersionResponse) Size() uint16 {
	return 164
}

func (g *TracerGetVersionResponse) IsNeedAns() uint8 {
	return 0
}

// TracerResetSystemRequest Tracer复位请求
type TracerResetSystemRequest struct {
	ResetCode uint16 `json:"reset_code"`
	Type      uint16 `json:"type"`
}

func (g *TracerResetSystemRequest) ID() uint8 {
	return TracerIdResetSystem
}

func (g *TracerResetSystemRequest) Size() uint16 {
	return 4
}

func (g *TracerResetSystemRequest) IsNeedAns() uint8 {
	return 0
}

func (g *TracerResetSystemRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_V2DRONEID), uint8(common.DEV_SCREEN), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

// TracerRequestUpgradeRequest 请求固件升级
type TracerRequestUpgradeRequest struct {
	Data [256]uint8 `json:"data"`
}

func (g *TracerRequestUpgradeRequest) ID() uint8 {
	return TracerIdRequestUpgrade
}

func (g *TracerRequestUpgradeRequest) Size() uint16 {
	return 256
}

func (g *TracerRequestUpgradeRequest) IsNeedAns() uint8 {
	return 1
}

func (g *TracerRequestUpgradeRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_V2DRONEID), uint8(common.DEV_SCREEN), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type TracerRequestUpgradeResponse struct {
	Status uint8 `json:"status"`
}

func (g *TracerRequestUpgradeResponse) ID() uint8 {
	return TracerIdRequestUpgrade
}

func (g *TracerRequestUpgradeResponse) Size() uint16 {
	return 8
}

func (g *TracerRequestUpgradeResponse) IsNeedAns() uint8 {
	return 0
}

// TracerSendUpdatePkgRequest 发送升级固件数据
type TracerSendUpdatePkgRequest struct {
	ImageOffset uint32  `json:"image_offset"` // 数据偏移位置
	ImageLength uint32  `json:"image_length"` // 数据长度
	ImageData   []uint8 `json:"image_data"`   // 升级数据流，最大4096字节
}

func (g *TracerSendUpdatePkgRequest) ID() uint8 {
	return TracerIdSendUpdatePkg
}

func (g *TracerSendUpdatePkgRequest) Size() uint16 {
	return uint16(g.Len())
}

func (g *TracerSendUpdatePkgRequest) IsNeedAns() uint8 {
	return 1
}

func (g *TracerSendUpdatePkgRequest) Len() int {
	return 8 + len(g.ImageData)
}

// Create 元素长度不固定使用protocols下的message进行编码
func (g *TracerSendUpdatePkgRequest) Create() ([]byte, error) {

	size := g.Size()
	rowLength := uint8(size & 0x00FF)
	highLength := uint8((size & 0xFF00) >> 8)
	header := MavHeader{
		FrameStart:        FrameStart,
		PayloadLowLength:  rowLength,
		PayloadHighLength: highLength,
		PacketSequence:    PackageSeq,
		ReceiveID:         uint8(common.DEV_V2DRONEID),
		SendID:            uint8(common.DEV_SCREEN),
		MessageID:         g.ID(),
		Ans:               g.IsNeedAns(),
	}
	header.Checksum = g.computeChecksum(header)
	genBuff := g.structToSlice(header)

	return genBuff, nil
}

func (g *TracerSendUpdatePkgRequest) bytes(header MavHeader) []byte {
	var r bytes.Buffer
	var err error
	if err = binary.Write(&r, binary.LittleEndian, header); err != nil {
		return []byte{}
	}
	if err = binary.Write(&r, binary.LittleEndian, g.ImageOffset); err != nil {
		return []byte{}
	}
	if err = binary.Write(&r, binary.LittleEndian, g.ImageLength); err != nil {
		return []byte{}
	}
	if err = binary.Write(&r, binary.LittleEndian, g.ImageData); err != nil {
		return []byte{}
	}
	return r.Bytes()
}

func (g *TracerSendUpdatePkgRequest) computeChecksum(header MavHeader) uint8 {
	var sum uint32
	buff := g.bytes(header)
	if buff == nil || len(buff) < CheckSumLen {
		return 0
	}
	sumData := buff[:CheckSumLen]
	for _, v := range sumData {
		sum += uint32(v)
	}
	return uint8(sum & 0xFF)
}

func (g *TracerSendUpdatePkgRequest) structToSlice(header MavHeader) []byte {
	dataBuff := g.bytes(header)
	if len(dataBuff) <= 0 {
		return dataBuff
	}
	crc16 := CRC(dataBuff[CrcStartLoc:])
	crcArr := make([]byte, CrcLen)
	binary.BigEndian.PutUint16(crcArr, crc16)
	genBuff := make([]byte, 0)
	genBuff = append(genBuff, dataBuff...)
	genBuff = append(genBuff, crcArr[1])
	genBuff = append(genBuff, crcArr[0])
	return genBuff
}

type TracerSendUpdatePkgResponse struct {
	Status uint8  `json:"status"`
	Rsv1   uint8  `json:"rsv1"`
	Rsv2   uint8  `json:"rsv2"`
	Rsv3   uint8  `json:"rsv3"`
	Offset uint32 `json:"offset"`
}

func (g *TracerSendUpdatePkgResponse) ID() uint8 {
	return TracerIdSendUpdatePkg
}

func (g *TracerSendUpdatePkgResponse) Size() uint16 {
	return 5
}

func (g *TracerSendUpdatePkgResponse) IsNeedAns() uint8 {
	return 0
}

// TracerVerifyImageRequest 请求校验固件
type TracerVerifyImageRequest struct {
}

func (g *TracerVerifyImageRequest) ID() uint8 {
	return TracerIdVerifyImage
}

func (g *TracerVerifyImageRequest) Size() uint16 {
	return 0
}

func (g *TracerVerifyImageRequest) IsNeedAns() uint8 {
	return 1
}

func (g *TracerVerifyImageRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_V2DRONEID), uint8(common.DEV_SCREEN), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type TracerVerifyImageResponse struct {
	Status uint8 `json:"status"`
}

func (g *TracerVerifyImageResponse) ID() uint8 {
	return TracerIdVerifyImage
}

func (g *TracerVerifyImageResponse) Size() uint16 {
	return 1
}

func (g *TracerVerifyImageResponse) IsNeedAns() uint8 {
	return 0
}

// RadarGetUpdateTimeoutRetryTimeRequest 获取固件升级超时重试时间
type TracerGetUpdateTimeoutRetryTimeRequest struct {
}

func (g *TracerGetUpdateTimeoutRetryTimeRequest) ID() uint8 {
	return 0xAE
}

func (g *TracerGetUpdateTimeoutRetryTimeRequest) Size() uint16 {
	return 0
}

func (g *TracerGetUpdateTimeoutRetryTimeRequest) IsNeedAns() uint8 {
	return 1
}

func (g *TracerGetUpdateTimeoutRetryTimeRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_V2DRONEID), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type TracerGetUpdateTimeoutRetryTimeResponse struct {
	ImagePkgLenMax uint16 `json:"image_pkg_len_max"`
	CmdTimeoutMs   uint16 `json:"cmd_timeout_ms"`
	CheckTimeoutS  uint16 `json:"check_timeout_s"`
	WriteTimeoutS  uint16 `json:"write_timeout_s"`
}

func (g *TracerGetUpdateTimeoutRetryTimeResponse) ID() uint8 {
	return 0xAE
}

func (g *TracerGetUpdateTimeoutRetryTimeResponse) Size() uint16 {
	return 8
}

func (g *TracerGetUpdateTimeoutRetryTimeResponse) IsNeedAns() uint8 {
	return 0
}

// TracerUpdateF1Request 写入固件数据
type TracerUpdateF1Request struct {
	Url           [256]byte //镜像文件的URL
	Authorization uint8     //0-无需验证，1-需要验证用户名密码
	UserName      [32]byte  //用户名
	Password      [32]byte  //密码
	Reserve       [4]byte
}

func (g *TracerUpdateF1Request) ID() uint8 {
	return TracerIdUpgradeF1
}

func (g *TracerUpdateF1Request) Size() uint16 {
	return 325
}

func (g *TracerUpdateF1Request) IsNeedAns() uint8 {
	return 1
}

func (g *TracerUpdateF1Request) Create(fileName string, c2Ip string) []byte {
	url := " http://" + c2Ip + ":8081" + "/" + fileName
	logger.Info("send url is:", url)
	var tmp [256]byte
	for i, v := range []byte(url) {
		tmp[i] = v
	}
	g.Url = tmp
	g.Authorization = 0
	p, err := NewPacket(uint8(common.DEV_V2DRONEID), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type TracerUpdateF1Response struct {
	Status uint8 `json:"status"` //0:成功    1：请求失败    10：状态错误    其他错误
}

func (g *TracerUpdateF1Response) ID() uint8 {
	return TracerIdUpgradeF1
}

func (g *TracerUpdateF1Response) Size() uint16 {
	return 1
}

func (g *TracerUpdateF1Response) IsNeedAns() uint8 {
	return 0
}

// TracerUpdateF2Request 写入固件数据
type TracerUpdateF2Request struct {
}

func (g *TracerUpdateF2Request) ID() uint8 {
	return TracerIdUpgradeF2
}

func (g *TracerUpdateF2Request) Size() uint16 {
	return 0
}

func (g *TracerUpdateF2Request) IsNeedAns() uint8 {
	return 1
}

func (g *TracerUpdateF2Request) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_V2DRONEID), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type TracerUpdateF2Response struct {
	Progress uint8 `json:"Progress"` //下载进度百分比 0~100
}

func (g *TracerUpdateF2Response) ID() uint8 {
	return TracerIdUpgradeF2
}

func (g *TracerUpdateF2Response) Size() uint16 {
	return 1
}

func (g *TracerUpdateF2Response) IsNeedAns() uint8 {
	return 0
}

type TracerUpdateF3Response struct {
	UpgradeResult uint8 `json:"upgrade_result"` //0-成功 1-下载镜像失败 2-无效的镜像文件 3-Emmc不可写 4-其他原因
}

func (g *TracerUpdateF3Response) ID() uint8 {
	return TracerIdUpgradeF3
}

func (g *TracerUpdateF3Response) Size() uint16 {
	return 1
}

func (g *TracerUpdateF3Response) IsNeedAns() uint8 {
	return 0
}

// TracerWriteUpdateDataRequest 写入固件数据
type TracerWriteUpdateDataRequest struct {
}

func (g *TracerWriteUpdateDataRequest) ID() uint8 {
	return TracerIdWriteUpdateData
}

func (g *TracerWriteUpdateDataRequest) Size() uint16 {
	return 0
}

func (g *TracerWriteUpdateDataRequest) IsNeedAns() uint8 {
	return 1
}

func (g *TracerWriteUpdateDataRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_V2DRONEID), uint8(common.DEV_SCREEN), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type TracerWriteUpdateDataResponse struct {
	Status uint8 `json:"status"`
}

func (g *TracerWriteUpdateDataResponse) ID() uint8 {
	return TracerIdWriteUpdateData
}

func (g *TracerWriteUpdateDataResponse) Size() uint16 {
	return 1
}

func (g *TracerWriteUpdateDataResponse) IsNeedAns() uint8 {
	return 0
}

// TracerGetUpdateWriteStatusRequest 获取固件更新写入状态请求
type TracerGetUpdateWriteStatusRequest struct {
}

func (g *TracerGetUpdateWriteStatusRequest) ID() uint8 {
	return TracerIdGetUpdateWriteStatus
}

func (g *TracerGetUpdateWriteStatusRequest) Size() uint16 {
	return 0
}

func (g *TracerGetUpdateWriteStatusRequest) IsNeedAns() uint8 {
	return 1
}

func (g *TracerGetUpdateWriteStatusRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_V2DRONEID), uint8(common.DEV_SCREEN), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type TracerGetUpdateWriteStatusResponse struct {
	Status uint8  `json:"status"`
	Permil uint16 `json:"permil"`
}

func (g *TracerGetUpdateWriteStatusResponse) ID() uint8 {
	return TracerIdGetUpdateWriteStatus
}

func (g *TracerGetUpdateWriteStatusResponse) Size() uint16 {
	return 3
}

func (g *TracerGetUpdateWriteStatusResponse) IsNeedAns() uint8 {
	return 0
}

// TracerRunAppRequest 请求运行固件App
type TracerRunAppRequest struct {
}

func (g *TracerRunAppRequest) ID() uint8 {
	return TracerIdRunApp
}

func (g *TracerRunAppRequest) Size() uint16 {
	return 0
}

func (g *TracerRunAppRequest) IsNeedAns() uint8 {
	return 1
}

func (g *TracerRunAppRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_V2DRONEID), uint8(common.DEV_SCREEN), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type TracerRunAppResponse struct {
	Status uint8 `json:"status"`
}

func (g *TracerRunAppResponse) ID() uint8 {
	return TracerIdRunApp
}

func (g *TracerRunAppResponse) Size() uint16 {
	return 1
}

func (g *TracerRunAppResponse) IsNeedAns() uint8 {
	return 0
}

// TracerGetWorkModeRequest 获取工作模式
type TracerGetWorkModeRequest struct {
}

func (g *TracerGetWorkModeRequest) ID() uint8 {
	return TracerGetWorkMode
}

func (g *TracerGetWorkModeRequest) Size() uint16 {
	return 0
}

func (g *TracerGetWorkModeRequest) IsNeedAns() uint8 {
	return 1
}

func (g *TracerGetWorkModeRequest) Create() []byte {
	p, err := NewPacket(uint8(common.DEV_V2DRONEID), uint8(common.DEV_SCREEN), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

// TracerGetWorkModeResponse 获取工作模式响应
type TracerGetWorkModeResponse struct {
	Status uint8 `json:"status"`
}

func (g *TracerGetWorkModeResponse) ID() uint8 {
	return TracerGetWorkMode
}

func (g *TracerGetWorkModeResponse) Size() uint16 {
	return 1
}

func (g *TracerGetWorkModeResponse) IsNeedAns() uint8 {
	return 0
}

// TracerSetOrientationModeRequest 设置定向模式
type TracerSetOrientationModeRequest struct {
	Status    uint8    //0 退出    1进入
	UavNumber uint8    //无人机编号
	DroneName [25]byte //无人机名称
	UFreq     uint32   //LSB 无人机信号频率（mHZ)
}

func (g *TracerSetOrientationModeRequest) ID() uint8 {
	return TracerSetOrientationMode
}

func (g *TracerSetOrientationModeRequest) Size() uint16 {
	return 31
}

func (g *TracerSetOrientationModeRequest) IsNeedAns() uint8 {
	return 1
}

func (g *TracerSetOrientationModeRequest) Create(status uint8, uavNumber uint8, uamName string, uFreq uint32) []byte {
	g.Status = status
	g.UavNumber = uavNumber
	g.UFreq = uFreq
	var tmp [25]byte
	for i, v := range []byte(uamName) {
		tmp[i] = v
	}
	g.DroneName = tmp

	p, err := NewPacket(uint8(common.DEV_V2DRONEID), uint8(common.DEV_SCREEN), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

// TracerSetOrientationModeResponse 设置定向模式响应
type TracerSetOrientationModeResponse struct {
	Status uint8 `json:"status"`
}

func (g *TracerSetOrientationModeResponse) ID() uint8 {
	return TracerSetOrientationMode
}

func (g *TracerSetOrientationModeResponse) Size() uint16 {
	return 1
}

func (g *TracerSetOrientationModeResponse) IsNeedAns() uint8 {
	return 0
}

// TracerCliRequest 下发Tracer指令
type TracerCliRequest struct {
	Handle uint32
	Cmd    []uint8
}

func (g *TracerCliRequest) ID() uint8 {
	return TracerCliSend
}

func (g *TracerCliRequest) Size() uint16 {
	return uint16(g.Len())
}

func (g *TracerCliRequest) IsNeedAns() uint8 {
	return 1
}
func (g *TracerCliRequest) Len() int {
	return 4 + len(g.Cmd)
}

func (g *TracerCliRequest) Create() []byte {

	size := g.Size()
	rowLength := uint8(size & 0x00FF)
	highLength := uint8((size & 0xFF00) >> 8)
	var header MavHeader
	header = MavHeader{
		FrameStart:        FrameStart,
		PayloadLowLength:  rowLength,
		PayloadHighLength: highLength,
		PacketSequence:    PackageSeq,
		ReceiveID:         uint8(common.DEV_V2DRONEID),
		SendID:            uint8(common.DEV_SCREEN),
		MessageID:         g.ID(),
		Ans:               g.IsNeedAns(),
	}
	header.Checksum = g.computeChecksum(header)
	genBuff := g.structToSlice(header)

	return genBuff
}
func (g *TracerCliRequest) bytes(header MavHeader) []byte {
	var r bytes.Buffer
	var err error
	if err = binary.Write(&r, binary.LittleEndian, header); err != nil {
		return []byte{}
	}
	if err = binary.Write(&r, binary.LittleEndian, g.Handle); err != nil {
		return []byte{}
	}
	if err = binary.Write(&r, binary.LittleEndian, g.Cmd); err != nil {
		return []byte{}
	}

	return r.Bytes()
}

func (g *TracerCliRequest) computeChecksum(header MavHeader) uint8 {
	var sum uint32
	buff := g.bytes(header)
	if buff == nil || len(buff) < CheckSumLen {
		return 0
	}
	sumData := buff[:CheckSumLen]
	for _, v := range sumData {
		sum += uint32(v)
	}
	return uint8(sum & 0xFF)
}

func (g *TracerCliRequest) structToSlice(header MavHeader) []byte {
	dataBuff := g.bytes(header)
	if len(dataBuff) <= 0 {
		return dataBuff
	}
	crc16 := CRC(dataBuff[CrcStartLoc:])
	crcArr := make([]byte, CrcLen)
	binary.BigEndian.PutUint16(crcArr, crc16)
	genBuff := make([]byte, 0)
	genBuff = append(genBuff, dataBuff...)
	genBuff = append(genBuff, crcArr[1])
	genBuff = append(genBuff, crcArr[0])
	return genBuff
}

// TracerCliResponse tracer指令响应
type TracerCliResponse struct {
	Handle          uint32
	CmdParseRetcode uint32
	CmdExecRetcode  uint32
	CmdResult       []byte
}

func (g *TracerCliResponse) ID() uint8 {
	return TracerCliSend
}

func (g *TracerCliResponse) Size() uint16 {
	return uint16(12 + len(g.CmdResult))
}

func (g *TracerCliResponse) IsNeedAns() uint8 {
	return 0
}

type DroneIdGetLogRequestAll struct {
}

// 向雷达  获取日志文件
type DroneIdGetLogRequest struct {
	LogNum      uint32
	LogFileInfo [1]DroneIdLogFileInfo
}
type DroneIdLogFileInfo struct {
	LogId      uint32
	LogNameLen uint32
	LogName    []byte
}

func (p *DroneIdGetLogRequestAll) ID() uint8 {
	return 0x29
}

func (p *DroneIdGetLogRequestAll) Size() uint16 {
	return 4
}

func (p *DroneIdGetLogRequestAll) IsNeedAns() uint8 {
	return 1
}

func (p *DroneIdGetLogRequestAll) CreateDroneIdGetLog(logInfo []*DroneIdGetLogRequest) []byte {
	size := uint16(4 + len(logInfo)*(8+len(logInfo[0].LogFileInfo[0].LogName)))
	logger.Info("size is : ", size)
	rowLength := uint8(size & 0x00FF)
	highLength := uint8((size & 0xFF00) >> 8)
	mavPackage1 := &MavPacket{
		Header: MavHeader{
			FrameStart:        FrameStart,
			PayloadLowLength:  rowLength,
			PayloadHighLength: highLength,
			PacketSequence:    PackageSeq,
			ReceiveID:         uint8(common.DEV_V2DRONEID),
			SendID:            uint8(common.DEV_C2_WIFI),
			MessageID:         p.ID(),
			Ans:               p.IsNeedAns(),
		},
		Msg: p,
	}
	var r1 bytes.Buffer
	if err := binary.Write(&r1, binary.LittleEndian, mavPackage1.Header); err != nil {
		logger.Error("Header binary Write err : ", err)
		return []byte{}
	}
	mavPackage1.RadarGetLogChecksum(r1)
	mavPackage := &MavPacket{
		Header: MavHeader{
			FrameStart:        FrameStart,
			PayloadLowLength:  rowLength,
			PayloadHighLength: highLength,
			PacketSequence:    PackageSeq,
			ReceiveID:         uint8(common.DEV_V2DRONEID),
			SendID:            uint8(common.DEV_C2_WIFI),
			MessageID:         p.ID(),
			Ans:               p.IsNeedAns(),
			Checksum:          mavPackage1.RadarGetLogChecksum(r1),
		},
		Msg: p,
	}
	var r bytes.Buffer
	if err := binary.Write(&r, binary.LittleEndian, mavPackage.Header); err != nil {
		logger.Error("Header binary Write err : ", err)
		return []byte{}
	}

	if err := binary.Write(&r, binary.LittleEndian, p); err != nil {
		logger.Error("p binary Write err : ", err)
		return []byte{}
	}
	for _, v := range logInfo {
		if err := binary.Write(&r, binary.LittleEndian, v.LogNum); err != nil {
			logger.Error("range binary Write err : ", err)
			return []byte{}
		}
		for _, v2 := range v.LogFileInfo {
			if err := binary.Write(&r, binary.LittleEndian, v2.LogId); err != nil {
				logger.Error("LogId binary Write err : ", err)
				return []byte{}
			}
			if err := binary.Write(&r, binary.LittleEndian, v2.LogNameLen); err != nil {
				logger.Error("LogNameLen binary Write err : ", err)
				return []byte{}
			}
			if err := binary.Write(&r, binary.LittleEndian, v2.LogName); err != nil {
				logger.Error("LogName binary Write err : ", err)
				return []byte{}
			}
		}

	}

	dataBuff := r.Bytes()
	crc16 := CRC(dataBuff[CrcStartLoc:])
	crcArr := make([]byte, CrcLen)
	binary.BigEndian.PutUint16(crcArr, crc16)
	genBuff := make([]byte, 0)
	genBuff = append(genBuff, dataBuff...)
	genBuff = append(genBuff, crcArr[1])
	genBuff = append(genBuff, crcArr[0])
	logger.Info("send msg is:%v", genBuff)
	logger.Info("send msg is:%v", string(genBuff))
	return genBuff

}

var DroneIdLogMsgAll DroneIdGetLogMsgResponse

type DroneIdGetLogMsgResponse struct {
	//LogMsgAll GunGetLogResponse
	LogMsgAll []string
	DataLock  sync.Mutex
}

func (this *DroneIdGetLogMsgResponse) SetData(data string) {
	this.DataLock.Lock()
	defer this.DataLock.Unlock()
	logger.Debug("LogMsg load data:%v", data)
	this.LogMsgAll = append(this.LogMsgAll, data)
}
func (this *DroneIdGetLogMsgResponse) GetData() []string {
	this.DataLock.Lock()
	defer this.DataLock.Unlock()
	logger.Info("Get LogMsg data")
	return this.LogMsgAll
}
func (this *DroneIdGetLogMsgResponse) DeleteData() {
	this.DataLock.Lock()
	defer this.DataLock.Unlock()
	logger.Info("Del LogMsg data")
	this.LogMsgAll = this.LogMsgAll[:0]
}

var DroneIdResAll DroneIdGetLogListResponseAll

type DroneIdGetLogListResponseAll struct {
	LogListAll []DroneIdGetLogListResponse
	DataLock   sync.Mutex
}

func (this *DroneIdGetLogListResponseAll) SetData(data interface{}) {
	this.DataLock.Lock()
	defer this.DataLock.Unlock()
	logger.Debug("LogList load data:%v", data)
	data1 := data.(*DroneIdGetLogListResponse)
	this.LogListAll = append(this.LogListAll, *data1)
}
func (this *DroneIdGetLogListResponseAll) GetData() []DroneIdGetLogListResponse {
	this.DataLock.Lock()
	defer this.DataLock.Unlock()
	logger.Info("Get LogList data")
	return this.LogListAll
}
func (this *DroneIdGetLogListResponseAll) DeleteData() {
	this.DataLock.Lock()
	defer this.DataLock.Unlock()
	logger.Info("Del LogList data")
	this.LogListAll = this.LogListAll[:0]
}

// 获取日志列表响应
type DroneIdGetLogListResponse struct {
	PkgTotalNum    uint32
	PkgCurNum      uint32
	DroneIdLogInfo []DroneIdLogInfo
}

type DroneIdLogInfo struct {
	LogNameLen uint32
	LogDataLen uint32
	LogName    []byte
}

func (p *DroneIdGetLogListResponse) Len() int {
	//TODO implement me
	templen := 0
	for _, v := range p.DroneIdLogInfo {
		templen = templen + 8 + len(v.LogName)
	}
	return 8 + +templen
}
func (p *DroneIdGetLogListResponse) ID() uint8 {
	return 0x28
}

//func (p *GunGetLogListResponse) Size() uint8 {
//	var size int
//	for _, v := range p.LogInfo {
//		size += len(v.LogName) + 8
//	}
//	return uint8(size + 16)
//}

func (p *DroneIdGetLogListResponse) IsNeedAns() uint8 {
	return 0
}

// 向雷达  获取日志列表
type DroneIdGetLogListRequest struct {
}

func (p *DroneIdGetLogListRequest) ID() uint8 {
	return 0x28
}

func (p *DroneIdGetLogListRequest) Size() uint16 {
	return 0
}

func (p *DroneIdGetLogListRequest) IsNeedAns() uint8 {
	return 1
}

func (p *DroneIdGetLogListRequest) CreateDroneIdGetLogList() []byte {
	pac, err := NewPacket(uint8(common.DEV_V2DRONEID), uint8(common.DEV_C2_WIFI), p)
	if err != nil {
		return nil
	}
	genBuff := pac.StructToSlice()
	return genBuff
}

// 删除日志文件响应
type DroneIdDelLogResponse struct {
	Status bool
}

func (r DroneIdDelLogResponse) ID() uint8 {
	return 0x2A
}

func (r DroneIdDelLogResponse) Size() uint16 {
	return 1
}

func (r DroneIdDelLogResponse) IsNeedAns() uint8 {
	return 0
}

// 向雷达  获取日志文件
type DroneIdDelLogRequestAll struct {
}
type DroneIdDelLogRequest struct {
	FolderNameLen uint32
	FolderName    []byte
}

func (p *DroneIdDelLogRequestAll) ID() uint8 {
	return 0x2A
}

func (p *DroneIdDelLogRequestAll) Size() uint16 {
	return 4
}

func (p *DroneIdDelLogRequestAll) IsNeedAns() uint8 {
	return 1
}

func (p *DroneIdDelLogRequestAll) CreateDroneIdDelLog(logDir string) []byte {
	logNameLen := len(logDir)

	size := uint16(4 + logNameLen)
	logger.Info("size is : ", size)
	rowLength := uint8(size & 0x00FF)
	highLength := uint8((size & 0xFF00) >> 8)
	mavPackage1 := &MavPacket{
		Header: MavHeader{
			FrameStart:        FrameStart,
			PayloadLowLength:  rowLength,
			PayloadHighLength: highLength,
			PacketSequence:    PackageSeq,
			ReceiveID:         uint8(common.DEV_V2DRONEID),
			SendID:            uint8(common.DEV_C2_WIFI),
			MessageID:         p.ID(),
			Ans:               p.IsNeedAns(),
		},
		Msg: p,
	}
	var r1 bytes.Buffer
	if err := binary.Write(&r1, binary.LittleEndian, mavPackage1.Header); err != nil {
		logger.Error("Header binary Write err:", err)
		return []byte{}
	}
	mavPackage1.RadarGetLogChecksum(r1)
	mavPackage := &MavPacket{
		Header: MavHeader{
			FrameStart:        FrameStart,
			PayloadLowLength:  rowLength,
			PayloadHighLength: highLength,
			PacketSequence:    PackageSeq,
			ReceiveID:         uint8(common.DEV_V2DRONEID),
			SendID:            uint8(common.DEV_C2_WIFI),
			MessageID:         p.ID(),
			Ans:               p.IsNeedAns(),
			Checksum:          mavPackage1.RadarGetLogChecksum(r1),
		},
		Msg: p,
	}
	var r bytes.Buffer
	if err := binary.Write(&r, binary.LittleEndian, mavPackage.Header); err != nil {
		logger.Error("Header binary Write err:", err)
		return []byte{}
	}

	if err := binary.Write(&r, binary.LittleEndian, p); err != nil {
		logger.Error("p binary Write err:", err)
		return []byte{}
	}
	if err := binary.Write(&r, binary.LittleEndian, uint32(logNameLen)); err != nil {
		logger.Error("logNameLen binary Write err:", err)
		return []byte{}
	}
	if err := binary.Write(&r, binary.LittleEndian, []byte(logDir)); err != nil {
		logger.Error("logDir binary Write err:", err)
		return []byte{}
	}
	dataBuff := r.Bytes()
	crc16 := CRC(dataBuff[CrcStartLoc:])
	crcArr := make([]byte, CrcLen)
	binary.BigEndian.PutUint16(crcArr, crc16)
	genBuff := make([]byte, 0)
	genBuff = append(genBuff, dataBuff...)
	genBuff = append(genBuff, crcArr[1])
	genBuff = append(genBuff, crcArr[0])
	logger.Info("send msg is:%v", genBuff)
	logger.Info("send msg is:%v", string(genBuff))
	return genBuff
}

type DroneIdGetTimeResponse struct {
	Time [20]byte `json:"time"`
}

func (g *DroneIdGetTimeResponse) ID() uint8 {
	return 0xE3
}

func (g *DroneIdGetTimeResponse) Size() uint16 {
	return 20
}

func (g *DroneIdGetTimeResponse) IsNeedAns() uint8 {
	return 1
}

func (g *DroneIdGetTimeResponse) CreateGetTimeMessage(time [20]byte) []byte {
	g.Time = time
	p, err := NewPacket(uint8(common.DEV_V2DRONEID), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

type TracerSetWhiteRequestAll struct {
}

// TracerSetWhiteRequest 设置告警白名单
type TracerSetWhiteRequest struct {
	WhiteNum  uint16
	WhiteList []TracerWhiteInfo
}
type TracerWhiteInfo struct {
	Serial [32]byte
}

func (g *TracerSetWhiteRequestAll) ID() uint8 {
	return TracerSetWhiteList
}

func (g *TracerSetWhiteRequestAll) Size() uint16 {
	return 0
}

func (g *TracerSetWhiteRequestAll) IsNeedAns() uint8 {
	return 1
}

func (g *TracerSetWhiteRequestAll) Create(info *TracerSetWhiteRequest) []byte {
	size := 2 + 32*info.WhiteNum
	logger.Info("Tracer SetWhite size is : ", size)
	rowLength := uint8(size & 0x00FF)
	highLength := uint8((size & 0xFF00) >> 8)
	mavPackage1 := &MavPacket{
		Header: MavHeader{
			FrameStart:        FrameStart,
			PayloadLowLength:  rowLength,
			PayloadHighLength: highLength,
			PacketSequence:    PackageSeq,
			ReceiveID:         uint8(common.DEV_V2DRONEID),
			SendID:            uint8(common.DEV_C2_WIFI),
			MessageID:         g.ID(),
			Ans:               g.IsNeedAns(),
		},
		Msg: g,
	}
	var r1 bytes.Buffer
	if err := binary.Write(&r1, binary.LittleEndian, mavPackage1.Header); err != nil {
		logger.Error("Header binary Write err : ", err)
		return []byte{}
	}
	mavPackage1.TracerGetLogChecksum(r1)
	mavPackage := &MavPacket{
		Header: MavHeader{
			FrameStart:        FrameStart,
			PayloadLowLength:  rowLength,
			PayloadHighLength: highLength,
			PacketSequence:    PackageSeq,
			ReceiveID:         uint8(common.DEV_V2DRONEID),
			SendID:            uint8(common.DEV_C2_WIFI),
			MessageID:         g.ID(),
			Ans:               g.IsNeedAns(),
			Checksum:          mavPackage1.TracerGetLogChecksum(r1),
		},
		Msg: g,
	}
	var r bytes.Buffer
	if err := binary.Write(&r, binary.LittleEndian, mavPackage.Header); err != nil {
		logger.Error("Header binary Write err : ", err)
		return []byte{}
	}
	if err := binary.Write(&r, binary.LittleEndian, g); err != nil {
		logger.Error("g binary Write err : ", err)
		return []byte{}
	}
	if err := binary.Write(&r, binary.LittleEndian, info.WhiteNum); err != nil {
		logger.Error("g binary Write err : ", err)
		return []byte{}
	}
	for _, v := range info.WhiteList {
		if err := binary.Write(&r, binary.LittleEndian, v.Serial); err != nil {
			logger.Error("DroneHorizon binary Write err : ", err)
			return []byte{}
		}

	}

	dataBuff := r.Bytes()
	crc16 := CRC(dataBuff[CrcStartLoc:])
	crcArr := make([]byte, CrcLen)
	binary.BigEndian.PutUint16(crcArr, crc16)
	genBuff := make([]byte, 0)
	genBuff = append(genBuff, dataBuff...)
	genBuff = append(genBuff, crcArr[1])
	genBuff = append(genBuff, crcArr[0])
	logger.Info("Tracer SetWhite send msg is:%v", genBuff)
	logger.Info("Tracer SetWhite send msg is:%v", string(genBuff))
	return genBuff
}
func (m *MavPacket) TracerGetLogChecksum(r bytes.Buffer) uint8 {
	var sum uint32
	buff := r.Bytes()
	if buff == nil || len(buff) < CheckSumLen {
		return 0
	}
	sumData := buff[:CheckSumLen]

	for _, v := range sumData {
		sum += uint32(v)
	}
	m.Header.Checksum = uint8(sum & 0xFF)
	return m.Header.Checksum
}

// TracerSetWhiteResponse 设置告警白名单  返回
type TracerSetWhiteResponse struct {
	Status uint8 `json:"status"`
}

func (g *TracerSetWhiteResponse) ID() uint8 {
	return TracerSetWhiteList
}

func (g *TracerSetWhiteResponse) Size() uint16 {
	return 1
}

func (g *TracerSetWhiteResponse) IsNeedAns() uint8 {
	return 0
}

// TracerSetAlarmRequest 设置告警等级
type TracerSetAlarmRequest struct {
	WarnLevel uint8
}

func (g *TracerSetAlarmRequest) ID() uint8 {
	return TracerSetAlarmLevel
}

func (g *TracerSetAlarmRequest) Size() uint16 {
	return 1
}

func (g *TracerSetAlarmRequest) IsNeedAns() uint8 {
	return 1
}

func (g *TracerSetAlarmRequest) Create(level int) []byte {
	g.WarnLevel = uint8(level)
	p, err := NewPacket(uint8(common.DEV_V2DRONEID), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

// TracerSetAlarmResponse 设置告警等级
type TracerSetAlarmResponse struct {
	Status uint8 `json:"status"`
}

func (g *TracerSetAlarmResponse) ID() uint8 {
	return TracerSetAlarmLevel
}

func (g *TracerSetAlarmResponse) Size() uint16 {
	return 1
}

func (g *TracerSetAlarmResponse) IsNeedAns() uint8 {
	return 0
}

// TracerSetHideModeRequest 设置隐蔽模式
type TracerSetHideModeRequest struct {
	HideMode uint8
}

func (g *TracerSetHideModeRequest) ID() uint8 {
	return TracerSetHideMode
}

func (g *TracerSetHideModeRequest) Size() uint16 {
	return 1
}

func (g *TracerSetHideModeRequest) IsNeedAns() uint8 {
	return 1
}

func (g *TracerSetHideModeRequest) Create(hideMode int) []byte {
	g.HideMode = uint8(hideMode)
	p, err := NewPacket(uint8(common.DEV_V2DRONEID), uint8(common.DEV_C2_WIFI), g)
	if err != nil {
		return nil
	}
	genBuff := p.StructToSlice()
	return genBuff
}

// TracerSetHideModeResponse 设置隐蔽模式
type TracerSetHideModeResponse struct {
	Status uint8 `json:"status"`
}

func (g *TracerSetHideModeResponse) ID() uint8 {
	return TracerSetHideMode
}

func (g *TracerSetHideModeResponse) Size() uint16 {
	return 1
}

func (g *TracerSetHideModeResponse) IsNeedAns() uint8 {
	return 0
}

// TracerVideoControlRequest tracers video control cmd
type TracerVideoControlRequest struct {
	Status    uint8     // 0: exit, 1: entry
	UavName   uint8     //无人机编号
	DroneName [25]uint8 //无人机名称
	Freq      uint32    //lsb无人机信号频率(mHz)
}

func (d *TracerVideoControlRequest) ID() uint8 {
	return TracerControlVideo
}
func (d *TracerVideoControlRequest) Size() uint16 {
	return 31
}
func (d *TracerVideoControlRequest) IsNeedAns() uint8 {
	return 1
}

func (d *TracerVideoControlRequest) Build(devType uint8) []byte {
	pkg, e := NewPacket(uint8(devType), uint8(common.DEV_C2_WIFI), d) //if change to drone DEV_V2DRONEID
	if e != nil {
		logger.Errorf("package ")
		return nil
	}

	genBuf := pkg.StructToSlice()
	return genBuf
}

// TracerVideoControlResponse 回包
type TracerVideoControlResponse struct {
	Status uint8 // 0: fail, 1: succ, 2:
}

func (d *TracerVideoControlResponse) ID() uint8 {
	return TracerControlVideo
}
func (d *TracerVideoControlResponse) Size() uint16 {
	return 1
}

func (d *TracerVideoControlResponse) IsNeedAns() uint8 {
	return 0
}

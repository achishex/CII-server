package devicerpc

import (
	"errors"
	"strconv"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/slink_proto/slinkv1"
	"adasgitlab.autel.com/tools/slink_proto/slinkv2"

	entity "adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/rpc/codec"
	"adasgitlab.autel.com/tools/cuav_server/rpc/connmgr"
	"adasgitlab.autel.com/tools/cuav_server/rpc/idgenerator"
	"adasgitlab.autel.com/tools/cuav_server/rpc/task"
)

// Call 下行命令远程调用
func Call(sn string, devType entity.DeviceType, cmd uint16, req interface{}) (interface{}, error) {
	//获取设备连接
	conn := connmgr.Instance().GetConn(sn)
	if conn == nil {
		logger.Errorf("sn %s GetConn nil", sn)
		return nil, errors.New("GetConn conn nil")
	}
	// 编码请求
	reqBodyBuff, err := codec.Marshal(codec.SerializationTypeSlink, req)
	if err != nil {
		logger.Errorf("req encode err %v", err)
		return nil, errors.New("req encode err")
	}
	// 构造mavlink包
	seq := idgenerator.SeqInstance().GetSeq(sn)
	header := slinkv1.NewMavHeader(slinkv1.WithSourceID(uint8(entity.DEV_C2_WIFI)), slinkv1.WithSeq(seq),
		slinkv1.WithMsgID(uint8(cmd)), slinkv1.WithAns(1), slinkv1.WithDestID(uint8(devType)), slinkv1.WithLen(uint16(len(reqBodyBuff))))
	packet := &slinkv1.MavPacket{
		Header:  *header,
		PayLoad: reqBodyBuff,
	}
	reqBuff, err := slinkv1.Encode(packet)
	if err != nil {
		logger.Errorf("rpc slinkv1 encode err %v", err)
		return nil, errors.New("rpc slinkv1 encode err")
	}
	logger.Debugf("rpc call remoteip %s send buff[% x]", conn.Conn.RemoteAddr().String(), reqBuff)
	if n, err := conn.Conn.Write(reqBuff); err != nil {
		logger.Errorf("conn write reqBuff len %d err %v", n, err)
		return nil, errors.New("conn write reqBuff err")
	}
	// 构造请求任务
	t := task.NewTask(task.WithID(strconv.Itoa(int(seq))))
	result, err := task.TaskMgrInstance().Wait(sn, cmd, t)
	if err != nil {
		logger.Errorf("wait task finish err %v", err)
		return nil, errors.New("wait task finish err")
	}
	t.SetResult(result, err)
	return result, err
}

// Call 下行命令远程调用
func CallV2(sn string, devType entity.DeviceType, cmd uint16, req interface{}) (interface{}, error) {
	//获取设备连接
	conn := connmgr.Instance().GetConn(sn)
	if conn == nil {
		logger.Errorf("sn %s GetConn nil", sn)
		return nil, errors.New("GetConn conn nil")
	}
	// 编码请求
	reqBodyBuff, err := codec.Marshal(codec.SerializationTypePB, req)
	if err != nil {
		logger.Errorf("req encode err %v", err)
		return nil, errors.New("req encode err")
	}
	// 构造mavlink包
	seq := idgenerator.SeqInstance().GetSeq(sn)
	header := slinkv2.NewMavHeader(
		slinkv2.WithSn(sn),
		slinkv2.WithProtoType(uint8(entity.ProtoTypeProto)),
		slinkv2.WithSourceID(uint8(entity.DEV_C2_WIFI)),
		slinkv2.WithSeq(uint32(seq)),
		slinkv2.WithMsgID(cmd),
		slinkv2.WithDestID(uint8(devType)),
		slinkv2.WithLen(uint16(len(reqBodyBuff))))
	packet := &slinkv2.PacketV2{
		Header:  *header,
		PayLoad: reqBodyBuff,
	}
	reqBuff, err := slinkv2.Encode(packet)

	if err != nil {
		logger.Errorf("rpc slinkv1 encode err %v", err)
		return nil, errors.New("rpc slinkv1 encode err")
	}
	logger.Debugf("rpc call remoteip %s send buff[% x]", conn.Conn.RemoteAddr().String(), reqBuff)
	if n, err := conn.Conn.Write(reqBuff); err != nil {
		logger.Errorf("conn write reqBuff len %d err %v", n, err)
		return nil, errors.New("conn write reqBuff err")
	}
	// 构造请求任务
	t := task.NewTask(task.WithID(strconv.Itoa(int(seq))))
	result, err := task.TaskMgrInstance().Wait(sn, cmd, t)
	if err != nil {
		logger.Errorf("wait task finish err %v", err)
		return nil, errors.New("wait task finish err")
	}
	t.SetResult(result, err)
	return result, err
}

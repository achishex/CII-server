package webclient

import (
	"sync"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
)

// ClientMgr websocket接入对象管理
type ClientMgr struct {
	mu      sync.Mutex
	clients map[string]*Client
}

var (
	clientMgrInstance *ClientMgr
	clientOnce        sync.Once
)

// ClientMgrInstance websocket管理
func ClientMgrInstance() *ClientMgr {
	clientOnce.Do(func() {
		clientMgrInstance = &ClientMgr{
			clients: make(map[string]*Client),
		}
	})
	return clientMgrInstance
}

// Register 注册client
func (c *ClientMgr) Register(client *Client) error {
	c.mu.Lock()
	defer c.mu.Unlock()
	logger.Debugf("Register Client id %s remoteip %s", client.id, client.conn.RemoteAddr().String())
	c.clients[client.id] = client
	return nil
}

// UnRegister 删除client
func (c *ClientMgr) UnRegister(client *Client) {
	c.mu.Lock()
	defer c.mu.Unlock()
	logger.Debugf("UnRegister Client id %s remoteip %s", client.id, client.conn.RemoteAddr().String())
	delete(c.clients, client.id)
}

// SendData 广播各个client数据
func (c *ClientMgr) SendData(data []byte) error {
	for _, client := range c.clients {
		//logger.Debugf("Send data client %s ip %s data[% x]", k, client.conn.RemoteAddr().String(), data)
		client.data <- data
	}
	return nil
}

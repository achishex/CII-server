package idgenerator

import "sync"

type IDGenerator struct {
	currID uint8 //当前ID
}

// NewIDGenerator 构造ID构造器
func NewIDGenerator() *IDGenerator {
	return &IDGenerator{
		currID: 0,
	}
}

func (i *IDGenerator) NextID() uint8 {
	id := i.currID
	i.currID = (i.currID + 1) % 255
	return id
}

type Seq struct {
	mu   sync.Mutex
	seqs map[string]*IDGenerator
}

var (
	seqInstance *Seq
	once        sync.Once
)

// SeqInstance 序列号单例
func SeqInstance() *Seq {
	once.Do(func() {
		seqInstance = &Seq{
			seqs: make(map[string]*IDGenerator),
		}
	})
	return seqInstance
}

// GetSeq 获取设备消息序列号
func (s *Seq) GetSeq(sn string) uint8 {
	s.mu.Lock()
	defer s.mu.Unlock()
	v, ok := s.seqs[sn]
	if !ok {
		s.seqs[sn] = NewIDGenerator()
	}
	if v == nil {
		s.seqs[sn] = NewIDGenerator()
	}
	return s.seqs[sn].NextID()
}

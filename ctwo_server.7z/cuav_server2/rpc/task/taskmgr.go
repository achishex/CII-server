package task

import (
	"errors"
	"sync"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
)

type TaskMgr struct {
	mu    sync.Mutex                    //数据安全锁
	tasks map[string]map[uint16][]*Task // 设备ID到命令字到任务列表
}

var (
	taskMgrInstance *TaskMgr
	taskOnce        sync.Once
)

// TaskMgrInstance 任务管理单例
func TaskMgrInstance() *TaskMgr {
	taskOnce.Do(func() {
		taskMgrInstance = &TaskMgr{
			tasks: make(map[string]map[uint16][]*Task),
		}
	})
	return taskMgrInstance
}

// Wait 等待任务完成结果
func (t *TaskMgr) Wait(sn string, cmd uint16, task *Task) (interface{}, error) {
	// 加入任务列表
	if err := t.addTask(sn, cmd, task); err != nil {
		return nil, err
	}
	ticker := time.NewTicker(task.timeout)
	defer ticker.Stop()
	for {
		select {
		case <-ticker.C:
			if err := t.delTask(sn, cmd, task); err != nil {
				return nil, errors.New("task timeout del task error")
			}
			return nil, errors.New("task timeout")
		case <-task.ch:
			return task.result, task.err
		}
	}
}

func (t *TaskMgr) Finish(sn string, cmd uint16, task *Task) error {
	// 根据TaskID先找到对应的任务
	result, err := t.getTask(sn, cmd, task.id)
	if err != nil {
		logger.Errorf("getTask sn %s cmd %d task %v err %v", sn, cmd, task, err)
		return err
	}
	result.result = task.result
	result.err = task.err
	close(result.ch)
	if err = t.delTask(sn, cmd, result); err != nil {
		logger.Errorf("task finished delTask err %v, sn %s cmd %d task %v", err, sn, cmd, task)
	}
	return nil
}

// addTask 增加任务列表
func (t *TaskMgr) addTask(sn string, cmd uint16, task *Task) error {
	t.mu.Lock()
	defer t.mu.Unlock()
	v, ok := t.tasks[sn]
	if !ok {
		t.tasks[sn] = make(map[uint16][]*Task)
	}
	_, ok = v[cmd]
	if !ok {
		t.tasks[sn][cmd] = make([]*Task, 0)
	}
	logger.Debugf("addTask sn %s cmd %d task %+v", sn, cmd, task)
	t.tasks[sn][cmd] = append(t.tasks[sn][cmd], task)
	return nil
}

// delTask 删除任务列表
func (t *TaskMgr) delTask(sn string, cmd uint16, task *Task) error {
	t.mu.Lock()
	defer t.mu.Unlock()
	if _, ok := t.tasks[sn]; !ok {
		return nil
	}
	if _, ok := t.tasks[sn][cmd]; !ok {
		return nil
	}
	tasks := t.tasks[sn][cmd]
	//删除列表中元素
	index := 0
	for _, v := range tasks {
		if task.id == v.id {
			continue
		}
		tasks[index] = v
		index++
	}
	logger.Debugf("delTask sn %s cmd %d task %+v tasks len %d end index %d", sn, cmd, task, len(tasks), index)
	t.tasks[sn][cmd] = tasks[:index]
	return nil
}

// GetTask 查找任务列表
func (t *TaskMgr) getTask(sn string, cmd uint16, id string) (*Task, error) {
	t.mu.Lock()
	defer t.mu.Unlock()
	if _, ok := t.tasks[sn]; !ok {
		return nil, errors.New("no device task")
	}
	if _, ok := t.tasks[sn][cmd]; !ok {
		return nil, errors.New("no cmd task")
	}
	for _, v := range t.tasks[sn][cmd] {
		//if v.id == id {
		return v, nil
		//}
	}
	return nil, errors.New("no find task")
}

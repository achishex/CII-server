package connmgr

import (
	"net"
	"sync"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
)

// DevConn 设备连接信息
type DevConn struct {
	Conn net.Conn
}

// ConnectMgr 设备管理
type ConnectMgr struct {
	mu       sync.Mutex
	DevConns map[string]*DevConn
}

var (
	connMgrInstance *ConnectMgr
	connOnce        sync.Once
)

// Instance 连接管理单例
func Instance() *ConnectMgr {
	connOnce.Do(func() {
		connMgrInstance = &ConnectMgr{
			DevConns: make(map[string]*DevConn),
		}
	})
	return connMgrInstance
}

// GetConn 获取连接
func (c *ConnectMgr) GetConn(sn string) *DevConn {
	c.mu.Lock()
	defer c.mu.Unlock()
	if v, ok := c.DevConns[sn]; ok {
		return v
	}
	return nil
}

// SetConn 设置连接
func (c *ConnectMgr) SetConn(sn string, conn *DevConn) error {
	logger.Debugf("SetConn sn %s conn %s", sn, conn.Conn.RemoteAddr().String())
	c.mu.Lock()
	defer c.mu.Unlock()
	c.DevConns[sn] = conn
	return nil
}

// UpdateConn 更新连接
func (c *ConnectMgr) UpdateConn(sn string, conn *DevConn) error {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.DevConns[sn] = conn
	return nil
}

// DelConn 删除连接
func (c *ConnectMgr) DelConn(sn string) error {
	logger.Debugf("DelConn sn %s ", sn)
	c.mu.Lock()
	defer c.mu.Unlock()
	delete(c.DevConns, sn)
	return nil
}

// CloseConn 主动关闭链接
func (c *ConnectMgr) CloseConn(sn string) error {
	logger.Debugf("CloseConn sn %s ", sn)
	c.mu.Lock()
	defer c.mu.Unlock()
	if conn, ok := c.DevConns[sn]; ok && conn != nil {
		conn.Conn.Close()
	}
	delete(c.DevConns, sn)
	return nil
}

package tcpserver

import (
	"sync"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	iphelper "adasgitlab.autel.com/tools/cuav_server/entity/helper"
)

// TcpServerMgr 设备唯一sn号对应的连接
type TcpServerMgr struct {
	mu         sync.Mutex
	deviceSvrs map[string]*TCPServer
}

var (
	once                 sync.Once
	tcpserverMgrInstance *TcpServerMgr
)

// TcpServerMgrInstance 获取设备连接管理单例
func TcpServerMgrInstance() *TcpServerMgr {
	once.Do(func() {
		tcpserverMgrInstance = &TcpServerMgr{
			deviceSvrs: make(map[string]*TCPServer),
		}
	})
	return tcpserverMgrInstance
}

// GetServer
func (d *TcpServerMgr) GetServer(sn string) *TCPServer {
	d.mu.Lock()
	defer d.mu.Unlock()
	//打印当前的设备连接
	for k, v := range d.deviceSvrs {
		logger.Debugf("DeviceConns sn %s tcpserver %+v", k, v)
	}
	if v, ok := d.deviceSvrs[sn]; ok {
		return v
	}
	return nil
}

// SetServer
func (d *TcpServerMgr) SetServer(sn string, svr *TCPServer) {
	d.mu.Lock()
	defer d.mu.Unlock()
	d.deviceSvrs[sn] = svr
}

// DelServer
func (d *TcpServerMgr) DelServer(sn string) {
	d.mu.Lock()
	defer d.mu.Unlock()
	delete(d.deviceSvrs, sn)
}

// GetServerInfo 通过远端sn和IP获取合适的ip和端口
func GetServerInfo(sn, remoteIP string) (string, int) {
	svr := TcpServerMgrInstance().GetServer(sn)
	if svr != nil {
		return svr.IP, svr.Port
	}
	matchIP := iphelper.MatchLocalIP(remoteIP)
	if matchIP == "" {
		logger.Errorf("MatchLocalIP empty remoteIP %s", remoteIP)
		return "", 0
	}
	matchPort, err := iphelper.GetFreeTCPPort()
	if err != nil {
		logger.Errorf("GetFreeTcpPort empty remoteip %s", remoteIP)
		return "", 0
	}
	return matchIP, matchPort
}

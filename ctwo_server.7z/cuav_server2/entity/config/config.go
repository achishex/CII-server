package config

var (
	Global = new(GlobalConfig)
)

// GlobalConfig 全局配置
type GlobalConfig struct {
	DB                 *DB
	Radar              *Radar
	Server             *Server
	Jwt                *Jwt
	Sms                *Sms
	SmsNotify          *SmsNotify
	MicroSvc           *MicroSvc
	Email              *Email
	LogKafka           *LogKafka
	LoginCloudPlatform *LoginCloudPlatform
	DbVersion          *DbVersion
	AgxPTZ             *AgxPTZ
}

// GetGlobalConfig 获取全局配置
func GetGlobalConfig() *GlobalConfig {
	return Global
}

type DB struct {
	Host   string `yaml:"host"`
	Port   int    `yaml:"port"`
	Dbname string `yaml:"dbname"`
	User   string `yaml:"user"`
	Pwd    string `yaml:"pwd"`
}

type Radar struct {
	Sid        string `yaml:"sid"`
	CtlTcpIp   string `yaml:"ctlTcpIp"`
	CtlTcpPort int    `yaml:"ctlTcpPort"`
	RcvUdpIp   string `yaml:"rcvUdpIp"`
	RcvUdpPort int    `yaml:"rcvUdpPort"`
}

type Server struct {
	RestfulApiPort     int    `yaml:"restfulApiPort"`
	RestfulApiIp       string `yaml:"restfulApiIp"`
	WebsocketIp        string `yaml:"websocketIp"`
	WebsocketPort      int    `yaml:"websocketPort"`
	RadarUdpIp         string `yaml:"radarUdpIp"`
	RadarUdpPort       int    `yaml:"radarUdpPort"`
	RadarTcpIp         string `yaml:"radarTcpIp"`
	RadarTcpPort       int    `yaml:"radarTcpPort"`
	Urd360Version      uint16 `yaml:"urd360Version"`
	Urd360TcpIp        string `yaml:"urd360TcpIp"`
	Urd360TcpPort      int    `yaml:"urd360TcpPort"`
	Urd360SpectrumPort int    `yaml:"urd360SpectrumPort"`
}

type AgxPTZ struct {
	UDPURL       string `yaml:"udpURL"`
	VideoURL     string `yaml:"videoURL"`
	VideoTimeOut string `yaml:"videoTimeOut"`
	FfmpegPath   string `yaml:"ffmpegPath"`
	VideoLogPath string `yaml:"videoLogPath"`
	BucketName   string `yaml:"bucketName"`
	Region       string `yaml:"region"`
	Ak           string `yaml:"ak"`
	Sk           string `yaml:"sk"`
	StoreType    int64  `yaml:"storeType"`
}

type Jwt struct {
	Secret    string `yaml:"secret"`
	Ttl       int64  `yaml:"ttl"`
	TokenType string `yaml:"tokenType"`
}

type Sms struct {
	AccessKeyId        string `yaml:"accessKeyId"`
	AccessKeySecret    string `yaml:"accessKeySecret"`
	SignName           string `yaml:"signName"`
	CnTemplatecode     string `yaml:"cntemplateCode"`
	AbroadTemplatecode string `yaml:"abroadtemplateCode"`
}

type SmsNotify struct {
	AccessKeyId     string           `yaml:"accessKeyId"`
	AccessKeySecret string           `yaml:"accessKeySecret"`
	SignName        string           `yaml:"signName"`
	TemplateCode    map[int32]string `yaml:"templateCode"`
}

type MicroSvc struct {
	AgentManagerSvc    string `yaml:"agentManagerSvc"`
	AppAgentSvc        string `yaml:"appAgentSvc"`
	AutelRadarAgentSvc string `yaml:"autelRadarAgentSvc"`
	WebApiSvc          string `yaml:"webApiSvc"`
	DbSvc              string `yaml:"dbSvc"`
	Version            string `yaml:"version"`
}

type Email struct {
	SmtpHost     string `yaml:"smtpHost"`
	SmtpPort     int    `yaml:"smtpPort"`
	Sender       string `yaml:"sender"`
	Password     string `yaml:"password"`
	EmailSubject string `yaml:"emailSubject"`
}

type LogKafka struct {
	SyncSwitch bool   `yaml:"syncSwitch"`
	Addr       string `yaml:"addr"`
	LogTopic   string `yaml:"logTopic"`
}

type LoginCloudPlatform struct {
	CloudIp          string `yaml:"cloudIp"`
	CloudPort        string `yaml:"cloudPort"`
	CloudRestfulIp   string `yaml:"cloudRestfulIp"`
	CloudRestfulPort string `yaml:"cloudRestfulPort"`
	C2Sn             string `yaml:"c2Sn"`
}

type DbVersion struct {
	Version string `yaml:"version"`
}

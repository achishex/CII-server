/*
	使用c2map命名区分可能被误认为是数据类型map的定义
*/

package config

import "sync"

type C2ConfigStr struct {
	Id            int64
	Longitude     float64
	Latitude      float64
	Heading       int64
	WarningRadius float64
	CounterRadius float64
	FenceRadius   float64
	ScannerRadius float64
	Height        float64
	C2Longitude   float64
	C2Latitude    float64
}
type C2ConfigMap struct {
	Mu     sync.RWMutex
	Config map[string]C2ConfigStr
}

func NewC2ConfigMap() *C2ConfigMap {
	return &C2ConfigMap{
		Config: make(map[string]C2ConfigStr),
	}
}

func (m *C2ConfigMap) Set(key string, value C2ConfigStr) {
	m.Mu.Lock()
	defer m.Mu.Unlock()
	m.Config[key] = value
}

func (m *C2ConfigMap) Get(key string) (C2ConfigStr, bool) {
	m.Mu.RLock()
	defer m.Mu.RUnlock()
	value, ok := m.Config[key]
	return value, ok
}

func IsMapEqual(m1, m2 map[string]C2ConfigStr) bool {
	if len(m1) != len(m2) {
		return false
	}

	for k, v1 := range m1 {
		v2, ok := m2[k]
		if !ok || !isStructEqual(v1, v2) {
			return false
		}
	}
	return true
}

// 检查两个结构体是否相等
func isStructEqual(s1, s2 C2ConfigStr) bool {
	return s1.Id == s2.Id &&
		s1.Longitude == s2.Longitude &&
		s1.Latitude == s2.Latitude &&
		s1.Heading == s2.Heading &&
		s1.WarningRadius == s2.WarningRadius &&
		s1.CounterRadius == s2.CounterRadius &&
		s1.FenceRadius == s2.FenceRadius &&
		s1.ScannerRadius == s2.ScannerRadius &&
		s1.Height == s2.Height &&
		s1.C2Longitude == s2.C2Longitude &&
		s1.C2Latitude == s2.C2Latitude
}

// 复制一个新的 map
func CopyMap(m map[string]C2ConfigStr) map[string]C2ConfigStr {
	copied := make(map[string]C2ConfigStr)
	for k, v := range m {
		copied[k] = v
	}
	return copied
}

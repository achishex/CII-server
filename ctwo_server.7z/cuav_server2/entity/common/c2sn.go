package common

import (
	"errors"
	"fmt"
	"os"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"github.com/denisbrodbeck/machineid"
)

const (
	//自研平板设备SN路径
	snFilePath = "/mnt/vendor/persist/devSN"
)

func getSelfAndroidSn() (string, error) {
	_, err := os.Stat(snFilePath)
	if err != nil {
		logger.Debug("read snFile fail:", err)
		return "", err
	}

	data, err := os.ReadFile(snFilePath)
	if err != nil {
		logger.Debug("read snFile fail:", err)
		return "", err
	}

	if len(data) == 0 {
		errMsg := fmt.Sprintf("%s not contain sn\n", snFilePath)
		logger.Debug(errMsg)
		return "", errors.New(errMsg)
	}

	strData := string(data)
	return strData, err

}

func GetC2DevSn() (string, error) {
	sn, err := getSelfAndroidSn()
	if err == nil {
		return sn, nil
	}
	id, err := machineid.ID()
	if err == nil {
		logger.Debug("machineid.ID = ", id)
		return id, err
	}

	logger.Debug(" err = ", err)

	return "", err
}

package common

import (
	"crypto/md5"
	"encoding/hex"
)

// ComputeMD5 ...
func ComputeMD5(s string) string {
	hash := md5.Sum([]byte(s))
	return hex.EncodeToString(hash[:])
}

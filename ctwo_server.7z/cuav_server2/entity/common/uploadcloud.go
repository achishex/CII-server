package common

// equip_list 设备类型目前是通过获取到的 etype 字符串名来判断是那类设备
const (
	Drone          = "DroneID" //TracerP TracerS
	Radar          = "radar"
	Sfl            = "Sfl"
	FPV            = "Fpv"
	NSF400         = "Spoofer"
	TracerRFurd360 = "tracerRF"
	Agx            = "Agx"
)

// 上报到云侧名称显示
const (
	DroneName          = "Tracer#"
	RadarName          = "雷达#"
	SflName            = "哨兵塔SFL"
	FPVName            = "车载FPV"
	NSF400Name         = "导航诱导"
	TracerRFurd360Name = "TracerRFurd360"
	AgxName            = "雷视一体#"
)

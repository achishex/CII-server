package common

import (
	"reflect"
	"sync"
	"testing"
)

func TestNewDeviceNFSMapSet(t *testing.T) {
	tests := []struct {
		name string
		want *DevNFSMapSet
	}{
		// TODO: Add test cases.
		{
			name: "NewDeviceNFSMapSet",
			want: &DevNFSMapSet{
				Status: make(map[string]DevNFS),
				mutex:  sync.RWMutex{},
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := NewDeviceNFSMapSet(); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("NewDeviceNFSMapSet() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestDevNFSMapSet_Clear(t *testing.T) {
	type fields struct {
		Status map[string]DevNFS
		mutex  sync.RWMutex
	}
	tests := []struct {
		name   string
		fields fields
	}{
		// TODO: Add test cases.
		{
			name: "Clear",
			fields: fields{
				Status: map[string]DevNFS{
					"sn1": {"sn1", 1},
					"sn2": {"sn2", 2},
				},
				mutex: sync.RWMutex{},
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			s := &DevNFSMapSet{
				Status: tt.fields.Status,
				mutex:  tt.fields.mutex,
			}
			s.Clear()

			if len(s.Status) != 0 {
				t.Errorf("Clear() failed, expected empty map, got %v", s.Status)
			}
		})
	}
}

func TestDevNFSMapSet_Del(t *testing.T) {
	type fields struct {
		Status map[string]DevNFS
		mutex  sync.RWMutex
	}
	type args struct {
		k string
	}
	tests := []struct {
		name   string
		fields fields
		args   args
	}{
		// TODO: Add test cases.
		{
			name: "Del",
			fields: fields{
				Status: map[string]DevNFS{
					"sn1": {"sn1", 1},
					"sn2": {"sn2", 2},
				},
				mutex: sync.RWMutex{},
			},
			args: args{
				k: "sn1",
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			s := &DevNFSMapSet{
				Status: tt.fields.Status,
				mutex:  tt.fields.mutex,
			}
			s.Del(tt.args.k)

			if _, ok := s.Status[tt.args.k]; ok {
				t.Errorf("Del() failed, key %v still exists", tt.args.k)
			}
		})
	}
}

func TestDevNFSMapSet_Get(t *testing.T) {
	type fields struct {
		Status map[string]DevNFS
		mutex  sync.RWMutex
	}
	type args struct {
		k string
	}
	tests := []struct {
		name   string
		fields fields
		args   args
		want   *DevNFS
		want1  bool
	}{
		// TODO: Add test cases.
		{
			name: "GetExistingKey",
			fields: fields{
				Status: map[string]DevNFS{
					"sn1": {"sn1", 1},
					"sn2": {"sn2", 2},
				},
				mutex: sync.RWMutex{},
			},
			args: args{
				k: "sn1",
			},
			want:  &DevNFS{"sn1", 1},
			want1: true,
		},
		{
			name: "GetNonExistingKey",
			fields: fields{
				Status: map[string]DevNFS{
					"sn1": {"sn1", 1},
					"sn2": {"sn2", 2},
				},
				mutex: sync.RWMutex{},
			},
			args: args{
				k: "sn3",
			},
			want:  nil,
			want1: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			s := &DevNFSMapSet{
				Status: tt.fields.Status,
				mutex:  tt.fields.mutex,
			}
			got, got1 := s.Get(tt.args.k)

			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("Get() got = %v, want %v", got, tt.want)
			}
			if got1 != tt.want1 {
				t.Errorf("Get() got1 = %v, want %v", got1, tt.want1)
			}
		})
	}
}

func TestDevNFSMapSet_GetAll(t *testing.T) {
	type fields struct {
		Status map[string]DevNFS
		mutex  sync.RWMutex
	}
	tests := []struct {
		name   string
		fields fields
		want   map[string]DevNFS
	}{
		// TODO: Add test cases.
		{
			name: "GetAll",
			fields: fields{
				Status: map[string]DevNFS{
					"sn1": {"sn1", 1},
					"sn2": {"sn2", 2},
				},
				mutex: sync.RWMutex{},
			},
			want: map[string]DevNFS{
				"sn1": {"sn1", 1},
				"sn2": {"sn2", 2},
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			s := &DevNFSMapSet{
				Status: tt.fields.Status,
				mutex:  tt.fields.mutex,
			}
			if got := s.GetAll(); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("GetAll() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestDevNFSMapSet_Set(t *testing.T) {
	type fields struct {
		Status map[string]DevNFS
		mutex  sync.RWMutex
	}
	type args struct {
		sn     string
		status int
	}
	tests := []struct {
		name   string
		fields fields
		args   args
		want   string
	}{
		// TODO: Add test cases.
		{
			name: "Set",
			fields: fields{
				Status: map[string]DevNFS{
					"sn1": {"sn1", 1},
					"sn2": {"sn2", 2},
				},
				mutex: sync.RWMutex{},
			},
			args: args{
				sn:     "sn3",
				status: 3,
			},
			want: "sn3",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			s := &DevNFSMapSet{
				Status: tt.fields.Status,
				mutex:  tt.fields.mutex,
			}
			if got := s.Set(tt.args.sn, tt.args.status); got != tt.want {
				t.Errorf("Set() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestNewRadarReplaySnMapSet(t *testing.T) {
	tests := []struct {
		name string
		want *RadarReplaySnMapSet
	}{
		{
			name: "Test NewRadarReplaySnMapSet",
			want: &RadarReplaySnMapSet{
				SnMap: make(map[string]RadarReplaySn),
				mutex: sync.RWMutex{},
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := NewRadarReplaySnMapSet(); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("NewRadarReplaySnMapSet() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestRadarReplaySnMapSet_Clear(t *testing.T) {
	type fields struct {
		SnMap map[string]RadarReplaySn
		mutex sync.RWMutex
	}
	tests := []struct {
		name   string
		fields fields
	}{
		{
			name: "Test RadarReplaySnMapSet Clear",
			fields: fields{
				SnMap: map[string]RadarReplaySn{
					"key1": {Sn: "SN1", IsStore: true},
					"key2": {Sn: "SN2", IsStore: false},
				},
				mutex: sync.RWMutex{},
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			s := &RadarReplaySnMapSet{
				SnMap: tt.fields.SnMap,
				mutex: tt.fields.mutex,
			}
			s.Clear()

			if len(s.SnMap) != 0 {
				t.Errorf("RadarReplaySnMapSet.Clear() failed, expected empty SnMap, got %v", s.SnMap)
			}
		})
	}
}

func TestRadarReplaySnMapSet_Del(t *testing.T) {
	type fields struct {
		SnMap map[string]RadarReplaySn
		mutex sync.RWMutex
	}
	type args struct {
		k string
	}
	tests := []struct {
		name   string
		fields fields
		args   args
	}{
		{
			name: "Test RadarReplaySnMapSet Del",
			fields: fields{
				SnMap: map[string]RadarReplaySn{
					"key1": {Sn: "SN1", IsStore: true},
					"key2": {Sn: "SN2", IsStore: false},
				},
				mutex: sync.RWMutex{},
			},
			args: args{
				k: "key1",
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			s := &RadarReplaySnMapSet{
				SnMap: tt.fields.SnMap,
				mutex: tt.fields.mutex,
			}
			s.Del(tt.args.k)

			if _, ok := s.SnMap[tt.args.k]; ok {
				t.Errorf("RadarReplaySnMapSet.Del() failed, expected key %v to be deleted, got %v", tt.args.k, s.SnMap)
			}
		})
	}
}

func TestRadarReplaySnMapSet_Get(t *testing.T) {
	type fields struct {
		SnMap map[string]RadarReplaySn
		mutex sync.RWMutex
	}
	type args struct {
		k string
	}
	tests := []struct {
		name   string
		fields fields
		args   args
		want   *RadarReplaySn
		want1  bool
	}{
		{
			name: "Test RadarReplaySnMapSet Get - Existing key",
			fields: fields{
				SnMap: map[string]RadarReplaySn{
					"key1": {Sn: "SN1", IsStore: true},
					"key2": {Sn: "SN2", IsStore: false},
				},
				mutex: sync.RWMutex{},
			},
			args: args{
				k: "key1",
			},
			want:  &RadarReplaySn{Sn: "SN1", IsStore: true},
			want1: true,
		},
		{
			name: "Test RadarReplaySnMapSet Get - Non-existent key",
			fields: fields{
				SnMap: map[string]RadarReplaySn{
					"key1": {Sn: "SN1", IsStore: true},
					"key2": {Sn: "SN2", IsStore: false},
				},
				mutex: sync.RWMutex{},
			},
			args: args{
				k: "key3",
			},
			want:  nil,
			want1: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			s := &RadarReplaySnMapSet{
				SnMap: tt.fields.SnMap,
				mutex: tt.fields.mutex,
			}
			got, got1 := s.Get(tt.args.k)
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("Get() got = %v, want %v", got, tt.want)
			}
			if got1 != tt.want1 {
				t.Errorf("Get() got1 = %v, want %v", got1, tt.want1)
			}
		})
	}
}

func TestRadarReplaySnMapSet_GetAll(t *testing.T) {
	type fields struct {
		SnMap map[string]RadarReplaySn
		mutex sync.RWMutex
	}
	tests := []struct {
		name   string
		fields fields
		want   map[string]RadarReplaySn
	}{
		{
			name: "Test RadarReplaySnMapSet GetAll",
			fields: fields{
				SnMap: map[string]RadarReplaySn{
					"key1": {Sn: "SN1", IsStore: true},
					"key2": {Sn: "SN2", IsStore: false},
				},
				mutex: sync.RWMutex{},
			},
			want: map[string]RadarReplaySn{
				"key1": {Sn: "SN1", IsStore: true},
				"key2": {Sn: "SN2", IsStore: false},
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			s := &RadarReplaySnMapSet{
				SnMap: tt.fields.SnMap,
				mutex: tt.fields.mutex,
			}
			if got := s.GetAll(); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("GetAll() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestRadarReplaySnMapSet_Set(t *testing.T) {
	type fields struct {
		SnMap map[string]RadarReplaySn
		mutex sync.RWMutex
	}
	type args struct {
		k       string
		sn      string
		IsStore bool
	}
	tests := []struct {
		name   string
		fields fields
		args   args
		want   string
	}{
		{
			name: "Test RadarReplaySnMapSet Set",
			fields: fields{
				SnMap: map[string]RadarReplaySn{
					"key1": {Sn: "SN1", IsStore: true},
					"key2": {Sn: "SN2", IsStore: false},
				},
				mutex: sync.RWMutex{},
			},
			args: args{
				k:       "key3",
				sn:      "SN3",
				IsStore: true,
			},
			want: "key3",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			s := &RadarReplaySnMapSet{
				SnMap: tt.fields.SnMap,
				mutex: tt.fields.mutex,
			}
			if got := s.Set(tt.args.k, tt.args.sn, tt.args.IsStore); got != tt.want {
				t.Errorf("Set() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestNewFileMapSet(t *testing.T) {
	tests := []struct {
		name string
		want *FileMapSet
	}{
		{
			name: "Test NewFileMapSet",
			want: &FileMapSet{
				FileMap: make(map[uint32]File),
				mutex:   sync.RWMutex{},
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := NewFileMapSet(); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("NewFileMapSet() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestFileMapSet_Del(t *testing.T) {
	type fields struct {
		FileMap map[uint32]File
		mutex   sync.RWMutex
	}
	type args struct {
		k uint32
	}
	tests := []struct {
		name   string
		fields fields
		args   args
	}{
		{
			name: "Test FileMapSet Del",
			fields: fields{
				FileMap: map[uint32]File{
					1: {Name: "file1", FilePath: "/path/to/file1"},
					2: {Name: "file2", FilePath: "/path/to/file2"},
				},
				mutex: sync.RWMutex{},
			},
			args: args{
				k: 1,
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			s := &FileMapSet{
				FileMap: tt.fields.FileMap,
				mutex:   tt.fields.mutex,
			}
			s.Del(tt.args.k)

			if _, ok := s.FileMap[tt.args.k]; ok {
				t.Errorf("FileMapSet.Del() failed, expected key %v to be deleted, got %v", tt.args.k, s.FileMap)
			}
		})
	}
}

func TestFileMapSet_Get(t *testing.T) {
	type fields struct {
		FileMap map[uint32]File
		mutex   sync.RWMutex
	}
	type args struct {
		k uint32
	}
	tests := []struct {
		name   string
		fields fields
		args   args
		want   *File
		want1  bool
	}{
		{
			name: "Test FileMapSet Get - Existing key",
			fields: fields{
				FileMap: map[uint32]File{
					1: {Name: "file1", FilePath: "/path/to/file1"},
					2: {Name: "file2", FilePath: "/path/to/file2"},
				},
				mutex: sync.RWMutex{},
			},
			args: args{
				k: 1,
			},
			want:  &File{Name: "file1", FilePath: "/path/to/file1"},
			want1: true,
		},
		{
			name: "Test FileMapSet Get - Non-existent key",
			fields: fields{
				FileMap: map[uint32]File{
					1: {Name: "file1", FilePath: "/path/to/file1"},
					2: {Name: "file2", FilePath: "/path/to/file2"},
				},
				mutex: sync.RWMutex{},
			},
			args: args{
				k: 3,
			},
			want:  nil,
			want1: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			s := &FileMapSet{
				FileMap: tt.fields.FileMap,
				mutex:   tt.fields.mutex,
			}
			got, got1 := s.Get(tt.args.k)
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("FileMapSet.Get() got = %v, want %v", got, tt.want)
			}
			if got1 != tt.want1 {
				t.Errorf("FileMapSet.Get() got1 = %v, want %v", got1, tt.want1)
			}
		})
	}
}

package common

import (
	"fmt"
	"testing"
	"time"
)

func TestBuildHeartTableName(t *testing.T) {
	want := fmt.Sprintf("%s%s%s", "123", "_heart_", time.Now().Format(TimeStFormatOnTabName))
	ret := BuildHeartTableName("123")
	if want != ret {
		t.Error("ret = ", ret)
	}
}

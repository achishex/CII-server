package bean

type C2Id struct {
	Id   int32  `json:"id"`
	C2Id string `json:"c2_id"`
}

func (C2Id) TableName() string {
	return "c2_id"
}

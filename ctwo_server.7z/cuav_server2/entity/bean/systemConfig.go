package bean

type SystemConfig struct {
	Id            int32   `json:"id"`
	Longitude     float64 `json:"longitude"`
	Latitude      float64 `json:"latitude"`
	Heading       int32   `json:"heading"`
	Arch          int32   `json:"arch"`
	TerminalId    string  `json:"terminal_id"`
	Etype         string  `json:"etype"`
	WarningRadius float64 `json:"warning_radius"`
	CounterRadius float64 `json:"counter_radius"`
	FenceRadius   float64 `json:"fence_radius"`
	ScannerRadius float64 `json:"scanner_radius"`
	Height        float64 `json:"height"`
	C2Longitude   float64 `json:"c2_longitude"`
	C2Latitude    float64 `json:"c2_latitude"`
}

func (SystemConfig) TableName() string {
	return "system_config"
}

package bean

type GunTcpHeart struct {
	Id             int     `json:"id"`
	HeaderId       int64   `json:"header_id"`
	TimeStamp      uint32  `json:"time_stamp"`
	ScreenStatus   uint8   `json:"screen_status"`
	Electricity    uint8   `json:"electricity"`
	SignalStrength uint8   `json:"signal_strength"`
	WorkStatus     uint8   `json:"work_status"`
	AlarmLevel     uint8   `json:"alarm_level"`
	HitFreq        uint8   `json:"hit_freq"`
	DetectFreq     uint32  `json:"detect_freq"`
	X              uint16  `json:"x"`
	Y              uint16  `json:"y"`
	Z              uint16  `json:"z"`
	GunLongitude   float64 `json:"gun_longitude"`
	GunLatitude    float64 `json:"gun_latitude"`
	GunAltitude    int32   `json:"gun_altitude"`
	SatellitesNum  uint16  `json:"satellites_num"`
	GunDirection   float64 `json:"gun_direction"`
	UDroneNum      uint8   `json:"u_drone_num"`
	Elevation      float64 `json:"elevation"`
	ReceivedTime   int64   `json:"received_time"`
}

func (GunTcpHeart) TableName() string {
	return "gun_tcp_heart"
}

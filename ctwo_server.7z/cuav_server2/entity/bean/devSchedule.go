package bean

type DevSchedule struct {
	Id          int32  `json:"id"`
	Sn          string `json:"sn"`
	Date        string `json:"date"`        //日期  20230719
	Information int32  `json:"information"` //是否有数据1:有   2无
}

func (DevSchedule) TableName() string {
	return "dev_date_schedule"
}

package bean

type Nsf4000Config struct {
	Id                   int32   `json:"id"`
	Sn                   string  `json:"sn"`
	Radius               int32   `json:"radius"`
	Power                int32   `json:"power"`
	DefenseLevelSpeed    int32   `json:"defense_level_speed"`
	DefenseVerticalSpeed int32   `json:"defense_vertical_speed"`
	Longitude            float64 `json:"longitude"`
	Latitude             float64 `json:"latitude"`
	Height               int32   `json:"height"`
	DriveLevelSpeed      int32   `json:"drive_level_speed"`
	DriveVerticalSpeed   int32   `json:"drive_vertical_speed"`
	DefenseLongitude     float64 `json:"defense_longitude"`   //主动防御经度
	DefenseLatitude      float64 `json:"defense_latitude"`    //主动防御纬度
	AreaStopLongitude    float64 `json:"area_stop_longitude"` //区域拒止经度
	AreaStopLatitude     float64 `json:"area_stop_latitude"`  //区域拒止纬度
}

func (Nsf4000Config) TableName() string {
	return "nsf4000_config"
}

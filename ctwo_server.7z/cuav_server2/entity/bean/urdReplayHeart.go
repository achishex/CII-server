package bean

import "adasgitlab.autel.com/tools/cuav_server/entity/common"

// UrdReplayHeartData deprecated
type UrdReplayHeartData struct {
	Id                int     `json:"id"`
	Sn                string  `json:"sn"`
	Name              string  `json:"name"`
	Longitude         float32 `json:"longitude"`
	Latitude          float32 `json:"latitude"`
	Height            int32   `json:"height"`
	Status            int16   `json:"status"`
	Azimuth           int32   `json:"azimuth"`
	Type              int32   `json:"type"`
	CompassStatus     int8    `json:"compass_status"`
	GpsStatus         int8    `json:"gps_status"`
	ReceiverStatus    int8    `json:"receiver_status"`
	AntennaStatus     int8    `json:"antenna_status"`
	AntennaCoverRange int32   `json:"antenna_cover_range"`
	CreateTime        int64   `json:"create_time"` //创建时间戳格式  "2006-01-02 15:04:05.000"  // 对应的时间格式
}

// GetTableName UrdReplayHeartData
func (UrdReplayHeartData) GetTableName(sn string) string {
	return common.BuildHeartTableName(sn)
}

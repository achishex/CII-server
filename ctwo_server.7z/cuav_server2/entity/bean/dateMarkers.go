package bean

type DateMarkers struct {
	Id        int32  `json:"id"`
	TimeStamp string `json:"time_stamp"`
	Level     int32  `json:"level"`
	Tips      string `json:"tips"`
	CreatTime int64  `json:"creat_time"`
}

func (DateMarkers) TableName() string {
	return "date_markers"
}

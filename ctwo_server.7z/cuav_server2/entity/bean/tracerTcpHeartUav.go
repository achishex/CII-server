package bean

type TracerTcpHeartUav struct {
	Id                 int     `json:"id"`
	HeaderId           int64   `json:"header_id"`
	ProductType        int     `json:"product_type"`
	DroneName          string  `json:"drone_name"`
	SerialNum          string  `json:"serial_num"`
	DroneLongitude     float64 `json:"drone_longitude"`
	DroneLatitude      float64 `json:"drone_latitude"`
	DroneHeight        float64 `json:"drone_height"`
	DroneYawAngle      float64 `json:"drone_yaw_angle"`
	DroneSpeed         float64 `json:"drone_speed"`
	DroneVerticalSpeed float64 `json:"drone_vertical_speed"`
	OperatorLongitude  float64 `json:"operator_longitude"`
	OperatorLatitude   float64 `json:"operator_latitude"`
	DroneHorizon       float64 `json:"drone_horizon"`
	DronePitch         float64 `json:"drone_pitch"`
	Freq               float64 `json:"freq"`
	Distance           int     `json:"distance"`
	DangerLevels       int     `json:"danger_levels"`
	WaypointLongitude  float64 `json:"waypoint_longitude"`
	WaypointLatitude   float64 `json:"waypoint_latitude"`
}

func (TracerTcpHeartUav) TableName() string {
	return "tracer_tcp_heart_uav"
}

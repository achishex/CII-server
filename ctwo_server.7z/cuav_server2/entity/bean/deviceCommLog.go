package bean

type DeviceCommLog struct {
	Id         int    `json:"id"`
	DeviceType int    `json:"device_type"`
	Sn         string `json:"sn"`
	MsgId      uint8  `json:"msg_id"`
	Request    string `json:"request"`
	Response   string `json:"response"`
	Remark     string `json:"remark"`
	CreateTime int    `json:"create_time"`
}

func (DeviceCommLog) TableName() string {
	return "device_comm_log"
}

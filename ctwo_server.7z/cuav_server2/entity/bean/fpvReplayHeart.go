package bean

import "adasgitlab.autel.com/tools/cuav_server/entity/common"

type FpvReplayHeartData struct {
	Id            int    `json:"id"`
	Sn            string `json:"sn"`
	IsOnline      int    `json:"is_online"`
	BatteryStatus int    `json:"battery_status"`
	Electricity   int    `json:"electricity"`
	WorkMode      int    `json:"work_mode"`
	WorkStatus    int    `json:"work_status"`
	AlarmLevel    int    `json:"alarm_level"`
	CreateTime    int64  `json:"create_time"  gorm:"index"` //创建时间戳格式  "2006-01-02 15:04:05.000"  // 对应的时间格式
}

func (FpvReplayHeartData) GetTableName(sn string) string {
	return common.BuildHeartTableName(sn)
}

type TabNameOps interface {
	GetTableName(sn string) string
}

type FpvReplaySysConfigData struct {
	Id            int     `json:"id"`
	Sn            string  `json:"sn"`
	Longitude     float64 `json:"longitude"`
	Latitude      float64 `json:"latitude"`
	Heading       int32   `json:"heading"`
	Arch          int32   `json:"arch"`
	TerminalId    string  `json:"terminal_id"`
	EType         string  `json:"e_type"`
	WarningRadius float64 `json:"warning_radius"`
	CounterRadius float64 `json:"counter_radius"`
	FenceRadius   float64 `json:"fence_radius"`
	ScannerRadius float64 `json:"scanner_radius"`
	Height        float64 `json:"height"`
	C2Longitude   float64 `json:"c2_longitude"`
	C2Latitude    float64 `json:"c2_latitude"`
	CreateTime    int64   `json:"create_time"  gorm:"index"` //创建时间戳格式  "2006-01-02 15:04:05.000"  // 对应的时间格式
}

func (FpvReplaySysConfigData) GetTableName(sn string) string {
	return common.BuildSysCfgTabName(sn)
}

package bean

type LogId struct {
	Id    int32  `json:"id"`
	LogId string `json:"log_id"`
}

func (LogId) TableName() string {
	return "log_id"
}

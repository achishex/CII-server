package bean

import (
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
)

type RadarReplayDetect struct {
	Id             int     `json:"id"`
	ObjId          int     `json:"obj_id"`
	Sn             string  `json:"sn"`
	X              float64 `json:"x"`
	Y              float64 `json:"y"`
	Z              float64 `json:"z"`
	Velocity       float64 `json:"velocity"`      //速度
	Azimuth        float64 `json:"azimuth"`       //方位角
	Alive          int     `json:"alive"`         //周期数
	ExistingProb   float64 `json:"existing_prob"` //存在概率
	StateType      int     `json:"state_type"`
	CreateTime     int64   `json:"create_time"  gorm:"index"` //创建时间戳格式  "2006-01-02 15:04:05.000"  // 对应的时间格式
	Classification int32   `json:"classification"`
}

func (RadarReplayDetect) TableName() string {
	return "radar_replay_detect"
}

func (RadarReplayDetect) GetTableName(sn string) string {
	return common.BuildDetectTableName(sn)
}

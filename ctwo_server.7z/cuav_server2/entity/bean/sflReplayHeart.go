package bean

import "adasgitlab.autel.com/tools/cuav_server/entity/common"

type SFLReplayHeartData struct {
	Id            int     `json:"id"`
	Sn            string  `json:"sn"`
	TimeStamp     int32   `json:"time_stamp"`
	WorkStatus    int32   `json:"work_status"`
	IsOnline      int32   `json:"is_online"`
	HitFreq       int32   `json:"hit_freq"`
	DetectFreq    float64 `json:"detect_freq"`
	Elevation     float64 `json:"elevation"`
	GunDirection  float64 `json:"gun_direction"`
	GunLongitude  float64 `json:"gun_longitude"`
	GunLatitude   float64 `json:"gun_latitude"`
	GunAltitude   float64 `json:"gun_altitude"`
	SatellitesNum int32   `json:"satellites_num"`
	FaultLevel    int32   `json:"fault_level"`
	CtrlFault     int32   `json:"ctrl_fault"`
	AeagFault     int32   `json:"aeag_fault"`
	TracerFault   int32   `json:"tracer_fault"`
	CreateTime    int64   `json:"create_time"  gorm:"index"` //创建时间戳格式  "2006-01-02 15:04:05.000"  // 对应的时间格式
}

func (SFLReplayHeartData) GetTableName(sn string) string {
	return common.BuildHeartTableName(sn)
}

package bean

type RemoteAlarm struct {
	Id        int32  `json:"id"`
	Phone     string `json:"phone"`
	Email     string `json:"email"`
	Open      int32  `json:"open"`
	AlarmTime int32  `json:"alarm_time"`
}

func (RemoteAlarm) TableName() string {
	return "remote_alarm"
}

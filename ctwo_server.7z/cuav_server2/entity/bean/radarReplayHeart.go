package bean

import (
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
)

type RadarReplayHeart struct {
	Id          int    `json:"id"`
	Sn          string `json:"sn"`
	IsOnline    int    `json:"is_online"`
	Electricity int    `json:"electricity"`
	CreateTime  int64  `json:"create_time" gorm:"index"` //创建时间

}

func (RadarReplayHeart) TableName() string {
	return "radar_replay_heart"
}

func (RadarReplayHeart) GetTableName(sn string) string {
	return common.BuildHeartTableName(sn)
}

package threatlevel

import "testing"

func TestMaxThreatLevel(t *testing.T) {
	type args struct {
		e *JudgeElement
	}
	tests := []struct {
		name string
		args args
		want int
	}{
		{
			name: "CASE1",
			args: args{
				e: &JudgeElement{
					X:             0.3,
					Y:             0.2,
					Z:             -0.6,
					Vx:            3.6,
					Vy:            5.9,
					EleScanCenter: 15,
					EleScanScope:  40,
					Pitching:      20,
				},
			},
			want: 1,
		},
		{
			name: "CASE2",
			args: args{
				e: &JudgeElement{
					X:             0.3,
					Y:             0.2,
					Z:             0.6,
					Vx:            3.6,
					Vy:            5.9,
					EleScanCenter: 15,
					EleScanScope:  40,
					Pitching:      20,
				},
			},
			want: 1,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := MaxThreatLevel(tt.args.e); got != tt.want {
				t.Errorf("MaxThreatLevel() = %v, want %v", got, tt.want)
			}
		})
	}
}

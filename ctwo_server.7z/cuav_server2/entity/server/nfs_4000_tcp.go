package server

import (
	"context"
	"net"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
)

type TcpProcessor interface {
	Handle(conn net.Conn)
}

type TcpClient struct {
	addr   string
	conn   net.Conn
	always bool
	ctrl   TcpProcessor
	ctx    context.Context
	cancel context.CancelFunc
}

func NewTcpClient(adr string, proc TcpProcessor, al bool) *TcpClient {
	tc := &TcpClient{}
	tc.addr = adr
	tc.always = al
	tc.ctrl = proc

	return tc
}

func (tc *TcpClient) Run() {
	tick := time.NewTicker(5 * time.Second)
	defer tick.Stop()
	for {
		select {
		case <-tick.C:
			logger.Info("Run connect NFS4000")
			conn, err := net.Dial("tcp", tc.addr)
			if err != nil {
				logger.Error("再链接失败, err:", err)
				continue
			}
			tc.ctrl.Handle(conn)
		}
	}
}

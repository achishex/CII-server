//go:build !(linux || android)

package ip

import (
	"fmt"
	"net"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
)

// GetBroadcastAddress 返回本地地址及对应广播地址列表
func GetBroadcastAddress() ([]string, []string, error) {
	var localAddrs []string
	var broadcastAddrs []string
	interfaces, err := net.Interfaces() // 获取所有网络接口
	if err != nil {
		return localAddrs, broadcastAddrs, err
	}

	for _, face := range interfaces {
		// 选择 已启用的、能广播的、非回环 的接口
		if (face.Flags & (net.FlagUp | net.FlagBroadcast | net.FlagLoopback)) == (net.FlagBroadcast | net.FlagUp) {
			addrs, err := face.Addrs()
			if err != nil {
				return localAddrs, broadcastAddrs, err
			}
			for _, addr := range addrs {
				if ipNet, ok := addr.(*net.IPNet); ok {
					// 只取IPv4的
					if ipNet.IP.To4() != nil {
						// 用于存放广播地址字段（共4个字段）
						var fields net.IP
						for i := 0; i < 4; i++ {
							ipSec := ipNet.IP.To4()[i]
							maskSec := ipNet.Mask[i]
							//ip先按位与mask ,再或mask的反
							fields = append(fields, (ipSec&maskSec)|(^ipNet.Mask[i])) // 计算广播地址各个字段
						}
						broadAddr := fields.String()
						localAddrs = append(localAddrs, ipNet.IP.To4().String())
						broadcastAddrs = append(broadcastAddrs, broadAddr)
					}
				}
			}
		}
	}

	return localAddrs, broadcastAddrs, err
}

// GetLocalIp 根据对方ip获取对应本地ip
func GetLocalIp(remoteIp string) (string, error) {
	remoteArr := net.ParseIP(remoteIp).To4()
	if remoteArr == nil {
		logger.Error("ip 转换错误：", remoteIp)
		return "", fmt.Errorf("ip 转换错误: %s", remoteIp)
	}
	addrs, err := net.InterfaceAddrs()
	if err != nil {
		logger.Error("获取ip地址错误：", err)
		return "", fmt.Errorf("获取ip地址错误: %v", err)
	}
	var ips string
	for _, address := range addrs {
		// 检查ip地址判断是否回环地址
		if ipNet, ok := address.(*net.IPNet); ok && !ipNet.IP.IsLoopback() {
			localArr := ipNet.IP.To4()
			if localArr != nil && len(localArr) > 0 {
				mask := ipNet.Mask
				if (remoteArr[0]&mask[0] == localArr[0]&mask[0]) &&
					(remoteArr[1]&mask[1] == localArr[1]&mask[1]) &&
					(remoteArr[2]&mask[2] == localArr[2]&mask[2]) && (remoteArr[3]&mask[3] == localArr[3]&mask[3]) {
					ips = ipNet.IP.String()
					return ips, nil
				}
			}
		}
	}
	return ips, nil
}

// GetFreeTcpPort gets a free tcp port.
func GetFreeTcpPort() (port int, err error) {
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		return 0, err
	}
	defer listener.Close()

	return listener.Addr().(*net.TCPAddr).Port, nil
}

// IPV4 字符串IP转换成IPv4
func IPV4(ip string) [4]uint8 {
	ips := net.ParseIP(ip)
	if ips == nil {
		logger.Errorf("invalid ip %s", ip)
		return [4]uint8{}
	}
	ipBytes := ips.To4()
	if ipBytes == nil {
		logger.Errorf("invalid ipv4 ip")
		return [4]uint8{}
	}
	var addr [4]uint8
	copy(addr[:], ipBytes)
	return addr
}

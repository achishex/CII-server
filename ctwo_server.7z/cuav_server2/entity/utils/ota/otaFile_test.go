package ota

import (
	"testing"
)

func TestPathOrFileExists(t *testing.T) {
	type args struct {
		path string
	}
	tests := []struct {
		name    string
		args    args
		want    bool
		wantErr bool
	}{
		{
			name: "Case1",
			args: args{
				path: "/tmp/update.bin",
			},
			want:    false,
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := PathOrFileExists(tt.args.path)
			if (err != nil) != tt.wantErr {
				t.Errorf("PathOrFileExists() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if got != tt.want {
				t.Errorf("PathOrFileExists() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestCheckVersionExist(t *testing.T) {
	type args struct {
		filePath string
		version  string
	}
	tests := []struct {
		name string
		args args
		want bool
	}{
		{
			name: "Case1",
			args: args{
				filePath: "./",
				version:  "",
			},
			want: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := CheckVersionExist(tt.args.filePath, tt.args.version); got != tt.want {
				t.Errorf("CheckVersionExist() = %v, want %v", got, tt.want)
			}
		})
	}
}

package ota

import (
	"bytes"
	"encoding/json"
	"errors"
	"io/ioutil"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"gorm.io/gorm"
)

const (
	CloudOtaDownloadPreSignUrl = "http://ec2-52-83-173-24.cn-northwest-1.compute.amazonaws.com.cn/otaPackage/downloadPreSignUrl"
	GetCloudFileListUrl        = "http://ec2-52-83-173-24.cn-northwest-1.compute.amazonaws.com.cn/file/list"
	GetLatestPkgUrl            = "http://ec2-52-83-173-24.cn-northwest-1.compute.amazonaws.com.cn/otaPackage/getLatestPkg"

	DefaultOtaPkgPath = "/storage/emulated/0/Android/data/com.skyfend.cuav/files/c2ota"

	FileTypeOtaPkg = 2

	TestFileTypeOtaPkg             = 10
	TestGetLatestPkgUrl            = "http://ec2-52-83-173-24.cn-northwest-1.compute.amazonaws.com.cn/otaPackage/test/getLatestPkg"
	TestCloudOtaDownloadPreSignUrl = "http://ec2-52-83-173-24.cn-northwest-1.compute.amazonaws.com.cn/otaPackage/test/downloadPreSignUrl"

	DeviceTypeRadar   = 1
	DeviceTypeGun     = 2
	DeviceTypeDroneID = 3
	DeviceTypeTracerP = 4
	DeviceTypeTracerS = 5
	DeviceTypeFPV     = 6
	DeviceTypeSFL     = 7
	DeviceTypeSta     = 8 //机载
)

var mutex sync.Mutex

func GetCloudOtaFilePackage(key string) (Package, bool) {
	mutex.Lock()
	defer mutex.Unlock()

	pkg, ok := CloudOtaFileMap[key]
	return pkg, ok
}

func SetCloudOtaFilePackage(key string, pkg Package) {
	mutex.Lock()
	defer mutex.Unlock()

	CloudOtaFileMap[key] = pkg
}

func GetLatestOtaCacheMapPackage(key int32) (*Package, bool) {
	mutex.Lock()
	defer mutex.Unlock()

	pkg, ok := LatestOtaCacheMap[key]
	return pkg, ok
}

func SetLatestOtaCacheMapPackage(key int32, pkg *Package) {
	mutex.Lock()
	defer mutex.Unlock()

	LatestOtaCacheMap[key] = pkg
}

var (
	LocalOtaPkgPathMap = map[int32]string{
		DeviceTypeRadar:   "/radar/",
		DeviceTypeGun:     "/gun/",
		DeviceTypeDroneID: "/droneID/",
		DeviceTypeTracerP: "/tracerP/",
		DeviceTypeTracerS: "/tracerS/",
		DeviceTypeFPV:     "/fpv/",
		DeviceTypeSFL:     "/sfl/",
	}

	LatestOtaCacheMap     = make(map[int32]*Package) // 用于缓存最新版本升级包
	CloudOtaFileCacheList = make([]Package, 0)       // 用于缓存云端升级包列表以备无网络情况
	CloudOtaFileMap       = make(map[string]Package) // 用于缓存云端升级包以备无网络情况
)

type Response struct {
	Code int         `json:"code"`
	Data interface{} `json:"data"`
	Msg  string      `json:"msg"`
}

type PreSignUrlResp struct {
	Method  string      `json:"method"`
	URL     string      `json:"url"`
	FileKey string      `json:"fileKey"`
	Header  http.Header `json:"header" swaggertype:"string"`
}

type GetOtaPreSignDownloadUrlReq struct {
	FileName    string `json:"file_name"`    // 文件名
	FileKey     string `json:"file_key"`     // 文件key
	FileType    int8   `json:"file_type"`    // 文件类型 1日志 2升级包
	DeviceType  int8   `json:"device_type"`  // 设备类型 1雷达 2反制抢 3droneID
	RangeHeader string `json:"range_header"` // 文件下载起始位置如:bytes=1-1024
}

type FileListReq struct {
	Page       int    `json:"page" form:"page"`             // 页码
	PageSize   int    `json:"pageSize" form:"pageSize"`     // 每页大小
	FileType   int8   `json:"file_type" binding:"required"` // 文件类型 1日志 2升级包
	DeviceType int8   `json:"device_type"`                  // 设备类型 0全部 1雷达 2反制抢 3droneID
	MacNo      string `json:"mac_no"`                       // mac设备号
}

type GetOtaCloudFileListResult struct {
	List     []Package `json:"list"`
	Total    int64     `json:"total"`
	Page     int       `json:"page"`
	PageSize int       `json:"pageSize"`
}

type Package struct {
	ID         uint           `gorm:"primarykey"` // 主键ID
	CreatedAt  time.Time      // 创建时间
	UpdatedAt  time.Time      // 更新时间
	DeletedAt  gorm.DeletedAt `gorm:"index" json:"-"`                                                            // 删除时间
	FileKey    string         `json:"file_key" gorm:"index;default:'';not null;comment:文件key"`                   // 文件key
	FileName   string         `json:"file_name" gorm:"index;default:'';not null;comment:文件名"`                    // 文件名
	Version    string         `json:"version" gorm:"index;default:'';not null;comment:更新包版本"`                    // 更新包版本
	IsLatest   int8           `json:"is_latest " gorm:"default:0;not null;comment:是否为最新版本 0否 1是"`                // 是否为最新版本 0否 1是
	FileType   string         `json:"file_type" gorm:"default:'';not null;comment:文件类型"`                         // 文件类型
	FileSize   int            `json:"file_size" gorm:"default:0;not null;comment:文件大小"`                          // 文件大小
	MacAddr    string         `json:"mac_addr" gorm:"default:'';not null;comment:mac地址"`                         // mac地址
	UserName   string         `json:"user_name" gorm:"default:'';not null;comment:上传用户名"`                        // 上传用户名
	DeviceType int8           `json:"device_type" gorm:"default:0;not null;comment:更新包类型 0未知 1雷达 2反制抢 3droneID"` // 更新包类型 0未知 1雷达 2反制抢 3droneID
	Status     int8           `json:"status" gorm:"default:0;not null;comment:上传状态 0待上传 1上传成功 2上传失败"`            // 上传状态 0待上传 1上传成功 2上传失败
	C2Version  string         `json:"c2_version" gorm:"index;default:'';not null;comment:对应C2版本"`                //对应C2版本
}

type GetLatestPkgReq struct {
	DeviceType int8 `json:"device_type"` // 设备类型
}

// SendJsonPostReq 发送postJson请求
func SendJsonPostReq(req interface{}, url string) (rsp *http.Response, err error) {
	jsonData, err := json.Marshal(req)
	if err != nil {
		logger.Errorf("json.Marshal err: %v", err)
		return nil, errors.New("json.Marshal  err:")
	}
	request, _ := http.NewRequest("POST", url, bytes.NewBuffer(jsonData))
	if err != nil {
		logger.Errorf("POST err: %v", err)
		return nil, errors.New("Post  err:")
	}
	request.Header.Set("Content-Type", "application/json; charset=UTF-8")

	client := &http.Client{
		Timeout: time.Second * 3,
	}
	rsp, err = client.Do(request)
	if err != nil {
		logger.Errorf("req client err: %v", err)
		return nil, errors.New("req client err")
	}
	return
}

func PathOrFileExists(path string) (bool, error) {
	_, err := os.Stat(path)
	if err == nil {
		return true, nil
	}
	if os.IsNotExist(err) {
		return false, nil
	}
	return false, err
}

type TracerUpgradeInfo struct {
	List []TracerUpgradeList `json:"list"`
}
type TracerUpgradeList struct {
	Version            string `json:"version"`
	UpgradeDesc        string `json:"upgrade_des"`
	UpgradeDescChinese string `json:"upgrade_des_chinese"`
	UpgradeDescEnglish string `json:"upgrade_des_english"`
	UpgradeDescRussian string `json:"upgrade_des_russian"`
}

// GetLocalOtaPkgInfo 根据本地目录获取升级包信息
func GetLocalOtaPkgInfo(filePath string, deviceType int32, reqPath string) []*client.OtaPkgInfo {
	exit, _ := PathOrFileExists(filePath)
	if !exit {
		return nil
	}
	files, err := os.ReadDir(filePath)
	if err != nil {
		logger.Errorf("GetLocalOtaPkgList 读取目录错误：%v \n", err)
		return nil
	}

	upgradeList, err := GetLocalTracerJson(reqPath, deviceType)
	if err != nil {
		logger.Error("Get Local Tracer Json err:", err)
	}

	otaPkgList := make([]*client.OtaPkgInfo, 0)
	for _, file := range files {
		if !file.IsDir() {
			fileName := file.Name()
			cloudFileKey := fileName
			downloadStatus := 2
			var permil int64
			if filepath.Ext(fileName) != ".bin" {
				downloadStatus = 3
				cloudFileKey = strings.TrimSuffix(fileName, filepath.Ext(fileName)) + ".bin"
			}

			cloudFile, ok := GetCloudOtaFilePackage(cloudFileKey)
			if !ok {
				// 删除不在云端列表中的ota文件
				if strings.Contains(file.Name(), "json") {
					continue
				}
				deleteFilePath := filepath.Join(filePath, file.Name())
				logger.Info("GetLocalOtaPkgInfo 删除文件", deleteFilePath)
				fileExit, _ := PathOrFileExists(deleteFilePath)
				if fileExit {
					// 删除文件
					//_ = os.Remove(deleteFilePath)
				}
				continue
			}
			fileInfo, _ := file.Info()
			permil = 1000 * fileInfo.Size() / int64(cloudFile.FileSize)

			// 截取版本信息
			version := fileName[:len(fileName)-8]
			if permil != 1000 && downloadStatus != 3 {
				downloadStatus = 4
			}
			upgradeInfo, upgradeDescChinese, upgradeDescEnglish, upgradeDescRussian := "", "", "", ""
			if upgradeList != nil {
				for _, list := range upgradeList.List {
					if fileName == list.Version {
						upgradeInfo = list.UpgradeDesc
						upgradeDescChinese = list.UpgradeDescChinese
						upgradeDescEnglish = list.UpgradeDescEnglish
						upgradeDescRussian = list.UpgradeDescRussian
					}
				}
			}
			otaPkgList = append(otaPkgList, &client.OtaPkgInfo{
				FileName:           fileName,
				DeviceType:         deviceType,
				Version:            version,
				ModTime:            fileInfo.ModTime().String(),
				FileKey:            "",
				IsLatest:           false,
				DownloadStatus:     int32(downloadStatus),
				Permil:             permil,
				UpgradeInfo:        upgradeInfo,
				UpgradeInfoChinese: upgradeDescChinese,
				UpgradeInfoEnglish: upgradeDescEnglish,
				UpgradeInfoRussian: upgradeDescRussian,
			})
		}
	}
	return otaPkgList
}

// DelLocalOtaPkgInfo 根据本地目录获取升级包信息
func DelLocalOtaPkgInfo(filePath string, rsp []*client.OtaPkgInfo, devType int32) {
	exit, _ := PathOrFileExists(filePath)
	if !exit {
		return
	}
	files, err := os.ReadDir(filePath)
	if err != nil {
		logger.Errorf("GetLocalOtaPkgList read dir err：%v \n", err)
		return
	}
	logger.Info("rsp is %v:", rsp)
	for _, file := range files {
		logger.Info("file is :", file.Name())
		if !file.IsDir() && !strings.HasSuffix(file.Name(), ".json") {
			remove := true
			for _, info := range rsp {
				logger.Info("file key is :", info.FileKey)
				logger.Info("devType  is :", info.FileKey)
				logger.Info("info.DeviceType:", info.DeviceType)
				if devType == info.DeviceType && strings.Contains(info.FileKey, file.Name()) {
					remove = false
				}
			}
			if remove {
				err := os.Remove(filepath.Join(filePath, file.Name()))
				if err != nil {
					logger.Errorf("delte file err：%v\n", err)
				} else {
					logger.Infof("delete file suc：%s\n", file.Name())
				}
			}
		}
	}
}
func GetLocalTracerJson(path string, deviceType int32) (*TracerUpgradeInfo, error) {
	rspList := &TracerUpgradeInfo{}
	rspListInfo := make([]TracerUpgradeList, 0)

	rspTracerP, err := GetLocalUpgradeInfo(DeviceTypeTracerP, path)
	if err != nil {
		logger.Error("GetUpgradeInfo tracerP err:", err)
	}
	if rspTracerP != nil {
		for _, listP := range rspTracerP.List {
			rspListInfo = append(rspListInfo, listP)
		}
	}
	rspTracerS, err := GetLocalUpgradeInfo(DeviceTypeTracerS, path)
	if err != nil {
		logger.Error("GetUpgradeInfo tracerS err:", err)
	}
	if rspTracerS != nil {
		for _, listS := range rspTracerS.List {
			rspListInfo = append(rspListInfo, listS)
		}
	}
	rspList.List = rspListInfo
	logger.Info("Rsp info is :", rspList.List)
	return rspList, nil
}

func GetLocalUpgradeInfo(deviceType int32, path string) (*TracerUpgradeInfo, error) {
	result := &TracerUpgradeInfo{}
	filePath := LocalOtaPkgPathMap[deviceType]
	if filePath == "" {
		return nil, errors.New("file path is err")
	}
	path = filepath.Join(path, filePath)
	filename := ""

	if deviceType == DeviceTypeTracerS {
		filename = "tracerS.json"
	}
	if deviceType == DeviceTypeTracerP {
		filename = "tracerP.json"
	}
	fileContent, err := ioutil.ReadFile(filepath.Join(path, filename))
	if err != nil {
		logger.Error("Read file err：%v\n", err)
		return nil, errors.New("Read file err")
	}
	// 解析JSON数据
	data := make([]TracerUpgradeList, 0)
	err = json.Unmarshal(fileContent, &data)
	if err != nil {
		logger.Error("Unmarshal json err：%v\n", err)
		return nil, errors.New("Unmarshal json err")
	}
	// 打印解析结果
	for _, item := range data {
		data = append(data, TracerUpgradeList{
			Version:            item.Version,
			UpgradeDesc:        item.UpgradeDesc,
			UpgradeDescChinese: item.UpgradeDescChinese,
			UpgradeDescEnglish: item.UpgradeDescEnglish,
			UpgradeDescRussian: item.UpgradeDescRussian,
		})
	}
	result.List = data
	return result, nil
}

// CheckVersionExist 查询版本是否存在本地
func CheckVersionExist(filePath string, version string) bool {
	exit, _ := PathOrFileExists(filePath)
	if !exit {
		return false
	}
	files, err := os.ReadDir(filePath)
	if err != nil {
		logger.Errorf("GetLocalOtaPkgList 读取目录错误：%v \n", err)
		return false
	}
	for _, file := range files {
		if !file.IsDir() {
			fileFallName := file.Name()
			start := strings.Index(fileFallName, version)
			if start > 0 {
				return true
			}
		}
	}
	return false
}

// CacheLocal 将数据缓存到本地
func CacheLocal(data interface{}, path, fileName string) {
	marshalData, err := json.MarshalIndent(data, "", "\t")
	filePath := filepath.Join(DefaultOtaPkgPath, path)
	if err := os.MkdirAll(filePath, 0666); err != nil {
		logger.Errorf("CacheLocal failed to os.Create, %v \n", err)
		return
	}
	f, err := os.Create(filepath.Join(filePath, fileName))
	if err != nil {
		logger.Errorf("CacheLocal err: %v \n", err)
		return
	}
	defer f.Close()
	_, _ = f.Write(marshalData)
}

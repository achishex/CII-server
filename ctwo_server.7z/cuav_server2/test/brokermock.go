// Package test

package test

import "go-micro.dev/v4/broker"

type MockBroker struct{}

func (m *MockBroker) Address() string             { return "" }
func (m *MockBroker) Connect() error              { return nil }
func (m *MockBroker) Disconnect() error           { return nil }
func (m *MockBroker) Init(...broker.Option) error { return nil }
func (m *MockBroker) Options() broker.Options     { return broker.Options{} }
func (m *MockBroker) Publish(topic string, msg *broker.Message, opts ...broker.PublishOption) error {
	return nil
}
func (m *MockBroker) String() string { return "" }
func (m *MockBroker) Subscribe(topic string, handler broker.Handler, opts ...broker.SubscribeOption) (broker.Subscriber, error) {
	return nil, nil
}

package clientdata

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/rpc/webclient"
	jsoniter "github.com/json-iterator/go"
	"go-micro.dev/v4/broker"
	"google.golang.org/protobuf/proto"
)

// reportSpooferStatus ...
func reportSpooferStatus(event broker.Event) error {
	box := &common.EquipmentMessageBoxEntity{}
	err := jsoniter.Unmarshal(event.Message().Body, box)
	if err != nil {
		logger.Error("NSF4000 Induce box unmarshal error: ", err)
		return err
	}
	d, err := jsoniter.Marshal(box.Info)
	if err != nil {
		logger.Error("NSF4000 Induce remarshal error: ", err)
		return err
	}
	report := &handler.NSF4000Msg{}
	err = jsoniter.Unmarshal(d, report)
	if err != nil {
		logger.Error("NSF4000InduceReport unmarshal error: ", err)
		return err
	}
	buData, err := proto.Marshal(&client.SpooferStatusInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Sn:        box.Sn,
			Name:      box.Name,
			EquipType: int32(box.EquipType),
			MsgType:   GetClientMsgID(common.DeviceType(box.EquipType), int32(box.MsgType)),
		},
		Data: &client.SpooferStatus{
			IsOnline:    int32(report.IsOnline),
			IsWorking:   int32(report.IsWorking),
			GpsStatus:   int32(report.GpsStatus),
			Ephemeris:   int32(report.Ephemeris),
			TimeSync:    int32(report.TimeSync),
			Longititude: report.Longititude,
			Latitude:    report.Latitude,
			Height:      report.Height,
			Enable:      report.Enable,
			WorkMode:    report.WorkMode,
			Radius:      report.Radius,
			Angle:       report.Angle,
			OpsTime:     report.OpsTime,
		},
	})
	if err != nil {
		logger.Errorf("Marshal SpooferStatusInfo err %v", err)
		return err
	}
	out := &client.ClientReport{
		MsgType: GetClientMsgID(common.DeviceType(box.EquipType), int32(box.MsgType)),
		Data:    buData,
	}
	data, err := proto.Marshal(out)
	if err != nil {
		logger.Errorf("ClientReport Marshal err %v", err)
		return err
	}
	if err := webclient.ClientMgrInstance().SendData(data); err != nil {
		logger.Errorf("topic %s SendData err %v", event.Topic(), err)
		return err
	}
	return nil
}

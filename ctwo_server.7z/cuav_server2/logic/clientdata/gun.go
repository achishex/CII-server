package clientdata

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/proto/mavlink"
	jsoniter "github.com/json-iterator/go"
	"google.golang.org/protobuf/proto"
)

// convertHitResult ...
func convertHitResult(head *client.EquipmentMessageBoxEntity, in []byte) ([]byte, error) {
	status := &common.ScreenHitStatusEntity{}
	err := jsoniter.Unmarshal(in, status)
	if err != nil {
		logger.Error("hit unmarshal error: ", err)
		return nil, err
	}
	buData := &client.ScreenHitStatusInfo{
		Header: head,
		Data: &client.ScreenHitStatusEntity{
			WorkStatus: uint32(status.WorkStatus),
			DroneNum:   uint32(status.DroneNum),
			Uavs:       make([]*client.HitUavEntity, len(status.Uavs)),
		},
	}
	for _, uav := range status.Uavs {
		hitUav := &client.HitUavEntity{
			ProductType:    uint32(uav.ProductType),
			DroneName:      uav.DroneName,
			DroneLongitude: uav.DroneLongitude,
			DroneLatitude:  uav.DroneLatitude,
			DroneHeight:    int32(uav.DroneHeight),
			SerialNum:      uav.SerialNum,
			ObjId:          uint32(uav.ObjId),
		}
		buData.Data.Uavs = append(buData.Data.Uavs, hitUav)
	}
	buBuff, err := proto.Marshal(buData)
	if err != nil {
		logger.Errorf("Marshal ScreenHitStatusInfo err %v", err)
		return nil, err
	}
	out := &client.ClientReport{
		MsgType: head.MsgType,
		Data:    buBuff,
	}
	data, err := proto.Marshal(out)
	if err != nil {
		logger.Errorf("ClientReport Marshal err %v", err)
		return nil, err
	}
	return data, nil
}

// convertScreenHitResult ...
func convertScreenHitResult(head *client.EquipmentMessageBoxEntity, in []byte) ([]byte, error) {
	results := []*mavlink.HitResult{}
	err := jsoniter.Unmarshal(in, results)
	if err != nil {
		logger.Error("hit result unmarshal error: ", err)
		return nil, err
	}
	buData := &client.ScreenHitResultInfo{
		Header: head,
		Data:   make([]*client.HitResult, len(results)),
	}
	for _, result := range results {
		hitResult := &client.HitResult{
			ObjId:  uint32(result.ObjId),
			Result: uint32(result.Result),
		}
		buData.Data = append(buData.Data, hitResult)
	}
	buBuff, err := proto.Marshal(buData)
	if err != nil {
		logger.Errorf("Marshal ScreenHitResultInfo err %v", err)
		return nil, err
	}
	out := &client.ClientReport{
		MsgType: head.MsgType,
		Data:    buBuff,
	}
	data, err := proto.Marshal(out)
	if err != nil {
		logger.Errorf("ClientReport Marshal err %v", err)
		return nil, err
	}
	return data, nil
}

package clientdata

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/rpc/webclient"
	jsoniter "github.com/json-iterator/go"
	"go-micro.dev/v4/broker"
	"google.golang.org/protobuf/proto"
)

// reportRadarPosture ...
func reportRadarPosture(event broker.Event) error {
	box := &common.EquipmentMessageBoxEntity{}
	err := jsoniter.Unmarshal(event.Message().Body, box)
	if err != nil {
		logger.Error("radar posture box unmarshal error: ", err)
		return err
	}
	d, err := jsoniter.Marshal(box.Info)
	if err != nil {
		logger.Error("radar posture remarshal error: ", err)
		return err
	}
	posture := &common.RadarUploadPostureEntity{}
	err = jsoniter.Unmarshal(d, posture)
	if err != nil {
		logger.Error("radar posture unmarshal error: ", err)
		return err
	}
	buData, err := proto.Marshal(&client.RadarPosture{
		Header: &client.EquipmentMessageBoxEntity{
			Sn:        box.Sn,
			Name:      box.Name,
			EquipType: int32(box.EquipType),
			MsgType:   GetClientMsgID(common.DeviceType(box.EquipType), int32(box.MsgType)),
		},
		Data: &client.RadarUploadPostureEntity{
			Heading:             posture.Heading,
			Pitching:            posture.Pitching,
			Rolling:             posture.Rolling,
			Longitude:           posture.Longitude,
			Latitude:            posture.Latitude,
			Altitude:            posture.Altitude,
			VelocityNavi:        posture.VelocityNavi,
			SigProcRelativeTime: posture.SigProcRelativeTime,
		},
	})
	if err != nil {
		logger.Errorf("Marshal RadarPosture err %v", err)
		return err
	}
	out := &client.ClientReport{
		MsgType: GetClientMsgID(common.DeviceType(box.EquipType), int32(box.MsgType)),
		Data:    buData,
	}
	data, err := proto.Marshal(out)
	if err != nil {
		logger.Errorf("ClientReport Marshal err %v", err)
		return err
	}
	if err := webclient.ClientMgrInstance().SendData(data); err != nil {
		logger.Errorf("topic %s SendData err %v", event.Topic(), err)
		return err
	}
	return nil
}

// reportRadarTrack ...
func reportRadarTrack(event broker.Event) error {
	box := &common.EquipmentMessageBoxEntity{}
	err := jsoniter.Unmarshal(event.Message().Body, box)
	if err != nil {
		logger.Error("radar track data box unmarshal error: ", err)
		return err
	}
	d, err := jsoniter.Marshal(box.Info)
	if err != nil {
		logger.Error("radar track data remarshal error: ", err)
		return err
	}
	radarTracks := []*common.DbRawAutelRadarPlotTrackBodyEntity{}
	err = jsoniter.Unmarshal(d, &radarTracks)
	if err != nil {
		logger.Error("radar track data unmarshal error: ", err)
		return err
	}
	buData := &client.RadarTrackInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Sn:        box.Sn,
			Name:      box.Name,
			EquipType: int32(box.EquipType),
			MsgType:   GetClientMsgID(common.DeviceType(box.EquipType), int32(box.MsgType)),
		},
		Data: make([]*client.DbRawAutelRadarPlotTrackBodyEntity, 0),
	}
	for _, track := range radarTracks {
		radarPlot := &client.DbRawAutelRadarPlotTrackBodyEntity{
			HeaderUid:        track.HeaderUid,
			Model:            track.Model,
			AbsVel:           track.Abs_vel,
			Alive:            uint32(track.Alive),
			Ambiguous:        int32(track.Ambiguous),
			AssocBit0:        track.Assoc_bit0,
			AssocBit1:        track.Assoc_bit1,
			AssociationNum:   int32(track.Association_num),
			Ax:               track.AX,
			AxVariance:       track.Ax_variance,
			Ay:               track.AY,
			AyVariance:       track.Ay_variance,
			Az:               track.AZ,
			Azimuth:          track.Azimuth,
			AzVariance:       track.Az_variance,
			ClassfyProb:      track.Classfy_prob,
			Classification:   int32(track.Classification),
			Crc:              uint32(track.Crc),
			CreateTime:       track.Create_time,
			DopplerChn:       int32(track.Doppler_chn),
			Elevation:        track.Elevation,
			ExistingProb:     track.ExistingProb,
			ForcastFrameNum:  int32(track.Forcast_frame_num),
			Frequency:        track.Frequency,
			IsWhitelist:      track.Is_whitelist,
			Level:            int32(track.Level),
			Mag:              track.Mag,
			MotionType:       int32(track.Motion_type),
			ObjId:            track.Obj_id,
			ObjDistInterpol:  track.Obj_dist_interpol,
			OrientationAngle: track.Orientation_angle,
			StateType:        int32(track.State_type),
			TwsTasFlag:       uint32(track.Tws_tas_flag),
			Velocity:         track.Velocity,
			Vendor:           track.Vendor,
			Vx:               track.VX,
			VxVariance:       track.Vx_variance,
			Vy:               track.VY,
			VyVariance:       track.Vy_variance,
			Vz:               track.VZ,
			VzVariance:       track.Vz_variance,
			X:                track.X,
			XVariance:        track.X_variance,
			Y:                track.Y,
			YVariance:        track.Y_variance,
			Z:                track.Z,
			ZVariance:        track.Z_variance,
		}
		buData.Data = append(buData.Data, radarPlot)
	}
	buBuff, err := proto.Marshal(buData)
	if err != nil {
		logger.Errorf("Marshal RadarTrackInfo err %v", err)
		return err
	}
	out := &client.ClientReport{
		MsgType: GetClientMsgID(common.DeviceType(box.EquipType), int32(box.MsgType)),
		Data:    buBuff,
	}
	data, err := proto.Marshal(out)
	if err != nil {
		logger.Errorf("ClientReport Marshal err %v", err)
		return err
	}
	if err := webclient.ClientMgrInstance().SendData(data); err != nil {
		logger.Errorf("topic %s SendData err %v", event.Topic(), err)
		return err
	}
	return nil
}

// convertRadarPosture ...
func convertRadarPosture(head *client.EquipmentMessageBoxEntity, in []byte) ([]byte, error) {
	posture := &common.RadarUploadPostureEntity{}
	err := jsoniter.Unmarshal(in, posture)
	if err != nil {
		logger.Error("radar posture cali unmarshal error: ", err)
		return nil, err
	}
	buData, err := proto.Marshal(&client.RadarPosture{
		Header: head,
		Data: &client.RadarUploadPostureEntity{
			Heading:             posture.Heading,
			Pitching:            posture.Pitching,
			Rolling:             posture.Rolling,
			Longitude:           posture.Longitude,
			Latitude:            posture.Latitude,
			Altitude:            posture.Altitude,
			VelocityNavi:        posture.VelocityNavi,
			SigProcRelativeTime: posture.SigProcRelativeTime,
		},
	})
	if err != nil {
		logger.Errorf("Marshal RadarPosture err %v", err)
		return nil, err
	}
	out := &client.ClientReport{
		MsgType: head.MsgType,
		Data:    buData,
	}
	data, err := proto.Marshal(out)
	if err != nil {
		logger.Errorf("ClientReport Marshal err %v", err)
		return nil, err
	}
	return data, nil
}

// converRadarConn ...
func converRadarConn(head *client.EquipmentMessageBoxEntity, in []byte) ([]byte, error) {
	radar := &client.SetRadarConnReq{}
	err := jsoniter.Unmarshal(in, radar)
	if err != nil {
		logger.Error("conn unmarshal error: ", err)
		return nil, err
	}
	buData, err := proto.Marshal(&client.SetRadarConnReqInfo{
		Header: head,
		Data:   radar,
	})
	if err != nil {
		logger.Errorf("Marshal SetRadarConnReqInfo err %v", err)
		return nil, err
	}
	out := &client.ClientReport{
		MsgType: head.MsgType,
		Data:    buData,
	}
	data, err := proto.Marshal(out)
	if err != nil {
		logger.Errorf("SetRadarConnReqInfo Marshal err %v", err)
		return nil, err
	}
	return data, nil
}

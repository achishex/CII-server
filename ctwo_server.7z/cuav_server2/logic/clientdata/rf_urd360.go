package clientdata

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/rpc/webclient"
	jsoniter "github.com/json-iterator/go"
	"go-micro.dev/v4/broker"
	"google.golang.org/protobuf/proto"
)

// reportRFURD360Status ...
func reportRFURD360Status(event broker.Event) error {
	box := &common.EquipmentMessageBoxEntity{}
	err := jsoniter.Unmarshal(event.Message().Body, box)
	if err != nil {
		logger.Error("urd360 status box unmarshal error: ", err)
		return err
	}
	d, err := jsoniter.Marshal(box.Info)
	if err != nil {
		logger.Error("urd360 status remarshal error: ", err)
		return err
	}

	deviceInfo := &handler.UrdDeviceInfoUpload{}
	err = jsoniter.Unmarshal(d, deviceInfo)
	if err != nil {
		logger.Error("urd360 status unmarshal error: ", err)
		return err
	}
	buData, err := proto.Marshal(&client.UrdDeviceInfoUpload{
		Header: &client.EquipmentMessageBoxEntity{
			Sn:        box.Sn,
			Name:      box.Name,
			MsgType:   GetClientMsgID(common.DeviceType(box.EquipType), int32(box.MsgType)),
			EquipType: int32(box.EquipType),
		},
		Data: &client.UrdDeviceInfo{
			Id:                deviceInfo.Id,
			Name:              deviceInfo.Name,
			Longitude:         deviceInfo.Longitude,
			Latitude:          deviceInfo.Latitude,
			Height:            deviceInfo.Height,
			Status:            int32(deviceInfo.Status),
			Azimuth:           deviceInfo.Azimuth,
			Type:              deviceInfo.Type,
			CompassStatus:     int32(deviceInfo.CompassStatus),
			GpsStatus:         int32(deviceInfo.GpsStatus),
			ReceiverStatus:    int32(deviceInfo.ReceiverStatus),
			AntennaStatus:     int32(deviceInfo.AntennaStatus),
			AntennaCoverRange: deviceInfo.AntennaCoverRange,
		},
	})
	if err != nil {
		logger.Errorf("Marshal UrdDeviceInfoUpload err %v", err)
		return err
	}
	out := &client.ClientReport{
		MsgType: GetClientMsgID(common.DeviceType(box.EquipType), int32(box.MsgType)),
		Data:    buData,
	}
	data, err := proto.Marshal(out)
	if err != nil {
		logger.Errorf("ClientReport Marshal err %v", err)
		return err
	}
	if err := webclient.ClientMgrInstance().SendData(data); err != nil {
		logger.Errorf("topic %s SendData err %v", event.Topic(), err)
		return err
	}
	return nil
}

// reportRFURD360Specturm ...
func reportRFURD360Specturm(event broker.Event) error {
	box := &common.EquipmentMessageBoxEntity{}
	err := jsoniter.Unmarshal(event.Message().Body, box)
	if err != nil {
		logger.Error("urd360 spectrum data box unmarshal error: ", err)
		return err
	}
	d, err := jsoniter.Marshal(box.Info)
	if err != nil {
		logger.Error("urd360 spectrum data remarshal error: ", err)
		return err
	}

	report := &handler.UrdSpectrumReport{}
	err = jsoniter.Unmarshal(d, report)
	if err != nil {
		logger.Error("urd360 spectrum data unmarshal error: ", err)
		return err
	}
	buData, err := proto.Marshal(&client.UrdSpectrumInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Sn:        box.Sn,
			Name:      box.Name,
			MsgType:   GetClientMsgID(common.DeviceType(box.EquipType), int32(box.MsgType)),
			EquipType: int32(box.EquipType),
		},
		X: report.X,
		Y: report.Y,
	})
	if err != nil {
		logger.Errorf("Marshal UrdSpectrumInfo err %v", err)
		return err
	}
	out := &client.ClientReport{
		MsgType: GetClientMsgID(common.DeviceType(box.EquipType), int32(box.MsgType)),
		Data:    buData,
	}
	data, err := proto.Marshal(out)
	if err != nil {
		logger.Errorf("ClientReport Marshal err %v", err)
		return err
	}
	if err := webclient.ClientMgrInstance().SendData(data); err != nil {
		logger.Errorf("topic %s SendData err %v", event.Topic(), err)
		return err
	}
	return nil
}

// reportRFURD360DroneInfo ...
func reportRFURD360DroneInfo(event broker.Event) error {
	box := &common.EquipmentMessageBoxEntity{}
	err := jsoniter.Unmarshal(event.Message().Body, box)
	if err != nil {
		logger.Error("urd360 drone info box unmarshal error: ", err)
		return err
	}
	d, err := jsoniter.Marshal(box.Info)
	if err != nil {
		logger.Error("urd360 drone info remarshal error: ", err)
		return err
	}
	info := &handler.UrdDroneInfoUpload{}
	err = jsoniter.Unmarshal(d, info)
	if err != nil {
		logger.Error("urd360 drone info unmarshal error: ", err)
		return err
	}
	buData, err := proto.Marshal(&client.UrdDroneInfoUpload{
		Header: &client.EquipmentMessageBoxEntity{
			Sn:        box.Sn,
			Name:      box.Name,
			MsgType:   GetClientMsgID(common.DeviceType(box.EquipType), int32(box.MsgType)),
			EquipType: int32(box.EquipType),
		},
		Data: &client.UrdDroneInfo{
			Id:               info.Id,
			UniqueId:         info.UniqueId,
			TargetInfoLength: info.TargetInfoLength,
			TargetInfo:       info.TargetInfo,
			StationId:        info.StationId,
			TargetAzimuth:    info.TargetAzimuth,
			TargetRange:      info.TargetRange,
			Longitude:        info.Longitude,
			Latitude:         info.Latitude,
			Height:           info.Height,
			Frequency:        info.Frequency,
			Bandwidth:        info.Bandwidth,
			SignalStrength:   info.SignalStrength,
			Trust:            int32(info.Trust),
			Time:             info.Time,
			DataType:         int32(info.DataType),
			Modulation:       int32(info.Modulation),
		},
	})
	if err != nil {
		logger.Errorf("Marshal UrdDroneInfoUpload err %v", err)
		return err
	}
	out := &client.ClientReport{
		MsgType: GetClientMsgID(common.DeviceType(box.EquipType), int32(box.MsgType)),
		Data:    buData,
	}
	data, err := proto.Marshal(out)
	if err != nil {
		logger.Errorf("RadarPosture Marshal err %v", err)
		return err
	}
	if err := webclient.ClientMgrInstance().SendData(data); err != nil {
		logger.Errorf("topic %s SendData err %v", event.Topic(), err)
		return err
	}
	return nil
}

package udp

var (
	UDPHandler *Adaptor
)

// 包命令字长度
const (
	//旋转
	DirectionCmd uint32 = 0x0D
	//光电镜头控制缩放操作
	ZoomCmd uint32 = 0x09
)

// 光电编号
const (
	devSunElecCode uint32 = 0
)

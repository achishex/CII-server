package down

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/logic/uploadcloud/mqtt"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
)

// opsCode define
const (
	opsGetVer       = 1 //预留，暂时未用到
	opsStopHit      = 2
	opsSetHit       = 3
	opsShutdown     = 4
	opsReset        = 5
	opsFindMsg      = 6
	opsExportMsg    = 7
	opsHitUav       = 8
	opsGetDevStatus = 9
	opsSflGetPower  = 10
	opsSetAutoHit   = 11
	opsGetAutoHit   = 12
)

func sflPropertyTopicName() string {
	return propertySubTopic(common.Sfl)
}

func sflSvcTopicName() string {
	return svcSubTopic(common.Sfl)
}

func getVersion(req *client.SflGetVersionRequest, rsp *client.SflGetVersionResponse) error {
	dev := handler.FindCacheDevice(req.Sn, common.DEV_SFL)
	logger.Debug("sn = ", req.Sn)
	if dev == nil {
		logger.Debug("sfl offline ")
		return errors.New("设备未在线")
	}

	d := &handler.Sfl{Device: dev}
	version, err := d.SendGetVersionInfo()
	if err != nil {
		return err
	}

	rsp.Sn = req.Sn
	rsp.Version = version
	return nil
}

func errorMsg(errorCode, opsCode int32, tid, bid, sn, errorMsg string) mqttPubMsg {
	msg := mqttPubMsg{
		Tid: tid,
		Bid: bid,
		Sn:  sn,
		MsgData: msgpubData{
			Result: result{
				ErrorCode: errorCode,
				ErrorMsg:  errorMsg,
			},
			Data: data{
				OpsCode: opsCode,
			},
		},
		Timestamp: time.Now().UnixMilli(),
	}
	logger.Debug("msg = ", msg)
	return msg
}

type version struct {
	Sn      string `json:"sn"`
	Version string `json:"version"`
}

func successfulMsg(errorCode, opsCode int32, tid, bid, sn, errorMsg string, payload interface{}) mqttPubMsg {
	return mqttPubMsg{
		Tid: tid,
		Bid: bid,
		Sn:  sn,
		MsgData: msgpubData{
			Result: result{
				ErrorCode: errorCode,
				ErrorMsg:  errorMsg,
			},
			Data: data{
				OpsCode: opsCode,
				Payload: payload,
			},
		},
		Timestamp: time.Now().UnixMilli(),
	}
}

// func sflGetStatus(req *client.SflGetStatusRequest, rsp *client.SflGetStatusResponse) error {
// 	dev := handler.FindCacheDevice(req.Sn, common.DEV_SFL)
// 	logger.Debug("dev = ", dev)
// 	if dev == nil {
// 		return errors.New("设备未在线")
// 	}

// 	d := &handler.Sfl{Device: dev}

// 	result, err := d.SendSflGetStatus()
// 	logger.Debug("result = ", result)
// 	logger.Debug("err = ", err)
// 	if err != nil {
// 		return err
// 	}
// 	rsp.Sn = req.Sn
// 	rsp.HitAngleEnd = result.HitAngleEnd
// 	rsp.HitAngleBegin = result.HitAngleBegin
// 	rsp.HitMode = result.HitMode
// 	rsp.HitPitch1 = result.HitPitch1
// 	rsp.HitPitch2 = result.HitPitch2
// 	rsp.HitTime = result.HitTime

// 	return nil
// }

func doSflLogic(m mqtt.Message) []byte {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	logger.Debug("m = ", m.Payload())
	p, err := decodeMessage(m.Payload())
	//json Marshal or UnMarshal error
	errJSONTypeMsg := errorMsg(jsonFail, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, jsonFailMsg)
	logger.Error("errMsg = ", errJSONTypeMsg)
	if err != nil {
		logger.Error("decodeMessage error = ", err)
		return encodeMessage(errJSONTypeMsg)
	}
	encodeOkmsg := make([]byte, 0)
	logger.Debug("p.MsgData.Data.OpsCode = ", p.MsgData.Data.OpsCode)
	switch p.MsgData.Data.OpsCode {
	case opsStopHit:
		req := &client.SflStopHitRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.SflStopHitResponse{}

		err = handler.NewDeviceCenter().SflStopHitSet(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg
		}
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		encodeOkmsg = encodeMessage(smsg)
	case opsSetHit:
		req := &client.SflHitAngleRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.SflHitAngleResponse{}

		err = handler.NewDeviceCenter().SflHitAngleSet(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg
		}
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		encodeOkmsg = encodeMessage(smsg)
	case opsShutdown:
		req := &client.SflOnOffRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.SflOnOffResponse{}

		err = handler.NewDeviceCenter().SflOnOffSet(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg
		}
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		encodeOkmsg = encodeMessage(smsg)
	case opsReset:
		req := &client.SflResetRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.SflResetResponse{}

		err = handler.NewDeviceCenter().SflReSet(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg
		}
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		encodeOkmsg = encodeMessage(smsg)
	case opsFindMsg:
		req := &client.SflDetectInfoRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.SflDetectInfoResponse{}

		err = handler.NewDeviceCenter().SflDetectInfo(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg
		}
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		encodeOkmsg = encodeMessage(smsg)
	case opsExportMsg:
		req := &client.SflDetectInfoExportRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.SflDetectInfoExportResponse{}

		err = handler.NewDeviceCenter().SflDetectInfoExport(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg
		}
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		encodeOkmsg = encodeMessage(smsg)
	case opsHitUav:
		req := &client.SflSendHitUavRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.SflSendHitUavResponse{}

		err = handler.NewDeviceCenter().SflSendHitUav(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg
		}
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		encodeOkmsg = encodeMessage(smsg)
	case opsGetDevStatus:
		req := &client.SflGetStatusRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.SflGetStatusResponse{}

		err = handler.NewDeviceCenter().SflGetStatus(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg
		}
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		encodeOkmsg = encodeMessage(smsg)
	case opsSflGetPower:
		req := &client.SflGetPowerRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.SflGetPowerResponse{}

		err = handler.NewDeviceCenter().SflGetPower(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg
		}
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		encodeOkmsg = encodeMessage(smsg)
	case opsSetAutoHit:
		req := &client.SflSetHitModeRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.SflSetHitModeResponse{}

		err = handler.NewDeviceCenter().SflSetHitMode(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg
		}
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		encodeOkmsg = encodeMessage(smsg)
	case opsGetAutoHit:
		req := &client.SflGetHitModeRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.SflGetHitModeResponse{}

		err = handler.NewDeviceCenter().SflGetHitMode(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg
		}
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		encodeOkmsg = encodeMessage(smsg)

	default:
		unknownOps := errorMsg(unknowOpsCode, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, unknowOpsCodeMsg)
		return encodeMessage(unknownOps)
	}
	logger.Debug("encodeSmsg = ", encodeOkmsg)
	return encodeOkmsg
}

// func doSflLogic(m mqtt.Message) []byte {
// 	defer func() {
// 		if r := recover(); r != nil {
// 			err := fmt.Errorf("panic: %v", r)
// 			logger.Error("panic:", err)
// 		}
// 	}()
// 	logger.Debug("m = ", m.Payload())
// 	p, err := decodeMessage(m.Payload())
// 	if err != nil {
// 		logger.Error("decodeMessage error = ", err)
// 		errMsg := errorMsg(fail, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, jsonFailMsg)
// 		logger.Error("errMsg = ", errMsg)
// 		return encodeMessage(errMsg)
// 	}
// 	logger.Debug("p.MsgData.Data.OpsCode = ", p.MsgData.Data.OpsCode)
// 	switch p.MsgData.Data.OpsCode {
// 	case 1:
// 		req := &client.SflGetVersionRequest{
// 			Sn: p.Sn,
// 		}
// 		resp := &client.SflGetVersionResponse{}

// 		err := getVersion(req, resp)
// 		logger.Debug("resp = ", resp)
// 		if err != nil {
// 			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
// 			logger.Debug("errMsg = ", errMsg)
// 			encodeMsg := encodeMessage(errMsg)
// 			logger.Debug("result = ", errMsg.MsgData.Result)
// 			logger.Debug("encodeMsg = ", encodeMsg)

// 			var msg mqttPubMsg
// 			json.Unmarshal(encodeMsg, &msg)
// 			logger.Debug("msg = ", msg)
// 			logger.Debug("OpsCode = ", msg.MsgData.Data.OpsCode)
// 			logger.Debug("Result = ", msg.MsgData.Result)

// 			return encodeMsg
// 		}
// 		pload := version{
// 			Sn:      p.Sn,
// 			Version: resp.Version,
// 		}
// 		bpload, err := json.Marshal(pload)
// 		if err != nil {
// 			logger.Error("josn marshal error", err)
// 		}
// 		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, bpload)
// 		encodeSmsg := encodeMessage(smsg)
// 		logger.Debug("encodeSmsg = ", encodeSmsg)
// 		return encodeSmsg
// 	case 9:
// 		req := &client.SflGetStatusRequest{}
// 		var payloadByte []byte
// 		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
// 		if err != nil {
// 			logger.Error("josn marshal error", err)
// 		}
// 		err = json.Unmarshal(payloadByte, req)
// 		if err != nil {
// 			logger.Error("josn Unmarshal error", err)
// 		}

// 		resp := &client.SflGetStatusResponse{}

// 		err = sflGetStatus(req, resp)
// 		logger.Debug("resp = ", resp)
// 		if err != nil {
// 			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
// 			logger.Debug("errMsg = ", errMsg)
// 			encodeMsg := encodeMessage(errMsg)
// 			logger.Debug("result = ", errMsg.MsgData.Result)
// 			logger.Debug("encodeMsg = ", encodeMsg)

// 			var msg mqttPubMsg
// 			json.Unmarshal(encodeMsg, &msg)
// 			logger.Debug("msg = ", msg)
// 			logger.Debug("OpsCode = ", msg.MsgData.Data.OpsCode)
// 			logger.Debug("Result = ", msg.MsgData.Result)

// 			return encodeMsg
// 		}
// 		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
// 		encodeSmsg := encodeMessage(smsg)
// 		logger.Debug("encodeSmsg = ", encodeSmsg)
// 		return encodeSmsg

// 	}

// 	return m.Payload()
// }

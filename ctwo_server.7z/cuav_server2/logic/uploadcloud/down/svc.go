package down

import (
	"encoding/json"
	"fmt"
	"strings"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/logic/uploadcloud/mqtt"
	"adasgitlab.autel.com/tools/cuav_server/logic/uploadcloud/udp"
)

var gC2sn = ""

const (
	success          = 0
	offline          = 70001
	deviceError      = 70002
	unknowOpsCode    = 70003
	jsonFail         = 70004
	jsonFailMsg      = "request param invalid"
	unknowOpsCodeMsg = "unknow opsCode"
	successMsg       = "operation successful"
	offlineMsg       = "device offline"
)

func propertySubTopic(deviceName string) string {
	topic := fmt.Sprintf("/mqtt/v1/cloud/%s/%s/property/set", deviceName, gC2sn)
	logger.Debug("topic = ", topic)
	return topic
}

func svcSubTopic(deviceName string) string {
	topic := fmt.Sprintf("/mqtt/v1/cloud/%s/%s/services/get", deviceName, gC2sn)
	logger.Debug("topic = ", topic)
	return topic
}

const (
	pingTopic = "/ping"
)

func ping(m mqtt.Message) []byte {
	// logger.Debug("m = ", m.Payload())
	p, _ := decodeMessage(m.Payload())
	// logger.Debug(p)
	// logger.Debug("sub ping message timestamp = ", p.Timestamp)
	curtime := time.Now().UnixMilli()
	gapTime := (curtime - p.Timestamp) / 1000
	// logger.Debug("gap time = ", gapTime)
	if gapTime > 1 {
		logger.Debug("bad network  = ", gapTime)
	}
	return m.Payload()
}

// RegisterSubHandlers ...
func RegisterSubHandlers(adaptor *mqtt.Adaptor) {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	if adaptor == nil {
		return
	}
	consumes := []mqtt.DoRoute{
		{
			Topic:   pingTopic,
			Handler: ping,
		},
		{
			Topic:   sflSvcTopicName(),
			Handler: doSflLogic,
		},
		{
			Topic:   sflPropertyTopicName(),
			Handler: doSflLogic,
		},
		{
			Topic:   agxSvcTopicName(),
			Handler: doAgxLogic,
		},
		{
			Topic:   agxPropertyTopicName(),
			Handler: doAgxLogic,
		},
		{
			Topic:   tracerPSvcTopicName(),
			Handler: doTracerPLogic,
		},
		{
			Topic:   tracerPPropertyTopicName(),
			Handler: doTracerPLogic,
		},
		{
			Topic:   nsf400PSvcTopicName(),
			Handler: donsf400Logic,
		},
		{
			Topic:   nsf400PropertyTopicName(),
			Handler: donsf400Logic,
		},
		{
			Topic:   urd360PSvcTopicName(),
			Handler: doUrd360Logic,
		},
		{
			Topic:   urd360PropertyTopicName(),
			Handler: doUrd360Logic,
		},
	}
	adaptor.AddSubHandlers(consumes)
}

// MqttLoginConfig ...
type MqttLoginConfig struct {
	URL      string
	ClientID string
	Account  string
	Passwd   string
	C2sn     string
}

type data struct {
	OpsCode int32       `json:"opsCode"`
	Payload interface{} `json:"payload"`
}

type msgSubData struct {
	Data data `json:"data"`
}

type result struct {
	ErrorCode int32  `json:"errorCode"`
	ErrorMsg  string `json:"errorMsg"`
}

type msgpubData struct {
	Data   data   `json:"data"`
	Result result `json:"result"`
}

type mqttSubMsg struct {
	Tid       string     `json:"tid"`
	Bid       string     `json:"bid"`
	Sn        string     `json:"sn"`
	MsgData   msgSubData `json:"msgData"`
	Timestamp int64      `json:"timestamp"`
}

type mqttPubMsg struct {
	Tid       string     `json:"tid"`
	Bid       string     `json:"bid"`
	Sn        string     `json:"sn"`
	MsgData   msgpubData `json:"msgData"`
	Timestamp int64      `json:"timestamp"`
}

func decodeMessage(payload []byte) (*mqttSubMsg, error) {
	message := new(mqttSubMsg)
	decoder := json.NewDecoder(strings.NewReader(string(payload)))
	if err := decoder.Decode(&message); err != nil {
		return nil, err
	}
	return message, nil
}

func encodeMessage(msg mqttPubMsg) []byte {
	bmsg, err := json.Marshal(msg)
	if err != nil {
		logger.Error("josn marshal error", err)
	}
	return bmsg
}

func MqttSvc(m MqttLoginConfig) {
	// s := mqtt.NewAdaptorWithAuth("tcp://localhost:1883", "client", "fzw", "12345678")
	logger.Debug("mqtt config :", m)
	s := mqtt.NewAdaptorWithAuth(m.URL, m.ClientID, m.Account, m.Passwd)
	gC2sn = m.C2sn
	logger.Debug("mqtt  = ", s)
	go MqttHandler(s)
}

func MqttHandler(s *mqtt.Adaptor) {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
			MqttHandler(s)
			time.Sleep(1 * time.Second)
		}
	}()
	logger.Debug("start connect mqtt broker")
	cRet := s.Connect()
	logger.Debug("cRet = ", cRet)
	s.SetQoS(1)
	go HandlerPub(s)
	RegisterSubHandlers(s)
	udp.UDPHandler = udp.NewUDPHandler()
}

func HandlerPub(s *mqtt.Adaptor) {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	ticker := time.NewTicker(1 * time.Second)
	for range ticker.C {
		nowtime := time.Now()

		msg := mqttPubMsg{
			Tid: "0xffff",
			Bid: "0xffff",
			Sn:  s.Name(),
			MsgData: msgpubData{
				Data: data{
					OpsCode: 0xff,
					Payload: nowtime.Format("2006-01-02 15:04:05"),
				},
				Result: result{
					ErrorCode: 0,
					ErrorMsg:  "ping message",
				},
			},
			Timestamp: nowtime.UnixMilli(),
		}
		// logger.Debug("pub ping message,timestamp:", msg.Timestamp)
		pubMsg := encodeMessage(msg)
		s.Publish(pingTopic, pubMsg)
	}
	// ticker := time.NewTicker(1 * time.Second)
	// done := make(chan bool)
	// go func() {
	// 	for {
	// 		select {
	// 		case <-done:
	// 			return
	// 		case <-ticker.C:
	// msg := "{\"msg\":\"mqtt ping msg, test network time. :" + nowtime + "\"}"
	// logger.Debug(msg)
	// 		}
	// 	}
	// }()
	// // time.Sleep(500000 * time.Second)
	// ticker.Stop()
	// done <- true
	// logger.Debug("stop publish")

}

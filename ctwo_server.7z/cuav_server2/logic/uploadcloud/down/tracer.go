package down

import (
	"context"
	"encoding/json"
	"fmt"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/logic/uploadcloud/mqtt"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
)

// opsCode define
const (
	opsTracerSetAlarm           = 1
	opsTracerSetHideMode        = 2
	opsTracerGetVersionInfo     = 3
	opsTracerGetInfo            = 4
	opsTracerGetWorkMode        = 5
	opsTracerSetOrientationMode = 6
)

func tracerPPropertyTopicName() string {
	return propertySubTopic(common.Drone)
}

func tracerPSvcTopicName() string {
	return svcSubTopic(common.Drone)
}

func doTracerPLogic(m mqtt.Message) []byte {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	logger.Debug("m = ", m.Payload())
	p, err := decodeMessage(m.Payload())
	//json Marshal or UnMarshal error
	errJSONTypeMsg := errorMsg(jsonFail, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, jsonFailMsg)
	logger.Error("errMsg = ", errJSONTypeMsg)
	if err != nil {
		logger.Error("decodeMessage error = ", err)
		return encodeMessage(errJSONTypeMsg)
	}
	encodeOkmsg := make([]byte, 0)
	logger.Debug("p.MsgData.Data.OpsCode = ", p.MsgData.Data.OpsCode)
	switch p.MsgData.Data.OpsCode {
	case opsTracerSetAlarm:
		req := &client.TracerSetAlarmRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.TracerSetAlarmResponse{}

		err = handler.NewDeviceCenter().TracerSetAlarm(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg
		}
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		encodeOkmsg = encodeMessage(smsg)
	case opsTracerSetHideMode:
		req := &client.TracerSetHideModeRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.TracerSetHideModeResponse{}

		err = handler.NewDeviceCenter().TracerSetHideMode(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg
		}
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		encodeOkmsg = encodeMessage(smsg)
	case opsTracerGetVersionInfo:
		req := &client.TracerGetVersionInfoRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.TracerGetVersionInfoResponse{}

		err = handler.NewDeviceCenter().TracerGetVersionInfo(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg
		}
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		encodeOkmsg = encodeMessage(smsg)
	case opsTracerGetInfo:
		req := &client.TracerGetInfoRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.TracerGetInfoResponse{}

		err = handler.NewDeviceCenter().TracerGetInfo(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg
		}
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		encodeOkmsg = encodeMessage(smsg)
	case opsTracerGetWorkMode:
		req := &client.TracerGetWorkModeRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.TracerGetWorkModeResponse{}

		err = handler.NewDeviceCenter().TracerGetWorkMode(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg
		}
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		encodeOkmsg = encodeMessage(smsg)
	case opsTracerSetOrientationMode:
		req := &client.TracerSetOrientationModeRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.TracerSetOrientationModeResponse{}

		err = handler.NewDeviceCenter().TracerSetOrientationMode(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg
		}
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		encodeOkmsg = encodeMessage(smsg)
	default:
		unknownOps := errorMsg(unknowOpsCode, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, unknowOpsCodeMsg)
		return encodeMessage(unknownOps)
	}
	logger.Debug("encodeSmsg = ", encodeOkmsg)
	return encodeOkmsg
}

package uploadcloud

import (
	"fmt"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/proto/cloudPlatform"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
	broker2 "go-micro.dev/v4/broker"
	"google.golang.org/protobuf/proto"
)

// ReportSfl 数据上报
func (c *CloudTcpCli) ReportSfl() {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	_, _ = mq.RadarPostureBroker.Subscribe(mq.SflTopic, func(event broker2.Event) error {
		entity := client.ClientReport{}
		err := proto.Unmarshal(event.Message().Body, &entity)
		if err != nil {
			return fmt.Errorf("report sfl proto Unmarshal error: %v", err)
		}
		MsgType := entity.MsgType
		info := entity.Data
		switch MsgType {
		case common.ClientMsgIDSFLHeartBeat:
			return c.ReportSflHeartBeat(info)
		case common.ClientMsgIDSFLDetect:
			return c.ReportSflDetection(info)
		case common.ClientMsgIDSFLHitStatus:
			return c.ReportSflSflHit(info)
		default:
			err := fmt.Errorf("unrecognized msg type: %v", MsgType)
			logger.Error(err)
			return err
		}
	})
}
func reverseOnline(in int32) int32 {
	if in == 0 {
		return 1
	} else {
		return 0
	}
}

// ReportSflHeartBeat 上报哨兵塔sfl心跳
func (c *CloudTcpCli) ReportSflHeartBeat(info []byte) error {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	hb := &client.SflHeartInfo{}
	err := proto.Unmarshal(info, hb)
	if err != nil {
		return fmt.Errorf("report sfl proto Unmarshal error: %v", err)
	}
	// hb := mavlink.SflHeartReport{}
	logger.Debug("start Unmarshal")

	// mu.Lock()
	// defer mu.Unlock()

	//给云端发送
	hbData := make([]*cloudPlatform.SflHeartData, 0)
	hbData = append(hbData, &cloudPlatform.SflHeartData{
		Sn:            hb.Header.Sn,
		CreateTime:    time.Now().UnixMilli(),
		WorkStatus:    hb.Data.WorkStatus,
		Online:        reverseOnline(hb.Data.IsOnline),
		DetectFreq:    hb.Data.DetectFreq,
		Elevation:     hb.Data.Elevation,
		GunDirection:  hb.Data.GunDirection,
		GunLongitude:  hb.Data.GunLongitude,
		GunLatitude:   hb.Data.GunLatitude,
		GunAltitude:   int32(hb.Data.GunAltitude),
		SatellitesNum: int32(hb.Data.SatellitesNum),
		FaultLevel:    int32(hb.Data.FaultLevel),
		CtrlFault:     int32(hb.Data.CtrlFault),
		AeagFault:     int32(hb.Data.AeagFault),
		TracerFault:   int32(hb.Data.TracerFault),
	})
	// logger.Debug("hb.Sn, = ", hb.Sn)
	logger.Debug("hbData = ", hbData)
	data := &cloudPlatform.SflHeartList{
		Body: hbData,
	}

	// encodedMessage
	encodedMessage, err := proto.Marshal(data)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return fmt.Errorf("Marshal encodedMessage error: %v", err)
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       SflHeartURL,
			Sn:        c.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   c.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return err
	}
	//对消息进行封装+head+crc
	sendMessage := createPacket(encodedMessage)
	// 发送TCP消息
	if c.Conn == nil || c.IsLogin == false {
		return nil
	}
	_, err = c.Conn.Write(sendMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return err
	}

	return nil
}

// ReportSflDetection sfl 侦测无人机信息
func (c *CloudTcpCli) ReportSflDetection(info []byte) error {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	oriData := client.SflDetectInfo{}
	err := proto.Unmarshal(info, &oriData)
	if err != nil {
		logger.Error("Protobuf 解码失败:", err)
		return err
	}
	// umData := client.GimbalCounterDetectSocketInfo{}
	// err := proto.Unmarshal(oriData.data, &umData
	umData := oriData.Data
	sn := oriData.Data.Sn
	droneList := umData.List
	//给云端发送侦测到的无人机小组
	dData := make([]*cloudPlatform.SflUavData, 0)
	for _, drone := range droneList {
		dData = append(dData, &cloudPlatform.SflUavData{
			ProductType:        drone.ProductType,
			DroneName:          drone.DroneName,
			SerialNum:          drone.SerialNum,
			DroneLongitude:     drone.DroneLongitude,
			DroneLatitude:      drone.DroneLatitude,
			DroneHeight:        drone.DroneHeight,
			DroneYawAngle:      drone.DroneYawAngle,
			DroneSpeed:         drone.DroneSpeed,
			DroneVerticalSpeed: drone.DroneVerticalSpeed,
			SpeedDirection:     drone.SpeedDirection,
			DroneSailLongitude: drone.DroneSailLongitude,
			DroneSailLatitude:  drone.DroneSailLatitude,
			PilotLongitude:     drone.PilotLongitude,
			PilotLatitude:      drone.PilotLatitude,
			DroneHorizon:       drone.DroneHorizon,
			DronePitch:         drone.DronePitch,
			UFreq:              drone.UFreq,
			UDistance:          drone.UDistance,
			UDangerLevels:      drone.UDangerLevels,
			Role:               drone.Role,
			Sn:                 sn,
			DetectionNum:       int32(umData.DetectionNum),
			CreateTime:         time.Now().UnixMilli(),
		})
	}
	Message := &cloudPlatform.SflUavList{
		Body: dData,
	}

	// encodedMessage
	encodedMessage, err := proto.Marshal(Message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return fmt.Errorf("Marshal encodedMessage error: %v", err)
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       SflUavURL,
			Sn:        c.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   c.LoginId,
		},
		Data: encodedMessage,
	}
	logger.Debug("<----->message = ", message)
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	logger.Debug("encodedMessage = ->", encodedMessage)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return err
	}
	//对消息进行封装+head+crc
	encodedMessage = createPacket(encodedMessage)
	// 发送TCP消息
	if c.Conn == nil || c.IsLogin == false {
		return nil
	}

	_, err = c.Conn.Write(encodedMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return err
	}

	return nil
}

// ReportSflSflHit sfl 侦测无人机信息
func (c *CloudTcpCli) ReportSflSflHit(info []byte) error {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()

	report := client.SflHitStateInfo{}
	err := proto.Unmarshal(info, &report)

	//给云端发送侦测到的无人机小组
	dData := make([]*cloudPlatform.SflHitData, 0)
	dData = append(dData, &cloudPlatform.SflHitData{
		Sn:                 report.Header.Sn,
		HitState:           int32(report.Data.HitState),
		ProductType:        int32(report.Data.ProductType),
		DroneName:          report.Data.DroneName[:],
		SerialNum:          report.Data.SerialNum[:],
		DroneLongitude:     report.Data.DroneLongitude,
		DroneLatitude:      report.Data.DroneLatitude,
		DroneHeight:        report.Data.DroneHeight,
		DroneYawAngle:      report.Data.DroneYawAngle,
		DroneSpeed:         report.Data.DroneSpeed,
		DroneVerticalSpeed: report.Data.DroneVerticalSpeed,
		SpeedDirection:     report.Data.SpeedDirection,
		DroneSailLongitude: report.Data.DroneSailLongitude,
		DroneSailLatitude:  report.Data.DroneSailLatitude,
		PilotLongitude:     report.Data.PilotLongitude,
		PilotLatitude:      report.Data.PilotLatitude,
		DroneHorizon:       report.Data.DroneHorizon,
		DronePitch:         report.Data.DronePitch,
		UFreq:              report.Data.UFreq,
		UDistance:          report.Data.UDistance,
		UDangerLevels:      report.Data.UDangerLevels,
		Role:               report.Data.Role,
		CreateTime:         time.Now().UnixMilli(),
	})

	Message := &cloudPlatform.SflHitList{
		Body: dData,
	}

	// encodedMessage
	encodedMessage, err := proto.Marshal(Message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return fmt.Errorf("Marshal encodedMessage error: %v", err)
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       SflHitURL,
			Sn:        c.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   c.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return err
	}
	//对消息进行封装+head+crc
	encodedMessage = createPacket(encodedMessage)
	// 发送TCP消息
	if c.Conn == nil || c.IsLogin == false {
		return nil
	}
	_, err = c.Conn.Write(encodedMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return err
	}

	return nil
}

//go:build !windows
// +build !windows

package videostore

import (
	"context"
	"crypto/md5"
	"encoding/csv"
	"encoding/hex"
	"errors"
	"fmt"
	"io"
	"os"
	"os/exec"
	"runtime"
	"strconv"
	"sync"
	"time"

	"adasgitlab.autel.com/tools/cuav_plugin/broker"
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/config"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/proto/mavlink"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/awserr"
	"github.com/aws/aws-sdk-go/aws/credentials"
	"github.com/aws/aws-sdk-go/aws/request"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/s3"
	ffmpeg "github.com/u2takey/ffmpeg-go"
	"google.golang.org/protobuf/proto"
)

type eventLog struct {
	*csv.Writer
	FileName string
}

type s3Config struct {
	BucketName string
	Region     string
	Ak         string
	Sk         string
	StoreType  int64
}

type videoConfig struct {
	//本地视频流地址
	InVideoURL string
	//视频最大保存时间
	MaxTime string
	//ffmpeg 文件路径
	FfmpegPath string
}
type storeConfig struct {
	videoConfig
	S3Con s3Config
}

type videoS3Object struct {
	//本地视频流地址
	InVideoURL string
	//视频最大保存时间
	MaxTime string
	//ffmpeg 文件路径
	FfmpegPath string
	EventMap   sync.Map
	Log        eventLog
	S3Con      s3Config
}

const (
	autoExit    = "autoExit"
	outTimeExit = "outTimeExit"
)

var vsSingletonOnce sync.Once

// VsSingleton ...
var VsSingleton *videoS3Object

// InitVideoStoreInstance ...
func InitVideoStoreInstance() {
	var videoLogPath string
	v := storeConfig{}
	logger.Debugf("Initializing video,config.GetGlobalConfig().AgxPTZ =", config.GetGlobalConfig().AgxPTZ)
	if config.GetGlobalConfig().AgxPTZ != nil {
		if len(config.GetGlobalConfig().AgxPTZ.VideoURL) != 0 {
			v.InVideoURL = config.GetGlobalConfig().AgxPTZ.VideoURL
		} else {
			v.InVideoURL = "rtsp://admin:Autel123@192.168.1.6:554/h264/ch33/main/av_steam" //default configuration
		}
		logger.Debug("config.GetGlobalConfig().AgxPTZ.VideoTimeOut = ", config.GetGlobalConfig().AgxPTZ.VideoTimeOut)
		if len(config.GetGlobalConfig().AgxPTZ.VideoTimeOut) != 0 {
			v.MaxTime = config.GetGlobalConfig().AgxPTZ.VideoTimeOut
		} else {
			v.MaxTime = "60"
		}
		if len(config.GetGlobalConfig().AgxPTZ.FfmpegPath) != 0 {
			v.FfmpegPath = config.GetGlobalConfig().AgxPTZ.FfmpegPath
		} else {
			v.FfmpegPath = "./ffmpeg.exe"
		}
		if len(config.GetGlobalConfig().AgxPTZ.VideoLogPath) != 0 {
			videoLogPath = config.GetGlobalConfig().AgxPTZ.VideoLogPath
		}

		if len(config.GetGlobalConfig().AgxPTZ.BucketName) != 0 {
			v.S3Con.BucketName = config.GetGlobalConfig().AgxPTZ.BucketName
		} else {
			v.S3Con.BucketName = "c2-eventvideo-fzwtest"
		}
		if len(config.GetGlobalConfig().AgxPTZ.Region) != 0 {
			v.S3Con.Region = config.GetGlobalConfig().AgxPTZ.Region
		} else {
			v.S3Con.Region = "cn-northwest-1"
		}
		if len(config.GetGlobalConfig().AgxPTZ.Ak) != 0 {
			v.S3Con.Ak = config.GetGlobalConfig().AgxPTZ.Ak
		} else {
			v.S3Con.Ak = "AKIAVVMOXO7XBDF4DBXL"
		}
		if len(config.GetGlobalConfig().AgxPTZ.Sk) != 0 {
			v.S3Con.Sk = config.GetGlobalConfig().AgxPTZ.Sk
		} else {
			v.S3Con.Sk = "08U2LuWaFV1el5DhdIaTGEyfXpvgMIs7hhzbd5rg"
		}
		if config.GetGlobalConfig().AgxPTZ.StoreType != 0 {
			v.S3Con.StoreType = config.GetGlobalConfig().AgxPTZ.StoreType
		} else {
			v.S3Con.StoreType = 1
		}
	}
	logger.Info("videoS3Object config Msg ", v)
	VsSingleton = newVideoS3ObjectInstance(v).withLog(videoLogPath)
}

func newVideoS3ObjectInstance(v storeConfig) *videoS3Object {
	vsSingletonOnce.Do(func() {
		VsSingleton = new(videoS3Object)
		VsSingleton.InVideoURL = v.InVideoURL
		VsSingleton.MaxTime = v.MaxTime
		VsSingleton.FfmpegPath = v.FfmpegPath
		VsSingleton.S3Con = v.S3Con
	})
	return VsSingleton
}

func (v *videoS3Object) withLog(filePath string) *videoS3Object {
	if len(filePath) == 0 {
		return v
	}
	v.Log = eventLog{FileName: filePath}
	file, err := os.Create(v.Log.FileName)
	if err != nil {
		msg := fmt.Sprintf("create file video log file fail: %v\n", err)
		logger.Debug(msg)
	}

	v.Log.Writer = csv.NewWriter(file)
	defer v.Log.Flush()

	v.Log.Writer.Write([]string{"Event ID", "startTime", "endTime", "totalTime", "exitType", "fileMd5Sum"})
	return v
}

func (v *videoS3Object) GoSaveToLocalVideoAndPushToS3(eventID, sn string) error {

	go func() {
		defer func() {
			if r := recover(); r != nil {
				err := fmt.Errorf("SaveToLocalVideo : %v", r)
				logger.Error("PushToS3 :", err)
			}
		}()
		err := v.SaveToLocalVideo(eventID)
		if err != nil {
			logger.Error("saveToLocalVideo err = ", err)
		} else {
			err := v.PushToS3(eventID)
			if err != nil {
				logger.Error("pushToS3 err = ", err)
			} else {
				logger.Debug("pushToS3 succeeded,EventID = ", eventID, " sn = ", sn)
				v.agxDetectVideoPushToS3EventReport(eventID, sn)

			}
		}
	}()

	return nil
}

func (v *videoS3Object) GoCancelCaptureVideo(eventID string) error {

	go func() {
		defer func() {
			if r := recover(); r != nil {
				err := fmt.Errorf("SaveToLocalVideo : %v", r)
				logger.Error("PushToS3 :", err)
			}
		}()
		v.CancelCaptureVideo(eventID)
	}()

	return nil
}

func (v *videoS3Object) SaveToLocalVideo(eventID string) error {

	supportOS := "windows"
	osName := runtime.GOOS

	if osName != supportOS {
		eMsg := fmt.Sprintf("unsupported ! system is not windows,system is %s\n", osName)
		return errors.New(eMsg)
	}
	logger.Debug("v.FfmpegPath = ", v.FfmpegPath)
	fileName := fmt.Sprintf("%s.mp4", eventID)
	FfmpegHandler := ffmpeg.Input(v.InVideoURL,
		ffmpeg.KwArgs{"t": v.MaxTime, "rtsp_transport": "tcp"}).OverWriteOutput().ErrorToStdOut().Output(fileName, ffmpeg.KwArgs{
		"vcodec": "copy",
	}).SetFfmpegPath(v.FfmpegPath).Compile()

	v.EventMap.Store(eventID, FfmpegHandler)

	startTime := time.Now()
	exitType := outTimeExit
	logger.Debug("ffmpeg store video path =", fileName)
	logger.Debug("FfmpegHandler = ", FfmpegHandler)
	err := FfmpegHandler.Run()
	if err != nil {
		exitType = autoExit
		logger.Debug("ffmpeg store video path,run exit msg:", err)
	}
	v.EventMap.Delete(eventID)

	endTime := time.Now()
	totalTime := endTime.Sub(startTime).Seconds()
	if v.Log.Writer != nil {
		v.saveEventToCSV(eventID, startTime.Format("2006-01-02 15:04:05"), endTime.Format("2006-01-02 15:04:05"), strconv.FormatFloat(totalTime, 'f', -1, 64), exitType, v.videoMd5(eventID))
	}
	return nil
}

func (v *videoS3Object) agxDetectVideoPushToS3EventReport(eventId, sn string) {
	var detectInfo []*client.AgxDetectInfoList

	dataInfo := &client.AgxDetectInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      sn,
			Sn:        sn,
			EquipType: int32(common.DEV_AGX),
			MsgType:   mavlink.AgxEventPushVideoDone,
		},
		Data:    detectInfo,
		EventId: eventId,
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgAgxDetectEventData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}
	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Infof("agx detect disappear event report: %v", dataInfo)
}
func (v *videoS3Object) saveEventToCSV(eventID, startTime, endTime, totalTime, exitType, md5 string) {
	logger.Debug("save event to CSV, eventID: , startTime: , endTime: ", eventID, startTime, endTime)
	err := v.Log.Writer.Write([]string{eventID, startTime, endTime, totalTime, exitType, md5})
	defer v.Log.Flush()
	if err != nil {
		logger.Error("saveEventToCSV = %v", err)
	}
}

func (v *videoS3Object) videoMd5(eventID string) (md5String string) {

	filePath := fmt.Sprintf("%s.mp4", eventID)
	file, err := os.Open(filePath)
	if err != nil {
		fmt.Println("Error opening file:", err)
		return
	}
	defer file.Close()
	hash := md5.New()
	if _, err := io.Copy(hash, file); err != nil {
		fmt.Println("Error calculating MD5:", err)
		return
	}
	md5Hash := hash.Sum(nil)
	md5String = hex.EncodeToString(md5Hash)

	return
}

func (v *videoS3Object) CancelCaptureVideo(eventID string) error {

	osName := runtime.GOOS
	if osName == "windows" {
		eMsg := fmt.Sprintf("unsupported ! system is not Windows,system is %s\n", osName)
		return errors.New(eMsg)
	}

	var FfmpegHandler *exec.Cmd

	val, ok := v.EventMap.Load(eventID)
	if ok {
		FfmpegHandler = val.(*exec.Cmd)
	} else {
		return errors.New("unknown event")
	}
	err := FfmpegHandler.Cancel()
	if err != nil {
		errMsg := fmt.Sprintf("GenerateConsoleCtrlEvent: %v\n", err)
		return errors.New(errMsg)
	}

	return nil
}

func (v *videoS3Object) PushToS3(eventID string) error {
	localPath, remotePath := fmt.Sprintf("%s.mp4", eventID), fmt.Sprintf("%s.mp4", eventID)

	Ak := v.S3Con.Ak
	Sk := v.S3Con.Sk
	Region := v.S3Con.Region
	Bucket := v.S3Con.BucketName

	var timeout time.Duration

	timeout = 30 * time.Second

	sess := session.Must(session.NewSession())

	svc := s3.New(sess, &aws.Config{
		Region:      aws.String(Region),
		Credentials: credentials.NewStaticCredentials(Ak, Sk, ""),
	})
	logger.Debugf("svc = ", svc)
	ctx := context.Background()
	var cancelFn func()
	if timeout > 0 {
		ctx, cancelFn = context.WithTimeout(ctx, timeout)
	}

	if cancelFn != nil {
		defer cancelFn()
	}

	fileContent, err := os.Open(localPath)
	if err != nil {
		fmt.Println("read file failed, err = ", err)
	}

	output, err := svc.PutObjectWithContext(ctx, &s3.PutObjectInput{
		Bucket: aws.String(Bucket),
		Key:    aws.String(remotePath),
		Body:   fileContent,
	})
	if err != nil {
		if aerr, ok := err.(awserr.Error); ok && aerr.Code() == request.CanceledErrorCode {
			fmt.Fprintf(os.Stderr, "upload canceled due to timeout, %v\n", err)
			msg := fmt.Sprintf("upload canceled due to timeout,%s\n", err.Error())
			return errors.New(msg)
		}
		fmt.Fprintf(os.Stderr, "failed to upload object, %v\n", err)
		msg := fmt.Sprintf("upload failed to upload object, %s\n", err.Error())
		return errors.New(msg)
	}
	fileEtag := *output.ETag
	fileMd5 := fmt.Sprintf("\"%s\"", v.videoMd5(eventID))
	if fileEtag != fileMd5 {
		return errors.New("remote upload file does error")
	}
	fileContent.Close()
	err = os.Remove(localPath)
	if err != nil {
		msg := fmt.Sprintf("failed to remove: %v\n", err)
		return errors.New(msg)
	}
	return nil
}

## 概述 
uploadcloud 包主要用于处理数据上报云端

- **cloud_platform.go** - 建立云端通信，账号登录，认证等。
- **device_msg_report.go** - 上报设备数据(C2系统配置,设备列表,雷达数据，tracer设备数据)
- **fpv.go** -  车载心跳，侦测无人机数据上报
- **sfl.go** - 哨兵塔 上报心跳、侦测无人机、打击状态
- **nsf400.go** - 导航诱导上报设备状态
- **tracerRF3600.go** - 上报设备状态、无人机消息、频谱信息

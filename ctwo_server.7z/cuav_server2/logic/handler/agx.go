package handler

import (
	"bytes"
	"context"
	"crypto/rand"
	"encoding/binary"
	"errors"
	"fmt"
	"math/big"
	"strconv"
	"strings"
	"sync"
	"time"

	"adasgitlab.autel.com/tools/cuav_server/repo/utils"

	"adasgitlab.autel.com/tools/cuav_plugin/broker"
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/server"
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/ip"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/proto/mavlink"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
	"adasgitlab.autel.com/tools/slink_proto/slinkv1"
	"google.golang.org/protobuf/proto"
)

const (
	AgxTcpPort        = 16000
	AgxServerMaxCount = 500
	AgxReducedValue   = 64 //2的6次方,Agx上报数值扩大值
)

type Agx struct {
	*Device
	dt common.DeviceType
}

var (
	AgxTcpServerLock sync.Mutex
	AgxTcpServerMap  sync.Map
	AgxHeartSum      uint8
)

func NewAgx(conn Connection, d []byte, dataLen int, remoteIp string, remotePort int, localIp string, serverPort int,
	mailBox map[int]*WaitTaskManager) DeviceInterface {
	agx := &Agx{
		Device: &Device{
			Conn:        conn,
			Msg:         d,
			MsgLen:      dataLen,
			SourceId:    d[mavlink.SenderLoc],
			RemoteIp:    remoteIp,
			RemotePort:  remotePort,
			LocalIp:     localIp,
			ServerPort:  serverPort,
			WaitTaskMap: mailBox,
		},
	}
	return agx
}

func (d *Agx) Deal() {
	defer func() {
		if err := recover(); err != nil {
			logger.Error("Agx deal 接收到panic:", err)
		}
	}()

	if d.MsgLen <= 0 {
		logger.Error("Agx 数据为null,不作处理:", d.Device.RemoteIp)
		return
	}
	d.MsgId = int(d.Msg[mavlink.MsgIdLoc])
	switch d.MsgId {
	case mavlink.AgxMsgHeartBeat:
		d.ReceiveAgxHeartBeat()
	case mavlink.AgxMsgDetect:
		d.ReceiveAgxDetectRes()
	case mavlink.AgxMsgPerception:
		d.ReceiveAgxPerceptionRes()
	case mavlink.AgxMsgDeviceStatus:
		d.ReceiveAgxDeviceStatusRes()
	case mavlink.AgxMsgPTZStatus:
		d.ReceiveAgxPTZStatusRes()
	case mavlink.AgxCalibrationResult:
		d.ReceiveAgxCalibrationResultRes()
	case mavlink.AgxTransferDevMsg:
		d.ReceiveAgxTransferDevMsg()
	case mavlink.AgxSendMsgSfl:
		d.ReceiveAgxSelectSflUav()

	default:
		logger.Error("Agx 未知Agx消息id:", d.MsgId)
		break
	}
}
func SendAgxHeart() {
	ticker := time.NewTicker(time.Second * 1)
	defer ticker.Stop()
	for range ticker.C {
		DevStatusMap.Range(func(key, value interface{}) bool {
			dev := value.(*Device)
			if dev.DevType == common.DEV_AGX && dev.Status == common.DevOnline {
				reqMode := &Agx{
					Device: dev,
					dt:     common.DEV_AGX,
				}
				reqMode.SendExtHeartbeat()
			}
			return true
		})
	}
}
func (d *Agx) SendExtHeartbeat() error {
	AgxHeartSum++
	if AgxHeartSum > 255 {
		AgxHeartSum = 0
	}
	req := &mavlink.AgxHeartbeatExtRequest{
		Sum: AgxHeartSum,
	}
	reqBuff := req.CreateAgxHeartbeatExt()
	if d != nil && d.Conn != nil {
		_, err := d.Conn.Write(reqBuff)
		logger.Infof("Agx c2发送心跳结果：%X", reqBuff)
		if err != nil {
			dataInfo := &client.AgxHeartBeatInfo{
				Header: &client.EquipmentMessageBoxEntity{
					Name:      d.Sn,
					Sn:        d.Sn,
					EquipType: int32(common.DEV_AGX),
					MsgType:   mavlink.AgxMsgHeartBeat,
				},
				Data: &client.AgxHeartBeatReport{
					Sn:       d.Sn,
					IsOnline: common.DevOffline,
				},
			}
			msg, err := proto.Marshal(dataInfo)
			if err != nil {
				logger.Error("marshal dataInfo err:", err)
				return err
			}
			report := &client.ClientReport{
				MsgType: common.ClientMsgIdAgxHeartData,
				Data:    msg,
			}
			out, err := proto.Marshal(report)
			if err != nil {
				logger.Error("marshal report err:", err)
				return err
			}
			_ = mq.AgxMsgBroker.Publish(mq.AgxTopic, broker.NewMessage(out))
			logger.Info("agx Offline report:", report)
		}
		return err
	}
	return nil
}

// AgxOfflineReport Agx设备离线处理
func AgxOfflineReport(sn string) {
	var tcpServer *server.TcpServer
	if s, ok := AgxTcpServerMap.Load(sn); ok {
		tcpServer = s.(*server.TcpServer)

		if tcpServer != nil {
			tcpServer.Stop()
		}
		deviceUsedPorts.Delete(tcpServer.Port)
		AgxTcpServerMap.Delete(sn)
		DevSnMap.Delete(tcpServer.Port)
		cachekeyDroneid := fmt.Sprintf("%d_%s", common.DEV_AGX, sn)
		DevStatusMap.Delete(cachekeyDroneid)
		tcpServer = nil
	}
	dataInfo := &client.AgxHeartBeatInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      sn,
			Sn:        sn,
			EquipType: int32(common.DEV_AGX),
			MsgType:   mavlink.AgxMsgHeartBeat,
		},
		Data: &client.AgxHeartBeatReport{
			Sn:       sn,
			IsOnline: common.DevOffline,
		},
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIdAgxHeartData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.AgxMsgBroker.Publish(mq.AgxTopic, broker.NewMessage(out))
	logger.Info("Agx Offline report:", report)

}

// HandleBroadCast 处理广播消息
func (d *Agx) HandleBroadCast(ctx context.Context, req *slinkv1.UdpBroadcastConfirmRequest) (*slinkv1.UdpBroadcastConfirmResponse, error) {
	if req.GetSn() == "" {
		logger.Info("device sn empty")
		return nil, nil
	}

	if status := d.GetStatus(req.GetSn()); status == common.DeviceDisenable {
		logger.Infof("device %v disable", req.GetSn())
		return nil, nil
	}

	localIP := make([]string, 0)
	localIps, broadIps, err := ip.GetBroadcastAddress()
	if err != nil {
		logger.Error("Get IP error :%v", err)
	}
	for i, ip := range localIps {
		if i >= len(broadIps) {
			continue
		}
		localIP = append(localIP, ip)
	}
	logger.Debugf("[Fpv] localIP:%v,", localIP)

	tcpServer := d.TcpServerCheck(req.GetSn(), localIP)
	DevSnMap.Store(tcpServer.Port, req.GetSn())
	d.ServerPort = tcpServer.Port

	//响应
	rsp := &slinkv1.UdpBroadcastConfirmResponse{
		Sn:       req.Sn,
		Addr:     ip.IPV4(tcpServer.Ip),
		Port:     uint16(tcpServer.Port),
		ConnType: 1,
	}
	return rsp, nil
}

func (d *Agx) GetStatus(sn string) int32 {
	statusRes := &client.GetStatusRes{}
	err := NewEquipList().GetStatus(context.Background(), &client.GetStatusReq{Sn: sn, EType: "Agx"}, statusRes)
	if err != nil {
		logger.Errorf("GetStatus err: %v", err.Error())
		return 0
	}

	return statusRes.IsEnable
}

func (d *Agx) TcpServerCheck(devSn string, localIP []string) *server.TcpServer {
	var tcpServer *server.TcpServer
	if s, ok := AgxTcpServerMap.Load(devSn); ok {
		tcpServer = s.(*server.TcpServer)
		isAlike := false
		for _, ip := range localIP {
			if ip == tcpServer.Ip {
				isAlike = true
			}
		}
		if isAlike == false { //查找的本地IP没有与之前相同的
			if tcpServer != nil {
				tcpServer.Stop()
			}
			deviceUsedPorts.Delete(tcpServer.Port)
			AgxTcpServerMap.Delete(devSn)
			DevSnMap.Delete(tcpServer.Port)
			tcpServer = nil
		}
	}

	//注册tcp服务
	if tcpServer == nil {
		port, err := ip.GetFreeTcpPort()
		if err != nil {
			logger.Error("Agx tcp 获取可用端口失败：", err)
			port = d.getRandPort(AgxTcpPort, AgxTcpPort+AgxServerMaxCount)
		}
		tcpServer = server.NewTcpServer(port, Handle)
		AgxTcpServerMap.Store(devSn, tcpServer)
		tcpServer.ServerType = uint8(common.DEV_AGX)
		tcpServer.ServerName = devSn
		localAddr, _ := ip.GetLocalIp(d.UdpIp)
		tcpServer.Ip = localAddr
		go tcpServer.Start()
	}
	return tcpServer
}
func (d *Agx) getRandPort(min, max int64) int {
	maxBigInt := big.NewInt(max)
	i, _ := rand.Int(rand.Reader, maxBigInt)
	_, ok := deviceUsedPorts.Load(i.Int64())
	port := i.Int64()
	//缓存不存在或者符合范围
	if !ok && (port > min && port < max) {
		deviceUsedPorts.Store(port, port)
		return int(port)
	}
	return d.getRandPort(min, max)
}

func (d *Agx) ReceiveGetChannelReq() {
	AgxTcpServerLock.Lock()
	defer AgxTcpServerLock.Unlock()

	devSn := d.UnMarshalGetChannelReq()
	if devSn == "" {
		logger.Info("Agx device sn empty")
		return
	}

	//if isContinue := d.deviceDiscover(devSn); !isContinue {
	//	logger.Error("droneID等待设备确认：", devSn)
	//	return
	//}

	if status := d.GetStatus(devSn); status == common.DeviceDisenable {
		logger.Infof("Agx device %v disable", devSn)
		return
	}

	localIP := make([]string, 0)

	localIps, broadIps, err := ip.GetBroadcastAddress()
	if err != nil {
		logger.Error("Agx Get IP error :%v", err)
	}
	for i, ip := range localIps {
		if i >= len(broadIps) {
			continue
		}
		localIP = append(localIP, ip)
	}
	logger.Debugf("[Agx] localIP:%v,", localIP)

	tcpServer := d.TcpServerCheck(devSn, localIP)
	DevSnMap.Store(tcpServer.Port, devSn)
	d.ServerPort = tcpServer.Port

	//响应
	switch d.MsgId {
	case mavlink.AgxUdpBroadcastResponse:
		logger.Info("[Agx] receive Broadcast BB Msg")
		UdpBroadcastSendChannel(devSn, d.UdpIp, d.SourceId, tcpServer)
		err := NewEquipList().Update(context.Background(), &client.EquipCrudReq{
			Sn: devSn,
			Ip: d.UdpIp,
		}, &client.EquipCrudRes{})
		if err != nil {
			logger.Error("Update EquipList err: ", err)
			return
		}
		break
	default:
		break
	}

	return
}
func (d *Agx) UnMarshalGetChannelReq() string {
	devSn := ""
	switch d.MsgId {
	case mavlink.AgxUdpBroadcastResponse:
		req := &mavlink.UdpBroadcastConfirmRequest{}
		d.GetPacket(req)
		devSn = strings.TrimRight(string(req.Sn[:]), string(rune(0)))
		break
	default:
		break
	}
	return devSn
}

func (d *Agx) GetPacket(message mavlink.Message) *mavlink.MavPacket {
	logger.Infof("Agx GetPacket is [% x]", d.Msg)
	req := mavlink.NewNullPacket(message)
	buff := &bytes.Buffer{}
	if err := binary.Write(buff, binary.LittleEndian, d.Msg); err != nil {
		logger.Error("Agx GetPacket write buff err:", err)
		return nil

	}
	if err := binary.Read(buff, binary.LittleEndian, &req.Header); err != nil {
		logger.Error("Agx GetPacket read header err:", err)
		return nil
	}
	if err := binary.Read(buff, binary.LittleEndian, req.Msg); err != nil {
		logger.Error("Agx GetPacket read msg err:", err)
		return nil
	}
	return req
}
func (d *Agx) getSn() string {
	if sn, ok := DevSnMap.Load(d.ServerPort); ok {
		return sn.(string)
	}
	return ""
}
func (d *Agx) updateStatus(sn string) int32 {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_AGX, sn)
	if cache, ok := DevStatusMap.Load(cacheKey); ok {
		dev := cache.(*Device)
		if dev.IsEnable == common.DeviceDisenable {
			return common.DeviceDisenable
		}
		dev.Status = common.DevOnline
		dev.Conn = d.Conn
		dev.WaitTaskMap = d.WaitTaskMap
		dev.RemoteIp = d.RemoteIp
		dev.LastHeartTime = time.Now()
		dev.GetStatusInterval = time.Now()
		if dev.IsEnable != common.DeviceDisenable && dev.IsEnable != common.DeviceEnable {
			dev.IsEnable = d.GetStatus(sn)
		}
		return dev.IsEnable
	} else {
		dev := &Device{
			Sn:                sn,
			Conn:              d.Conn,
			Status:            common.DevOnline,
			RemoteIp:          d.RemoteIp,
			RemotePort:        d.RemotePort,
			LocalIp:           d.LocalIp,
			ServerPort:        d.ServerPort,
			DevType:           common.DEV_AGX,
			FirstHeartTime:    time.Now(),
			LastHeartTime:     time.Now(),
			SourceId:          d.SourceId,
			IsEnable:          d.GetStatus(sn),
			GetStatusInterval: time.Now(),
			WaitTaskMap:       d.WaitTaskMap,
		}
		DevStatusMap.Store(cacheKey, dev)
		return dev.IsEnable
	}
}
func (d *Agx) updateStatusOnLine(sn string) {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_AGX, sn)
	if cache, ok := DevStatusMapOnEvent.Load(cacheKey); ok {
		dev := cache.(*Device)
		dev.LastHeartTime = time.Now()
		dev.GetStatusInterval = time.Now()
		DevStatusMapOnEvent.Store(cacheKey, cache)

		return
	}
	dev := &Device{
		Sn:                sn,
		Status:            common.DevOnline,
		RemoteIp:          d.RemoteIp,
		RemotePort:        d.RemotePort,
		LocalIp:           d.LocalIp,
		ServerPort:        d.ServerPort,
		DevType:           common.DEV_AGX,
		FirstHeartTime:    time.Now(),
		LastHeartTime:     time.Now(),
		SourceId:          d.SourceId,
		IsEnable:          d.GetStatus(sn), //Notice...
		GetStatusInterval: time.Now(),
		SessionId:         GetGlobalSessionId(),
		WorkMode:          d.WorkMode,
	}
	DevStatusMapOnEvent.Store(cacheKey, dev)

	go func() {
		dataInfo := &client.AgxHeartBeatInfo{
			Header: &client.EquipmentMessageBoxEntity{
				Name:      sn,
				Sn:        sn,
				EquipType: int32(common.DEV_AGX),
				MsgType:   mavlink.AgxEventOnLine,
			},
			Data: &client.AgxHeartBeatReport{
				Sn:       sn,
				IsOnline: common.DevOnline,
				EventId:  utils.GetEventId(dev.SessionId),
				//需要查询下表：因为tracer不携带经纬度信息。由c2获取
				//GunLatitude:  float64(heartInfo.Info.GunLatitude) / GunLatitudeTion,
				//GunLongitude: float64(heartInfo.Info.GunLongitude) / GunLongitudeTion,
			},
		}
		msg, err := proto.Marshal(dataInfo)
		if err != nil {
			logger.Error("marshal dataInfo err:", err)
			return
		}

		report := &client.ClientReport{
			MsgType: common.ClientMsgAgxStatusEventData,
			Data:    msg,
		}
		out, err := proto.Marshal(report)
		if err != nil {
			logger.Error("marshal report err:", err)
			return
		}
		_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
		logger.Infof("agx heartbeat event has reported, devSn: %v,report:%v", sn, dataInfo.Data)
	}()
	return
}
func (d *Agx) ReceiveAgxHeartBeat() {
	heart := &mavlink.AgxHeart{}
	d.GetPacket(heart)
	devSn := d.getSn()
	if isEnable := d.updateStatus(devSn); isEnable == common.DeviceDisenable {
		logger.Infof("Agx device %v disable", devSn)
		return
	}
	logger.Info("Receive Agx Heart:", heart, devSn)
	dataInfo := &client.AgxHeartBeatInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      devSn,
			Sn:        devSn,
			EquipType: int32(common.DEV_AGX),
			MsgType:   mavlink.AgxMsgHeartBeat,
		},
		Data: &client.AgxHeartBeatReport{
			Electricity: int32(heart.Electricity),
			Status:      int32(heart.Status),
			IsOnline:    common.DevOnline,
			Ip:          d.RemoteIp,
			Sn:          devSn,
		},
	}
	if dataInfo.Data.Ip == "" {
		dbequips := &client.EquipListRes{}
		err := NewEquipList().List(context.Background(), &client.EquipListReq{}, dbequips)
		if err != nil {
			logger.Info("Get EquipList err: ", err)
		}
		for _, equip := range dbequips.Equips {
			if equip.Sn == dataInfo.Data.Sn {
				dataInfo.Data.Ip = equip.Ip
			}
		}
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIdAgxHeartData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}
	d.updateStatusOnLine(devSn)

	_ = mq.AgxMsgBroker.Publish(mq.AgxTopic, broker.NewMessage(out))
	logger.Info("Agx heart report:", heart, devSn)
}

// ReceiveAgxPerceptionRes 收到Agx感知信息上报
func (d *Agx) ReceiveAgxPerceptionRes() {
	logger.Info("--->Into Receive Agx Perception")
	devSn := d.getSn()
	result := &mavlink.AgxPerceptionResult{}
	if err := d.UnmarshalAgxPerception(result); err != nil {
		logger.Errorf(err.Error())
		return
	}
	if devSn != "" {
		if isEnable := d.updateStatus(devSn); isEnable == common.DeviceDisenable {
			logger.Infof("Agx device %v disable", devSn)
			return
		}
		d.agxPerceptionReport(devSn, result)
	}
	logger.Info("--->End Receive Agx Perception")
}
func (d *Agx) agxPerceptionReport(devSn string, agxInfo *mavlink.AgxPerceptionResult) {
	logger.Info("--->Into Receive agx  Perception Report")
	agxResult := make([]*client.AgxPerceptionReportInfo, 0)

	for _, agx := range agxInfo.Description {
		r := &client.AgxPerceptionReportInfo{
			Id:             int32(agx.Id),
			Classification: int32(agx.Classification),
			RectX:          int32(agx.RectX),
			RectY:          int32(agx.RectY),
			RectW:          int32(agx.RectW),
			RectH:          int32(agx.RectH),
			RectXV:         int32(agx.RectXV),
			RectYV:         int32(agx.RectYV),
			ClassFyProb:    agx.ClassFvProb,
			Type:           int32(agx.Type),
			TypeProb:       agx.TypeProb,
			LoadLever:      int32(agx.LoadLever),
			DangerLever:    int32(agx.DangerLever),
			Azimuth:        agx.Azimuth,
			Elevation:      agx.Elevation,
			Range:          agx.Range,
			MotionType:     int32(agx.MotionType),
			BTracked:       int32(agx.BTracked),
		}
		logger.Infof("agx Info data: %+v", agx)
		agxResult = append(agxResult, r)
	}

	dataInfo := &client.AgxPerceptionInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      devSn,
			Sn:        devSn,
			EquipType: int32(common.DEV_AGX),
			MsgType:   mavlink.AgxMsgPerception,
		},
		Data: &client.AgxPerceptionReport{
			Sn:        devSn,
			TimeStamp: int32(agxInfo.Info.TimeStamp),
			ObjId:     int32(agxInfo.Info.ObjNum),
			TargetId:  int32(agxInfo.Info.TargetId),
			Zoom:      agxInfo.Info.Zoom,
			HFov:      agxInfo.Info.HFov,
			VFov:      agxInfo.Info.VFov,
			List:      agxResult,
		},
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIdAgxPerceptionData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}
	_ = mq.AgxMsgBroker.Publish(mq.AgxTopic, broker.NewMessage(out))
	logger.Infof("Agx has perception reported, devSn: %v, data info %v", devSn, dataInfo)
}

func (d *Agx) UnmarshalAgxPerception(data *mavlink.AgxPerceptionResult) error {
	deviceInfoLen := binary.Size(mavlink.AgxPerceptionInfo{})
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}

	start := mavlink.HeaderLen + deviceInfoLen
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializeDrone(d.Msg[start:end]); err != nil {
		return err
	}

	return nil
}

// ReceiveAgxDetectRes 收到Agx无人机信息上报
func (d *Agx) ReceiveAgxDetectRes() {
	logger.Info("--->Into Receive Agx Detect")
	devSn := d.getSn()
	result := &mavlink.AgxDetectResult{}
	if err := d.UnmarshalAgxDetect(result); err != nil {
		logger.Errorf(err.Error())
		return
	}
	if devSn != "" {
		if isEnable := d.updateStatus(devSn); isEnable == common.DeviceDisenable {
			logger.Infof("Agx device %v disable", devSn)
			return
		}
		d.agxDetectReport(devSn, result)
	}
	logger.Info("--->End Receive Agx Detect")
}
func CheckUavLocked(history []*DetectUavItem, objId uint32) bool {
	if history == nil || len(history) <= 0 {
		return false
	}
	for _, item := range history {
		if item == nil {
			continue
		}
		if item.ObjectId == objId {
			return true
		}
	}
	return false
}
func (d *Agx) updateAgxDetectEvent(sn string, detectInfo []*client.AgxDetectInfoList) {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_AGX, sn)

	if cache, ok := DevDetectMapOnEvent.Load(cacheKey); ok {
		detect := cache.(*DetectEvent)
		detect.LastReceiveTime = time.Now()

		for _, uav := range detectInfo {
			if uav == nil {
				continue
			}
			//
			var isLockedByPtz uint32 = uav.AssocBit1
			if isLockedByPtz == 0 {
				continue
			}
			//只记录 当前有被锁定且之前未被锁定但的无人机。
			if !CheckUavLocked(detect.Items, uav.ObjId) {
				logger.Infof("uav not been locked previously, this time is locked by ptz, uav: %v", uav.ObjId)
				detect.Items = append(detect.Items, &DetectUavItem{
					ObjectId:    uav.ObjId,
					LockedUavIs: int8(isLockedByPtz),
					LockedTime:  time.Now(),
				})
			}
		}

		DevDetectMapOnEvent.Store(cacheKey, cache)
		return
	}

	if len(detectInfo) <= 0 {
		logger.Infof("detect uav info is empty")
		return
	}

	detect := &DetectEvent{
		Sn:               sn,
		LastReceiveTime:  time.Now(),
		DevType:          common.DEV_AGX,
		SessionId:        GetGlobalSessionId(),
		LockPtzSessionId: GetGlobalSessionId(),
	}
	// 记录无人机是否被锁定
	for _, uav := range detectInfo {
		if uav == nil {
			continue
		}

		var lockedByPtz uint32 = uav.AssocBit1
		if lockedByPtz == 0 {
			continue
		}
		//记录被锁定的无人机
		logger.Infof("uav locked by ptz firstly, uav: %v", uav.ObjId)
		detect.Items = append(detect.Items, &DetectUavItem{
			ObjectId:    uav.ObjId,
			LockedUavIs: int8(lockedByPtz),
			LockedTime:  time.Now(),
		})
	}

	DevDetectMapOnEvent.Store(cacheKey, detect)

	eventDetectInfo := &client.AgxDetectInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Sn:        sn,
			EquipType: int32(common.DEV_AGX),
			MsgType:   mavlink.AgxEventDetectAppear,
		},
		Data:    detectInfo,
		EventId: utils.GetEventId(detect.SessionId),
	}

	buBuff, err := proto.Marshal(eventDetectInfo)
	if err != nil {
		logger.Errorf("Marshal TracerDetectInfo err %v", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgAgxDetectEventData,
		Data:    buBuff,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}
	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Infof("agx detect uav event has reported, devSn: %v,report:%v", sn, detectInfo)
}

func (d *Agx) agxDetectReport(devSn string, agxInfo *mavlink.AgxDetectResult) {
	logger.Info("--->Into Receive agx  Detect Report")
	agxResult := make([]*client.AgxDetectInfoList, 0)
	for _, agx := range agxInfo.Description {
		r := &client.AgxDetectInfoList{
			ObjId:            uint32(agx.Id),
			Azimuth:          float64(agx.Azimuth) / float64(AgxReducedValue),
			Elevation:        float64(agx.Elevation) / float64(AgxReducedValue),
			Velocity:         float64(agx.Velocity) / float64(AgxReducedValue),
			DopplerChn:       int32(agx.DopplerChn),
			Mag:              float64(agx.Mag) / float64(AgxReducedValue),
			Ambiguous:        int32(agx.Ambiguous),
			Classification:   int32(agx.Classification),
			ClassfyProb:      float64(agx.ClassifyProb) / float64(AgxReducedValue),
			ExistingProb:     float32(agx.ExistingProb) / float32(AgxReducedValue),
			AbsVel:           float64(agx.AbsVel) / float64(AgxReducedValue),
			OrientationAngle: float64(agx.OrientationAngle) / float64(AgxReducedValue),
			Alive:            uint32(agx.Alive),
			TwsTasFlag:       uint32(agx.TwsTasFlag),
			X:                float64(agx.X) / float64(AgxReducedValue),
			Y:                float64(agx.Y) / float64(AgxReducedValue),
			Z:                float64(agx.Z) / float64(AgxReducedValue),
			Vx:               float64(agx.Vx) / float64(AgxReducedValue),
			Vy:               float64(agx.Vy) / float64(AgxReducedValue),
			Vz:               float64(agx.Vz) / float64(AgxReducedValue),
			Ax:               float64(agx.Ax) / float64(AgxReducedValue),
			Ay:               float64(agx.Ay) / float64(AgxReducedValue),
			Az:               float64(agx.Az) / float64(AgxReducedValue),
			XVariance:        float64(agx.XVariance) / float64(AgxReducedValue),
			YVariance:        float64(agx.YVariance) / float64(AgxReducedValue),
			ZVariance:        float64(agx.ZVariance) / float64(AgxReducedValue),
			VxVariance:       float64(agx.VxVariance) / float64(AgxReducedValue),
			VyVariance:       float64(agx.VyVariance) / float64(AgxReducedValue),
			VzVariance:       float64(agx.VzVariance) / float64(AgxReducedValue),
			AxVariance:       float64(agx.AxVariance) / float64(AgxReducedValue),
			AyVariance:       float64(agx.AyVariance) / float64(AgxReducedValue),
			AzVariance:       float64(agx.AzVariance) / float64(AgxReducedValue),
			StateType:        int32(agx.StateType),
			MotionType:       int32(agx.MotionType),
			ForcastFrameNum:  int32(agx.ForcastFrameNum),
			AssociationNum:   int32(agx.AssociationNum),
			AssocBit0:        agx.AssocBit0,
			AssocBit1:        agx.AssocBit1, // 0: 就代表没有被PTZ锁定过，1就是有被锁定过; (temp definition)
		}
		logger.Infof("agx Info data: %+v", agx)
		if agx.StateType == 0 {
			logger.Info("Agx State Type is 0")
			continue
		}
		agxResult = append(agxResult, r)
	}

	dataInfo := &client.AgxDetectInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      devSn,
			Sn:        devSn,
			EquipType: int32(common.DEV_AGX),
			MsgType:   mavlink.AgxMsgDetect,
		},
		Data: agxResult,
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIdAgxDetectData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}
	_ = mq.AgxMsgBroker.Publish(mq.AgxTopic, broker.NewMessage(out))

	d.updateAgxDetectEvent(devSn, agxResult)

	logger.Infof("Agx has Detect reported, devSn: %v, data info %v", devSn, report)
}

func (d *Agx) UnmarshalAgxDetect(data *mavlink.AgxDetectResult) error {
	deviceInfoLen := binary.Size(mavlink.AgxDetectInfo{})
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}

	start := mavlink.HeaderLen + deviceInfoLen
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializeDrone(d.Msg[start:end]); err != nil {
		return err
	}

	return nil
}

// ReceiveAgxTransferDevMsg 收到Agx 上报转发设备的消息
func (d *Agx) ReceiveAgxTransferDevMsg() {
	logger.Info("--->Into Receive Agx Transfer DevMsg")
	devSn := d.getSn()
	result := &mavlink.AgxTransferMsg{}
	if err := d.UnmarshalAgxTransferDevMsg(result, devSn); err != nil {
		logger.Errorf(err.Error())
		return
	}
	logger.Info("--->End Receive Agx Transfer DevMsg")
}
func (d *Agx) UnmarshalAgxTransferDevMsg(data *mavlink.AgxTransferMsg, devSn string) error {
	begin := mavlink.HeaderLen
	msgLen := 1
	readLen := begin + msgLen
	err := mavlink.Read(bytes.NewReader(d.Msg[begin:readLen]), binary.LittleEndian, &data.SlaveDevId, msgLen)
	logger.Debug("slave DevId : ", data.SlaveDevId)

	begin = readLen
	msgLen = mavlink.DevSNLen
	readLen = begin + msgLen

	err = mavlink.Read(bytes.NewReader(d.Msg[begin:readLen]), binary.LittleEndian, &data.Sn, msgLen)
	logger.Debug("dev sn is  : ", string(data.Sn[:]))

	begin = readLen
	msgLen = 1
	readLen = begin + msgLen

	err = mavlink.Read(bytes.NewReader(d.Msg[begin:readLen]), binary.LittleEndian, &data.TransferCmd, msgLen)
	logger.Debug("transfer cmd is  : ", data.TransferCmd)
	begin = readLen
	msgLen = 4
	readLen = begin + msgLen

	err = mavlink.Read(bytes.NewReader(d.Msg[begin:readLen]), binary.LittleEndian, &data.CmdLen, msgLen)
	logger.Debug("cmd len is  : ", data.CmdLen)
	begin = readLen
	msgLen = int(data.CmdLen)
	readLen = begin + msgLen
	if data.SlaveDevId == uint8(common.DEV_SFL) {
		if data.TransferCmd == mavlink.SflDetectMsg {
			result := &mavlink.SflDetect{}
			deviceInfoLen := binary.Size(mavlink.SflDetectInfo{})
			buff := &bytes.Buffer{}
			if err := binary.Write(buff, binary.LittleEndian, d.Msg[begin:]); err != nil {
				return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
			}
			if err := binary.Read(buff, binary.LittleEndian, &result.Info); err != nil {
				return fmt.Errorf("UnmarshalPayload read data err: %v", err)
			}
			start := begin + deviceInfoLen
			end := d.MsgLen - mavlink.CrcLen
			if err = result.DeserializeDrone(d.Msg[start:end]); err != nil {
				return err
			}
			if devSn != "" {
				d.agxReportSflDetectMsg(devSn, result)
			}
		}
		if data.TransferCmd == mavlink.SflHeartMsg {
			result := &mavlink.SflHeart{}
			buff := &bytes.Buffer{}
			if err := binary.Write(buff, binary.LittleEndian, d.Msg[begin:readLen]); err != nil {
				return fmt.Errorf("AGX_Sfl UnmarshalPayload write buff err: %v", err)
			}
			if err = binary.Read(buff, binary.LittleEndian, &result.Info); err != nil {
				return fmt.Errorf("AGX_Sfl UnmarshalPayload read data err: %v", err)
			}
			d.agxReportSflHeartMsg(devSn, result)
		}

	}

	return nil
}
func (d *Agx) agxReportSflHeartMsg(devSn string, heartInfo *mavlink.SflHeart) {

	dataInfo := &client.SflHeartInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      devSn,
			Sn:        devSn,
			EquipType: int32(common.DEV_AGX),
			MsgType:   mavlink.AgxTransferDevMsg,
		},
		Data: &client.GimbalCounterHeartInfo{
			Sn:              ByteToString(heartInfo.Info.Sn[:]),
			TimeStamp:       int32(heartInfo.Info.TimeStamp),
			WorkStatus:      int32(heartInfo.Info.WorkStatus),
			IsOnline:        common.DevOnline,
			HitFreq:         int32(heartInfo.Info.HitFreq),
			DetectFreq:      float64(heartInfo.Info.DetectFreq) / DetectFreqTion,
			Elevation:       float64(heartInfo.Info.Elevation) / ElevationTion,
			GunDirection:    float64(heartInfo.Info.GunDirection) / GunDirectTion,
			GunLongitude:    float64(heartInfo.Info.GunLongitude) / GunLongitudeTion,
			GunLatitude:     float64(heartInfo.Info.GunLatitude) / GunLatitudeTion,
			GunAltitude:     float64(heartInfo.Info.GunAltitude),
			SatellitesNum:   int32(heartInfo.Info.SatellitesNum),
			FaultLevel:      int32(heartInfo.Info.FaultLevel),
			CtrlFault:       int32(heartInfo.Info.CtrlFault),
			AeagFault:       int32(heartInfo.Info.AeagFault),
			TracerFault:     int32(heartInfo.Info.TracerFault),
			WorkStatusParam: int32(heartInfo.Info.WorkStatusParam),
		},
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgIdAgxTransferSflHeartMsg,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.AgxMsgBroker.Publish(mq.AgxTopic, broker.NewMessage(out))

	logger.Infof("Agx Transfer Sfl heartbeat has reported, devSn: %v,report:%v", devSn, dataInfo.Data)
}
func (d *Agx) agxReportSflDetectMsg(devSn string, detectInfo *mavlink.SflDetect) {
	dataInfo := &client.GimbalCounterDetectSocketInfo{}
	dataInfo.List = make([]*client.GimbalCounterDetectDroneInfo, 0, len(detectInfo.Description))
	dataInfo.Sn = ByteToString(detectInfo.Info.SN[:]) //sflSn
	dataInfo.DetectionNum = int32(detectInfo.Info.DetectionNum)
	//查白名单中的无人机，在Tracer侦测结果中添加无人机角色
	whiteList := &client.ListResAll{}
	err := NewWhiteList().ListAll(context.Background(), &client.ListReqAll{}, whiteList)
	if err != nil {
		logger.Error("Get whiteList err: ", err)
		return
	}
	logger.Debug("detect Info Description:", len(detectInfo.Description))
	for _, drone := range detectInfo.Description {
		if drone.Source == 0 {
			drone = DetectCheckInputNum(drone)
			//1-敌军 2-友军 3-未知 4-中立     批量导入为2友军
			var role int32
			for _, info := range whiteList.WhiteList {
				if info.Sn == ByteToString(drone.SerialNum[:]) {
					role = info.Role
				}
			}
			if role == ERRTYPE {
				role = ENEMY
			}
			r := &client.GimbalCounterDetectDroneInfo{
				ProductType:        int32(drone.ProductType),
				DroneName:          ByteToString(drone.DroneName[:]),
				SerialNum:          ByteToString(drone.SerialNum[:]),
				DroneLongitude:     float64(drone.DroneLongitude) / DroneTion,
				DroneLatitude:      float64(drone.DroneLatitude) / DroneTion,
				DroneHeight:        float64(drone.DroneHeight) / DroneHeightTion,
				DroneYawAngle:      float64(drone.DroneYawAngle) / DroneYawTion,
				DroneSpeed:         float64(drone.DroneSpeed) / DroneSpeedTion,
				DroneVerticalSpeed: float64(drone.DroneVerticalSpeed) / DroneVerticalSpeedTion,
				SpeedDirection:     int32(drone.SpeedDerection) / DroneSpeedTion,
				DroneSailLongitude: float64(drone.DroneSailLongitude) / DroneSailLongitudeTion,
				DroneSailLatitude:  float64(drone.DroneSailLatitude) / DroneSailLatitudeTion,
				PilotLongitude:     float64(drone.PilotLongitude) / DroneTion,
				PilotLatitude:      float64(drone.PilotLatitude) / DroneTion,
				DroneHorizon:       float64(drone.DroneHorizon) / DroneHorizonTion,
				DronePitch:         float64(drone.DronePitch) / DronePitch,
				UFreq:              float64(drone.UFreq) / DetectFreqTion,
				UDistance:          int32(drone.UDistance),
				UDangerLevels:      int32(drone.UDangerLevels),
				Role:               role,
				UZC:                int32(drone.Uzc),
			}
			logger.Infof("agx Detect data: %v", r)
			dataInfo.List = append(dataInfo.List, r)
		}
	}

	msg := &client.SflDetectInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      devSn, //agxSn
			Sn:        devSn, //agxSn
			EquipType: int32(common.DEV_AGX),
			MsgType:   mavlink.AgxTransferDevMsg,
		},
		Data: dataInfo,
	}
	msgOut, err := proto.Marshal(msg)
	if err != nil {
		logger.Error("marshal msg err:", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIdAgxTransferSflDetectMsg,
		Data:    msgOut,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	_ = mq.AgxMsgBroker.Publish(mq.AgxTopic, broker.NewMessage(out))

	logger.Infof("agx Transfer SFL Detect has reported, devSn: %v, Drone size: %v", devSn, msg.Data)
}

// AgxSelectUav 发送选中无人机Agx
func (d *Agx) AgxSelectUav(req *client.AgxSelectUavRequest) (int32, error) {

	request := &mavlink.AgxSendSelectUavRequest{}

	buff := request.Create(req)

	logger.Debugf("Agx Select Uav buff:", buff)
	logger.Debugf("Agx Select Uav buff: %x\n", buff)

	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("Agx Select Uav err: ", err)
		return Fail, err
	}
	logger.Debug("Agx Send Agx Select Uav Suc")
	return Success, nil
}

// AgxSelectSflUav Agx 发送选中Sfl探测到的无人机
func (d *Agx) AgxSelectSflUav(req *client.AgxSelectSflUavRequest) (int32, error) {

	request := &mavlink.AgxSendSelectSflUavRequest{}

	buff := request.Create(req)

	logger.Debugf("Agx Select Sfl Uav buff:", buff)

	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("Agx Select Uav err: ", err)
		return Fail, err
	}
	manager, ok := d.WaitTaskMap[mavlink.AgxSendMsgSfl]
	if !ok {
		manager = NewWaitTaskManager(mavlink.AgxSendMsgSfl, true, 0)
		d.WaitTaskMap[mavlink.AgxSendMsgSfl] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Agx to Sfl Send Hit Uav info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.AgxSendSelectSflUavResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}

	logger.Debug("Agx Send Sfl Select Uav Suc")
	return int32(res.Status), nil
}
func (d *Agx) ReceiveAgxSelectSflUav() {
	logger.Info("-->into Receive Agx Select Sfl Uav ")
	res := &mavlink.AgxSendSelectSflUavResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveAgxSelectSflUav  接收到Sfl信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.AgxSendMsgSfl]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// AgxCalibration Agx发送标定
func (d *Agx) AgxCalibration(req *client.AgxCalibrationRequest) (int32, error) {

	request := &mavlink.AgxSendCalibrationRequest{}

	buff := request.Create(req)

	logger.Debugf("Agx Calibration buff:", buff)
	logger.Debugf("Agx Calibration buff: %x\n", buff)

	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("Agx Calibration err: ", err)
		return Fail, err
	}
	logger.Debug("Agx Send Agx Calibration Suc")
	return Success, nil
}

func (d *Agx) ReceiveAgxDeviceStatusRes() {
	logger.Info("-->Into Receive Agx Dev Status")
	devSn := d.getSn()
	result := &mavlink.AgxDevStateResult{}
	if err := d.UnmarshalAgxDevState(result); err != nil {
		logger.Errorf(err.Error())
		return
	}
	if devSn != "" {
		if isEnable := d.updateStatus(devSn); isEnable == common.DeviceDisenable {
			logger.Infof("Agx device %v disable", devSn)
			return
		}
		d.agxDevStateReport(devSn, result)
	}
	logger.Info("--->End Receive Agx Detect")
}

func (d *Agx) UnmarshalAgxDevState(data *mavlink.AgxDevStateResult) error {
	deviceInfoLen := binary.Size(mavlink.AgxDevStateInfo{})
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}

	start := mavlink.HeaderLen + deviceInfoLen
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializeDrone(d.Msg[start:end]); err != nil {
		return err
	}

	return nil
}

func (d *Agx) agxDevStateReport(devSn string, result *mavlink.AgxDevStateResult) {
	logger.Info("--->Into Receive agx  Dev State Report")
	agxResult := make([]*client.AgxDeviceSn, 0)

	for _, agx := range result.Description {
		r := &client.AgxDeviceSn{
			DevType: int32(agx.DevType),
			DevSn:   ByteToString(agx.DevSn[:]),
		}
		logger.Infof("agx Dev sn Info data: %+v", *r)
		agxResult = append(agxResult, r)
	}

	dataInfo := &client.AgxDevStateInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      devSn,
			Sn:        devSn,
			EquipType: int32(common.DEV_AGX),
			MsgType:   mavlink.AgxMsgDeviceStatus,
		},
		Data: &client.AgxDevStateList{
			Sn:   devSn,
			List: agxResult,
		},
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIdAgxDevStatusData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}
	_ = mq.AgxMsgBroker.Publish(mq.AgxTopic, broker.NewMessage(out))

	radarList := make([]*client.RadarDevList, 0)
	for _, radar := range agxResult {
		radarList = append(radarList, &client.RadarDevList{Sn: radar.DevSn})
	}
	err = NewEquipList().UpdateRadarStatus(context.Background(), &client.UpdateRadarStatusReq{List: radarList}, &client.UpdateRadarStatusRes{})
	if err != nil {
		logger.Error("Update Radar Status err: ", err)
		return
	}

	logger.Infof("Agx has dev sn reported, devSn: %v, data info %v", devSn, dataInfo)
}

func (d *Agx) ReceiveAgxPTZStatusRes() {
	logger.Info("-->Into Receive Agx PTZ Status")
	devSn := d.getSn()
	result := &mavlink.AgxPTZStateResultData{}
	if err := d.UnmarshalAgxPTZState(result); err != nil {
		logger.Errorf(err.Error())
		return
	}
	if isEnable := d.updateStatus(devSn); isEnable == common.DeviceDisenable {
		logger.Infof("Agx device %v disable", devSn)
		return
	}
	d.agxPTZStateReport(devSn, result)
	logger.Info("--->End Receive Agx PTZ data")
}

func (d *Agx) ReceiveAgxCalibrationResultRes() {
	logger.Info("-->Into Receive Agx Calibration Result")
	devSn := d.getSn()
	result := &mavlink.ReceiveAgxCalibrationResultData{}
	if err := d.UnmarshalAgxCalibration(result); err != nil {
		logger.Errorf(err.Error())
		return
	}
	if isEnable := d.updateStatus(devSn); isEnable == common.DeviceDisenable {
		logger.Infof("Agx device %v disable", devSn)
		return
	}
	d.agxCalibrationReport(devSn, result)
	logger.Info("--->End Receive Agx PTZ data")
}

func (d *Agx) UnmarshalAgxPTZState(data *mavlink.AgxPTZStateResultData) error {
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("Agx UnmarshalAgxPTZState write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("Sfl UnmarshalAgxPTZState read data err: %v", err)
	}

	return nil
}

func (d *Agx) UnmarshalAgxCalibration(data *mavlink.ReceiveAgxCalibrationResultData) error {
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("Agx UnmarshalAgxPTZState write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("Sfl UnmarshalAgxPTZState read data err: %v", err)
	}

	return nil
}

func (d *Agx) agxPTZStateReport(devSn string, result *mavlink.AgxPTZStateResultData) {
	logger.Info("--->Into Receive agx  PTZ State Report")
	dataInfo := &client.AgxPTZStateInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      devSn,
			Sn:        devSn,
			EquipType: int32(common.DEV_AGX),
			MsgType:   mavlink.AgxMsgPTZStatus,
		},
		Data: &client.AgxPTZStateList{
			Sn:           ByteToString(result.Info.SnName[:]),
			TimeStamp:    int64(result.Info.TimeStamp),
			PtzLongitude: result.Info.PtzLongitude,
			PtzLatitude:  result.Info.PtzLatitude,
			PtzHeight:    result.Info.PtzHeight,
			Azimuth:      result.Info.Azimuth,
			Elevation:    result.Info.Elevation,
			OmegaAz:      result.Info.OmegaAz,
			OmegaEl:      result.Info.OmegaEl,
			Zoom:         result.Info.Zoom,
		},
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIdAgxPTZStatusData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}
	_ = mq.AgxMsgBroker.Publish(mq.AgxTopic, broker.NewMessage(out))

	logger.Infof("Agx PTZ has dev sn reported, data info %v", dataInfo)
}

func (d *Agx) agxCalibrationReport(devSn string, result *mavlink.ReceiveAgxCalibrationResultData) {
	logger.Info(" agxCalibrationReport result.Info ,", result.Info)
	dataInfo := &client.AgxPTZCalibrationInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      devSn,
			Sn:        devSn,
			EquipType: int32(common.DEV_AGX),
			MsgType:   mavlink.AgxCalibrationResult,
		},
		Data: &client.AgxCalibration{
			Flag:         result.Info.Flag,
			AzimuthOff:   result.Info.AzimuthOff,
			ElevationOff: result.Info.ElevationOff,
		},
	}
	logger.Debug("dataInfo: ", dataInfo)
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIdAgxCalibrationData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}
	_ = mq.AgxMsgBroker.Publish(mq.AgxTopic, broker.NewMessage(out))

	logger.Infof("Agx PTZ has dev sn reported, data info %v", dataInfo)
}

func AgxOffLineEventReport(sn string) {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_AGX, sn)
	eventId := ""

	if cache, ok := DevStatusMapOnEvent.Load(cacheKey); ok {
		dev := cache.(*Device)
		eventId = utils.GetEventId(dev.SessionId)

	} else {
		logger.Infof("not exist on event status context, sn: %v", sn)
		return
	}
	DevStatusMapOnEvent.Delete(cacheKey)

	dataInfo := &client.AgxHeartBeatInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      sn,
			Sn:        sn,
			EquipType: int32(common.DEV_AGX),
			MsgType:   mavlink.AgxEventOffOnLine,
		},
		Data: &client.AgxHeartBeatReport{
			Sn:       sn,
			IsOnline: common.DevOffline,
			EventId:  eventId,
		},
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgAgxStatusEventData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Infof("agx Offline event report: %v", report)
}

func AgxPtzLockEventReport(detectInfo *DetectEvent, eventId string, sn string) {
	if detectInfo == nil {
		return
	}

	var lockUavByPtz uint8 = 0
	var msgType = int32(mavlink.AgxEventPtzLockUavFail)

	if detectInfo.Items != nil && len(detectInfo.Items) > 0 {
		lockUavByPtz = 1
		logger.Infof("ptz lock uav succ, sn: %v", sn)
	}

	lockedItem := []*client.AgxPtzLockedItem{}
	if lockUavByPtz == 1 {
		msgType = mavlink.AgxEventPtzLockUavSucc

		for _, uav := range detectInfo.Items {
			if uav == nil {
				continue
			}
			lockedItem = append(lockedItem, &client.AgxPtzLockedItem{
				DroneName:  uav.DroneName,
				SerialNum:  strconv.FormatInt(int64(uav.ObjectId), 10),
				Longitude:  uav.Longitude,
				Latitude:   uav.Latitude,
				LockedTime: uav.LockedTime.UnixMilli(),
			})
		}
	}

	dataInfo := &client.AgxPtzLockInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      sn,
			Sn:        sn,
			EquipType: int32(common.DEV_AGX),
			MsgType:   msgType,
		},
		Data:    lockedItem,
		EventId: eventId,
	}

	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgAgzPtzLockEventData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}
	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Infof("agx ptz lock event status: %v,  report: %v", lockUavByPtz, dataInfo)

}
func AgxDetectDisappearEventReport(sn string) {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_AGX, sn)
	eventId := ""
	cache, ok := DevDetectMapOnEvent.Load(cacheKey)
	if !ok {
		return
	}

	dev, exist := cache.(*DetectEvent)
	if dev == nil || !exist {
		logger.Errorf("not exist agx DetectEvent, cache key: %v", cacheKey)
		return
	}

	eventId = utils.GetEventId(dev.SessionId)
	AgxPtzLockEventReport(dev, utils.GetEventId(dev.LockPtzSessionId), sn)

	DevDetectMapOnEvent.Delete(cacheKey)
	var detectInfo []*client.AgxDetectInfoList

	dataInfo := &client.AgxDetectInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      sn,
			Sn:        sn,
			EquipType: int32(common.DEV_AGX),
			MsgType:   mavlink.AgxEventDetectDisappear,
		},
		Data:    detectInfo,
		EventId: eventId,
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgAgxDetectEventData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}
	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Infof("agx detect disappear event report: %v", dataInfo)
}

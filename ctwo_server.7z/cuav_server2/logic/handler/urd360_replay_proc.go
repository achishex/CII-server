package handler

import (
	"errors"
	"fmt"
	"time"

	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
	jsoniter "github.com/json-iterator/go"
	broker2 "go-micro.dev/v4/broker"
	"gorm.io/gorm"
)

var (
	errMsgType = errors.New("error msg type")
	errDevType = errors.New("error device type")
)

// UrdSpectrumSDB ..数据订阅后使用byte存储，使用时候再做解析
type UrdSpectrumSDB struct {
	ID         int64  `gorm:"primarykey"`
	SN         string `json:"sn"`
	Data       []byte `gorm:"type:blob"`
	CreateTime int64  `json:"create_time"` //创建时间
}

// UrdDroneInfoReplay .. detect
type UrdDroneInfoReplay struct {
	TbID             int64   `json:"tb_id" gorm:"primarykey"`
	SN               string  `json:"sn"`
	ID               int32   `json:"id"`
	UniqueID         string  `json:"unique_id"`
	TargetInfoLength int32   `json:"target_info_length"`
	TargetInfo       string  `json:"target_info"`
	StationID        int32   `json:"station_id"`
	TargetAzimuth    int32   `json:"target_azimuth"`
	TargetRange      int32   `json:"target_range"`
	Longitude        float32 `json:"longitude"`
	Latitude         float32 `json:"latitude"`
	Height           int32   `json:"height"`
	Frequency        float64 `json:"frequency"`       // 目标频率 单位：kHz
	Bandwidth        float64 `json:"bandwidth"`       // 带宽 单位：kHz
	SignalStrength   float64 `json:"signal_strength"` // 信号强度 单位：db
	Trust            int8    `json:"trust"`           // 置信度
	Time             string  `json:"time"`            // 发现时间
	DataType         int8    `json:"data_type"`       // 数据类型
	Modulation       int8    `json:"modulation"`      // 调制方式
	CreateTime       int64   `json:"create_time"`     //创建时间
}

// UrdSpectrumRepaly spectrum
type UrdSpectrumRepaly struct {
	X []int32
	Y []int32
}

// UrdStatusRepaly heart 心跳数据
type UrdStatusRepaly struct {
	TbID              int64   `json:"tb_id" gorm:"primarykey;AUTO_INCREMENT"`
	ID                int     `json:"id"`
	SN                string  `json:"sn"`
	Name              string  `json:"name"`
	Longitude         float32 `json:"longitude"`
	Latitude          float32 `json:"latitude"`
	Height            int32   `json:"height"`
	Status            int16   `json:"status"`
	Azimuth           int32   `json:"azimuth"`
	Type              int32   `json:"type"`
	CompassStatus     int8    `json:"compass_status"`
	GpsStatus         int8    `json:"gps_status"`
	ReceiverStatus    int8    `json:"receiver_status"`
	AntennaStatus     int8    `json:"antenna_status"`
	AntennaCoverRange int32   `json:"antenna_cover_range"`
	CreateTime        int64   `json:"create_time"` //创建时间戳格式  "2006-01-02 15:04:05.000"  // 对应的时间格式
}

// insertUrdToDb
func insertUrdToDb(db *gorm.DB, tname string, stor UrdDroneInfoReplay) error {
	insertRet := db.Table(tname).Create(&stor)
	if insertRet.Error != nil {
		err := db.Table(tname).AutoMigrate(&UrdDroneInfoReplay{})
		if err != nil {
			logger.Debug("create table %s fail,err = %v", tname, err)
			return err
		}
		insertRet = db.Table(tname).Create(&stor)
		if insertRet.Error != nil {
			logger.Debug("insert data into table= %s fail,error = %v", tname, insertRet.Error)
		}
	}
	return nil
}

// func insertSpecToDb(db *gorm.DB, tname string, stor UrdSpectrumRepaly) error {
// 	insertRet := db.Table(tname).Create(&stor)
// 	if insertRet.Error != nil {
// 		err := db.Table(tname).AutoMigrate(&UrdSpectrumRepaly{})
// 		if err != nil {
// 			fmt.Printf("create table %s fail,err = %v", tname, err)
// 			return err
// 		}
// 		insertRet = db.Table(tname).Create(&stor)
// 		if insertRet.Error != nil {
// 			fmt.Printf("insert data into table= %s fail,error = %v", tname, insertRet.Error)
// 		}
// 	}
// 	return nil
// }

func insertStatusToDb(db *gorm.DB, tname string, stor UrdStatusRepaly) error {
	insertRet := db.Table(tname).Create(&stor)
	if insertRet.Error != nil {
		err := db.Table(tname).AutoMigrate(&UrdStatusRepaly{})
		if err != nil {
			fmt.Printf("create table %s fail,err = %v", tname, err)
			return err
		}
		insertRet = db.Table(tname).Create(&stor)
		if insertRet.Error != nil {
			fmt.Printf("insert data into table= %s fail,error = %v", tname, insertRet.Error)
		}
	}
	return nil
}

// ReplayDroneUrd360 drone 侦测信息 logic,process
func ReplayDroneUrd360(dbGorm *gorm.DB, data []byte) error {
	var box common.EquipmentMessageBoxEntity
	err := jsoniter.Unmarshal(data, &box)
	if err != nil {
		logger.Error("urd360 drone info box unmarshal error: ", err)
		return err
	}
	if box.MsgType != UrdDroneInfoType {
		return errMsgType
	}
	// logger.Debug("++++++++++++++++++++++++++++++++++++++++++> ReplayDroneUrd360 msgType =  ", box.MsgType)
	info := UrdDroneInfoUpload{}
	jInfo, err := jsoniter.Marshal(box.Info)
	if err != nil {
		logger.Error("jsoniter.Marshal ", err)
	}
	jsoniter.Unmarshal(jInfo, &info)

	dbinfo := UrdDroneInfoReplay{
		SN:               box.Sn,
		ID:               info.Id,
		UniqueID:         info.UniqueId,
		TargetInfoLength: info.TargetInfoLength,
		TargetInfo:       info.TargetInfo,
		StationID:        info.StationId,
		TargetAzimuth:    info.TargetAzimuth,
		TargetRange:      info.TargetRange,
		Longitude:        info.Longitude,
		Latitude:         info.Latitude,
		Height:           info.Height,
		Frequency:        info.Frequency,
		Bandwidth:        info.Bandwidth,
		SignalStrength:   info.SignalStrength,
		Trust:            info.Trust,
		Time:             info.Time,
		DataType:         info.DataType,
		Modulation:       info.Modulation,
		CreateTime:       time.Now().UnixMilli(),
	}

	tname := TableName(box.Sn, box.MsgType)
	record := bean.RecordList{
		DevType:         int32(common.DEV_URD360),
		DetectTableName: tname,
	}
	if err := db.GetDB().Table(bean.RecordList{}.TableName()).Create(&record).Error; err != nil {
		logger.Errorf("Write To Db RecordList data, urd360 write to db fail, e: %v", err)
	}
	return insertUrdToDb(dbGorm, tname, dbinfo)
}

// ReplayUrd360Specturm logic,process
func ReplayUrd360Specturm(db *gorm.DB, data []byte) error {
	var box common.EquipmentMessageBoxEntity
	err := jsoniter.Unmarshal(data, &box)
	if err != nil {
		logger.Error("urd360 drone info box unmarshal error: ", err)
		return err
	}

	sliceInfo, err := jsoniter.Marshal(box.Info)
	if err != nil {
		logger.Error("jsoniter.Marshal ", err)
	}
	// logger.Debug("ReplayUrd360Specturm===============> dbinfo", sliceInfo)
	tname := TableName(box.Sn, box.MsgType)

	return insertSpecToDb(db, tname, sliceInfo, box.Sn)
}

// ReplayUrd360Status logic,process
func ReplayUrd360Status(db *gorm.DB, data []byte) error {
	var box common.EquipmentMessageBoxEntity

	err := jsoniter.Unmarshal(data, &box)
	if err != nil {
		logger.Error("urd360 status box unmarshal error: ", err)
		return err
	}
	// logger.Debug("---------------------------------------------> ReplayUrd360Status msgType =  ", box.MsgType)
	if box.EquipType != int(common.DEV_URD360) {
		return errDevType
	}
	if box.MsgType != UrdDeviceInfoType {
		return errMsgType
	}
	info := UrdDeviceInfoUpload{}
	jInfo, err := jsoniter.Marshal(box.Info)
	if err != nil {
		logger.Error("jsoniter.Marshal ", err)
	}

	jsoniter.Unmarshal(jInfo, &info)
	sn := box.Sn
	dbinfo := UrdStatusRepaly{
		SN:                sn,
		ID:                int(info.Id),
		Name:              info.Name,
		Longitude:         info.Longitude,
		Latitude:          info.Latitude,
		Height:            info.Height,
		Status:            info.Status,
		Azimuth:           info.Azimuth,
		Type:              info.Type,
		CompassStatus:     info.CompassStatus,
		GpsStatus:         info.GpsStatus,
		ReceiverStatus:    info.ReceiverStatus,
		AntennaStatus:     info.AntennaStatus,
		AntennaCoverRange: info.AntennaCoverRange,
		CreateTime:        time.Now().UnixMilli(),
	}

	tname := TableName(box.Sn, box.MsgType)
	return insertStatusToDb(db, tname, dbinfo)
}
func consumeReplayUrd360() {
	mq.RFURDBroker.Subscribe(mq.RFURD360DroneInfoTopic, func(event broker2.Event) error {
		return ReplayDroneUrd360(db.GetDB(), event.Message().Body)
	})
	mq.RFURDBroker.Subscribe(mq.RFURD360SpecturmTopic, func(event broker2.Event) error {
		return ReplayUrd360Specturm(db.GetDB(), event.Message().Body)
	})
	mq.RFURDBroker.Subscribe(mq.RFURD360StatusTopic, func(event broker2.Event) error {
		return ReplayUrd360Status(db.GetDB(), event.Message().Body)
	})
}

// store as slice
// insertUrdToDb
func insertSpecToDb(db *gorm.DB, tname string, data []byte, sn string) error {
	ctime := time.Now().UnixMilli()
	stor := UrdSpectrumSDB{Data: data, CreateTime: ctime, SN: sn}
	insertRet := db.Table(tname).Create(&stor)
	if insertRet.Error != nil {
		err := db.Table(tname).AutoMigrate(&UrdSpectrumSDB{})
		if err != nil {
			fmt.Printf("create table %s fail,err = %v", tname, err)
			return err
		}
		insertRet = db.Table(tname).Create(&stor)
		if insertRet.Error != nil {
			fmt.Printf("insert data into table= %s fail,error = %v", tname, insertRet.Error)
		}
	}
	return nil
}

// // ReplayRawUrd360 logic,process
// func ReplayRawUrd360(db *gorm.DB, data []byte) error {
// 	var box common.EquipmentMessageBoxEntity
// 	err := jsoniter.Unmarshal(data, &box)
// 	if err != nil {
// 		logger.Error("urd360 drone info box unmarshal error: ", err)
// 		return err
// 	}
// 	tname := TableName(box.Sn, box.MsgType)
// 	return insertUrdRawToDb(db, tname, data, box.Sn)
// }

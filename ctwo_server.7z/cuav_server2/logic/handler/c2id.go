package handler

import (
	"context"
	"errors"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
	"gorm.io/gorm"
)

type C2UId struct {
}

func NewC2Id() *C2UId {
	return &C2UId{}
}
func (w *C2UId) Insert(ctx context.Context, req *client.C2IdInsertReq, res *client.C2IdInsertRsp) error {
	var model bean.C2Id

	model.C2Id = req.C2Id

	// logger.Info("Into Insert Log ID")

	var c2id bean.C2Id
	if err := db.GetDB().Model(&bean.C2Id{}).Where("id = ?", 1).First(&c2id).Error; err != nil {
		if err == gorm.ErrRecordNotFound {
			if err := db.GetDB().Model(&bean.C2Id{}).Create(&model).Error; err != nil {
				logger.Errorf("create c2id error: %v", err)
				return err
			}
			return nil
		}
		logger.Errorf("query c2id error:", err)
		return err
	}
	return nil
}

func (w *C2UId) List(ctx context.Context, req *client.C2IdListReq, rsp *client.C2IdListRsp) error {
	var model bean.C2Id
	err := db.GetDB().Model(&bean.C2Id{}).Find(&model).Error
	if err != nil {
		return errors.New("query C2 Id failed")
	}
	rsp.C2Id = model.C2Id
	return nil
}

func GetDevGuid() string {
	machGuid := ""
	c2id := &client.C2IdListRsp{}
	err := NewC2Id().List(context.Background(), &client.C2IdListReq{}, c2id)
	if err != nil {
		logger.Error("Cloud Platorm List C2Id err:", err)
	}

	if c2id.C2Id != "" {
		machGuid = c2id.C2Id
	}
	// logger.Info("c2id machGuid:", machGuid)
	return machGuid
}

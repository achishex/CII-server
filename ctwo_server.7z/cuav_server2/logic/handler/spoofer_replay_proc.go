package handler

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/config"
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/helper"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"

	"sync"
	"time"

	jsoniter "github.com/json-iterator/go"
	"go-micro.dev/v4/broker"
)

func consumeReplaySpooferHeartInfo() {
	heartEntities := make([]bean.SpooferReplayHeartData, 0, batchSize)
	mu := sync.Mutex{}

	_, _ = mq.NSF4000Broker.Subscribe(mq.NSF4000Topic, func(event broker.Event) error {
		entity := common.EquipmentMessageBoxEntity{}
		if err := jsoniter.Unmarshal(event.Message().Body, &entity); err != nil {
			logger.Errorf("consume spoofer Unmarshal error: %v", err)
			return err
		}

		if entity.EquipType != int(common.DEV_NSF4000) {
			return nil
		}
		if entity.MsgType != config.NSF4000TypeOnline {
			return nil
		}

		d, err := jsoniter.Marshal(entity.Info)
		if err != nil {
			logger.Error("NSF4000 Induce remarshal error: ", err)
			return err
		}

		dataInfo := NSF4000Msg{}
		if err := jsoniter.Unmarshal(d, &dataInfo); err != nil {
			logger.Errorf("parse spoofer heart info fail, e: %v", err)
			return err
		}
		if dataInfo.IsOnline != 1 {
			//is offline message
			return nil
		}
		sn := entity.Sn

		mu.Lock()
		defer mu.Unlock()

		heartEntities = append(heartEntities, bean.SpooferReplayHeartData{
			Sn:          sn,
			IsOnline:    dataInfo.IsOnline,
			IsWorking:   dataInfo.IsWorking,
			GpsStatus:   dataInfo.GpsStatus,
			Ephemeris:   dataInfo.Ephemeris,
			TimeSync:    dataInfo.TimeSync,
			Longititude: dataInfo.Longititude,
			Latitude:    dataInfo.Latitude,
			Height:      dataInfo.Height,
			CreateTime:  time.Now().UnixMilli(),
		})
		createBusiHeartTable[bean.SpooferReplayHeartData](db.GetDB(), sn, 0)
		if err := db.GetDB().Table(bean.SpooferReplayHeartData{}.GetTableName(sn)).Create(&heartEntities).Error; err != nil {
			logger.Errorf("consume spoofer heart data, write to db fail, e: %v", err)
		}
		heartEntities = helper.ClearSlice[bean.SpooferReplayHeartData](heartEntities)
		return nil
	})
}

func consumeReplaySpooferHeartInfoLLH() {
	heartEntities := make([]bean.SpooferReplayHeartData, 0, batchSize)
	mu := sync.Mutex{}

	_, _ = mq.NSF4000Broker.Subscribe(mq.NSF4000TopicLLH, func(event broker.Event) error {
		entity := common.EquipmentMessageBoxEntity{}
		if err := jsoniter.Unmarshal(event.Message().Body, &entity); err != nil {
			logger.Errorf("consume spoofer Unmarshal error: %v", err)
			return err
		}

		if entity.EquipType != int(common.DEV_NSF4000) {
			return nil
		}
		if entity.MsgType != config.NSF4000TypeOnline {
			return nil
		}

		d, err := jsoniter.Marshal(entity.Info)
		if err != nil {
			logger.Error("NSF4000 Induce remarshal error: ", err)
			return err
		}

		dataInfo := NSF4000Msg{}
		if err := jsoniter.Unmarshal(d, &dataInfo); err != nil {
			logger.Errorf("parse spoofer heart info fail, e: %v", err)
			return err
		}
		if dataInfo.IsOnline != 1 {
			//is offline message
			return nil
		}
		sn := entity.Sn

		mu.Lock()
		defer mu.Unlock()

		heartEntities = append(heartEntities, bean.SpooferReplayHeartData{
			Sn:          sn,
			IsOnline:    dataInfo.IsOnline,
			IsWorking:   dataInfo.IsWorking,
			GpsStatus:   dataInfo.GpsStatus,
			Ephemeris:   dataInfo.Ephemeris,
			TimeSync:    dataInfo.TimeSync,
			Longititude: dataInfo.Longititude,
			Latitude:    dataInfo.Latitude,
			Height:      dataInfo.Height,
			CreateTime:  time.Now().UnixMilli(),
		})
		createBusiHeartTable[bean.SpooferReplayHeartData](db.GetDB(), sn, 0)
		if err := db.GetDB().Table(bean.SpooferReplayHeartData{}.GetTableName(sn)).Create(&heartEntities).Error; err != nil {
			logger.Errorf("consume spoofer heart data, write to db fail, e: %v", err)
		}
		heartEntities = helper.ClearSlice[bean.SpooferReplayHeartData](heartEntities)
		return nil
	})
}

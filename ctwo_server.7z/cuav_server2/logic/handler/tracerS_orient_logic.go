package handler

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/proto/mavlink"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
	"bytes"
	"context"
	"errors"
	"fmt"
	"gorm.io/gorm"
	"strconv"
	"sync"
	"time"
)

// 数据库状态值
const (
	TracerSBeginOrienting = 1 // 1: 开始定向且未定向到无人机，
	TracerSOriented       = 2 // 2：已经定向无人机
)

// 请求定向的操作枚举
const (
	TracerSOrientOpExit  = 0 //退出定向
	TracerSOrientOpEntry = 1 //进入定向
)

// 定向过程中，c2 后端内部状态
const (
	// StatusFirstDetectOrient 第一次收到且方位角有值
	StatusFirstDetectOrient = 1
	// StatusAzimuthModify 方位角值有变更且最终不为0
	StatusAzimuthModify = 2
)

var (
	tracerSOrientSessionMng  *TracerSOrientationSessionMng
	tracerSOrientSessionOnce sync.Once
)

type OrientTracerSFreqDetectExpDesc mavlink.TracerSFreqDetectExpDesc

func (r *OrientTracerSFreqDetectExpDesc) String() string {
	var sBuf bytes.Buffer
	sBuf.Write([]byte("uavNumber: " + strconv.Itoa(int(r.UavNumber))))
	sBuf.Write([]byte(", drone name: " + string(r.DroneName[:])))
	sBuf.Write([]byte(", UFreq: " + strconv.Itoa(int(r.UFreq))))
	sBuf.Write([]byte(", DroneHorizon: " + strconv.FormatInt(int64(r.DroneHorizon), 10)))
	sBuf.Write([]byte(", IsSptOrient: " + strconv.Itoa(int(r.IsSptOrient))))
	sBuf.Write([]byte(", OrientState: " + strconv.Itoa(int(r.OrientState))))

	return sBuf.String()
}

func ReportOnOrientStatusImpl(detectInfo *mavlink.TracerSFreqDetectExpDesc) (error, bool) {
	if detectInfo == nil {
		return errors.New("input param is nil"), false
	}
	if detectInfo.IsSptOrient == 0 { //0: 不支持
		logger.Infof("not support orient, detectInfo: %v", (*OrientTracerSFreqDetectExpDesc)(detectInfo))
		return nil, false
	}
	if detectInfo.DroneHorizon < 0 || detectInfo.DroneHorizon > 36000 { //0x7fffffff
		logger.Debugf("not valid freq detect data: %v", (*OrientTracerSFreqDetectExpDesc)(detectInfo))
		return nil, false
	}

	////6：水平瞄准中; //9：瞄准完成
	//if detectInfo.OrientState != 6 && detectInfo.OrientState != 9 {
	//	logger.Infof("not entry orient status, detectInfo: %v", (*OrientTracerSFreqDetectExpDesc)(detectInfo))
	//	return nil, false
	//}
	return nil, true
}
func CheckItemExistInLocalImpl(sn string, self *TracerSOrientationSessionMng, detectInfo *mavlink.TracerSFreqDetectExpDesc) (error, bool) {
	if self == nil || detectInfo == nil {
		logger.Errorf("input params is nil")
		return errors.New("input params is nil"), false
	}

	self.SessionLocker.Lock()
	defer self.SessionLocker.Unlock()

	item, ok := self.Tasks[sn]
	if !ok || item == nil {
		return nil, false
	}

	if item.Sn != sn || item.DroneNumber != detectInfo.UavNumber {
		logger.Errorf("report detect info not exist orient session, sn: %v, report detect: %v, local item: %v",
			sn, (*OrientTracerSFreqDetectExpDesc)(detectInfo), item)
		return nil, false
	}
	return nil, true
}
func CheckLocalEntryOrientImpl(sn string, self *TracerSOrientationSessionMng, detectInfo *mavlink.TracerSFreqDetectExpDesc) (error, uint8) {
	if self == nil || detectInfo == nil {
		return errors.New("is nil"), 0
	}

	self.SessionLocker.Lock()
	defer self.SessionLocker.Unlock()

	item, ok := self.Tasks[sn]
	if !ok || item == nil {
		return nil, 0
	}

	if item.Status == TracerSBeginOrienting {
		if detectInfo.DroneHorizon > 0 {
			logger.Infof("receive droneHorizon not req 0, status trans to StatusFirstDetectOrient")
			return nil, StatusFirstDetectOrient
		}
	}

	if item.Status == TracerSOriented {
		if detectInfo.DroneHorizon != item.Azimuth && (detectInfo.DroneHorizon > 0 && item.Azimuth > 0) {
			logger.Infof("receive drone horizon: %v, not eq local azimuth: %v, status trans to StatusAzimuthModify",
				detectInfo.DroneHorizon, item.Azimuth)
			return nil, StatusAzimuthModify
		}
	}

	return nil, 0
}

func TracerSOrientInstance() *TracerSOrientationSessionMng {
	tracerSOrientSessionOnce.Do(func() {
		tracerSOrientSessionMng = &TracerSOrientationSessionMng{
			SessionLocker: new(sync.RWMutex),
			Tasks:         make(map[string]*TracerSOrientationSession),
			//
			ReportOnOrientStatus:  ReportOnOrientStatusImpl,
			CheckItemExistInLocal: CheckItemExistInLocalImpl,
			CheckLocalEntryOrient: CheckLocalEntryOrientImpl,
		}
	})
	return tracerSOrientSessionMng
}

type TracerSOrientationSession struct {
	Id          int32
	Sn          string
	DroneNumber uint32
	DroneName   string
	Azimuth     int32
	Freq        uint32 // mhz
	Status      uint8
}

func (s *TracerSOrientationSession) String() string {
	if s == nil {
		return ""
	}

	var sBuf bytes.Buffer
	sBuf.Write([]byte("Id: " + strconv.Itoa(int(s.Id))))
	sBuf.Write([]byte(", sn: " + s.Sn))
	sBuf.Write([]byte(", drone number: " + strconv.Itoa(int(s.DroneNumber))))
	sBuf.Write([]byte(", drone name: " + s.DroneName))
	sBuf.Write([]byte(", azimuth: " + strconv.Itoa(int(s.Azimuth))))
	sBuf.Write([]byte(", freq: " + strconv.Itoa(int(s.Freq))))
	sBuf.Write([]byte(", status: " + strconv.Itoa(int(s.Status))))

	return sBuf.String()
}

func (s *TracerSOrientationSession) CheckParameter() bool {
	if s == nil {
		return false
	}
	if len(s.Sn) <= 0 {
		logger.Infof("sn is empty")
		return false
	}
	if s.DroneNumber < 0 {
		logger.Errorf("drone number less 0")
		return false
	}
	if len(s.DroneName) <= 0 {
		logger.Errorf("drone name is empty")
		return false
	}
	if s.Freq <= 0 {
		logger.Errorf("freq less than 0")
		return false
	}

	logger.Infof("check tracerS orient session ok.")
	return true
}

type WriteLogToDbFuncCB = func(*bean.TracerSOrientLog, *gorm.DB) error

type TracerSOrientationSessionMng struct {
	SessionLocker *sync.RWMutex
	Tasks         map[string]*TracerSOrientationSession //key is: tracerS sn, 每个tracerS只能进入一个无人机定向模式

	ReportOnOrientStatus  func(*mavlink.TracerSFreqDetectExpDesc) (error, bool)
	CheckItemExistInLocal func(string, *TracerSOrientationSessionMng, *mavlink.TracerSFreqDetectExpDesc) (error, bool)
	//1. 第一次检测到水平角度 2. 监测到的水平角有变动且非0
	CheckLocalEntryOrient func(string, *TracerSOrientationSessionMng, *mavlink.TracerSFreqDetectExpDesc) (error, uint8)
}

// DoTracerSOrientLog 对定向任务做逻辑处理，包括进入定向和退出定向。
func (o *TracerSOrientationSessionMng) DoTracerSOrientLog(cond int32, op uint8,
	sess *TracerSOrientationSession, cb WriteLogToDbFuncCB) {

	if cond == 0 { // 0: fail, 1: succ
		return
	}

	if op == TracerSOrientOpExit { //exit orient mode
		o.DelOrientTask(sess)

	} else if op == TracerSOrientOpEntry { // entry orient mode
		o.AddNewOrientTask(sess, cb)

	} else {
		logger.Infof("not support op for orient")
	}
}

// AddNewOrientTask 向当前定向任务集添加一个新的定向任务。
func (o *TracerSOrientationSessionMng) AddNewOrientTask(sess *TracerSOrientationSession, writeDb WriteLogToDbFuncCB) {
	if sess == nil {
		return
	}

	if !sess.CheckParameter() {
		logger.Errorf("check session fail")
		return
	}

	if writeDb != nil {
		nowTm := time.Now().UnixMilli()

		dataItem := &bean.TracerSOrientLog{
			Sn:          sess.Sn,
			DroneNumber: sess.DroneNumber,
			DroneName:   sess.DroneName,
			Freq:        sess.Freq, //mHz
			CreateTime:  nowTm,
			UpdateTime:  nowTm,
			Status:      int32(sess.Status),
		}

		if wRet := writeDb(dataItem, db.GetDB()); wRet != nil {
			logger.Errorf("write to db fail, err: %v, data: %v", wRet, sess)
			return
		}

		//这里单独一份内存copy，解决多协程下对同一指针指向内容的访问。
		var tmpValue *TracerSOrientationSession = &TracerSOrientationSession{
			Id:          int32(dataItem.Id),
			Sn:          dataItem.Sn,
			DroneNumber: dataItem.DroneNumber,
			DroneName:   dataItem.DroneName,
			Freq:        dataItem.Freq, // mhz
			Status:      uint8(dataItem.Status),
		}

		{
			o.SessionLocker.Lock()
			defer o.SessionLocker.Unlock()

			o.Tasks[sess.Sn] = tmpValue
			logger.Infof("update orient to local session, value: %v", tmpValue)
		}
	}
}

// DelOrientTask 删除一个tracerS对应定向任务
func (o *TracerSOrientationSessionMng) DelOrientTask(sess *TracerSOrientationSession) {
	if sess == nil {
		return
	}

	o.SessionLocker.Lock()
	defer o.SessionLocker.Unlock()

	if _, ok := o.Tasks[sess.Sn]; ok {
		delete(o.Tasks, sess.Sn)
		logger.Infof("del orient task in: %v", sess)
	}
}

// DoOrientLogicOnDetect 根据tracerS 上报中携带的定向信息，更新内存数据和数据数据
func (o *TracerSOrientationSessionMng) DoOrientLogicOnDetect(tracerSn string, detectInfo *mavlink.TracerSFreqDetectExpDesc) {
	if detectInfo == nil || len(tracerSn) <= 0 {
		return
	}

	err, isOrient := o.ReportOnOrientStatus(detectInfo)
	if err != nil {
		logger.Errorf("check report on orient status fail,e: %v", err)
		return
	}
	if !isOrient {
		logger.Debugf("report current status not on orient")
		return
	}

	err, isExist := o.CheckItemExistInLocal(tracerSn, o, detectInfo)
	if err != nil {
		logger.Errorf("check report drone status not exist in fail")
		return
	}
	if !isExist {
		return
	}

	err, status := o.CheckLocalEntryOrient(tracerSn, o, detectInfo)
	if err != nil {
		logger.Errorf("check local orient entry to")
		return
	}

	if status == StatusFirstDetectOrient {
		o.UpdateStatusOnDB(tracerSn, detectInfo, db.GetDB())

	} else if status == StatusAzimuthModify {
		o.InsertNewItemToDB(tracerSn, detectInfo, db.GetDB())

	} else {
		return
	}
}

func (o *TracerSOrientationSessionMng) UpdateStatusOnDB(sn string, detectInfo *mavlink.TracerSFreqDetectExpDesc, db *gorm.DB) {
	if db == nil || detectInfo == nil {
		return
	}

	o.SessionLocker.Lock()
	defer o.SessionLocker.Unlock()

	item, ok := o.Tasks[sn]
	if !ok || item == nil {
		logger.Debugf("dev sn not op orient, sn: %v", sn)
		return
	}

	if item.Id <= 0 {
		logger.Errorf("insert primary key is less 0")
		return
	}

	ret := db.Table(bean.TracerSOrientLog{}.TableName()).Where("id", item.Id).Updates(
		map[string]interface{}{"status": TracerSOriented, "azimuth": detectInfo.DroneHorizon, "update_time": time.Now().UnixMilli()},
	)

	if ret.Error != nil {
		logger.Errorf("update data status to: TracerSOriented fail, e: %v, field item: %v", ret.Error, item)
		return
	}

	// update local status and value
	logger.Infof("update db status from %v to %v, azimuth: %v", item.Status, TracerSOriented, detectInfo.DroneHorizon)
	item.Status = TracerSOriented
	item.Azimuth = detectInfo.DroneHorizon

	return
}

func (o *TracerSOrientationSessionMng) InsertNewItemToDB(sn string, detectInfo *mavlink.TracerSFreqDetectExpDesc,
	db *gorm.DB) {

	if db == nil || detectInfo == nil {
		return
	}

	o.SessionLocker.Lock()
	defer o.SessionLocker.Unlock()

	item, ok := o.Tasks[sn]
	if !ok || item == nil {
		logger.Debugf("dev sn not op orient, sn: %v", sn)
		return
	}

	var toInsertItem *bean.TracerSOrientLog = &bean.TracerSOrientLog{
		Sn:          sn,
		DroneNumber: detectInfo.UavNumber,
		DroneName:   string(detectInfo.DroneName[:]),
		Freq:        detectInfo.UFreq,        //mHz
		Azimuth:     detectInfo.DroneHorizon, //水平角
		CreateTime:  time.Now().UnixMilli(),  //毫秒
		UpdateTime:  time.Now().UnixMilli(),  //毫秒
		Status:      TracerSOriented,         // 1: 开始定向且无人机， 2: 定向无人机
	}

	if err := WriteDBForOrient(toInsertItem, db); err != nil {
		logger.Errorf("insert data to db fail, err: %v, sn: %v, droneNumber: %v, droneName: %v, freq: %v, azimuth: %v",
			err, sn, detectInfo.UavNumber, string(detectInfo.DroneName[:]), detectInfo.UFreq, detectInfo.DroneHorizon)
		return
	}

	item.Id = int32(toInsertItem.Id)
	item.Sn = toInsertItem.Sn
	item.DroneNumber = toInsertItem.DroneNumber
	item.DroneName = toInsertItem.DroneName
	item.Azimuth = toInsertItem.Azimuth
	item.Freq = toInsertItem.Freq
	item.Status = TracerSOriented

	logger.Infof("insert new item to db and update to local, item: %v", item)
	return
}

func (o *TracerSOrientationSessionMng) QueryOrientRecordItems(
	req *client.TracerSOrientationDroneReq,
	res *client.TracerSOrientationDroneResponse) error {

	if len(req.GetSn()) <= 0 {
		return errors.New("req sn is empty")
	}

	var items []*bean.TracerSOrientLog = []*bean.TracerSOrientLog{}
	ret := db.GetDB().Table(bean.TracerSOrientLog{}.TableName()).Where(&bean.TracerSOrientLog{
		Sn: req.GetSn()}, "sn").Where("create_time >= ? and create_time <= ?",
		req.BeginTime, req.EndTime).Find(&items)

	if ret.Error != nil {
		logger.Errorf("query fail, e: %v", ret.Error)
		return errors.New("query db fail")
	}

	res.Sn = req.Sn
	for _, item := range items {
		if item == nil {
			continue
		}
		//只获取定向成功的历史记录
		if item.Status == TracerSOriented {
			res.DroneList = append(res.DroneList, &client.OrientationDroneItem{
				UavNumber:  int32(item.DroneNumber),
				DroneName:  item.DroneName,
				Freq:       float64(item.Freq) / FreqPrecision,
				Azimuth:    float64(item.Azimuth) / DroneHorizonPrecision,
				CreateTime: strconv.FormatInt(item.UpdateTime, 10),
			})
		}
	}
	return nil
}

// WriteDBForOrient 向db增加一条新记录
func WriteDBForOrient(logData *bean.TracerSOrientLog, db *gorm.DB) error {
	if logData == nil || db == nil {
		return errors.New("session obj or db is nil")
	}

	ret := db.Table(bean.TracerSOrientLog{}.TableName()).Create(logData)
	if ret.Error != nil {
		logger.Errorf("write data to db fail, e: %v, item: %v", ret.Error, logData)
		return fmt.Errorf("write db fail, e: %v", ret.Error)
	}
	return nil
}

func (e *DeviceCenter) GetOrientRecordItems(_ context.Context,
	req *client.TracerSOrientationDroneReq,
	res *client.TracerSOrientationDroneResponse) error {

	if len(req.GetBeginTime()) <= 0 || len(req.GetEndTime()) <= 0 {
		return errors.New("input beginTime or endTime is nil")
	}

	beginTime, err := strconv.ParseInt(req.GetBeginTime(), 10, 64)
	if err != nil || beginTime <= 0 {
		return fmt.Errorf("input beginTime parsed from string to int64 fail, e: %v", err)
	}

	endTime, err := strconv.ParseInt(req.GetEndTime(), 10, 64)
	if err != nil || endTime <= 0 {
		return fmt.Errorf("input endTime parsed from string to int64 fail, e: %v", err)
	}

	cond, err := time.ParseDuration("4.5h")
	if err != nil || time.UnixMilli(endTime).Sub(time.UnixMilli(beginTime)) > cond {
		return fmt.Errorf("endTime large than beginTime 4.5 h")
	}
	return TracerSOrientInstance().QueryOrientRecordItems(req, res)
}

package handler

import (
	"context"
	"time"

	"adasgitlab.autel.com/tools/cuav_plugin/broker"
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"

	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/proto/mavlink"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
)

var (
	ReplayApi   = new(Replay)
	StopCacheDB = 0
)

type Replay struct {
	PlaybackCancel func()
}

func (p *Replay) Replay(ctx1 context.Context, req *client.ReplayReq, res *client.ReplayRes) error {
	StopCacheDB = 1
	req.LoopEnable = true
	var ctx context.Context
	ctx, p.PlaybackCancel = context.WithCancel(context.Background())
	radarDataCache := NewRadarTcpDataCache()
	var offset, limit int
	if req.PlotTracks.Limit == 62389 {
		offset = 0
		limit = 325
	} else if req.PlotTracks.Limit == 19304 {
		offset = 452
		limit = 190
	} else if req.PlotTracks.Limit == 14657 {
		offset = 652
		limit = 300
	}

	plotTracks, trackCounts, err := radarDataCache.TrackTargetList(ctx, offset, limit)
	if err != nil {
		logger.Error("replay get plotTracks err :", err)
	}
	postures, err := radarDataCache.PostureList(ctx, 0, 5000)
	if err != nil {
		logger.Error("replay get postures err :", err)
	}
	statusList, err := radarDataCache.HeartList(ctx, 0, 1100)
	if err != nil {
		logger.Error("replay get statusList err :", err)
	}

	// 发送数据
	go func() {
		t := time.NewTicker(time.Millisecond * 1000)
		defer t.Stop()
		length := len(plotTracks)
	plotLoop:
		index := 0
		for _, count := range trackCounts {
			select {
			case <-ctx.Done():
				return
			case <-t.C:
				if index+count-1 > length {
					continue
				}
				msg := common.EquipmentMessageBoxEntity{
					Sn:        plotTracks[index].Sn,
					MsgType:   mavlink.RadarIdUploadTrackInfo,
					EquipType: int(common.DEV_RADAR),
					Info:      plotTracks[index : index+count],
				}
				_ = mq.RadarTrackBroker.Publish(mq.RadarTrackTopic, broker.NewMessage(msg))
				index = index + count
			}
		}
		if req.LoopEnable {
			goto plotLoop
		}
	}()
	var longitude float64
	var latitude float64
	configInfo := &client.ConfigRes{}
	err = NewSystemConfig().GetSystemConfig(context.Background(), &client.ConfigReq{}, configInfo)
	if err != nil {
		logger.Error("Get SystemConfig err: ", err)
	}
	if configInfo.C2Longitude == -180 || configInfo.C2Latitude == -180 {
		go func() {
		postureLoop:
			for _, h := range postures {
				select {
				case <-ctx.Done():
					return
				default:
					h.Heading = 45.0
					msg := common.EquipmentMessageBoxEntity{
						Sn:        h.Sn,
						MsgType:   mavlink.RadarIdUploadPosture,
						EquipType: int(common.DEV_RADAR),
						Info:      h,
					}
					_ = mq.RadarPostureBroker.Publish(mq.RadarPostureTopic, broker.NewMessage(msg))
					time.Sleep(time.Millisecond * 200)
				}
			}
			if req.LoopEnable {
				goto postureLoop
			}
		}()
	} else {
		longitude = configInfo.C2Longitude
		latitude = configInfo.C2Latitude
		go func() {
		postureLoop:
			for _, h := range postures {
				select {
				case <-ctx.Done():
					return
				default:
					h.Latitude = latitude
					h.Longitude = longitude
					h.Heading = 45.0
					msg := common.EquipmentMessageBoxEntity{
						Sn:        h.Sn,
						MsgType:   mavlink.RadarIdUploadPosture,
						EquipType: int(common.DEV_RADAR),
						Info:      h,
					}
					_ = mq.RadarPostureBroker.Publish(mq.RadarPostureTopic, broker.NewMessage(msg))
					time.Sleep(time.Millisecond * 200)
				}
			}
			if req.LoopEnable {
				goto postureLoop
			}
		}()
	}

	go func() {
	statusLoop:
		for _, h := range statusList {
			select {
			case <-ctx.Done():
				temp := bean.RadarTcpHeart{
					Id:          0,
					Sn:          h.Sn,
					Electricity: 0,
					Status:      0,
					IsOnline:    0,
				}
				msg := common.EquipmentMessageBoxEntity{
					Sn:        h.Sn,
					EquipType: int(common.DEV_RADAR),
					MsgType:   mavlink.RadarIdHeartbeat,
					Info:      temp,
				}
				_ = mq.EquipmentStatusBroker.Publish(mq.EquipmentStatusTopic, broker.NewMessage(msg))
				return
			default:
				msg := common.EquipmentMessageBoxEntity{
					Sn:        h.Sn,
					EquipType: int(common.DEV_RADAR),
					MsgType:   mavlink.RadarIdHeartbeat,
					Info:      h,
				}
				_ = mq.EquipmentStatusBroker.Publish(mq.EquipmentStatusTopic, broker.NewMessage(msg))
				time.Sleep(time.Millisecond * 500)
			}

		}
		if req.LoopEnable {
			goto statusLoop
		}
	}()
	return nil
}

func (p *Replay) ReplayStop(ctx context.Context, req *client.ReplayStopReq, res *client.ReplayStopRes) error {
	StopCacheDB = 0
	if p.PlaybackCancel != nil {
		p.PlaybackCancel()
	}
	return nil
}

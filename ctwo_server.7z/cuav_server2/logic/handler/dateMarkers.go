package handler

import (
	"adasgitlab.autel.com/tools/cuav_plugin/broker"
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
	"context"
	"errors"
	"fmt"
	baseTm "time"
)

type DateMarkers struct {
}

func NewDateMarkers() *DateMarkers {
	return &DateMarkers{}
}
func (w *DateMarkers) QueryAllDateTime(ctx context.Context, _ *client.DateMarkersDateTimeReq, res *client.DateMarkersDateTimeRsp) error {

	var timeYMD []int64
	err := db.GetDB().Model(&bean.DateMarkers{}).Select("creat_time").Find(&timeYMD).Error
	if err != nil {
		logger.Errorf("query all item on create time fail, e: %v", err)
		return err
	}
	logger.Infof("get all create items nums: %v", len(timeYMD))

	var filter map[string]bool = make(map[string]bool)
	for _, v := range timeYMD {
		if v <= 0 {
			continue
		}

		tmstr := baseTm.Unix(v, 0).Format("2006-01-02")

		if _, ok := filter[tmstr]; !ok {
			filter[tmstr] = true
			res.DateTimeItem = append(res.DateTimeItem, tmstr)
		}
	}

	logger.Infof("after filter repeated ymd items nums: %v", len(res.DateTimeItem))
	return nil
}

func (w *DateMarkers) Insert(ctx context.Context, req *client.DateMarkersInsertReq, res *client.DateMarkersInsertRsp) error {
	var model bean.DateMarkers
	model.TimeStamp = req.Timestamp
	model.Level = req.Level
	model.Tips = req.Tips
	model.CreatTime = req.CreatTime

	logger.Info("Into Insert Date Markers")
	if err := db.GetDB().Model(&bean.DateMarkers{}).Create(&model).Error; err != nil {
		logger.Errorf("create Date Markers error: %v", err)
		return err
	}
	report := &bean.DateMarkers{
		TimeStamp: req.Timestamp,
		Level:     req.Level,
		Tips:      req.Tips,
		CreatTime: req.CreatTime,
	}
	entity := &common.EquipmentMessageBoxEntity{
		Name:      "",
		Sn:        "",
		MsgType:   1,
		EquipType: int(common.DEV_C2_WIFI),
		Info:      report,
	}
	_ = mq.EquipmentStatusBroker.Publish(mq.DataReplayMarkTopic, broker.NewMessage(entity))
	return nil
}
func (w *DateMarkers) Update(ctx context.Context, req *client.DateMarkersUpdateReq, rsp *client.DateMarkersUpdateRsp) error {
	var model bean.DateMarkers
	model.Level = req.Level

	r := db.GetDB().Model(&bean.DateMarkers{}).Where("time_stamp=?", req.Timestamp).Updates(&model).RowsAffected
	if r == 0 {
		return fmt.Errorf("update Date Markers error: timestamp=%v no-exist", req.Timestamp)
	}

	return nil
}

func (w *DateMarkers) Deletes(ctx context.Context, req *client.DateMarkersDeletesReq, rsp *client.DateMarkersDeletesRsp) error {
	var model bean.DateMarkers

	err := db.GetDB().Model(&bean.DateMarkers{}).Where("time_stamp = ?", req.Timestamp).Delete(&model).Error
	if err != nil {
		logger.Errorf("delete Date Markers error: %v", err)
	}
	report := &bean.DateMarkers{
		TimeStamp: req.Timestamp,
		Level:     req.Level,
		Tips:      req.Tips,
		CreatTime: req.CreatTime,
	}
	entity := &common.EquipmentMessageBoxEntity{
		Name:      "",
		Sn:        "",
		MsgType:   2,
		EquipType: int(common.DEV_C2_WIFI),
		Info:      report,
	}
	_ = mq.EquipmentStatusBroker.Publish(mq.DataReplayMarkTopic, broker.NewMessage(entity))
	return nil
}

func (w *DateMarkers) List(ctx context.Context, req *client.DateMarkersListReq, rsp *client.DateMarkersListRsp) error {
	var list []*bean.DateMarkers
	err := db.GetDB().Model(&bean.DateMarkers{}).Where("creat_time >= ? and creat_time <= ?", req.StartTime, req.StopTime).Find(&list).Error
	if err != nil {
		return errors.New("query list failed")
	}
	for _, v := range list {
		var model client.MarkersList
		w.generateRes(&model, *v)
		rsp.Markerslist = append(rsp.Markerslist, &model)
	}
	return nil
}
func (w *DateMarkers) generateRes(model *client.MarkersList, list bean.DateMarkers) {
	model.Id = list.Id
	model.Timestamp = list.TimeStamp
	model.Level = list.Level
	model.Tips = list.Tips
	model.CreatTime = list.CreatTime
}

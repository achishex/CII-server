package handler

import (
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/helper"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"context"
	"github.com/stretchr/testify/assert"
	"testing"
)

func TestHeartProcess(t *testing.T) {
	//test.LoggerMock()

	data := &DayTimeInfo{
		beginTime: 1703123994652,
		endTime:   1703123994653,
		mydString: "20231221",
	}

	heartProc := QueryDevListProcess{
		tabNameKey:  "_heart_", // %_heart_20231208
		dateTimeStr: data.mydString,
		beginTime:   data.beginTime,
		endTime:     data.endTime,
	}
	//
	fzName := heartProc.GetFuzzyTabName(context.Background())
	t.Logf("fuzzy table name: %v", fzName)

	tab := heartProc.GetMatchTabName(context.Background())
	t.Logf("tab: %s", tab)

	snList, workModes := heartProc.QueryDevList(context.Background())
	t.Logf("get sn List: %v, workModes: %v", snList, workModes)

	devTypeList := heartProc.QueryDevListType(context.Background(), snList, workModes)
	t.Logf("get dev type list: %v", devTypeList)
}

func TestDevTypeTrans(t *testing.T) {
	testDemos := []struct {
		devTypeInt  int32
		wantTypeStr string
		//
		wantTypeInt int32
		devTypeStr  string
	}{
		{
			devTypeInt:  int32(client.EnumDevTypeList_RadarDevTypeEnum),
			wantTypeStr: helper.DevTypeDescRadar,

			//
			wantTypeInt: int32(client.EnumDevTypeList_RadarDevTypeEnum),
			devTypeStr:  helper.DevTypeDescRadar,
		},
		{
			devTypeInt:  int32(client.EnumDevTypeList_TracerPDevTypeEnum),
			wantTypeStr: helper.DevTypeDescTraceP,

			wantTypeInt: int32(client.EnumDevTypeList_TracerPDevTypeEnum),
			devTypeStr:  helper.DevTypeDescTraceP,
		},
		{
			devTypeInt:  int32(client.EnumDevTypeList_TracerSDevTypeEnum),
			wantTypeStr: helper.DevTypeDescTracerS,

			wantTypeInt: int32(client.EnumDevTypeList_TracerSDevTypeEnum),
			devTypeStr:  helper.DevTypeDescTracerS,
		},
		{
			devTypeInt:  int32(client.EnumDevTypeList_FpvDevTypeEnum),
			wantTypeStr: helper.DevTypeDescFpv,

			wantTypeInt: int32(client.EnumDevTypeList_FpvDevTypeEnum),
			devTypeStr:  helper.DevTypeDescFpv,
		},
		{
			devTypeInt:  int32(client.EnumDevTypeList_GunDevTypeEnum),
			wantTypeStr: helper.DevTypeDescRF,

			wantTypeInt: int32(client.EnumDevTypeList_GunDevTypeEnum),
			devTypeStr:  helper.DevTypeDescRF,
		},
		{
			devTypeInt:  int32(client.EnumDevTypeList_SFLDevTypeEnum),
			wantTypeStr: helper.DevTypeDescSfl,

			wantTypeInt: int32(client.EnumDevTypeList_SFLDevTypeEnum),
			devTypeStr:  helper.DevTypeDescSfl,
		},
		{
			devTypeInt:  int32(client.EnumDevTypeList_SpooferDevTypeEnum),
			wantTypeStr: helper.DevTypeDescSpoofer,

			wantTypeInt: int32(client.EnumDevTypeList_SpooferDevTypeEnum),
			devTypeStr:  helper.DevTypeDescSpoofer,
		},
		{
			devTypeInt:  int32(client.EnumDevTypeList_UrdDevTypeEnum),
			wantTypeStr: helper.DevTypeDescTracerRF,

			wantTypeInt: int32(client.EnumDevTypeList_UrdDevTypeEnum),
			devTypeStr:  helper.DevTypeDescTracerRF,
		},
	}

	for _, v := range testDemos {
		t.Run("test", func(tt *testing.T) {
			tt.Logf("int -> str, %v -> %v", v.devTypeInt, helper.DevTypeFromIntToStr(v.devTypeInt))
			assert.Equal(tt, v.wantTypeStr, helper.DevTypeFromIntToStr(v.devTypeInt))
			tt.Logf("str -> int, %v -> %v", v.devTypeStr, helper.DevTypeFromStrToInt(v.devTypeStr))
			assert.Equal(tt, v.wantTypeInt, helper.DevTypeFromStrToInt(v.devTypeStr))
		})
	}
}

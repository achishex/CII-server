package handler

import (
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
	"sync"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/helper"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
	jsoniter "github.com/json-iterator/go"
	"go-micro.dev/v4/broker"
)

// urd heartbeat. deprecated
func consumerReplayTracerRFHeartInfo() {
	heartEntities := make([]bean.UrdReplayHeartData, 0, batchSize)
	mu := sync.Mutex{}

	_, _ = mq.RFURDBroker.Subscribe(mq.RFURD360StatusTopic, func(event broker.Event) error {
		entity := common.EquipmentMessageBoxEntity{}
		if err := jsoniter.Unmarshal(event.Message().Body, &entity); err != nil {
			logger.Errorf("consume urd Unmarshal error: %v", err)
			return err
		}
		if entity.EquipType != int(common.DEV_URD360) {
			return nil
		}
		if entity.MsgType != UrdDeviceInfoType {
			return nil
		}

		d, err := jsoniter.Marshal(entity.Info)
		if err != nil {
			logger.Error("NSF4000 Induce remarshal error: ", err)
			return err
		}

		dataInfo := UrdDeviceInfoUpload{}
		if err := jsoniter.Unmarshal(d, &dataInfo); err != nil {
			logger.Errorf("parse spoofer heart info fail, e: %v", err)
			return err
		}
		sn := entity.Sn // sn := strconv.Itoa(int(dataInfo.Id))???@fzw

		mu.Lock()
		defer mu.Unlock()

		heartEntities = append(heartEntities, bean.UrdReplayHeartData{
			Sn:                sn,
			Name:              dataInfo.Name,
			Longitude:         dataInfo.Longitude,
			Latitude:          dataInfo.Latitude,
			Height:            dataInfo.Height,
			Status:            dataInfo.Status,
			Azimuth:           dataInfo.Azimuth,
			Type:              dataInfo.Type,
			CompassStatus:     dataInfo.CompassStatus,
			GpsStatus:         dataInfo.GpsStatus,
			ReceiverStatus:    dataInfo.ReceiverStatus,
			AntennaStatus:     dataInfo.AntennaStatus,
			AntennaCoverRange: dataInfo.AntennaCoverRange,
			CreateTime:        time.Now().UnixMilli(),
		})
		createBusiHeartTable[bean.UrdReplayHeartData](db.GetDB(), sn, 0)
		if err := db.GetDB().Table(bean.UrdReplayHeartData{}.GetTableName(sn)).Create(&heartEntities).Error; err != nil {
			logger.Errorf("consume urd heart data, write to db fail, e: %v", err)
		}
		heartEntities = helper.ClearSlice[bean.UrdReplayHeartData](heartEntities)
		return nil
	})
}

package handler

import (
	"context"

	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"google.golang.org/protobuf/types/known/emptypb"
)

type Email struct {
}

func NewEmail() *Email {
	return &Email{}
}

func (s *Email) Send(ctx context.Context, req *client.SendReq, resp *client.SendRes) error {
	code, err := sdk.SendEmail(req.Email)
	if err != nil {
		return err
	}
	resp.Code = code
	return nil
}

func (s *Email) Verify(ctx context.Context, req *client.VerifyReq, resp *emptypb.Empty) error {
	err := sdk.CheckVerificationCode(req.Email, req.Code)
	if err != nil {
		return err
	}
	return nil
}

func (s *Email) Notify(ctx context.Context, req *client.NotifyReq, resp *client.SendRes) error {
	if err := sdk.NotifyEmail(req); err != nil {
		return err
	}

	return nil
}

package handler

import (
	"bytes"
	"context"
	"crypto/rand"
	"encoding/binary"
	"errors"
	"fmt"
	"math/big"
	"os"
	"strconv"
	"strings"
	"sync"
	"time"

	"adasgitlab.autel.com/tools/cuav_plugin/broker"
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/server"
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/ip"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/proto/mavlink"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
	"adasgitlab.autel.com/tools/slink_proto/slinkv1"
	"github.com/allegro/bigcache/v3"
	"google.golang.org/protobuf/proto"
)

const (
	FpvTcpPort        = 15000
	FpvServerMaxCount = 500
)

type Fpv struct {
	*Device
	dt common.DeviceType
}

var (
	FpvTcpServerLock sync.Mutex
	FpvTcpServerMap  sync.Map
	FpvHeartSum      uint8
)

func InspectFpvVideo(cacheBuf []byte, packetLen int) {
	if len(cacheBuf) < mavlink.HeaderLen+mavlink.DevSNLen+8+4 {
		return
	}

	if cacheBuf[mavlink.MsgIdLoc] == mavlink.FpvPushVideoStreams {
		frameIndex := GetFrameIndex(cacheBuf, mavlink.HeaderLen+mavlink.DevSNLen, mavlink.HeaderLen+mavlink.DevSNLen+4)
		pkgIndex := GetPkgIndex(cacheBuf, mavlink.HeaderLen+mavlink.DevSNLen+8, mavlink.HeaderLen+mavlink.DevSNLen+8+4)

		logger.Debugf("pkg data len: %v, frameIndex: %v, pkgIndex: %v, 处理buf: % x",
			packetLen, frameIndex, pkgIndex, cacheBuf[:packetLen])
	}
}
func NewFpv(conn Connection, d []byte, dataLen int, remoteIp string, remotePort int, localIp string, serverPort int,
	mailBox map[int]*WaitTaskManager) DeviceInterface {
	fpv := &Fpv{
		Device: &Device{
			Conn:        conn,
			Msg:         d,
			MsgLen:      dataLen,
			SourceId:    d[mavlink.SenderLoc],
			RemoteIp:    remoteIp,
			RemotePort:  remotePort,
			LocalIp:     localIp,
			ServerPort:  serverPort,
			WaitTaskMap: mailBox,
		},
		//video: VideoMsgFullPkg{
		//	videoBuf: make(map[int32]*FrameData),
		//},
	}
	return fpv
}

func (d *Fpv) Deal() {
	defer func() {
		if err := recover(); err != nil {
			logger.Error("Fpv deal 接收到panic:", err)
		}
	}()

	if d.MsgLen <= 0 {
		logger.Error("Fpv 数据为null,不作处理:", d.Device.RemoteIp)
		return
	}
	d.MsgId = int(d.Msg[mavlink.MsgIdLoc])
	switch d.MsgId {
	case mavlink.FpvMsgHeartbeat: //上报心跳
		d.Heart()
	case mavlink.FpvGetFreqDetectRes: //上报频谱侦测
		d.ReceiveFreqDetectRes()
	case mavlink.FpvSendHitCmd:
		d.ReceiveFpvSendHit()
	case mavlink.FpvSendStopHitCmd:
		d.ReceiveFpvSendStopHitCmd()

	case mavlink.FpvSendSetHitMode:
		d.ReceiveFpvSendSetHitMode()
	case mavlink.FpvSendGetHitMode:
		d.ReceiveFpvSendGetHitMode()

	case mavlink.FpvSendSetHitTime:
		d.ReceiveFpvSendSetHitTime()
	case mavlink.FpvSendGetHitTime:
		d.ReceiveFpvSendGetHitTime()
	case mavlink.FpvCliSend:
		d.ReceiveFpvCli()
	case mavlink.FpvGetVersionInfo:
		d.ReceiveGetVersionInfo()
	case mavlink.FpvIdGetVersionInfo:
		d.ReceiveFpvIdGetVersion()
	case mavlink.FpvIdRequestUpgrade:
		d.ReceiveFpvRequestUpgrade()
	case mavlink.FpvIdSendUpdatePkg:
		d.ReceiveFpvSendUpdatePkg()
	case mavlink.FpvIdVerifyImage:
		d.ReceiveFpvVerifyImage()
	case mavlink.FpvIdWriteUpdateData:
		d.ReceiveFpvWriteUpdateData()
	case mavlink.FpvIdGetUpdateWriteStatus:
		d.ReceiveFpvGetUpdateWriteStatus()
	case mavlink.FpvIdRunApp:
		d.ReceiveFpvRunApp()
	case mavlink.FpvPushVideoStreams:
		d.TransferVideoStream()
	case mavlink.TracerControlVideo:
		d.ProcVideoCmdResponse()

	default:
		logger.Error("Fpv 未知Fpv消息id:", d.MsgId)
		break
	}
}

// FpvOfflineReport FPV设备离线处理
func FpvOfflineReport(sn string) {
	var tcpServer *server.TcpServer
	if s, ok := FpvTcpServerMap.Load(sn); ok {
		tcpServer = s.(*server.TcpServer)

		if tcpServer != nil {
			tcpServer.Stop()
		}
		deviceUsedPorts.Delete(tcpServer.Port)
		FpvTcpServerMap.Delete(sn)
		DevSnMap.Delete(tcpServer.Port)
		cachekeyDroneid := fmt.Sprintf("%d_%s", common.DEV_FPV, sn)
		DevStatusMap.Delete(cachekeyDroneid)
		tcpServer = nil
	}
	dataInfo := &client.FpvHeartInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      sn,
			Sn:        sn,
			EquipType: int32(common.DEV_FPV),
			MsgType:   mavlink.FpvHeartReportMsg,
		},
		Data: &client.FpvHeartInfoReport{
			Sn:       sn,
			IsOnline: common.DevOffline,
		},
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIDFPVHeartBeat,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.FpvMsgBroker.Publish(mq.FpvTopic, broker.NewMessage(out))
	logger.Info("Fpv Offline report:", report)

}

// Heart 处理FPV发过来的心跳消息
func (d *Fpv) Heart() {
	heart := &mavlink.FpvHeartbeat{}
	if err := d.UnmarshalPayload(heart); err != nil {
		logger.Errorf(err.Error())
		return
	}

	devSn := ByteToString(heart.Info.SN[:])
	if devSn != "" {
		// update device status
		if isEnable := d.updateStatus(devSn); isEnable == common.DeviceDisenable {
			logger.Infof("Fpv device %v disable", devSn)
			return
		}
		// report heartbeat
		d.HeartReport(devSn, heart)
	}
}
func (d *Fpv) HeartReport(devSn string, heartInfo *mavlink.FpvHeartbeat) {
	dataInfo := &client.FpvHeartInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      devSn,
			Sn:        devSn,
			EquipType: int32(common.DEV_FPV),
			MsgType:   mavlink.FpvHeartReportMsg,
		},
		Data: &client.FpvHeartInfoReport{
			TimeStamp:     int32(heartInfo.Info.TimeStamp),
			Electricity:   int32(heartInfo.Info.Electricity),
			Sn:            devSn,
			IsOnline:      common.DevOnline,
			BatteryStatus: int32(heartInfo.Info.BatteryStatus),
			WorkMode:      int32(heartInfo.Info.WorkMode),
			WorkStatus:    int32(heartInfo.Info.WorkStatus),
			AlarmLevel:    int32(heartInfo.Info.AlarmLevel),
		},
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIDFPVHeartBeat,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.FpvMsgBroker.Publish(mq.FpvTopic, broker.NewMessage(out))
	logger.Infof("heartbeat has reported, devSn: %v", devSn)
}

// HandleBroadCast 处理广播消息
func (d *Fpv) HandleBroadCast(ctx context.Context, req *slinkv1.UdpBroadcastConfirmRequest) (*slinkv1.UdpBroadcastConfirmResponse, error) {
	if req.GetSn() == "" {
		logger.Info("device sn empty")
		return nil, nil
	}

	if status := d.GetStatus(req.GetSn()); status == common.DeviceDisenable {
		logger.Infof("device %v disable", req.GetSn())
		return nil, nil
	}

	localIP := make([]string, 0)
	localIps, broadIps, err := ip.GetBroadcastAddress()
	if err != nil {
		logger.Error("Get IP error :%v", err)
	}
	for i, ip := range localIps {
		if i >= len(broadIps) {
			continue
		}
		localIP = append(localIP, ip)
	}
	logger.Debugf("[Fpv] localIP:%v,", localIP)

	tcpServer := d.TcpServerCheck(req.GetSn(), localIP)
	DevSnMap.Store(tcpServer.Port, req.GetSn())
	d.ServerPort = tcpServer.Port

	//响应
	rsp := &slinkv1.UdpBroadcastConfirmResponse{
		Sn:       req.Sn,
		Addr:     ip.IPV4(tcpServer.Ip),
		Port:     uint16(tcpServer.Port),
		ConnType: 1,
	}
	return rsp, nil
}

func (d *Fpv) GetStatus(sn string) int32 {
	statusRes := &client.GetStatusRes{}
	err := NewEquipList().GetStatus(context.Background(), &client.GetStatusReq{Sn: sn, EType: "Fpv"}, statusRes)
	if err != nil {
		logger.Errorf("GetStatus err: %v", err.Error())
		return 0
	}

	return statusRes.IsEnable
}

func (d *Fpv) TcpServerCheck(devSn string, localIP []string) *server.TcpServer {
	var tcpServer *server.TcpServer
	if s, ok := FpvTcpServerMap.Load(devSn); ok {
		tcpServer = s.(*server.TcpServer)
		isAlike := false
		for _, ip := range localIP {
			if ip == tcpServer.Ip {
				isAlike = true
			}
		}
		if isAlike == false { //查找的本地IP没有与之前相同的
			if tcpServer != nil {
				tcpServer.Stop()
			}
			deviceUsedPorts.Delete(tcpServer.Port)
			FpvTcpServerMap.Delete(devSn)
			DevSnMap.Delete(tcpServer.Port)
			tcpServer = nil
		}
	}

	//注册tcp服务
	if tcpServer == nil {
		port, err := ip.GetFreeTcpPort()
		if err != nil {
			logger.Error("Fpv tcp 获取可用端口失败：", err)
			port = d.getRandPort(FpvTcpPort, FpvTcpPort+FpvServerMaxCount)
		}
		tcpServer = server.NewTcpServer(port, Handle)
		FpvTcpServerMap.Store(devSn, tcpServer)
		tcpServer.ServerType = uint8(common.DEV_FPV)
		tcpServer.ServerName = devSn
		localAddr, _ := ip.GetLocalIp(d.UdpIp)
		tcpServer.Ip = localAddr
		go tcpServer.Start()
	}
	return tcpServer
}

func (d *Fpv) getRandPort(min, max int64) int {
	maxBigInt := big.NewInt(max)
	i, _ := rand.Int(rand.Reader, maxBigInt)
	_, ok := deviceUsedPorts.Load(i.Int64())
	port := i.Int64()
	//缓存不存在或者符合范围
	if !ok && (port > min && port < max) {
		deviceUsedPorts.Store(port, port)
		return int(port)
	}
	return d.getRandPort(min, max)
}

// ReceiveFreqDetectRes 收到Fpv频谱侦测结果
func (d *Fpv) ReceiveFreqDetectRes() {
	logger.Info("--->Into Receive Freq Detect Res")
	result := &mavlink.FpvFreqDetectResult{}
	if err := d.UnmarshalPayloadFreqDetectRes(result); err != nil {
		logger.Errorf(err.Error())
		return
	}

	devSn := ByteToString(result.Info.SN[:])
	if devSn != "" {
		if isEnable := d.updateStatus(devSn); isEnable == common.DeviceDisenable {
			logger.Infof("Fpv device %v disable", devSn)
			return
		}
		d.freqDetectReport(devSn, result)
	}
	logger.Info("--->End Receive Freq Detect Res")
}
func (d *Fpv) freqDetectReport(devSn string, detectInfo *mavlink.FpvFreqDetectResult) {
	logger.Info("--->Into Receive Freq Report Res")
	droneInfo := make([]*client.FpvDetect, 0)

	for _, drone := range detectInfo.Description {
		tempDroneHorizon := drone.DroneHorizon

		if tempDroneHorizon > MAXDroneHorizon {
			tempDroneHorizon = Invalid
		}
		r := &client.FpvDetect{
			UavNumber:     int32(drone.UavNumber),
			DroneName:     ByteToString(drone.DroneName[:]),
			DroneHorizon:  float64(tempDroneHorizon) / DroneHorizonPrecision,
			UFreq:         float64(drone.UFreq) / FreqPrecision,
			UDangerLevels: int32(drone.UDangerLevels),
		}
		logger.Infof("droneID Detect Freq data: %+v", *r)
		droneInfo = append(droneInfo, r)
	}

	dataInfo := &client.FpvDetectInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      devSn,
			Sn:        devSn,
			EquipType: int32(common.DEV_FPV),
			MsgType:   mavlink.FpvFreqReportMsg,
		},
		Data: &client.FpvDetectInfoReport{
			Sn:        devSn,
			QxPower:   float64(detectInfo.Info.QxPower),
			DxPower:   float64(detectInfo.Info.DxPower),
			DxHorizon: float64(detectInfo.Info.DxHorizon) / DroneHorizonPrecision,
			List:      droneInfo,
		},
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIDFPVFreq,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}
	_ = mq.FpvMsgBroker.Publish(mq.FpvTopic, broker.NewMessage(out))
	logger.Info("--->End Receive Freq Report Res")
	logger.Infof("Fpv Detect Freq has reported, devSn: %v, Drone size: %v", devSn, report)
}

func (d *Fpv) UnmarshalPayloadFreqDetectRes(data *mavlink.FpvFreqDetectResult) error {
	deviceInfoLen := binary.Size(mavlink.FpvFreqDetectInfo{})
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}

	start := mavlink.HeaderLen + deviceInfoLen
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializeDrone(d.Msg[start:end]); err != nil {
		return err
	}

	return nil
}

func (d *Fpv) ReceiveGetChannelReq() {
	FpvTcpServerLock.Lock()
	defer FpvTcpServerLock.Unlock()

	devSn := d.UnMarshalGetChannelReq()
	if devSn == "" {
		logger.Info("Fpv device sn empty")
		return
	}

	//if isContinue := d.deviceDiscover(devSn); !isContinue {
	//	logger.Error("droneID等待设备确认：", devSn)
	//	return
	//}

	if status := d.GetStatus(devSn); status == common.DeviceDisenable {
		logger.Infof("Fpv device %v disable", devSn)
		return
	}

	localIP := make([]string, 0)

	localIps, broadIps, err := ip.GetBroadcastAddress()
	if err != nil {
		logger.Error("Fpv Get IP error :%v", err)
	}
	for i, ip := range localIps {
		if i >= len(broadIps) {
			continue
		}
		localIP = append(localIP, ip)
	}
	logger.Debugf("[Fpv] localIP:%v,", localIP)

	tcpServer := d.TcpServerCheck(devSn, localIP)
	DevSnMap.Store(tcpServer.Port, devSn)
	d.ServerPort = tcpServer.Port

	//响应
	switch d.MsgId {
	case mavlink.FpvUdpBroadcastResponse:
		logger.Info("[Fpv] receive Broadcast BB Msg")
		UdpBroadcastSendChannel(devSn, d.UdpIp, d.SourceId, tcpServer)
		break
	default:
		break
	}

	return
}

// ReceiveFpvSendSetHitMode 接收设备返回设置工作模式响应
func (d *Fpv) ReceiveFpvSendSetHitMode() {
	res := &mavlink.FpvSendSetHitModeResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveFpvSendHitMode 获取信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.FpvSendSetHitMode]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// FpvSendSetHitMode 发送设置工作模式指令
func (d *Fpv) FpvSendSetHitMode(req *client.FpvSendSetHitModeRequest) (int32, error) {
	logger.Info("Fpv Send Hit Mode Start")
	defer func() {
		if r := recover(); r != nil {
			logger.Error("Fpv Send Mode Uav occurred:", r)
			return
		}
	}()
	request := &mavlink.FpvSendSetHitModeRequest{}
	buff := request.Create(uint8(req.HitMode))

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.FpvSendSetHitMode]
	if !ok {
		manager = NewWaitTaskManager(mavlink.FpvSendSetHitMode, true, time.Second*3)
		d.WaitTaskMap[mavlink.FpvSendSetHitMode] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("FpvSendHitMode buff:", buff)

	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("FpvSendHitMode 发送获取Fpv版本信息失败: ", err)
		return Fail, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return Fail, checkNetConnErr
		}
		return Fail, err
	}
	res := result.(*mavlink.FpvSendSetHitModeResponse)
	logger.Debugf("Fpv Send Set Hit Mode 获取Fpv结果：%#v", res)
	return int32(res.Status), nil
}

func (d *Fpv) ReceiveGetVersionInfo() {
	res := &mavlink.FpvSendGetVersionResponse{}
	d.GetPacket(res)
	logger.Debug("receive Fpv version info:%+v", *res)
	manager, ok := d.WaitTaskMap[mavlink.FpvGetVersionInfo]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// FpvSendGetVersion 发送获取版本信息
func (d *Fpv) FpvSendGetVersion() (*client.FpvSendGetVersionResponse, error) {
	logger.Info("Fpv Send get Version")
	request := &mavlink.FpvSendGetVersionRequest{}
	buff := request.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.FpvGetVersionInfo]
	if !ok {
		manager = NewWaitTaskManager(mavlink.FpvGetVersionInfo, true, time.Second*3)
		d.WaitTaskMap[mavlink.FpvGetVersionInfo] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("get Version buff:", buff)

	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("get Version 发送获取Fpv版本信息失败: ", err)
		return nil, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return nil, checkNetConnErr
		}
		return nil, err
	}
	res := result.(*mavlink.FpvSendGetVersionResponse)
	r := &client.FpvSendGetVersionResponse{}
	r.Company = ByteToString(res.CompanyName[:])
	r.Sn = ByteToString(res.DeviceSn[:])
	r.PsVersion = ByteToString(res.PsVersion[:])
	r.PlVersion = ByteToString(res.PlVersion[:])
	r.Ip = ByteToString(res.DeviceIP[:])
	logger.Debug("response droneID version result:%+v", *r)
	return r, nil
}

// ReceiveFpvSendGetHitMode 接收设备返回获取工作模式响应
func (d *Fpv) ReceiveFpvSendGetHitMode() {
	res := &mavlink.FpvSendGetHitModeResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveFpvSendGetHitMode 获取信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.FpvSendGetHitMode]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// FpvSendGetHitMode 发送获取工作模式指令
func (d *Fpv) FpvSendGetHitMode() (int32, error) {
	logger.Info("Fpv Send  Get Hit Mode Start")
	defer func() {
		if r := recover(); r != nil {
			logger.Error("Fpv Send Get Hit Mode occurred:", r)
			return
		}
	}()
	request := &mavlink.FpvSendGetHitModeRequest{}
	buff := request.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.FpvSendGetHitMode]
	if !ok {
		manager = NewWaitTaskManager(mavlink.FpvSendGetHitMode, true, time.Second*3)
		d.WaitTaskMap[mavlink.FpvSendGetHitMode] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Fpv Send Get Hit Mode buff:", buff)

	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("Fpv Send Get  Hit Mode 发送获取Fpv版本信息失败: ", err)
		return Fail, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return Fail, checkNetConnErr
		}
		return Fail, err
	}
	res := result.(*mavlink.FpvSendGetHitModeResponse)
	logger.Debugf("Fpv Send Get Hit Mode 获取Fpv结果：%#v", res)
	return int32(res.Status), nil
}

// ReceiveFpvSendHit 接收设备返回打击无人机响应
func (d *Fpv) ReceiveFpvSendHit() {
	res := &mavlink.FpvSendHitResponse{}
	d.GetPacket(res)
	logger.Debugf("Receive Fpv Send Hit 获取信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.FpvSendHitCmd]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// FpvSendHit 发送打击无人机指令
func (d *Fpv) FpvSendHit() (int32, error) {
	logger.Info("Fpv Send  Hit  Start")
	defer func() {
		if r := recover(); r != nil {
			logger.Error("Fpv Send Hit occurred:", r)
			return
		}
	}()
	request := &mavlink.FpvSendHitRequest{}
	buff := request.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.FpvSendHitCmd]
	if !ok {
		manager = NewWaitTaskManager(mavlink.FpvSendHitCmd, true, time.Second*3)
		d.WaitTaskMap[mavlink.FpvSendHitCmd] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Fpv Send  Hit  buff:", buff)

	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("Fpv Send   Hit  发送获取Fpv版本信息失败: ", err)
		return Fail, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return Fail, checkNetConnErr
		}
		return Fail, err
	}
	res := result.(*mavlink.FpvSendHitResponse)
	logger.Debugf("Fpv Send  Hit  获取Fpv结果：%#v", res)
	return int32(res.Status), nil
}

// ReceiveFpvSendStopHitCmd 接收设备返回停止打击响应
func (d *Fpv) ReceiveFpvSendStopHitCmd() {
	res := &mavlink.FpvSendStopHitResponse{}
	d.GetPacket(res)
	logger.Debugf("Receive Fpv Send Stop HitCmd 获取信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.FpvSendStopHitCmd]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// FpvSendStopHit 发送停止打击无人机指令
func (d *Fpv) FpvSendStopHit() (int32, error) {
	logger.Info("Fpv Send Stop Hit  Start")
	defer func() {
		if r := recover(); r != nil {
			logger.Error("Fpv Send Stop  Hit occurred:", r)
			return
		}
	}()
	request := &mavlink.FpvSendStopHitRequest{}
	buff := request.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.FpvSendStopHitCmd]
	if !ok {
		manager = NewWaitTaskManager(mavlink.FpvSendStopHitCmd, true, time.Second*3)
		d.WaitTaskMap[mavlink.FpvSendStopHitCmd] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Fpv Send Stop Hit  buff:\n", buff)

	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("Fpv Send  Stop Hit  发送获取Fpv版本信息失败: ", err)
		return Fail, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return Fail, checkNetConnErr
		}
		return Fail, err
	}
	res := result.(*mavlink.FpvSendStopHitResponse)
	logger.Debugf("Fpv Send Stop Hit  获取Fpv结果：%#v", res)
	return int32(res.Status), nil
}

// ReceiveFpvSendSetHitTime 接收设备返回设置打击时长响应
func (d *Fpv) ReceiveFpvSendSetHitTime() {
	res := &mavlink.FpvSetHitTimeResponse{}
	d.GetPacket(res)
	logger.Debugf("Receive Fpv Send Set HitTime 获取信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.FpvSendSetHitTime]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// FpvSendSetHitTime 发送设置打击无人机时长指令
func (d *Fpv) FpvSendSetHitTime(req *client.FpvSendSetHitTimeRequest) (int32, error) {
	logger.Info("Fpv Send Set Hit Time  Start")
	defer func() {
		if r := recover(); r != nil {
			logger.Error("Fpv Send Set Hit Time occurred:", r)
			return
		}
	}()
	request := &mavlink.FpvSetHitTimeRequest{}
	buff := request.Create(uint8(req.HitTime))

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.FpvSendSetHitTime]
	if !ok {
		manager = NewWaitTaskManager(mavlink.FpvSendSetHitTime, true, time.Second*3)
		d.WaitTaskMap[mavlink.FpvSendSetHitTime] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Fpv Send Set Hit Time  buff:", buff)

	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("Fpv Send  Set Hit Time  发送获取Fpv版本信息失败: ", err)
		return Fail, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return Fail, checkNetConnErr
		}
		return Fail, err
	}
	res := result.(*mavlink.FpvSetHitTimeResponse)
	logger.Debugf("Fpv Send Set Hit Time  获取Fpv结果：%#v", res)
	return int32(res.Status), nil
}

// ReceiveFpvSendGetHitTime 接收设备返回获取打击时长响应
func (d *Fpv) ReceiveFpvSendGetHitTime() {
	res := &mavlink.FpvGetHitTimeResponse{}
	d.GetPacket(res)
	logger.Debugf("Receive Fpv Send Get HitTime 获取信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.FpvSendGetHitTime]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// FpvSendGetHitTime 发送获取打击无人机时长指令
func (d *Fpv) FpvSendGetHitTime() (int32, error) {
	logger.Info("Fpv Send Get Hit Time  Start")
	defer func() {
		if r := recover(); r != nil {
			logger.Error("Fpv Send Get Hit Time occurred:", r)
			return
		}
	}()
	request := &mavlink.FpvGetHitTimeRequest{}
	buff := request.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.FpvSendGetHitTime]
	if !ok {
		manager = NewWaitTaskManager(mavlink.FpvSendGetHitTime, true, time.Second*3)
		d.WaitTaskMap[mavlink.FpvSendGetHitTime] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Fpv Send Get Hit Time  buff:", buff)

	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("Fpv Send  Get Hit Time  发送获取Fpv版本信息失败: ", err)
		return Fail, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return Fail, checkNetConnErr
		}
		return Fail, err
	}
	res := result.(*mavlink.FpvGetHitTimeResponse)
	logger.Debugf("Fpv Send Get Hit Time  获取Fpv结果：%#v", res)
	return int32(res.HitTime), nil
}

// SendFpvCli 发送请求Fpv  Cmd
func (d *Fpv) SendFpvCli(cmd string) ([]byte, error) {
	logger.Info("---> Send Tracer Cli")
	req := &mavlink.FpvCliRequest{
		Handle: 1,
		Cmd:    append([]byte(cmd), 0),
	}

	buff := req.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.FpvCliSend]
	if !ok {
		manager = NewWaitTaskManager(mavlink.FpvCliSend, true, 0)
		d.WaitTaskMap[mavlink.FpvCliSend] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Send Fpv Cli is :[%v]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send Fpv Cli err:[%v].Buff is [%v]", err, buff)
		return nil, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send Fpv Cli err %s", err.Error())
		return nil, err
	}
	res := result.(*mavlink.FpvCliResponse)

	logger.Info("-->End Set Fpv Cli")
	return res.CmdResult, nil
}

func (d *Fpv) ReceiveFpvCli() {
	res := &mavlink.FpvCliResponse{}
	var cmdRes []byte
	var status uint32
	var result uint32
	cmdRes = make([]byte, len(d.Msg)-14-mavlink.HeaderLen)
	err := mavlink.Read(bytes.NewReader(d.Msg[mavlink.HeaderLen+4:]), binary.LittleEndian, &status, 4)
	if err != nil {
		logger.Error("msg Decode Fpv Cli status err:%v", err)
		return
	}
	err = mavlink.Read(bytes.NewReader(d.Msg[mavlink.HeaderLen+8:]), binary.LittleEndian, &result, 4)
	if err != nil {
		logger.Error("msg Decode Fpv Cli result err:%v", err)
		return
	}

	err = mavlink.Read(bytes.NewReader(d.Msg[mavlink.HeaderLen+12:]), binary.LittleEndian, &cmdRes, len(d.Msg)-14-mavlink.HeaderLen)
	if err != nil {
		logger.Error("msg Decode Fpv Cli  cmdRes err:%v", err)
		return
	}
	logger.Info("cmdRes is :", cmdRes)

	resultCode := strconv.Itoa(int(result))
	resCmd := string(cmdRes)
	str := ""
	if status == 0 {
		str = "ok"
		resCmd = str + " " + resultCode + " " + resCmd
	} else {
		str = "fail"
		resCmd = str + " " + resultCode + " " + resCmd
	}
	logger.Info("resCmd is :", resCmd)

	res.CmdResult = []byte(resCmd)
	manager, ok := d.WaitTaskMap[mavlink.FpvCliSend]
	if ok {
		manager.CompletedTask(res, nil)
	}
	logger.Debugf("Receive Fpv Cli res.CmdResult is ", res.CmdResult)
	return
}

// SendFpvHeart 发送心跳消息给FPV
func SendFpvHeart() {
	ticker := time.NewTicker(time.Second * 1)
	defer ticker.Stop()
	for range ticker.C {
		DevStatusMap.Range(func(key, value interface{}) bool {
			dev := value.(*Device)
			if dev.DevType == common.DEV_FPV && dev.Status == common.DevOnline {
				reqMode := &Fpv{
					Device: dev,
					dt:     common.DEV_FPV,
				}
				reqMode.SendExtHeartbeat()
			}
			return true
		})
	}
}
func (d *Fpv) SendExtHeartbeat() error {
	FpvHeartSum++
	if FpvHeartSum > 255 {
		FpvHeartSum = 0
	}
	req := &mavlink.FpvHeartbeatExtRequest{
		FpvHeartSum,
	}
	reqBuff := req.CreateFpvHeartbeatExt()
	if d != nil && d.Conn != nil {
		n, err := d.Conn.Write(reqBuff)
		logger.Info("Fpv c2发送心跳结果：", FpvHeartSum, n, err, reqBuff)
		if err != nil {
			dataInfo := &client.FpvHeartInfo{
				Header: &client.EquipmentMessageBoxEntity{
					Name:      d.Sn,
					Sn:        d.Sn,
					EquipType: int32(common.DEV_FPV),
					MsgType:   mavlink.FpvHeartReportMsg,
				},
				Data: &client.FpvHeartInfoReport{
					Sn:       d.Sn,
					IsOnline: common.DevOffline,
				},
			}
			msg, err := proto.Marshal(dataInfo)
			if err != nil {
				logger.Error("marshal dataInfo err:", err)
				return err
			}
			report := &client.ClientReport{
				MsgType: common.ClientMsgIDFPVHeartBeat,
				Data:    msg,
			}
			out, err := proto.Marshal(report)
			if err != nil {
				logger.Error("marshal report err:", err)
				return err
			}
			_ = mq.FpvMsgBroker.Publish(mq.FpvTopic, broker.NewMessage(out))
			logger.Info("Fpv Offline report:", report)
		}
		return err
	}
	return nil
}

func (d *Fpv) GetPacket(message mavlink.Message) *mavlink.MavPacket {
	logger.Infof("Fpv GetPacket is [% x]", d.Msg)
	req := mavlink.NewNullPacket(message)
	buff := &bytes.Buffer{}
	if err := binary.Write(buff, binary.LittleEndian, d.Msg); err != nil {
		logger.Error("Fpv GetPacket write buff err:", err)
		return nil

	}
	if err := binary.Read(buff, binary.LittleEndian, &req.Header); err != nil {
		logger.Error("Fpv GetPacket read header err:", err)
		return nil
	}
	if err := binary.Read(buff, binary.LittleEndian, req.Msg); err != nil {
		logger.Error("Fpv GetPacket read msg err:", err)
		return nil
	}
	return req
}

func (d *Fpv) UnMarshalGetChannelReq() string {
	devSn := ""
	switch d.MsgId {
	case mavlink.FpvUdpBroadcastResponse:
		req := &mavlink.UdpBroadcastConfirmRequest{}
		d.GetPacket(req)
		devSn = strings.TrimRight(string(req.Sn[:]), string(rune(0)))
		break
	default:
		break
	}
	return devSn
}

func (d *Fpv) UnmarshalPayload(data *mavlink.FpvHeartbeat) error {
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("Fpv UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("Fpv UnmarshalPayload read data err: %v", err)
	}

	return nil
}

func (d *Fpv) updateStatus(sn string) int32 {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_FPV, sn)
	if cache, ok := DevStatusMap.Load(cacheKey); ok {
		dev := cache.(*Device)
		if dev.IsEnable == common.DeviceDisenable {
			return common.DeviceDisenable
		}
		dev.Status = common.DevOnline
		dev.Conn = d.Conn
		dev.WaitTaskMap = d.WaitTaskMap
		dev.RemoteIp = d.RemoteIp
		dev.LastHeartTime = time.Now()
		dev.GetStatusInterval = time.Now()
		if dev.IsEnable != common.DeviceDisenable && dev.IsEnable != common.DeviceEnable {
			dev.IsEnable = d.GetStatus(sn)
		}
		return dev.IsEnable
	} else {
		dev := &Device{
			Sn:                sn,
			Conn:              d.Conn,
			Status:            common.DevOnline,
			RemoteIp:          d.RemoteIp,
			RemotePort:        d.RemotePort,
			LocalIp:           d.LocalIp,
			ServerPort:        d.ServerPort,
			DevType:           common.DEV_FPV,
			FirstHeartTime:    time.Now(),
			LastHeartTime:     time.Now(),
			SourceId:          d.SourceId,
			IsEnable:          d.GetStatus(sn),
			GetStatusInterval: time.Now(),
			WaitTaskMap:       d.WaitTaskMap,
		}
		DevStatusMap.Store(cacheKey, dev)
		go func() {
			time.Sleep(time.Second * 2)
			if d.Conn == nil {
				return
			}
			runVer, appVer, bootVer, HwVer, protoVer, err := d.FpvGetVersionInfo()
			logger.Infof("fpv get  Ver: %v, %v, %v, %v, %v \n",
				runVer, appVer, bootVer, HwVer, protoVer)
			if err != nil {
				logger.Infof("fpv get  Ver runVer: %v err: %v \n", runVer, err)
			}
			if appVer != "" {
				err = NewEquipList().Update(context.Background(), &client.EquipCrudReq{
					Sn:         sn,
					DevVersion: appVer,
				}, &client.EquipCrudRes{})
				if err != nil {
					logger.Error("Update EquipList err: ", err)
				}
			}
		}()

		return dev.IsEnable
	}
}

type FrameData struct {
	bufFrame    bytes.Buffer
	totalBufLen int32
	//
	curPkgIndex int32
	maxPkgNums  int32
}

func (p *FrameData) write(buf []byte) error {
	n, e := p.bufFrame.Write(buf)
	if e != nil {
		logger.Errorf("write data to buf fail, e: %v", e)
		return e
	}
	p.totalBufLen += int32(n)
	//
	return nil
}
func (p *FrameData) read() []byte {
	r := p.bufFrame.Bytes()
	p.bufFrame.Reset()
	p.totalBufLen = 0

	return r
}

type VideoMsgFullPkg struct {
	videoBuf map[int32]*FrameData
}

func (v *VideoMsgFullPkg) WriteData(frameIndex int32, buf []byte, wCurIndex, maxIndex int32) {
	if len(buf) <= 0 {
		logger.Info("sub pkg len is 0")
		return
	}

	var frameBuf *FrameData
	if _, ok := v.videoBuf[frameIndex]; !ok {
		frameBuf = new(FrameData)
	} else {
		frameBuf = v.videoBuf[frameIndex]
	}

	frameBuf.curPkgIndex = wCurIndex
	frameBuf.maxPkgNums = maxIndex

	e := frameBuf.write(buf)
	if e != nil {
		logger.Errorf("write data to buf fail, e: %v", e)
		return
	}
	v.videoBuf[frameIndex] = frameBuf
}
func (v *VideoMsgFullPkg) IsFullPkg(frameIndex int32) bool {
	frameBuf, ok := v.videoBuf[frameIndex]
	if !ok || frameBuf == nil {
		logger.Errorf("frame index not find video buf, frameIndex: %v, ok: %v", frameIndex, ok)
		return false
	}
	if frameBuf.maxPkgNums <= 0 {
		logger.Errorf("frame buf max pkg nums: %v", frameBuf.maxPkgNums)
		return false
	}
	if frameBuf.curPkgIndex == frameBuf.maxPkgNums-1 {
		logger.Infof("is whole pkg, curPkgIndex: %v, maxPkgNums: %v", frameBuf.curPkgIndex, frameBuf.maxPkgNums)
		return true
	}
	return false
}
func (v *VideoMsgFullPkg) FetchWholeFrameData(frameIndex int32) []byte {
	if frameBuf, ok := v.videoBuf[frameIndex]; !ok {
		return nil
	} else {
		ret := frameBuf.read()
		delete(v.videoBuf, frameIndex)
		return ret
	}
}

type VideoIndex struct {
	FrameIndex  int32
	CurPkgIndex int32
	MaxPkgIndex int32
	//
	HasReceiveIndexes map[int32]any
}
type VideoIndexManager struct {
	lock sync.Mutex
	rel  map[int32]*VideoIndex
	//
	contentData *bigcache.BigCache
}

func (p *VideoIndexManager) GetKey(frameIndex, pkgIndex int32) string {
	key := fmt.Sprintf("%v:%v", frameIndex, pkgIndex)
	return key
}
func (p *VideoIndexManager) SetFramePkgIndex(frameIndex int32, pkgIndex, pkgMaxNums int32) {
	p.lock.Lock()
	defer p.lock.Unlock()

	if _, ok := p.rel[frameIndex]; !ok {
		p.rel[frameIndex] = new(VideoIndex)
		p.rel[frameIndex].HasReceiveIndexes = make(map[int32]any)
	}

	p.rel[frameIndex].HasReceiveIndexes[pkgIndex] = true
	p.rel[frameIndex].FrameIndex = frameIndex
	p.rel[frameIndex].CurPkgIndex = pkgIndex
	p.rel[frameIndex].MaxPkgIndex = pkgMaxNums
}
func (p *VideoIndexManager) IsFullPkg(frameIndex int32) bool {
	p.lock.Lock()
	defer p.lock.Unlock()

	if v, ok := p.rel[frameIndex]; !ok || v == nil {
		return false
	}

	if len(p.rel[frameIndex].HasReceiveIndexes) >= int(p.rel[frameIndex].MaxPkgIndex) {
		return true
	}
	return false
}
func (p *VideoIndexManager) SetData(frameIndex int32, pkgIndex int32, data []byte) {
	key := p.GetKey(frameIndex, pkgIndex)
	p.contentData.Set(key, data)
}
func (p *VideoIndexManager) GetData(frameIndex int32, pkgIndex int32) []byte {
	key := p.GetKey(frameIndex, pkgIndex)
	ret, err := p.contentData.Get(key)
	if err != nil {
		logger.Errorf("get pkg data fail, e: %v, pkg index: %v", err, pkgIndex)
		return nil
	}
	return ret
}
func (p *VideoIndexManager) DelData(frameIndex int32, pkgIndex int32) {
	key := p.GetKey(frameIndex, pkgIndex)
	p.contentData.Delete(key)
}
func (p *VideoIndexManager) DelFrameIndex(frameIndex int32) {
	p.lock.Lock()
	defer p.lock.Unlock()
	if _, ok := p.rel[frameIndex]; !ok {
		return
	}
	delete(p.rel, frameIndex)
}

var tmpBgCache, _ = bigcache.New(context.Background(),
	bigcache.Config{Shards: 1024,
		LifeWindow: 10 * time.Minute})

var FpvVideoFrameIndexMng = &VideoIndexManager{
	rel:         make(map[int32]*VideoIndex),
	contentData: tmpBgCache,
}

func GetFrameIndex(buf []byte, startIndex, endIndex int) uint32 {
	if len(buf) <= 0 {
		return 0
	}
	frameIndex := uint32(0)
	mavlink.Read(bytes.NewReader(buf[startIndex:endIndex]), binary.LittleEndian, &frameIndex, 4)
	return frameIndex
}

func GetPkgIndex(buf []byte, startIndex, endIndex int) uint32 {
	if len(buf) <= 0 {
		return 0
	}
	if len(buf) < endIndex {
		return 0
	}

	pkgIndex := uint32(0)
	mavlink.Read(bytes.NewReader(buf[startIndex:endIndex]), binary.LittleEndian, &pkgIndex, 4)
	return pkgIndex
}
func WriteOneFrameToFile(buf []byte, frameIndex uint32) {
	//os.File
	var fileName string = "/storage/emulated/0/Android/data/com.skyfend.cuav/files/Backend/log/fpv_video_catch_"
	suffixFile := frameIndex % 100
	fileName += fmt.Sprintf("%d.dat", suffixFile)
	if _, e := os.Stat(fileName); e == nil {
		os.Remove(fileName)
	}

	f, e := os.OpenFile(fileName, os.O_APPEND|os.O_WRONLY|os.O_CREATE, 0644)
	if e != nil {
		logger.Errorf("open file: %v fail, e: %v", fileName, e)
		return
	}
	_, e = f.Write(buf)
	if e != nil {
		logger.Errorf("write buf to file: %v fail, e: %v", fileName, e)
		return
	}
	f.Close()
}

// TransferVideoStream 转发fpv 发过来的视频流。
func (d *Fpv) TransferVideoStream() {
	FpvVideoInstance().UpdateStatusOnPushingVideo()

	logger.Info("receive  fpv transfer video stream.")
	videoStreamPkg := &mavlink.FpvTransferVideoStreamPkg{}

	readBegin := mavlink.HeaderLen
	offSet := mavlink.DevSNLen
	readEnd := readBegin + offSet
	err := mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, &videoStreamPkg.SN, offSet)
	logger.Debug("SN : ", string(videoStreamPkg.SN[:]))

	readBegin = readEnd
	offSet = 4
	readEnd = readBegin + offSet
	err = mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, &videoStreamPkg.FrameIndex, offSet)
	logger.Debug("FrameIndex : ", videoStreamPkg.FrameIndex)

	readBegin = readEnd
	offSet = 4
	readEnd = readBegin + offSet
	err = mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, &videoStreamPkg.PkgMax, offSet)
	logger.Debug("PkgMax : ", videoStreamPkg.PkgMax)

	readBegin = readEnd
	offSet = 4
	readEnd = readBegin + offSet
	_ = mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, &videoStreamPkg.PkgIndex, offSet)
	logger.Debug("PkgIndex : ", videoStreamPkg.PkgIndex)

	readBegin = readEnd
	offSet = 4
	readEnd = readBegin + offSet
	_ = mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, &videoStreamPkg.DataLen, offSet)
	logger.Debug("DataLen : ", videoStreamPkg.DataLen)

	if videoStreamPkg.PkgMax == 0 && videoStreamPkg.PkgIndex == 0 {
		return
	}
	if videoStreamPkg.DataLen <= 0 {
		logger.Errorf("has no msg data")
		return
	}
	logger.Infof("sub pkg data len: %v, this pkg total pkg len: %v", videoStreamPkg.DataLen, d.MsgLen)

	readBegin = readEnd
	offSet = int(videoStreamPkg.DataLen)
	readEnd = readBegin + offSet
	videoStreamPkg.Data = make([]byte, offSet)
	//  是否需要循环等待去读。应该不需要，框架根据头部长度已经把数据读完整了。
	err = mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, videoStreamPkg.Data, offSet)
	if err != nil {
		logger.Errorf("msg decode fail, e: %v", err)
		return
	}
	FpvVideoFrameIndexMng.SetData(int32(videoStreamPkg.FrameIndex),
		int32(videoStreamPkg.PkgIndex), videoStreamPkg.Data)

	FpvVideoFrameIndexMng.SetFramePkgIndex(int32(videoStreamPkg.FrameIndex),
		int32(videoStreamPkg.PkgIndex), int32(videoStreamPkg.PkgMax))

	if !FpvVideoFrameIndexMng.IsFullPkg(int32(videoStreamPkg.FrameIndex)) {
		logger.Infof("continue to receive pkg, frameIndex: %v", videoStreamPkg.FrameIndex)
		return
	}

	responseBuf := []byte{}
	for i := 0; i < int(videoStreamPkg.PkgMax); i++ {
		bufData := FpvVideoFrameIndexMng.GetData(int32(videoStreamPkg.FrameIndex), int32(i))
		if bufData == nil {
			logger.Infof("get incompletely frame index, omit this get, frame index: %v, pkgIndex: %v",
				videoStreamPkg.FrameIndex, i)
			return
		}
		responseBuf = append(responseBuf, bufData...)
	}
	for i := 0; i < int(videoStreamPkg.PkgMax); i++ {
		ii := int32(i)
		fIndex := int32(videoStreamPkg.FrameIndex)

		go func() {
			FpvVideoFrameIndexMng.DelData(fIndex, ii)
			FpvVideoFrameIndexMng.DelFrameIndex(fIndex)
		}()
	}

	logger.Infof("whole pkg len: %v, frameIndex: %v", len(responseBuf), videoStreamPkg.FrameIndex)

	// struct 转 pb协议：
	devSn := ByteToString(videoStreamPkg.SN[:])
	if devSn == "" {
		return
	}
	if isEnable := d.updateStatus(devSn); isEnable == common.DeviceDisenable {
		logger.Infof("Fpv device %v disable", devSn)
		return
	}
	msgProto := &client.FpvVideoStreams{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      devSn,
			Sn:        devSn,
			MsgType:   mavlink.FpvVideoStreamMsg,
			EquipType: int32(common.DEV_FPV),
		},
		Data: &client.FpvVideoStreamItem{
			FrameIndex: videoStreamPkg.FrameIndex,
			PackIndex:  videoStreamPkg.PkgIndex,
			PackMax:    videoStreamPkg.PkgMax,
			DataLen:    uint32(len(responseBuf)),
			Data:       responseBuf,
		},

		EndVideoCond: &client.VideoMsgForEnd{
			UavSeqNo:  FpvVideoInstance().UavSeqNo,
			DroneName: FpvVideoInstance().DroneName,
			UFreq:     FpvVideoInstance().UFreq,
			Sn:        FpvVideoInstance().Sn,
			DevType:   4,
		},
	}
	msgProtoBin, e := proto.Marshal(msgProto)
	if e != nil {
		logger.Errorf("marshal FpvVideoStreams fail, e: %v", e)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgIdTransferFpvVideoStream,
		Data:    msgProtoBin,
	}
	out, e := proto.Marshal(report)
	if e != nil {
		logger.Errorf("marshal report data fail, e: %v", e)
		return
	}
	e = mq.FpvMsgBroker.Publish(mq.FpvTopic, broker.NewMessage(out))
	if e != nil {
		logger.Errorf("push msg on topic: %v fail", mq.FpvTopic)
		return
	}
	logger.Info("--->End Receive fpv video stream")
}

// FpvResetSystem 系统复位
func (d *Fpv) FpvResetSystem() (int32, error) {
	logger.Info("FpvResetSystem Start")

	req := &mavlink.FpvResetSystemRequest{
		ResetCode: mavlink.FpvOtaReSetCode,
		Type:      uint16(4),
	}
	buff := req.Create()

	logger.Debugf("FpvResetSystem buff: %02X \n", buff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("FpvResetSystem 发送反制抢系统复位信息失败: ", err)
		return 1, err
	}
	logger.Infof("FpvResetSystem End")
	return 0, nil
}

// FpvRunApp 运行固件App
func (d *Fpv) FpvRunApp() (int32, error) {
	logger.Info("FpvRunApp Start")
	req := &mavlink.FpvRunAppRequest{}
	buff := req.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.FpvIdRunApp]
	if !ok {
		manager = NewWaitTaskManager(mavlink.FpvIdRunApp, true, 0)
		d.WaitTaskMap[mavlink.FpvIdRunApp] = manager
	}
	task := manager.AddTask(nil, nil)
	logger.Debugf("FpvRunApp buff: %02X \n", buff)

	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("FpvRunApp 发送运行固件App信息失败: ", err)
		return 1, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("FpvRunApp WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 1, checkNetConnErr
		}
		return 1, err
	}
	res := result.(*mavlink.FpvRunAppResponse)
	logger.Debugf("FpvRunApp 获取运行固件App信息结果：%#v", res)
	logger.Info("FpvRunApp End")
	return int32(res.Status), nil
}

// ReceiveFpvRunApp 获取运行固件App响应
func (d *Fpv) ReceiveFpvRunApp() {
	res := &mavlink.FpvRunAppResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveFpvRunApp 获取运行固件App响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.FpvIdRunApp]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// FpvGetUpdateWriteStatus 获取固件写入状态
func (d *Fpv) FpvGetUpdateWriteStatus() (*mavlink.FpvGetUpdateWriteStatusResponse, error) {
	logger.Info("FpvGetUpdateWriteStatus Start")
	req := &mavlink.FpvGetUpdateWriteStatusRequest{}
	buff := req.Create()
	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.FpvIdGetUpdateWriteStatus]
	if !ok {
		manager = NewWaitTaskManager(mavlink.FpvIdGetUpdateWriteStatus, true, 0)
		d.WaitTaskMap[mavlink.FpvIdGetUpdateWriteStatus] = manager
	}
	task := manager.AddTask(nil, nil)

	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("FpvGetUpdateWriteStatus 发送获取固件写入状态信息失败: ", err)
		return nil, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("FpvGetUpdateWriteStatus WaitTask Err: %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return nil, checkNetConnErr
		}
		return nil, err
	}
	res := result.(*mavlink.FpvGetUpdateWriteStatusResponse)
	logger.Debugf("FpvGetUpdateWriteStatus 获取固件写入状态信息结果：%#v", res)
	logger.Info("FpvGetUpdateWriteStatus End")
	return res, nil
}

// ReceiveFpvGetUpdateWriteStatus 获取固件写入状态回复结果
func (d *Fpv) ReceiveFpvGetUpdateWriteStatus() {
	res := &mavlink.FpvGetUpdateWriteStatusResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveFpvGetUpdateWriteStatus 获取固件写入状态回复信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.FpvIdGetUpdateWriteStatus]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// FpvWriteUpdateData 写入固件数据
func (d *Fpv) FpvWriteUpdateData() (int32, error) {
	logger.Info("FpvWriteUpdateData Start")
	req := &mavlink.FpvWriteUpdateDataRequest{}
	buff := req.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.FpvIdWriteUpdateData]
	if !ok {
		manager = NewWaitTaskManager(mavlink.FpvIdWriteUpdateData, true, 0)
		d.WaitTaskMap[mavlink.FpvIdWriteUpdateData] = manager
	}
	task := manager.AddTask(nil, nil)
	logger.Debugf("FpvWriteUpdateData buff: %02X \n", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("FpvWriteUpdateData 发送写入固件数据信息失败: ", err)
		return 1, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("FpvWriteUpdateData WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 1, checkNetConnErr
		}
		return 1, err
	}
	res := result.(*mavlink.FpvWriteUpdateDataResponse)
	logger.Debugf("FpvWriteUpdateData 获取写入固件数据信息结果：%#v", res)
	logger.Info("FpvWriteUpdateData End")
	return int32(res.Status), nil
}

// ReceiveFpvWriteUpdateData 获取写入固件数据响应
func (d *Fpv) ReceiveFpvWriteUpdateData() {
	res := &mavlink.FpvWriteUpdateDataResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveFpvWriteUpdateData 获取写入固件数据响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.FpvIdWriteUpdateData]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// FpvVerifyImage 校验固件镜像
func (d *Fpv) FpvVerifyImage() (int32, error) {
	logger.Info("FpvVerifyImage Start")
	req := &mavlink.FpvVerifyImageRequest{}
	buff := req.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.FpvIdVerifyImage]
	if !ok {
		manager = NewWaitTaskManager(mavlink.FpvIdVerifyImage, true, 0)
		d.WaitTaskMap[mavlink.FpvIdVerifyImage] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("FpvVerifyImage buff: %02X \n", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("FpvVerifyImage 发送校验固件镜像信息失败: ", err)
		return 1, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("FpvVerifyImage WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 1, checkNetConnErr
		}
		return 1, err
	}
	res := result.(*mavlink.FpvVerifyImageResponse)
	logger.Debugf("FpvVerifyImage 获取校验固件镜像信息结果：%#v", res)
	logger.Info("FpvVerifyImage End")
	return int32(res.Status), nil
}

// ReceiveFpvVerifyImage 获取校验固件镜像响应
func (d *Fpv) ReceiveFpvVerifyImage() {
	res := &mavlink.FpvVerifyImageResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveFpvVerifyImage 获取校验固件镜像响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.FpvIdVerifyImage]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// FpvRequestUpgrade 请求固件升级
func (d *Fpv) FpvRequestUpgrade(data [256]byte, tryCount int) (int32, error) {
	logger.Info("FpvRequestUpgrade Start")
	var req = &mavlink.FpvRequestUpgradeRequest{
		Data: data,
	}
	buff := req.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.FpvIdRequestUpgrade]
	if !ok {
		manager = NewWaitTaskManager(mavlink.FpvIdRequestUpgrade, true, 0)
		d.WaitTaskMap[mavlink.FpvIdRequestUpgrade] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("FpvRequestUpgrade buff: %02X \n", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("FpvRequestUpgrade 请求固件升级: ", err)
		return 1, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("FpvRequestUpgrade WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 1, checkNetConnErr
		}
		return 1, err
	}
	res := result.(*mavlink.FpvRequestUpgradeResponse)
	logger.Debugf("FpvRequestUpgrade 请求固件升级：%#v", res)
	logger.Info("FpvRequestUpgrade End")
	// 嵌入是boot有个bug第一次请求A7会返回1;睡眠2两秒再重试
	if res.Status != 0 {
		if tryCount > 0 {
			tryCount--
			time.Sleep(2 * time.Second)
			return d.FpvRequestUpgrade(data, tryCount)
		}
	}
	return int32(res.Status), nil
}

// ReceiveFpvRequestUpgrade 获取请求固件升级响应
func (d *Fpv) ReceiveFpvRequestUpgrade() {
	res := &mavlink.FpvRequestUpgradeResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveFpvRequestUpgrade 获取请求固件升级响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.FpvIdRequestUpgrade]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Fpv) FpvGetVersionInfo() (uint32, string, string, string, string, error) {
	logger.Info("FpvGetVersionInfo Start")
	defer func() {
		if r := recover(); r != nil {
			logger.Error("Fpv Get Version Info occurred:", r)
			return
		}
	}()
	req := &mavlink.FpvGetVersionRequest{}
	buff := req.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.FpvIdGetVersionInfo]
	if !ok {
		manager = NewWaitTaskManager(mavlink.FpvIdGetVersionInfo, true, time.Second*3)
		d.WaitTaskMap[mavlink.FpvIdGetVersionInfo] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("FpvGetVersionInfo buff: %02X \n", buff)

	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("FpvGetVersionInfo 发送获取Fpv版本信息失败: ", err)
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 0, "", "", "", "", checkNetConnErr
		}
		return 0, "", "", "", "", err
	}
	res := result.(*mavlink.FpvGetVersionResponse)
	logger.Debugf("FpvGetVersionInfo 获取Fpv版本信息结果：%#v", res)
	logger.Info("FpvGetVersionInfo End")
	return res.RunVersion,
		d.TrimStringSpace(res.AppVersion[:]),
		d.TrimStringSpace(res.BootVersion[:]),
		d.TrimStringSpace(res.HwVersion[:]),
		d.TrimStringSpace(res.ProtocolVersion[:]),
		nil
}
func (d *Fpv) ReceiveFpvIdGetVersion() {
	res := &mavlink.FpvGetVersionResponse{}
	d.GetPacket(res)
	logger.Debugf(" Receive FpvGetVersionResponse :%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.FpvIdGetVersionInfo]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Fpv) TrimStringSpace(strArr []byte) string {
	tmp := make([]byte, 0)
	for _, v := range strArr {
		if v == 0x00 {
			break
		}
		tmp = append(tmp, v)
	}
	return string(tmp)
}

func (d *Fpv) ReceiveFpvGetVersionInfo() {
	res := &mavlink.FpvGetVersionResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveFpvGetVersionInfo 接收到Tracer版本信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.FpvIdGetVersionInfo]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// FpvSendUpdatePkg 发送升级固件数据
func (d *Fpv) FpvSendUpdatePkg(offset uint32, imageData []uint8) (*mavlink.FpvSendUpdatePkgResponse, error) {
	logger.Info("FpvSendUpdatePkg Start")
	req := &mavlink.FpvSendUpdatePkgRequest{
		ImageOffset: offset,
		ImageLength: uint32(len(imageData)),
		ImageData:   imageData,
	}
	buff, err := req.Create()
	if err != nil {
		return nil, err
	}

	// 超时重发
	result, err := d.TimeOutRepeatSendBuff(buff, 3, 5*time.Second, mavlink.FpvIdSendUpdatePkg)
	if err != nil {
		logger.Errorf("FpvSendUpdatePkg 获取发送升级固件数据信息结果报错：%#v", err)
		logger.Errorf("FpvSendUpdatePkg Err buff: %v", buff)
		logger.Errorf("FpvSendUpdatePkg WaitTask Err %s", err.Error())
		return nil, err
	}
	res := result.(*mavlink.FpvSendUpdatePkgResponse)
	logger.Debugf("FpvSendUpdatePkg 获取发送升级固件数据信息结果：%#v", result)
	logger.Info("FpvSendUpdatePkg End")
	return res, nil
}

// ReceiveFpvSendUpdatePkg 获取发送升级固件数据响应
func (d *Fpv) ReceiveFpvSendUpdatePkg() {
	res := &mavlink.FpvSendUpdatePkgResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveFpvSendUpdatePkg 获取发送升级固件数据响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.FpvIdSendUpdatePkg]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// TimeOutRepeatSendBuff 超时重发字节数据
func (d *Fpv) TimeOutRepeatSendBuff(buff []byte, tryCount int, timeOut time.Duration, messageId int) (interface{}, error) {
	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[messageId]
	if !ok {
		manager = NewWaitTaskManager(messageId, true, timeOut)
		d.WaitTaskMap[messageId] = manager
	}
	task := manager.AddTask(nil, nil)
	if d.Conn == nil {
		manager.DeleteTask(task.TaskId)
		fmt.Println("TimeOutRepeatSendBuff device conn is nil")
		return nil, errors.New("device conn is nil")
	}
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("TimeOutRepeatSendBuff 发送信息失败: ", err)
		fmt.Printf("TimeOutRepeatSendBuff 发送信息失败:  %v \n", err)
		manager.DeleteTask(task.TaskId)
		return nil, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		// 超时重试
		if tryCount > 0 {
			tryCount--
			fmt.Println("TimeOutRepeatSendBuff tryCount: ", tryCount)
			return d.TimeOutRepeatSendBuff(buff, tryCount, timeOut, messageId)
		}
	}
	return result, err
}

// ControlVideoCmd send Tracer Video control
func (d *Fpv) ControlVideoCmd(op uint8, uavName uint8, droneName []uint8, freq uint32) (int32, error) {
	tmpArray := [mavlink.DevSNLen]uint8{}
	copy(tmpArray[:], droneName)

	req := &mavlink.TracerVideoControlRequest{
		Status:    op,
		UavName:   uavName,
		DroneName: tmpArray,
		Freq:      freq,
	}

	buf := req.Build(uint8(common.DEV_FPV))
	if buf == nil {
		return VideoFail, errors.New("build send to tracer pkg fail")
	}

	mng, ok := d.WaitTaskMap[mavlink.TracerControlVideo]
	if !ok {
		mng = NewWaitTaskManager(mavlink.TracerControlVideo, true, 5*time.Second)
		d.WaitTaskMap[mavlink.TracerControlVideo] = mng
	}

	task := mng.AddTask(nil, nil)

	logger.Debugf("send tracer video msg: [% x]", buf)

	if _, e := d.Conn.Write(buf); e != nil {
		logger.Errorf("send fpv video control fail, e: %v, value: %v", e, buf)
		return VideoFail, e
	}

	ret, e := mng.WaitTask(task)
	if e != nil {
		logger.Errorf("set tracer video control response, fail,e: %v", e)
		return VideoFail, e
	}

	res := ret.(*mavlink.TracerVideoControlResponse)
	if res.Status == 0 {
		return VideoFail, nil
	}
	return int32(res.Status), nil
}
func (d *Fpv) ProcVideoCmdResponse() {
	logger.Info("--->Into Receive video cmd star/stop response from device")
	result := &mavlink.TracerVideoControlResponse{}

	d.GetPacket(result)
	logger.Debugf("ProcVideoCmdResponse 获取信息：%#v", result)
	manager, ok := d.WaitTaskMap[mavlink.TracerControlVideo]
	if ok {
		manager.CompletedTask(result, nil)
	}
	logger.Infof("process video cmd star/stop response from device.")
	return
}

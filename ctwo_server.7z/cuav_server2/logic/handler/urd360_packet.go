package handler

import logger "adasgitlab.autel.com/tools/cuav_plugin/log"

type Packet struct {
	Data   []byte
	Length int
	Index  int
}

type Urd360Packet struct {
	buf    []byte
	tail   []byte
	length int
}

func NewUrd360Packet() *Urd360Packet {
	u := &Urd360Packet{
		buf:  make([]byte, 2048),
		tail: make([]byte, 2048),
	}
	u.buf = u.buf[0:0]
	u.tail = u.tail[0:0]
	return u
}

func (u *Urd360Packet) PacketHandler(data []byte, ch chan<- Packet) {
	n := len(data)
	// 处理分包粘包
	if u.length == 0 {
		if len(u.buf)+n < UrdHeaderLength {
			u.buf = append(u.buf, data[:n]...)
			return
		} else {
			temp := append([]byte{}, u.buf[:]...)
			if UrdHeaderLength-len(u.buf) > 0 {
				temp = append(temp, data[:UrdHeaderLength-len(u.buf)]...)
			}
			// 检查数据头
			if !checkUrdDataStartFlag(temp[:4]) {
				logger.Error("urd data start flag is not correct")
				u.buf = u.buf[0:0]
				return
			}
			// 获取数据长度
			u.length = int(getUrdDataLength(temp[6:10]))
		}
	}
	bufLength := len(u.buf)
	//if bufLength >= u.length {
	//	u.tail = append(u.tail, u.buf[u.length:]...)
	//	u.tail = append(u.tail, data[:n]...)
	//	u.buf = u.buf[0:u.length]
	//} else {
	if n < u.length-bufLength {
		u.buf = append(u.buf, data[:n]...)
		return
	} else {
		u.buf = append(u.buf, data[:u.length-bufLength]...)
		u.tail = append(u.tail, data[u.length-bufLength:n]...)
	}
	//}

	// 检查数据尾
	if !checkUrdDataEndFlag(u.buf[u.length-4 : u.length]) {
		logger.Error("urd data end flag is not correct")
		u.reset()
		u.tailHandler(ch)
		return
	}

	// 和校验，未生效，暂时不校验

	// 打印数据
	//logger.Debugf("buf: %+v", u.buf)
	//logger.Debugf("tail: %+v", u.tail)

	// 发送数据
	temp := append([]byte{}, u.buf[:u.length]...)
	ch <- Packet{
		Data:   temp,
		Length: u.length,
	}

	// 重置
	u.reset()
	u.tailHandler(ch)
}

func (u *Urd360Packet) reset() {
	u.buf = u.buf[0:0]
	u.length = 0
}

func (u *Urd360Packet) tailHandler(ch chan<- Packet) {
	if len(u.tail) > 0 {
		temp := append([]byte{}, u.tail[:]...)
		u.tail = u.tail[0:0]
		u.PacketHandler(temp, ch)
	}
}

type Urd360SpectrumPacket struct {
	buf       []byte
	startFlag bool
	index     int
	count     int
}

func NewUrd360SpectrumPacket() *Urd360SpectrumPacket {
	u := &Urd360SpectrumPacket{
		buf:   make([]byte, 3072),
		index: 20000000,
	}
	u.buf = u.buf[0:0]
	return u
}

func (u *Urd360SpectrumPacket) PacketHandler(data []byte, ch chan<- Packet) {
	// 处理分包粘包
	if !u.startFlag {
		if len(data) < 4 || !checkUrdSpectrumDataStartFlag(data[:4]) {
			return
		} else {
			u.startFlag = true
			u.buf = append(u.buf, data[4:]...)
		}
	} else {
		u.buf = append(u.buf, data[:]...)
	}

	for len(u.buf) >= 1200 && u.count < 318 {
		if u.count > 0 {
			temp := append([]byte{}, u.buf[:1200]...)
			length := getUrdSpectrumDataLength(temp[29:33])
			ch <- Packet{
				Data:   temp,
				Length: int(length),
				Index:  u.index,
			}
			u.index += 18750 * int(length)
		}
		u.count++
		u.buf = u.buf[1200:]
	}

	// 处理包尾
	if len(u.buf) >= 4 && checkUrdSpectrumDataEndFlag(u.buf[:4]) {
		temp := append([]byte{}, u.buf[4:]...)
		u.reset()
		u.PacketHandler(temp, ch)
		return
	}
	if u.count == 318 {
		u.reset()
		return
	}
}

func (u *Urd360SpectrumPacket) reset() {
	u.buf = u.buf[0:0]
	u.startFlag = false
	u.index = 20000000
	u.count = 0
}

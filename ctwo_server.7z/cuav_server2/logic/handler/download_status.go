package handler

import (
	"context"
	"os"
	"path/filepath"
	"strings"
	"time"

	"adasgitlab.autel.com/tools/cuav_plugin/broker"
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
)

var (
	OtaDownloadStatusChanMap = make(map[string]chan *OtaFileDownloadStatus)
	OtaDownloadCancelMap     = make(map[string]context.CancelFunc)
)

type DownloadStatus int8

const (
	WsOtaPkgDownloadStatus                = 0x38 // 下载升级包状态websocket消息Type
	Downloading            DownloadStatus = 1    // 下载中
	DownloadDone           DownloadStatus = 2    // 下载成功
	DownloadField          DownloadStatus = 3    // 失败
	DownloadPause          DownloadStatus = 4    // 暂停
	DownloadNetworkErr     DownloadStatus = 5    // 网络断开或不稳定

	DownloadFiledSuffix = ".filed"
	DownloadDoneSuffix  = ".bin"
)

type OtaFileDownloadStatus struct {
	Status               DownloadStatus `json:"status"`
	DownloadedPercentage int            `json:"downloadedPercentage"`
	FileName             string         `json:"fileName"`
	ErrMsg               string         `json:"errMsg"`
	FallPath             string         `json:"fallPath"`
}

// UpdateDownLoadPkgStatus 更新下载升级包升级状态
func UpdateDownLoadPkgStatus(cacheKey string, downloadStatus *OtaFileDownloadStatus) {
	statusChan, ok := OtaDownloadStatusChanMap[cacheKey]
	if !ok {
		statusChan = make(chan *OtaFileDownloadStatus, 1000)
		OtaDownloadStatusChanMap[cacheKey] = statusChan
	}
	statusChan <- downloadStatus
}

// CloseDownLoadPkgStatusChan 关闭下载升级包进度管道
func CloseDownLoadPkgStatusChan(cacheKey string) {
	statusChan := OtaDownloadStatusChanMap[cacheKey]
	close(statusChan)
	delete(OtaDownloadStatusChanMap, cacheKey)
}

// OtaSyncDownLoadPkgStatus 通过wbSocket和前端同步下载文件状态
func OtaSyncDownLoadPkgStatus(cacheKey string) {
	timer := time.After(time.Second * 1800)
	statusChan := OtaDownloadStatusChanMap[cacheKey]

	for {
		select {
		case downloadStatus, ok := <-statusChan:
			if !ok {
				return
			}
			entity := common.EquipmentMessageBoxEntity{
				Name:      cacheKey,
				Sn:        "",
				Info:      downloadStatus,
				EquipType: int(common.DEV_RADAR),
				MsgType:   WsOtaPkgDownloadStatus,
			}
			logger.Infof("OtaSyncDownLoadPkgStatus 发送下载状态 %v \n", downloadStatus)
			if downloadStatus.Status != Downloading {
				// 不是升级中状态
				// 删除取消下载通知函数
				delete(OtaDownloadCancelMap, downloadStatus.FileName)
				// 关闭信道
				CloseDownLoadPkgStatusChan(cacheKey)
				// 发送websocket消息
				_ = mq.EquipMessageBoxBroker.Publish(mq.EquipMessageBoxTopic, broker.NewMessage(entity))
				// 如果报错修改文件后缀为.field
				if downloadStatus.Status == DownloadField {
					if _, err := os.Stat(downloadStatus.FallPath); os.IsNotExist(err) {
						return
					}
					dir, filename := filepath.Split(downloadStatus.FallPath)
					newName := strings.TrimSuffix(filename, filepath.Ext(filename)) + DownloadFiledSuffix
					newPath := filepath.Join(dir, newName)
					// 重命名
					if err := os.Rename(downloadStatus.FallPath, newPath); err != nil {
						logger.Error("Rename err:", err)
					}
				} else {
					if _, err := os.Stat(downloadStatus.FallPath); os.IsNotExist(err) {
						return
					}
					if DownloadDoneSuffix != filepath.Ext(downloadStatus.FallPath) {
						dir, filename := filepath.Split(downloadStatus.FallPath)
						newName := strings.TrimSuffix(filename, filepath.Ext(filename)) + DownloadDoneSuffix
						newPath := filepath.Join(dir, newName)
						// 重命名
						if err := os.Rename(downloadStatus.FallPath, newPath); err != nil {
							logger.Error("Rename err", err)
						}
					}
				}

				return
			}

			_ = mq.EquipMessageBoxBroker.Publish(mq.EquipMessageBoxTopic, broker.NewMessage(entity))
		case <-timer:
			logger.Error("OtaSyncDownLoadPkgStatus timer out exit.")
			// 删除取消下载通知函数
			delete(OtaDownloadCancelMap, cacheKey)
			// 关闭信道
			CloseDownLoadPkgStatusChan(cacheKey)

			return
		}
	}
}

package handler

import (
	"sync"
	"time"

	"adasgitlab.autel.com/tools/cuav_plugin/broker"
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/ota"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
)

var (
	DevResetMap             sync.Map // 用于存储复位重启的设备信息
	DevUpgradeStatusChanMap = make(map[string]chan *UpgradeStatus)
	DevUpgradingMap         = NewDevUpgradingMap()

	OtaDeviceTypeMap = map[int32]common.DeviceType{
		ota.DeviceTypeRadar:   common.DEV_RADAR,
		ota.DeviceTypeGun:     common.DEV_SCREEN,
		ota.DeviceTypeDroneID: common.DEV_V2DRONEID,
		ota.DeviceTypeTracerP: common.DEV_V2DRONEID,
		ota.DeviceTypeTracerS: common.DEV_V2DRONEID,
		ota.DeviceTypeFPV:     common.DEV_FPV,
		ota.DeviceTypeSFL:     common.DEV_SFL,
	}
)

const (
	UpgradeStatusReset        = 1 // 系统复位重启中
	UpgradeStatusSendPkg      = 2 // 发送升级包中
	UpgradeStatusWritePkg     = 3 // 写入升级包中
	UpgradeStatusSuccess      = 4 // 升级成功
	UpgradeStatusFailed       = 5 // 升级失败
	UpgradeStatusNotInUpgrade = 6 // 设备不在升级状态

	WsDeviceUpdateStatus = 0x37 // 升级状态websocket消息Type
)

type UpgradingMap struct {
	snMap map[string]bool
	mutex sync.RWMutex
}

func NewDevUpgradingMap() *UpgradingMap {
	return &UpgradingMap{
		snMap: make(map[string]bool),
		mutex: sync.RWMutex{},
	}
}

// SetStatus 设置下载状态
func (s *UpgradingMap) SetStatus(cacheKey string, upgrading bool) string {
	s.mutex.Lock()
	defer s.mutex.Unlock()
	s.snMap[cacheKey] = upgrading
	return cacheKey
}

// CheckIsUpgrading 查看是否正在升级中
func (s *UpgradingMap) CheckIsUpgrading(cacheKey string) bool {
	s.mutex.RLock()
	defer s.mutex.RUnlock()

	upgrading, ok := s.snMap[cacheKey]
	if !ok {
		return false
	}
	return upgrading
}

// Del 删除
func (s *UpgradingMap) Del(cacheKey string) {
	s.mutex.Lock()
	defer s.mutex.Unlock()

	delete(s.snMap, cacheKey)
}

// UpgradeStatus 设备升级状态
type UpgradeStatus struct {
	Sn          string `json:"sn"`     // 设备Sn
	DeviceType  int32  `json:"-"`      // 设备类型 1-反制抢, 2-屏幕, 3-雷达
	Status      int32  `json:"status"` // 升级状态 1-系统复位中, 2-发送数据中, 3-写入数据中, 4-升级成功, 5-升级失败
	Permil      int64  `json:"permil"` // 运行状态千分比
	PkgPathName string `json:"-"`      // 已下载升级包文件路径
	ErrMsg      string `json:"errMsg"` // 失败原因
}

// UpdateOtaStatus 更新Ota升级状态
func UpdateOtaStatus(cacheKey string, upgradeStatus *UpgradeStatus) {
	statusChan, ok := DevUpgradeStatusChanMap[cacheKey]
	if !ok {
		statusChan = make(chan *UpgradeStatus, 1000)
		DevUpgradeStatusChanMap[cacheKey] = statusChan
	}
	statusChan <- upgradeStatus
}

// CloseOtaStatusChan 关闭升级进度管道
func CloseOtaStatusChan(cacheKey string) {
	statusChan, ok := DevUpgradeStatusChanMap[cacheKey]
	if ok {
		close(statusChan)
		delete(DevUpgradeStatusChanMap, cacheKey)
	}
}

// OtaSyncUpgradeStatus 通过wbSocket和前端同步ota升级状态
func OtaSyncUpgradeStatus(sn, cacheKey string) {
	timer := time.After(time.Second * 1800)
	statusChan := DevUpgradeStatusChanMap[cacheKey]

	for {
		select {
		case upgradeStatus, ok := <-statusChan:
			if !ok {
				return
			}
			entity := common.EquipmentMessageBoxEntity{
				Name:      sn,
				Sn:        sn,
				Info:      upgradeStatus,
				MsgType:   WsDeviceUpdateStatus,
				EquipType: int(upgradeStatus.DeviceType),
			}
			logger.Infof("OtaSyncUpgradeStatus 发送升级状态 %v \n", upgradeStatus)
			if upgradeStatus.Status == UpgradeStatusFailed || upgradeStatus.Status == UpgradeStatusSuccess {
				// 成功或失败退出
				_ = mq.EquipMessageBoxBroker.Publish(mq.EquipMessageBoxTopic, broker.NewMessage(entity))
				// 修改升级状态
				DevUpgradingMap.Del(cacheKey)
				// 关闭信道
				CloseOtaStatusChan(cacheKey)
				return
			}

			_ = mq.EquipMessageBoxBroker.Publish(mq.EquipMessageBoxTopic, broker.NewMessage(entity))
		case <-timer:
			logger.Error("OtaSyncUpgradeStatus timer out exit.")
			// 修改升级状态
			DevUpgradingMap.Del(cacheKey)
			// 关闭信道
			CloseOtaStatusChan(cacheKey)
			return
		}
	}
}

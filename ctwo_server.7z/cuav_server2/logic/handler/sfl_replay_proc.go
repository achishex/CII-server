package handler

import (
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/helper"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/proto/mavlink"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
	broker2 "go-micro.dev/v4/broker"
	"google.golang.org/protobuf/proto"
)

// consumeReplaySFLInfo heart,detect,hit
func consumeReplaySFLInfo() {

	_, _ = mq.SflMsgBroker.Subscribe(mq.SflTopic, func(event broker2.Event) error {
		entity := client.ClientReport{}
		if err := proto.Unmarshal(event.Message().Body, &entity); err != nil {
			logger.Errorf("consume sfl Unmarshal error: %v", err)
			return err
		}

		if entity.MsgType == common.ClientMsgIDSFLHeartBeat {
			doSFLHeart(entity.Data)
		} else if entity.MsgType == common.ClientMsgIDSFLDetect {
			doSFLDetectInfo(entity.Data)
		} else if entity.MsgType == common.ClientMsgIDSFLHitStatus {
			doSFLHitStatusInfo(entity.Data)
		} else {
			logger.Error("SFL replay subscribe error msg,msg type = ", entity.MsgType)
		}

		return nil
	})
}

// doSFLHeart do logic
func doSFLHeart(data []byte) error {
	heartEntities := make([]bean.SFLReplayHeartData, 0, batchSize)
	dataInfo := client.SflHeartInfo{}
	if err := proto.Unmarshal(data, &dataInfo); err != nil {
		logger.Errorf("parse sfl heart info fail, e: %v", err)
		return err
	}
	if dataInfo.GetData() == nil || dataInfo.GetHeader() == nil {
		logger.Infof("parse data info is nil for gun heart")
		return nil
	}
	sn := dataInfo.GetHeader().GetSn()

	heartEntities = append(heartEntities, bean.SFLReplayHeartData{
		Sn:            sn,
		WorkStatus:    dataInfo.GetData().GetWorkStatus(),
		IsOnline:      dataInfo.GetData().GetIsOnline(),
		HitFreq:       dataInfo.GetData().GetHitFreq(),
		DetectFreq:    dataInfo.GetData().GetDetectFreq(),
		Elevation:     dataInfo.GetData().GetElevation(),
		GunDirection:  dataInfo.GetData().GetGunDirection(),
		GunLongitude:  dataInfo.GetData().GetGunLongitude(),
		GunLatitude:   dataInfo.GetData().GetGunLatitude(),
		GunAltitude:   dataInfo.GetData().GetGunAltitude(),
		SatellitesNum: dataInfo.GetData().GetSatellitesNum(),
		FaultLevel:    dataInfo.GetData().GetFaultLevel(),
		CtrlFault:     dataInfo.GetData().GetCtrlFault(),
		AeagFault:     dataInfo.GetData().GetAeagFault(),
		TracerFault:   dataInfo.GetData().GetTracerFault(),

		CreateTime: time.Now().UnixMilli(),
	})
	createBusiHeartTable[bean.SFLReplayHeartData](db.GetDB(), sn, 0)
	if err := db.GetDB().Table(bean.SFLReplayHeartData{}.GetTableName(sn)).Create(&heartEntities).Error; err != nil {
		logger.Errorf("consume gun heart data, write to db fail, e: %v", err)
	}
	heartEntities = helper.ClearSlice[bean.SFLReplayHeartData](heartEntities)
	return nil
}

// doSFLHitStatusInfo do logic
func doSFLHitStatusInfo(data []byte) error {
	var hitStatusEntities bean.SFLReplayHitStatusData

	dataInfo := client.SflHitStateInfo{}
	if err := proto.Unmarshal(data, &dataInfo); err != nil {
		logger.Errorf("parse sfl detect info fail, e: %v", err)
		return err
	}
	if dataInfo.Header == nil || dataInfo.GetData() == nil {
		logger.Errorf("parse data info is nil for fpv detect")
		return nil
	}
	if dataInfo.GetHeader().GetMsgType() != mavlink.SflHitStatusMsgReport {
		return nil
	}

	sn := dataInfo.Data.Sn

	hitStatusEntities.DroneHeight = float64(dataInfo.Data.HitState)
	hitStatusEntities.CreateTime = time.Now().UnixMilli()
	hitStatusEntities.DroneHorizon = dataInfo.Data.DroneHorizon
	hitStatusEntities.DroneLatitude = dataInfo.Data.DroneLatitude
	hitStatusEntities.DronePitch = dataInfo.Data.DronePitch
	hitStatusEntities.DroneSailLatitude = dataInfo.Data.DroneLatitude
	hitStatusEntities.DroneSpeed = dataInfo.Data.DroneSpeed
	hitStatusEntities.DroneVerticalSpeed = dataInfo.Data.DroneVerticalSpeed
	hitStatusEntities.DroneYawAngle = dataInfo.Data.DroneYawAngle
	hitStatusEntities.HitState = dataInfo.Data.HitState
	hitStatusEntities.PilotLatitude = dataInfo.Data.PilotLatitude
	hitStatusEntities.UFreq = dataInfo.Data.UFreq
	hitStatusEntities.UDistance = dataInfo.Data.UDangerLevels
	hitStatusEntities.UDangerLevels = dataInfo.Data.UDangerLevels
	hitStatusEntities.SerialNum = dataInfo.Data.SerialNum
	hitStatusEntities.SN = dataInfo.Header.Sn
	hitStatusEntities.Role = dataInfo.Data.Role
	hitStatusEntities.ProductType = dataInfo.Data.ProductType

	createBusiSflHitTable[bean.SFLReplayHitStatusData](db.GetDB(), sn)
	if err := db.GetDB().Table(bean.SFLReplayHitStatusData{}.GetTableName(sn)).Create(&hitStatusEntities).Error; err != nil {
		logger.Errorf("consume sfl hit status, write to db fail, e: %v", err)
	}

	return nil
}

// consumeReplaySFLDetectInfo deprecated
func doSFLDetectInfo(data []byte) error {
	detectEntities := make([]bean.SFLReplayDetectData, 0, batchSize)

	dataInfo := client.SflDetectInfo{}
	if err := proto.Unmarshal(data, &dataInfo); err != nil {
		logger.Errorf("parse sfl detect info fail, e: %v", err)
		return err
	}
	if dataInfo.Header == nil || dataInfo.GetData() == nil {
		logger.Errorf("parse data info is nil for fpv detect")
		return nil
	}
	if dataInfo.GetHeader().GetMsgType() != mavlink.SflDetectMsgReport {
		return nil
	}

	sn := dataInfo.GetData().GetSn()

	OnceSeq := time.Now().UnixMilli()
	if len(dataInfo.GetData().GetList()) <= 0 {
		return nil
	}

	for _, droneItem := range dataInfo.GetData().GetList() {
		if droneItem == nil {
			continue
		}
		detectEntities = append(detectEntities, bean.SFLReplayDetectData{
			Sn:                 sn,
			ProductType:        droneItem.GetProductType(),
			DroneName:          droneItem.GetDroneName(),
			SerialNum:          droneItem.GetSerialNum(),
			DroneLongitude:     droneItem.GetDroneLongitude(),
			DroneLatitude:      droneItem.GetDroneLatitude(),
			DroneHeight:        droneItem.GetDroneHeight(),
			DroneYawAngle:      droneItem.GetDroneYawAngle(),
			DroneSpeed:         droneItem.GetDroneSpeed(),
			DroneVerticalSpeed: droneItem.GetDroneVerticalSpeed(),
			SpeedDirection:     droneItem.GetSpeedDirection(),
			DroneSailLongitude: droneItem.GetDroneSailLongitude(),
			DroneSailLatitude:  droneItem.GetDroneSailLatitude(),
			PilotLongitude:     droneItem.GetPilotLongitude(),
			PilotLatitude:      droneItem.GetPilotLatitude(),
			DroneHorizon:       droneItem.GetDroneHorizon(),
			DronePitch:         droneItem.GetDronePitch(),
			UFreq:              droneItem.GetUFreq(),
			UDistance:          droneItem.GetUDistance(),
			UDangerLevels:      droneItem.GetUDangerLevels(),
			Role:               droneItem.GetRole(),
			OnceSeq:            OnceSeq,
			CreateTime:         time.Now().UnixMilli(),
		})
	}

	createBusiDetectTable[bean.SFLReplayDetectData](db.GetDB(), sn, int32(common.DEV_SFL))
	if err := db.GetDB().Table(bean.SFLReplayDetectData{}.GetTableName(sn)).Create(&detectEntities).Error; err != nil {
		logger.Errorf("consume sfl detect data, write to db fail, e: %v", err)
	}

	detectEntities = helper.ClearSlice[bean.SFLReplayDetectData](detectEntities)
	return nil
}

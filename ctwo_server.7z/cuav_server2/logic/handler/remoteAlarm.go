package handler

import (
	"context"
	"errors"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
	"gorm.io/gorm"
)

type RemoteAlarm struct {
}

func NewRemoteAlarm() *RemoteAlarm {
	return &RemoteAlarm{}
}

func (r *RemoteAlarm) Update(ctx context.Context, req *client.AlarmCrudReq, res *client.AlarmCrudRes) error {
	err := db.GetDB().Model(&bean.RemoteAlarm{}).Where("id=?", req.Id).Updates(map[string]interface{}{
		"phone":      req.Phone,
		"email":      req.Email,
		"open":       req.Open,
		"alarm_time": req.AlarmTime,
	}).Error
	if err != nil {
		logger.Errorf("update failed,error:%v", err)
		return err
	}
	return nil
}

func (r *RemoteAlarm) GetAlarm(ctx context.Context, req *client.AlarmReq, res *client.AlarmRes) error {
	err := db.GetDB().Model(&bean.RemoteAlarm{}).First(&res).Error
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil
		}
		logger.Errorf("query remote alarm failed,err:%v", err)
		return err
	}
	logger.Infof("====================>res:%#v", res)
	return nil
}

package handler

import (
	"encoding/json"
	"fmt"
	"log"
	"os"
	"reflect"
	"testing"
	"time"

	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
)

func connectToSQLite(filePath string) (*gorm.DB, error) {

	logger := logger.New(
		log.New(os.Stdout, "\r\n", log.LstdFlags), // 将日志输出到标准输出
		logger.Config{},
	)
	db, err := gorm.Open(sqlite.Open(filePath), &gorm.Config{Logger: logger})
	if err != nil {
		return nil, err
	}

	return db, nil
}

func deepEqualUrd360(src, dest UrdDroneInfoReplay) bool {
	return src.SN == dest.SN &&
		src.ID == dest.ID &&
		src.UniqueID == dest.UniqueID &&
		src.TargetInfoLength == dest.TargetInfoLength &&
		src.TargetInfo == dest.TargetInfo &&
		src.StationID == dest.StationID &&
		src.TargetAzimuth == dest.TargetAzimuth &&
		src.TargetRange == dest.TargetRange &&
		src.Longitude == dest.Longitude &&
		src.Latitude == dest.Latitude &&
		src.Height == dest.Height &&
		src.Frequency == dest.Frequency &&
		src.Bandwidth == dest.Bandwidth &&
		src.SignalStrength == dest.SignalStrength &&
		src.Trust == dest.Trust &&
		src.DataType == dest.DataType
}
func TestReplayUrd360Specturm(t *testing.T) {
	filePath := fmt.Sprintf("%d%s", time.Now().UnixNano(), "_test_gen.db")
	_ = os.Remove(filePath)

	db, err := connectToSQLite(filePath)
	if err != nil {
		t.Error("connect DB error", err)
	}

	sn := "TestReplayUrd360_sn"
	msgType := 1
	wantMsgInfo := UrdSpectrumRepaly{
		X: []int32{1, 1, 1, 1},
		Y: []int32{2, 2, 2, 2},
	}
	wantMsg := common.EquipmentMessageBoxEntity{
		Name:      "127.0.0.1",
		Sn:        sn,
		MsgType:   msgType,
		EquipType: int(common.DEV_URD360),
		Info:      wantMsgInfo,
	}
	bmsg, err := json.Marshal(wantMsg)
	if err != nil {
		t.Error("josn marshal error", err)
	}
	ReplayUrd360Specturm(db, bmsg)
	ntime := time.Now().UnixMilli()
	time.Sleep(10 * time.Millisecond)

	MsgInfo := UrdSpectrumRepaly{
		X: []int32{1, 1, 1, 1},
		Y: []int32{3, 3, 3, 3},
	}
	Msg := common.EquipmentMessageBoxEntity{
		Name:      "127.0.0.1",
		Sn:        sn,
		MsgType:   msgType,
		EquipType: int(common.DEV_URD360),
		Info:      MsgInfo,
	}
	bmsg2, err := json.Marshal(Msg)
	if err != nil {
		t.Error("josn marshal error", err)
	}
	ReplayUrd360Specturm(db, bmsg2)

	var queryMsg []UrdSpectrumSDB
	db.Table(TableName(sn, msgType)).Where("create_time <= ?", ntime).Find(&queryMsg)

	infoo := UrdSpectrumRepaly{}
	err = json.Unmarshal(queryMsg[0].Data, &infoo)
	if err != nil {
		t.Error("json.Unmarshal err = ", err)
	}
	t.Log("X = ", infoo.X)
	t.Log("y = ", infoo.Y)
	if !reflect.DeepEqual(wantMsgInfo, infoo) {
		t.Error("wantMsgInfo= ", wantMsgInfo)
		t.Error("infoo = ", infoo)
	}
	if reflect.DeepEqual(MsgInfo, infoo) {
		t.Error("MsgInfo= ", MsgInfo)
		t.Error("infoo = ", infoo)
	}
	_ = os.Remove(filePath)
}

func TestReplayUrd360(t *testing.T) {
	filePath := fmt.Sprintf("%d%s", time.Now().UnixNano(), "_test_gen.db")
	_ = os.Remove(filePath)

	db, err := connectToSQLite(filePath)
	if err != nil {
		t.Error("connect DB error", err)
	}

	sn := "Urd360"
	msgType := UrdDroneInfoType
	wantMsgInfo := UrdDroneInfoReplay{
		TbID:             1,
		SN:               sn,
		ID:               1210000,
		UniqueID:         "UniqueIda",
		TargetInfoLength: 123456,
		TargetInfo:       "TargetInfo",
		StationID:        357,
		TargetAzimuth:    238,
		TargetRange:      428,
		Longitude:        32.002,
		Latitude:         63.02,
		Height:           4239,
		Frequency:        12.40,
		Bandwidth:        92.00,
		SignalStrength:   32.01,
		Trust:            31,
		Time:             "1992-02-12",
		DataType:         2,
		Modulation:       3,
		CreateTime:       time.Now().UnixMilli(),
	}
	wantMsg := common.EquipmentMessageBoxEntity{
		Name:      "127.0.0.1",
		Sn:        sn,
		MsgType:   msgType,
		EquipType: int(common.DEV_URD360),
		Info:      wantMsgInfo,
	}
	bmsg, err := json.Marshal(wantMsg)
	if err != nil {
		t.Error("josn marshal error", err)
	}
	ReplayDroneUrd360(db, bmsg)
	ntime := time.Now().UnixMilli()
	time.Sleep(10 * time.Millisecond)

	MsgInfo := UrdDroneInfoReplay{
		TbID:             2,
		SN:               sn,
		ID:               1210001,
		UniqueID:         "UniqueId",
		TargetInfoLength: 654321, //对比wantMsg1，修改这一项数据
		TargetInfo:       "TargetInfo",
		StationID:        357,
		TargetAzimuth:    238,
		TargetRange:      428,
		Longitude:        32.001, //对比wantMsg1，修改这一项数据
		Latitude:         63.02,
		Height:           4239,
		Frequency:        12.40,
		Bandwidth:        92.00,
		SignalStrength:   32.01,
		Trust:            31,
		Time:             "2002-02-15", //对比wantMsg1，修改这一项数据
		DataType:         2,
		Modulation:       3,
		CreateTime:       time.Now().UnixMilli(),
	}
	Msg := common.EquipmentMessageBoxEntity{
		Name:      "127.0.0.1",
		Sn:        sn + "_1",
		MsgType:   msgType,
		EquipType: int(common.DEV_URD360),
		Info:      MsgInfo,
	}
	bmsg2, err := json.Marshal(Msg)
	if err != nil {
		t.Error("josn marshal error", err)
	}
	ReplayDroneUrd360(db, bmsg2)
	var queryMsg []UrdDroneInfoReplay
	db.Table(TableName(Msg.Sn, Msg.MsgType)).Where("create_time <= ?", ntime).Find(&queryMsg)

	if len(queryMsg) <= 0 {
		t.Logf("not find item, create_time: %v", ntime)
		return
	}

	infoo := queryMsg[0]
	fmt.Println("infoo = ", infoo)

	if !deepEqualUrd360(wantMsgInfo, infoo) {
		t.Error("wantMsgInfo= ", wantMsgInfo)
		t.Error("infoo = ", infoo)
	}
	if deepEqualUrd360(MsgInfo, infoo) {
		t.Error("MsgInfo= ", MsgInfo)
		t.Error("infoo = ", infoo)
	}
	_ = os.Remove(filePath)
}

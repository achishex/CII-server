package handler

const (
	ErrDevListInputParamInvalid = 10000
)

func init() {
	ErrorInfo = make(map[int32]*DeviceCenterErr)
	ErrorInfo[ErrDevListInputParamInvalid] = &DeviceCenterErr{
		ErrDevListInputParamInvalid, "beginTime more than endTime",
	}
}

type DeviceCenterErr struct {
	Code    int
	Message string
}

func (de *DeviceCenterErr) Error() string {
	return de.Message
}

var ErrorInfo map[int32]*DeviceCenterErr

package handler

import (
	"github.com/gammazero/workerpool"
	"testing"
	"time"
)

func TestCheckIsSameDay(t *testing.T) {
	testDemos := []struct {
		name string
		t1   int64
		t2   int64
		ret  bool
		//
		tmSecond int64
		tmStr    string
	}{
		{
			"test1",
			1701867831, //不在同一天
			1701781431,
			false,
			1701788631,
			"20231205",
		},
		{
			"test2",
			1701709431,
			1701788631, //同一天
			true,
			1701875031,
			"20231206",
		},
	}
	for _, tRun := range testDemos {
		t.Logf("want ret: %v, really ret: %v", tRun.ret, CheckIsSameDay(tRun.t1, tRun.t2))
		t.Logf("want tmStr: %v, really ret: %v", tRun.tmStr, Format20060102OnTime(tRun.tmSecond))

		t.Log(Format20060102OnTime(tRun.tmSecond))
	}
}

func TestSplitTimeByDay(t *testing.T) {
	testDemos := []DayTimeInfo{}
	testDemos = append(testDemos, DayTimeInfo{
		beginTime: 1701695019, // 2023-12-04 同一天
		endTime:   1701702219,
	},
		DayTimeInfo{
			beginTime: 1701702219, // 2023-12-04, 2023-12-05
			endTime:   1701705819,
		},
		DayTimeInfo{
			beginTime: 1701619419, // 2023-12-04, 2023-12-06
			endTime:   1701864219,
		},
	)

	for i, v := range testDemos {
		t.Logf("test case: %v, day: %#v", i, SplitTimeByDay(v.beginTime, v.endTime))
	}
}

func TestWorkClose(t *testing.T) {
	var chVals chan int = make(chan int, 100)
	wp := workerpool.New(10)

	costTm := time.Now()
	for i := 0; i < 100; i++ {
		ii := i
		wp.Submit(func() {
			time.Sleep(10 * time.Millisecond)
			chVals <- ii
		})

		//time.Sleep(10 * time.Millisecond)
		//chVals <- ii

	}
	wp.StopWait()
	close(chVals)

	for v := range chVals {
		t.Log(v)
	}
	t.Logf("cost tm: %d", time.Since(costTm))

	nowTm := time.Now()
	nextTm := nowTm.Add(2 * time.Second)
	t.Logf("%d", nextTm.Sub(nowTm))
}

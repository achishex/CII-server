package handler

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"math/rand"
	"net"
	"net/http"
	"os"
	"regexp"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"time"

	"adasgitlab.autel.com/tools/cuav_plugin/broker"
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/config"
	"adasgitlab.autel.com/tools/cuav_server/entity/server"
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/helper"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/proto/mavlink"
	"adasgitlab.autel.com/tools/cuav_server/repo/awsS3"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
	"google.golang.org/protobuf/proto"
)

var (
	DevStatusMap        sync.Map       //设备Key到Device数据结构 map[string]Device
	DevStatusNfsMap     sync.Map       //NFS设备Key到Device数据结构 map[string]Device
	DevSnMap            sync.Map       //TCP端口和设备SN映射 map[int32]string (aeag.go文件使用为消息发送者ID到sn映射,待梳理)
	IsSimulateMode      int32      = 2 //是否是模拟模式
	IsRunSimulateMode   bool           //模拟数据是否正在运行
	EleScanScope        int32      = 0
	DevStatusReportLock sync.Mutex //确保雷达和反制枪的的状态发送有序
	CheckOnlineDuration = time.Millisecond * 5000
	DeviceLogMap        MapWithChan
	LocalLogMap         = make(chan interface{})
	FileNameMap         = common.NewFileMapSet()

	GWaitTaskMap     sync.Map //= make(map[string]map[int]*WaitTaskManager)
	IsSerialMap      bool
	RadarReplayMap         = common.NewRadarReplaySnMapSet()
	RadarSpace       int64 = 0
	NsfReport        int64 = 0
	DeviceNSF4000Map       = common.NewDeviceNFSMapSet()
	StopCh                 = make(chan bool)
	StopMsg                = make(chan bool)
	NFSStartCmd      int64 = 0
	C2Config               = config.NewC2ConfigMap()
	Mutex            sync.Mutex

	DevStatusMapOnEvent  sync.Map
	DevDetectMapOnEvent  sync.Map
	SflHitOverMapOnEvent sync.Map //记录打击的无人机信息
)

func DeviceInit() {
	go OnlineCheck()
	go SendRadarExtHeart()
	go SendGunHeart()
	go SendScreenHeart()
	// go GetC2Id()
	go SendDroneIDHeart()
	go SendFpvHeart()
	go SendSflHeart()
	go SendAgxHeart()
	go SyncLog()
	go SyncCloudLog()
	go ListenSerialData()
	go ReplayDataDel()
	go reportSystemHeartbeat()
	go reportLicenseStatus()

	go OffLineEventCheck()
	go DetectEventCheck()
	go SflHitOverEventCheck()
}

func reportSystemHeartbeat() {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	ticker := time.NewTicker(1 * time.Second)
	for range ticker.C {
		currentTime := time.Now()
		formattedTime := currentTime.Format("2006-01-02 15:04:05")
		sn := GetDevGuid()
		// logger.Debug("sn = ", sn)
		data := &client.SystemHeartbeat{
			SysTime: formattedTime,
			Sn:      sn,
		}
		msg, err := proto.Marshal(data)
		if err != nil {
			logger.Error("marshal dataInfo err:", err)
			return
		}
		report := &client.ClientReport{
			MsgType: common.ClientMsgSystemHeartData,
			Data:    msg,
		}
		out, err := proto.Marshal(report)
		if err != nil {
			logger.Error("marshal report err:", err)
			return
		}

		_ = mq.SystemHeartBroker.Publish(mq.SystemHeartTopic, broker.NewMessage(out))

	}
}

var errorMap = map[string]int32{
	bean.NoLicense:      bean.NoLicenseCode,
	bean.InvalidLicense: bean.InvalidLicenseCode,
	bean.ExpiredLicense: bean.ExpiredLicenseCode,
}

func reportLicenseStatus() {
	osName := runtime.GOOS
	if osName != "windows" && osName != "linux" {
		logger.Debug("License check not supported int this operation system, system := ", osName)
		return
	}
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
			reportLicenseStatus()
		}
	}()

	ticker := time.NewTicker(3 * time.Second)

	for range ticker.C {

		lienceEndTime, licenseErr := bean.LicenseInvalidTime()
		if licenseErr != nil {
			logger.Error("license error:", licenseErr)
			// for range ticker.C {

			data := &client.SystemLicenseMsg{
				ErrorCode:    errorMap[licenseErr.Error()],
				ErrorMessage: licenseErr.Error(),
			}
			msg, err := proto.Marshal(data)
			if err != nil {
				logger.Error("marshal dataInfo err:", err)
				// return
			}
			report := &client.ClientReport{
				MsgType: common.ClientMsgSystemLicensetData,
				Data:    msg,
			}
			out, err := proto.Marshal(report)
			if err != nil {
				logger.Error("marshal report err:", err)
				// return
			}

			_ = mq.SystemHeartBroker.Publish(mq.SystemHeartTopic, broker.NewMessage(out))
			// }

		} else {

			if lienceEndTime == "" {
				logger.Debug("licenseEndTime is empty")
				// return
			}
			logger.Debug("reportLicenseStatus lienceEndTime = ", lienceEndTime)
			lendTime, err := time.Parse("2006-01-02 15:04:05", lienceEndTime)
			if err != nil {
				logger.Errorf("Error parsing time:", err)
				// return nil, errors.New(InvalidLicense)
			}

			ctsrtchange, err := time.Parse("2006-01-02 15:04:05", time.Now().Format("2006-01-02 15:04:05"))
			if err != nil {
				logger.Errorf("Error parsing time ...:", err)
				// return nil, errors.New(InvalidLicense)
			}

			if ctsrtchange.After(lendTime) {
				logger.Errorf("license expiration: lienceEndTime = ", lendTime)
				logger.Errorf("current time = 	", time.Now().Format("2006-01-02 15:04:05"))

				data := &client.SystemLicenseMsg{
					ErrorCode:    bean.ExpiredLicenseCode,
					ErrorMessage: bean.ExpiredLicense,
				}
				msg, err := proto.Marshal(data)
				if err != nil {
					logger.Error("marshal dataInfo err:", err)
					return
				}
				report := &client.ClientReport{
					MsgType: common.ClientMsgSystemLicensetData,
					Data:    msg,
				}
				out, err := proto.Marshal(report)
				if err != nil {
					logger.Error("marshal report err:", err)
					return
				}

				_ = mq.SystemHeartBroker.Publish(mq.SystemHeartTopic, broker.NewMessage(out))
			}
		}

	}

}

const (
	Success = 1
	Fail    = 2
)
const (
	Invalid         = -100
	MAXDroneHorizon = 36000
)
const (
	ConnectError   = 1
	ConnectTimeOut = 2
)
const (
	HeadingRan = 360
	ErrData    = 10000
)

type DevType int

const (
	RADAR DevType = 1
	GUN   DevType = 2
)

type DevTypes int

const (
	GUNS   DevType = 1
	RADARS DevType = 2
)
const (
	PackNum     = 200
	GunPackNUm  = 1000
	SyncPeriod  = 10 //分钟
	SWITCHOPEN  = 1  //开关状态  开
	SWITCHCLOSE = 2  //开关状态 关
)

const (
	HIGHLEVEL    = 1
	MIDDLELEVEL  = 2
	LOWLEVEL     = 3
	DEVEXCEPTION = 4
	UNKNOW       = 5
	OTHER        = 6
)
const (
	ADD  = 1
	DEL  = 2
	FIND = 3
)

// 无人机角色： 1-敌军 2-友军 3-未知 4-中立     批量导入为2友军
const (
	ERRTYPE = 0
	ENEMY   = 1
	FRIEND  = 2
	//UNKNOW     = 3
	NEUTRALITY = 4
)

type Connection interface {
	io.Reader
	io.Writer
	io.Closer
}

type Device struct {
	Name              string
	Sn                string
	Msg               []byte //数据包
	MsgLen            int
	MsgId             int        //当前消息类型
	Conn              Connection //连接
	RemoteIp          string
	RemotePort        int
	LocalIp           string
	ServerPort        int
	Status            uint8 //状态
	DevType           common.DeviceType
	FirstHeartTime    time.Time
	LastHeartTime     time.Time //最后一次心跳时间
	SourceId          uint8
	IsEnable          int32 //启用、禁用
	GetStatusInterval time.Time
	UdpIp             string
	WorkMode          int32
	SessionId         int64
	WaitTaskMap       map[int]*WaitTaskManager
}
type MapWithChan struct {
	Data map[string]SnChan
}
type SnChan chan string

type DeviceLogList struct {
	LogName    string // 日志名
	LogDataLen uint32 // 日志有效数据长度
	LogState   bool   //日志是否已经下载到本地的状态，false:不存在，true:已存在
}

type UploadDevLogCloud struct {
	Sn          string
	LogPath     string
	LogName     string
	UserAccount string
	RouteIp     string
}

func (d *Device) Close() {
	cachekeyDroneid := fmt.Sprintf("%d_%s", common.DEV_V2DRONEID, d.Sn)
	DevStatusMap.Delete(cachekeyDroneid)
	if d.Conn != nil {
		if err := d.Conn.Close(); err != nil {
			logger.Errorf("close connect err: %v", err)
		}
	}
}

type LogMsg struct {
	FileName string
}
type DeviceInterface interface {
	Deal()
}

type CreateDevFactoryFunc func(conn Connection, d []byte, dataLen int, remoteIp string, remotePort int, localIp string, serverPort int,
	mailBox map[int]*WaitTaskManager) DeviceInterface

/* 这里可以用接口注入的方式，可以做到解耦*/
var CreateDevFactoryMap = map[common.DeviceType]CreateDevFactoryFunc{
	common.DEV_AEAG:      NewCounterGun,
	common.DEV_RADAR:     NewRadar,
	common.DEV_SCREEN:    NewScreen,
	common.DEV_V2DRONEID: NewDroneID,
	common.DEV_FPV:       NewFpv,
	common.DEV_SFL:       NewSfl,
	common.DEV_AGX:       NewAgx,
}

func GetDevice(conn net.Conn, d []byte, mailBox map[int]*WaitTaskManager) DeviceInterface {
	if err := Check(d); err != nil {
		logger.Error("check receive err:", err)
		return nil
	}
	dataLen := len(d)
	devType := d[mavlink.SenderLoc] & 0xFF
	devId := common.DeviceType(devType)
	LocalAddr := strings.Split(conn.LocalAddr().String(), ":")
	serverPort, _ := strconv.Atoi(LocalAddr[1])
	remoteAddr := strings.Split(conn.RemoteAddr().String(), ":")
	remotePort, _ := strconv.Atoi(remoteAddr[1])
	if fn, ok := CreateDevFactoryMap[devId]; ok {
		return fn(conn, d, dataLen, remoteAddr[0], remotePort, LocalAddr[0], serverPort, mailBox)
	}
	logger.Error("未知设备信息:", devId)
	return nil
}

func GetTracerDevice(conn *TracerSerialConn, d []byte, mailBox map[int]*WaitTaskManager) DeviceInterface {
	logger.Info("GetTracerDevice Start")
	if err := Check(d); err != nil {
		logger.Error("check receive err:", err)
		return nil
	}
	dataLen := len(d)
	devType := d[mavlink.SenderLoc] & 0xFF
	devId := common.DeviceType(devType)
	LocalAddr := strings.Split(conn.Conn.LocalAddr().String(), ":")
	serverPort, _ := strconv.Atoi(LocalAddr[1])
	remoteAddr := strings.Split(conn.Conn.RemoteAddr().String(), ":")
	remotePort, _ := strconv.Atoi(remoteAddr[1])
	logger.Info("remote Port:", remotePort)
	IsSerialMap = true
	if fn, ok := CreateDevFactoryMap[devId]; ok {
		return fn(conn, d, dataLen, remoteAddr[0], remotePort, LocalAddr[0], serverPort, mailBox)
	}
	logger.Error("未知设备信息:", devId)
	return nil
}

func FindCacheDevice(sn string, deviceType common.DeviceType) *Device {
	cacheKey := fmt.Sprintf("%d_%s", deviceType, sn)
	if dev, ok := DevStatusMap.Load(cacheKey); ok {
		return dev.(*Device)
	}
	return nil
}
func FindCacheDeviceAndType(sn string) (*Device, common.DeviceType) {
	cachekeyAeag := fmt.Sprintf("%d_%s", common.DEV_SCREEN, sn)
	cachekeyRadar := fmt.Sprintf("%d_%s", common.DEV_RADAR, sn)
	cachekeyDroneid := fmt.Sprintf("%d_%s", common.DEV_V2DRONEID, sn)
	if dev, ok := DevStatusMap.Load(cachekeyAeag); ok {
		return dev.(*Device), common.DEV_SCREEN
	} else if devRadar, okRadar := DevStatusMap.Load(cachekeyRadar); okRadar {
		return devRadar.(*Device), common.DEV_RADAR
	} else if devDroneid, okDroneid := DevStatusMap.Load(cachekeyDroneid); okDroneid {
		return devDroneid.(*Device), common.DEV_V2DRONEID
	} else {
		return nil, 0
	}
}

func StopCacheServer(sn string) {

	if cache, ok := RadarTcpServerMap.Load(sn); ok {
		svc := cache.(*server.TcpServer)
		svc.Stop()
	}
}

func AddSimulateDevice(status int32, msgtype int32) {
	IsSimulateMode = status

	if IsSimulateMode == 1 || IsSimulateMode == 2 {
		cacheKey := fmt.Sprintf("%d_%s", common.DEV_RADAR, "radar0000000000")
		_, ok := DevStatusMap.Load(cacheKey)
		if !ok && IsSimulateMode == 1 {
			//如果不存在则根据消息id创建一个,这里不做保持，在心跳那里保存
			dev := &Device{
				Sn:             "radar0000000000",
				Conn:           nil,
				Status:         common.DevOffline,
				RemoteIp:       "127.0.0.1",
				DevType:        common.DEV_RADAR,
				FirstHeartTime: time.Now(),
				LastHeartTime:  time.Now(),
				IsEnable:       common.DeviceEnable,
			}
			DevStatusMap.Store(cacheKey, dev)
			logger.Info("添加模拟设备")
			err := NewEquipList().Update(context.Background(), &client.EquipCrudReq{Sn: "radar0000000000", Etype: "radar", IsEnable: true}, &client.EquipCrudRes{})

			if err != nil {
				logger.Error("radar Insert err:", err)
				return
			}

			return
		}
		if ok && IsSimulateMode == 2 {
			time.Sleep(1 * time.Second)
			RadarOfflineReport("radar0000000000", "")
			DevStatusMap.Delete(cacheKey)
			logger.Info("删除模拟设备")
			err := NewEquipList().DeleteWithSn(context.Background(), &client.DeleteWithSnReq{
				Sn: "radar0000000000",
			}, &client.EquipCrudRes{})
			if err != nil {
				logger.Error("radar Delete WithSn err:", err)
				return
			}
		}
	}
	if IsSimulateMode == 3 || IsSimulateMode == 4 {
		cacheKey := fmt.Sprintf("%d_%s", common.DEV_V2DRONEID, "Tracer_123456")
		_, ok := DevStatusMap.Load(cacheKey)

		if !ok && IsSimulateMode == 3 {
			//如果不存在则根据消息id创建一个,这里不做保持，在心跳那里保存
			dev := &Device{
				Sn:             "Tracer_123456",
				Conn:           nil,
				Status:         common.DevOffline,
				RemoteIp:       "127.0.0.1",
				DevType:        common.DEV_V2DRONEID,
				FirstHeartTime: time.Now(),
				LastHeartTime:  time.Now(),
				IsEnable:       common.DeviceEnable,
			}
			DevStatusMap.Store(cacheKey, dev)
			logger.Info("添加模拟设备")
			time.Sleep(time.Second * 1)
			err := NewEquipList().Update(context.Background(), &client.EquipCrudReq{Sn: "Tracer_123456", Etype: "DroneID", IsEnable: true}, &client.EquipCrudRes{})

			if err != nil {
				logger.Error("Tracer Insert err:", err)
				return
			}
			go func() { //发心跳
				IsRunSimulateMode = true
				var ticker *time.Ticker
				if msgtype == 226 {
					ticker = time.NewTicker(time.Millisecond * 100)
				} else {
					ticker = time.NewTicker(time.Millisecond * 120)
				}

				defer ticker.Stop()
				rand.Seed(time.Now().UnixNano())
				dronemin := 10000000000 // 最小值
				dronemax := 99999999999 // 最大值

				configInfo := &client.ConfigRes{}
				err = NewSystemConfig().GetSystemConfig(context.Background(), &client.ConfigReq{}, configInfo)
				if err != nil {
					logger.Error("Get SystemConfig err: ", err)
				}
				startlati := 22.5965
				startlati1 := 22.59713876
				maxlong := 114.0100000
				maxlati := 22.7000000
				startLong := 113.991318
				startLong1 := 114.00073570

				OperatorLongitude := 113.999988
				OperatorLatitude := 22.59459760
				OperatorLongitude2 := 114.00853
				OperatorLatitude2 := 22.59984
				OperatorLongitude3 := 114.00853
				OperatorLatitude3 := 22.59984

				if configInfo.C2Latitude > 0 {
					startlati = configInfo.C2Latitude
					startlati1 = configInfo.C2Latitude + 0.002
					maxlati = configInfo.C2Latitude + 0.1
					OperatorLatitude = configInfo.C2Latitude - 0.0045
					OperatorLatitude2 = configInfo.C2Latitude - 0.0070
					OperatorLatitude3 = configInfo.C2Latitude - 0.0045
				}
				if configInfo.C2Longitude > 0 {
					startLong = configInfo.C2Longitude
					startLong1 = configInfo.C2Longitude + 0.0007
					maxlong = configInfo.C2Longitude + 0.01
					OperatorLongitude = configInfo.C2Longitude - 0.0030
					OperatorLongitude2 = configInfo.C2Longitude - 0.0065
					OperatorLongitude3 = configInfo.C2Longitude - 0.0075
				}
				templong := startLong
				templati := startlati
				templong1 := startLong1
				templati1 := startlati1

				drone1 := strconv.Itoa(rand.Intn(dronemax-dronemin+1) + dronemin)
				drone2 := strconv.Itoa(rand.Intn(dronemax-dronemin+1) + dronemin)

				minHorizon := 0
				maxHorizon := 360
				horizon := minHorizon

				// 设置随机种子

				for {
					select {
					case <-ticker.C: //
						// 生成随机数
						randomNumlong := rand.Float64()*(0.00002-0.00001) + 0.00001
						// 生成随机数
						randomNumlait := rand.Float64()*(0.00002-0.00001) + 0.00001
						// 生成随机数
						randomNumlong1 := rand.Float64()*(0.00002-0.00001) + 0.00001
						// 生成随机数
						randomNumlait1 := rand.Float64()*(0.00002-0.00001) + 0.00001

						templong = templong + randomNumlong
						templati = templati + randomNumlait
						if templong >= maxlong || templati >= maxlati {
							templong = startLong
							templati = startlati
							drone1 = strconv.Itoa(rand.Intn(dronemax-dronemin+1) + dronemin)

						}
						templong1 = templong1 + randomNumlong1
						templati1 = templati1 + randomNumlait1
						if templong1 >= maxlong || templati1 >= maxlati {
							templong1 = startLong1
							templati1 = startlati1
							drone2 = strconv.Itoa(rand.Intn(dronemax-dronemin+1) + dronemin)

						}
						min := 25
						max := 30
						randomYawAngle := rand.Intn(max-min+1) + min

						if msgtype == 224 {
							var report1 mavlink.DroneIDReport
							report1.IsOnline = common.DevOnline
							report1.Electricity = 66
							report1.TimeStamp = 1
							report1.Sn = "Tracer_123456"
							report1.BatteryStatus = 2
							report1.AlarmLevel = 0
							report1.WorkMode = 1
							report1.WorkStatus = 1

							msg := common.EquipmentMessageBoxEntity{
								Name:      "Tracer_123456",
								Sn:        "Tracer_123456",
								MsgType:   mavlink.DRONEIDMsgHeartbeat,
								EquipType: int(common.DEV_V2DRONEID),
								Info:      report1,
							}
							_ = mq.V2DroneIdBroker.Publish(mq.V2DroneIdTopic, broker.NewMessage(msg))
							logger.Infof("heartbeat has reported, devSn: %v, Drone size: %v", "Tracer_123456")

							var report mavlink.TracerDetectReport
							report.Description = make([]*mavlink.TracerDetectDescriptionReport, 0, 1)

							report.Sn = "Tracer_123456"

							//查白名单中的无人机，在Tracer侦测结果中添加无人机角色
							whiteList := &client.ListResAll{}
							err := NewWhiteList().ListAll(context.Background(), &client.ListReqAll{}, whiteList)
							if err != nil {
								logger.Error("Get whiteList err: ", err)
								return
							}
							var role1, role2 int32
							for _, info := range whiteList.WhiteList {
								if info.Sn == drone1 {
									role1 = info.Role
								}
								if info.Sn == drone2 {
									role2 = info.Role
								}
							}
							if role1 == ERRTYPE {
								role1 = ENEMY
							}
							if role2 == ERRTYPE {
								role2 = ENEMY
							}
							r := &mavlink.TracerDetectDescriptionReport{
								ProductType:        1,
								DroneName:          "DJI Phantom 1",
								SerialNum:          drone1,
								DroneLongitude:     templong,
								DroneLatitude:      templati,
								DroneHeight:        80,
								DroneYawAngle:      float64(randomYawAngle),
								DroneSpeed:         5,
								DroneVerticalSpeed: 1,
								OperatorLongitude:  OperatorLongitude,
								OperatorLatitude:   OperatorLatitude,
								Freq:               2.4,
								Distance:           150,
								DangerLevels:       1,
								Role:               role1,
							}
							r2 := &mavlink.TracerDetectDescriptionReport{
								ProductType:        1,
								DroneName:          "DJI Phantom 3",
								SerialNum:          drone2,
								DroneLongitude:     templong1,
								DroneLatitude:      templati1,
								DroneHeight:        150,
								DroneYawAngle:      float64(randomYawAngle),
								DroneSpeed:         4,
								DroneVerticalSpeed: 1,
								OperatorLongitude:  OperatorLongitude2,
								OperatorLatitude:   OperatorLatitude2,
								Freq:               2.4,
								Distance:           100,
								DangerLevels:       1,
								Role:               role2,
							}
							logger.Infof("droneID Detect data: %+v", *r)
							report.Description = append(report.Description, r)
							report.Description = append(report.Description, r2)
							msg1 := common.EquipmentMessageBoxEntity{
								Name:      "Tracer_123456",
								Sn:        "Tracer_123456",
								MsgType:   mavlink.TracerIdGetDetectRes,
								EquipType: int(common.DEV_V2DRONEID),
								Info:      report,
							}
							_ = mq.TracerDetectBroker.Publish(mq.TracerDetectTopic, broker.NewMessage(msg1))
							logger.Infof("Tracer Detect has reported, devSn: %v, Drone size: %v", "Tracer_123456", len(report.Description))
							logger.Info("--->End Report Detect Res")
						} else if msgtype == 225 {
							var report mavlink.TracerRemoteDetectReport
							report.Description = make([]*mavlink.TracerRemoteDetectDescriptionReport, 0, 1)
							report.Sn = "Tracer_123456"

							//查白名单中的无人机，在Tracer侦测结果中添加无人机角色
							whiteList := &client.ListResAll{}
							err := NewWhiteList().ListAll(context.Background(), &client.ListReqAll{}, whiteList)
							if err != nil {
								logger.Error("Get whiteList err: ", err)
								return
							}
							var role1 int32
							for _, info := range whiteList.WhiteList {
								if info.Sn == drone1 {
									role1 = info.Role
								}
							}
							if role1 == ERRTYPE {
								role1 = ENEMY
							}
							r := &mavlink.TracerRemoteDetectDescriptionReport{
								ProductType:         1,
								DroneName:           "Autel lite rid1",
								SerialNum:           drone1,
								DroneLongitude:      templong,
								DroneLatitude:       templati,
								DroneHeight:         60,
								DroneDirection:      24,
								DroneYawAngle:       float64(randomYawAngle),
								DroneSpeed:          3,
								DroneSpeedderection: 2,
								DroneVerticalSpeed:  2,
								OperatorLongitude:   OperatorLongitude3,
								OperatorLatitude:    OperatorLatitude3,
								Freq:                2.4,
								Distance:            90,
								DangerLevels:        2,
								Role:                role1,
							}
							logger.Infof("droneID Detect Remote data: %+v", *r)
							report.Description = append(report.Description, r)

							msg1 := common.EquipmentMessageBoxEntity{
								Name:      "Tracer_123456",
								Sn:        "Tracer_123456",
								MsgType:   mavlink.TracerIdGetRemoteIdDetectRes,
								EquipType: int(common.DEV_V2DRONEID),
								Info:      report,
							}
							_ = mq.TracerDetectBroker.Publish(mq.TracerDetectTopic, broker.NewMessage(msg1))
							logger.Infof("Tracer Detect Remote has reported, devSn: %v, Drone size: %v", "Tracer_123456", len(report.Description))
							logger.Info("--->End Receive Remote Report Res")

							var report1 mavlink.DroneIDReport
							report1.IsOnline = common.DevOnline
							report1.Electricity = 66
							report1.TimeStamp = 1
							report1.Sn = "Tracer_123456"
							report1.BatteryStatus = 2
							report1.AlarmLevel = 0
							report1.WorkMode = 1
							report1.WorkStatus = 1

							msg := common.EquipmentMessageBoxEntity{
								Name:      "Tracer_123456",
								Sn:        "Tracer_123456",
								MsgType:   mavlink.DRONEIDMsgHeartbeat,
								EquipType: int(common.DEV_V2DRONEID),
								Info:      report1,
							}
							_ = mq.V2DroneIdBroker.Publish(mq.V2DroneIdTopic, broker.NewMessage(msg))
							logger.Infof("heartbeat has reported, devSn: %v, Drone size: %v", "Tracer_123456")

						} else if msgtype == 226 {

							var report1 mavlink.DroneIDReport
							report1.IsOnline = common.DevOnline
							report1.Electricity = 66
							report1.TimeStamp = 1
							report1.Sn = "Tracer_123456"
							report1.BatteryStatus = 2
							report1.AlarmLevel = 0
							report1.WorkMode = 3
							report1.WorkStatus = 1

							//更新状态：
							tracerSDev := &DroneID{
								Device: &Device{},
							}
							tracerSDev.WorkMode = 3
							tracerSDev.updateStatus("Tracer_123456")
							//tmpDroneId, ok := DevStatusMap.Load(cacheKey)
							////if ok {
							////	logger.Infof("droneId: %v", tmpDroneId.(*Device).WorkMode)
							////}

							msg := common.EquipmentMessageBoxEntity{
								Name:      "Tracer_123456",
								Sn:        "Tracer_123456",
								MsgType:   mavlink.DRONEIDMsgHeartbeat,
								EquipType: int(common.DEV_V2DRONEID),
								Info:      report1,
							}
							_ = mq.V2DroneIdBroker.Publish(mq.V2DroneIdTopic, broker.NewMessage(msg))
							logger.Infof("heartbeat has reported, devSn: %v, Drone size: %v", "Tracer_123456")

							var report mavlink.TracerFreqDetectReport
							report.Description = make([]*mavlink.TracerFreqDetectDescriptionReport, 0, 1)

							report.Sn = "Tracer_123456"
							report.DxPower = 15.3
							report.QxPower = 20.4
							horizon = horizon + 1
							if horizon > maxHorizon {
								horizon = minHorizon
							}
							report.DxHorizon = float64(horizon)

							r := &mavlink.TracerFreqDetectDescriptionReport{
								UavNumber:     0004,
								DroneName:     "DJI Phantom 3",
								DroneHorizon:  90.4,
								UFreq:         2.4,
								UDangerLevels: 1,
								UMoving:       1,
								Dist:          350.6,
								Recerve:       0,
							}
							logger.Infof("droneID Detect Freq data: %+v", *r)
							report.Description = append(report.Description, r)

							msg1 := common.EquipmentMessageBoxEntity{
								Name:      "Tracer_123456",
								Sn:        "Tracer_123456",
								MsgType:   mavlink.TracerIdGetFreqDetectRes,
								EquipType: int(common.DEV_V2DRONEID),
								Info:      report,
							}
							_ = mq.TracerDetectBroker.Publish(mq.TracerDetectTopic, broker.NewMessage(msg1))
							logger.Info("--->End Receive Freq Report Res")
							logger.Infof("Tracer Detect Freq has reported, devSn: %v, Drone size: %v", "Tracer_123456", len(report.Description))
						}
					case <-StopCh:
						V2DroneIDOfflineReport("Tracer_123456", 0)
						return
					}
				}
			}()
		}

		if IsSimulateMode == 4 && IsRunSimulateMode == true {
			go func() {
				StopCh <- true
				IsRunSimulateMode = false
				DevStatusMap.Delete(cacheKey)
				logger.Info("删除模拟设备")
			}()
			time.Sleep(2 * time.Second)
		}
	}

	if IsSimulateMode == 5 || IsSimulateMode == 6 {
		cacheKey := fmt.Sprintf("%d_%s", common.DEV_AGX, "Agx_123456")
		_, ok := DevStatusMap.Load(cacheKey)

		if !ok && IsSimulateMode == 5 {
			//如果不存在则根据消息id创建一个,这里不做保持，在心跳那里保存
			dev := &Device{
				Sn:             "Agx_123456",
				Conn:           nil,
				Status:         common.DevOffline,
				RemoteIp:       "127.0.0.1",
				DevType:        common.DEV_AGX,
				FirstHeartTime: time.Now(),
				LastHeartTime:  time.Now(),
				IsEnable:       common.DeviceEnable,
			}
			DevStatusMap.Store(cacheKey, dev)
			logger.Info("添加模拟设备")
			time.Sleep(time.Second * 1)
			err := NewEquipList().Update(context.Background(), &client.EquipCrudReq{Sn: "Agx_123456", Etype: "Agx", IsEnable: true}, &client.EquipCrudRes{})

			if err != nil {
				logger.Error("Agx Insert err:", err)
				return
			}
			go func() {
				IsRunSimulateMode = true
				var ticker *time.Ticker
				var tickerUav *time.Ticker
				var tickerDev *time.Ticker
				ticker = time.NewTicker(time.Millisecond * 1000)
				tickerUav = time.NewTicker(time.Millisecond * 300)
				tickerDev = time.NewTicker(time.Millisecond * 5000)
				defer ticker.Stop()
				defer tickerUav.Stop()
				defer tickerDev.Stop()
				rand.Seed(time.Now().UnixNano())

				// 设置随机种子

				for {
					select {
					case <-ticker.C: //
						dataInfo := &client.AgxHeartBeatInfo{
							Header: &client.EquipmentMessageBoxEntity{
								Name:      "Agx_123456",
								Sn:        "Agx_123456",
								EquipType: int32(common.DEV_AGX),
								MsgType:   mavlink.AgxMsgHeartBeat,
							},
							Data: &client.AgxHeartBeatReport{
								Electricity: 66,
								Status:      0,
								IsOnline:    common.DevOnline,
								Sn:          "Agx_123456",
							},
						}
						msg, err := proto.Marshal(dataInfo)
						if err != nil {
							logger.Error("marshal dataInfo err:", err)
							return
						}
						report := &client.ClientReport{
							MsgType: common.ClientMsgIdAgxHeartData,
							Data:    msg,
						}
						out, err := proto.Marshal(report)
						if err != nil {
							logger.Error("marshal report err:", err)
							return
						}
						_ = mq.AgxMsgBroker.Publish(mq.AgxTopic, broker.NewMessage(out))
					case <-tickerUav.C:
						agxResult := make([]*client.AgxDetectInfoList, 0)

						r := &client.AgxDetectInfoList{
							ObjId:            1,
							HeaderUid:        0,
							Azimuth:          1,
							ObjDistInterpol:  0,
							Elevation:        1,
							Velocity:         3,
							DopplerChn:       4,
							Mag:              5,
							Ambiguous:        6,
							Classification:   7,
							ClassfyProb:      8,
							ExistingProb:     9,
							AbsVel:           1,
							OrientationAngle: 12,
							Alive:            2,
							TwsTasFlag:       1,
							X:                50,
							Y:                60,
							Z:                70,
							Vx:               10,
							Vy:               20,
							Vz:               30,
							Ax:               40,
							Ay:               50,
							Az:               60,
						}
						agxResult = append(agxResult, r)

						dataInfo := &client.AgxDetectInfo{
							Header: &client.EquipmentMessageBoxEntity{
								Name:      "Agx_123456",
								Sn:        "Agx_123456",
								EquipType: int32(common.DEV_AGX),
								MsgType:   mavlink.AgxMsgDetect,
							},
							Data: agxResult,
						}
						msg, err := proto.Marshal(dataInfo)
						if err != nil {
							logger.Error("marshal dataInfo err:", err)
							return
						}
						report := &client.ClientReport{
							MsgType: common.ClientMsgIdAgxDetectData,
							Data:    msg,
						}
						out, err := proto.Marshal(report)
						if err != nil {
							logger.Error("marshal report err:", err)
							return
						}
						_ = mq.AgxMsgBroker.Publish(mq.AgxTopic, broker.NewMessage(out))
					case <-tickerDev.C:
						agxResult := make([]*client.AgxDeviceSn, 0)

						agxResult = append(agxResult, &client.AgxDeviceSn{
							DevType: 1,
							DevSn:   "test123456789",
						})
						agxResult = append(agxResult, &client.AgxDeviceSn{
							DevType: 1,
							DevSn:   "test111111111",
						})
						agxResult = append(agxResult, &client.AgxDeviceSn{
							DevType: 1,
							DevSn:   "radar0000000000",
						})

						dataInfo := &client.AgxDevStateInfo{
							Header: &client.EquipmentMessageBoxEntity{
								Name:      "Agx_123456",
								Sn:        "Agx_123456",
								EquipType: int32(common.DEV_AGX),
								MsgType:   mavlink.AgxMsgDeviceStatus,
							},
							Data: &client.AgxDevStateList{
								Sn:   "Agx_123456",
								List: agxResult,
							},
						}
						msg, err := proto.Marshal(dataInfo)
						if err != nil {
							logger.Error("marshal dataInfo err:", err)
							return
						}
						report := &client.ClientReport{
							MsgType: common.ClientMsgIdAgxDevStatusData,
							Data:    msg,
						}
						out, err := proto.Marshal(report)
						if err != nil {
							logger.Error("marshal report err:", err)
							return
						}
						_ = mq.AgxMsgBroker.Publish(mq.AgxTopic, broker.NewMessage(out))

					case <-StopCh:
						AgxOfflineReport("Agx_123456")
						return
					}
				}
			}()
		}

		if IsSimulateMode == 6 && IsRunSimulateMode == true {
			go func() {
				StopCh <- true
				IsRunSimulateMode = false
				DevStatusMap.Delete(cacheKey)
				logger.Info("删除模拟设备")
			}()
			time.Sleep(2 * time.Second)
		}
	}
	return
}

// DeleteDevFromDevStatusMap 关闭设备连接并从DevStatusMap中剔除设备
func DeleteDevFromDevStatusMap(dev *Device) {
	dev.Close()
	cacheKey := fmt.Sprintf("%d_%s", dev.DevType, dev.Sn)
	_, ok := DevStatusMap.Load(cacheKey)
	if ok {
		DevStatusMap.Delete(cacheKey)
		logger.Info("剔除设备: ", cacheKey)
		fmt.Println("==================剔除设备: ", cacheKey)
	}
}

/*
1.检查帧头
2.检查长度
3.检查checkSum
4.检查crc
5.是否要检查序列号
*/
func Check(d []byte) error {
	if err := mavlink.CheckFrame(d); err != nil {
		return err
	}
	dataLen := mavlink.GetDataLen(d)
	if len(d) != dataLen+mavlink.HeaderLen+mavlink.CrcLen {
		return errors.New("长度错误")
	}
	if err := mavlink.CheckChecksum(d); err != nil {
		return err
	}
	if err := mavlink.CheckCrc(d); err != nil {
		return err
	}
	return nil
}

// CheckIsReset 判断链接是否是设备进行更新升级系统复位后建立的连接
func CheckIsReset(conn net.Conn, mailbox map[int]*WaitTaskManager) {
	addrPort := strings.Split(conn.RemoteAddr().String(), ":")
	addr := addrPort[0]
	d, ok := DevResetMap.Load(addr)
	logger.Info("CheckIsReset: ", addr, ok)
	if ok {
		dev, t := d.(*Device)
		if !t {
			fmt.Println(t)
		}
		if dev.Conn != nil {
			fmt.Println("CheckIsReset dev.Close ", dev.RemoteIp)
			dev.Close()
		}
		// 更新链接
		dev.Conn = conn
		dev.WaitTaskMap = mailbox
		cacheKey := fmt.Sprintf("%d_%s", dev.DevType, dev.Sn)
		logger.Infof("从新缓存了设备： %v 连接\n", cacheKey)
		// 保存到DevStatusMap中
		DevStatusMap.Store(cacheKey, dev)
		logger.Debug("[CheckIsReset] DevStatus Stroe sn:", dev.Sn)
		DevResetMap.Delete(addr)
	}
	return
}

func Handle(ctx context.Context, conn net.Conn) {
	defer func() {
		if err := conn.Close(); err != nil {
			logger.Error("return handle close err:", err)
		}
	}()

	remoteAddr := strings.Split(conn.RemoteAddr().String(), ":")
	var mailBox map[int]*WaitTaskManager
	mbox, ok := GWaitTaskMap.Load(remoteAddr[0])
	if !ok {
		mailBox = make(map[int]*WaitTaskManager)
		GWaitTaskMap.Store(remoteAddr[0], mailBox)
	} else {
		mailBox = mbox.(map[int]*WaitTaskManager)
	}

	// 判断链接是否是系统复位后建立的连接
	CheckIsReset(conn, mailBox)

	logger.Debugf("设备 %v 建立链接 \n", conn.RemoteAddr())
	defer logger.Debugf("设备 %v 断开链接\n", conn.RemoteAddr())
	cacheBuff := make([]byte, 0)
	packetLen := 0
	go func() {
		<-ctx.Done()
		if conn != nil {
			if err := conn.Close(); err != nil {
				logger.Error("context done close err:", err)
			}
		}
		return
	}()
	for {
		buff := make([]byte, common.MaxReceiveSize*60) //to support fpv video stream
		n, err := conn.Read(buff)
		if err != nil {
			// 通常遇到的错误是连接中断或被关闭，用io.EOF表示
			if err == io.EOF {
				logger.Info("tcp conn receive close:", conn.RemoteAddr())
			} else {
				logger.Info("tcp conn receive err:", err)
			}
			return
		}
		if n <= 0 {
			continue
		}
		logger.Infof("tcp receive data:[% x],len:%d", buff[:n], n)
		if buff[mavlink.FrameLoc] == mavlink.FrameStart {
			packetLen = mavlink.GetPacketLen(buff[:n])
		}

		//通过dataLen和n 处理接收长度小于1024 但是是拆包的情况。这里用队列会好些，不过队列的个数会有点多
		if packetLen > n && packetLen > len(cacheBuff)+n {
			cacheBuff = append(cacheBuff, buff[:n]...)
			logger.Info("当前buf长度：", len(cacheBuff))
			continue
		}

		cacheBuff = append(cacheBuff, buff[:n]...)
		if cacheBuff[mavlink.FrameLoc] != mavlink.FrameStart {
			logger.Info("首字节1不对清空buf")
			cacheBuff = make([]byte, 0)
			packetLen = 0
			continue
		}
		//如果拆包后剩下mavlink前3位以内
		packetLen = mavlink.GetPacketLen(cacheBuff)
		//处理粘包、粘包+拆包
		for packetLen > 0 && len(cacheBuff) >= packetLen && cacheBuff[mavlink.FrameLoc] == mavlink.FrameStart {
			if dev := GetDevice(conn, cacheBuff[:packetLen], mailBox); dev != nil {
				//日志消息不能并发处理
				if (cacheBuff[mavlink.MsgIdLoc] >= mavlink.AEAGGetLogList && cacheBuff[mavlink.MsgIdLoc] <= mavlink.AEAGDeleteLog) ||
					(cacheBuff[mavlink.MsgIdLoc] >= mavlink.RadarGetLogList && cacheBuff[mavlink.MsgIdLoc] <= mavlink.RadarDeleteLog) ||
					(cacheBuff[mavlink.MsgIdLoc] >= mavlink.SflHeartMsg && cacheBuff[mavlink.SenderLoc] == 0x0B) || //哨兵塔心跳
					(cacheBuff[mavlink.MsgIdLoc] >= mavlink.RadarIdHeartbeat && cacheBuff[mavlink.SenderLoc] == 0x03) || //雷达心跳
					(cacheBuff[mavlink.MsgIdLoc] >= mavlink.AgxMsgHeartBeat && cacheBuff[mavlink.SenderLoc] == 0x0C) || //AGX心跳
					(cacheBuff[mavlink.MsgIdLoc] >= mavlink.AgxMsgDetect && cacheBuff[mavlink.SenderLoc] == 0x0C) || //AGX 无人机消息
					(cacheBuff[mavlink.MsgIdLoc] >= mavlink.AgxMsgPerception && cacheBuff[mavlink.SenderLoc] == 0x0C) || //AGX 感知信息上报
					(cacheBuff[mavlink.MsgIdLoc] >= mavlink.AgxMsgPTZStatus && cacheBuff[mavlink.SenderLoc] == 0x0C) || //AGX 上报PTZ状态
					(cacheBuff[mavlink.MsgIdLoc] >= mavlink.DRONEIDMsgHeartbeat && cacheBuff[mavlink.SenderLoc] == 0x07) { //Tracer
					dev.Deal()
				} else {
					go dev.Deal()
				}
			}

			cacheBuff = cacheBuff[packetLen:]
			logger.Infof("处理buf:%d,剩余buf:%d", packetLen, len(cacheBuff))
			if len(cacheBuff) > 0 {
				//再判断一次帧头，不符合直接抛弃
				if cacheBuff[mavlink.FrameLoc] != mavlink.FrameStart {
					logger.Info("首字节2不对清空buf")
					cacheBuff = make([]byte, 0)
					packetLen = 0
					break
				}
				packetLen = mavlink.GetPacketLen(cacheBuff)
				if packetLen <= mavlink.HeaderLen+mavlink.CrcLen {
					packetLen = 0
					break
				}
			} else {
				packetLen = 0
			}
		}
	}
}

// 定时在线检测
func OnlineCheck() {
	ticker := time.NewTicker(time.Millisecond * 500)
	defer ticker.Stop()
	for range ticker.C {
		if IsSimulateMode == 1 || IsSimulateMode == 3 {
			continue
		}
		now := time.Now()
		DevStatusMap.Range(func(key, value interface{}) bool {
			dev := value.(*Device)
			if now.Sub(dev.LastHeartTime) > CheckOnlineDuration && dev.Status == common.DevOnline {
				logger.Errorf("检测到设备已离线: %v, %v, %v", dev.Sn, dev.LastHeartTime, dev.DevType)
				dev.Status = common.DevOffline
				if dev.DevType == common.DEV_RADAR {
					RadarOfflineReport(dev.Sn, dev.RemoteIp)
				} else if dev.DevType == common.DEV_AEAG {
					msg := common.EquipmentMessageBoxEntity{
						Name: dev.Sn,
						Sn:   dev.Sn,
						Info: common.AeagHeartbeatReport{
							Heartbeat: &common.GunStatusReport{
								Electricity: 0,
								WorkStatus:  common.DevOffline,
								IsOnline:    common.DevOffline,
							},
						},
						MsgType:   mavlink.AEAGMsgHeartbeat,
						EquipType: int(common.DEV_AEAG),
					}
					_ = mq.GunHeartBroker.Publish(mq.GunHeartTopic, broker.NewMessage(msg))
				} else if dev.DevType == common.DEV_SCREEN {
					ScreenOfflineReport(dev.Sn, dev.RemoteIp)
				} else if dev.DevType == common.DEV_V2DRONEID {
					V2DroneIDOfflineReport(dev.Sn, dev.RemotePort)
				} else if dev.DevType == common.DEV_FPV {
					FpvOfflineReport(dev.Sn)
				} else if dev.DevType == common.DEV_SFL {
					SflOfflineReport(dev.Sn)
				} else if dev.DevType == common.DEV_AGX {
					AgxOfflineReport(dev.Sn)
				}
			}
			return true
		})
	}
}

func DetectEventCheck() {
	ticker := time.NewTicker(time.Millisecond * 100)
	defer ticker.Stop()
	//var printNum int32 = 0
	for range ticker.C {

		now := time.Now()
		DevDetectMapOnEvent.Range(func(key, value any) bool {
			detect := value.(*DetectEvent)
			if now.Sub(detect.LastReceiveTime) > 10*time.Second {
				logger.Errorf("event check detect disappear, detect: %v,", detect)
				if detect.DevType == common.DEV_SFL {
					SflDetectDisappearEventReport(detect.Sn)

				} else if detect.DevType == common.DEV_V2DRONEID {
					TracerDetectDisappearEventReport(detect.Sn)

				} else if detect.DevType == common.DEV_AGX {
					AgxDetectDisappearEventReport(detect.Sn)
				}
			}
			return true
		})
	}
}
func OffLineEventCheck() {
	ticker := time.NewTicker(time.Millisecond * 100)
	defer ticker.Stop()
	for range ticker.C {
		now := time.Now()
		DevStatusMapOnEvent.Range(func(key, value interface{}) bool {
			dev := value.(*Device)
			if now.Sub(dev.LastHeartTime) > time.Second*10 {
				logger.Error("event check dev offline,", dev.Sn, dev.LastHeartTime)
				dev.Status = common.DevOffline
				if dev.DevType == common.DEV_SFL {
					SflOffLineEventReport(dev.Sn)

				} else if dev.DevType == common.DEV_V2DRONEID {
					TracerOffLineEventReport(dev.Sn)

				} else if dev.DevType == common.DEV_AGX {
					AgxOffLineEventReport(dev.Sn)
				}
			}
			return true
		})
	}
}
func SflHitOverEventCheck() {
	ticker := time.NewTicker(time.Millisecond * 1)
	defer ticker.Stop()
	for range ticker.C {
		now := time.Now()
		SflHitOverMapOnEvent.Range(func(key, value interface{}) bool {
			hitNode := value.(*common.SflHitEventInfo)
			if now.Sub(hitNode.HitOverTime) >= time.Second*10 {
				logger.Errorf("event sfl hit over succ, uav sn: %v, hit overTime: %v ,", hitNode.Sn, hitNode.HitOverTime)
				SflHitOverEventReport(hitNode)
			}
			return true
		})
	}
}

func IsOffline(cacheKey string) bool {
	if value, ok := DevStatusMap.Load(cacheKey); ok {
		dev := value.(*Device)
		if dev.Status == common.DevOffline && !dev.LastHeartTime.IsZero() {
			return true
		}
	}
	return false
}

func GetDeviceLogList(sn string) ([]DeviceLogList, error) {
	logger.Info("-->Into Get LogList")

	dev, devType := FindCacheDeviceAndType(sn)
	if dev == nil {
		logger.Error("设备未在线")
		return nil, nil
	}
	if devType == common.DEV_SCREEN {
		logger.Info("-->Into Get Gun LogList")

		logInfo := make([]DeviceLogList, 0)
		gun := &CounterGun{Device: dev}
		logListRes, err := gun.SendGetLogList(sn)
		//gun.LogOperator(req, rsp, err)
		if err != nil || logListRes == nil {
			return nil, err
		}

		for _, v := range logListRes.LogListAll {
			for _, v1 := range v.LogInfo {
				status := false
				logInfo = append(logInfo, DeviceLogList{
					LogName:    string(v1.LogName),
					LogDataLen: v1.LogDataLen,
					LogState:   status,
				})
			}
		}
		logger.Info("-->Get Gun LogList List is: %v", logInfo)
		logger.Info("-->Get Gun LogList End")
		mavlink.GunResAll.DeleteData()
		return logInfo, nil
	} else if devType == common.DEV_RADAR {
		logger.Info("-->Into Get Radar LogList")
		radar := &Radar{Device: dev}
		logListRes, err := radar.SendGetLogList(sn)
		if err != nil || logListRes == nil {
			return nil, err
		}
		logInfo := make([]DeviceLogList, 0)

		for _, v := range logListRes.LogListAll {
			for _, v1 := range v.RadarLogInfo {
				status := false
				logInfo = append(logInfo, DeviceLogList{
					LogName:    string(v1.LogName),
					LogDataLen: v1.LogDataLen,
					LogState:   status,
				})
			}
		}
		logger.Info("-->Get Radar LogList List is: ", logInfo)
		logger.Info("-->Get Radar LogList End")
		mavlink.RadarResAll.DeleteData()
		return logInfo, nil
	} else if devType == common.DEV_V2DRONEID {
		logger.Info("-->Into Get DroneId LogList")
		DroneId := &DroneID{Device: dev}
		logListRes, err := DroneId.SendGetLogList(sn)
		if err != nil || logListRes == nil {
			return nil, err
		}
		logInfo := make([]DeviceLogList, 0)

		for _, v := range logListRes.LogListAll {
			for _, v1 := range v.DroneIdLogInfo {
				status := false
				logInfo = append(logInfo, DeviceLogList{
					LogName:    string(v1.LogName),
					LogDataLen: v1.LogDataLen,
					LogState:   status,
				})
			}
		}
		logger.Info("-->Get DroneId LogList List is: ", logInfo)
		logger.Info("-->Get DroneId LogList End")
		mavlink.DroneIdResAll.DeleteData()
		return logInfo, nil
	} else if devType == 0 {
		logger.Error("设备未在线")
		return nil, nil
	}
	return nil, nil
}
func GetDeviceLog(sn, logPath string, logList []DeviceLogList) {
	dev, devType := FindCacheDeviceAndType(sn)
	if dev == nil {
		logger.Error("设备未在线")
		return
	}
	if devType == common.DEV_SCREEN {
		logger.Info("-->Into Get GunLog")
		go func() {
			//for _, list := range logList {
			for i := len(logList) - 1; i >= 0; i-- {
				list := logList[i]
				time.Sleep(3 * time.Second)
				gun := &CounterGun{Device: dev}
				logInfo := make([]DeviceLogList, 0)
				logInfo = append(logInfo, DeviceLogList{
					LogName:    list.LogName,
					LogDataLen: list.LogDataLen,
					LogState:   false,
				})
				_, err := gun.SendGetLog(sn, logPath, logInfo)
				gun.LogOperator(sn, "", err)
				if err != nil {
					logger.Error("-->Get Gun Log fail")
					return
				}
				logger.Info("-->Get Gun Log:", list.LogName)
			}
			logger.Error("-->Get Gun Log over")
		}()
	} else if devType == common.DEV_RADAR {
		logger.Info("-->Into Get Radar Log")
		go func() {
			for _, list := range logList {
				time.Sleep(3 * time.Second)
				radar := &Radar{Device: dev}
				_, err := radar.SendGetLog(sn, logPath, list)
				if err != nil {
					logger.Error("-->Get Radar Log fail")
					return
				}
				logger.Info("-->Get Radar Log:", list.LogName)
			}
			logger.Info("-->Get Radar Log over")
		}()
	} else if devType == common.DEV_V2DRONEID {
		logger.Info("-->Into Get DroneID Log")
		go func() {
			for _, list := range logList {
				time.Sleep(3 * time.Second)
				droneID := &DroneID{Device: dev}
				_, err := droneID.SendGetLog(sn, logPath, list)
				if err != nil {
					logger.Error("-->Get DroneID Log fail")
					return
				}
				logger.Info("-->Get DroneID Log:", list.LogName)
			}
			logger.Info("-->Get DroneID Log over")
		}()
	} else if devType == 0 {
		logger.Error("设备未在线")
		return
	}
}
func UploadDevLog(req []UploadDevLogCloud) error {
	logger.Info("-->Into Upload Device Log Cloud")
	for _, loginfo := range req {
		//打开文件
		logger.Info("LogPath is %v", loginfo.LogPath+loginfo.LogName)

		uploadFile, err := os.Open(loginfo.LogPath + loginfo.LogName)
		if err != nil {
			logger.Error("Open file [%v] err:%v", loginfo.LogPath+loginfo.LogName, err)
			return err
		}
		defer uploadFile.Close()

		info, err := uploadFile.Stat()
		if err != nil {
			logger.Error("File Stat err:%v", err)
			return err
		}
		//文件如果没有内容，不允许上传。
		if info.Size() == 0 {
			logger.Error("File Size is 0")
			continue
			//return errors.New("文件内容为空,上传失败。")
		}
		//判断上传文件设备类型
		var dev awsS3.DevType
		if strings.Contains(loginfo.LogPath, "/guns/") {
			dev = awsS3.GUN
		} else if strings.Contains(loginfo.LogPath, "/radar/") {
			dev = awsS3.RADAR
		} else if strings.Contains(loginfo.LogPath, "/droneID/") {
			dev = awsS3.DRONEID
		}

		err = awsS3.PresigningUploadFile(awsS3.LOG, dev, "User1", loginfo.Sn, loginfo.LogPath, loginfo.LogName)
		if err != nil {
			logger.Error("Presigning Upload File err:", err)
			return err
		}
		logger.Info("Upload succeeded,LogName : ", loginfo.LogName)
	}

	logger.Info("-->Upload Device Log Cloud End")
	return nil
}

func FirstGetLog(sn, logpath string, proid int32) {
	ctx := context.Background()
	if proid < 10 {
		proid = SyncPeriod
	}
	logger.Info("--->Into First Get Log")
	//设备日志开关状态记录到数据库
	err := NewLogStatus().Insert(ctx, &client.LogStatusInsertReq{Sn: sn, Status: 1, Path: logpath, Proid: proid}, &client.LogStatusInsertRsp{})
	if err != nil {
		logger.Error("Log Stat Insert err : ", err)
	}
	logList, err1 := GetDeviceLogList(sn) //获取设备日志列表
	if logList == nil {
		return
	}
	if err1 != nil {
		logger.Error("Get Device Log List err : ", err)
		return
	}

	fileArr := helper.Findfile(logpath) //获取本地文件夹下所有文件的完整路径
	logger.Debug("FileArr is :", fileArr)
	localLogList := make([]DeviceLogList, 0)

	//如果本地文件夹下有设备的文件，则不获取 改进：判断日志大小，修改时间进行判断
	for _, v := range logList {
		isExist := false
		for _, v1 := range fileArr {
			if strings.Contains(v1, v.LogName) {
				isExist = true
			}
		}
		if !isExist {
			localLogList = append(localLogList, DeviceLogList{
				LogName:    v.LogName,
				LogDataLen: v.LogDataLen,
			})
		}
	}
	logger.Info("-->Req Log List is: ", localLogList)
	GetDeviceLog(sn, logpath, localLogList)
	logger.Info("--->End First Get Log")
}

func FirstUploadLog(sn, logpath string, proid int32) {
	ctx := context.Background()
	if proid < 10 {
		proid = SyncPeriod
	}
	logger.Info("--->Into First Upload Log")
	err := NewLogCloudStatus().Insert(ctx, &client.LogCloudStatusInsertReq{Status: 1, Path: logpath, Proid: proid}, &client.LogCloudStatusInsertRsp{})
	if err != nil {
		logger.Error("Log Stat Insert err : ", err)
	}
	//修改数据库
	err = NewLogCloudStatus().Update(ctx, &client.LogCloudStatusUpdateReq{Status: 1}, &client.LogCloudStatusUpdateRsp{})
	if err != nil {
		logger.Error("Log Stat Update err : ", err)
	}
	fileArr := helper.Findfile(logpath) //获取文件夹下所有文件的完整路径
	logger.Info("fileArr is : ", fileArr)
	LogList := make([]UploadDevLogCloud, 0)
	for _, v := range fileArr {
		v = strings.ReplaceAll(v, "\\", "/")
		filePathArr := strings.Split(v, "/")
		fileName := ""
		for i, devType := range filePathArr {
			if devType == "guns" || devType == "radar" || devType == "droneID" {
				sn = filePathArr[i+1]
				logpath = strings.Join(filePathArr[:i+2], "/")
				logger.Info("logpath is : ", logpath)
				logpath = logpath + "/"
				fileName = strings.Join(filePathArr[i+2:], "/")
				logger.Info("fileName is : ", fileName)
			}
		}

		logger.Info("Upload file sn is : ", sn)
		LogList = append(LogList, UploadDevLogCloud{
			LogName: fileName,
			Sn:      sn,
			LogPath: logpath,
		})

	}
	UploadDevLog(LogList)
	logger.Info("--->End First Upload Log")
}

type LogListStart struct {
	Sn         string `json:"Sn"`
	LogPath    string `json:"LogPath"`
	SyncSwitch bool   `json:"SyncSwitch"`
	SyncPeriod int32  `json:"SyncPeriod"`
}

func GetEquipList() []client.EquipInfo {

	logger.Info("-->into Get EquipList")
	equips := make([]client.EquipInfo, 0)
	dbequips := &client.EquipListRes{}
	err := NewEquipList().List(context.Background(), &client.EquipListReq{}, dbequips)
	if err != nil {
		logger.Info("Get EquipList err: ", err)
	}
	for _, value := range dbequips.Equips {
		equips = append(equips, client.EquipInfo{
			Id:         value.Id,
			Reverse:    value.Reverse,
			TerminalId: value.TerminalId,
			Etype:      value.Etype,
			TcpPort:    value.TcpPort,
			UdpPort:    value.UdpPort,
			Ip:         value.Ip,
			CrtTime:    value.CrtTime,
			Status:     string(value.Status),
			UpdateTime: value.UpdateTime,
			Vendor:     "",
			Frequency:  "",
			Model:      "",
			Protocol:   "",
			Name:       value.Name,
			Content:    "",
			IsEnable:   value.IsEnable,
			Sn:         value.Sn,
			IsOnline:   value.Status,
		})
	}
	if equips == nil {
		logger.Info("equips is nil")
		return nil
	}

	return equips
}

func SyncLog() {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	time.Sleep(time.Second * 30)
	var ctx context.Context
	ctx = context.Background()
	logger.Info("-->Into go Sync Log")
	//获取设备列表
	equipList := GetEquipList()
	logger.Info("equipList is :", equipList)

	//获取数据库信息
	logList := &client.LogStatusListRsp{}
	err := NewLogStatus().List(ctx, &client.LogStatusListReq{}, logList)
	if err != nil {
		logger.Error("Log Stat Insert err : ", err)
	}
	if logList == nil {
		return
	}
	logger.Info("db log List is: ", logList)
	for _, equip := range equipList {
		for _, value := range logList.StatusList {
			if equip.Sn == value.Sn && value.Status == SWITCHOPEN { //设备列表里面有，且日志状态为true,则发起同步请求
				url := "http://127.0.0.1:9901/device/sync/log"
				reqData := LogListStart{
					Sn:         value.Sn,
					LogPath:    value.Path,
					SyncSwitch: true,
					SyncPeriod: value.Proid,
				}
				jsonStr, _ := json.Marshal(reqData)
				logger.Info("reqData:", reqData)

				req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonStr))
				if err != nil {
					logger.Error("DownLoadFile New Request err:%v", err)
				}
				req.Header.Set("Content-Type", "application/json")

				client := &http.Client{}
				_, err = client.Do(req)
				if err != nil {
					logger.Error("Client Do err:%v", err)
				}
				time.Sleep(time.Second * 1)
			}
		}
	}
	logger.Info("-->End go Sync Log")

}
func SyncCloudLog() {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	time.Sleep(time.Second * 30)

	var ctx context.Context
	ctx = context.Background()
	logger.Info("-->Into go Sync Cloud Log")
	//获取数据库信息
	logCloudList := &client.LogCloudStatusListRsp{}
	err := NewLogCloudStatus().List(ctx, &client.LogCloudStatusListReq{}, logCloudList)
	if err != nil {
		logger.Error("Log Cloud Stat Insert err : ", err)
	}
	if logCloudList == nil {
		return
	}
	logger.Info("log Cloud List is : ", logCloudList)
	if logCloudList.Status == SWITCHOPEN { //云日志状态为true,则发起同步请求

		url := "http://127.0.0.1:9901/cloud/sync/log"
		reqData := LogListStart{
			Sn:         "",
			LogPath:    logCloudList.Path,
			SyncSwitch: true,
			SyncPeriod: logCloudList.Proid,
		}
		jsonStr, _ := json.Marshal(reqData)
		logger.Info("reqData:", reqData)

		req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonStr))
		if err != nil {
			logger.Error("Log Cloud Stat New Request err:%v", err)
		}
		req.Header.Set("Content-Type", "application/json")

		client := &http.Client{}
		_, err = client.Do(req)
		if err != nil {
			logger.Error("Client Do err:%v", err)
		}

	}
	logger.Info("-->End go Sync Cloud Log")
}

// 清除设备中的数据回放日志
func ReplayDataDel() {
	time.Sleep(time.Second * 30)
	logger.Info("-->Replay Data Del")
	err := NewDataReplay().DataReplayDel(context.Background(), &client.DataReplayDelReq{}, &client.DataReplayDelRes{}) //删除数据库中超过30天的数据回放数据
	if err != nil {
		logger.Info("-->Replay Data Del err:", err)
	}
	logger.Info("-->Replay Data Del")
}

func GetLatestVersion(versions []string) string {
	maxVersion := "0" // 初始化最大版本号为0

	// 遍历所有版本号
	for _, version := range versions {
		// 提取版本号中的数字部分
		re := regexp.MustCompile(`(\d+\.\d+\.\d+\.\d+)`) // 使用正则表达式提取版本号中的数字部分
		match := re.FindStringSubmatch(version)
		if len(match) > 0 {
			currentVersion := match[1]
			// 比较当前版本号和最大版本号，更新最大版本号
			if compareVersion(currentVersion, maxVersion) > 0 {
				maxVersion = currentVersion
			}
		}
	}

	return maxVersion
}

func compareVersion(version1, version2 string) int {
	// 使用"."将版本号分割成多个部分
	v1 := strings.Split(version1, ".")
	v2 := strings.Split(version2, ".")

	// 比较每个部分的大小
	for i := 0; i < len(v1) && i < len(v2); i++ {
		// 将部分版本号转换为整数进行比较
		num1, _ := strconv.Atoi(v1[i])
		num2, _ := strconv.Atoi(v2[i])

		if num1 != num2 {
			// 如果当前部分不相等，则根据数值的比较结果返回对应的值
			return num1 - num2
		}
	}

	// 如果两个版本号的相同部分都相等，则比较它们的长度
	return len(v1) - len(v2)
}

// 将版本号字符串转换为整数切片
func ParseVersionNum(versionStr string) []int {
	parts := strings.Split(versionStr, ".")
	version := make([]int, len(parts))
	for i, p := range parts {
		n, _ := strconv.Atoi(p)
		version[i] = n
	}
	return version
}

// 比较两个版本号大小，如果前者大，则返回1；如果后者大，则返回-1；否则返回0
func CompareVersionsNum(version1, version2 []int) int {
	for i := 0; i < len(version1) && i < len(version2); i++ {
		if version1[i] > version2[i] {
			return 1
		} else if version1[i] < version2[i] {
			return -1
		}
	}
	if len(version1) > len(version2) {
		return 1
	} else if len(version1) < len(version2) {
		return -1
	} else {
		return 0
	}
}

// 获取最大的版本号
func MaxVersion(versions []string) string {
	max := versions[0]
	for _, v := range versions {
		if CompareVersionsNum(ParseVersionNum(v), ParseVersionNum(max)) > 0 {
			max = v
		}
	}
	return max
}

type DetectUavItem struct {
	// 无人机类型
	ProductType int32
	// 字符串 无人机名称
	DroneName string
	// 字符串 无人机SN
	SerialNum string
	// 经度
	Longitude float32
	// 纬度
	Latitude float32
	// 无人机的编号
	ObjectId uint32
	//无人机被锁定时间点
	LockedTime time.Time
	//该无人机是否被锁定; 0: unlocked, 1: locked.
	LockedUavIs int8
}
type DetectEvent struct {
	Sn              string    //设备sn
	LastReceiveTime time.Time //
	DevType         common.DeviceType
	SessionId       int64

	Items            []*DetectUavItem //记录被ptz锁定的无人机信息。
	LockPtzSessionId int64
}

func (d *DetectEvent) String() string {
	ret := "sn: " + d.Sn
	ret += ", lastReceiveTime: " + d.LastReceiveTime.String()
	ret += ", devType: " + d.DevType.ToString()
	ret += ", sessionId: " + strconv.Itoa(int(d.SessionId))
	return ret
}

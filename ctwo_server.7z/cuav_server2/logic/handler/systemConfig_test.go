package handler

import (
	"context"
	"testing"

	"adasgitlab.autel.com/tools/cuav_server/proto/client"
)

func TestSystemConfig_Insert(t *testing.T) {
	type args struct {
		ctx context.Context
		req *client.CrudReq
		res *client.CrudRes
	}
	tests := []struct {
		name    string
		s       *SystemConfig
		args    args
		wantErr bool
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if err := tt.s.Insert(tt.args.ctx, tt.args.req, tt.args.res); (err != nil) != tt.wantErr {
				t.Errorf("SystemConfig.Insert() error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

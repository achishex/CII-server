package handler

import (
	"errors"
	"fmt"
	"math/rand"
	"strings"
	"sync"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/config"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"github.com/aliyun/alibaba-cloud-sdk-go/services/dysmsapi"
	"github.com/patrickmn/go-cache"
	"gopkg.in/gomail.v2"
)

const sendOK = "OK"

type aliSdk struct {
	verificationCodeCache    *cache.Cache
	verificationCodeReqCache *cache.Cache
}

var (
	aliyunOnce   sync.Once
	aliyunEntity *aliSdk
	//EmailSubject = "SKYFEND"
)

const (
	DroneWarn = 1
)
const (
	NUMBERTYPE_CN     int32 = 1
	NUMBERTYPE_ABROAD int32 = 2
)

func NewSDK() *aliSdk {
	aliyunOnce.Do(func() {
		aliyunEntity = new(aliSdk)
		aliyunEntity.verificationCodeReqCache = cache.New(time.Minute, time.Minute)
		aliyunEntity.verificationCodeCache = cache.New(time.Minute*5, time.Minute*5)
	})
	return aliyunEntity
}

func CreateRandCode() string {
	return fmt.Sprintf("%06v", rand.New(rand.NewSource(time.Now().UnixNano())).Int31n(1000000))
}

func (a *aliSdk) SendSms(phone string, numberType int32) (string, error) {
	config := config.GetGlobalConfig()
	_, found := a.verificationCodeReqCache.Get(phone)
	if found {
		return "", errors.New("do not send the verification code repeatedly within a minute")
	}
	var code string
	if numberType == NUMBERTYPE_CN {
		//国内
		client, err := dysmsapi.NewClientWithAccessKey("cn-hangzhou", config.Sms.AccessKeyId, config.Sms.AccessKeySecret)
		if err != nil {
			logger.Errorf("create ali sms client error:%v", err)
			return "", err
		}
		code = CreateRandCode()
		request := dysmsapi.CreateSendSmsRequest()
		request.Scheme = "https"
		request.PhoneNumbers = phone
		request.SignName = config.Sms.SignName

		//国内
		request.TemplateCode = config.Sms.CnTemplatecode
		request.TemplateParam = `{"code":"` + code + `"}`
		response, err := client.SendSms(request)
		if err != nil {
			logger.Errorf("SendSms error %v", err.Error())
			return "", err
		}
		a.verificationCodeReqCache.SetDefault(phone, 1)
		a.verificationCodeCache.SetDefault(phone, code)
		logger.Infof("send code[%v] to phone[%v] success,response is %#v\n", code, phone, response)
		return code, nil
	} else if numberType == NUMBERTYPE_ABROAD {
		//国外
		client, err := dysmsapi.NewClientWithAccessKey("us-west-1", config.Sms.AccessKeyId, config.Sms.AccessKeySecret)
		if err != nil {
			logger.Errorf("create ali sms client error:%v", err)
			return "", err
		}
		code = CreateRandCode()
		request := dysmsapi.CreateSendSmsRequest()
		request.Scheme = "https"
		request.PhoneNumbers = phone
		request.SignName = config.Sms.SignName
		//国外
		request.TemplateCode = config.Sms.AbroadTemplatecode

		request.TemplateParam = `{"code":"` + code + `"}`
		response, err := client.SendSms(request)
		if err != nil {
			logger.Errorf(err.Error())
			return "", err
		}
		a.verificationCodeReqCache.SetDefault(phone, 1)
		a.verificationCodeCache.SetDefault(phone, code)
		logger.Infof("send code[%v] to phone[%v] success,response is %#v\n", code, phone, response)
		return code, nil
	}
	return code, nil
}

func (a *aliSdk) SendEmail(email string) (string, error) {
	toName := strings.Split(email, "@")[0]
	code := CreateRandCode()
	m := gomail.NewMessage()
	emailConf := config.Global.Email
	m.SetAddressHeader("From", emailConf.Sender, emailConf.EmailSubject)
	m.SetHeader("To",
		m.FormatAddress(email, toName),
	)
	m.SetHeader("Subject", emailConf.EmailSubject)
	body := `<p style="font-size: 16px; font-weight: normal;">您本次操作的邮箱验证码为:</p>
<p style="font-size: 20px; font-weight: bold;">%v</p>
<p style="font-size: 16px; font-weight: normal;">10分钟有效。请妥善保管。</p>`
	body = fmt.Sprintf(body, code)

	m.SetBody("text/html", body)
	d := gomail.NewDialer(emailConf.SmtpHost, emailConf.SmtpPort, emailConf.Sender, emailConf.Password)
	if err := d.DialAndSend(m); err != nil {
		logger.Error(err)
		fmt.Println("SendEmail Err: ", err)
	}
	a.verificationCodeReqCache.SetDefault(email, 1)
	a.verificationCodeCache.SetDefault(email, code)
	return code, nil
}

func (a *aliSdk) CheckVerificationCode(phoneOrEmail, verificationCode string) (err error) {
	cacheCode, found := a.verificationCodeCache.Get(phoneOrEmail)
	if !found {
		err = errors.New("verification code has expired")
		return
	}
	cc, sure := cacheCode.(string)
	if !sure {
		err = errors.New("internal service error")
		return
	}
	if cc != verificationCode {
		err = errors.New("incorrect verification code")
		return
	}
	return
}

func (a *aliSdk) NotifySms(req *client.SmsNotifyReq) error {
	config := config.GetGlobalConfig()
	client, err := dysmsapi.NewClientWithAccessKey("cn-hangzhou", config.SmsNotify.AccessKeyId, config.SmsNotify.AccessKeySecret)
	if err != nil {
		logger.Errorf("create ali sms client error:%v", err)
		return err
	}

	request := dysmsapi.CreateSendSmsRequest()
	request.Scheme = "https"
	request.PhoneNumbers = req.Phone
	request.SignName = config.SmsNotify.SignName
	temp, ok := config.SmsNotify.TemplateCode[req.TemplateType]
	if !ok {
		err := fmt.Errorf("non-exist template type %v", req.TemplateType)
		logger.Errorf(err.Error())
		return err
	}
	request.TemplateCode = temp
	response, err := client.SendSms(request)
	if err != nil {
		logger.Errorf(err.Error())
		return err
	}
	if response.Code != sendOK {
		logger.Error(*response)
		return fmt.Errorf(response.Message)
	}

	logger.Infof("sms notify to phone[%v] success, response is %#v\n", req.Phone, response)
	return nil
}

func (a *aliSdk) NotifyEmail(req *client.NotifyReq) error {
	toName := strings.Split(req.Email, "@")[0]
	emailConf := config.Global.Email
	m := gomail.NewMessage()
	m.SetAddressHeader("From", emailConf.Sender, emailConf.EmailSubject)
	m.SetHeader("To",
		m.FormatAddress(req.Email, toName),
	)
	m.SetHeader("Subject", emailConf.EmailSubject)
	switch req.TemplateType {
	case DroneWarn:
		m.SetBody("text/html", "❗发现无人机入侵行为，请保持警惕并及时处理。 ------SKYFEND反无系统")
	default:
		return fmt.Errorf("non-exist template type %v", req.TemplateType)
	}

	d := gomail.NewDialer(emailConf.SmtpHost, emailConf.SmtpPort, emailConf.Sender, emailConf.Password)
	if err := d.DialAndSend(m); err != nil {
		logger.Errorf("email notify err: %v", err.Error())
		return err
	}
	return nil
}

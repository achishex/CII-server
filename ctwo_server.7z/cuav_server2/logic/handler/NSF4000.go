package handler

import (
	"bytes"
	"context"
	"fmt"
	"io"
	"net"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"adasgitlab.autel.com/tools/cuav_plugin/broker"
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/config"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
)

type ControllerNSF4000 struct {
	*Device
	CC            CheatConfig
	AreaDenial    string
	ActiveDefense string
	Version       string
	NFSIP         string
}

var (
	timer     *time.Timer
	timerWork *time.Timer
	limitRate int64 = 1000 * 60 * 30 //30分钟

)

type CheatConfig struct {
	Longititude string
	Latitude    string
	Height      string
}
type NSF4000SendCmdRes struct {
	Status int
}

type NSF4000Msg struct {
	IsOnline    int     `json:"isOnline"`    //1:在线
	IsWorking   int     `json:"isWorking"`   //工作状态： 1：工作中，2：未工作
	GpsStatus   int     `json:"gpsStatus"`   //定位状态 1:已定位  2：未定位
	Ephemeris   int     `json:"ephemeris"`   //星历    1:以获取  2:未获取
	TimeSync    int     `json:"timeSync"`    //时间同步状态  1:已同步  2:未同步
	Longititude float64 `json:"longititude"` //经度
	Latitude    float64 `json:"latitude"`    //纬度
	Height      float64 `json:"height"`
	Enable      bool    `json:"enable"`   //功能开关 true:开启   false:关闭 默认值false
	WorkMode    int32   `json:"workMode"` //工作模式 1：主动防御 2：区域拒止 3：定向驱离 默认值1
	Radius      int32   `json:"radius"`   //防御区半径 默认值500
	Angle       int32   `json:"angle"`    //诱导角度  0/90/180/270   0正北，90正东  1  向上  -1向下  默认值0
	OpsTime     int64   `json:"opsTime"`  //记录操作时长，时间单位为秒(enable_true_time - enable_false_time ) 默认值0

}

var SyncNotifyData = Nsf4000Sync{
	Data: Nsf4000StatuData{
		Radius: 500,
	},
}

type Nsf4000StatuData struct {
	IsStartGoroutine bool   `json:"isStartGoroutine"`          //是否调已经启动过数据同步
	Sn               string `json:"sn,omitempty"`              //设备标识
	Enable           bool   `json:"enable,omitempty"`          //功能开关 true:开启   false:关闭
	WorkMode         int32  `json:"workMode,omitempty"`        //工作模式 1：主动防御 2：区域拒止 3：定向驱离
	Radius           int32  `json:"radius,omitempty"`          //防御区半径
	Angle            int32  `json:"angle,omitempty"`           //诱导角度  0/90/180/270   0正北，90正东  1  向上  -1向下
	EnableStartTime  int64  `json:"enableStartTime,omitempty"` //记录操作时长(enable_true_time - enable_false_time )
}

type Nsf4000Sync struct {
	Data Nsf4000StatuData
	sync.RWMutex
}

func NewControllerNSF4000() *ControllerNSF4000 {
	return &ControllerNSF4000{
		Device:        &Device{},
		AreaDenial:    config.AreaDenial,
		ActiveDefense: config.ActiveDefense,
	}
}

func (ctrl *ControllerNSF4000) Handle(conn net.Conn) {

	ctx, cancel := context.WithCancel(context.Background())
	defer conn.Close()
	defer cancel()
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()

	ctrl.Sn = ""
	ctrl.Version = ""
	go ctrl.GetDevSn(ctx)
	sendTime := 0
	go ctrl.GetDevVer()
	go ctrl.SendHeart(ctx)
	NsfTimeSyncCacheQueue := &common.ReportEntity{ReportTime: time.Time{}, LimitRate: limitRate}
	cache := make([]byte, 0)
	for {
		buf := make([]byte, 1024)
		status := &client.GetStatusRes{}
		err := NewEquipList().GetStatus(context.Background(), &client.GetStatusReq{
			Sn:    ctrl.Sn,
			EType: "Spoofer",
		}, status)
		if err != nil {
			logger.Error("NSF 4000 GetStatus err:", err)
			return
		}
		if status.IsEnable == common.DeviceDisenable {
			return
		}
		// 设置读取操作的截止时间为 6秒后
		err = conn.SetReadDeadline(time.Now().Add(6 * time.Second))
		if err != nil {
			logger.Error(err)
			conn.Close()
			return
		}
		n, err := conn.Read(buf)

		if err != nil {
			// 通常遇到的错误是连接中断或被关闭，用io.EOF表示
			if err == io.EOF {
				logger.Info("conn receive close:", conn.RemoteAddr())
			} else {
				logger.Info("conn receive err:", err)
			}
			ctrl.ReportStatus(2, 2, 2, 2, 2, config.NSF4000TypeOnline, "", "", "") //给前端发离线消息
			return
		}
		if n <= 0 {
			continue
		}
		// update connection
		ctrl.cacheConn(conn)
		// 将读取到的数据追加到消息缓冲区
		cache = append(cache, buf[:n]...)
		for {
			msgIndex := bytes.IndexByte(cache, '$')
			if msgIndex == -1 {
				// 没有找到消息分隔符，跳出内循环等待更多数据
				break
			}

			if msgIndex > 0 {
				// 处理消息
				msg := string(cache[:msgIndex])
				ms := strings.Split(msg, "\r\n")
				var TimeSync int
				var IsWorking int
				var StarReport int
				var GpsStat int
				for _, e := range ms {
					sg := strings.Split(e, ",")

					//fmt.Println(sg)
					if len(sg) <= 1 {
						continue
					}
					logger.Debug("NSF4000 receive msg is :", sg)
					if sg[0] == "RPT" && sg[1] == "ClkDoSta" { //设备上报时钟状态
						if time.Since(NsfTimeSyncCacheQueue.ReportTime).Milliseconds() < NsfTimeSyncCacheQueue.LimitRate {
							continue
						}
						strength, err := strconv.Atoi(sg[len(sg)-1])
						if err == nil && strength > 11 {
							TimeSync = 1
							//上报设备状态消息
							if ctrl.Sn == "" {
								continue
							} else {
								ctrl.ReportStatus(1, GpsStat, TimeSync, StarReport, IsWorking, config.NSF4000TypeTimeSync, "", "", "")
								sendTime++
								if sendTime >= 5 {
									NsfTimeSyncCacheQueue.ReportTime = time.Now()
									sendTime = 0
								}
							}

						} else {
							TimeSync = 2
							//上报设备状态消息
							ctrl.ReportStatus(1, GpsStat, TimeSync, StarReport, IsWorking, config.NSF4000TypeTimeSync, "", "", "")
						}
					} else if sg[0] == "RPT" && sg[1] == "UbxSynTmInfo" { //设备上报星历状态
						//$RPT UbxSynTmInfo 2023-10-09 17:52:17[|11|9|5|6] 0 0     判断星历后4个数都不为0并且相加大于等于7
						if len(sg) < 5 {
							continue
						}
						tempStr := sg[2]
						index := strings.Index(tempStr, "[")
						lastIndex := strings.Index(tempStr, "]")
						targetStr := tempStr[index+1 : lastIndex]
						targetNum := strings.Split(targetStr, "|")
						start1, _ := strconv.Atoi(targetNum[1])
						start2, _ := strconv.Atoi(targetNum[2])
						start3, _ := strconv.Atoi(targetNum[3])
						start4, _ := strconv.Atoi(targetNum[4])
						if start1 > 0 && start2 > 0 && start3 > 0 && start4 > 0 && start1+start2+start3+start4 >= 7 {
							StarReport = 1
							ctrl.ReportStatus(1, GpsStat, TimeSync, StarReport, IsWorking, config.NSF4000TypeEphemeris, "", "", "")
						} else {
							StarReport = 2
							ctrl.ReportStatus(1, GpsStat, TimeSync, StarReport, IsWorking, config.NSF4000TypeEphemeris, "", "", "")
						}

					} else if sg[0] == "RPT" && sg[1] == "FuconPosInfo" { //设备返回的经纬高
						//$RPT FuconPosInfo 201858 22.5971437 113.9982126 25.909 0.004 0.013 -0.001 0.000 0.000
						GpsStat = 1
						ctrl.CC.Longititude = sg[4]
						ctrl.CC.Latitude = sg[3]
						ctrl.CC.Height = sg[5]
						ctrl.ReportStatus(1, GpsStat, TimeSync, StarReport, IsWorking, config.NSF4000TypeLLH, sg[4], sg[3], sg[5])
						ctrl.ReportStatus(1, GpsStat, TimeSync, StarReport, IsWorking, config.NSF4000TypeGpsStatus, sg[4], sg[3], sg[5])
					} else if (sg[0] == "RPT" && sg[1] == "GpsSimSat") ||
						(sg[0] == "RPT" && sg[1] == "BdsSimSat") ||
						(sg[0] == "RPT" && sg[1] == "GloSimSat") ||
						(sg[0] == "RPT" && sg[1] == "GalSimSat") { //设备是否在工作模式
						atomic.AddInt64(&NsfReport, 1)
						temp := atomic.LoadInt64(&NsfReport)
						if temp == 9 {
							atomic.StoreInt64(&NsfReport, 0)
							IsWorking = 1
							ctrl.ReportStatus(1, GpsStat, TimeSync, StarReport, IsWorking, config.NSF4000TypeWorking, "", "", "")
							DeviceNSF4000Map.Set(ctrl.Sn, 1)
							// 重置计时器
							if timerWork != nil {
								timerWork.Stop()
							}
							timerWork = time.AfterFunc(3*time.Second, func() {
								ctrl.ReportStatus(1, 2, 0, 0, 0, config.NSF4000TypeWorking, "", "", "") //给前端发离线消息
							})
						}
					} else if sg[0] == "RACK" && sg[1] == "PkgVer" { //设备版本信息
						ctrl.Version = sg[2]
						ctrl.NFSIP = "192.168.2.74"
						logger.Info("NSF4000 version is :", ctrl.Version)
					} else if sg[0] == "RPT" && sg[1] == "PlyHeartBeat" { //设备发过来的心跳
						if ctrl.Sn != "" {
							// 重置计时器
							if timer != nil {
								timer.Stop()
							}
							timer = time.AfterFunc(5*time.Second, func() {
								ctrl.ReportStatus(2, 2, 2, 2, 2, config.NSF4000TypeOnline, "", "", "") //给前端发离线消息
							})
							ctrl.ReportStatus(1, GpsStat, TimeSync, StarReport, IsWorking, config.NSF4000TypeOnline, "", "", "")
						}
					} else if sg[0] == "RACK" && sg[1] == "JamDeviceNo" { //获取设备唯一标识
						ctrl.Sn = sg[2]

					}
				}
			}
			cache = cache[msgIndex+1:]
		}
	}
}

// GetDevSn 获取设备Sn号
func (ctrl *ControllerNSF4000) GetDevSn(ctx context.Context) {
	timer1 := time.NewTicker(1 * time.Second)
	for {
		select {
		case <-timer1.C:
			if ctrl.Conn == nil || ctrl.Sn != "" {
				continue
			}
			if ctrl.Sn == "" || len(ctrl.Sn) < 10 {
				cmdTemp := "$REQ,JamDeviceNo" + "\r\n"
				ctrl.SendMsg([]byte(cmdTemp))
			}
		case <-ctx.Done():
			return
		}
	}
}

// GetDevVer 获取设备版本信息
func (ctrl *ControllerNSF4000) GetDevVer() {
	timer1 := time.NewTicker(1 * time.Second)
	for {
		select {
		case <-timer1.C:
			if ctrl.Conn == nil {
				continue
			}
			if ctrl.Version == "" {
				cmdTemp := "$REQ,PkgVer" + "\r\n"
				ctrl.SendMsg([]byte(cmdTemp))
			}
			if ctrl.Version != "" {
				return
			}
		}
	}
}

// SendHeart 定时给设备发送心跳
func (ctrl *ControllerNSF4000) SendHeart(ctx context.Context) {
	timer1 := time.NewTicker(1 * time.Second)
	for {
		select {
		case <-timer1.C:
			if ctrl.Conn == nil {
				continue
			}
			cmdTemp := "$SET,PlyHeartBeat,5" + "\r\n"
			ctrl.SendMsg([]byte(cmdTemp))
			logger.Info("Send Heart to NSF4000")
		case <-ctx.Done():
			return
		}
	}
}
func (ctrl *ControllerNSF4000) cacheConn(conn net.Conn) {
	ctrl.Conn = conn
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_NSF4000, ctrl.Sn)
	dev := &Device{
		Sn:   ctrl.Sn,
		Conn: ctrl.Conn,
	}
	reqMode := &ControllerNSF4000{
		Device:  dev,
		Version: ctrl.Version,
		NFSIP:   ctrl.NFSIP,
		CC:      ctrl.CC,
	}
	if ctrl.Sn == "" {
		logger.Error("NSF4000 sn is nil")
		return
	}
	DevStatusNfsMap.Store(cacheKey, reqMode)
}

func (ctrl *ControllerNSF4000) SendMsg(data []byte) int {
	defer func() {
		if err := recover(); err != nil {
			logger.Error("SendMsg 接收到panic:", err)
		}
	}()
	if ctrl.Conn == nil {
		logger.Error("NSF conn is nil")
		return -1
	}
	res, err := ctrl.Conn.Write(data)
	if err != nil {
		logger.Error("NSF Write err:", err)
		ctrl.Conn.Close()
		ctrl.Conn = nil
		return -1
	}
	return res
}

// SetPlay 发起主动防御、区域拒止、定向驱离
func (ctrl *ControllerNSF4000) SetPlay(req *client.InduceRequest) int {
	var res int
	temp := atomic.LoadInt64(&NFSStartCmd)
	if temp == 1 {
		atomic.StoreInt64(&NFSStartCmd, 0)
		logger.Info("NFS Stop Cmd ")
		StopMsg <- true
		config.M_tgtHeading = 0
	}
	if req.Enable {
		if req.WorkMode == int32(config.ACTIVEDEFENSE) { //主动防御
			res = ctrl.SendActiveDefenseCommand(req.Power, req.DefenseLongitude, req.DefenseLatitude, req.Height)
			if res == -1 {
				logger.Error("SendMsg To NSF Active defense err")
				return res
			}
			// req.Radius = 300 //诱导需求 发起时半径写死300
			constRadius := int32(300) //诱导需求 发起时半径写死300
			pos, vel, err := ctrl.CalculatePosAndVel(req.DefenseLevelSpeed, constRadius, req.DefenseVerticalSpeed)
			if err != nil {
				logger.Error("CalculatePosAndVel error:", err)
				return -1
			}
			cmdTemp := "$SET,SimPos,1," + pos + "," + vel + "\r\n"
			cmdTemp1 := "$SET,SimMov,0," + vel + "\r\n"
			logger.Debug("Active defense cmdTemp SimPos is :", cmdTemp)
			logger.Debug("Active defense cmdTemp1 SimMov is :", cmdTemp1)
			logger.Debug("CalculatePosAndVel  :", ctrl.CC)

			time.Sleep(time.Second * 2)

			res = ctrl.SendMsg([]byte(cmdTemp))
			if res == -1 {
				logger.Error("SendMsg To NSF $SET,SimPos,1 err")
				return res
			}

			res = ctrl.SendMsg([]byte(cmdTemp1))
			if res == -1 {
				logger.Error("SendMsg To NSF $SET,SimMov,1 err")
				return res
			}
			go func() {
				atomic.AddInt64(&NFSStartCmd, 1)
				tickerSend := time.NewTicker(time.Second * 1)
				for {
					select {
					case <-tickerSend.C:
						pos, vel, err = ctrl.CalculatePosAndVel(req.DefenseLevelSpeed, constRadius, req.DefenseVerticalSpeed)
						if err != nil {
							logger.Error("CalculatePosAndVel error:", err)
						}
						cmdTemp2 := "$SET,SimMov,0," + vel + "\r\n"
						logger.Debug("CalculatePosAndVel  :", ctrl.CC)
						logger.Debug("Active defense cmdTemp2 SimMov is :", cmdTemp2)
						ctrl.SendMsg([]byte(cmdTemp2))
					case <-StopMsg:
						logger.Debug("Active defense cmdTemp2 stop")
						return

					}
				}
			}()

			ticker := time.NewTicker(time.Millisecond * 100)
			stop := time.NewTicker(time.Second * 10)

			defer ticker.Stop()
			defer stop.Stop()
			DeviceNSF4000Map.Set(ctrl.Sn, 0)
			for {
				select {
				case <-ticker.C:
					statusMap, isexist := DeviceNSF4000Map.Get(ctrl.Sn)
					if isexist == true {
						if statusMap.Status == 1 || statusMap.Status == -1 {
							DeviceNSF4000Map.Set(ctrl.Sn, 0)
							return statusMap.Status
						}
					}
				case <-stop.C:
					return -1
				}
			}

		} else if req.WorkMode == int32(config.AREADENIAL) { //区域拒止
			logger.Debug("Start AreaDenial Cmd is :", config.AreaDenial)
			startCmd := ""
			if req.Power == 0 {
				startCmd = strings.ReplaceAll(config.AreaDenial, "$Power", "0")
				startCmd = strings.ReplaceAll(startCmd, "$Add10", "10")
			} else {
				startCmd = strings.ReplaceAll(config.AreaDenial, "$Power", strconv.Itoa(int(req.Power)))
				startCmd = strings.ReplaceAll(startCmd, "$Add10", strconv.Itoa(int(req.Power+10)))
			}

			longitudeStr := strconv.FormatFloat(req.AreaStopLongitude, 'f', -1, 64)
			latitudeStr := strconv.FormatFloat(req.AreaStopLatitude, 'f', -1, 64)
			startCmd = strings.Replace(startCmd, "$Longititude", longitudeStr, -1)
			startCmd = strings.Replace(startCmd, "$Latitude", latitudeStr, -1)
			startCmd = strings.Replace(startCmd, "$Height", strconv.Itoa(int(req.Height)), -1)
			res = ctrl.SendMsg([]byte(startCmd))

			logger.Info("AREADENIAL  startCmd is :", startCmd)
			if res == -1 {
				logger.Error("SendMsg To NSF Area Denial err")
				return res
			}
			ticker := time.NewTicker(time.Millisecond * 100)
			stop := time.NewTicker(time.Second * 10)

			defer ticker.Stop()
			defer stop.Stop()
			DeviceNSF4000Map.Set(ctrl.Sn, 0)
			for {
				select {
				case <-ticker.C:
					statusMap, isexist := DeviceNSF4000Map.Get(ctrl.Sn)
					if isexist == true {
						if statusMap.Status == 1 || statusMap.Status == -1 {
							DeviceNSF4000Map.Set(ctrl.Sn, 0)
							return statusMap.Status
						}
					}
				case <-stop.C:
					return -1
				}

			}
		} else if req.WorkMode == int32(config.DIRECTIONALDRIVE) { //定向驱离

			logger.Info("cc is ", ctrl.CC)

			startCmd := strings.Replace(config.ActiveDefense, "$Longititude", ctrl.CC.Longititude, -1)
			startCmd = strings.Replace(startCmd, "$Latitude", ctrl.CC.Latitude, -1)
			heightStr := ctrl.CC.Height
			heightInt, err := strconv.Atoi(heightStr)
			if err != nil {
				logger.Error("Atoi err :", err)
			}
			startCmd = strings.Replace(startCmd, "$Height", strconv.Itoa(heightInt+200), -1)

			if req.Power == 0 {
				startCmd = strings.ReplaceAll(startCmd, "$Power", "0")
				startCmd = strings.ReplaceAll(startCmd, "$Add10", "10")
			} else {
				startCmd = strings.ReplaceAll(startCmd, "$Power", strconv.Itoa(int(req.Power)))
				startCmd = strings.ReplaceAll(startCmd, "$Add10", strconv.Itoa(int(req.Power+10)))
			}

			logger.Info("Start  is Directional Drive startCmd is :", startCmd)

			ctrl.SendMsg([]byte(startCmd))

			sendMsg := ""
			if req.Angle == int32(config.NORTH) {
				sendMsg = "$SET,SimMov,0,0,-" + strconv.Itoa(int(req.DriveLevelSpeed)) + ",0\r\n" //向北驱离
				if req.Vertical == int32(config.UP) {
					sendMsg = "$SET,SimMov,0,0,-" + strconv.Itoa(int(req.DriveLevelSpeed)) + ",-" + strconv.Itoa(int(req.DriveVerticalSpeed)) + "\r\n" //向北上驱离
				}
				if req.Vertical == int32(config.DOWN) {
					sendMsg = "$SET,SimMov,0,0,-" + strconv.Itoa(int(req.DriveLevelSpeed)) + "," + strconv.Itoa(int(req.DriveVerticalSpeed)) + "\r\n" //向北下驱离
				}
			} else if req.Angle == int32(config.EAST) {
				sendMsg = "$SET,SimMov,0,-" + strconv.Itoa(int(req.DriveLevelSpeed)) + ",0,0\r\n" //向东驱离
				if req.Vertical == int32(config.UP) {
					sendMsg = "$SET,SimMov,0,-" + strconv.Itoa(int(req.DriveLevelSpeed)) + ",0,-" + strconv.Itoa(int(req.DriveVerticalSpeed)) + "\r\n" //向东上驱离
				}
				if req.Vertical == int32(config.DOWN) {
					sendMsg = "$SET,SimMov,0,-" + strconv.Itoa(int(req.DriveLevelSpeed)) + ",0," + strconv.Itoa(int(req.DriveVerticalSpeed)) + "\r\n" //向东下驱离
				}
			} else if req.Angle == int32(config.SOUTH) {
				sendMsg = "$SET,SimMov,0,0," + strconv.Itoa(int(req.DriveLevelSpeed)) + ",0\r\n" //向南驱离
				if req.Vertical == int32(config.UP) {
					sendMsg = "$SET,SimMov,0,0," + strconv.Itoa(int(req.DriveLevelSpeed)) + ",-" + strconv.Itoa(int(req.DriveVerticalSpeed)) + "\r\n" //向南上驱离
				}
				if req.Vertical == int32(config.DOWN) {
					sendMsg = "$SET,SimMov,0,0," + strconv.Itoa(int(req.DriveLevelSpeed)) + "," + strconv.Itoa(int(req.DriveVerticalSpeed)) + "\r\n" //向南下驱离
				}
			} else if req.Angle == int32(config.WEST) {
				sendMsg = "$SET,SimMov,0," + strconv.Itoa(int(req.DriveLevelSpeed)) + ",0,0\r\n" //向西驱离
				if req.Vertical == int32(config.UP) {
					sendMsg = "$SET,SimMov,0," + strconv.Itoa(int(req.DriveLevelSpeed)) + ",0,-" + strconv.Itoa(int(req.DriveVerticalSpeed)) + "\r\n" //向西上驱离
				}
				if req.Vertical == int32(config.DOWN) {
					sendMsg = "$SET,SimMov,0," + strconv.Itoa(int(req.DriveLevelSpeed)) + ",0," + strconv.Itoa(int(req.DriveVerticalSpeed)) + "\r\n" //向西下驱离
				}
			} else if req.Angle == int32(config.UP) {
				sendMsg = "$SET,SimMov,0,0,0,-" + strconv.Itoa(int(req.DriveVerticalSpeed)) + "\r\n" //向上驱离
			} else if req.Angle == int32(config.DOWN) {
				sendMsg = "$SET,SimMov,0,0,0," + strconv.Itoa(int(req.DriveVerticalSpeed)) + "\r\n" //向下驱离
			} else if req.Angle == 0 && req.Vertical == 0 {
				res = ctrl.SendMsg([]byte(config.NFSCLOSE))
				logger.Info("send close:", config.NFSCLOSE)
				if res != -1 {
					time.Sleep(time.Second * 1)
					ctrl.ReportStatus(1, 0, 0, 0, 2, config.NSF4000TypeWorking, "", "", "")
				}
				return res
			}

			logger.Info("send driver msg:", sendMsg)
			ctrl.SendMsg([]byte(sendMsg))
			time.Sleep(1 * time.Second)
		}
	} else {
		res = ctrl.SendMsg([]byte(config.NFSCLOSE))
		logger.Info("send close:", config.NFSCLOSE)

		if res != -1 {
			time.Sleep(time.Second * 1)
			ctrl.ReportStatus(1, 0, 0, 0, 2, config.NSF4000TypeWorking, "", "", "")
		}
	}
	return res
}
func (ctrl *ControllerNSF4000) SetClose() {
	ctrl.SendMsg([]byte(config.NFSCLOSE))
	ctrl.SendMsg([]byte(config.NFSCLOSE))
	ctrl.ReportStatus(1, 0, 0, 0, 2, config.NSF4000TypeWorking, "", "", "")
	ctrl.ReportStatus(2, 2, 2, 2, 2, config.NSF4000TypeOnline, "", "", "")
	go func() {
		time.Sleep(time.Millisecond * 10)
		ctrl.ReportStatus(2, 2, 2, 2, 2, config.NSF4000TypeOnline, "", "", "")
	}()
}

func FindCacheDeviceNSF(sn string, deviceType common.DeviceType) *ControllerNSF4000 {
	cacheKey := fmt.Sprintf("%d_%s", deviceType, sn)
	if dev, ok := DevStatusNfsMap.Load(cacheKey); ok {
		return dev.(*ControllerNSF4000)
	}
	return nil
}

// SendActiveDefenseCommand 发送主动防御命令
func (ctrl *ControllerNSF4000) SendActiveDefenseCommand(power int32, longititude, latitude float64, height int32) int {
	logger.Info("ActiveDefense  req is: ", power, longititude, latitude, height)
	longititudeStr := ""
	latitudeStr := ""

	if longititude == 0 {
		longititudeStr = ctrl.CC.Longititude
	} else {
		longititudeStr = strconv.FormatFloat(longititude, 'f', -1, 64)
	}

	if latitude == 0 {
		latitudeStr = ctrl.CC.Latitude
	} else {
		latitudeStr = strconv.FormatFloat(latitude, 'f', -1, 64)
	}
	startCmd := strings.Replace(config.ActiveDefense, "$Longititude", longititudeStr, -1)
	startCmd = strings.Replace(startCmd, "$Latitude", latitudeStr, -1)
	startCmd = strings.Replace(startCmd, "$Height", strconv.Itoa(int(height)), -1)
	if power == 0 {
		startCmd = strings.ReplaceAll(startCmd, "$Power", "0")
		startCmd = strings.ReplaceAll(startCmd, "$Add10", "10")
	} else {
		startCmd = strings.ReplaceAll(startCmd, "$Power", strconv.Itoa(int(power)))
		startCmd = strings.ReplaceAll(startCmd, "$Add10", strconv.Itoa(int(power+10)))
	}

	logger.Debug("ActiveDefense cmd is :", startCmd)
	res := ctrl.SendMsg([]byte(startCmd))
	return res
}

// CalculatePosAndVel 计算位置和速度
func (ctrl *ControllerNSF4000) CalculatePosAndVel(speed int32, radius int32, vspeed int32) (string, string, error) {
	longitude, err := strconv.ParseFloat(ctrl.CC.Longititude, 64)
	if err != nil {
		logger.Error("longitude Parse Float err:", err)
		return "", "", err
	}
	latitude, err := strconv.ParseFloat(ctrl.CC.Latitude, 64)
	if err != nil {
		logger.Error("latitude Parse Float err:", err)
		return "", "", err
	}
	height, err := strconv.ParseFloat(ctrl.CC.Height, 64)
	if err != nil {
		logger.Error("height Parse Float err:", err)
		return "", "", err
	}
	pos, vel := config.CalculatellhToposAndvel(speed, radius, vspeed, longitude, latitude, height)

	return pos, vel, nil
}

// ReportStatus 给前端上报消息
func (ctrl *ControllerNSF4000) ReportStatus(stat int, gpsstat int, timeSync int, starReport int, isWorking int, msgType int, longitude string, latitude string, height string) {
	if ctrl.Sn == "" {
		return
	}
	var m NSF4000Msg
	m.IsOnline = stat
	m.TimeSync = timeSync
	m.IsWorking = isWorking
	m.Ephemeris = starReport
	m.GpsStatus = gpsstat
	m.Enable = SyncNotifyData.Data.Enable
	m.WorkMode = SyncNotifyData.Data.WorkMode
	m.Radius = SyncNotifyData.Data.Radius
	m.Angle = SyncNotifyData.Data.Angle
	nowTime := time.Now().UnixMilli()
	if SyncNotifyData.Data.Angle != 0 {
		m.OpsTime = (nowTime - SyncNotifyData.Data.EnableStartTime) / 1000
	}

	if longitude != "" {
		longitude1, err := strconv.ParseFloat(longitude, 64)
		if err != nil {
			logger.Error("longitude Parse Float err:", err)
			return
		}
		m.Longititude = longitude1

		ctrl.CC.Longititude = longitude
	} else {
		m.Longititude = -1
	}

	if latitude != "" {
		latitude1, err := strconv.ParseFloat(latitude, 64)
		if err != nil {
			logger.Error("latitude Parse Float err:", err)
			return
		}
		m.Latitude = latitude1
		ctrl.CC.Latitude = latitude
	} else {
		m.Latitude = -1
	}
	if longitude == "0.00000000" && latitude == "0.00000000" {
		m.Longititude = -1
		m.Latitude = -1
	}
	if height != "" {
		height1, err := strconv.ParseFloat(height, 64)
		if err != nil {
			logger.Error("height Parse Float err:", err)
			return
		}
		m.Height = height1
		ctrl.CC.Height = height
	}

	msg := common.EquipmentMessageBoxEntity{
		Name:      ctrl.Sn,
		Sn:        ctrl.Sn,
		MsgType:   msgType,
		EquipType: int(common.DEV_NSF4000),
		Info:      m,
	}
	if m.IsOnline == 2 {
		logger.Infof("Send NSF 4000 msg Offline: %v", msg)
	} else {
		status := &client.GetStatusRes{}
		err := NewEquipList().GetStatus(context.Background(), &client.GetStatusReq{
			Sn:    ctrl.Sn,
			EType: "Spoofer",
		}, status)
		if err != nil {
			logger.Error("NSF 4000 GetStatus err:", err)
			return
		}
		if status.IsEnable == common.DeviceDisenable {
			return
		}
	}
	logger.Infof("Send NSF 4000 msg is: %v", msg)
	if msgType == config.NSF4000TypeLLH {
		_ = mq.NSF4000BrokerLLH.Publish(mq.NSF4000TopicLLH, broker.NewMessage(msg))
	} else {
		_ = mq.NSF4000Broker.Publish(mq.NSF4000Topic, broker.NewMessage(msg))
	}

}

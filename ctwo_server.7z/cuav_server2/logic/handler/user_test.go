package handler

import (
	"context"
	"testing"

	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
	"adasgitlab.autel.com/tools/cuav_server/test"
	"github.com/DATA-DOG/go-sqlmock"
	"github.com/agiledragon/gomonkey"
	"gorm.io/gorm"
)

func TestUser_Register_Case1(t *testing.T) {
	// Mock 日志
	test.LoggerMock()
	// Mock数据库
	DB, mock := test.GetMockDB(t)
	patch := gomonkey.ApplyFunc(db.GetDB, func() *gorm.DB {
		return DB
	})
	defer patch.Reset()

	mock.ExpectQuery("^SELECT \\* FROM `user_base` WHERE name = \\? ORDER BY `user_base`.`id` LIMIT 1").WillReturnError(gorm.ErrDuplicatedKey)

	type args struct {
		ctx context.Context
		req *client.RegisterReq
		res *client.RegisterRes
	}
	tests := []struct {
		name    string
		u       *User
		args    args
		wantErr bool
	}{
		{
			name: "case1",
			u:    &User{},
			args: args{
				ctx: context.Background(),
				req: &client.RegisterReq{
					Name:     "test1",
					NickName: "tes12233",
					Mobile:   "122334354364",
				},
				res: &client.RegisterRes{},
			},
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if err := tt.u.Register(tt.args.ctx, tt.args.req, tt.args.res); (err != nil) != tt.wantErr {
				t.Errorf("User.Register() error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

func TestUser_Register_Case2(t *testing.T) {
	// Mock 日志
	test.LoggerMock()
	// Mock数据库
	DB, mock := test.GetMockDB(t)
	patch := gomonkey.ApplyFunc(db.GetDB, func() *gorm.DB {
		return DB
	})
	defer patch.Reset()

	mock.ExpectQuery("^SELECT \\* FROM `user_base` WHERE name = \\? ORDER BY `user_base`.`id` LIMIT 1").WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectBegin()
	mock.ExpectExec("INSERT INTO `user_base` \\(`role`,`name`,`password`,`nick_name`,`gender`,`mobile`,`email`,`crt_time`,`update_time`,`updater`,`push_token`,`is_delete`,`last_sms_time`,`daily_send_times`\\) VALUES \\(\\?,\\?,\\?,\\?,\\?,\\?,\\?,\\?,\\?,\\?,\\?,\\?,\\?,\\?\\)").WithArgs(sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg()).WillReturnResult(sqlmock.NewResult(1, 1))
	mock.ExpectCommit()

	type args struct {
		ctx context.Context
		req *client.RegisterReq
		res *client.RegisterRes
	}
	tests := []struct {
		name    string
		u       *User
		args    args
		wantErr bool
	}{
		{
			name: "case1",
			u:    &User{},
			args: args{
				ctx: context.Background(),
				req: &client.RegisterReq{
					Name:     "test1",
					NickName: "tes12233",
					Mobile:   "122334354364",
				},
				res: &client.RegisterRes{},
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if err := tt.u.Register(tt.args.ctx, tt.args.req, tt.args.res); (err != nil) != tt.wantErr {
				t.Errorf("User.Register() error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

//func TestUser_Login(t *testing.T) {
//	// Mock数据库
//	var mock sqlmock.Sqlmock
//	Db, mock = test.GetMockDB(t)
//
//	rows := sqlmock.NewRows([]string{"id", "name", "nickname", "mobile", "password"}).AddRow(
//		1, "test1", "aaaa", "ffag@qq.com", "aaa",
//	)
//	mock.ExpectQuery("^SELECT \\* FROM `user_base` WHERE name = \\? ORDER BY `user_base`.`id` LIMIT 1").WillReturnRows(rows)
//
//	type args struct {
//		ctx context.Context
//		req *client.LoginReq
//		res *client.LoginRes
//	}
//	tests := []struct {
//		name    string
//		u       *User
//		args    args
//		wantErr bool
//	}{
//		{
//			name: "Case1",
//			u:    &User{},
//			args: args{
//				ctx: context.Background(),
//				req: &client.LoginReq{
//					Name:     "test1",
//					Password: "aaa",
//				},
//				res: &client.LoginRes{},
//			},
//			wantErr: false,
//		},
//	}
//	for _, tt := range tests {
//		t.Run(tt.name, func(t *testing.T) {
//			if err := tt.u.Login(tt.args.ctx, tt.args.req, tt.args.res); (err != nil) != tt.wantErr {
//				t.Errorf("User.Login() error = %v, wantErr %v", err, tt.wantErr)
//			}
//		})
//	}
//}

package handler

import (
	"context"
	"errors"
	"fmt"
	"strconv"
	"strings"
	"time"

	"adasgitlab.autel.com/tools/slink_proto/slinkv2/generatecode/golang/bizproto"

	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"

	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/cache"
)

type DeviceCenter struct{}

func NewDeviceCenter() *DeviceCenter {
	return &DeviceCenter{}
}

// GetSystemInfo 雷达 获取系统信息 0xD2
func (e *DeviceCenter) GetSystemInfo(ctx context.Context, req *client.GetSystemInfoRequest, rsp *client.GetSystemInfoResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_RADAR)
	if dev == nil {
		return errors.New("设备未在线")
	}
	radar := &Radar{Device: dev}
	workMode, value, err := radar.SendGetSystemInfo(req.Sn, uint8(req.DataType))
	if err != nil {
		return err
	}
	rsp.DataType = req.DataType
	rsp.Value = value
	rsp.WorkMode = int32(workMode)
	radar.LogOperator(req, rsp, err)
	return err
}

// SetSystemStatus 雷达 设置系统状态 0xD1
func (e *DeviceCenter) SetSystemStatus(ctx context.Context, req *client.SetSystemStatusRequest, rsp *client.SetSystemStatusResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_RADAR)
	if dev == nil {
		return errors.New("设备未在线")
	}
	radar := &Radar{Device: dev}
	// 接入radar v2协议
	// result, err := radar.SendSetSystemStatus(req.Sn, uint8(req.Status), uint8(req.WorkMode))
	// todo 前端workMode与设备type字段需重新映射
	result, err := radar.SetRadarSetting(req.Sn, &bizproto.RadarSetReq{
		Type: uint32(req.WorkMode),
		// Data: 0,
	})
	radar.LogOperator(req, result, err)
	if err != nil {
		return err
	}
	rsp.Status = int32(result.Status)
	return nil
}

// SetSn 雷达 设置序列号 0xD4
func (e *DeviceCenter) SetSn(ctx context.Context, req *client.SetSnRequest, rsp *client.SetSnResponse) error {
	dev := FindCacheDevice(req.CurSn, common.DEV_RADAR)
	if dev == nil {
		return errors.New("设备未在线")
	}
	radar := &Radar{Device: dev}
	result, err := radar.SendSetSn(req.CurSn)
	if err != nil {
		return err
	}
	rsp.Status = int32(result.Status)
	return nil
}

// GetCryptKey 雷达 获取通讯加密密钥 0xA0
func (e *DeviceCenter) GetCryptKey(ctx context.Context, req *client.GetCryptKeyRequest, rsp *client.GetCryptKeyResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_RADAR)
	if dev == nil {
		return errors.New("设备未在线")
	}
	radar := &Radar{Device: dev}
	result, err := radar.SendGetCryptKey(req.Sn)
	if err != nil {
		return err
	}
	rsp.Status = int32(result.Status)
	rsp.CryptType = int32(result.MsgType)
	rsp.Key = result.GetSecret()
	return nil
}

// DeleteDev 删除设备
func (e *DeviceCenter) DeleteDev(ctx context.Context, req *client.DelReq, rsp *client.DelRsp) error {
	rsp.Status = 0
	err := NewEquipList().Delete(context.Background(), &client.EquipDeleteReq{
		Ids: req.Ids,
	}, &client.EquipCrudRes{})
	if err != nil {
		rsp.Status = 1
		logger.Error("Delete EquipList err: ", err)
		return errors.New("删除数据库失败")
	}
	for _, sn := range req.Sn {
		dev, devType := FindCacheDeviceAndType(sn)
		if devType == common.DEV_RADAR {
			radar := &Radar{Device: dev}
			radar.SendSetWifiDisConnNotDetect(sn)
		}
	}
	return nil
}

// SetWifiDisConn 雷达 设置wifi断开连接 0xB1
func (e *DeviceCenter) SetWifiDisConn(ctx context.Context, req *client.SetWifiDisConnRequest, rsp *client.SetWifiDisConnResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_RADAR)
	if dev == nil {
		return errors.New("设备未在线")
	}
	radar := &Radar{Device: dev}
	result, err := radar.SendSetWifiDisConn(req.Sn)
	radar.LogOperator(req, result, err)
	if err != nil {
		return err
	}
	rsp.Status = int32(result.Status)
	return nil
}

// SetUploadMode 雷达 设置上报模式 0x11
func (e *DeviceCenter) SetUploadMode(ctx context.Context, req *client.SetUploadModeRequest, rsp *client.SetUploadModeResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_RADAR)
	if dev == nil {
		return errors.New("设备未在线")
	}
	radar := &Radar{Device: dev}
	result, err := radar.SendSetUploadMode(req.Sn, uint8(req.CheckType), uint8(req.Status), uint8(req.Route), uint8(req.Cycle))
	radar.LogOperator(req, result, err)
	if err != nil {
		return err
	}
	rsp.Status = int32(result.Status)
	return nil
}

// RadarGetBeamConfig 雷达 获取波控配置信息 0x15
func (e *DeviceCenter) RadarGetBeamConfig(ctx context.Context, req *client.RadarGetBeamConfigRequest, rsp *client.RadarGetBeamConfigResponse) error {
	//模拟数据返回
	if IsSimulateMode == 1 && req.Sn == "radar0000000000" {
		rsp.TrSwitchCtrl = 1
		rsp.WorkMode = 2
		rsp.WorkWaveCode = 3
		rsp.WorkFreqCode = 4
		rsp.PrfPeriod = 5
		rsp.AccuNum = 6
		rsp.CohesionVelThre = 7
		rsp.CohesionRgnThre = 8
		rsp.ClutterMapSwitch = 9
		rsp.ClutterMapUpdateCoef = 10
		rsp.AziCalcSlope = 11
		rsp.AziCalcPhase = 12
		rsp.EleCalcSlope = 13
		rsp.EleCalcPhase = 14
		rsp.AziScanCenter = 15
		rsp.AziScanScope = 120
		rsp.EleScanCenter = 0
		rsp.EleScanScope = EleScanScope
		rsp.CoherentDetectSwitch = 19
		rsp.NoiseCoef = 20
		rsp.ClutterCoef = 21
		rsp.CfarCoef = 22
		rsp.FocusRangeMin = 23
		rsp.FocusRangeMax = 34
		rsp.ClutterCurveNum = 25
		rsp.LobeCompCoef = 26
		rsp.Sn = req.Sn
		rsp.ScanRadius = 900
		return nil
	}

	dev := FindCacheDevice(req.Sn, common.DEV_RADAR)
	if dev == nil {
		return errors.New("设备未在线")
	}
	radar := &Radar{Device: dev}
	result, err := radar.SendBeamSteerConfig(req.Sn)
	radar.LogOperator(req, result, err)
	if err != nil {
		return err
	}
	rsp.TrSwitchCtrl = int32(result.TrSwitchCtrl)
	rsp.WorkMode = int32(result.WorkMode)
	rsp.WorkWaveCode = int32(result.WorkWaveCode)
	rsp.WorkFreqCode = int32(result.WorkFreqCode)
	rsp.PrfPeriod = int32(result.PrfPeriod)
	rsp.AccuNum = int32(result.AccuNum)
	rsp.CohesionVelThre = int32(result.CohesionVelThre)
	rsp.CohesionRgnThre = int32(result.CohesionRgnThre)
	rsp.ClutterMapSwitch = int32(result.ClutterMapSwitch)
	rsp.ClutterMapUpdateCoef = int32(result.ClutterMapUpdateCoef)
	rsp.AziCalcSlope = int32(result.AziCalcSlope)
	rsp.AziCalcPhase = int32(result.AziCalcPhase)
	rsp.EleCalcSlope = int32(result.EleCalcSlope)
	rsp.EleCalcPhase = int32(result.EleCalcPhase)
	rsp.AziScanCenter = int32(result.AziScanCenter)
	rsp.AziScanScope = int32(result.AziScanScope)
	rsp.EleScanCenter = int32(result.EleScanCenter)
	rsp.EleScanScope = int32(result.EleScanScope)
	rsp.CoherentDetectSwitch = int32(result.CoherentDetectSwitch)
	rsp.NoiseCoef = int32(result.NoiseCoef)
	rsp.ClutterCoef = int32(result.ClutterCoef)
	rsp.CfarCoef = int32(result.CfarCoef)
	rsp.FocusRangeMin = int32(result.FocusRangeMin)
	rsp.FocusRangeMax = int32(result.FocusRangeMax)
	rsp.ClutterCurveNum = int32(result.ClutterCurveNum)
	rsp.LobeCompCoef = int32(result.LobeCompCoef)
	rsp.WaveFrequencyChannel = int32(result.WaveFrequencyChannel)
	rsp.Sn = req.Sn
	rsp.ScanRadius = 900
	// 获取扫描半径
	//v, _, err := cache.GetPersist().Get(context.Background(), req.Sn+"-"+"scan_radius")
	//if err != nil {
	//	logger.Debug("get scan_radius failed: ", err)
	//	return nil
	//}
	//if v != nil {
	//	rsp.ScanRadius = int32(v.(float64))
	//}
	return nil
}

// 雷达 开始探测 0xC1
func (e *DeviceCenter) RadarStartDetect(ctx context.Context, req *client.RadarStartDetectRequest, rsp *client.RadarStartDetectResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_RADAR)
	if dev == nil {
		return errors.New("设备未在线")
	}
	radar := &Radar{Device: dev}
	// 接入radar v2 协议
	// result, err := radar.SendStartDetect(req.Sn)
	result, err := radar.SetRadarSetting(req.Sn, &bizproto.RadarSetReq{
		Type: uint32(common.RadarSetType_START_DETECT),
		//Data: 0,
	})
	radar.LogOperator(req, result, err)
	if err != nil {
		return err
	}
	rsp.Status = int32(result.Status)
	return nil
}

// 雷达 结束探测 0xC2
func (e *DeviceCenter) RadarEndDetect(ctx context.Context, req *client.RadarEndDetectRequest, rsp *client.RadarEndDetectResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_RADAR)
	if dev == nil {
		return errors.New("设备未在线")
	}
	radar := &Radar{Device: dev}
	// result, err := radar.SendEndDetect(req.Sn, true)
	result, err := radar.SetRadarSetting(req.Sn, &bizproto.RadarSetReq{
		Type: uint32(common.RadarSetType_STOP_DETECT),
		//Data: 0,
	})
	radar.LogOperator(req, result, err)
	if err != nil {
		return err
	}
	rsp.Status = int32(result.Status)
	return nil
}

// 雷达 波控范围设置 0xC4
func (e *DeviceCenter) RadarSetBeamSchedule(ctx context.Context, req *client.RadarSetBeamScheduleRequest, rsp *client.RadarSetBeamScheduleResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_RADAR)
	if dev == nil {
		return errors.New("设备未在线")
	}
	radar := &Radar{Device: dev}
	// result, err := radar.SendSetBeamSize(req.Sn, req.EleScanCenter, req.EleScanScope, req.AziScanCenter, req.AziScanScope, req.WaveFrequencyChannel)
	result, err := radar.SetBeamScheduling(req.Sn, &bizproto.RadarSetBeamSchedulingReq{
		EleScanCenter: float32(req.EleScanCenter),
		EleScanScope:  float32(req.EleScanScope),
		AziScanCenter: float32(req.AziScanCenter),
		AziScanScope:  float32(req.AziScanScope),
		// todo 设备缺省字段，代补充
		//WaveFrequencyChannel: uint32(req.WaveFrequencyChannel),
	})
	radar.LogOperator(req, result, err)
	if err != nil {
		return err
	}
	rsp.Status = int32(result.Status)
	if result.Status == 1 {
		return nil
	}
	// 设置扫描半径
	err = cache.GetPersist().Put(context.Background(), req.Sn+"-"+"scan_radius", float64(req.ScanRadius), 0)
	if err != nil {
		logger.Debug("set scan_radius failed: ", err)
		return errors.New("set scan_radius failed")
	}
	return nil
}

func (e *DeviceCenter) GetEquipList(ctx context.Context, req *client.GetEquipListRequest, rsp *client.GetEquipListResponse) error {
	logger.Info("receive GetEquipList")
	equips := make([]*client.EquipInfo, 0)
	DevStatusMap.Range(func(key, value any) bool {
		dev := value.(*Device)
		if dev.DevType == common.DEV_RADAR {
			//启用时逻辑不经过这，缓存还没做
			enable := dev.IsEnable
			curStatus := &client.GetStatusRes{}
			err := NewEquipList().GetStatus(ctx, &client.GetStatusReq{Sn: dev.Sn}, curStatus)
			if err == nil {
				dev.IsEnable = curStatus.IsEnable
				enable = curStatus.IsEnable
			}
			equips = append(equips, &client.EquipInfo{
				Id:         0,
				Reverse:    "",
				TerminalId: "",
				Etype:      "radar",
				TcpPort:    1001,
				UdpPort:    0,
				Ip:         dev.RemoteIp,
				CrtTime:    dev.LastHeartTime.Format("2006-01-02 15:04:05"),
				//Status:     1,
				UpdateTime: dev.LastHeartTime.Format("2006-01-02 15:04:05"),
				Vendor:     "",
				Frequency:  "",
				Model:      "",
				Protocol:   "",
				Name:       dev.Name,
				Content:    "",
				IsEnable:   enable,
				IsOnline:   int32(dev.Status),
				Sn:         dev.Sn,
			})
		} else if dev.DevType == common.DEV_AEAG {
			equips = append(equips, &client.EquipInfo{
				Id:         0,
				Reverse:    "",
				TerminalId: "",
				Etype:      "RF",
				TcpPort:    1001,
				UdpPort:    0,
				Ip:         dev.RemoteIp,
				CrtTime:    dev.LastHeartTime.Format("2006-01-02 15:04:05"),
				//Status:     1,
				UpdateTime: dev.LastHeartTime.Format("2006-01-02 15:04:05"),
				Vendor:     "",
				Frequency:  "",
				Model:      "",
				Protocol:   "",
				Name:       dev.Name,
				Content:    "",
				IsEnable:   common.DeviceEnable, //枪没有禁用、启用
				IsOnline:   int32(dev.Status),
				Sn:         dev.Sn,
			})
		} else if dev.DevType == common.DEV_SCREEN {
			equips = append(equips, &client.EquipInfo{
				Id:         0,
				Reverse:    "",
				TerminalId: "",
				Etype:      "RF",
				TcpPort:    1001,
				UdpPort:    0,
				Ip:         dev.RemoteIp,
				CrtTime:    dev.LastHeartTime.Format("2006-01-02 15:04:05"),
				//Status:     1,
				UpdateTime: dev.LastHeartTime.Format("2006-01-02 15:04:05"),
				Vendor:     "",
				Frequency:  "",
				Model:      "",
				Protocol:   "",
				Name:       dev.Sn,
				Content:    "",
				IsEnable:   common.DeviceEnable, //屏没有禁用、启用
				IsOnline:   int32(dev.Status),
				Sn:         dev.Sn,
			})
		}
		return true
	})
	rsp.Equips = equips
	return nil
}

// 反制枪 获取版本信息 0xAB
func (e *DeviceCenter) GunGetSoftVer(ctx context.Context, req *client.GunGetSoftVersionRequest, rsp *client.GunGetSoftVersionResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SCREEN)
	if dev == nil {
		return errors.New("设备未在线")
	}
	gun := &CounterGun{Device: dev}
	runVer, ver, bootVer, hwVer, protocolVer, err := gun.SendGetAEAGSoftVer(req.Sn)
	logger.Infof("gunLoopCheckIsInBootUpdateMod Ver: %v, %v, %v, %v, %v \n",
		runVer, ver, bootVer, hwVer, protocolVer)
	logger.Infof("GunGetSoftVer Ver: %v, %v, %v, %v, %v \n",
		runVer, ver, bootVer, hwVer, protocolVer)
	gun.LogOperator(req, rsp, err)
	if err != nil {
		return err
	}
	dbequip := &client.EquipListRes{}
	err = NewEquipList().List(context.Background(), &client.EquipListReq{}, dbequip)
	if err != nil {
		logger.Error("Get EquipList err: ", err)
	}
	for _, equip := range dbequip.Equips {
		if equip.Sn == req.Sn {
			rsp.Ip = equip.Ip
		}
	}
	rsp.Version = ver
	if rsp.Version != "" {
		err = NewEquipList().Update(context.Background(), &client.EquipCrudReq{
			Sn:         req.Sn,
			DevVersion: rsp.Version,
		}, &client.EquipCrudRes{})
		if err != nil {
			logger.Error("Update EquipList err: ", err)
		}
	}
	return nil
}

// 反制枪 设置白名单 0x22
func (e *DeviceCenter) GunSetWhiteList(ctx context.Context, req *client.GunSetWhiteListRequest, rsp *client.GunSetWhiteListResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SCREEN)
	if dev == nil {
		return errors.New("设备未在线")
	}
	gun := &CounterGun{Device: dev}
	statusRes, err := gun.SendSetWhiteList(req.Sn, req.UavName)
	gun.LogOperator(req, rsp, err)
	if err != nil {
		return err
	}
	rsp.Status = int32(statusRes.Status)
	return nil
}

// 反制枪 获取所有白名单 0x24
func (e *DeviceCenter) GunGetWhiteList(ctx context.Context, req *client.GunGetWhiteListRequest, rsp *client.GunGetWhiteListResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SCREEN)
	if dev == nil {
		return errors.New("设备未在线")
	}
	gun := &CounterGun{Device: dev}
	uavs, err := gun.SendGetWhiteList(req.Sn)
	gun.LogOperator(req, rsp, err)
	if err != nil {
		return err
	}
	rsp.Uavs = uavs
	return nil
}

// 反制枪 枪打击 0x23
func (e *DeviceCenter) GunHit(ctx context.Context, req *client.GunHitRequest, rsp *client.GunHitResponse) error {
	//改为屏打击，屏演示版本还没有sn
	dev := FindCacheDevice(req.Sn, common.DEV_SCREEN)
	if dev == nil {
		return errors.New("设备未在线")
	}
	hitDevice := &Screen{Device: dev}
	res, err := hitDevice.SendHit(req.Sn, uint8(req.Mode), uint8(req.HitFreq), uint16(req.DroneLongitude), uint16(req.DroneLatitude), uint16(req.DroneAltitude), 10)
	if err != nil {
		return err
	}
	rsp.Status = int32(res.Status)
	return nil
}

func (e *DeviceCenter) SendGunHitData(ctx context.Context, req *client.SendGunHitDataRequest, rsp *client.SendGunHitDataResponse) error {
	//改为屏打击，屏演示版本还没有sn
	dev := FindCacheDevice(req.Sn, common.DEV_SCREEN)
	if dev == nil {
		return errors.New("设备未在线")
	}
	hitDevice := &Screen{Device: dev}
	res, err := hitDevice.SendUavData(req)
	if err != nil {
		return err
	}
	rsp.Status = int32(res.Status)
	return nil
}

func (e *DeviceCenter) SendGunHitResult(ctx context.Context, req *client.SendGunHitResultRequest, rsp *client.SendGunHitResultResponse) error {
	//改为屏打击，屏演示版本还没有sn
	dev := FindCacheDevice(req.Sn, common.DEV_SCREEN)
	if dev == nil {
		return errors.New("设备未在线")
	}
	//hitDevice := &Screen{Device: dev}
	//res, err := hitDevice.SendUavData(req.Sn, uint8(0), uint8(0), uint16(0), uint16(0), uint16(0), 10)
	//if err != nil {
	//	return err
	//}
	//rsp.Status = int32(res.Status)
	return nil
}

func (e *DeviceCenter) AddSimulateDevice(ctx context.Context, req *client.AddSimulateDeviceRequest, rsp *client.AddSimulateDeviceResponse) error {
	AddSimulateDevice(req.Status, req.MsgType)
	rsp.Status = 1
	return nil
}

func (e *DeviceCenter) PostureCalibration(ctx context.Context, req *client.PostureCalibrationRequest, rsp *client.PostureCalibrationResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_RADAR)
	if dev == nil {
		return errors.New("设备未在线")
	}
	radar := &Radar{Device: dev}
	result, err := radar.PostureCalibration()
	if err != nil {
		return err
	}
	rsp.Status = int32(result.Status)
	return nil
}

func (e *DeviceCenter) PostureCalibrationManual(ctx context.Context, req *client.PostureCalibrationManualRequest, rsp *client.PostureCalibrationManualResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_RADAR)
	if dev == nil {
		return errors.New("设备未在线")
	}
	radar := &Radar{Device: dev}

	// 接入radar v2协议
	//result, err := radar.PostureCalibrationManual(&mavlink.PostureCalibrationManualRequest{
	//	ULongitude: int32(req.ULongitude * RadarPostureReduce20),
	//	ULatitude:  int32(req.ULatitude * RadarPostureReduce20),
	//	UAltitude:  int32(req.UAltitude * RadarPostureReduce),
	//	UHeading:   int32(req.UHeading * RadarPostureReduce),
	//	UPitching:  int32(req.UPitching * RadarPostureReduce),
	//	URolling:   int32(req.URolling * RadarPostureReduce),
	//})

	result, err := radar.SetRadarAttitudeLLA(req.Sn, &bizproto.RadarSetAttitudeLLAReq{
		RadarLLA: &bizproto.RadarLLA{
			Longitude: float32(req.ULongitude),
			Latitude:  float32(req.ULatitude),
			Altitude:  float32(req.UAltitude),
		},
		Attitude: &bizproto.RadarAttitude{
			Heading:  float32(req.UHeading),
			Pitching: float32(req.UPitching),
			Rolling:  float32(req.URolling),
		},
		TimestampUs: uint64(time.Now().UnixMicro()),
	})
	if err != nil {
		return err
	}
	rsp.Status = int32(result.Status)
	return nil
}

func (e *DeviceCenter) RadarGetVersionInfo(ctx context.Context, req *client.RadarGetVersionInfoRequest, rsp *client.RadarGetVersionInfoResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_RADAR)
	if dev == nil {
		return errors.New("设备未在线")
	}
	radar := &Radar{Device: dev}
	runVer, appVer, bootVer, hwVer, protoVer, err := radar.SendGetVersionInfo()
	if err != nil {
		return err
	}
	rsp.Sn = req.Sn
	rsp.RunVersion = int64(runVer)
	rsp.AppVersion = appVer
	rsp.BootVersion = bootVer
	rsp.HwVersion = hwVer
	rsp.ProtocolVersion = protoVer
	if appVer != "" {
		err = NewEquipList().Update(context.Background(), &client.EquipCrudReq{
			Sn:         req.Sn,
			DevVersion: appVer,
		}, &client.EquipCrudRes{})
		if err != nil {
			logger.Error("Update EquipList err: ", err)
		}
	}
	return nil
}

func (e *DeviceCenter) DroneIDGetVersionInfo(ctx context.Context, req *client.DroneIDGetVersionInfoRequest, rsp *client.DroneIDGetVersionInfoResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_V2DRONEID)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &DroneID{Device: dev}
	rsp, err := d.SendGetVersionInfo()
	if err != nil {
		return err
	}
	if rsp.PsVersion != "" {
		err = NewEquipList().Update(context.Background(), &client.EquipCrudReq{
			Sn:         req.Sn,
			DevVersion: rsp.PsVersion,
		}, &client.EquipCrudRes{})
		if err != nil {
			logger.Error("Update EquipList err: ", err)
		}
	}
	return nil
}

// TracerGetVersionInfo 获取Tracer版本信息
func (e *DeviceCenter) TracerGetVersionInfo(ctx context.Context, req *client.TracerGetVersionInfoRequest, rsp *client.TracerGetVersionInfoResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_V2DRONEID)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &DroneID{Device: dev}
	runVer, appVer, bootVer, hwVer, protoVer, err := d.TracerGetVersionInfo()
	if err != nil {
		return err
	}
	rsp.Sn = req.Sn
	rsp.RunVersion = int64(runVer)
	rsp.AppVersion = appVer
	rsp.BootVersion = bootVer
	rsp.HwVersion = hwVer
	rsp.ProtocolVersion = protoVer
	if appVer != "" {
		err = NewEquipList().Update(context.Background(), &client.EquipCrudReq{
			Sn:         req.Sn,
			DevVersion: appVer,
		}, &client.EquipCrudRes{})
		if err != nil {
			logger.Error("Update EquipList err: ", err)
		}
	}
	return nil
}

// TracerGetInfo 获取Tracer设备信息
func (e *DeviceCenter) TracerGetInfo(ctx context.Context, req *client.TracerGetInfoRequest, rsp *client.TracerGetInfoResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_V2DRONEID)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &DroneID{Device: dev}
	_, appVer, _, _, _, err := d.TracerGetVersionInfo()
	if err != nil {
		return err
	}
	rsp.Ip = dev.RemoteIp
	rsp.AppVersion = appVer
	if appVer != "" {
		err = NewEquipList().Update(context.Background(), &client.EquipCrudReq{
			Sn:         req.Sn,
			DevVersion: appVer,
		}, &client.EquipCrudRes{})
		if err != nil {
			logger.Error("Update EquipList err: ", err)
		}
	}
	return nil
}

// TracerGetWorkMode 获取tracer工作模式
func (e *DeviceCenter) TracerGetWorkMode(ctx context.Context, req *client.TracerGetWorkModeRequest, rsp *client.TracerGetWorkModeResponse) error {
	logger.Info("---->Into Get Trace Work Mode,sn:", req.Sn)

	dev := FindCacheDevice(req.Sn, common.DEV_V2DRONEID)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &DroneID{Device: dev}
	result, err := d.SendGetWorkMode()
	if err != nil {
		logger.Info("---->End Get Trace Work Mode")
		return err
	}
	rsp.Status = result
	logger.Info("---->End Get Trace Work Mode")
	return nil
}

// TracerSetOrientationMode 设置tracer定向模式
func (e *DeviceCenter) TracerSetOrientationMode(ctx context.Context, req *client.TracerSetOrientationModeRequest, rsp *client.TracerSetOrientationModeResponse) error {
	logger.Infof("---->Into Set Orientation Mode,req: %v", req)
	dev := FindCacheDevice(req.Sn, common.DEV_V2DRONEID)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &DroneID{Device: dev}
	result, err := d.SendSetOrientationMode(uint8(req.Status), uint8(req.UavNumber), req.DroneName, uint32(req.UFreq))
	if err != nil {
		logger.Info("---->End Set Orientation Mode")
		return err
	}
	rsp.Status = result
	logger.Info("---->End Set Orientation Mode")
	return nil
}

func (e *DeviceCenter) GunSetStatus(ctx context.Context, req *client.GunSetStatusRequest, rsp *client.GunSetStatusResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SCREEN)
	if dev == nil {
		return errors.New("设备未在线")
	}
	gun := &Screen{Device: dev}
	statusRes, err := gun.SendCloseConn(req.Sn)
	if err != nil {
		return err
	}
	rsp.Status = int32(statusRes.Status)
	return nil
}

func (e *DeviceCenter) SetDeviceStatus(ctx context.Context, req *client.SetDeviceStatusRequest, rsp *client.SetDeviceStatusResponse) error {
	dev := FindCacheDevice(req.Sn, common.DeviceType(req.DeviceType))
	if dev == nil {
		logger.Info("device has offline")
		return nil
	}

	if req.Status == common.DeviceDisenable {
		dev.Close()
		dev.IsEnable = common.DeviceDisenable
	} else if req.Status == common.DeviceEnable {
		dev.IsEnable = common.DeviceEnable
	} else {
		return fmt.Errorf("set status %v err", req.Status)
	}

	rsp.Status = 1
	return nil
}

func (e *DeviceCenter) StartUdpBroadCast(ctx context.Context, req *client.StartUdpBroadCastRequest, rsp *client.StartUdpBroadCastResponse) error {
	if err := StartUdpBroadCast(req.Id); err != nil {
		return err
	}
	rsp.Status = 1
	return nil
}

func (e *DeviceCenter) StopUdpBroadCast(ctx context.Context, req *client.StopUdpBroadCastRequest, rsp *client.StopUdpBroadCastResponse) error {
	if err := StopUdpBroadCast(req.Id); err != nil {
		return err
	}
	rsp.Status = 1
	return nil
}

func (e *DeviceCenter) ConfirmDeviceConn(ctx context.Context, req *client.ConfirmDeviceConnRequest, rsp *client.ConfirmDeviceConnResponse) error {
	if err := ConfirmDeviceConn(req.SnList); err != nil {
		return err
	}
	rsp.Status = 1
	return nil
}

// StartInduce 导航诱骗  开始工作模式
func (e *DeviceCenter) StartInduce(ctx context.Context, req *client.InduceRequest, rsp *client.InduceResponse) error {
	rsp.Status = 1
	logger.Info("------->Into Start Induce:", req)
	if req.Sn == "" {
		rsp.Status = 2
		return errors.New("sn is nil")
	}
	dev := FindCacheDeviceNSF(req.Sn, common.DEV_NSF4000)
	if dev == nil {
		rsp.Status = 2
		return errors.New("设备未在线")
	}
	res := dev.SetPlay(req)
	if res == -1 {
		rsp.Status = 2
	}
	enableStartTime := time.Now().UnixMilli()
	logger.Debug("enableStartTime = ", enableStartTime)
	logger.Debug("req.Enable = ", req.Enable)

	if rsp.Status == 1 {
		SyncNotifyData.Lock()
		SyncNotifyData.Data.Sn = req.Sn
		if req.WorkMode != 0 {
			SyncNotifyData.Data.Enable = req.Enable
			SyncNotifyData.Data.WorkMode = req.WorkMode
			SyncNotifyData.Data.Radius = req.Radius
		} else {
			SyncNotifyData.Data.Radius = req.Radius
		}

		SyncNotifyData.Data.Angle = req.Angle
		SyncNotifyData.Data.EnableStartTime = enableStartTime
		SyncNotifyData.Unlock()
	}
	logger.Debug("SyncNotifyData.Data = ", SyncNotifyData.Data)
	logger.Info("------->End Start Induce rsp:", rsp.Status)
	return nil
}

// GetInduceVer 导航诱骗  获取版本号
func (e *DeviceCenter) GetInduceVer(ctx context.Context, req *client.GetInduceVerRequest, rsp *client.GetInduceVerResponse) error {
	rsp.Status = 1
	logger.Info("------->Into Get Induce Ver:", req.Sn)
	dev := FindCacheDeviceNSF(req.Sn, common.DEV_NSF4000)
	if dev == nil {
		rsp.Status = 2
		return errors.New("设备未在线")
	}
	rsp.Status = 1
	rsp.Sn = dev.Sn
	rsp.Ip = dev.NFSIP
	rsp.Version = dev.Version
	logger.Info("------->End Get Induce Ver:", rsp.Ip, rsp.Version)
	return nil
}

// EnableInduce 导航诱骗  启用禁用
func (e *DeviceCenter) EnableInduce(ctx context.Context, req *client.EnableInduceRequest, rsp *client.EnableInduceResponse) error {
	logger.Info("Enable Induce is :", req.Enable)
	rsp.Status = 1

	dev := FindCacheDeviceNSF(req.Sn, common.DEV_NSF4000)
	//禁用时关闭工作模式
	if req.Enable == 2 && dev != nil { //禁用时发关闭工作，并上报前端
		dev.SetClose()
	}
	err := NewEquipList().SetEnableState(context.Background(), &client.SetEnableReq{Sn: req.Sn, Status: req.Enable, EType: "Spoofer"}, &client.SetEnableRes{})
	if err != nil {
		logger.Error("Enable Induce err:", err)
		rsp.Status = 2
		return err
	}

	rsp.Status = 1
	return nil
}

// GetInduceConfig 获取导航诱导参数
func (e *DeviceCenter) GetInduceConfig(ctx context.Context, req *client.GetInduceConfigRequest, rsp *client.GetInduceConfigResponse) error {
	logger.Info("Get Induce Config Sn is :", req.Sn)

	dev := FindCacheDeviceNSF(req.Sn, common.DEV_NSF4000)
	if dev == nil {
		return errors.New("设备未在线")
	}
	listInfo := &client.Nsf4000ListRsp{}
	err := NewNsf4000().List(context.Background(), &client.Nsf4000ListReq{}, listInfo)
	if err != nil {
		logger.Error("Get Induce config err:", err)
		return err
	}
	rsp.Radius = 200
	rsp.Power = 0
	rsp.DefenseLevelSpeed = 20
	rsp.DefenseVerticalSpeed = 0
	rsp.Longitude = 113.81022061
	rsp.Latitude = 22.63407730
	rsp.Height = 50
	rsp.DriveLevelSpeed = 5
	rsp.DriveVerticalSpeed = 5
	for _, info := range listInfo.ConfigList {
		if info.Sn == req.Sn {
			rsp.Radius = info.Radius
			rsp.Power = info.Power
			rsp.DefenseLevelSpeed = info.DefenseLevelSpeed
			rsp.DefenseVerticalSpeed = info.DefenseVerticalSpeed
			rsp.Longitude = info.Longitude
			rsp.Latitude = info.Latitude
			rsp.Height = info.Height
			rsp.DriveLevelSpeed = info.DriveLevelSpeed
			rsp.DriveVerticalSpeed = info.DriveVerticalSpeed
			rsp.DefenseLongitude = info.DefenseLongitude
			rsp.DefenseLatitude = info.DefenseLatitude
			rsp.AreaStopLongitude = info.AreaStopLongitude
			rsp.AreaStopLatitude = info.AreaStopLatitude
		}
	}
	logger.Info("Get Induce Config is :", rsp)
	return nil
}

// DeleteInduceConfig 删除诱导设备的本地配置
func (e *DeviceCenter) DeleteInduceConfig(_ context.Context, sn string) error {
	if len(sn) <= 0 {
		return errors.New("sn is empty")
	}
	err := NewNsf4000().Delete(context.Background(), sn)
	if err != nil {
		logger.Error("Get Induce config err:", err)
		return err
	}
	return nil
}

// SetInduceConfig 设置导航诱导参数
func (e *DeviceCenter) SetInduceConfig(ctx context.Context, req *client.SetInduceConfigRequest, rsp *client.SetInduceConfigResponse) error {
	logger.Infof("Set Induce Config Sn is:%v", req)
	rsp.Status = 1
	dev := FindCacheDeviceNSF(req.Sn, common.DEV_NSF4000)
	if dev == nil {
		rsp.Status = 2
		return errors.New("设备未在线")
	}
	err := NewNsf4000().InsertAndUpdate(context.Background(), &client.Nsf4000InsertAndUpdateReq{
		Sn:                   req.Sn,
		Radius:               req.Radius,
		Power:                req.Power,
		DefenseLevelSpeed:    req.DefenseLevelSpeed,
		DefenseVerticalSpeed: req.DefenseVerticalSpeed,
		Longitude:            req.Longitude,
		Latitude:             req.Latitude,
		Height:               req.Height,
		DriveLevelSpeed:      req.DriveLevelSpeed,
		DriveVerticalSpeed:   req.DriveVerticalSpeed,
		DefenseLongitude:     req.DefenseLongitude,
		DefenseLatitude:      req.DefenseLatitude,
		AreaStopLongitude:    req.AreaStopLongitude,
		AreaStopLatitude:     req.AreaStopLatitude,
	}, &client.Nsf4000InsertAndUpdateRsp{})
	if err != nil {
		rsp.Status = 2
		logger.Error("Insert Induce config err:", err)
		return nil
	}

	logger.Info("Set Induce Config is :", rsp)
	return nil
}

// TracerCli 给tracer下发指令
func (e *DeviceCenter) TracerCli(ctx context.Context, req *client.TracerCliRequest, rsp *client.TracerCliResponse) error {
	logger.Info("---->Into Set Tracer Cli ,sn:", req.Sn, req.Cmd)
	dev := FindCacheDevice(req.Sn, common.DEV_V2DRONEID)
	if dev == nil {
		return errors.New("设备未在线")
	}
	if dev.WaitTaskMap == nil {
		return errors.New("send err")
	}
	d := &DroneID{Device: dev}
	result, err := d.SendTracerCli(req.Cmd)
	if err != nil {
		logger.Info("---->Send Tracer Cli err:", err)
		return err
	}
	logger.Info("---->result:", string(result))
	rsp.Result = string(result)
	logger.Info("---->End Tracer Cli")

	return nil
}

// TracerSetHideMode 给tracer下发设置隐蔽模式
func (e *DeviceCenter) TracerSetHideMode(ctx context.Context, req *client.TracerSetHideModeRequest, rsp *client.TracerSetHideModeResponse) error {
	logger.Info("---->Into Set Tracer Set Hide Mode ,sn:", req.Sn, req.HideMode)
	dev := FindCacheDevice(req.Sn, common.DEV_V2DRONEID)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &DroneID{Device: dev}
	status, err := d.SendTracerSetHideMode(int(req.HideMode))
	if err != nil {
		logger.Info("---->Send Tracer Set HideMode err:", err)
		return err
	}
	rsp.Status = int32(status)
	if status == 0 {
		rsp.Status = 2
	}
	logger.Info("---->End Tracer Set HideMode,rsp:", rsp)

	return nil
}

// TracerSetAlarm 给tracer下发设置告警设置
func (e *DeviceCenter) TracerSetAlarm(ctx context.Context, req *client.TracerSetAlarmRequest, rsp *client.TracerSetAlarmResponse) error {
	logger.Info("---->Into Set Tracer Set Alarm ,sn:", req.Sn, req.Alarm)
	dev := FindCacheDevice(req.Sn, common.DEV_V2DRONEID)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &DroneID{Device: dev}
	status, err := d.SendTracerSetAlarm(int(req.Alarm))
	if err != nil {
		logger.Info("---->Send Tracer Set Alarm err:", err)
		return err
	}
	rsp.Status = int32(status)
	if status == 0 {
		rsp.Status = 2
	}
	logger.Info("---->End Tracer Set Alarm,rsp:", rsp)
	return nil
}

// FpvSendSetHitMode Fpv发送设置打击模式
func (e *DeviceCenter) FpvSendSetHitMode(ctx context.Context, req *client.FpvSendSetHitModeRequest, rsp *client.FpvSendSetHitModeResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_FPV)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Fpv{Device: dev}
	status, err := d.FpvSendSetHitMode(req)
	if err != nil {
		return err
	}
	rsp.Status = status
	if status == 0 {
		rsp.Status = 2
	}
	return nil
}

// FpvSendGetVersion Fpv发送获取版本信息
func (e *DeviceCenter) FpvSendGetVersion(ctx context.Context, req *client.FpvSendGetVersionRequest, rsp *client.FpvSendGetVersionResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_FPV)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Fpv{Device: dev}
	rsp, err := d.FpvSendGetVersion()
	if err != nil {
		return err
	}
	if rsp.PsVersion != "" {
		err = NewEquipList().Update(context.Background(), &client.EquipCrudReq{
			Sn:         req.Sn,
			DevVersion: rsp.PsVersion,
		}, &client.EquipCrudRes{})
		if err != nil {
			logger.Error("Update EquipList err: ", err)
		}
	}
	return nil
}

// FpvSendGetHitMode Fpv发送获取打击模式
func (e *DeviceCenter) FpvSendGetHitMode(ctx context.Context, req *client.FpvSendGetHitModeRequest, rsp *client.FpvSendGetHitModeResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_FPV)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Fpv{Device: dev}
	status, err := d.FpvSendGetHitMode()
	if err != nil {
		return err
	}
	rsp.Status = status
	if status == 0 {
		rsp.Status = 2
	}
	return nil
}

// FpvSendHitUav Fpv发送全面打击
func (e *DeviceCenter) FpvSendHitUav(ctx context.Context, req *client.FpvSendHitRequest, rsp *client.FpvSendHitResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_FPV)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Fpv{Device: dev}
	status, err := d.FpvSendHit()
	if err != nil {
		return err
	}
	rsp.Status = status
	if status == 0 {
		rsp.Status = 2
	}
	return nil
}

// FpvSendStopHit Fpv发送停止打击
func (e *DeviceCenter) FpvSendStopHit(ctx context.Context, req *client.FpvSendStopHitRequest, rsp *client.FpvSendStopHitResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_FPV)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Fpv{Device: dev}
	status, err := d.FpvSendStopHit()
	if err != nil {
		return err
	}
	rsp.Status = status
	if status == 0 {
		rsp.Status = 2
	}
	return nil
}

// FpvSendSetHitTime Fpv发送设置打击时间
func (e *DeviceCenter) FpvSendSetHitTime(ctx context.Context, req *client.FpvSendSetHitTimeRequest, rsp *client.FpvSendSetHitTimeResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_FPV)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Fpv{Device: dev}
	status, err := d.FpvSendSetHitTime(req)
	if err != nil {
		return err
	}
	rsp.Status = status
	if status == 0 {
		rsp.Status = 2
	}
	return nil
}

// FpvSendGetHitTime Fpv发送获取打击时间
func (e *DeviceCenter) FpvSendGetHitTime(ctx context.Context, req *client.FpvSendGetHitTimeRequest, rsp *client.FpvSendGetHitTimeResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_FPV)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Fpv{Device: dev}
	time, err := d.FpvSendGetHitTime()
	if err != nil {
		return err
	}
	rsp.HitTime = time
	return nil
}

// FpvCli 给Fpv下发指令
func (e *DeviceCenter) FpvCli(ctx context.Context, req *client.FpvCliRequest, rsp *client.FpvCliResponse) error {
	logger.Info("---->Into Set Fpv Cli ,sn:", req.Sn, req.Cmd)
	dev := FindCacheDevice(req.Sn, common.DEV_FPV)
	if dev == nil {
		return errors.New("设备未在线")
	}
	d := &Fpv{Device: dev}
	result, err := d.SendFpvCli(req.Cmd)
	if err != nil {
		logger.Info("---->Send Fpv Cli err:", err)
		return err
	}
	logger.Info("---->result:", string(result))
	rsp.Result = string(result)
	logger.Info("---->End Fpv Cli")

	return nil
}

// SflGetVersionInfo Sfl获取版本信息
func (e *DeviceCenter) SflGetVersionInfo(ctx context.Context, req *client.SflGetVersionRequest, rsp *client.SflGetVersionResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Sfl{Device: dev}
	version, err := d.SendGetVersionInfo()
	if err != nil {
		return err
	}
	rsp.Sn = req.Sn
	rsp.Version = version
	if rsp.Version != "" {
		err = NewEquipList().Update(context.Background(), &client.EquipCrudReq{
			Sn:         req.Sn,
			DevVersion: rsp.Version,
		}, &client.EquipCrudRes{})
		if err != nil {
			logger.Error("Update EquipList err: ", err)
		}
	}
	return nil
}

// SflStopHitSet 发送停止打击消息
func (e *DeviceCenter) SflStopHitSet(ctx context.Context, req *client.SflStopHitRequest, rsp *client.SflStopHitResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Sfl{Device: dev}
	status, err := d.SendSflStopHitReq()
	if err != nil {
		return err
	}
	rsp.Status = int32(status)
	if status == 0 {
		rsp.Status = 2
	}
	return nil
}

// SflGNSSSet ...
func (e *DeviceCenter) SflGNSSSet(ctx context.Context, req *client.SflSetGNSSRequest, rsp *client.SflSetGNSSResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Sfl{Device: dev}
	status, err := d.SflGNSSSetReq(req)
	if err != nil {
		logger.Debug("err = ", err)
		return err
	}
	rsp.Status = int32(status)
	if status == 0 {
		rsp.Status = 2
	}
	return nil
}

// SflGNSSGet ...
func (e *DeviceCenter) SflGNSSGet(ctx context.Context, req *client.SflGetGNSSRequest, rsp *client.SflGetGNSSResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		return errors.New("设备未在线")
	}
	logger.Debug("req = ", req)
	logger.Debug("req sn = ", req.Sn)
	logger.Debug("dev = ", dev)
	d := &Sfl{Device: dev}
	status, err := d.SflGNSSGetReq()
	if err != nil {
		return err
	}
	fmt.Println("status = ", status)
	// GunLatitudeTion        = 1e7
	toFloat := 1e7
	// float64(heartInfo.Info.GunLatitude) / GunLatitudeTion
	rsp.Altitude = status.Altitude
	rsp.Latitude = float64(status.Latitude) / toFloat
	rsp.Longitude = float64(status.Longitude) / toFloat
	rsp.Type = uint32(status.Type)
	return nil
}

// SflHitAngleSet 发送打击点信息配置
func (e *DeviceCenter) SflHitAngleSet(ctx context.Context, req *client.SflHitAngleRequest, rsp *client.SflHitAngleResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Sfl{Device: dev}

	status, err := d.SendSflHitAngleSet(req)
	if err != nil {
		return err
	}
	rsp.Status = int32(status)
	if status == 0 {
		rsp.Status = 2
	}

	return nil
}

// SflOnOffSet 发送开关机
func (e *DeviceCenter) SflOnOffSet(ctx context.Context, req *client.SflOnOffRequest, rsp *client.SflOnOffResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Sfl{Device: dev}

	status, err := d.SendSflOnOffSet(req)
	if err != nil {
		return err
	}
	rsp.Status = int32(status)
	if status == 0 {
		rsp.Status = 2
	}

	return nil
}

// SflDetectInfo 侦测信息查询
func (e *DeviceCenter) SflDetectInfo(ctx context.Context, req *client.SflDetectInfoRequest, rsp *client.SflDetectInfoResponse) error {
	//查数据库
	var result *client.SflDetectInfoResponse
	var err error
	if req.FindKey == "" {
		result, err = FindSflDetectInfo(req)
		if err != nil {
			return err
		}
	} else {
		result, err = FindSflDetectInfoByKey(req)
		if err != nil {
			return err
		}
	}

	rsp.List = result.List
	rsp.DetectNum = result.DetectNum
	rsp.HitNum = result.HitNum
	return nil
}

// SflDetectInfoExport  侦测信息导出
func (e *DeviceCenter) SflDetectInfoExport(ctx context.Context, req *client.SflDetectInfoExportRequest, rsp *client.SflDetectInfoExportResponse) error {
	//查数据库
	result, err := FindSflDetectExportInfo(ctx, req)
	//result, err := FindSflDetectExportInfoV2(ctx, req)
	if err != nil {
		return err
	}
	rsp.Status = int32(result)
	return nil
}

// SflReSet 发送复位
func (e *DeviceCenter) SflReSet(ctx context.Context, req *client.SflResetRequest, rsp *client.SflResetResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Sfl{Device: dev}

	status, err := d.SendSflReset()
	if err != nil {
		return err
	}
	rsp.Status = int32(status)
	if status == 0 {
		rsp.Status = 2
	}
	logger.Info("Sfl Reset rsp", rsp.Status)
	return nil
}

// SflSendHitUav 手动选择打击无人机
func (e *DeviceCenter) SflSendHitUav(ctx context.Context, req *client.SflSendHitUavRequest, rsp *client.SflSendHitUavResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Sfl{Device: dev}

	status, err := d.SendSflHitUav(req)
	if err != nil {
		return err
	}
	rsp.Status = int32(status)
	if status == 0 {
		rsp.Status = 2
	}
	logger.Info("Sfl Reset rsp", rsp.Status)
	return nil
}

// SflGetStatus 发送获取状态
func (e *DeviceCenter) SflGetStatus(ctx context.Context, req *client.SflGetStatusRequest, rsp *client.SflGetStatusResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Sfl{Device: dev}

	result, err := d.SendSflGetStatus()
	if err != nil {
		return err
	}
	rsp.Sn = req.Sn
	rsp.HitAngleEnd = result.HitAngleEnd
	rsp.HitAngleBegin = result.HitAngleBegin
	rsp.HitMode = result.HitMode
	rsp.HitPitch1 = result.HitPitch1
	rsp.HitPitch2 = result.HitPitch2
	rsp.HitTime = result.HitTime

	return nil
}

// SflGetPower 发送获取开关机
func (e *DeviceCenter) SflGetPower(ctx context.Context, req *client.SflGetPowerRequest, rsp *client.SflGetPowerResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Sfl{Device: dev}

	result, status, err := d.SendSflGetPower()
	if err != nil {
		return err
	}
	rsp.PowerStatus = int32(result)
	rsp.Status = int32(status)
	if status == 0 {
		rsp.Status = 2
	}
	return nil
}

// SflSetHitMode 发送设置工作模式
func (e *DeviceCenter) SflSetHitMode(ctx context.Context, req *client.SflSetHitModeRequest, rsp *client.SflSetHitModeResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Sfl{Device: dev}

	status, err := d.SendSflSetHitMode(req.HitMode)
	if err != nil {
		return err
	}
	rsp.Status = int32(status)
	if status == 0 {
		rsp.Status = 2
	}
	return nil
}

// SflGetHitMode 发送获取工作模式
func (e *DeviceCenter) SflGetHitMode(ctx context.Context, req *client.SflGetHitModeRequest, rsp *client.SflGetHitModeResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Sfl{Device: dev}

	result, err := d.SendSflGetHitMode()
	if err != nil {
		return err
	}
	rsp.Status = int32(result)
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// 启动/停止打击
func (e *DeviceCenter) SflTurnHit(ctx context.Context, req *client.SflTurnHitRequest, rsp *client.SflTurnHitResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &Sfl{Device: dev}

	result, err := d.SendSflTurnHit(req.StartStop)
	if err != nil {
		return err
	}
	rsp.Status = int32(result)
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// 水平方向转动
func (e *DeviceCenter) SflHorizontalTurn(ctx context.Context, req *client.SflHorizontalTurnRequest, rsp *client.SflHorizontalTurnResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &Sfl{Device: dev}

	result, err := d.SendSflHorizontalTurn(req)
	if err != nil {
		return err
	}
	rsp.Status = int32(result)
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// 垂直方向转动
func (e *DeviceCenter) SflVerticalTurn(ctx context.Context, req *client.SflVerticalTurnRequest, rsp *client.SflVerticalTurnResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &Sfl{Device: dev}

	result, err := d.SendSflVerticalTurn(req)
	if err != nil {
		return err
	}
	rsp.Status = int32(result)
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// AgxSelectUav Agx发送选中无人机
func (e *DeviceCenter) AgxSelectUav(ctx context.Context, req *client.AgxSelectUavRequest, rsp *client.AgxSelectUavResponse) error {
	logger.Info("Agx Send Agx Select Uav,req:", req)
	dev := FindCacheDevice(req.Sn, common.DEV_AGX)
	if dev == nil {
		return errors.New("设备未在线")
	}
	d := &Agx{Device: dev}
	result, err := d.AgxSelectUav(req)
	if err != nil {
		logger.Error("Agx Select Uav err:", err)
		return err
	}
	rsp.Status = result
	return nil
}

// AgxSelectSflUav Agx发送选中Sfl探测的无人机
func (e *DeviceCenter) AgxSelectSflUav(ctx context.Context, req *client.AgxSelectSflUavRequest, rsp *client.AgxSelectSflUavResponse) error {
	logger.Info("Agx Send Agx Select Sfl Uav,req:", req)
	dev := FindCacheDevice(req.AgxSn, common.DEV_AGX)
	if dev == nil {
		return errors.New("设备未在线")
	}
	d := &Agx{Device: dev}
	status, err := d.AgxSelectSflUav(req)
	if err != nil {
		logger.Error("Agx Select Sfl Uav err:", err)
		return err
	}
	rsp.Status = status
	if status == 0 {
		rsp.Status = 2
	}
	return nil
}

type SqTable struct {
	Name string
}

func isSameDay(starttime, endtime int64) bool {
	time1 := time.Unix(starttime/1000, 0)
	time2 := time.Unix(endtime/1000, 0)

	// 获取日期部分
	date1 := time1.Format("2006-01-02")
	date2 := time2.Format("2006-01-02")
	return date1 == date2
}

const (
	durationSplitTime = 5000 //5秒
)

func splitTimes(timeSeri []int64) []*client.DeviceDetailListRespUtil {
	if len(timeSeri) == 0 {
		logger.Debug("len timeSeri = 0")
		return nil
	}
	startTime := timeSeri[0]
	endTime := timeSeri[0]
	rsptime := make([]*client.DeviceDetailListRespUtil, 0)
	sep := 0
	logger.Debug("len timeSeri = ", len(timeSeri))
	for _, t := range timeSeri[1:] {
		// logger.Debug("t-endTime = ", t-endTime)
		if t-endTime > durationSplitTime {
			// logger.Debug("t = ", t)
			// ss := time.Unix(startTime/1000, 0) //  return with debug message
			// sss := ss.Format("2006-01-02 15:04:05")
			// s := fmt.Sprintf("%s__%s", sss, strconv.FormatInt(startTime, 10))

			s := strconv.FormatInt(startTime, 10)

			// ee := time.Unix(endTime/1000, 0) // return with debug message
			// eee := ee.Format("2006-01-02 15:04:05")
			// e := fmt.Sprintf("%s__%s", eee, strconv.FormatInt(endTime, 10))
			e := strconv.FormatInt(endTime, 10)

			rsptime = append(rsptime, &client.DeviceDetailListRespUtil{StartTime: s, EndTime: e})
			startTime = t
			sep++
		}
		endTime = t
	}
	s := strconv.FormatInt(startTime, 10)
	e := strconv.FormatInt(endTime, 10)
	rsptime = append(rsptime, &client.DeviceDetailListRespUtil{StartTime: s, EndTime: e})

	return rsptime
}

/*
DeviceDetailList handle层
*/
func (e *DeviceCenter) DeviceDetailList(ctx context.Context, req *client.DeviceDetailListReq, rsp *client.DeviceDetailListResp) error {
	startTimeInt, err := strconv.ParseInt(req.StartTime, 10, 64)
	if err != nil {
		logger.Error("error startTime format")
		return errors.New("error startTime format")
	}
	logger.Debug("startTimeInt  = ", startTimeInt)
	endTimeInt, err := strconv.ParseInt(req.EndTime, 10, 64)
	if err != nil {
		logger.Error("error endTime format")
		return errors.New("error endTime format")
	}
	logger.Debug("endTimeInt  = ", endTimeInt)
	if startTimeInt > endTimeInt {
		logger.Error("start time larger than end time")
		return errors.New("start time larger than end time")
	}

	dateTime := time.Unix(startTimeInt/1000, 0) // 转换为 time.Time 对象
	startTimeStr := dateTime.Format("20060102")
	var sns []string

	for _, u := range req.DevList {
		sns = append(sns, u.Sn)
	}

	var detectsTable []string
	var xxxTable []string
	logger.Debug("sns = ", sns)
	for _, snu := range sns {
		var tmpTable []SqTable
		sPrefix := snu + "_%_" + startTimeStr
		if isSameDay(startTimeInt, endTimeInt) {
			result := db.GetDB().Raw("SELECT name FROM sqlite_master WHERE type='table' AND name LIKE ? ", sPrefix).Scan(&tmpTable)
			if result.Error != nil {
				logger.Error(result.Error)
			}
		} else {
			dtmp := time.Unix(endTimeInt/1000, 0)
			endTimeStr := dtmp.Format("20060102")
			ePrefix := snu + "_%_" + endTimeStr
			result := db.GetDB().Raw("SELECT name FROM sqlite_master WHERE type='table' AND (name LIKE ? OR name LIKE ?)", sPrefix, ePrefix).Scan(&tmpTable)
			if result.Error != nil {
				logger.Error(result.Error)
			}
		}
		for _, t := range tmpTable {
			fmt.Println("table name = **************> ", t.Name)
			if strings.Contains(t.Name, ReplayDetectName) {
				logger.Debug("detect table = ", t.Name)
				detectsTable = append(detectsTable, "\""+t.Name+"\"")
				logger.Debug("detectsTable = ", detectsTable)
			} else {
				xxxTable = append(xxxTable, "\""+t.Name+"\"")
			}
		}
	}
	timeSeri := make([]int64, 0)
	if len(detectsTable) > 0 {
		childSQL := fmt.Sprintf("SELECT create_time FROM %s WHERE create_time >= %d AND create_time <= %d ", detectsTable[0], startTimeInt, endTimeInt)
		var child string
		for _, dt := range detectsTable[1:] {
			child = fmt.Sprintf(" %s UNION SELECT create_time FROM %s WHERE create_time >= %d AND create_time <= %d ", child, dt, startTimeInt, endTimeInt)
		}
		formSQL := fmt.Sprintf("%s%s", childSQL, child)
		detectSQL := fmt.Sprintf("SELECT create_time FROM ( %s ) AS combined_times ORDER BY create_time;", formSQL)
		logger.Debug("detectSQL = ", detectSQL)
		err = db.GetDB().Raw(detectSQL).Scan(&timeSeri).Error
		if err != nil {
			logger.Debug(err)
		}
		logger.Debug("timeSeri = ", timeSeri)
		spResult := splitTimes(timeSeri)
		logger.Debug("sp_result = ", spResult)
		rsp.DroneTimeList = spResult
	}

	if len(xxxTable) > 0 {
		childSQL := fmt.Sprintf("SELECT create_time FROM %s  WHERE create_time >= %d AND create_time <= %d ", xxxTable[0], startTimeInt, endTimeInt)
		var child string
		for _, dt := range xxxTable[1:] {
			child = fmt.Sprintf("%s UNION SELECT create_time FROM %s WHERE create_time >= %d AND create_time <= %d", child, dt, startTimeInt, endTimeInt)
		}
		formSQL := fmt.Sprintf("%s%s", childSQL, child)
		detectSQL := fmt.Sprintf("SELECT create_time FROM ( %s) AS combined_times ORDER BY create_time;", formSQL)

		logger.Debug("detectSQL = ", detectSQL)
		err = db.GetDB().Raw(detectSQL).Scan(&timeSeri).Error
		if err != nil {
			logger.Debug(err)
		}
		logger.Debug("timeSeri = ", timeSeri)
		spResult := splitTimes(timeSeri)
		logger.Debug("sp_result = ", spResult)

		rsp.DevTimeList = spResult
	}
	return nil

}

// AgxCalibration Agx发送标定
func (e *DeviceCenter) AgxCalibration(ctx context.Context, req *client.AgxCalibrationRequest, rsp *client.AgxCalibrationRespone) error {
	logger.Info("Agx Send Calibration,req:", req)
	dev := FindCacheDevice(req.Sn, common.DEV_AGX)
	if dev == nil {
		return errors.New("设备未在线")
	}
	d := &Agx{Device: dev}
	result, err := d.AgxCalibration(req)
	if err != nil {
		logger.Error("Agx Calibration err:", err)
		return err
	}
	rsp.Result = result
	return nil
}

//// AirTracerGetVersionInfo 发送获取机载Tracer版本信息
//func (e *DeviceCenter) AirTracerGetVersionInfo(ctx context.Context, req *client.AirTracerGetVersionRequest, rsp *client.AirTracerGetVersionResponse) error {
//	dev := FindCacheDevice(req.Sn, common.DEV_Air_Tracer)
//	if dev == nil {
//		return errors.New("设备未在线")
//	}
//
//	d := &Fpv{Device: dev}
//	rsp, err := d.FpvSendGetVersion()
//	if err != nil {
//		return err
//	}
//	return nil
//}

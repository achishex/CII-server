package handler

import (
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/helper"
	pb "adasgitlab.autel.com/tools/cuav_server/proto/client"
	"context"
	"errors"
	"fmt"
	"github.com/gammazero/workerpool"
	"strconv"
	"strings"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
)

type DataReplay struct{}

func NewDataReplay() *DataReplay {
	return &DataReplay{}
}
func (p *DataReplay) DataReplay(ctx context.Context, req *client.DataReplayReq, res *client.DataReplayRes) error {
	logger.Debug("------>into DataReplay req is :", req)
	t2 := time.Unix(0, req.TimeStamp*int64(time.Millisecond))
	// 加上指定的秒数
	newTime := t2.Add(time.Duration(req.ReplayTime) * time.Second)
	// 将新的时间转换回时间戳（精确到毫秒）
	stopTime := newTime.UnixNano() / int64(time.Millisecond)

	timestampTostr := time.Unix(0, req.TimeStamp*int64(time.Millisecond))
	if req.DevType == 1 { //雷达
		detectTableName, heartTableName, postureTableName := common.BuildDetectTableName(req.Sn, timestampTostr),
			common.BuildHeartTableName(req.Sn, timestampTostr),
			common.BuildPostureTableName(req.Sn, timestampTostr)

		var listDetect []*bean.RadarReplayDetect
		err := db.GetDB().Raw("select * from "+detectTableName+" where create_time >= ? and create_time <= ?", req.TimeStamp, stopTime).Scan(&listDetect).Error
		if err != nil {
			return errors.New("query RadarReplayDetect failed")
		}
		var listHeart []*bean.RadarReplayHeart
		err = db.GetDB().Raw("select * from "+heartTableName+" where create_time >= ? and create_time <= ?", req.TimeStamp, stopTime).Scan(&listHeart).Error
		if err != nil {
			return errors.New("query RadarReplayHeart failed")
		}
		var listPosture []*bean.RadarReplayPosture
		err = db.GetDB().Raw("select * from "+postureTableName+" where create_time >= ? and create_time <= ?", req.TimeStamp, stopTime).Scan(&listPosture).Error
		if err != nil {
			return errors.New("query RadarReplayPosture failed")
		}

		var temptime int64
		var templist []*client.ReplayListDetectRadar
		templist = make([]*client.ReplayListDetectRadar, 0)
		//雷达探测数据
		for _, detect := range listDetect {
			if temptime == detect.CreateTime || temptime == 0 {
				templist = append(templist, &client.ReplayListDetectRadar{
					X:            float32(detect.X),
					Y:            float32(detect.Y),
					Z:            float32(detect.Z),
					Velocity:     float32(detect.Velocity),
					Azimuth:      float32(detect.Azimuth),
					Alive:        int32(detect.Alive),
					ExistingProb: int32(detect.ExistingProb),
					ObjId:        int32(detect.ObjId),
					StateType:    int32(detect.StateType),
				})
				temptime = detect.CreateTime
			} else {
				res.ListDetect = append(res.ListDetect, &client.ReplayListDetect{
					Timestamp:       temptime,
					ListDetectRadar: templist,
				})
				temptime = detect.CreateTime
				templist = make([]*client.ReplayListDetectRadar, 0)
				templist = append(templist, &client.ReplayListDetectRadar{
					X:            float32(detect.X),
					Y:            float32(detect.Y),
					Z:            float32(detect.Z),
					Velocity:     float32(detect.Velocity),
					Azimuth:      float32(detect.Azimuth),
					Alive:        int32(detect.Alive),
					ExistingProb: int32(detect.ExistingProb),
					ObjId:        int32(detect.ObjId),
					StateType:    int32(detect.StateType),
				})

			}

		}
		//雷达心跳数据
		for _, heart := range listHeart {
			res.ListHeart = append(res.ListHeart, &client.ReplayListHeart{
				Timestamp:   heart.CreateTime,
				IsOnline:    int32(heart.IsOnline),
				Electricity: int32(heart.Electricity),
			})
		}
		//雷达姿态数据
		for _, posture := range listPosture {
			res.ListPosture = append(res.ListPosture, &client.ReplayListPosture{
				Timestamp: posture.CreateTime,
				Heading:   float32(posture.Heading),
				Pitching:  float32(posture.Pitching),
				Rolling:   float32(posture.Rolling),
				Longitude: float32(posture.Longitude),
				Latitude:  float32(posture.Latitude),
			})
		}
		return nil
	} else if req.DevType == 2 { //tracer
		detectTableName, heartTableName := common.BuildDetectTableName(req.Sn, timestampTostr),
			common.BuildHeartTableName(req.Sn, timestampTostr)

		var listDetect []*bean.TracerReplayDetect
		err := db.GetDB().Raw("select * from "+detectTableName+" where create_time >= ? and create_time <= ?", req.TimeStamp, stopTime).Scan(&listDetect).Error
		if err != nil {
			return errors.New("query TracerReplayDetect failed")
		}
		var listHeart []*bean.TracerReplayHeart
		err = db.GetDB().Raw("select * from "+heartTableName+" where create_time >= ? and create_time <= ?", req.TimeStamp, stopTime).Scan(&listHeart).Error
		if err != nil {
			return errors.New("query TracerReplayHeart failed")
		}

		//Tracer探测数据
		var temptime int64
		var templist []*client.ReplayListDetectTracer
		for _, detect := range listDetect {
			if temptime == detect.CreateTime || temptime == 0 {
				templist = append(templist, &client.ReplayListDetectTracer{
					OperatorLongitude: float32(detect.OperatorLongitude),
					OperatorLatitude:  float32(detect.OperatorLatitude),
					Freq:              float32(detect.Freq),
					Distance:          float32(detect.Distance),
					DangerLevels:      int32(detect.DangerLevels),
					Role:              int32(detect.Role),
					DroneName:         detect.DroneName,
					SerialNum:         detect.SerialNum,
					DroneLongitude:    float32(detect.DroneLongitude),
					DroneLatitude:     float32(detect.DroneLatitude),
					DroneHeight:       float32(detect.DroneHeight),
					DroneSpeed:        float32(detect.DroneSpeed),
					DroneYawAngle:     float32(detect.DroneYawAngle),
				})
				temptime = detect.CreateTime
			} else {
				res.ListDetect = append(res.ListDetect, &client.ReplayListDetect{
					Timestamp:        temptime,
					ListDetectTracer: templist,
				})
				temptime = detect.CreateTime
				templist = make([]*client.ReplayListDetectTracer, 0)
				templist = append(templist, &client.ReplayListDetectTracer{
					OperatorLongitude: float32(detect.OperatorLongitude),
					OperatorLatitude:  float32(detect.OperatorLatitude),
					Freq:              float32(detect.Freq),
					Distance:          float32(detect.Distance),
					DangerLevels:      int32(detect.DangerLevels),
					Role:              int32(detect.Role),
					DroneName:         detect.DroneName,
					SerialNum:         detect.SerialNum,
					DroneLongitude:    float32(detect.DroneLongitude),
					DroneLatitude:     float32(detect.DroneLatitude),
					DroneHeight:       float32(detect.DroneHeight),
					DroneSpeed:        float32(detect.DroneSpeed),
					DroneYawAngle:     float32(detect.DroneYawAngle),
				})
			}
		}
		//Tracer心跳数据
		for _, heart := range listHeart {
			res.ListHeart = append(res.ListHeart, &client.ReplayListHeart{
				Timestamp:   heart.CreateTime,
				IsOnline:    int32(heart.IsOnline),
				Electricity: int32(heart.Electricity),
				WorkMode:    int32(heart.WorkMode),
				WorkStatus:  int32(heart.WorkStatus),
				AlarmLevel:  int32(heart.AlarmLevel),
			})
		}
	}
	logger.Debug("------>End DataReplay")
	return nil
}

func (p *DataReplay) DataReplayDel(ctx context.Context, req *client.DataReplayDelReq, res *client.DataReplayDelRes) error {
	layout := "20060102" // 日期格式

	timeNowFormat := time.Now().Format("20060102")
	timeNow, err := time.Parse(layout, timeNowFormat)
	if err != nil {
		logger.Error("pare time error:", err)
	}

	tables := make([]string, 0)
	err = db.GetDB().Raw("SELECT name FROM sqlite_master WHERE type='table'").Scan(&tables).Error
	if err != nil {
		return errors.New("SELECT name FROM sqlite_master")
	}

	for _, table := range tables {
		timeIndex := strings.LastIndex(table, "_")
		timeStr := table[timeIndex+1:]
		_, err := time.Parse("20060102", timeStr)
		if err != nil {
			continue
		} else {
			timeAfter, err := time.Parse(layout, timeStr)
			if err != nil {
				logger.Error("pare time error:", err)
			}
			days := int(timeNow.Sub(timeAfter).Hours() / 24)
			if days > 30 {

				sql := fmt.Sprintf("DROP TABLE IF EXISTS `%s`;", table)
				// 执行原始 SQL 语句
				err = db.GetDB().Exec(sql).Error

				if err != nil {
					logger.Error("删除表失败:", err)
					return nil
				}
				logger.Info("删除成功 ：", table)
			}
		}

	}

	return nil
}

func (p *DataReplay) DataReplayGetTime(ctx context.Context, req *client.DataReplayGetTimeReq, res *client.DataReplayGetTimeRes) error {
	var tableName string
	logger.Info("-------> Start rsp device schedule:", req.ListDevice)
	for _, date := range req.ListDevice { //tracer
		if date.DevType != 2 {
			continue
		}

		timestamp := int64(date.StartTime) // 时间戳，单位为毫秒
		// 将时间戳转换为对应的时间
		t := time.Unix(0, timestamp*int64(time.Millisecond))
		// 格式化为年月日时间格式
		tableName = common.BuildDetectTableName(date.Sn, t)

		createTime := make([]float64, 0)
		startTime := strconv.FormatFloat(date.StartTime, 'f', -1, 64)
		stopTime := strconv.FormatFloat(date.EndTime, 'f', -1, 64)
		err := db.GetDB().Raw("SELECT " + "create_time" + " FROM " + tableName +
			" where create_time >= " + startTime + " and create_time <= " + stopTime).Scan(&createTime).Error
		if err != nil {
			logger.Error("query DataReplayGetTime failed")
			continue
		}
		var strTime float64
		var stpTime float64
		if len(createTime) == 0 {
			continue
		}
		for i, time := range createTime {
			if i == 0 {
				strTime = time
			} else if time-createTime[i-1] >= 5000 {
				stpTime = createTime[i-1]
				res.ListDevice = append(res.ListDevice, &client.ListDeviceRsp{
					Sn:        date.Sn,
					DevType:   date.DevType,
					StartTime: strTime,
					EndTime:   stpTime,
					MsgType:   1, //消息类型 1:无人机信息 2：姿态
				})
				strTime = time
			}
		}

		// 处理最后一个时间段
		stpTime = createTime[len(createTime)-1]

		res.ListDevice = append(res.ListDevice, &client.ListDeviceRsp{
			Sn:        date.Sn,
			DevType:   date.DevType,
			StartTime: strTime,
			EndTime:   stpTime,
			MsgType:   1, //消息类型 1:无人机信息 2：姿态
		})

	}

	for _, date := range req.ListDevice { //雷达
		if date.DevType != 1 {
			continue
		}
		timestamp := int64(date.StartTime) // 时间戳，单位为毫秒
		// 将时间戳转换为对应的时间
		t := time.Unix(0, timestamp*int64(time.Millisecond))
		// 格式化为年月日时间格式
		tableName = common.BuildPostureTableName(date.Sn, t)

		createTime := make([]float64, 0)
		startTime := strconv.FormatFloat(date.StartTime, 'f', -1, 64)
		stopTime := strconv.FormatFloat(date.EndTime, 'f', -1, 64)
		err := db.GetDB().Raw("SELECT " + "create_time" + " FROM " + tableName +
			" where create_time >= " + startTime + " and create_time <= " + stopTime).Scan(&createTime).Error
		if err != nil {
			logger.Error("query DataReplayGetTime failed")
			continue
		}
		var strTime float64
		var stpTime float64
		if len(createTime) == 0 {
			continue
		}
		for i, time := range createTime {
			if i == 0 {
				strTime = time
			} else if time-createTime[i-1] >= 5000 {
				stpTime = createTime[i-1]
				res.ListDevice = append(res.ListDevice, &client.ListDeviceRsp{
					Sn:        date.Sn,
					DevType:   date.DevType,
					StartTime: strTime,
					EndTime:   stpTime,
					MsgType:   2, //消息类型 1:无人机信息 2：姿态
				})
				strTime = time
			}
		}

		// 处理最后一个时间段
		stpTime = createTime[len(createTime)-1]

		res.ListDevice = append(res.ListDevice, &client.ListDeviceRsp{
			Sn:        date.Sn,
			DevType:   date.DevType,
			StartTime: strTime,
			EndTime:   stpTime,
			MsgType:   2, //消息类型 1:无人机信息 2：姿态
		})

	}
	logger.Info("End rsp device schedule:", res.ListDevice)
	return nil
}

type QueryDevListProcess struct {
	tabNameKey  string
	dateTimeStr string
	beginTime   int64 //millisecond
	endTime     int64
}

func (q *QueryDevListProcess) GetFuzzyTabName(ctx context.Context) string {
	tabName := q.tabNameKey + q.dateTimeStr
	return tabName
}
func (q *QueryDevListProcess) GetMatchTabName(ctx context.Context) []string {
	fuzzyTabName := q.GetFuzzyTabName(ctx)

	type TableFuzzy struct {
		Name string
	}
	var tables []TableFuzzy

	//sqlQuery := fmt.Sprintf("SELECT name FROM sqlite_master WHERE type='table' and name like '%v%v'", "%", fuzzyTabName)
	sqlQuery := `SELECT name FROM sqlite_master WHERE type='table' and name like '` + "%" + fuzzyTabName + "';"
	logger.Infof("query tab name: %v", sqlQuery)

	err := db.GetDB().Raw(sqlQuery, nil).Find(&tables).Error
	if err != nil {
		logger.Info("select sqlite_master fail")
		return nil
	}
	var ret []string
	for _, v := range tables {
		ret = append(ret, v.Name)

	}
	return ret
}
func (q *QueryDevListProcess) QueryDevList(ctx context.Context) ([]string, map[string]int) {
	tables := q.GetMatchTabName(ctx)
	if len(tables) <= 0 {
		return nil, nil
	}
	//tables may different business heart table
	filterSN := make(map[string]bool) //

	var snWorkModeMap map[string]int

	for _, tab := range tables {
		nums := int(0)
		querySql := fmt.Sprintf("select COUNT(id) as num from '%v' where create_time >= ? and create_time <= ? limit 1", tab)
		err := db.GetDB().Raw(querySql, q.beginTime, q.endTime).Scan(&nums).Error
		if err != nil {
			continue
		}
		if nums <= 0 {
			continue
		}

		items := strings.Split(tab, "_heart_")
		if len(items) <= 0 {
			continue
		}

		if _, ok := filterSN[items[0]]; !ok {
			filterSN[items[0]] = true
		}

		queryWorkMode := fmt.Sprintf("select work_mode from '%v' where work_mode NOT  NULL limit 1;", tab)
		workMode := 0
		err = db.GetDB().Raw(queryWorkMode).Scan(&workMode).Error
		if err == nil && workMode > 0 {
			logger.Infof("sn: %v, work mode: %v", items[0], workMode)

			if snWorkModeMap == nil {
				snWorkModeMap = make(map[string]int)
			}
			snWorkModeMap[items[0]] = workMode
		}
	}

	getSN := func(kv map[string]bool) []string {
		retSN := []string{}
		for k := range kv {
			retSN = append(retSN, k)
		}
		return retSN
	}
	return getSN(filterSN), snWorkModeMap
}

// TODO
// const DevAppEnums
// //1：radar 雷达，
// //2：tracerP
// //3：tracerS
// //4：fpv 车载FPV
// //5：gun/screen 大枪（非云台）
// //6：sfl 哨兵塔
// //7：dev_nsf4000  导航诱导
// //8：dev_urd360 坤雷RF

//
//const (
//	DevTypeDescRadar    string = "radar"
//	DevTypeDescTraceP   string = "traceP"
//	DevTypeDescTracerS  string = "tracerS"
//	DevTypeDescFpv      string = "Fpv"
//	DevTypeDescRF       string = "RF"
//	DevTypeDescSfl      string = "Sfl"
//	DevTypeDescSpoofer  string = "Spoofer"
//	DevTypeDescTracerRF string = "tracerRF"
//)
//
//type DevTypStrEnumMap struct {
//	StrToInt32Map map[string]int32
//	Int32ToStrMap map[int32]string
//}
//
//var DevTypeMapsNode DevTypStrEnumMap
//
//func init() {
//	DevTypeMapsNode = DevTypStrEnumMap{
//		StrToInt32Map: map[string]int32{
//			DevTypeDescRadar:    int32(dataReplay.EnumDevTypeList_RadarDevTypeEnum),   //radar 雷达，
//			DevTypeDescTraceP:   int32(dataReplay.EnumDevTypeList_TracerPDevTypeEnum), //tracerP
//			DevTypeDescTracerS:  int32(dataReplay.EnumDevTypeList_TracerSDevTypeEnum), // EnumDevTypeList = 3 //tracerS
//			DevTypeDescFpv:      int32(dataReplay.EnumDevTypeList_FpvDevTypeEnum),     //    EnumDevTypeList = 4 //fpv 车载FPV
//			DevTypeDescRF:       int32(dataReplay.EnumDevTypeList_GunDevTypeEnum),     //     EnumDevTypeList = 5 //gun/screen 大枪（非云台）
//			DevTypeDescSfl:      int32(dataReplay.EnumDevTypeList_SFLDevTypeEnum),     //    EnumDevTypeList = 6 //sfl 哨兵塔
//			DevTypeDescSpoofer:  int32(dataReplay.EnumDevTypeList_SpooferDevTypeEnum), // EnumDevTypeList = 7 // dev_nsf4000  导航诱导
//			DevTypeDescTracerRF: int32(dataReplay.EnumDevTypeList_UrdDevTypeEnum),     //    EnumDevTypeList = 8 //dev_urd360 坤雷RF
//		},
//	}
//	DevTypeMapsNode.Int32ToStrMap = make(map[int32]string)
//	for k, v := range DevTypeMapsNode.StrToInt32Map {
//		DevTypeMapsNode.Int32ToStrMap[v] = k
//	}
//}
//
//func DevTypeFromStrToInt(devTypeStr string) int32 {
//	if v, ok := DevTypeMapsNode.StrToInt32Map[devTypeStr]; ok {
//		return v
//	}
//	return 0
//}
//
//func DevTypeFromIntToStr(devTypeInt int32) string {
//	if v, ok := DevTypeMapsNode.Int32ToStrMap[devTypeInt]; ok {
//		return v
//	}
//	return ""
//}

type DevTypeData struct {
	sn    string `json:"sn"`
	etype string `json:"etype"`
}

func (dv *DevTypeData) String() string {
	return dv.sn + ":" + dv.etype
}

type ListDevTypeData []*DevTypeData

func (ldt ListDevTypeData) String() string {
	if ldt == nil {
		return ""
	}
	var s string
	for _, v := range ldt {
		if v == nil {
			return ""
		}
		s += v.String()
	}
	return s
}

func (q *QueryDevListProcess) QueryDevListType(ctx context.Context, devList []string, workModes map[string]int) []*client.DevTypeItem {
	logger.Infof("sn list: %v", devList)

	ret := make([]*client.DevTypeItem, 0)

	if len(devList) <= 0 {
		return nil
	}
	inSql := ""
	for range devList {
		if len(inSql) <= 0 {
			inSql += " ? "
		} else {
			inSql += ", ? "
		}
	}

	logger.Infof("inSql: %v", inSql)
	queryTabName := []string{
		bean.EquipList{}.TableName(),
		bean.EquipListBackUp{}.TableName(),
	}
	for _, queryTab := range queryTabName {
		var queryDevType []*pb.EquipInfo

		querySql := fmt.Sprintf("select * from %v where sn in  (%v)", queryTab, inSql)
		logger.Infof("sql query tmp: %v", querySql)

		var vals []any
		for _, v := range devList {
			vals = append(vals, v)
		}
		err := db.GetDB().Debug().Raw(querySql, vals...).Scan(&queryDevType).Error
		if err != nil {
			logger.Errorf("query device type fail from tab: %v fail, e: %v", queryTab, err)
			continue
		}

		logger.Infof("query dev type: %v", queryDevType)

		for _, item := range queryDevType {
			if item == nil {
				continue
			}

			retItem := &client.DevTypeItem{
				SN:      item.Sn,
				DevType: helper.DevTypeFromStrToInt(item.Etype),
			}

			if item.Etype != "DroneID" &&
				retItem.DevType != int32(client.EnumDevTypeList_TracerPDevTypeEnum) &&
				retItem.DevType != int32(client.EnumDevTypeList_TracerSDevTypeEnum) {
				//
			} else {
				if workModes != nil && len(workModes) > 0 {
					if workMode, ok := workModes[item.Sn]; ok {
						if workMode != 2 && workMode != 3 {
							retItem.DevType = helper.DevTypeFromStrToInt(helper.DevTypeDescTraceP)
							logger.Infof("sn: %v, is tracerP: %v", item.Sn, retItem.DevType)

						} else {
							retItem.DevType = helper.DevTypeFromStrToInt(helper.DevTypeDescTracerS)
							logger.Infof("sn: %v, is tracerS: %v", item.Sn, retItem.DevType)
						}
					}
				} else {
					retItem.DevType = helper.DevTypeFromStrToInt(helper.DevTypeDescTraceP)
					logger.Infof("sn: %v, is tracerP: %v", item.Sn, retItem.DevType)
				}
			}
			ret = append(ret, retItem)
		}
	}
	return ret
}

func (p *DataReplay) QueryDeviceTypeOnDay(ctx context.Context, data *DayTimeInfo) ([]*client.DevTypeItem, error) {
	if data == nil {
		return nil, errors.New("is nil")
	}
	heartProc := QueryDevListProcess{
		tabNameKey:  "_heart_", // %_heart_20231208
		dateTimeStr: data.mydString,
		beginTime:   data.beginTime,
		endTime:     data.endTime,
	}
	devList, snWorkModeMap := heartProc.QueryDevList(ctx)
	return heartProc.QueryDevListType(ctx, devList, snWorkModeMap), nil
}

func (p *DataReplay) DataReplayDevList(ctx context.Context, req *client.DeviceTimeScope, res *client.DeviceTypeList) error {
	if req == nil || res == nil {
		return errors.New("input param is nil")
	}
	//
	var timeInfo []DayTimeInfo
	var isSame = CheckIsSameDay(req.BeginTime, req.EndTime)
	if isSame {
		timeInfo = append(timeInfo, DayTimeInfo{
			beginTime: req.BeginTime,
			endTime:   req.EndTime,
			mydString: Format20060102OnTime(req.BeginTime),
		})
	} else {
		timeInfo = SplitTimeByDay(req.BeginTime, req.EndTime)
	}

	//每个任务 是查询表，然后在表内做范围查找。返回结果。
	wp := workerpool.New(len(timeInfo))

	var taskRet chan *client.DevTypeItem = make(chan *client.DevTypeItem, 10240)
	for i, _ := range timeInfo {
		ptrTask := &timeInfo[i]
		wp.Submit(func() {
			tmpRet, e := p.QueryDeviceTypeOnDay(ctx, ptrTask)
			if e != nil {
				return
			}

			for _, v := range tmpRet {
				if v == nil {
					continue
				}
				taskRet <- v
			}
		})
	}
	wp.StopWait()
	close(taskRet)

	var filters map[string]bool = make(map[string]bool)
	for item := range taskRet {
		if item == nil {
			continue
		}
		if _, ok := filters[item.SN]; ok {
			continue
		}
		filters[item.SN] = true
		res.DevList = append(res.DevList, item)
	}
	return nil
}

package handler

import (
	"context"
	"errors"
	"os"
	"strings"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/helper"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/awsS3"
)

// 本地日志
func (e *DeviceCenter) GetLocalLogs(ctx context.Context, req *client.GetLocalLogRequest, rsp *client.GetLocalLogResponse) error {
	logger.Info("-->Into Get Local Logs")
	logInfo := make([]*client.LogsAll, 0)

	//todo  和云日志比较，看是否云上已有文件

	//获取本地日志文件完整路径
	fileArr := helper.Findfile(req.LogPath) //返回形式

	logger.Info("Logs List is: ", fileArr)
	var i, j int
	if req.Sn != "" { //取固定sn下的日志目录
		for i = 0; i < len(fileArr); {
			if !strings.Contains(fileArr[i], req.Sn) {
				i++
				continue
			}
			list := make([]*client.Logs, 0)
			var devType DevType
			if strings.Contains(fileArr[i], "guns") {
				devType = GUN
			}
			if strings.Contains(fileArr[i], "radar") {
				devType = RADAR
			}

			for j = i; j < len(fileArr); j++ {
				// 获取文件信息
				fileInfo, err := os.Stat(fileArr[j])
				if err != nil {
					logger.Error("os stat err: ", err)
				}
				// 计算文件大小（单位为 KB）
				size := float64(fileInfo.Size())
				logStat := false

				list = append(list, &client.Logs{
					LogName:       fileArr[j],
					LogId:         fileArr[j],
					LogDataLength: int32(size),
					LogState:      logStat,
				})

			}
			logInfo = append(logInfo, &client.LogsAll{
				Sn:         req.Sn,
				DeviceType: int32(devType),
				List:       list,
			})
			i = i + j
		}
	} else { //取全部日志目录
		for i = 0; i < len(fileArr); {
			list := make([]*client.Logs, 0)
			var devType DevType
			if strings.Contains(fileArr[i], "guns") {
				devType = GUN
			}
			if strings.Contains(fileArr[i], "radar") {
				devType = RADAR
			}

			var tempSn string
			strArr := strings.Split(fileArr[j], "/")
			for k, v := range strArr {
				if v == "guns" {
					tempSn = strArr[k+1]
				} else if v == "radar" {
					tempSn = strArr[k+1]
				}
			}
			for j = i; j < len(fileArr); j++ {
				// 获取文件信息
				fileInfo, err := os.Stat(fileArr[j])
				if err != nil {
					logger.Error("os stat err: ", err)
				}
				// 计算文件大小
				size := float64(fileInfo.Size())
				list = append(list, &client.Logs{
					LogName:       fileArr[j],
					LogId:         fileArr[j],
					LogDataLength: int32(size),
					LogState:      false,
				})
			}
			logInfo = append(logInfo, &client.LogsAll{
				Sn:         tempSn,
				DeviceType: int32(devType),
				List:       list,
			})
			i = i + j
		}
	}

	rsp.List = logInfo
	logger.Info("-->Get Local Logs List is: ", rsp.List)
	logger.Info("-->Get Local Logs End")
	return nil
}
func (e *DeviceCenter) DelLocalLogs(ctx context.Context, req *client.DelLocalLogRequest, rsp *client.DelLocalLogResponse) error {
	logger.Info("-->Into Del Local Logs")
	//前端带全路径
	if strings.Contains(req.LogPath, req.LogName) {
		err := os.Remove(req.LogPath)
		if err != nil {
			rsp.Status = false
			logger.Error("Error deleting file:", err)
		} else {
			logger.Info("File deleted successfully")
		}
		logger.Info("-->DelLocal Logs is:  ", req.LogPath)
	}
	rsp.Status = true
	logger.Info("-->Del Local Logs End")
	return nil
}

// 设备日志
func (e *DeviceCenter) GetDeviceLogList(ctx context.Context, req *client.GetDeviceLogListRequest, rsp *client.DeviceLogList) error {
	return nil
}
func (e *DeviceCenter) GetDeviceLog(ctx context.Context, req *client.GetDeviceLogRequest, rsp *client.GetDeviceLogResponse) error {
	logger.Info("-->Into Get Device Log")

	return nil
}
func (e *DeviceCenter) DeleteDeviceLog(ctx context.Context, req *client.DeleteDeviceLogRequest, rsp *client.DeleteDeviceLogResponse) error {
	logger.Info("-->Into Delete Device Log")
	dev, devType := FindCacheDeviceAndType(req.Sn)
	if dev == nil {
		logger.Error("设备未在线")
		return errors.New("设备未在线")
	}
	if devType == common.DEV_SCREEN {
		logger.Info("-->Into Del Gun Log")
		gun := &CounterGun{Device: dev}
		logRes, err := gun.SendDelLog(req.Sn)
		gun.LogOperator(req, rsp, err)
		if err != nil {
			return err
		}
		rsp.Status = logRes.Status
		logger.Info("-->Del Gun Log End")
	} else if devType == common.DEV_RADAR {
		logger.Info("-->Into Del Radar Log")
		radar := &Radar{Device: dev}
		_, err := radar.SendDelLog(req.Sn, req.LogPath)
		if err != nil {
			rsp.Status = false //失败
			return err
		}
		rsp.Status = true //成功
		logger.Info("-->Del Radar Log End")
	} else if devType == common.DEV_V2DRONEID {
		logger.Info("-->Into Del DroneId Log")
		droneId := &DroneID{Device: dev}
		_, err := droneId.SendDelLog(req.Sn, req.LogPath)
		if err != nil {
			rsp.Status = false //失败
			return err
		}
		rsp.Status = true //成功
		logger.Info("-->Del DroneId Log End")
	} else if devType == 0 {
		logger.Error("设备未在线")
		return nil
	}
	return nil
}

// 云日志
func (e *DeviceCenter) GetDeviceLogListCloud(ctx context.Context, req *client.GetDeviceLogListCloudRequest, rsp *client.GetDeviceLogListCloudResponse) error {
	logger.Info("-->Into Get Device LogList Cloud")

	err, data := awsS3.GetDirFile(awsS3.LOG)
	if err != nil {
		logger.Error("Get DirFile fail:", err)
		rsp.Status = false
		return nil
	}

	loglist := make([]*client.LogList, 0)
	for _, fileInfo := range data.Data.List {
		var logtype int
		if fileInfo.DeviceType == int8(awsS3.GUN) {
			logtype = int(GUNS) //枪
		} else if fileInfo.DeviceType == int8(awsS3.RADAR) {
			logtype = int(RADARS) //雷达
		}

		loglist = append(loglist, &client.LogList{
			LogName:     fileInfo.FileName,
			UserAccount: fileInfo.UserName,
			LogType:     int32(logtype),
			Sn:          fileInfo.Sn,
		})
	}
	rsp.List = loglist
	rsp.Status = true
	logger.Info("-->Get Device LogList Cloud End")
	return nil
}

func (e *DeviceCenter) UploadDeviceLogCloud(ctx context.Context, req *client.UploadDeviceLogCloudRequest, rsp *client.UploadDeviceLogCloudResponse) error {
	logger.Info("-->Into Upload Device Log Cloud")

	rsp.Status = true
	rsp.UserAccount = req.UserAccount
	rsp.LogName = req.LogName
	//go DownLoadling(LocalLogUpload, req.LogName, req.Sn)

	//找到文件的完整路径
	files, err := helper.FindFileMoreDir(req.LogPath, req.LogName)
	if err != nil {
		logger.Error("Find File MoreDir err:", err, req.LogPath, req.LogName)
	} else {
		for _, file := range files {
			logger.Debug("file path :", file)
			req.LogPath = file[:strings.LastIndex(file, "/")+1]
		}
	}
	//打开文件
	logger.Info("LogPath is %v", req.LogPath)
	uploadFile, err := os.Open(req.LogPath + req.LogName)
	if err != nil {
		logger.Error("Open file [%v] err:%v", req.LogPath+req.LogName, err)
		return err
	}
	defer uploadFile.Close()

	info, err := uploadFile.Stat()
	if err != nil {
		logger.Error("File Stat err:%v", err)
		return err
	}
	//文件如果没有内容，不允许上传。
	if info.Size() == 0 {
		return errors.New("文件内容为空,上传失败。")
	}
	//判断上传文件设备类型
	var dev awsS3.DevType
	if strings.Contains(req.LogPath, "/guns/") {
		dev = awsS3.GUN
	} else if strings.Contains(req.LogPath, "/radar/") {
		dev = awsS3.RADAR
	}
	//新起协程去上传文件
	go func() {
		err = awsS3.PresigningUploadFile(awsS3.LOG, dev, req.UserAccount, req.Sn, req.LogPath, req.LogName)
		if err != nil {
			logger.Error("Presigning Upload File err:", err)
			return
		}
		logger.Info("Upload succeeded,LogName : ", req.LogName)
	}()

	logger.Info("-->Upload Device Log Cloud End")
	return nil
}

func (e *DeviceCenter) DownloadDeviceLogCloud(ctx context.Context, req *client.DownloadDeviceLogCloudRequest, rsp *client.DownloadDeviceLogCloudResponse) error {
	logger.Info("-->Into Download Device Log Cloud")

	rsp.Status = true
	rsp.UserAccount = req.UserAccount
	rsp.LogName = req.LogName
	//go DownLoadling(CloudLogDownload, req.LogName, req.Sn)
	//获取文件列表
	err, data := awsS3.GetDirFile(awsS3.LOG)
	if err != nil {
		logger.Error("Get DirFile fail:", err)
		return err
	}
	var dev awsS3.DevType
	var dirName string
	for _, fileInfo := range data.Data.List {
		if strings.Contains(fileInfo.FileKey, req.LogName) {
			if fileInfo.DeviceType == int8(awsS3.GUN) { //枪
				dev = awsS3.GUN
				errs := helper.CreateDirIfNotExist(req.LogPath + "/guns/" + req.Sn + "/")
				dirName = "/guns/"
				if errs != nil {
					logger.Error("Create directory error : ", errs)
				} else {
					logger.Info("Directory created successfully.")
				}
			} else if fileInfo.DeviceType == int8(awsS3.RADAR) { //雷达
				dev = awsS3.RADAR
				errs := helper.CreateDirIfNotExist(req.LogPath + "/radar/" + req.Sn + "/")
				dirName = "/radar/"
				if errs != nil {
					logger.Error("Create directory error : ", errs)
				} else {
					logger.Info("Directory created successfully.")
				}
			}
		}
	}
	go func() {
		loadFile, errs := awsS3.PresigningDownLoadFile(awsS3.LOG, dev, req.Sn, req.LogName)
		if errs != nil {
			logger.Error("Presigning DownLoad File err:%v", errs)
			return
		}
		errs = os.WriteFile(req.LogPath+dirName+req.Sn+"/"+req.LogName, loadFile, 0644)
		if err != nil {
			logger.Error("Write File err:%v", errs)
			return
		}
		logger.Info("Download succeeded,LogName : ", req.LogName)
	}()
	logger.Info("-->Download Device Log Cloud End")
	return nil
}

func (e *DeviceCenter) DeleteDeviceLogCloud(ctx context.Context, req *client.DeleteDeviceLogCloudRequest, rsp *client.DeleteDeviceLogCloudResponse) error {
	logger.Info("-->Into Delete Device Log Cloud")

	//获取文件列表
	err, data := awsS3.GetDirFile(awsS3.LOG)
	if err != nil {
		logger.Error("Get DirFile fail:", err)
		return err
	}
	var dev awsS3.DevType
	for _, fileInfo := range data.Data.List {
		if strings.Contains(fileInfo.FileKey, req.LogName) {
			if fileInfo.DeviceType == int8(awsS3.GUN) { //枪
				dev = awsS3.GUN
			} else if fileInfo.DeviceType == int8(awsS3.RADAR) { //雷达
				dev = awsS3.RADAR
			}
		}
	}
	go func() {
		_, errs := awsS3.PresigningDeleteFile(awsS3.LOG, dev, req.Sn, req.LogName)
		if errs != nil {
			logger.Error("Presigning Delete File err:", errs)
			return
		}
	}()
	rsp.Status = true
	rsp.UserAccount = req.UserAccount
	rsp.LogName = req.LogName
	logger.Info("-->Delete Device Log Cloud End")
	return nil
}

// 同步日志
func (e *DeviceCenter) SyncDeviceLog(ctx context.Context, req *client.SyncDeviceLogRequest, rsp *client.SyncDeviceLogResponse) error {
	logger.Info("-->Into Sync Device Log")
	if req.Sn == "" {
		return errors.New("sn为空")
	}
	if len(DeviceLogMap.Data) == 0 {
		DeviceLogMap = MapWithChan{
			Data: make(map[string]SnChan),
		}
	}
	if !req.SyncSwitch {
		//从数据库删除
		err := NewLogStatus().Deletes(ctx, &client.LogStatusDeletesReq{Sn: req.Sn}, &client.LogStatusDeletesRsp{})
		if err != nil {
			logger.Error("Log Stat Insert err : ", err)
		}
		//关掉对应协程
		if ch, ok := DeviceLogMap.Data[req.Sn]; ok {
			ch <- req.Sn
		}
	} else {
		DeviceLogMap.Data[req.Sn] = make(SnChan)
		FirstGetLog(req.Sn, req.LogPath, req.SyncPeriod)
		go func() {
			if req.SyncPeriod < SyncPeriod {
				req.SyncPeriod = SyncPeriod
			}
			ticker := time.NewTicker(time.Duration(req.SyncPeriod) * time.Minute)
			defer ticker.Stop()
			for {
				if ch, ok := DeviceLogMap.Data[req.Sn]; ok {
					select {
					case vars := <-ch: //退出协程
						logger.Info("Log Map out: ", vars)
						rsp.Status = true
						return
					case <-ticker.C: //周期执行获取设备日志
						logList, err := GetDeviceLogList(req.Sn) //获取设备日志列表
						if err != nil {
							logger.Error("Get Device Log List err : ", err)
							continue
							//rsp.Status = false
							//return
						}
						if logList == nil {
							continue
						}
						fileArr := helper.Findfile(req.LogPath) //获取本地文件夹下所有文件的完整路径
						logger.Debug("FileArr is :", fileArr)

						localLogList := make([]DeviceLogList, 0)

						//如果本地文件夹下有设备的文件，则不获取
						for _, v := range logList {
							isExist := false
							for _, v1 := range fileArr {
								if strings.Contains(v1, v.LogName) {
									isExist = true
								}
							}
							if !isExist {
								localLogList = append(localLogList, DeviceLogList{
									LogName:    v.LogName,
									LogDataLen: v.LogDataLen,
								})
							}
						}
						logger.Info("-->Req Log List is: ", localLogList)
						GetDeviceLog(req.Sn, req.LogPath, localLogList)
					}
				}
			}
		}()
	}
	logger.Info("-->End Sync Device Log")
	rsp.Status = true
	return nil
}
func (e *DeviceCenter) SyncLocalLog(ctx context.Context, req *client.SyncLocalLogRequest, rsp *client.SyncLocalLogResponse) error {
	logger.Info("-->Into Sync Local Log")
	if !req.SyncSwitch {
		//修改数据库
		err := NewLogCloudStatus().Update(ctx, &client.LogCloudStatusUpdateReq{Status: 2}, &client.LogCloudStatusUpdateRsp{})
		if err != nil {
			logger.Error("Log Stat Update err : ", err)
		}
		//关掉协程
		LocalLogMap <- struct{}{}
	} else {
		go FirstUploadLog(req.Sn, req.LogPath, req.SyncPeriod)
		go func() {
			if req.SyncPeriod < SyncPeriod {
				req.SyncPeriod = SyncPeriod
			}
			ticker := time.NewTicker(time.Duration(req.SyncPeriod) * time.Minute)
			defer ticker.Stop()
			for {
				select {
				case <-LocalLogMap: //退出协程
					logger.Info("Local Log Map out: ")
					rsp.Status = true
					return
				case <-ticker.C: //周期执行日志上传
					err, data := awsS3.GetDirFile(awsS3.LOG) //获取设备日志列表
					if err != nil {
						logger.Error("Get DirFile fail:", err)
						return
					}
					fileArr := helper.Findfile(req.LogPath) //获取文件夹下所有文件的完整路径

					LogList := make([]UploadDevLogCloud, 0)
					for _, v := range fileArr {
						isExist := false
						file := ""
						for _, v1 := range data.Data.List {
							if strings.Contains(v, v1.FileName) {
								isExist = true
								file = v1.FileName
							}
						}
						if !isExist {
							filePathArr := strings.Split(v, "/")
							for i, devType := range filePathArr {
								if devType == "guns" || devType == "radar" || devType == "droneId" {
									req.Sn = filePathArr[i+1]
								}
							}
							logger.Info("Upload file sn is : ", req.Sn)
							LogList = append(LogList, UploadDevLogCloud{
								LogName: file,
								Sn:      req.Sn,
								LogPath: v[:strings.LastIndex(v, "/")+1],
							})
						}
					}
					UploadDevLog(LogList)
				}
			}
		}()
	}
	logger.Info("-->End Sync Local Log")
	rsp.Status = true
	return nil
}
func (e *DeviceCenter) SyncDeviceStatus(ctx context.Context, req *client.SyncDeviceStatusRequest, rsp *client.SyncDeviceStatusResponse) error {
	logger.Info("-->Into Sync Device Status")
	//获取数据库中日志同步状态
	logList := &client.LogStatusListRsp{}
	err := NewLogStatus().List(ctx, &client.LogStatusListReq{}, logList)
	if err != nil {
		logger.Error("Log Stat Insert err : ", err)
	}
	//获取设备列表
	equipList := GetEquipList()
	nameMap := make([]*client.DevicesInfo, 0)
	if equipList != nil && len(equipList) > 0 {
		for _, v := range equipList {
			var syncSwitch int32
			var temp bool
			if v.Sn == "" {
				continue
			}
			for _, value := range logList.StatusList {
				if value.Sn == v.Sn {
					syncSwitch = value.Status
					if syncSwitch == SWITCHCLOSE {
						temp = false
					} else {
						temp = true
					}
				}
			}
			nameMap = append(nameMap, &client.DevicesInfo{
				Id:         v.Id,
				Sn:         v.Sn,
				DeviceType: v.Etype,
				SyncSwitch: temp,
				IsOnline:   v.IsOnline,
				IsEnable:   v.IsEnable,
				Name:       v.Name,
			})
		}

	}
	rsp.List = nameMap
	logger.Info("-->End Sync Device Status")
	return nil
}
func (e *DeviceCenter) SyncCloudStatus(ctx context.Context, req *client.SyncCloudStatusRequest, rsp *client.SyncCloudStatusResponse) error {
	logger.Info("-->Into Sync Cloud Status")
	//获取数据库中日志同步状态
	logCloud := &client.LogCloudStatusListRsp{}
	err := NewLogCloudStatus().List(ctx, &client.LogCloudStatusListReq{}, logCloud)
	if err != nil {
		logger.Error("Log Stat Insert err : ", err)
	}
	var temp bool
	if logCloud.Status == SWITCHCLOSE {
		temp = false
	} else if logCloud.Status == SWITCHOPEN {
		temp = true
	}
	rsp.SyncSwitch = temp
	logger.Info("-->End Sync Cloud Status")

	return nil
}

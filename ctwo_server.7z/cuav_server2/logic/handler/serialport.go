package handler

import (
	"fmt"
	"net"
	"net/http"
	"strconv"
	"strings"
	"sync"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/proto/mavlink"
	"github.com/gorilla/websocket"
)

func init() {
	RegisterInspectReceiveBufCBs(InspectFpvVideo)
}

type InspectReceiveBufCBType func(cacheBuf []byte, pkgLen int)

var InspectReceiveBufCBs []InspectReceiveBufCBType

func RegisterInspectReceiveBufCBs(cb InspectReceiveBufCBType) {
	InspectReceiveBufCBs = append(InspectReceiveBufCBs, cb)
}

// ListenSerialData 监听前端传过来的串口数据
func ListenSerialData() {
	addr := net.JoinHostPort("0.0.0.0", strconv.Itoa(9966))
	mux := http.NewServeMux()
	mux.HandleFunc("/ws/serial/droneid", HandleSerialDroneIdData)
	srv := &http.Server{
		Addr:    addr,
		Handler: mux,
	}
	err := srv.ListenAndServe()
	if err != nil {
		logger.Error("device center ws server close: ", err)
		return
	}
}

// CheckTracerIsReset 判断链接是否是设备进行更新升级系统复位后建立的连接
func CheckTracerIsReset(conn *websocket.Conn, mailbox map[int]*WaitTaskManager) {
	addrPort := strings.Split(conn.RemoteAddr().String(), ":")
	addr := addrPort[0]
	d, ok := DevResetMap.Load(addr)
	logger.Info("CheckTracerIsReset: ", addr, ok)
	if ok {
		dev, t := d.(*Device)
		if !t {
			fmt.Println(t)
		}

		// 更新链接
		dev.Conn = &TracerSerialConn{Conn: conn}
		dev.WaitTaskMap = mailbox
		IsSerialMap = true
		cacheKey := fmt.Sprintf("%d_%s", dev.DevType, dev.Sn)
		logger.Infof("CheckTracerIsReset 从新缓存了设备： %v 连接", cacheKey)
		// 保存到DevStatusMap中
		DevStatusMap.Store(cacheKey, dev)
		DevResetMap.Delete(addr)
	}
	return
}

// HandleSerialDroneIdData 处理前端传过来的droneId串口数据
func HandleSerialDroneIdData(w http.ResponseWriter, r *http.Request) {
	upgrader := websocket.Upgrader{
		CheckOrigin: func(r *http.Request) bool { return true },
	}
	conn, err := upgrader.Upgrade(w, r, nil)
	if err != nil {
		logger.Error(err)
		return
	}
	logger.Debug("droneId serial data websocket connect from: ", r.RemoteAddr)
	logger.Debug("HandleSerialDroneIdData Start r.RemoteAddr: ", r.RemoteAddr)
	defer logger.Debug("HandleSerialDroneIdData end r.RemoteAddr: ", r.RemoteAddr)
	defer conn.Close()
	remoteAddr := strings.Split(conn.RemoteAddr().String(), ":")
	var mailBox map[int]*WaitTaskManager
	mbox, ok := GWaitTaskMap.Load(remoteAddr[0])
	if !ok {
		mailBox = make(map[int]*WaitTaskManager)
		GWaitTaskMap.Store(remoteAddr[0], mailBox)
	} else {
		mailBox = mbox.(map[int]*WaitTaskManager)
	}
	CheckTracerIsReset(conn, mailBox)
	// 处理数据
	cacheBuff := make([]byte, 0, 100*1000)
	packetLen := 0
	for {
		_, buff, err := conn.ReadMessage()
		if err != nil {
			logger.Error("HandleSerialDroneIdData ReadMessage Err:", err)
			return
		}
		logger.Debugf("receive message from[%v], receive data len: %v, : % x", len(buff), r.RemoteAddr, buff)
		n := len(buff)
		if n <= 0 {
			continue
		}
		if buff[mavlink.FrameLoc] == mavlink.FrameStart {
			packetLen = mavlink.GetPacketLen(buff[:])
		}
		//通过dataLen和n 处理接收长度小于1024 但是是拆包的情况。这里用队列会好些，不过队列的个数会有点多
		if packetLen > n && packetLen > len(cacheBuff)+n {
			cacheBuff = append(cacheBuff, buff[:]...)
			continue
		}
		cacheBuff = append(cacheBuff, buff[:]...)
		if cacheBuff[mavlink.FrameLoc] != mavlink.FrameStart {
			logger.Errorf("receive cache buf start flag not 0XFD, discard data len: %v, pkg len: %v", len(cacheBuff), packetLen)
			cacheBuff = make([]byte, 0, 100*1000)
			packetLen = 0
			continue
		}

		// 如果拆包后剩下mavlink前3位以内
		packetLen = mavlink.GetPacketLen(cacheBuff)
		//处理粘包、粘包+拆包
		for packetLen > 0 && len(cacheBuff) >= packetLen && cacheBuff[mavlink.FrameLoc] == mavlink.FrameStart {
			dev := GetTracerDevice(&TracerSerialConn{Conn: conn}, cacheBuff[:packetLen], mailBox)
			if dev != nil {
				IsSerialMap = true
				go dev.Deal()
			} else {
				for _, cb := range InspectReceiveBufCBs {
					if cb == nil {
						continue
					}
					cb(cacheBuff, packetLen)
				}
			}
			//logger.Debugf("处理buf: % x", cacheBuff[:packetLen])
			//logger.Debugf("剩余buf: % x", cacheBuff[packetLen:])
			cacheBuff = cacheBuff[packetLen:]
			if len(cacheBuff) > 0 {
				//再判断一次帧头，不符合直接抛弃
				if cacheBuff[mavlink.FrameLoc] != mavlink.FrameStart {
					cacheBuff = make([]byte, 0, 100*1000)
					packetLen = 0
					break
				}
				packetLen = mavlink.GetPacketLen(cacheBuff)
				if packetLen <= mavlink.HeaderLen+mavlink.CrcLen {
					packetLen = 0
					break
				}
			} else {
				packetLen = 0
			}
		}
	}
}

type TracerSerialConn struct {
	Conn *websocket.Conn
	mux  sync.RWMutex
}

func (c *TracerSerialConn) Read(p []byte) (n int, err error) {
	if c.Conn == nil {
		return 0, net.ErrClosed
	}
	_, buf, err := c.Conn.ReadMessage()
	if err != nil {
		return 0, err
	}
	copy(p, buf)
	return len(p), nil
}

func (c *TracerSerialConn) Write(p []byte) (n int, err error) {
	if c.Conn == nil {
		return 0, net.ErrClosed
	}
	//不加锁多协程写websocket会出错
	Mutex.Lock()
	err = c.Conn.WriteMessage(websocket.BinaryMessage, p)
	Mutex.Unlock()

	if err != nil {
		return 0, err
	}
	return len(p), nil
}

func (c *TracerSerialConn) Close() error {
	IsSerialMap = false
	if c.Conn == nil {
		return net.ErrClosed
	}
	// 有线连接时不主动关闭连接
	//err := c.Conn.Close()
	//if err != nil {
	//	return err
	//}
	return nil
}

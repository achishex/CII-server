package handler

import (
	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
	"adasgitlab.autel.com/tools/slink_proto/slinkv1"
	"bytes"
	"context"
	"crypto/rand"
	"encoding/binary"
	"encoding/csv"
	"errors"
	"fmt"
	"math/big"
	"os"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"
	"adasgitlab.autel.com/tools/cuav_server/repo/utils"

	"adasgitlab.autel.com/tools/cuav_plugin/broker"
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"github.com/360EntSecGroup-Skylar/excelize"
	"google.golang.org/protobuf/proto"

	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/server"
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/ip"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/proto/mavlink"
)

const (
	SflTcpPort        = 14000
	SflServerMaxCount = 500
	SflUpdateTime     = 60000 //60秒

	DetectFreqTion         = 1000
	ElevationTion          = 100
	GunDirectTion          = 100
	GunLongitudeTion       = 1e7
	GunLatitudeTion        = 1e7
	DroneHeightTion        = 10
	DroneYawTion           = 100
	DroneSpeedTion         = 100
	DroneVerticalSpeedTion = 100
	DroneHorizonTion       = 100
	DronePitch             = 100
	DroneTion              = 1e7
	DroneSailLongitudeTion = 1e7
	DroneSailLatitudeTion  = 1e7

	InvalidValueInt8   = 0xFF
	InvalidValueInt16  = 0x7FFF
	InvalidValueInt32  = 0x7FFFFFFF
	InvalidValueUInt16 = 0xFFFF
)

const (
	HITING  = 1
	HITOVER = 2
)

type Sfl struct {
	*Device
	dt common.DeviceType
}

var (
	SflTcpServerLock sync.Mutex
	SflTcpServerMap  sync.Map
	SflHeartSum      uint8
	SflDetectInfoMap = common.NewSflDetectInfoMap()
)

func NewSfl(conn Connection, d []byte, dataLen int, remoteIp string, remotePort int, localIp string, serverPort int,
	mailBox map[int]*WaitTaskManager) DeviceInterface {
	sfl := &Sfl{
		Device: &Device{
			Conn:        conn,
			Msg:         d,
			MsgLen:      dataLen,
			SourceId:    d[mavlink.SenderLoc],
			RemoteIp:    remoteIp,
			RemotePort:  remotePort,
			LocalIp:     localIp,
			ServerPort:  serverPort,
			WaitTaskMap: mailBox,
		},
	}
	return sfl
}
func (d *Sfl) Deal() {
	defer func() {
		if err := recover(); err != nil {
			logger.Error("Sfl deal 接收到panic:", err)
		}
	}()

	if d.MsgLen <= 0 {
		logger.Error("Sfl 数据为null,不作处理:", d.Device.RemoteIp)
		return
	}
	d.MsgId = int(d.Msg[mavlink.MsgIdLoc])
	switch d.MsgId {
	case mavlink.SflHeartMsg:
		d.Heart()
	case mavlink.SflDetectMsg:
		d.ReceiveSflDetectMsg()
	case mavlink.SflHitStatusMsg:
		d.ReceiveSflHitStatusMsg()
	case mavlink.SflGetVersion:
		d.ReceiveSflGetVersion()
	case mavlink.SFLGetGNSS:
		d.ReceiveSflGetGNNS()
	case mavlink.SFLSetGNSS:
		d.ReceiveSflSetGNNS()
	case mavlink.SflGetHitPith:
		d.ReceiveSflGetHitPith()
	case mavlink.SflGetHitAngle:
		d.ReceiveSflGetHitAngle()
	case mavlink.SflGetHitMode:
		d.ReceiveSflGetHitMode()
	case mavlink.SflReset:
		d.ReceiveSflReset()
	case mavlink.SflSendHitUav:
		d.ReceiveSflGetHitUav()

	case mavlink.SflSetOnOff:
		d.ReceiveSflSetOnOff()

	case mavlink.SflGetOnOff:
		d.ReceiveSflGetOnOff()
	case mavlink.SflSetPith:
		d.ReceiveSflSetPith()
	case mavlink.SflSetAngle:
		d.ReceiveSflSetAngle()
	case mavlink.SflStopHit:
		d.ReceiveSflStopHit()
	case mavlink.SflSetHitMode:
		d.ReceiveSflSetHitMode()
	case mavlink.SflSetAutoHitMode:
		d.ReceiveSflSetAutoHitMode()
	case mavlink.SflGetAutoHitMode:
		d.ReceiveSflGetAutoHitMode()
	case mavlink.SflIdUpgradeF1:
		d.ReceiveSflUpdateF1()
	case mavlink.SflIdUpgradeF2:
		d.ReceiveSflUpdateF2()
	case mavlink.SflIdUpgradeF3:
		d.ReceiveSflUpdateF3()
	case mavlink.SflHitTurn:
		d.ReceiveSflTurnHit()
	case mavlink.SflHorizontalTurn:
		d.ReceiveSflHorizontalTurn()
	case mavlink.SflVerticalTurn:
		d.ReceiveSflVerticalTurn()

	default:
		logger.Error("Sfl 未知Sfl消息id:", d.MsgId)
		break
	}
}

func SendSflHeart() {
	ticker := time.NewTicker(time.Second * 1)
	defer ticker.Stop()
	for range ticker.C {
		DevStatusMap.Range(func(key, value interface{}) bool {
			dev := value.(*Device)
			if dev.DevType == common.DEV_SFL && dev.Status == common.DevOnline {
				reqMode := &Sfl{
					Device: dev,
					dt:     common.DEV_SFL,
				}
				reqMode.SendExtHeartbeat()
			}
			return true
		})
	}
}
func (d *Sfl) SendExtHeartbeat() error {
	SflHeartSum++
	if SflHeartSum > 255 {
		SflHeartSum = 0
	}
	req := &mavlink.SflHeartbeatExtRequest{
		SflHeartSum,
	}
	reqBuff := req.CreateSflHeartbeatExt()
	if d != nil && d.Conn != nil {
		_, err := d.Conn.Write(reqBuff)
		logger.Infof("Sfl c2发送心跳结果：%X", reqBuff)
		if err != nil {
			dataInfo := &client.SflHeartInfo{
				Header: &client.EquipmentMessageBoxEntity{
					Name:      d.Sn,
					Sn:        d.Sn,
					EquipType: int32(common.DEV_SFL),
					MsgType:   mavlink.SflHeartMsgReport,
				},
				Data: &client.GimbalCounterHeartInfo{
					Sn:       d.Sn,
					IsOnline: common.DevOffline,
				},
			}
			msg, err := proto.Marshal(dataInfo)
			if err != nil {
				logger.Error("marshal dataInfo err:", err)
				return err
			}
			report := &client.ClientReport{
				MsgType: common.ClientMsgIDSFLHeartBeat,
				Data:    msg,
			}
			out, err := proto.Marshal(report)
			if err != nil {
				logger.Error("marshal report err:", err)
				return err
			}
			_ = mq.SflMsgBroker.Publish(mq.SflTopic, broker.NewMessage(out))
			logger.Info("sfl Offline report:", report)
		}
		return err
	}
	return nil
}

// SflOfflineReport SFL离线处理
func SflOfflineReport(sn string) {
	var tcpServer *server.TcpServer
	if s, ok := SflTcpServerMap.Load(sn); ok {
		tcpServer = s.(*server.TcpServer)

		if tcpServer != nil {
			tcpServer.Stop()
		}
		deviceUsedPorts.Delete(tcpServer.Port)
		SflTcpServerMap.Delete(sn)
		DevSnMap.Delete(tcpServer.Port)
		cachekeyDroneid := fmt.Sprintf("%d_%s", common.DEV_SFL, sn)
		DevStatusMap.Delete(cachekeyDroneid)
		SflDetectInfoMap.Clear()
		tcpServer = nil
	}
	dataInfo := &client.SflHeartInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      sn,
			Sn:        sn,
			EquipType: int32(common.DEV_SFL),
			MsgType:   mavlink.SflHeartMsgReport,
		},
		Data: &client.GimbalCounterHeartInfo{
			Sn:       sn,
			IsOnline: common.DevOffline,
		},
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgIDSFLHeartBeat,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.SflMsgBroker.Publish(mq.SflTopic, broker.NewMessage(out))
	logger.Info("sfl Offline report:", report)
}

func SflDetectDisappearEventReport(sn string) {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_SFL, sn)
	eventId := ""

	if cache, ok := DevDetectMapOnEvent.Load(cacheKey); ok {
		detect := cache.(*DetectEvent)
		eventId = utils.GetEventId(detect.SessionId)
		logger.Infof("eventId: %v, sessionId: %v", eventId, detect.SessionId)
	} else {
		logger.Infof("has not eventId for sfl detect disappear event report, sn: %v", sn)
	}
	DevDetectMapOnEvent.Delete(cacheKey)

	dataInfo := &client.SflDetectInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      sn,
			Sn:        sn,
			EquipType: int32(common.DEV_SFL),
			MsgType:   mavlink.SflEventDetectDisappear,
		},
		Data: &client.GimbalCounterDetectSocketInfo{
			Sn:      sn,
			EventId: eventId,
		},
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgSFlDetectEventData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Info("sfl detect disappear event report:", report)
}
func SflHitOverEventReport(hitNode *common.SflHitEventInfo) {
	var (
		eventID                         = ""
		hitSucc                         = false
		hitOver *common.SflHitEventInfo = nil
	)

	cacheKey := GetSflHitCacheKey(hitNode.UavSn, hitNode.DroneName, hitNode.ProductType)
	if cache, ok := SflHitOverMapOnEvent.Load(cacheKey); ok {
		hitOver, ok = cache.(*common.SflHitEventInfo)
		if !ok {
			return
		}

		eventID = utils.GetEventId(hitOver.SessionId)
		if time.Since(hitOver.DetectReportTime) > 3*time.Second {
			hitSucc = true //disappear at begin, or recently disappear
		}
	} else {
		return
	}
	SflHitOverMapOnEvent.Delete(cacheKey)

	dataInfo := &client.SflHitStateInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      hitNode.Sn,
			Sn:        hitNode.Sn, // sfl sn
			EquipType: int32(common.DEV_SFL),
		},
		Data: &client.GimbalCounterHitSocketInfo{
			SerialNum:      hitNode.UavSn,
			DroneName:      hitOver.DroneName,
			DroneLongitude: hitOver.DroneLongitude,
			DroneLatitude:  hitOver.DroneLatitude,
			DroneHeight:    hitOver.DroneHeight,
			DroneYawAngle:  hitOver.DroneYawAngle,
			EventId:        eventID,
		},
	}
	if hitSucc == false {
		dataInfo.Header.MsgType = mavlink.SflEventHitFail
	} else {
		dataInfo.Header.MsgType = mavlink.SflEventHitSucc
	}

	logger.Infof("sfl hit over report: %v", dataInfo)
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgSflHitEventData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Infof("sfl hit status: %v, event report: %v", hitSucc, report)
}

func SflOffLineEventReport(sn string) {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_SFL, sn)
	eventId := ""

	if cache, ok := DevStatusMapOnEvent.Load(cacheKey); ok {
		dev := cache.(*Device)
		eventId = utils.GetEventId(dev.SessionId)
	}
	DevStatusMapOnEvent.Delete(cacheKey)

	dataInfo := &client.SflHeartInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      sn,
			Sn:        sn,
			EquipType: int32(common.DEV_SFL),
			MsgType:   mavlink.SflEventMsgOffLine,
		},
		Data: &client.GimbalCounterHeartInfo{
			Sn:       sn,
			IsOnline: common.DevOffline,
			EventId:  eventId,
		},
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgSFlStatusEventData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Info("sfl Offline event report:", report)
}

// Heart 处理SFL心跳消息
func (d *Sfl) Heart() {
	heart := &mavlink.SflHeart{}
	if err := d.UnmarshalPayload(heart); err != nil {
		logger.Errorf(err.Error())
		return
	}

	devSn := ByteToString(heart.Info.Sn[:])
	if devSn != "" {
		// update device status
		d.updateOnLineStatus(devSn, heart)
		if isEnable := d.updateStatus(devSn); isEnable == common.DeviceDisenable {
			logger.Infof("Sfl device %v disable", devSn)
			return
		}
		// report heartbeat
		d.HeartReport(devSn, heart)
	}
}
func (d *Sfl) HeartReport(devSn string, heartInfo *mavlink.SflHeart) {

	dataInfo := &client.SflHeartInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      devSn,
			Sn:        devSn,
			EquipType: int32(common.DEV_SFL),
			MsgType:   mavlink.SflHeartMsgReport,
		},
		Data: &client.GimbalCounterHeartInfo{
			Sn:              devSn,
			TimeStamp:       int32(heartInfo.Info.TimeStamp),
			WorkStatus:      int32(heartInfo.Info.WorkStatus),
			IsOnline:        common.DevOnline,
			HitFreq:         int32(heartInfo.Info.HitFreq),
			DetectFreq:      float64(heartInfo.Info.DetectFreq) / DetectFreqTion,
			Elevation:       float64(heartInfo.Info.Elevation) / ElevationTion,
			GunDirection:    float64(heartInfo.Info.GunDirection) / GunDirectTion,
			GunLongitude:    float64(heartInfo.Info.GunLongitude) / GunLongitudeTion,
			GunLatitude:     float64(heartInfo.Info.GunLatitude) / GunLatitudeTion,
			GunAltitude:     float64(heartInfo.Info.GunAltitude),
			SatellitesNum:   int32(heartInfo.Info.SatellitesNum),
			FaultLevel:      int32(heartInfo.Info.FaultLevel),
			CtrlFault:       int32(heartInfo.Info.CtrlFault),
			AeagFault:       int32(heartInfo.Info.AeagFault),
			TracerFault:     int32(heartInfo.Info.TracerFault),
			WorkStatusParam: int32(heartInfo.Info.WorkStatusParam),
		},
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgIDSFLHeartBeat,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.SflMsgBroker.Publish(mq.SflTopic, broker.NewMessage(out))

	logger.Infof("Sfl heartbeat has reported, devSn: %v,report:%v", devSn, dataInfo.Data)
}

var GlobalSessionId int64 = time.Now().UnixMilli()

func GetGlobalSessionId() int64 {
	return atomic.AddInt64(&GlobalSessionId, 1)
}

func (d *Sfl) updateOnLineStatus(sn string, heartInfo *mavlink.SflHeart) int32 {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_SFL, sn)
	if cache, ok := DevStatusMapOnEvent.Load(cacheKey); ok {
		dev := cache.(*Device)
		if dev.IsEnable == common.DeviceDisenable {
			return common.DeviceDisenable
		}
		dev.Status = common.DevOnline
		dev.LastHeartTime = time.Now()
		dev.GetStatusInterval = time.Now()
		return dev.IsEnable
	}

	dev := &Device{
		Sn:                sn,
		Status:            common.DevOnline,
		RemoteIp:          d.RemoteIp,
		RemotePort:        d.RemotePort,
		LocalIp:           d.LocalIp,
		ServerPort:        d.ServerPort,
		DevType:           common.DEV_SFL,
		FirstHeartTime:    time.Now(),
		LastHeartTime:     time.Now(),
		SourceId:          d.SourceId,
		IsEnable:          d.GetStatus(sn),
		GetStatusInterval: time.Now(),
		SessionId:         GetGlobalSessionId(),
	}
	DevStatusMapOnEvent.Store(cacheKey, dev)
	//SendNotify

	go func() {
		dataInfo := &client.SflHeartInfo{
			Header: &client.EquipmentMessageBoxEntity{
				Name:      sn,
				Sn:        sn,
				EquipType: int32(common.DEV_SFL),
				MsgType:   mavlink.SflEventMsgOnline,
			},
			Data: &client.GimbalCounterHeartInfo{
				Sn:           sn,
				EventId:      utils.GetEventId(dev.SessionId),
				GunLatitude:  float64(heartInfo.Info.GunLatitude) / GunLatitudeTion,
				GunLongitude: float64(heartInfo.Info.GunLongitude) / GunLongitudeTion,
			},
		}
		msg, err := proto.Marshal(dataInfo)
		if err != nil {
			logger.Error("marshal dataInfo err:", err)
			return
		}

		report := &client.ClientReport{
			MsgType: common.ClientMsgSFlStatusEventData,
			Data:    msg,
		}
		out, err := proto.Marshal(report)
		if err != nil {
			logger.Error("marshal report err:", err)
			return
		}

		_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
		logger.Infof("Sfl heartbeat event has reported, devSn: %v,report:%v", sn, dataInfo.Data)
	}()
	return dev.IsEnable

}
func (d *Sfl) updateStatus(sn string) int32 {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_SFL, sn)
	if cache, ok := DevStatusMap.Load(cacheKey); ok {
		dev := cache.(*Device)
		if dev.IsEnable == common.DeviceDisenable {
			return common.DeviceDisenable
		}
		dev.Status = common.DevOnline
		dev.Conn = d.Conn
		dev.WaitTaskMap = d.WaitTaskMap
		dev.RemoteIp = d.RemoteIp
		dev.LastHeartTime = time.Now()
		dev.GetStatusInterval = time.Now()
		if dev.IsEnable != common.DeviceDisenable && dev.IsEnable != common.DeviceEnable {
			dev.IsEnable = d.GetStatus(sn)
		}
		return dev.IsEnable
	} else {
		dev := &Device{
			Sn:                sn,
			Conn:              d.Conn,
			Status:            common.DevOnline,
			RemoteIp:          d.RemoteIp,
			RemotePort:        d.RemotePort,
			LocalIp:           d.LocalIp,
			ServerPort:        d.ServerPort,
			DevType:           common.DEV_SFL,
			FirstHeartTime:    time.Now(),
			LastHeartTime:     time.Now(),
			SourceId:          d.SourceId,
			IsEnable:          d.GetStatus(sn),
			GetStatusInterval: time.Now(),
			WaitTaskMap:       d.WaitTaskMap,
		}
		DevStatusMap.Store(cacheKey, dev)
		go func() {
			time.Sleep(time.Second * 2)
			//发送白名单给Sfl设备
			go SendDevWhiteListToSfl()
			if d.Conn == nil {
				return
			}
			appVer, err := d.SendGetVersionInfo()
			logger.Infof("sfl get  Ver: %v", appVer)
			if err != nil {
				logger.Infof("sfl get  Ver runVer: %v err: %v \n", appVer, err)
				return
			}
			if appVer != "" {
				err = NewEquipList().Update(context.Background(), &client.EquipCrudReq{
					Sn:         sn,
					DevVersion: appVer,
				}, &client.EquipCrudRes{})
				if err != nil {
					logger.Error("Update EquipList err: ", err)
				}
			}
		}()
		return dev.IsEnable
	}
}
func (d *Sfl) UnmarshalPayload(data *mavlink.SflHeart) error {
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("Sfl UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("Sfl UnmarshalPayload read data err: %v", err)
	}

	return nil
}

// HandleBroadCast 处理广播消息
func (d *Sfl) HandleBroadCast(ctx context.Context, req *slinkv1.UdpBroadcastConfirmRequest) (*slinkv1.UdpBroadcastConfirmResponse, error) {
	if req.GetSn() == "" {
		logger.Info("device sn empty")
		return nil, nil
	}

	if status := d.GetStatus(req.GetSn()); status == common.DeviceDisenable {
		logger.Infof("device %v disable", req.GetSn())
		return nil, nil
	}

	localIP := make([]string, 0)
	localIps, broadIps, err := ip.GetBroadcastAddress()
	if err != nil {
		logger.Error("Get IP error :%v", err)
	}
	for i, ip := range localIps {
		if i >= len(broadIps) {
			continue
		}
		localIP = append(localIP, ip)
	}
	logger.Debugf("[Sfl] localIP:%v,", localIP)

	tcpServer := d.TcpServerCheck(req.GetSn(), localIP)
	DevSnMap.Store(tcpServer.Port, req.GetSn())
	d.ServerPort = tcpServer.Port

	//响应
	rsp := &slinkv1.UdpBroadcastConfirmResponse{
		Sn:       req.Sn,
		Addr:     ip.IPV4(tcpServer.Ip),
		Port:     uint16(tcpServer.Port),
		ConnType: 1,
	}
	return rsp, nil
}

func (d *Sfl) ReceiveGetChannelReq() {
	SflTcpServerLock.Lock()
	defer SflTcpServerLock.Unlock()

	devSn := d.UnMarshalGetChannelReq()
	if devSn == "" {
		logger.Info("Sfl device sn empty")
		return
	}

	//if isContinue := d.deviceDiscover(devSn); !isContinue {
	//	logger.Error("droneID等待设备确认：", devSn)
	//	return
	//}

	if status := d.GetStatus(devSn); status == common.DeviceDisenable {
		logger.Infof("Sfl device %v disable", devSn)
		return
	}

	localIP := make([]string, 0)

	localIps, broadIps, err := ip.GetBroadcastAddress()
	if err != nil {
		logger.Error("Sfl Get IP error :%v", err)
	}
	for i, ip := range localIps {
		if i >= len(broadIps) {
			continue
		}
		localIP = append(localIP, ip)
	}
	logger.Debugf("[Sfl] localIP:%v,", localIP)

	tcpServer := d.TcpServerCheck(devSn, localIP)
	DevSnMap.Store(tcpServer.Port, devSn)
	d.ServerPort = tcpServer.Port

	//响应
	switch d.MsgId {
	case mavlink.SflUdpBroadcastResponse:
		logger.Info("[Sfl] receive Broadcast BB Msg")
		UdpBroadcastSendChannel(devSn, d.UdpIp, d.SourceId, tcpServer)
		break
	default:
		break
	}

	return
}

func (d *Sfl) TcpServerCheck(devSn string, localIP []string) *server.TcpServer {
	var tcpServer *server.TcpServer
	if s, ok := SflTcpServerMap.Load(devSn); ok {
		tcpServer = s.(*server.TcpServer)
		isAlike := false
		for _, ip := range localIP {
			if ip == tcpServer.Ip {
				isAlike = true
			}
		}
		if isAlike == false { //查找的本地IP没有与之前相同的
			if tcpServer != nil {
				tcpServer.Stop()
			}
			deviceUsedPorts.Delete(tcpServer.Port)
			SflTcpServerMap.Delete(devSn)
			DevSnMap.Delete(tcpServer.Port)
			tcpServer = nil
		}
	}

	//注册tcp服务
	if tcpServer == nil {
		port, err := ip.GetFreeTcpPort()
		if err != nil {
			logger.Error("Sfl tcp 获取可用端口失败：", err)
			port = d.getRandPort(SflTcpPort, SflTcpPort+SflServerMaxCount)
		}
		tcpServer = server.NewTcpServer(port, Handle)
		SflTcpServerMap.Store(devSn, tcpServer)
		tcpServer.ServerType = uint8(common.DEV_SFL)
		tcpServer.ServerName = devSn
		localAddr, _ := ip.GetLocalIp(d.UdpIp)
		tcpServer.Ip = localAddr
		go tcpServer.Start()
	}
	return tcpServer
}

func (d *Sfl) getRandPort(min, max int64) int {
	maxBigInt := big.NewInt(max)
	i, _ := rand.Int(rand.Reader, maxBigInt)
	_, ok := deviceUsedPorts.Load(i.Int64())
	port := i.Int64()
	//缓存不存在或者符合范围
	if !ok && (port > min && port < max) {
		deviceUsedPorts.Store(port, port)
		return int(port)
	}
	return d.getRandPort(min, max)
}
func (d *Sfl) GetStatus(sn string) int32 {
	statusRes := &client.GetStatusRes{}
	err := NewEquipList().GetStatus(context.Background(), &client.GetStatusReq{Sn: sn, EType: "Sfl"}, statusRes)
	if err != nil {
		logger.Errorf("GetStatus err: %v", err.Error())
		return 0
	}

	return statusRes.IsEnable
}

func (d *Sfl) UnMarshalGetChannelReq() string {
	devSn := ""
	switch d.MsgId {
	case mavlink.SflUdpBroadcastResponse:
		req := &mavlink.UdpBroadcastConfirmRequest{}
		d.GetPacket(req)
		devSn = strings.TrimRight(string(req.Sn[:]), string(rune(0)))
		break
	default:
		break
	}
	return devSn
}

func (d *Sfl) GetPacket(message mavlink.Message) *mavlink.MavPacket {
	logger.Infof("Sfl GetPacket is [% x]", d.Msg)
	req := mavlink.NewNullPacket(message)
	buff := &bytes.Buffer{}
	if err := binary.Write(buff, binary.LittleEndian, d.Msg); err != nil {
		logger.Error("Sfl GetPacket write buff err:", err)
		return nil

	}
	if err := binary.Read(buff, binary.LittleEndian, &req.Header); err != nil {
		logger.Error("Sfl GetPacket read header err:", err)
		return nil
	}
	if err := binary.Read(buff, binary.LittleEndian, req.Msg); err != nil {
		logger.Error("Sfl GetPacket read msg err:", err)
		return nil
	}
	return req
}

func (d *Sfl) ReceiveSflDetectMsg() {
	result := &mavlink.SflDetect{}
	if err := d.UnmarshalPayloadSflDetect(result); err != nil {
		logger.Errorf(err.Error())
		return
	}

	devSn := ByteToString(result.Info.SN[:])
	if devSn != "" {
		if isEnable := d.updateStatus(devSn); isEnable == common.DeviceDisenable {
			logger.Infof("Sfl device %v disable", devSn)
			return
		}
		d.SflDetectReport(devSn, result)
	}
	logger.Info("--->End Receive Sfl Detect")
}
func (d *Sfl) SflDetectAppearEvent(sn string, detectInfo *client.GimbalCounterDetectSocketInfo) {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_SFL, sn)
	if cache, ok := DevDetectMapOnEvent.Load(cacheKey); ok {
		detect := cache.(*DetectEvent)
		detect.LastReceiveTime = time.Now()
		return
	}

	if len(detectInfo.GetList()) <= 0 {
		logger.Infof("has not detect any uav")
		return
	}

	detect := &DetectEvent{
		Sn:              sn,
		LastReceiveTime: time.Now(),
		DevType:         common.DEV_SFL,
		SessionId:       GetGlobalSessionId(),
	}
	DevDetectMapOnEvent.Store(cacheKey, detect)
	detectInfo.EventId = utils.GetEventId(detect.SessionId)

	go func() {
		msg := &client.SflDetectInfo{
			Header: &client.EquipmentMessageBoxEntity{
				Name:      sn,
				Sn:        sn,
				EquipType: int32(common.DEV_SFL),
				MsgType:   mavlink.SflEventDetectAppear,
			},
			Data: detectInfo,
		}
		msgOut, err := proto.Marshal(msg)
		if err != nil {
			logger.Error("marshal msg err:", err)
			return
		}
		report := &client.ClientReport{
			MsgType: common.ClientMsgSFlDetectEventData,
			Data:    msgOut,
		}
		out, err := proto.Marshal(report)
		if err != nil {
			logger.Error("marshal dataInfo err:", err)
			return
		}

		_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
		logger.Infof("Sfl detect uav event has reported, devSn: %v,report:%v", sn, detectInfo.GetList())
	}()

}
func calcHitOverStatus(droneHeight int16, droneDistance uint16) bool {
	if droneHeight < 10 {
		return true
	}
	if droneHeight >= 10 && droneDistance > 200 {
		return true
	}
	return false
}

// SflHitOverCheckEventReport 打击无人机时，无人机位置变动满足打击成功，上报打击成功事件。
func (d *Sfl) SflHitOverCheckEventReport(uav *mavlink.SflDetectDescription, devSn string) {
	if uav == nil {
		return
	}

	uavSn := ByteToString(uav.SerialNum[:])
	cacheKey := GetSflHitCacheKey(uavSn, ByteToString(uav.DroneName[:]), int32(uav.ProductType))
	cache, ok := SflHitOverMapOnEvent.Load(cacheKey)
	if !ok || cache == nil {
		return
	}
	hitOverNode, ok := cache.(*common.SflHitEventInfo)
	if !ok {
		return
	}

	hitSucc := calcHitOverStatus(uav.DroneHeight, uav.UDistance)
	if !hitSucc {
		//如果不满足打击成功，则继续记录无人机上报信息。
		hitOverNode.DetectReportTime = time.Now()
		//
		hitOverNode.DroneName = ByteToString(uav.DroneName[:])
		hitOverNode.DroneLongitude = float64(uav.DroneLongitude) / DroneTion
		hitOverNode.DroneLatitude = float64(uav.DroneLatitude) / DroneTion
		hitOverNode.DroneHeight = float64(uav.DroneHeight) / DroneHeightTion
		hitOverNode.DroneYawAngle = float64(uav.DroneYawAngle) / DroneYawTion
		//
		SflHitOverMapOnEvent.Store(cacheKey, hitOverNode)
		logger.Infof("hit fail, uav: %v", cacheKey)
		return
	}

	// 打击满足成功，则上报打击成功事件
	eventId := utils.GetEventId(hitOverNode.SessionId)
	logger.Infof("hit succ, uav: %v, sn: %v", cacheKey, devSn)
	SflHitOverMapOnEvent.Delete(cacheKey)

	dataInfo := &client.SflHitStateInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      devSn,
			Sn:        devSn,
			EquipType: int32(common.DEV_SFL),
			MsgType:   mavlink.SflEventHitSucc,
		},
		Data: &client.GimbalCounterHitSocketInfo{
			SerialNum:      uavSn,
			DroneName:      ByteToString(uav.DroneName[:]),
			DroneLongitude: float64(uav.DroneLongitude) / DroneTion,
			DroneLatitude:  float64(uav.DroneLatitude) / DroneTion,
			DroneHeight:    float64(uav.DroneHeight) / DroneHeightTion,
			DroneYawAngle:  float64(uav.DroneYawAngle) / DroneYawTion,
			EventId:        eventId,
		},
	}
	logger.Infof("sfl hit succ report event: %v", dataInfo)

	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgSflHitEventData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Info("sfl hit succ event report:", report)
}

func (d *Sfl) SflDetectReport(devSn string, detectInfo *mavlink.SflDetect) {
	dataInfo := &client.GimbalCounterDetectSocketInfo{}
	dataInfo.List = make([]*client.GimbalCounterDetectDroneInfo, 0, len(detectInfo.Description))
	dataInfo.Sn = devSn
	dataInfo.DetectionNum = int32(detectInfo.Info.DetectionNum)
	//查白名单中的无人机，在Tracer侦测结果中添加无人机角色
	whiteList := &client.ListResAll{}
	err := NewWhiteList().ListAll(context.Background(), &client.ListReqAll{}, whiteList)
	if err != nil {
		logger.Error("Get whiteList err: ", err)
		return
	}

	var dstDetectItems []*client.GimbalCounterDetectDroneInfo
	//检查无效值
	for _, drone := range detectInfo.Description {
		if drone.Source == 0 {
			drone = DetectCheckInputNum(drone)
			//1-敌军 2-友军 3-未知 4-中立     批量导入为2友军
			var role int32
			for _, info := range whiteList.WhiteList {
				if info.Sn == ByteToString(drone.SerialNum[:]) {
					role = info.Role
				}
			}
			if role == ERRTYPE {
				role = ENEMY
			}
			r := &client.GimbalCounterDetectDroneInfo{
				ProductType:        int32(drone.ProductType),
				DroneName:          ByteToString(drone.DroneName[:]),
				SerialNum:          ByteToString(drone.SerialNum[:]),
				DroneLongitude:     float64(drone.DroneLongitude) / DroneTion,
				DroneLatitude:      float64(drone.DroneLatitude) / DroneTion,
				DroneHeight:        float64(drone.DroneHeight) / DroneHeightTion,
				DroneYawAngle:      float64(drone.DroneYawAngle) / DroneYawTion,
				DroneSpeed:         float64(drone.DroneSpeed) / DroneSpeedTion,
				DroneVerticalSpeed: float64(drone.DroneVerticalSpeed) / DroneVerticalSpeedTion,
				SpeedDirection:     int32(drone.SpeedDerection) / DroneSpeedTion,
				DroneSailLongitude: float64(drone.DroneSailLongitude) / DroneSailLongitudeTion,
				DroneSailLatitude:  float64(drone.DroneSailLatitude) / DroneSailLatitudeTion,
				PilotLongitude:     float64(drone.PilotLongitude) / DroneTion,
				PilotLatitude:      float64(drone.PilotLatitude) / DroneTion,
				DroneHorizon:       float64(drone.DroneHorizon) / DroneHorizonTion,
				DronePitch:         float64(drone.DronePitch) / DronePitch,
				UFreq:              float64(drone.UFreq) / DetectFreqTion,
				UDistance:          int32(drone.UDistance),
				UDangerLevels:      int32(drone.UDangerLevels),
				Role:               role,
				UZC:                int32(drone.Uzc),
			}
			logger.Infof("Sfl Detect data: %v", r)
			dataInfo.List = append(dataInfo.List, r)
			//记录探测信息
			RecordSflInfo(r)

			d.SflHitOverCheckEventReport(drone, devSn)
			dstDetectItems = append(dstDetectItems, r)
		}
	}
	// 处理打击后无人机消失时上报打击成功事件
	d.SflHitOverUavDisappearProc(dstDetectItems, devSn)

	msg := &client.SflDetectInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      devSn,
			Sn:        devSn,
			EquipType: int32(common.DEV_SFL),
			MsgType:   mavlink.SflDetectMsgReport,
		},
		Data: dataInfo,
	}
	msgOut, err := proto.Marshal(msg)
	if err != nil {
		logger.Error("marshal msg err:", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIDSFLDetect,
		Data:    msgOut,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	_ = mq.SflMsgBroker.Publish(mq.SflTopic, broker.NewMessage(out))
	d.SflDetectAppearEvent(devSn, dataInfo)
	logger.Infof("Sfl Detect has reported, devSn: %v, Drone size: %v", devSn, msg.Data)
}

// SflHitOverUavDisappearProc 打击无人机后，无人机消失时 上报打击成功事件。
func (d *Sfl) SflHitOverUavDisappearProc(uavs []*client.GimbalCounterDetectDroneInfo, devSn string) {
	var disappearHitNode []*common.SflHitEventInfo

	SflHitOverMapOnEvent.Range(func(key, value interface{}) bool {
		hitNode := value.(*common.SflHitEventInfo)
		existNode := false

		for _, uav := range uavs {
			if uav == nil {
				continue
			}
			//
			if uav.ProductType == hitNode.ProductType &&
				uav.DroneName == hitNode.DroneName &&
				uav.SerialNum == hitNode.UavSn {
				existNode = true
			}
		}

		if !existNode {
			disappearHitNode = append(disappearHitNode, hitNode)
			logger.Infof("history hit node disappear, ProductType: %v, uavSn: %v, uavName: %v",
				hitNode.ProductType, hitNode.UavSn, hitNode.DroneName)
		}
		return true
	})

	for _, hitNode := range disappearHitNode {
		if hitNode == nil {
			continue
		}
		//
		eventId := utils.GetEventId(hitNode.SessionId)
		cacheKey := GetSflHitCacheKey(hitNode.UavSn, hitNode.DroneName, hitNode.ProductType)
		SflHitOverMapOnEvent.Delete(cacheKey)
		//

		dataInfo := &client.SflHitStateInfo{
			Header: &client.EquipmentMessageBoxEntity{
				Name:      devSn,
				Sn:        devSn,
				EquipType: int32(common.DEV_SFL),
				MsgType:   mavlink.SflEventHitSucc,
			},
			Data: &client.GimbalCounterHitSocketInfo{
				SerialNum:      hitNode.UavSn,
				DroneName:      hitNode.DroneName,
				DroneLongitude: hitNode.DroneLongitude,
				DroneLatitude:  hitNode.DroneLatitude,
				DroneHeight:    hitNode.DroneHeight,
				DroneYawAngle:  hitNode.DroneYawAngle,
				EventId:        eventId,
			},
		}
		logger.Infof("sfl hit succ report event: %v", dataInfo)

		msg, err := proto.Marshal(dataInfo)
		if err != nil {
			logger.Error("marshal dataInfo err:", err)
			return
		}

		report := &client.ClientReport{
			MsgType: common.ClientMsgSflHitEventData,
			Data:    msg,
		}
		out, err := proto.Marshal(report)
		if err != nil {
			logger.Error("marshal report err:", err)
			return
		}

		_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
		logger.Info("sfl hit succ event report:", report)
	}
}
func RecordSflInfo(r *client.GimbalCounterDetectDroneInfo) {
	_, isExist := SflDetectInfoMap.Get(r.SerialNum)
	tempTime := time.Now().UnixMilli()
	if !isExist { //不存在添加
		logger.Info("Sfl add drone event,", r.SerialNum)
		piltlong := strconv.FormatFloat(r.PilotLongitude, 'f', 4, 64)
		piltlat := strconv.FormatFloat(r.PilotLatitude, 'f', 4, 64)
		SflDetectInfoMap.Set(r.SerialNum, r.DroneName, tempTime, 0, 0, r.UFreq,
			int64(r.DroneYawAngle), piltlong+","+piltlat, tempTime)
		//写数据库
		err := NewSflDetectInfo().Insert(context.Background(), &client.SflDetectInfoInsertReq{
			Sn:           r.SerialNum,
			Vendor:       r.DroneName,
			DetectTime:   tempTime,
			HitTime:      0,
			CounterTime:  0,
			Freq:         float32(r.UFreq),
			Direction:    int64(r.DroneHorizon),
			PilotLongLat: piltlong + " , " + piltlat,
			DroneHeight:  r.DroneHeight,
		}, &client.SflDetectInfoInsertRes{})
		if err != nil {
			logger.Error("Sfl Detect Info Insert err:", err)
		}
	}
}

func (d *Sfl) UnmarshalPayloadSflDetect(data *mavlink.SflDetect) error {
	deviceInfoLen := binary.Size(mavlink.SflDetectInfo{})
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}

	start := mavlink.HeaderLen + deviceInfoLen
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializeDrone(d.Msg[start:end]); err != nil {
		return err
	}

	return nil
}

func (d *Sfl) ReceiveSflHitStatusMsg() {
	hit := &mavlink.SflHit{}
	if err := d.UnmarshalPayloadHitInfo(hit); err != nil {
		logger.Errorf(err.Error())
		return
	}

	devSn := ByteToString(hit.Info.SN[:])
	if devSn != "" {
		// report Hit
		if isEnable := d.updateStatus(devSn); isEnable == common.DeviceDisenable {
			logger.Infof("Sfl device %v disable", devSn)
			return
		}
		d.HitInfoReport(devSn, hit)
	}
	logger.Info("--->End Receive Sfl HitStat")
}

func (d *Sfl) UnmarshalPayloadHitInfo(data *mavlink.SflHit) error {
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("Sfl UnmarshalPayloadHitInfo write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("Sfl UnmarshalPayloadHitInfo read data err: %v", err)
	}

	return nil
}

func (d *Sfl) HitInfoReport(devSn string, hitInfo *mavlink.SflHit) {
	//查白名单中的无人机，在Tracer侦测结果中添加无人机角色
	whiteList := &client.ListResAll{}
	err := NewWhiteList().ListAll(context.Background(), &client.ListReqAll{}, whiteList)
	if err != nil {
		logger.Error("Get whiteList err: ", err)
		return
	}
	//1-敌军 2-友军 3-未知 4-中立     批量导入为2友军
	var role int32
	for _, info := range whiteList.WhiteList {
		if info.Sn == ByteToString(hitInfo.Info.SerialNum[:]) {
			role = info.Role
		}
	}
	if role == ERRTYPE {
		role = ENEMY
	}

	//检查无效值
	hitInfo = CheckInputNum(hitInfo)

	dataInfo := &client.SflHitStateInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      devSn,
			Sn:        devSn,
			EquipType: int32(common.DEV_SFL),
			MsgType:   mavlink.SflHitStatusMsgReport,
		},
		Data: &client.GimbalCounterHitSocketInfo{
			Sn:                 devSn,
			HitState:           int32(hitInfo.Info.HitState),
			ProductType:        int32(hitInfo.Info.ProductType),
			DroneName:          ByteToString(hitInfo.Info.DroneName[:]),
			SerialNum:          ByteToString(hitInfo.Info.SerialNum[:]),
			DroneLongitude:     float64(hitInfo.Info.DroneLongitude) / DroneTion,
			DroneLatitude:      float64(hitInfo.Info.DroneLatitude) / DroneTion,
			DroneHeight:        float64(hitInfo.Info.DroneHeight) / DroneHeightTion,
			DroneYawAngle:      float64(hitInfo.Info.DroneYawAngle) / DroneYawTion,
			DroneSpeed:         float64(hitInfo.Info.DroneSpeed) / DroneSpeedTion,
			DroneVerticalSpeed: float64(hitInfo.Info.DroneVerticalSpeed) / DroneVerticalSpeedTion,
			SpeedDirection:     int32(hitInfo.Info.SpeedDerection) / DroneSpeedTion,
			DroneSailLongitude: float64(hitInfo.Info.DroneSailLongitude) / DroneSailLongitudeTion,
			DroneSailLatitude:  float64(hitInfo.Info.DroneSailLatitude) / DroneSailLatitudeTion,
			PilotLongitude:     float64(hitInfo.Info.PilotLongitude) / DroneTion,
			PilotLatitude:      float64(hitInfo.Info.PilotLatitude) / DroneTion,
			DroneHorizon:       float64(hitInfo.Info.DroneHorizon) / DroneHorizonTion,
			DronePitch:         float64(hitInfo.Info.DronePitch) / DronePitch,
			UFreq:              float64(hitInfo.Info.UFreq) / DetectFreqTion,
			UDistance:          int32(hitInfo.Info.UDistance),
			UDangerLevels:      int32(hitInfo.Info.UDangerLevels),
			Role:               role,
		},
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIDSFLHitStatus,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}
	_ = mq.SflMsgBroker.Publish(mq.SflTopic, broker.NewMessage(out))
	logger.Infof("Sfl HitInfo has reported, devSn: %v report:%v", devSn, report)

	//统计打击时间、打击时长
	uavNode := RecordSlfHitStatus(dataInfo.Data)
	if uavNode != nil {
		hitCacheKey := GetSflHitCacheKey(uavNode.UavSn, uavNode.DroneName, uavNode.ProductType)
		SflHitOverMapOnEvent.Store(hitCacheKey, uavNode)
	}
}

func GetSflHitCacheKey(serialNum string, droneName string, productType int32) string {
	hitCacheKey := fmt.Sprintf("%d_%d_%s_%s", common.DEV_SFL, productType, serialNum, droneName)
	logger.Infof("sfl hit cache key: %v", hitCacheKey)

	return hitCacheKey
}

func RecordSlfHitStatus(report *client.GimbalCounterHitSocketInfo) *common.SflHitEventInfo {
	var observeHitOverUav *common.SflHitEventInfo = nil

	droneInfo, isExist := SflDetectInfoMap.Get(report.SerialNum)
	tempTime := time.Now().UnixMilli()
	if isExist && (report.HitState == HITING || report.HitState == HITOVER) {
		if report.HitState == HITING && droneInfo.HitTime == 0 { //更新打击时间
			SflDetectInfoMap.UpdateHitTime(report.SerialNum, tempTime)
			//更新数据库
			err := NewSflDetectInfo().UpdateHitTime(context.Background(), &client.SflDetectInfoUpdateReq{Sn: report.SerialNum, HitTime: tempTime}, &client.SflDetectInfoUpdateRes{})
			if err != nil {
				logger.Error("Update Sfl Detect Info err:", err)
			}
		}
		if report.HitState == HITOVER {
			//更新数据库
			counterDur := (tempTime - droneInfo.HitTime) / 1000
			err := NewSflDetectInfo().UpdateCountTime(context.Background(), &client.SflDetectInfoUpdateReq{Sn: report.SerialNum, CounterTime: counterDur}, &client.SflDetectInfoUpdateRes{})
			if err != nil {
				logger.Error("Update Sfl Detect Info hit over err:", err)
			}

			// 判断10s内无人机的状态信息
			nowTime := time.Now()
			droneInfo.CounterTime = counterDur
			observeHitOverUav = &common.SflHitEventInfo{
				UavSn:            report.SerialNum,
				Sn:               report.Sn,
				HitOverTime:      nowTime,
				DetectReportTime: nowTime,
				ProductType:      report.ProductType,
				SessionId:        GetGlobalSessionId(),
				DroneName:        report.DroneName,
				DroneLongitude:   report.DroneLongitude,
				DroneLatitude:    report.DroneLatitude,
				DroneHeight:      report.DroneHeight,
				DroneYawAngle:    report.DroneYawAngle,
			}
			logger.Infof("sfl hit over, sfl sn: %v, uav serialNum: %v, productType: %v, droneName: %v",
				report.Sn, report.SerialNum, report.ProductType, report.DroneName)

			//清空map
			SflDetectInfoMap.Clear()
		}
	}

	return observeHitOverUav
}

func CheckInputNum(info *mavlink.SflHit) *mavlink.SflHit {
	if info.Info.DroneLongitude == InvalidValueInt32 {
		info.Info.DroneLongitude = 0
	}
	if info.Info.DroneLatitude == InvalidValueInt32 {
		info.Info.DroneLatitude = 0
	}
	if info.Info.DroneHeight == InvalidValueInt16 {
		info.Info.DroneHeight = 0
	}
	if info.Info.DroneYawAngle == InvalidValueInt16 {
		info.Info.DroneYawAngle = 0
	}
	if info.Info.DroneSpeed == InvalidValueInt16 {
		info.Info.DroneSpeed = 0
	}
	if info.Info.DroneVerticalSpeed == InvalidValueInt16 {
		info.Info.DroneVerticalSpeed = 0
	}
	if info.Info.DroneSailLongitude == InvalidValueInt32 {
		info.Info.DroneSailLongitude = 0
	}
	if info.Info.DroneSailLatitude == InvalidValueInt32 {
		info.Info.DroneSailLatitude = 0
	}
	if info.Info.PilotLongitude == InvalidValueInt32 {
		info.Info.PilotLongitude = 0
	}
	if info.Info.PilotLatitude == InvalidValueInt32 {
		info.Info.PilotLatitude = 0
	}
	if info.Info.DroneHorizon == InvalidValueInt32 {
		info.Info.DroneHorizon = -1
	}
	if info.Info.DronePitch == InvalidValueInt32 {
		info.Info.DronePitch = -1
	}

	if info.Info.UDistance == InvalidValueUInt16 {
		info.Info.UDistance = 0
	}
	if info.Info.UDangerLevels == InvalidValueInt16 {
		info.Info.UDangerLevels = 0
	}
	if info.Info.UFreq == InvalidValueInt32 {
		info.Info.UFreq = 0
	}

	return info
}
func DetectCheckInputNum(drone *mavlink.SflDetectDescription) *mavlink.SflDetectDescription {
	if drone.DroneLongitude == InvalidValueInt32 {
		drone.DroneLongitude = 0
	}
	if drone.DroneLatitude == InvalidValueInt32 {
		drone.DroneLatitude = 0
	}
	if drone.DroneHeight == InvalidValueInt16 {
		drone.DroneHeight = 0
	}
	if drone.DroneYawAngle == InvalidValueInt16 {
		drone.DroneYawAngle = 0
	}
	if drone.DroneSpeed == InvalidValueInt16 {
		drone.DroneSpeed = 0
	}
	if drone.DroneVerticalSpeed == InvalidValueInt16 {
		drone.DroneVerticalSpeed = 0
	}
	if drone.DroneSailLongitude == InvalidValueInt32 {
		drone.DroneSailLongitude = 0
	}
	if drone.DroneSailLatitude == InvalidValueInt32 {
		drone.DroneSailLatitude = 0
	}
	if drone.PilotLongitude == InvalidValueInt32 {
		drone.PilotLongitude = 0
	}
	if drone.PilotLatitude == InvalidValueInt32 {
		drone.PilotLatitude = 0
	}
	if drone.DroneHorizon == InvalidValueInt32 {
		drone.DroneHorizon = -1
	}
	if drone.DronePitch == InvalidValueInt32 {
		drone.DronePitch = -1
	}
	if drone.UDistance == InvalidValueUInt16 {
		drone.UDistance = 0
	}
	if drone.UDangerLevels == InvalidValueInt16 {
		drone.UDangerLevels = 0
	}
	if drone.UFreq == InvalidValueInt32 {
		drone.UFreq = 0
	}
	return drone
}
func (d *Sfl) ReceiveSflGetVersion() {
	logger.Info("-->into Receive Sfl Get Version")

	res := &mavlink.SflGetVersionResponse{}

	res.AppVersion = d.Msg[mavlink.HeaderLen : len(d.Msg)-2]
	manager, ok := d.WaitTaskMap[mavlink.SflGetVersion]
	if ok {
		manager.CompletedTask(res, nil)
	}
	logger.Info("-->End Receive Sfl Version:", string(res.AppVersion))
	return
}

func (d *Sfl) SendGetVersionInfo() (string, error) {
	logger.Info("-->into Send Get Version msg")
	req := &mavlink.SflGetVersionRequest{}
	buff := req.Create()
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Sfl version info err: %v", err)
		return "", fmt.Errorf("request Sfl version info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SflGetVersion]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflGetVersion, true, 0)
		d.WaitTaskMap[mavlink.SflGetVersion] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl version info err: %v", checkNetConnErr)
			return "", checkNetConnErr
		}
	}
	logger.Debug("SendGetVersionInfo result = ", result)
	res, ok := result.(*mavlink.SflGetVersionResponse)
	if !ok {
		return "", errors.New("response err type")
	}
	logger.Debug("response Sfl version result:%+v", *res)
	return string(res.AppVersion), nil
}
func (d *Sfl) ReceiveSflGetGNNS() {
	logger.Info("-->into Receive Sfl Get GNNS")

	res := &mavlink.SflGNSSGetResponse{}
	ret := d.UnmarshalPayloadSflGetGNSS(res)
	if ret != nil {
		logger.Debug("Receive Sfl Get GNNS ret = ", ret)
	}
	// res.AppVersion = d.Msg[mavlink.HeaderLen : len(d.Msg)-2]
	// res.Type = d.Msg[mavlink.HeaderLen : len(d.Msg)-2]
	manager, ok := d.WaitTaskMap[mavlink.SFLGetGNSS]
	if ok {
		manager.CompletedTask(res, nil)
	}
	logger.Info("-->End ReceiveSflGetGNNS Sfl :", res)
	return
}

func (d *Sfl) ReceiveSflSetGNNS() {
	logger.Info("-->into ReceiveSflSetGNNS Sfl Set GNNS")

	res := &mavlink.SflGNSSSetResponse{}
	ret := d.UnmarshalPayloadSflSetGNSS(res)
	if ret != nil {
		logger.Debug("Receive ReceiveSflSetGNNSret = ", ret)
	}
	manager, ok := d.WaitTaskMap[mavlink.SFLSetGNSS]
	if ok {
		manager.CompletedTask(res, nil)
	}
	logger.Info("-->End ReceiveSflSetGNNS Sfl :", res)
	return
}

func (d *Sfl) ReceiveSflSetPith() {
	logger.Info("-->into Receive Sfl Set Pith")
	res := &mavlink.SflSetHitInfoResponse{}
	d.GetPacket(res)
	logger.Debugf("Set Pith 接收到Sfl 信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflSetPith]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl) ReceiveSflSetAngle() {
	logger.Info("-->into Receive Sfl Set Angle")
	res := &mavlink.SflSetHitAngleResponse{}
	d.GetPacket(res)
	logger.Debugf("Set Angle 接收到Sfl 信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflSetAngle]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl) SendSflHitAngleSet(request *client.SflHitAngleRequest) (int, error) {
	logger.Info("-->into Send Hit Angle msg,req is %v", request)
	//1、设置打击俯仰角度
	req := &mavlink.SflSetHitInfoRequest{}
	buff := req.Create(request)
	logger.Debug("-->Set Hit Info is :", buff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Sfl Hit Angle  err: %v", err)
		return Fail, fmt.Errorf("request Sfl Hit Info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SflSetPith]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflSetPith, true, 0)
		d.WaitTaskMap[mavlink.SflSetPith] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl Hit Info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.SflSetHitInfoResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl Hit Info result:%+v", *res)

	//2、设置有效角度范围
	reqAngle := &mavlink.SflSetHitAngleRequest{}
	buffAngle := reqAngle.Create(request)
	logger.Debug("-->Set Hit Angle is :", buffAngle)
	if _, err := d.Conn.Write(buffAngle); err != nil {
		logger.Errorf("request Sfl Hit Angle err: %v", err)
		return Fail, fmt.Errorf("request Sfl Hit Angle err: %v", err)
	}
	managerAngle, ok := d.WaitTaskMap[mavlink.SflSetAngle]
	if !ok {
		managerAngle = NewWaitTaskManager(mavlink.SflSetAngle, true, 0)
		d.WaitTaskMap[mavlink.SflSetAngle] = managerAngle
	}

	resultAngle, err := managerAngle.Wait()
	if err != nil {
		if checkNetConnErr := managerAngle.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl  Hit Angle err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	resAngle, ok := resultAngle.(*mavlink.SflSetHitAngleResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl Hit Angle result:%+v", *resAngle)

	//3.设置打击模式   反制模式：1、Normal 2、GNSS
	reqMode := &mavlink.SflSetHitModeRequest{}
	buffMode := reqMode.Create(request)
	logger.Debug("-->Set Hit Mode is :", buffMode)
	if _, err := d.Conn.Write(buffMode); err != nil {
		logger.Errorf("request Sfl Hit Mode err: %v", err)
		return Fail, fmt.Errorf("request Sfl Hit Mode err: %v", err)
	}
	managerMode, ok := d.WaitTaskMap[mavlink.SflSetHitMode]
	if !ok {
		managerMode = NewWaitTaskManager(mavlink.SflSetHitMode, true, 0)
		d.WaitTaskMap[mavlink.SflSetHitMode] = managerMode
	}

	resultMode, err := managerMode.Wait()
	if err != nil {
		if checkNetConnErr := managerMode.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl  Hit Mode err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	resMode, ok := resultMode.(*mavlink.SflSetHitModeResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl Hit Mode result:%+v", *resMode)

	return int(resMode.Status), nil
}

func (d *Sfl) ReceiveSflStopHit() {
	logger.Info("-->into Receive Sfl Stop Hit")
	res := &mavlink.SflStopHitResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveSflStopHit 接收到信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflStopHit]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl) SendSflStopHitReq() (int, error) {
	logger.Info("-->into Send Sfl stop hit msg")
	req := &mavlink.SflStopHitRequest{}
	buff := req.Create()
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Sfl Stop Hit info err: %v", err)
		return Fail, fmt.Errorf("request Sfl Stop Hit info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SflStopHit]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflStopHit, true, 0)
		d.WaitTaskMap[mavlink.SflStopHit] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl Stop Hit info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.SflStopHitResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl Stop Hit result:%+v", *res)
	//清空map
	SflDetectInfoMap.Clear()
	return int(res.Status), nil
}

// SflGNSSSetReq
func (d *Sfl) SflGNSSSetReq(request *client.SflSetGNSSRequest) (int, error) {
	logger.Info("-->into SflGNSSSetReq stop hit msg")
	req := &mavlink.SflGNSSSetRequest{}
	buff := req.Create(request)
	logger.Debug("buff = ", buff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Sfl SSflGNSSSetReqerr: %v", err)
		return Fail, fmt.Errorf("request SflGNSSSetReq  info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SFLSetGNSS]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SFLSetGNSS, true, 0)
		d.WaitTaskMap[mavlink.SFLSetGNSS] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request SflGNSSSetReq info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.SflGNSSSetResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl SflGNSSSetReqresult:%+v", *res)
	//清空map
	SflDetectInfoMap.Clear()
	return int(res.Status), nil
}

// SflGNSSSetReq
func (d *Sfl) SflGNSSGetReq() (*mavlink.SflGNSSGetResponse, error) {
	logger.Info("-->into Send Sfl SflGNSSGetReq hit msg")
	req := &mavlink.SflGNSSGetRequest{}
	buff := req.Create()
	logger.Debug("buff = ", buff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("SflGNSSGetReqHit info err: %v", err)
		return nil, fmt.Errorf("SflGNSSGetReq info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SFLGetGNSS]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SFLGetGNSS, true, 0)
		d.WaitTaskMap[mavlink.SFLGetGNSS] = manager
	}

	result, err := manager.Wait()
	logger.Debug("result = ", result)
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request SflSflGNSSGetReq err: %v", checkNetConnErr)
			return nil, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.SflGNSSGetResponse)
	if !ok {
		return nil, errors.New("response err type")
	}
	logger.Debug("response SflGNSSGetReq result:%+v", *res)
	//清空map
	SflDetectInfoMap.Clear()
	return res, nil
}

func FindSflDetectInfo(request *client.SflDetectInfoRequest) (*client.SflDetectInfoResponse, error) {
	logger.Info("-->into Find SflDetect Info,req is :", request)
	layout := "2006-01-02 15:04:05" // 输入时间的格式

	start, err := time.Parse(layout, request.StartTime)
	if err != nil {
		logger.Error("Parse  StartTime err:", err)
		return nil, err
	}
	end, err := time.Parse(layout, request.EndTime)
	if err != nil {
		logger.Error("Parse  EndTime err:", err)
		return nil, err
	}
	startTimeInt := start.UnixNano() / int64(time.Millisecond)
	endTimeInt := end.UnixNano() / int64(time.Millisecond)
	rspInfo := make([]*client.Event, 0)
	rsp := &client.SflDetectInfoResponse{}
	detectList := &client.SflDetectInfoListRes{}

	err = NewSflDetectInfo().List(context.Background(), &client.SflDetectInfoListReq{
		StartTime: startTimeInt,
		StopTime:  endTimeInt,
	}, detectList)
	if err != nil {
		logger.Error("List Sfl err:", err)
		return nil, err
	}
	detectNum := 0
	hitNum := 0
	for _, list := range detectList.Sfllist {
		hittime := ""
		if list.HitTime != 0 {
			hittime = time.Unix(0, list.HitTime*int64(time.Millisecond)).Format("2006-01-02 15:04:05")
		}
		rspInfo = append(rspInfo, &client.Event{
			Id:            list.Id,
			BeginTime:     time.Unix(0, list.DetectTime*int64(time.Millisecond)).Format("2006-01-02 15:04:05"),
			Freq:          float64(list.Freq),
			DroneName:     list.Vendor,
			Protocol:      "TCP",
			SerialNum:     list.Sn,
			DevType:       int32(common.DEV_SFL),
			DroneYawAngle: float64(list.Direction),
			HitTime:       hittime,
			HitDev:        int32(common.DEV_SFL),
			PilotLongLat:  list.PilotLongLat,
			DroneHeight:   list.DroneHeight,
		})
		detectNum++
		if list.HitTime != 0 {
			hitNum++
		}
	}
	rsp.List = rspInfo
	rsp.DetectNum = int32(detectNum)
	rsp.HitNum = int32(hitNum)
	logger.Info("Sfl rsp is :", rsp)
	return rsp, nil
}

// FindSflDetectExportInfo 导出侦测信息
func FindSflDetectExportInfo(ctx context.Context, request *client.SflDetectInfoExportRequest) (int, error) {
	logger.Info("-->into Find SflDetect Export Info,req is :", request)

	file := excelize.NewFile()

	sheetName := file.GetSheetName(1) // 获取第一个表格的名称
	if sheetName != "sfl_detect_list" {
		file.SetSheetName(sheetName, "sfl_detect_list") // 将表格名称修改为 sfl_detect_list
	}

	tranStrToInt64 := func(data string) int64 {
		ret, e := strconv.ParseInt(data, 10, 64)
		if e != nil {
			return 0
		}
		return ret
	}
	file.SetCellValue("sfl_detect_list", "A1", "Sn")
	file.SetCellValue("sfl_detect_list", "B1", "Vendor")
	file.SetCellValue("sfl_detect_list", "C1", "DetectTime")
	file.SetCellValue("sfl_detect_list", "D1", "HitTime")
	file.SetCellValue("sfl_detect_list", "E1", "CounterTime")
	file.SetCellValue("sfl_detect_list", "F1", "Freq")
	file.SetCellValue("sfl_detect_list", "G1", "Direction")
	file.SetCellValue("sfl_detect_list", "H1", "PilotLongLat")
	file.SetCellValue("sfl_detect_list", "Ii", "DroneHeight")
	listinfo := &client.SflDetectInfoListRes{}
	sflDetectInfo := NewSflDetectInfo()
	err := sflDetectInfo.List(ctx, &client.SflDetectInfoListReq{
		StartTime: tranStrToInt64(request.StartTime),
		StopTime:  tranStrToInt64(request.EndTime),
	}, listinfo)
	if err != nil {
		logger.Error("-->get sfl_detect_list err:", err)
		return Fail, err
	}
	start := 0
	for i, list := range listinfo.Sfllist {
		rowNum := i + 2
		file.SetCellValue("sfl_detect_list", fmt.Sprintf("A%d", rowNum), list.Sn)
		file.SetCellValue("sfl_detect_list", fmt.Sprintf("B%d", rowNum), list.Vendor)
		file.SetCellValue("sfl_detect_list", fmt.Sprintf("C%d", rowNum), list.DetectTime)
		file.SetCellValue("sfl_detect_list", fmt.Sprintf("D%d", rowNum), list.HitTime)
		file.SetCellValue("sfl_detect_list", fmt.Sprintf("E%d", rowNum), list.CounterTime)
		file.SetCellValue("sfl_detect_list", fmt.Sprintf("F%d", rowNum), list.Freq)
		file.SetCellValue("sfl_detect_list", fmt.Sprintf("G%d", rowNum), list.Direction)
		file.SetCellValue("sfl_detect_list", fmt.Sprintf("H%d", rowNum), list.PilotLongLat)
		file.SetCellValue("sfl_detect_list", fmt.Sprintf("I%d", rowNum), list.DroneHeight)
		start = i
	}
	if err = file.SaveAs(request.FilePath); err != nil {
		logger.Error("-->SaveAs sfl_detect_list err:", err)
		return Fail, err
	}

	//其他类型设备数据导出
	var flightEvents []bean.FlightList
	err = db.GetDB().Model(&bean.FlightList{}).
		Order("begin_time desc").
		Find(&flightEvents).Error
	if err != nil {
		logger.Errorf("outPut query event list error:%v", err)
		return Fail, err
	}
	for i, list := range flightEvents {
		rowNum := i + 2 + start
		file.SetCellValue("sfl_detect_list", fmt.Sprintf("A%d", rowNum), list.SerialNum)
		file.SetCellValue("sfl_detect_list", fmt.Sprintf("B%d", rowNum), list.Vendor)
		file.SetCellValue("sfl_detect_list", fmt.Sprintf("C%d", rowNum), list.BeginTime)
		file.SetCellValue("sfl_detect_list", fmt.Sprintf("D%d", rowNum), 0)
		file.SetCellValue("sfl_detect_list", fmt.Sprintf("E%d", rowNum), list.DurationTime)
		file.SetCellValue("sfl_detect_list", fmt.Sprintf("F%d", rowNum), list.Freq)
		file.SetCellValue("sfl_detect_list", fmt.Sprintf("G%d", rowNum), list.DroneYawAngle)
		file.SetCellValue("sfl_detect_list", fmt.Sprintf("H%d", rowNum), "")
		file.SetCellValue("sfl_detect_list", fmt.Sprintf("I%d", rowNum), "")
	}
	if err = file.SaveAs(request.FilePath); err != nil {
		logger.Error("-->SaveAs Other sfl_detect_list err:", err)
		return Fail, err
	}

	logger.Info("-->End Export sfl_detect_list List")
	return Success, nil
}

func FindSflDetectExportInfoV2(ctx context.Context, request *client.SflDetectInfoExportRequest) (int, error) {
	logger.Info("-->into Find SflDetect Export Info,req is :", request)

	// 创建CSV文件
	file, err := os.Create(request.FilePath)
	if err != nil {
		logger.Error("FindSflDetectExportInfoV2 os.Create err:", err)
		return Fail, err
	}
	defer file.Close()

	// 创建CSV writer
	writer := csv.NewWriter(file)

	//写入UTF-8 BOM头，避免使用excel软件打开.csv文件出现中文乱码
	//writer.Write([]string{"\xEF\xBB\xBF"})
	// 写入CSV文件的头部
	title := []string{"Sn", "Vendor", "DetectTime", "HitTime", "CounterTime", "Freq", "Direction", "PilotLongLat", "DroneHeight"}
	if err := writer.Write(title); err != nil {
		logger.Error("FindSflDetectExportInfoV2 writer.Write title err:", err)
		return Fail, err
	}
	// 写入CSV文件的数据行
	tranStrToInt64 := func(data string) int64 {
		ret, e := strconv.ParseInt(data, 10, 64)
		if e != nil {
			return 0
		}
		return ret
	}
	listinfo := &client.SflDetectInfoListRes{}
	sflDetectInfo := NewSflDetectInfo()
	err = sflDetectInfo.List(ctx, &client.SflDetectInfoListReq{
		StartTime: tranStrToInt64(request.StartTime),
		StopTime:  tranStrToInt64(request.EndTime),
	}, listinfo)
	if err != nil {
		logger.Error("-->get sfl_detect_list err:", err)
		return Fail, err
	}

	records := make([][]string, 0)
	for _, list := range listinfo.Sfllist {
		record := []string{
			list.Sn,
			list.Vendor,
			strconv.FormatInt(list.DetectTime, 10),
			strconv.FormatInt(list.HitTime, 10),
			strconv.FormatInt(list.CounterTime, 10),
			strconv.FormatFloat(float64(list.Freq), 'f', -1, 32),
			strconv.FormatInt(list.Direction, 10),
			list.PilotLongLat,
			strconv.FormatFloat(list.DroneHeight, 'f', -1, 32),
		}
		records = append(records, record)
	}

	if err := writer.WriteAll(records); err != nil {
		logger.Error("FindSflDetectExportInfoV2 writer.WriteAll err:", err)
		return Fail, err
	}
	logger.Info("-->End Export sfl_detect_list List")
	return Success, nil
}

// FindSflDetectInfoByKey 侦测信息查询
func FindSflDetectInfoByKey(request *client.SflDetectInfoRequest) (*client.SflDetectInfoResponse, error) {
	logger.Info("-->into Detect Find Info,req is :", request)
	layout := "2006-01-02 15:04:05" // 输入时间的格式

	start, err := time.Parse(layout, request.StartTime)
	if err != nil {
		logger.Error("Parse  StartTime err:", err)
		return nil, err
	}
	end, err := time.Parse(layout, request.EndTime)
	if err != nil {
		logger.Error("Parse  EndTime err:", err)
		return nil, err
	}
	startTimeInt := start.UnixNano() / int64(time.Millisecond)
	endTimeInt := end.UnixNano() / int64(time.Millisecond)
	rspInfo := make([]*client.Event, 0)
	rsp := &client.SflDetectInfoResponse{}
	detectList := &client.SflDetectInfoListLikeRes{}
	err = NewSflDetectInfo().ListLike(context.Background(), &client.SflDetectInfoListLikeReq{
		StartTime: startTimeInt,
		StopTime:  endTimeInt,
		FindKey:   request.FindKey,
	}, detectList)
	if err != nil {
		logger.Error("List Sfl err:", err)
		return nil, err
	}
	detectNum := 0
	hitNum := 0
	for _, list := range detectList.Sfllist {
		hittime := ""
		if list.HitTime != 0 {
			hittime = time.Unix(0, list.HitTime*int64(time.Millisecond)).Format("2006-01-02 15:04:05")
		}
		rspInfo = append(rspInfo, &client.Event{
			Id:            list.Id,
			BeginTime:     time.Unix(0, list.DetectTime*int64(time.Millisecond)).Format("2006-01-02 15:04:05"),
			Freq:          float64(list.Freq),
			DroneName:     list.Vendor,
			Protocol:      "TCP",
			SerialNum:     list.Sn,
			DevType:       int32(common.DEV_SFL),
			DroneYawAngle: float64(list.Direction),
			HitTime:       hittime,
			HitDev:        int32(common.DEV_SFL),
			DroneHeight:   list.DroneHeight,
			PilotLongLat:  list.PilotLongLat,
		})
		detectNum++
		if list.HitTime != 0 {
			hitNum++
		}
	}
	rsp.List = rspInfo
	rsp.DetectNum = int32(detectNum)
	rsp.HitNum = int32(hitNum)
	logger.Info("Sfl rsp is :", rsp)
	return rsp, nil
}

func (d *Sfl) ReceiveSflSetHitMode() {
	logger.Info("-->into Receive Set Hit Mode")
	res := &mavlink.SflSetHitModeResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveSflSet Hit Mode 接收到Sfl信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflSetHitMode]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl) SendSflOnOffSet(request *client.SflOnOffRequest) (int, error) {
	logger.Info("-->into Send On Off  msg")
	req := &mavlink.SflSetOnOffRequest{}
	buff := req.Create(request)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Sfl On Off info err: %v", err)
		return Fail, fmt.Errorf("request Sfl On Off info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SflSetOnOff]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflSetOnOff, true, 0)
		d.WaitTaskMap[mavlink.SflSetOnOff] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl On Off info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.SflSetOnOffResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl On Off result:%+v", *res)
	return int(res.Status), nil
}
func (d *Sfl) ReceiveSflSetOnOff() {
	logger.Info("-->into Receive SflSetOnOff")
	res := &mavlink.SflSetOnOffResponse{}
	d.GetPacket(res)
	logger.Debugf("Sfl Set OnOff  接收到Sfl信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflSetOnOff]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl) SendSflReset() (int, error) {
	logger.Info("-->into Send Reset  msg")
	req := &mavlink.SflResetRequest{}
	buff := req.Create()
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Sfl Reset info err: %v", err)
		return Fail, fmt.Errorf("request Sfl Reset info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SflReset]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflReset, true, 0)
		d.WaitTaskMap[mavlink.SflReset] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl Reset info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.SflResetResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl Reset result:%+v", *res)
	return int(res.Status), nil
}
func (d *Sfl) ReceiveSflReset() {
	logger.Info("-->into Receive Reset")
	res := &mavlink.SflResetResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveSflGet Reset 接收到Sfl信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflReset]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}
func (d *Sfl) SendSflHitUav(request *client.SflSendHitUavRequest) (int, error) {
	logger.Info("-->into Send Hit Uav msg,req is:", request)
	req := &mavlink.SflSendHitUavRequest{}
	buff := req.Create(request)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Sfl Send Hit Uav info err: %v", err)
		return Fail, fmt.Errorf("request Sfl Send Hit Uav info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SflSendHitUav]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflSendHitUav, true, 0)
		d.WaitTaskMap[mavlink.SflSendHitUav] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl Send Hit Uav info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.SflSendHitUavResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl Send Hit Uav result:%+v", *res)
	return int(res.Status), nil
}

func (d *Sfl) ReceiveSflGetHitUav() {
	logger.Info("-->into Receive Get Hit Uav")
	res := &mavlink.SflSendHitUavResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveSflGetHitUav  接收到Sfl信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflSendHitUav]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}
func (d *Sfl) SendSflGetStatus() (*client.SflGetStatusResponse, error) {
	logger.Info("-->into Send Reset  msg")
	rsp := &client.SflGetStatusResponse{}

	//1.获取角度、打击时长信息
	req := &mavlink.SflGetPitchRequest{}
	buff := req.Create()
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Sfl GetPitch info err: %v", err)
		return rsp, fmt.Errorf("request Sfl GetPitch info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SflGetHitPith]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflGetHitPith, true, 0)
		d.WaitTaskMap[mavlink.SflGetHitPith] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl GetPitch info err: %v", checkNetConnErr)
			return rsp, checkNetConnErr
		}
	}
	resPitch, ok := result.(*mavlink.SflGetPitchResponse)
	if !ok {
		return rsp, errors.New("response err type")
	}
	logger.Debug("response Sfl GetPitch result:%+v", *resPitch)

	for i := 0; i < int(resPitch.HitCnt); i++ {
		rsp.HitTime = int32(resPitch.HitDescription[0].HitTime)
		rsp.HitPitch1 = int32(resPitch.HitDescription[0].HitPitch)
		rsp.HitPitch2 = int32(resPitch.HitDescription[i].HitPitch)
	}

	//2.获取打击范围信息
	reqAngle := &mavlink.SflGetAngleRequest{}
	buffAngle := reqAngle.Create()
	if _, err := d.Conn.Write(buffAngle); err != nil {
		logger.Errorf("request Sfl GetAngle info err: %v", err)
		return rsp, fmt.Errorf("request Sfl GetAngle info err: %v", err)
	}
	managerAngle, ok := d.WaitTaskMap[mavlink.SflGetHitAngle]
	if !ok {
		managerAngle = NewWaitTaskManager(mavlink.SflGetHitAngle, true, 0)
		d.WaitTaskMap[mavlink.SflGetHitAngle] = managerAngle
	}

	resultAngle, err := managerAngle.Wait()
	if err != nil {
		if checkNetConnErr := managerAngle.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl GetAngle info err: %v", checkNetConnErr)
			return rsp, checkNetConnErr
		}
	}
	resAngle, ok := resultAngle.(*mavlink.SflGetAngleResponse)
	if !ok {
		return rsp, errors.New("response err type")
	}
	logger.Debug("response Sfl GetAngle result:%+v", *resAngle)
	rsp.HitAngleBegin = int32(resAngle.HitAngleBegin)
	rsp.HitAngleEnd = int32(resAngle.HitAngleEnd)

	//3.获取工作模式
	reqMode := &mavlink.SflGetHitModeRequest{}
	buffMode := reqMode.Create()
	if _, err := d.Conn.Write(buffMode); err != nil {
		logger.Errorf("request Sfl GetMode info err: %v", err)
		return rsp, fmt.Errorf("request Sfl GetMode info err: %v", err)
	}
	managerreqMode, ok := d.WaitTaskMap[mavlink.SflGetHitMode]
	if !ok {
		managerreqMode = NewWaitTaskManager(mavlink.SflGetHitMode, true, 0)
		d.WaitTaskMap[mavlink.SflGetHitMode] = managerreqMode
	}

	resultMode, err := managerreqMode.Wait()
	if err != nil {
		if checkNetConnErr := managerreqMode.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl GetMode info err: %v", checkNetConnErr)
			return rsp, checkNetConnErr
		}
	}
	resMode, ok := resultMode.(*mavlink.SflGetHitModeResponse)
	if !ok {
		return rsp, errors.New("response err type")
	}
	logger.Debug("response Sfl GetMode result:%+v", *resMode)
	rsp.HitMode = int32(resMode.ModeStatus)

	return rsp, nil
}

func (d *Sfl) SendSflSetHitMode(hitMode int32) (int, error) {
	//设置打击模式  0 不自动打击    1 自动打击
	req := &mavlink.SflSetAutoModeRequest{}
	buff := req.Create(hitMode)
	logger.Debug("-->Set Hit Auto is :", buff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Sfl Hit Auto err: %v", err)
		return Fail, fmt.Errorf("request Sfl Hit Auto err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SflSetAutoHitMode]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflSetAutoHitMode, true, 0)
		d.WaitTaskMap[mavlink.SflSetAutoHitMode] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl  Hit Mode err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.SflSetAutoModeResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl Hit Auto result:%+v", *res)

	return int(res.Status), nil
}
func (d *Sfl) ReceiveSflSetAutoHitMode() {
	logger.Info("-->into ReceiveSfl Set Auto Hit Mode")
	res := &mavlink.SflSetAutoModeResponse{}
	d.GetPacket(res)
	logger.Debugf("Set Auto Hit Mode  接收到Sfl信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflSetAutoHitMode]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}
func (d *Sfl) SendSflGetHitMode() (int, error) {
	//获取打击模式  0 不自动打击    1 自动打击
	req := &mavlink.SflGetAutoModeRequest{}
	buff := req.Create()
	logger.Debug("-->Get Hit Auto is :", buff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Get Sfl Hit Auto err: %v", err)
		return Fail, fmt.Errorf("request Get Sfl Hit Auto err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SflGetAutoHitMode]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflGetAutoHitMode, true, 0)
		d.WaitTaskMap[mavlink.SflGetAutoHitMode] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl Get Hit Mode err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.SflGetAutoModeResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl Get Hit Auto result:%+v", *res)

	return int(res.AutoStatus), nil
}
func (d *Sfl) ReceiveSflGetAutoHitMode() {
	logger.Info("-->into ReceiveSfl Get Auto Hit Mode")
	res := &mavlink.SflGetAutoModeResponse{}
	d.GetPacket(res)
	logger.Debugf("Get Auto Hit Mode  接收到Sfl信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflGetAutoHitMode]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl) SendSflGetPower() (int, int, error) {
	logger.Info("-->into Send Get Power  msg")
	//获取开关机状态
	req := &mavlink.SflGetPowerRequest{}
	buff := req.Create()
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Sfl Get Power info err: %v", err)
		return Fail, Fail, fmt.Errorf("request Sfl Get Power info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SflGetOnOff]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflGetOnOff, true, 0)
		d.WaitTaskMap[mavlink.SflGetOnOff] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl Get Power info err: %v", checkNetConnErr)
			return Fail, Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.SflGetPowerResponse)
	if !ok {
		return Fail, Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl Get Power result:%+v", *res)

	return int(res.PowerStatus), int(res.Status), nil
}
func (d *Sfl) ReceiveSflGetOnOff() {
	logger.Info("-->into Receive SflGetOnOff")
	res := &mavlink.SflGetPowerResponse{}
	d.GetPacket(res)
	logger.Debugf("SflGetOnOff Get 接收到Sfl信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflGetOnOff]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl) SendSflTurnHit(startStop int32) (int, error) {
	logger.Info("-->into Send Turn Hit  msg")
	//获取开关机状态
	req := &mavlink.SflTurnHitRequest{}
	buff := req.Create(uint8(startStop))
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Sfl Send Turn Hit info err: %v", err)
		return Fail, fmt.Errorf("request Sfl Send Turn Hit info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SflHitTurn]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflHitTurn, true, 0)
		d.WaitTaskMap[mavlink.SflHitTurn] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl Turn Hit info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.SflTurnHitResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl Turn Hit result:%+v", *res)

	return int(res.Status), nil
}
func (d *Sfl) ReceiveSflTurnHit() {
	logger.Info("-->into Receive SflTurnHit")
	res := &mavlink.SflTurnHitResponse{}
	d.GetPacket(res)
	logger.Debugf("SflTurnHit Get 接收到Sfl信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflHitTurn]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl) SendSflHorizontalTurn(request *client.SflHorizontalTurnRequest) (int, error) {
	logger.Info("-->into Send Horizontal Turn  msg")
	//获取开关机状态
	req := &mavlink.SflHorizontalTurnRequest{}
	buff := req.Create(request)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Sfl Send Horizontal Turn info err: %v", err)
		return Fail, fmt.Errorf("request Sfl Send Horizontal Turn info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SflHorizontalTurn]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflHorizontalTurn, true, 0)
		d.WaitTaskMap[mavlink.SflHorizontalTurn] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl Horizontal Turn info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.SflHorizontalTurnResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl Horizontal Turn result:%+v", *res)

	return int(res.Status), nil
}
func (d *Sfl) ReceiveSflHorizontalTurn() {
	logger.Info("-->into Receive Sfl Horizontal Turn")
	res := &mavlink.SflHorizontalTurnResponse{}
	d.GetPacket(res)
	logger.Debugf("Sfl Horizontal Turn Get 接收到Sfl信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflHorizontalTurn]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl) SendSflVerticalTurn(request *client.SflVerticalTurnRequest) (int, error) {
	logger.Info("-->into Send Vertical Turn  msg")
	//获取开关机状态
	req := &mavlink.SflVerticalTurnRequest{}
	buff := req.Create(request)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Sfl Send Vertical Turn info err: %v", err)
		return Fail, fmt.Errorf("request Sfl Send Vertical Turn info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SflVerticalTurn]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflVerticalTurn, true, 0)
		d.WaitTaskMap[mavlink.SflVerticalTurn] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl Vertical Turn info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.SflVerticalTurnResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl Vertical Turn result:%+v", *res)

	return int(res.Status), nil
}
func (d *Sfl) ReceiveSflVerticalTurn() {
	logger.Info("-->into Receive Sfl Vertical Turn")
	res := &mavlink.SflVerticalTurnResponse{}
	d.GetPacket(res)
	logger.Debugf("Sfl Vertical Turn Get 接收到Sfl信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflVerticalTurn]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl) ReceiveSflGetHitPith() {
	logger.Info("-->into Receive Get Hit Pith")
	res := &mavlink.SflGetPitchResponse{}
	if err := d.UnmarshalPayloadSflHitPith(res); err != nil {
		logger.Errorf(err.Error())
		return
	}
	logger.Debugf("ReceiveSflGet Hit Pith 接收到Sfl信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflGetHitPith]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl) UnmarshalPayloadSflHitPith(data *mavlink.SflGetPitchResponse) error {
	deviceInfoLen := binary.Size(data.HitCnt)
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.HitCnt); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}

	start := mavlink.HeaderLen + deviceInfoLen
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializeDrone(d.Msg[start:end]); err != nil {
		return err
	}

	return nil
}

func (d *Sfl) UnmarshalPayloadSflGetGNSS(data *mavlink.SflGNSSGetResponse) error {
	buff := &bytes.Buffer{}
	start := mavlink.HeaderLen
	end := start + int(data.Size())
	logger.Debug("start: , end: ", start, end)
	logger.Debug("d.Msg[start:end] = ", d.Msg[start:end])
	if err := binary.Write(buff, binary.LittleEndian, d.Msg[start:end]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, data); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}
	logger.Debugf("ReceiveSfl UnmarshalPayloadSflGetGNSS 接收到Sfl信息：%#v", data)
	// if err := data.DeserializeDrone(d.Msg[start:end]); err != nil {
	// 	return err
	// }

	return nil
}

func (d *Sfl) UnmarshalPayloadSflSetGNSS(data *mavlink.SflGNSSSetResponse) error {
	buff := &bytes.Buffer{}
	start := mavlink.HeaderLen
	end := start + int(data.Size())
	logger.Debug("start: , end: ", start, end)
	logger.Debug("d.Msg[start:end] = ", d.Msg[start:end])
	if err := binary.Write(buff, binary.LittleEndian, d.Msg[start:end]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, data); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}
	logger.Debugf("ReceiveSfl UnmarshalPayloadSflSetGNSS 接收到Sfl信息：%#v", data)
	// if err := data.DeserializeDrone(d.Msg[start:end]); err != nil {
	// 	return err
	// }

	return nil
}

func (d *Sfl) ReceiveSflGetHitAngle() {
	logger.Info("-->into Receive Get Hit Angle")
	res := &mavlink.SflGetAngleResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveSfl Get Hit Angle 接收到Sfl信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflGetHitAngle]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl) ReceiveSflGetHitMode() {
	logger.Info("-->into Receive Get Hit Mode")
	res := &mavlink.SflGetHitModeResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveSflGet Hit Mode 接收到Sfl信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflGetHitMode]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// SendSflSetWhite 发送设置Sfl白名单
func (d *Sfl) SendSflSetWhite(snList []mavlink.SflWhiteInfo) (int, error) {
	logger.Info("---> Send Sfl Set White")
	defer func() {
		if r := recover(); r != nil {
			logger.Error("Sfl Set White occurred:", r)
			return
		}
	}()
	req := mavlink.SflSetWhiteRequestAll{}
	whitelist := make([]mavlink.SflWhiteInfo, 0)
	for _, s := range snList {
		whitelist = append(whitelist, mavlink.SflWhiteInfo{Serial: s.Serial})
	}
	reqInfo := &mavlink.SflSetWhiteRequest{
		WhiteNum:  uint16(len(whitelist)),
		WhiteList: whitelist,
	}

	buff := req.Create(reqInfo)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.SflSetWhiteList]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflSetWhiteList, true, time.Millisecond*300)
		d.WaitTaskMap[mavlink.SflSetWhiteList] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Send Sfl Set White is :[%v]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send Sfl Set White  err:[%v].Buff is [%v]", err, buff)
		return Fail, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send Sfl Set White  err %s", err.Error())
		return Fail, err
	}
	res := result.(*mavlink.SflSetWhiteResponse)

	logger.Info("-->End Set Sfl Set Alarm")
	return int(res.Status), nil
}

func SendDevWhiteListToSfl() {
	deviceInfo := &client.EquipListRes{}
	err := NewEquipList().List(context.Background(), &client.EquipListReq{}, deviceInfo)
	if err != nil {
		logger.Error("Get EquipList err: ", err)
	}
	//查白名单中的无人机，在Tracer侦测结果中添加无人机角色
	whiteList := &client.ListResAll{}
	err = NewWhiteList().ListAll(context.Background(), &client.ListReqAll{}, whiteList)
	if err != nil {
		logger.Error("Get whiteList err: ", err)
		return
	}
	logger.Info("Get EquipList is : ", whiteList.WhiteList)
	snList := make([]mavlink.SflWhiteInfo, 0)

	for _, all := range whiteList.WhiteList {
		if all.Role == FRIEND {
			var tempSn [32]byte
			copy(tempSn[:], all.Sn)
			snList = append(snList, mavlink.SflWhiteInfo{Serial: tempSn})
		}
	}
	for _, equip := range deviceInfo.Equips {
		if equip.Etype == "Sfl" {
			sflInfo := FindCacheDevice(equip.Sn, common.DEV_SFL)
			if sflInfo == nil {
				continue
			} else {
				dev := &Sfl{Device: sflInfo}
				dev.SendSflSetWhite(snList)
			}

		}
	}

}

// SflSendUpgradeF1
func (d *Sfl) SflSendUpgradeF1(fileName string, c2Ip string) (int32, error) {
	logger.Info("SflSendUpgradeF1 Start")

	req := &mavlink.SflUpdateF1Request{}
	buff := req.Create(fileName, c2Ip)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.SflIdUpgradeF1]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflIdUpgradeF1, true, 0)
		d.WaitTaskMap[mavlink.SflIdUpgradeF1] = manager
	}
	task := manager.AddTask(nil, nil)
	logger.Debugf("SflSendUpgradeF1 buff: %02X \n", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("SflSendUpgradeF1 发送写入固件数据信息失败: ", err)
		return 1, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("SflSendUpgradeF1 WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 1, checkNetConnErr
		}
		return 1, err
	}
	res := result.(*mavlink.SflUpdateF1Response)
	logger.Debugf("SflUpdateF1Response 获取写入固件数据信息结果：%#v", res)
	logger.Info("SflUpdateF1Response End")
	return int32(res.Status), nil
}

// ReceiveSflUpdateF1 获取请求固件升级响应
func (d *Sfl) ReceiveSflUpdateF1() {
	res := &mavlink.SflUpdateF1Response{}
	d.GetPacket(res)
	logger.Debugf("ReceiveSflUpdateF1 获取请求固件升级响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflIdUpgradeF1]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// SflSendUpgradeF2
func (d *Sfl) SflSendUpgradeF2() (int32, error) {
	logger.Info("SflSendUpgradeF2 Start")
	req := &mavlink.SflUpdateF2Request{}
	buff := req.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.SflIdUpgradeF2]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflIdUpgradeF2, true, time.Second*30)
		d.WaitTaskMap[mavlink.SflIdUpgradeF2] = manager
	}
	task := manager.AddTask(nil, nil)
	logger.Debugf("SflSendUpgradeF2 buff: %02X \n", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("SflSendUpgradeF2 发送写入固件数据信息失败: ", err)
		return 1, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("SflSendUpgradeF2 WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 1, checkNetConnErr
		}
		return 1, err
	}
	res := result.(*mavlink.SflUpdateF2Response)
	logger.Debugf("SflUpdateF2Response 获取写入固件数据信息结果：%#v", res)
	logger.Info("SflUpdateF2Response End")
	return int32(res.Progress), nil
}

// ReceiveSflUpdateF2 获取请求固件升级响应
func (d *Sfl) ReceiveSflUpdateF2() {
	res := &mavlink.SflUpdateF2Response{}
	d.GetPacket(res)
	logger.Debugf("ReceiveSflUpdateF2 获取请求固件升级响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflIdUpgradeF2]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// SflSendUpgradeF3
func (d *Sfl) SflSendUpgradeF3() (int32, error) {
	logger.Info("SflSendUpgradeF3 Start")

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.SflIdUpgradeF3]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflIdUpgradeF3, true, time.Second*60)
		d.WaitTaskMap[mavlink.SflIdUpgradeF3] = manager
	}
	task := manager.AddTask(nil, nil)

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("SflSendUpgradeF3 WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 1, checkNetConnErr
		}
		return 1, err
	}
	res := result.(*mavlink.SflUpdateF3Response)
	logger.Debugf("SflUpdateF3Response 获取写入固件数据信息结果：%#v", res)
	logger.Info("SflUpdateF3Response End")
	return int32(res.UpgradeResult), nil
}

// ReceiveSflUpdateF3 获取请求固件升级响应
func (d *Sfl) ReceiveSflUpdateF3() {
	res := &mavlink.SflUpdateF3Response{}
	d.GetPacket(res)
	logger.Debugf("ReceiveSflUpdateF3 获取请求固件升级响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflIdUpgradeF3]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

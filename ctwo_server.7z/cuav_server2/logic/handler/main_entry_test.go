package handler

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
	"path/filepath"
	"testing"
)

func setUp() {
	cuavConfigFile := "../../config/cuav-config.yaml"
	filepath.Dir(cuavConfigFile)
	if err := logger.Init(cuavConfigFile, "log/log"); err != nil {
		panic(err)
	}

	dbFile := "../../config/cuav.db"
	db.Init(dbFile) //可以考虑使用内存sqlite 模式来做测试。

	createRadarheartBroker()
}
func tearDown() {
	removeDemoCheckTab()
}

func TestMain(m *testing.M) {
	setUp()
	m.Run()
	tearDown()
}

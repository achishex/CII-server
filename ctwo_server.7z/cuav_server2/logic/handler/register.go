package handler

import (
	"go-micro.dev/v4"
)

// InitHandler ...
func InitHandler(srv micro.Service) {
}

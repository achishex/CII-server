package handler

import (
	"bytes"
	"context"
	"crypto/rand"
	"encoding/binary"
	"errors"
	"fmt"
	"math/big"
	"strconv"
	"strings"
	"sync"
	"time"

	"adasgitlab.autel.com/tools/cuav_plugin/broker"
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/server"
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/ip"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/proto/mavlink"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
	"adasgitlab.autel.com/tools/slink_proto/slinkv1"
	"github.com/golang/protobuf/proto"
	jsoniter "github.com/json-iterator/go"
	broker2 "go-micro.dev/v4/broker"
)

var (
	ScreenTcpPort        int64 = 11000
	ScreenServerMaxCount int64 = 500
	screenPortMutex      sync.Mutex
	screenTcpServerLock  sync.Mutex
	ScreenTcpServerMap   sync.Map //= make(map[string]*server.TcpServer, 0)
	SnMaps               sync.Map
)

type Screen struct {
	*Device
	dt common.DeviceType

	hitComputeStatus bool
	hitCompute       chan struct{}
}

func NewScreen(conn Connection, d []byte, dataLen int, remoteIp string, remotePort int, localIp string, serverPort int,
	mailBox map[int]*WaitTaskManager) DeviceInterface {
	return &Screen{
		Device: &Device{
			Conn:        conn,
			Msg:         d,
			MsgLen:      dataLen,
			SourceId:    d[mavlink.SenderLoc],
			RemoteIp:    remoteIp,
			RemotePort:  remotePort,
			LocalIp:     localIp,
			ServerPort:  serverPort,
			WaitTaskMap: mailBox,
		},
		hitCompute: make(chan struct{}, 1),
	}
}

func (d *Screen) Deal() {
	if d.MsgLen <= 0 {
		logger.Error("数据为null,不作处理，%v", d.RemoteIp)
		return
	}
	d.Sn = d.getCacheSn()
	d.MsgId = int(d.Msg[mavlink.MsgIdLoc])
	switch d.MsgId {
	case mavlink.ScreenIdHeart:
		d.ReceiveHeart()
		break
	case mavlink.ScreenIdGetChannel:
		logger.Debugf("Deal 通过tcp连接申请信道: %v \n", d.RemoteIp)
		d.ReceiveGetChannelReq()
		break
	case mavlink.ScreenMsgHit:
		d.ReceiveHitResponse()
		break
	case mavlink.ScreenHitStatusUpload:
		d.ReceiveHitStatus()
		break
	case mavlink.ScreenIdResetSystem:
		d.ReceiveScreenResetSystem()
		break
	case mavlink.ScreenGetTime: //屏幕获取时间
		d.ReceiveScreenGetTime()
		break
	default:
		logger.Debug("未知显示屏消息id:", d.MsgId)
		break
	}
}

func (d *Screen) ReceiveHeart() {
	heart := &mavlink.ScreenHeartBeatResponse{}
	dataBuff := d.Msg[mavlink.HeaderLen : d.MsgLen-mavlink.CrcLen]
	if err := jsoniter.Unmarshal(dataBuff, heart); err != nil {
		logger.Error("反序列化显示屏心跳错误：", err)
		return
	}
	logger.Info("接收到显示屏心跳:", heart)
	d.UpdateStatus(d.Sn)
	gunLongitude, _ := strconv.ParseFloat(heart.GunLongitude, 10)
	gunLatitude, _ := strconv.ParseFloat(heart.GunLatitude, 10)
	gunDirection, _ := strconv.ParseFloat(heart.GunDirection, 10)
	gunElevation, _ := strconv.ParseFloat(heart.Elevation, 10)

	uavs := make([]*client.ScreenHeartUavEntity, 0)
	for i := 0; i < len(heart.Info); i++ {
		droneLongitude, _ := strconv.ParseFloat(heart.Info[i].DroneLongitude, 10)
		droneLatitude, _ := strconv.ParseFloat(heart.Info[i].DroneLatitude, 10)
		droneHeight, _ := strconv.ParseFloat(heart.Info[i].DroneHeight, 10)
		droneYawAngle, _ := strconv.ParseFloat(heart.Info[i].DroneYawAngle, 10)
		droneSpeed, _ := strconv.ParseFloat(heart.Info[i].DroneSpeed, 10)
		droneVerticalSpeed, _ := strconv.ParseFloat(heart.Info[i].DroneVerticalSpeed, 10)
		pilotLongitude, _ := strconv.ParseFloat(heart.Info[i].PilotLongitude, 10)
		pilotLatitude, _ := strconv.ParseFloat(heart.Info[i].PilotLatitude, 10)
		droneHorizon, _ := strconv.ParseFloat(heart.Info[i].DroneHorizon, 10)
		dronePitch, _ := strconv.ParseFloat(heart.Info[i].DronePitch, 10)
		uFreq, _ := strconv.Atoi(heart.Info[i].UFreq)
		uDistance, _ := strconv.Atoi(heart.Info[i].UDistance)
		uavs = append(uavs, &client.ScreenHeartUavEntity{
			ProductType:        int32(heart.Info[i].ProductType),
			DroneName:          heart.Info[i].DroneName,
			SerialNum:          heart.Info[i].SerialNum,
			DroneLongitude:     droneLongitude,
			DroneLatitude:      droneLatitude,
			DroneHeight:        droneHeight,
			DroneYawAngle:      droneYawAngle,
			DroneSpeed:         droneSpeed,
			DroneVerticalSpeed: droneVerticalSpeed,
			PilotLongitude:     pilotLongitude,
			PilotLatitude:      pilotLatitude,
			DroneHorizon:       droneHorizon,
			DronePitch:         dronePitch,
			UFreq:              float64(uFreq) / 1000.0,
			UDistance:          int32(uDistance),
			UDangerLevels:      int32(heart.Info[i].UDangerLevels),
		})
	}
	dataInfo := &client.ScreenHeartBeatInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      d.Sn,
			Sn:        d.Sn,
			EquipType: int32(common.DEV_SCREEN),
			MsgType:   mavlink.ScreenIdHeart,
		},
		Data: &client.ScreenHeartBeatEntity{
			TimeStamp:      heart.TimeStamp,
			ScreenStatus:   uint32(heart.ScreenStatus),
			Electricity:    uint32(heart.Electricity),
			SignalStrength: uint32(heart.SignalStrength),
			WorkStatus:     uint32(heart.WorkStatus),
			AlarmLevel:     uint32(heart.AlarmLevel),
			HitFreq:        uint32(heart.HitFreq),
			DetectFreq:     heart.DetectFreq,
			X:              uint32(heart.X),
			Y:              uint32(heart.Y),
			Z:              uint32(heart.Z),
			GunLongitude:   gunLongitude,
			GunLatitude:    gunLatitude,
			GunAltitude:    heart.GunAltitude,
			SatellitesNum:  uint32(heart.SatellitesNum),
			GunDirection:   gunDirection,
			ReHitTime:      uint32(heart.ReHitTime),
			HitTime:        uint32(heart.HitTime),
			Elevation:      gunElevation,
			UDroneNum:      uint32(heart.UDroneNum),
			IsOnline:       common.DevOnline,
			Info:           uavs,
		},
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIDAEAGHeartBeat,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}
	_ = mq.GunDroneIdBroker.Publish(mq.GunDroneIdTopic, broker.NewMessage(out))

	logger.Info("显示屏上报心跳包完成")
	req := &mavlink.ScreenHeartbeatExtRequest{
		Sum: GunHeartSum,
	}
	if GunHeartSum > 255 {
		GunHeartSum = 0
	}
	reqBuff := req.CreateScreenHeartbeatExt()
	if d.Conn != nil {
		n, err := d.Conn.Write(reqBuff)
		logger.Info("receive heart --> c2发送显示屏心跳结果：", GunHeartSum, n, err)
		return
	}
}

func (d *Screen) SendHit(sn string, mode uint8, hitFreq uint8, longitude, latitude, altitude uint16, hitTime uint16) (*mavlink.SetScreenHitResponse, error) {
	if hitTime <= 0 {
		hitTime = 10
	}
	req := &mavlink.SetScreenHitRequest{
		Mode:           mode,
		HitFreq:        hitFreq,
		DroneLongitude: longitude,
		DroneLatitude:  latitude,
		DroneAltitude:  altitude,
		HitTime:        hitTime,
	}
	reqBuff := req.CreateHitRequest()
	n, err := d.Conn.Write(reqBuff)
	logger.Info("发送显示屏打击指令:", n, err)
	if err != nil {
		return nil, err
	}
	manager, ok := d.WaitTaskMap[mavlink.ScreenMsgHit]
	if !ok {
		manager = NewWaitTaskManager(mavlink.ScreenMsgHit, true, 0)
		d.WaitTaskMap[mavlink.ScreenMsgHit] = manager
	}
	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return nil, checkNetConnErr
		}
	}
	return result.(*mavlink.SetScreenHitResponse), nil
}

func (d *Screen) SendUavData(req *client.SendGunHitDataRequest) (*mavlink.SetScreenHitResponse, error) {
	logger.Info("开始发送显示屏打击指令")
	var hitTime uint16 = 10
	if req.HitTime > 0 {
		hitTime = uint16(req.HitTime)
	}
	uavs := make([]*mavlink.ScreenHitData, 0)
	for i := 0; i < len(req.UavList); i++ {
		var dn [20]byte
		copy(dn[:], req.UavList[i].DroneName)
		var sn [16]byte
		copy(sn[:], req.UavList[i].SerialNum)
		uavs = append(uavs, &mavlink.ScreenHitData{
			Mode:               uint8(req.Mode),
			HitFreq:            uint8(req.HitFreq),
			HitTime:            hitTime,
			ObjId:              uint8(req.UavList[i].ObjId),
			ProductType:        uint8(req.UavList[i].ProductType),
			DroneName:          dn,
			SerialNum:          sn,
			DroneLongitude:     int32(req.UavList[i].DroneLongitude * mavlink.DroneReduceValue),
			DroneLatitude:      int32(req.UavList[i].DroneLatitude * mavlink.DroneReduceValue),
			DroneHeight:        int16(req.UavList[i].DroneHeight * 10),
			DroneYawAngle:      int16(req.UavList[i].DroneYawAngle),
			DroneSpeed:         int16(req.UavList[i].DroneSpeed * 10),
			DroneVerticalSpeed: int16(req.UavList[i].DroneVerticalSpeed),
			PilotLongitude:     int32(req.UavList[i].PilotLongitude * mavlink.DroneReduceValue),
			PilotLatitude:      int32(req.UavList[i].PilotLatitude * mavlink.DroneReduceValue),
			UFreq:              uint32(req.UavList[i].UFreq * 10),
			UDistance:          uint16(req.UavList[i].UDistance),
			UDangerLevels:      uint16(req.UavList[i].UDangerLevels),
			X:                  int32(req.UavList[i].X * float32(RadarReducedValue)),
			Y:                  int32(req.UavList[i].Y * float32(RadarReducedValue)),
			Z:                  int32(req.UavList[i].Z * float32(RadarReducedValue)),
		})
	}
	hitData := &mavlink.SendScreenHitDataRequest{}
	reqBuff := hitData.CreateHitRequest(uavs)
	n, err := d.Conn.Write(reqBuff)
	logger.Info("发送显示屏打击指令结果:", n, err)
	if err != nil {
		return nil, err
	}
	return &mavlink.SetScreenHitResponse{Status: 1}, nil
}

func (d *Screen) ReceiveHitResponse() {
	hitRes := &mavlink.SetScreenHitResponse{}
	d.GetPacket(hitRes)
	logger.Info("set hit response :", hitRes.Status)
	manager, ok := d.WaitTaskMap[mavlink.ScreenMsgHit]
	if ok {
		manager.CompletedTask(hitRes, nil)
	}
}

func (d *Screen) ReceiveHitStatus() {
	hitRes := &mavlink.ScreenHitStatus{}
	size := hitRes.Size()
	d.GetPacket(hitRes)
	uavs := hitRes.ReverseHitUav(d.Msg[mavlink.HeaderLen+size : d.MsgLen-mavlink.CrcLen])
	logger.Info("receive hit status:", hitRes)
	info := common.ScreenHitStatusEntity{
		WorkStatus: hitRes.WorkStatus,
		DroneNum:   hitRes.DroneNum,
	}
	for _, v := range uavs {
		item := &common.HitUavEntity{
			ObjId:          uint8(v.GetObjId()),
			ProductType:    uint8(v.GetProductType()),
			DroneName:      v.GetDroneName(),
			SerialNum:      v.GetSerialNum(),
			DroneLongitude: v.GetDroneLongitude(),
			DroneLatitude:  v.GetDroneLatitude(),
			DroneHeight:    int16(v.GetDroneHeight()),
		}
		info.Uavs = append(info.Uavs, item)
	}
	// 发送打击状态给前端
	msg := common.EquipmentMessageBoxEntity{
		Sn:        d.Sn,
		EquipType: int(common.DEV_SCREEN),
		MsgType:   mavlink.SendHitResult,
		Info:      info,
	}
	_ = mq.EquipMessageBoxBroker.Publish(mq.EquipMessageBoxTopic, broker.NewMessage(msg))
	// 判断打击状态，如果为打击中
	if hitRes.WorkStatus != 0 || d.hitComputeStatus {
		return
	}
	status := &mavlink.ScreenHitStatusResponse{Status: 1}
	buf := status.CreateScreenHitStatusResponse()
	n, err := d.Conn.Write(buf)
	logger.Error("send hit status response:", n, err)
	d.hitComputeStatus = true
	// 计算打击结果
	objs := make(map[uint8]uint8)
	for _, uav := range uavs {
		objs[uint8(uav.ObjId)] = 1
	}
	sub, _ := mq.RadarTrackBroker.Subscribe(mq.RadarTrackTopic, func(event broker2.Event) error {
		plotTracks := make([]common.DbRawAutelRadarPlotTrackBodyEntity, 0)
		radarTrackEntity := common.EquipmentMessageBoxEntity{
			Info: plotTracks,
		}
		err := jsoniter.Unmarshal(event.Message().Body, &radarTrackEntity)
		if err != nil {
			return fmt.Errorf("track数据解析错误：%v", err)
		}
		logger.Debug("当前雷达目标：", plotTracks)
		for _, track := range plotTracks {
			if _, ok := objs[uint8(track.Obj_id)]; ok {
				objs[uint8(track.Obj_id)] = 0
			}
		}
		d.hitCompute <- struct{}{}
		return nil
	})
	// 等待
	<-d.hitCompute
	_ = sub.Unsubscribe()
	hitResult := make([]*mavlink.HitResult, 0)
	for obj, res := range objs {
		hitResult = append(hitResult, &mavlink.HitResult{
			ObjId:  obj,
			Result: res,
		})
	}
	hitSucResponse := &mavlink.SendHitResultRequest{
		DroneNum: uint8(len(hitResult)),
	}
	logger.Debug("打击结果：", hitSucResponse)
	// 发送打击结果给屏
	buf2 := hitSucResponse.CreateHitRequest(hitResult)
	n, err = d.Conn.Write(buf2)
	logger.Error("给显示屏发送打击结果:", n, err)
	msg2 := common.EquipmentMessageBoxEntity{
		Sn:        d.Sn,
		EquipType: int(common.DEV_SCREEN),
		MsgType:   mavlink.ScreenHitResult,
		Info:      hitResult,
	}
	_ = mq.EquipMessageBoxBroker.Publish(mq.EquipMessageBoxTopic, broker.NewMessage(msg2))
	d.hitComputeStatus = false
}

func (d *Screen) cacheConn(sn string) string {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_SCREEN, sn)
	cache, ok := DevStatusMap.Load(cacheKey)
	logger.Info("缓存显示屏存连接:", cacheKey, ok)
	logger.Infof("显示屏更新信息: WaitTaskMap=%p\n", d.WaitTaskMap)
	if !ok {
		//如果不存在则根据消息id创建一个,这里不做保持，在心跳那里保存
		dev := &Device{
			Sn:             sn,
			Conn:           d.Conn,
			Status:         common.DevOffline,
			RemoteIp:       d.RemoteIp,
			RemotePort:     d.RemotePort,
			LocalIp:        d.LocalIp,
			ServerPort:     d.ServerPort,
			DevType:        common.DEV_SCREEN,
			FirstHeartTime: time.Now(),
			LastHeartTime:  time.Now(),
			SourceId:       d.SourceId,
			IsEnable:       d.IsEnable,
			WaitTaskMap:    d.WaitTaskMap,
		}
		DevStatusMap.Store(cacheKey, dev)
		logger.Debug("[cacheConn_Screen] DevStatus Stroe sn:", sn)
		go func() {
			time.Sleep(time.Second * 2)
			devGun := FindCacheDevice(sn, common.DEV_SCREEN)
			if devGun == nil || devGun.Conn == nil {
				return
			}
			gun := &CounterGun{Device: dev}
			runVer, ver, bootVer, hwVer, protocolVer, err := gun.SendGetAEAGSoftVer(sn)
			logger.Infof("gun get  Ver: %v, %v, %v, %v, %v \n",
				runVer, ver, bootVer, hwVer, protocolVer)
			if err != nil {
				logger.Infof("gun get  Ver runVer: %v err: %v \n", runVer, err)
			}
			if ver != "" {
				err = NewEquipList().Update(context.Background(), &client.EquipCrudReq{
					Sn:         sn,
					DevVersion: ver,
				}, &client.EquipCrudRes{})
				if err != nil {
					logger.Error("Update EquipList err: ", err)
				}
			}
		}()
		return sn
	}
	if d.WaitTaskMap != nil && d.Conn != nil {
		dev := cache.(*Device)
		dev.Conn = d.Conn
		dev.WaitTaskMap = d.WaitTaskMap
		dev.IsEnable = d.IsEnable
	}
	return sn
}

// UpdateStatus 更新连接和在线状态
func (d *Screen) UpdateStatus(sn string) {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_SCREEN, sn)
	logger.Info("更新显示屏缓存连接:", cacheKey)
	if cache, ok := DevStatusMap.Load(cacheKey); ok {
		dev := cache.(*Device)
		dev.LastHeartTime = time.Now()
		dev.Status = common.DevOnline
		dev.Conn = d.Conn
		dev.WaitTaskMap = d.WaitTaskMap
		return
	}
}

// UpdateConn 更新连接
func (d *Screen) UpdateConn(tcpServer *server.TcpServer) {
	for {
		if tcpServer.Status == server.TcpServerNormal {
			select {
			case serverCon := <-tcpServer.ConnCh:
				logger.Debugf("UpdateConn DevSn %v", serverCon.DevSn)
				logger.Debugf("UpdateConn serverCon %v", serverCon.Conn)
				remoteAddr := strings.Split(serverCon.Conn.RemoteAddr().String(), ":")
				var mailBox map[int]*WaitTaskManager
				mbox, ok := GWaitTaskMap.Load(remoteAddr[0])
				if !ok {
					mailBox = make(map[int]*WaitTaskManager)
					GWaitTaskMap.Store(remoteAddr[0], mailBox)
				} else {
					mailBox = mbox.(map[int]*WaitTaskManager)
				}
				d.WaitTaskMap = mailBox
				d.Conn = serverCon.Conn
				d.cacheConn(serverCon.DevSn)
			case <-tcpServer.Ctx.Done():
				return
			}
		}
	}
}

func (d *Screen) ReceiveGetChannelReq() {
	screenTcpServerLock.Lock()
	defer screenTcpServerLock.Unlock()
	devSn := d.UnMarshalGetChannelReq()
	//fmt.Println("显示屏获取信道：", devSn)
	if devSn == "" {
		logger.Info("显示屏获取信道不能sn为空")
		return
	}
	if status := d.GetStatus(devSn); status == common.DeviceDisenable {
		logger.Infof("device %v disable", devSn)
		return
	}

	localIP := make([]string, 0)

	localIps, broadIps, err := ip.GetBroadcastAddress()
	if err != nil {
		logger.Error("Get IP error :%v", err)
	}
	for i, ip := range localIps {
		if i >= len(broadIps) {
			continue
		}
		localIP = append(localIP, ip)
	}
	logger.Debug("[gun] localIP:%v,", localIP)
	tcpServer := d.TcpServerCheck(devSn, localIP)
	d.ServerPort = tcpServer.Port

	switch d.MsgId {
	case mavlink.ScreenIdGetChannel:
		addr := d.LocalIp
		res := &mavlink.ScreenGetChannelResponse{}
		resBuff := res.CreateGetChannelResponse(addr, uint16(tcpServer.Port))
		n, err := d.Conn.Write(resBuff)
		logger.Info("显示屏响应获取信道：", addr, n, err)
		break
	case mavlink.RadarUdpBroadcastResponse:
		//暂时调回原来的
		logger.Info("--> receive Gun Udp Broadcast Response")
		UdpBroadcastSendChannel(devSn, d.UdpIp, d.SourceId, tcpServer)
		return
	default:
		break
	}
	return
}

func (d *Screen) UnMarshalGetChannelReq() string {
	devSn := ""
	switch d.MsgId {
	case mavlink.ScreenIdGetChannel:
		req := &mavlink.ScreenGetChannelRequest{}
		d.GetPacket(req)
		devSn = strings.TrimRight(string(req.Sn[:]), string(rune(0)))
		break
	case mavlink.RadarUdpBroadcastResponse:
		req := &mavlink.UdpBroadcastConfirmRequest{}
		d.GetPacket(req)
		devSn = strings.TrimRight(string(req.Sn[:]), string(rune(0)))
		break
	default:
		break
	}
	return devSn
}

func (d *Screen) TcpServerCheck(devSn string, localIp []string) *server.TcpServer {
	var tcpServer *server.TcpServer
	if s, ok := ScreenTcpServerMap.Load(devSn); ok {
		tcpServer = s.(*server.TcpServer)
		isAlike := false
		for _, ip := range localIp {
			if ip == tcpServer.Ip {
				isAlike = true
			}
		}
		if isAlike == false { //查找的本地IP没有与之前相同的
			if tcpServer != nil {
				tcpServer.Stop()
			}
			deviceUsedPorts.Delete(tcpServer.Port)
			ScreenTcpServerMap.Delete(devSn)
			DevSnMap.Delete(tcpServer.Port)
			tcpServer = nil
		}

	}
	if tcpServer == nil {
		localAddr, _ := ip.GetLocalIp(d.UdpIp)
		//注册tcp服务
		port, err := ip.GetFreeTcpPort()
		if err != nil {
			logger.Error("screen tcp 获取可用端口失败：", err)
			port = d.getRandPort(ScreenTcpPort, ScreenTcpPort+ScreenServerMaxCount)
		}
		tcpServer = server.NewTcpServer(port, Handle)
		ScreenTcpServerMap.Store(devSn, tcpServer)
		tcpServer.ServerType = uint8(common.DEV_SCREEN)
		tcpServer.ServerName = devSn
		tcpServer.NeedUpdateConn = true
		go tcpServer.Start()
		go d.UpdateConn(tcpServer)
		SnMaps.Store(tcpServer.Port, devSn)
		tcpServer.Ip = localAddr
		tcpServer.LastHeartTime = time.Now()
		//雷达通过sourceId 关联，屏和枪通过port
	}
	return tcpServer
}

func (d *Screen) getPort() int {
	screenPortMutex.Lock()
	defer screenPortMutex.Unlock()
	startPort := int(ScreenTcpPort)
	usedPort, ok := deviceUsedPorts.Load(startPort)
	for ok && usedPort.(int) > 0 {
		startPort++
		usedPort, ok = deviceUsedPorts.Load(startPort)
	}
	deviceUsedPorts.Store(startPort, startPort)
	return startPort
}

func (d *Screen) getRandPort(min, max int64) int {
	maxBigInt := big.NewInt(max)
	i, _ := rand.Int(rand.Reader, maxBigInt)
	_, ok := deviceUsedPorts.Load(i.Int64())
	port := i.Int64()
	//缓存不存在或者符合范围
	if !ok && (port > min && port < max) {
		deviceUsedPorts.Store(port, port)
		return int(port)
	}
	return d.getRandPort(min, max)
}

func (d *Screen) getCacheSn() string {
	sn := ""
	if v, ok := SnMaps.Load(d.ServerPort); ok {
		sn = v.(string)
	}
	return sn
}

func (d *Screen) GetPacket(message mavlink.Message) *mavlink.MavPacket {
	logger.Infof("GetPacket is [% x]", d.Msg)
	req := mavlink.NewNullPacket(message)
	buff := &bytes.Buffer{}
	if err := binary.Write(buff, binary.LittleEndian, d.Msg); err != nil {
		logger.Error("GetPacket write buff err:", err)
		return nil

	}
	if err := binary.Read(buff, binary.LittleEndian, &req.Header); err != nil {
		logger.Error("GetPacket read header err:", err)
		return nil
	}
	if err := binary.Read(buff, binary.LittleEndian, req.Msg); err != nil {
		logger.Error("GetPacket read msg err:", err)
		return nil
	}
	return req
}

func SendScreenHeart() {
	ticker := time.NewTicker(time.Second * 1)
	defer ticker.Stop()
	for range ticker.C {
		DevStatusMap.Range(func(key, value interface{}) bool {
			dev := value.(*Device)
			if dev.DevType == common.DEV_SCREEN && dev.Status == common.DevOnline {
				reqMode := &Screen{
					Device: dev,
					dt:     common.DEV_SCREEN,
				}
				reqMode.SendExtHeartbeat()
			}
			return true
		})
	}
}

func (d *Screen) SendExtHeartbeat() error {
	GunHeartSum++
	if GunHeartSum > 255 {
		GunHeartSum = 0
	}
	req := &mavlink.ScreenHeartbeatExtRequest{
		Sum: GunHeartSum,
	}
	reqBuff := req.CreateScreenHeartbeatExt()
	if d != nil && d.Conn != nil {
		n, err := d.Conn.Write(reqBuff)
		logger.Info("c2发送显示屏心跳结果：", GunHeartSum, n, err)
		if err != nil {
			dataInfo := &client.ScreenHeartBeatInfo{
				Header: &client.EquipmentMessageBoxEntity{
					Name:      d.Sn,
					Sn:        d.Sn,
					EquipType: int32(common.DEV_SCREEN),
					MsgType:   mavlink.ScreenIdHeart,
				},
				Data: &client.ScreenHeartBeatEntity{

					IsOnline: common.DevOffline,
				},
			}
			msg, err := proto.Marshal(dataInfo)
			if err != nil {
				logger.Error("marshal dataInfo err:", err)
				return err
			}
			report := &client.ClientReport{
				MsgType: common.ClientMsgIDAEAGHeartBeat,
				Data:    msg,
			}
			out, err := proto.Marshal(report)
			if err != nil {
				logger.Error("marshal report err:", err)
				return err
			}
			_ = mq.GunDroneIdBroker.Publish(mq.GunDroneIdTopic, broker.NewMessage(out))
			logger.Info("send gun offline:", report)
		}
		return err
	}
	return nil
}

func (d *Screen) SendCloseConn(sn string) (*mavlink.ScreenCloseConnResponse, error) {
	d.IsEnable = common.DeviceDisenable
	if err := d.Conn.Close(); err != nil {
		logger.Error("关闭显示屏tcp错误:", err)
		return nil, err
	}
	var tcpServer *server.TcpServer
	if s, ok := ScreenTcpServerMap.Load(sn); ok {
		tcpServer = s.(*server.TcpServer)
		if true {
			if tcpServer != nil {
				tcpServer.Stop()
			}
			deviceUsedPorts.Delete(tcpServer.Port)
			ScreenTcpServerMap.Delete(sn)
			DevSnMap.Delete(sn)
			tcpServer = nil
		}
	}
	logger.Info("关闭显示屏成功")

	return &mavlink.ScreenCloseConnResponse{
		Status: 1,
	}, nil
}

func (d *Screen) GetStatus(sn string) int32 {
	statusRes := &client.GetStatusRes{}
	err := NewEquipList().GetStatus(context.Background(), &client.GetStatusReq{Sn: sn, EType: "RF"}, statusRes)
	if err != nil {
		logger.Errorf("GetStatus err: %v", err.Error())
		return 0
	}

	return statusRes.IsEnable
}

func (d *Screen) GetGunSn() (string, error) {
	req := &mavlink.GetAEAGSnRequest{}
	buff := req.CreateGetSnRequest()
	if _, err := d.Conn.Write(buff); err != nil {
		return "", err
	}
	msgId := mavlink.AEAGMsgGetSn
	manager, ok := d.WaitTaskMap[msgId]
	if !ok {
		manager = NewWaitTaskManager(msgId, true, 0)
		d.WaitTaskMap[msgId] = manager
	}
	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return "", checkNetConnErr
		}
	}
	return result.(string), nil
}

func (d *Screen) deviceDiscover(sn string) bool {
	return true
}

func ScreenOfflineReport(sn, remoteIp string) {
	var tcpServer *server.TcpServer
	if s, ok := ScreenTcpServerMap.Load(sn); ok {
		tcpServer = s.(*server.TcpServer)

		if tcpServer != nil {
			tcpServer.Stop()
		}
		deviceUsedPorts.Delete(tcpServer.Port)
		ScreenTcpServerMap.Delete(sn)
		DevSnMap.Delete(tcpServer.Port)
		tcpServer = nil
	}

	dataInfo := &client.ScreenHeartBeatInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      sn,
			Sn:        sn,
			EquipType: int32(common.DEV_SCREEN),
			MsgType:   mavlink.ScreenIdHeart,
		},
		Data: &client.ScreenHeartBeatEntity{

			IsOnline: common.DevOffline,
		},
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIDAEAGHeartBeat,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}
	_ = mq.GunDroneIdBroker.Publish(mq.GunDroneIdTopic, broker.NewMessage(out))
	logger.Info("send gun offline:", report)
}

// ScreenResetSystem 系统复位
func (d *Screen) ScreenResetSystem(rq *client.ResetSystemRequest) (int32, error) {
	logger.Info("ScreenResetSystem Start")
	defer func() {
		if r := recover(); r != nil {
			logger.Error("Screen Reset System occurred:", r)
			return
		}
	}()
	req := &mavlink.ScreenResetSystemRequest{
		ResetCode: mavlink.ScreenOtaReSetCode,
		Type:      uint16(4),
	}
	buff := req.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.ScreenIdResetSystem]
	if !ok {
		manager = NewWaitTaskManager(mavlink.ScreenIdResetSystem, true, 20*time.Second)
		logger.Infof("ScreenResetSystem WaitTaskMap=%p\n", d.WaitTaskMap)
		if d.WaitTaskMap == nil {
			return 1, errors.New("ScreenResetSystem err")
		}
		d.WaitTaskMap[mavlink.ScreenIdResetSystem] = manager
	}
	task := manager.AddTask(nil, nil)
	fmt.Println(buff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("ScreenResetSystem 发送反制抢系统复位信息失败: ", err)
		return 1, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 1, checkNetConnErr
		}
		return 1, err
	}
	res := result.(*mavlink.ScreenResetSystemResponse)

	logger.Infof("ScreenResetSystem res %v \n", res)
	logger.Info("ScreenResetSystem End")
	return int32(res.Status), nil
}

// ReceiveScreenResetSystem 获取系统复位响应
func (d *Screen) ReceiveScreenResetSystem() {
	res := &mavlink.ScreenResetSystemResponse{}
	d.GetPacket(res)
	logger.Debugf("系统复位回复信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.ScreenIdResetSystem]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// ReceiveScreenGetTime 获取系统复位响应
func (d *Screen) ReceiveScreenGetTime() {
	logger.Info("--->Into Send Time To Screen")
	res := &mavlink.ScreenGetTimeResponse{}
	time1 := time.Now()
	resTime := time1.Format("20060102150405")

	var byteArr [20]byte
	for k := range resTime {
		byteArr[k] = resTime[k]
	}

	rspBuf := res.CreateGetTimeMessage(byteArr)
	n, err := d.Conn.Write(rspBuf)

	logger.Debugf("Send Time To Screen:%v,%#v", n, res)
	if err != nil {
		logger.Error("Send Time To Screen err:", err)
		return
	}
	logger.Info("--->End Send Time To Screen")
	return
}

// HandleBroadCast 处理广播消息
func (s *Screen) HandleBroadCast(ctx context.Context, req *slinkv1.UdpBroadcastConfirmRequest) (*slinkv1.UdpBroadcastConfirmResponse, error) {
	if req.GetSn() == "" {
		logger.Info("显示屏获取信道不能sn为空")
		return nil, nil
	}
	if status := s.GetStatus(req.GetSn()); status == common.DeviceDisenable {
		logger.Infof("device %v disable", req.GetSn())
		return nil, nil
	}

	localIP := make([]string, 0)
	localIps, broadIps, err := ip.GetBroadcastAddress()
	if err != nil {
		logger.Error("Get IP error :%v", err)
	}
	for i, ip := range localIps {
		if i >= len(broadIps) {
			continue
		}
		localIP = append(localIP, ip)
	}
	logger.Debug("[gun] localIP:%v,", localIP)
	tcpServer := s.TcpServerCheck(req.GetSn(), localIP)
	s.ServerPort = tcpServer.Port
	logger.Info("--> receive Gun Udp Broadcast Response")
	err = NewEquipList().Update(context.Background(), &client.EquipCrudReq{
		Sn: req.GetSn(),
		Ip: s.UdpIp,
	}, &client.EquipCrudRes{})
	if err != nil {
		logger.Error("Update EquipList err: ", err)
		return nil, nil
	}
	rsp := &slinkv1.UdpBroadcastConfirmResponse{
		Sn:       req.Sn,
		Addr:     ip.IPV4(tcpServer.Ip),
		Port:     uint16(tcpServer.Port),
		ConnType: 1,
	}
	logger.Debug(" BC msg is :", rsp)
	return rsp, nil
}

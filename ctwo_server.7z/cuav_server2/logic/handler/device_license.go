package handler

import (
	"context"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/awsS3"
)

// ReqC2License License功能
func (e *DeviceCenter) ReqC2License(ctx context.Context, req *client.ReqC2LicenseRequest, rsp *client.ReqC2LicenseResponse) error {
	rsp.Result = true
	macAddr, err := awsS3.GetMacAddr()
	if err != nil {
		rsp.Result = false
		logger.Error("Get Mac Addr err:", err)
	}

	err = awsS3.InsertLicense(macAddr)
	if err != nil {
		rsp.Result = false
		logger.Error("Insert Mac Addr err:", err)
	}
	err, licenseList := awsS3.GetLicenseList()
	if err != nil {
		rsp.Result = false
		logger.Error("Get License List err:", err)
	}
	for _, str := range licenseList.Data.List {
		if macAddr == str.MacAddr {
			//设备license记录到数据库
			res := &client.C2LicenseInsertRsp{}
			if err = NewC2License().Insert(ctx, &client.C2LicenseInsertReq{
				LicenseId:   str.LicenseId,
				MacAddr:     str.MacAddr,
				StartTime:   str.StartTime,
				StopTime:    str.StopTime,
				LastTime:    str.LastTime,
				Expires:     str.Expires,
				LicenseType: str.LicenseType,
				UserName:    str.UserName,
				UserPhone:   str.UserPhone,
				UserEmail:   str.UserEmail,
			}, res); err != nil {
				rsp.Result = false
				logger.Error("Log Stat Insert err : ", err)
			}
			// 解析时间字符串
			t1, _ := time.Parse("2006-01-02-15", str.StopTime)
			t2, _ := time.Parse("2006-01-02-15", str.LastTime)
			// 计算时间差
			diff := t1.Sub(t2)
			// 将时间差转换成小时
			hours := int(diff.Hours())
			if hours < 0 {
				rsp.Result = false
			}
		}
	}

	logger.Info("-->End Req C2 License")
	return nil
}

package handler

import (
	"fmt"
	"time"

	"adasgitlab.autel.com/tools/cuav_server/entity/common"
)

var (
	ReplayheartName  = fmt.Sprintf("_%s_", common.HeartSqlTbName)
	ReplayspecName   = fmt.Sprintf("_%s_", common.SpectrumSqlTbName)
	ReplayDetectName = fmt.Sprintf("_%s_", common.DetectSqlTbName)
)

// equipTypeToName 后面可以抽出作为公共函数使用
func equipTypeToName(msgType int) string {
	switch msgType {
	case UrdDroneInfoType:
		return ReplayDetectName
	case UrdSpectrumType:
		return ReplayspecName
	case UrdDeviceInfoType:
		return ReplayheartName
	default:
		return "_unknow_"
	}
}

// TableName ..
func TableName(sn string, msgType int) string {
	return fmt.Sprintf("%s%s%s", sn, equipTypeToName(msgType), time.Now().Format("20060102"))
}

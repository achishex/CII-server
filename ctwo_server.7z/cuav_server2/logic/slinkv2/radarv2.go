package slinkv2

import (
	"adasgitlab.autel.com/tools/slink_proto/slinkv2/generatecode/golang/bizproto"
	"adasgitlab.autel.com/tools/slink_proto/slinkv2/msgid"

	entity "adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/rpc/codec"
)

func init() {
	radarV2Detect := &bizproto.RadarDetect{}
	codec.Instance().Register(entity.DEV_RADAR, msgid.RadarIdV2Detect, radarV2Detect)

	radarV2DotCohe := &bizproto.RadarDotCohe{}
	codec.Instance().Register(entity.DEV_RADAR, msgid.RadarIdV2DotCohe, radarV2DotCohe)

	radarV2Track := &bizproto.RadarTrack{}
	codec.Instance().Register(entity.DEV_RADAR, msgid.RadarIdV2Track, radarV2Track)

	radarV2State := &bizproto.RadarState{}
	codec.Instance().Register(entity.DEV_RADAR, msgid.RadarIdV2State, radarV2State)

	radarV2BeamSchedule := &bizproto.RadarBeamScheduling{}
	codec.Instance().Register(entity.DEV_RADAR, msgid.RadarIdV2BeamScheduling, radarV2BeamSchedule)

	radarV2SetBeamSchedule := &bizproto.RadarSetBeamSchedulingRsp{}
	codec.Instance().Register(entity.DEV_RADAR, msgid.RadarIdV2SetBeamScheduling, radarV2SetBeamSchedule)

	radarV2SetConfig := &bizproto.RadarConfigRsp{}
	codec.Instance().Register(entity.DEV_RADAR, msgid.RadarIdV2SetConfig, radarV2SetConfig)

	radarV2GetConfig := &bizproto.RadarReadConfigRsp{}
	codec.Instance().Register(entity.DEV_RADAR, msgid.RadarIdV2GetConfig, radarV2GetConfig)

	radarV2SetSetting := &bizproto.RadarSetRsp{}
	codec.Instance().Register(entity.DEV_RADAR, msgid.RadarIdV2SetSetting, radarV2SetSetting)

	radarV2SetAttitudeLLA := &bizproto.RadarSetAttitudeLLARsp{}
	codec.Instance().Register(entity.DEV_RADAR, msgid.RadarIdV2SetAttitudeLLA, radarV2SetAttitudeLLA)
}

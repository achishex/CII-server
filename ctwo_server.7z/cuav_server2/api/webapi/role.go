package webapi

import (
	"context"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"github.com/emicklei/go-restful"
)

type roleApi struct {
}

var (
	RoleApi = new(roleApi)
)

func (r *roleApi) Insert(req *restful.Request, res *restful.Response) {
	roleReq := &client.CreateReq{}
	roleRsp := &client.CreateRes{}
	err := req.ReadEntity(roleReq)
	if err != nil {
		logger.Errorf("bind create params[%v] error:%v", roleReq, err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	err = handler.NewRole().CreateRole(context.Background(), roleReq, roleRsp)
	Result(err, res)
}

func (r *roleApi) Update(req *restful.Request, res *restful.Response) {
	roleReq := &client.UpdateRoleReq{}
	roleRsp := &client.UpdateRoleRes{}
	err := req.ReadEntity(roleReq)
	if err != nil {
		logger.Errorf("bind update  params[%v] error:%v", roleReq, err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	err = handler.NewRole().UpdateRole(context.Background(), roleReq, roleRsp)
	Result(err, res)
}

func (r *roleApi) Delete(req *restful.Request, res *restful.Response) {
	roleReq := &client.RoleIds{}
	roleRsp := &client.DeleteRes{}
	err := req.ReadEntity(roleReq)
	if err != nil {
		logger.Errorf("bind delete params[%v] error:%v", roleReq, err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	err = handler.NewRole().BatchDeleteRoleByIds(context.Background(), roleReq, roleRsp)
	Result(err, res)
}

func (r *roleApi) List(req *restful.Request, res *restful.Response) {
	roleReq := &client.ListReq{}
	roleRsp := &client.ListRes{}
	err := req.ReadEntity(roleReq)
	if err != nil {
		logger.Errorf("bind list  params[%v] error:%v", roleReq, err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	err = handler.NewRole().GetRoles(context.Background(), roleReq, roleRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(roleRsp.Roles, res)
}

func init() {
	RegistHandler("/role/list", RoleApi.List)
	RegistHandler("/role/create", RoleApi.Insert)
	RegistHandler("/role/update", RoleApi.Update)
	RegistHandler("/role/delete", RoleApi.Delete)
}

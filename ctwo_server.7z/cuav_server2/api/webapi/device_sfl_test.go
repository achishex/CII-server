package webapi

import (
	"context"
	"net/http"
	"net/http/httptest"
	"reflect"
	"strings"
	"testing"

	"github.com/agiledragon/gomonkey"
	"github.com/emicklei/go-restful"
	"github.com/stretchr/testify/assert"

	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
)

//func Test_deviceManager_SflDetectInfo(t *testing.T) {
//	data := `{"version":"v1.0.0.15","start_time":1697081206583,"end_time":1697086394709}`
//	req := httptest.NewRequest(http.MethodPost, "/device/sfl/detect-info", strings.NewReader(data))
//	req.Header.Set("Content-Type", "application/json")
//	rsp := httptest.NewRecorder()
//
//	e := &handler.DeviceCenter{}
//	patches := gomonkey.NewPatches()
//	patches.ApplyMethod(reflect.TypeOf(e), "SflDetectInfo", func(_ *handler.DeviceCenter, _ context.Context, req *client.SflDetectInfoRequest, rsp *client.SflDetectInfoResponse) error {
//		return nil
//	})
//	defer patches.Reset()
//	type args struct {
//		req *restful.Request
//		res *restful.Response
//	}
//	tests := []struct {
//		name string
//		e    *deviceManager
//		args args
//	}{
//		{
//			name: "Case1",
//			e:    &deviceManager{},
//			args: args{
//				req: restful.NewRequest(req),
//				res: restful.NewResponse(rsp),
//			},
//		},
//	}
//	for _, tt := range tests {
//		t.Run(tt.name, func(t *testing.T) {
//			e := &deviceManager{}
//			e.SflDetectInfo(tt.args.req, tt.args.res)
//			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
//		})
//	}
//}

func Test_deviceManager_SflGetPower(t *testing.T) {
	data := `{"sn":"v1.0.0.15"}`
	req := httptest.NewRequest(http.MethodPost, "/device/sfl/get-onoff", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	e := &handler.DeviceCenter{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(e), "SflGetPower", func(_ *handler.DeviceCenter, _ context.Context, req *client.SflGetPowerRequest, rsp *client.SflGetPowerResponse) error {
		return nil
	})
	defer patches.Reset()
	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		e    *deviceManager
		args args
	}{
		{
			name: "Case1",
			e:    &deviceManager{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			e := &deviceManager{}
			e.SflGetPower(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}

func Test_deviceManager_SflGetStatus(t *testing.T) {
	data := `{"sn":"v1.0.0.15"}`
	req := httptest.NewRequest(http.MethodPost, "/device/sfl/get-status", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	e := &handler.DeviceCenter{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(e), "SflGetStatus", func(_ *handler.DeviceCenter, _ context.Context, req *client.SflGetStatusRequest, rsp *client.SflGetStatusResponse) error {
		return nil
	})
	defer patches.Reset()
	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		e    *deviceManager
		args args
	}{
		{
			name: "Case1",
			e:    &deviceManager{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			e := &deviceManager{}
			e.SflGetStatus(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}

func Test_deviceManager_SflGetVersionInfo(t *testing.T) {
	data := `{"version":"v1.0.0.15"}`
	req := httptest.NewRequest(http.MethodPost, "/device/sfl/get-version-info", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	e := &handler.DeviceCenter{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(e), "SflGetVersionInfo", func(_ *handler.DeviceCenter, _ context.Context, req *client.SflGetVersionRequest, rsp *client.SflGetVersionResponse) error {
		return nil
	})
	defer patches.Reset()
	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		e    *deviceManager
		args args
	}{
		{
			name: "Case1",
			e:    &deviceManager{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			e := &deviceManager{}
			e.SflGetVersionInfo(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}

func Test_deviceManager_SflHitAngle(t *testing.T) {
	data := `{"sn":"v1.0.0.15","hit_angle_begin":1,"hit_angle_end":200,"hit_time":30,"hit_pitch_begin":5,"hit_pitch_end":15,"hit_mode":2}`
	req := httptest.NewRequest(http.MethodPost, "/device/sfl/hit-angle", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	e := &handler.DeviceCenter{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(e), "SflHitAngleSet", func(_ *handler.DeviceCenter, _ context.Context, req *client.SflHitAngleRequest, rsp *client.SflHitAngleResponse) error {
		return nil
	})
	defer patches.Reset()

	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		e    *deviceManager
		args args
	}{
		{
			name: "Case1",
			e:    &deviceManager{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			e := &deviceManager{}
			e.SflHitAngle(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}

//func Test_deviceManager_SflHitUav(t *testing.T) {
//	data := `{"version":"v1.0.0.15"}`
//	req := httptest.NewRequest(http.MethodPost, "/device/sfl/hit-angle", strings.NewReader(data))
//	req.Header.Set("Content-Type", "application/json")
//	rsp := httptest.NewRecorder()
//
//	e := &handler.DeviceCenter{}
//	patches := gomonkey.NewPatches()
//	patches.ApplyMethod(reflect.TypeOf(e), "SflHitAngle", func(_ *handler.DeviceCenter, _ context.Context, req *client.SflGetVersionRequest, rsp *client.SflGetVersionResponse) error {
//		return nil
//	})
//	defer patches.Reset()
//	type args struct {
//		req *restful.Request
//		res *restful.Response
//	}
//	tests := []struct {
//		name string
//		e    *deviceManager
//		args args
//	}{
//		{
//			name: "Case1",
//			e:    &deviceManager{},
//			args: args{
//				req: restful.NewRequest(req),
//				res: restful.NewResponse(rsp),
//			},
//		},
//	}
//	for _, tt := range tests {
//		t.Run(tt.name, func(t *testing.T) {
//			e := &deviceManager{}
//			e.SflHitAngle(tt.args.req, tt.args.res)
//			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
//		})
//	}
//}

func Test_deviceManager_SflOnOff(t *testing.T) {
	data := `{"sn":"v1.0.0.15","switch":1}`
	req := httptest.NewRequest(http.MethodPost, "/device/sfl/on-off", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	e := &handler.DeviceCenter{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(e), "SflOnOffSet", func(_ *handler.DeviceCenter, _ context.Context, req *client.SflOnOffRequest, rsp *client.SflOnOffResponse) error {
		return nil
	})
	defer patches.Reset()
	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		e    *deviceManager
		args args
	}{
		{
			name: "Case1",
			e:    &deviceManager{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			e := &deviceManager{}
			e.SflOnOff(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}

func Test_deviceManager_SflResetting(t *testing.T) {
	data := `{"sn":"v1.0.0.15","switch":1}`
	req := httptest.NewRequest(http.MethodPost, "/device/sfl/resetting", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	e := &handler.DeviceCenter{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(e), "SflReSet", func(_ *handler.DeviceCenter, _ context.Context, req *client.SflResetRequest, rsp *client.SflResetResponse) error {
		return nil
	})
	defer patches.Reset()
	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		e    *deviceManager
		args args
	}{
		{
			name: "Case1",
			e:    &deviceManager{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			e := &deviceManager{}
			e.SflResetting(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}

func Test_deviceManager_SflStopHit(t *testing.T) {
	data := `{"sn":"v1.0.0.15"}`
	req := httptest.NewRequest(http.MethodPost, "/device/sfl/stop-hit", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	e := &handler.DeviceCenter{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(e), "SflStopHitSet", func(_ *handler.DeviceCenter, _ context.Context, req *client.SflStopHitRequest, rsp *client.SflStopHitResponse) error {
		return nil
	})
	defer patches.Reset()
	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		e    *deviceManager
		args args
	}{
		{
			name: "Case1",
			e:    &deviceManager{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			e := &deviceManager{}
			e.SflStopHit(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}

func Test_deviceManager_SflGetHitMode(t *testing.T) {
	data := `{"sn":"v1.0.0.15"}`
	req := httptest.NewRequest(http.MethodPost, "/device/sfl/get-hit-mode", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	e := &handler.DeviceCenter{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(e), "SflGetHitMode", func(_ *handler.DeviceCenter, _ context.Context, req *client.SflGetHitModeRequest, rsp *client.SflGetHitModeResponse) error {
		return nil
	})
	defer patches.Reset()
	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		e    *deviceManager
		args args
	}{
		{
			name: "Case1",
			e:    &deviceManager{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			e := &deviceManager{}
			e.SflGetHitMode(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}

func Test_deviceManager_SflSetHitMode(t *testing.T) {
	data := `{"sn":"v1.0.0.15","hit_mode":1}`
	req := httptest.NewRequest(http.MethodPost, "/device/sfl/set-hit-mode", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	e := &handler.DeviceCenter{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(e), "SflSetHitMode", func(_ *handler.DeviceCenter, _ context.Context, req *client.SflSetHitModeRequest, rsp *client.SflSetHitModeResponse) error {
		return nil
	})
	defer patches.Reset()
	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		e    *deviceManager
		args args
	}{
		{
			name: "Case1",
			e:    &deviceManager{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			e := &deviceManager{}
			e.SflSetHitMode(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}

func Test_deviceManager_FindSflDetectExportInfo(t *testing.T) {
	data := `{"startTime":"1708416887","endTime":"1708416926","filePath":"D:/Gocode/cuav_server2/test.csv"}`
	req := httptest.NewRequest(http.MethodPost, "/device/sfl/detect-info-export", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()
	e := &deviceManager{}
	e.SflDetectInfoExport(restful.NewRequest(req), restful.NewResponse(rsp))
}

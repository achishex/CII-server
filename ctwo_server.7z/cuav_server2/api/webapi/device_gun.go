package webapi

import (
	"context"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"github.com/emicklei/go-restful"
)

func (e *deviceManager) GunGetSoftVer(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GunGetSoftVersionRequest{}
	deviceRsp := &client.GunGetSoftVersionResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		logger.Errorf("parse GunGetSoftVer params[%v] error:%v", deviceReq, err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().GunGetSoftVer(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

func (e *deviceManager) GunSetWhiteList(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GunSetWhiteListRequest{}
	deviceRsp := &client.GunSetWhiteListResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		logger.Errorf("parse GunSetWhiteList params[%v] error:%v", deviceReq, err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().GunSetWhiteList(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

func (e *deviceManager) GunGetWhiteList(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GunGetWhiteListRequest{}
	deviceRsp := &client.GunGetWhiteListResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		logger.Errorf("parse GunGetWhiteLis params[%v] error:%v", deviceReq, err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().GunGetWhiteList(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

func (e *deviceManager) GunHit(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GunHitRequest{}
	deviceRsp := &client.GunHitResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		logger.Errorf("parse GunHit params[%v] error:%v", deviceReq, err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().GunHit(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

func (e *deviceManager) GunSendHitData(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SendGunHitDataRequest{}
	deviceRsp := &client.SendGunHitDataResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		logger.Errorf("parse GunHit params[%v] error:%v", deviceReq, err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().SendGunHitData(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

func (e *deviceManager) GunSetEnable(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GunSetStatusRequest{}
	deviceRsp := &client.GunSetStatusResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		logger.Errorf("parse GunSetEnable params[%v] error:%v", deviceReq, err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	//禁用的时候才需要发
	if deviceReq.Status == 2 {
		if err = handler.NewDeviceCenter().GunSetStatus(context.Background(), deviceReq, deviceRsp); err != nil {
			ParameterBindFail(500, err.Error(), res)
			return
		}
	}
	setStatusRes := &client.SetEnableRes{}
	err = handler.NewEquipList().SetEnableState(context.Background(), &client.SetEnableReq{Sn: deviceReq.Sn, Status: deviceReq.Status, EType: "RF"}, setStatusRes)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(setStatusRes, res)
}

func init() {
	RegistHandler("/device/gun/get-soft-ver", DeviceManagerApi.GunGetSoftVer)
	RegistHandler("/device/gun/set-white-list", DeviceManagerApi.GunSetWhiteList)
	RegistHandler("/device/gun/hit", DeviceManagerApi.GunHit)
	RegistHandler("/device/gun/send-hit-data", DeviceManagerApi.GunSendHitData)
	RegistHandler("/device/gun/get-white-list", DeviceManagerApi.GunGetWhiteList)
	RegistHandler("/device/gun/set-enable", DeviceManagerApi.GunSetEnable)
}

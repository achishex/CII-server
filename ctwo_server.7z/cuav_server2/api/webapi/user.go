// Package api 用户管理
package webapi

import (
	"context"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/entity/jwttoken"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/logic/uploadcloud"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"github.com/emicklei/go-restful"
)

// UserAPI ...
var UserAPI = new(userAPI)

type userAPI struct {
}

// Responses:
//
//	200: Response
//
//swagger:route POST /user/register user register
func (u *userAPI) Register(req *restful.Request, res *restful.Response) {
	registerReq := &client.RegisterReq{}
	registerRsp := &client.RegisterRes{}
	err := req.ReadEntity(registerReq)
	if err != nil {
		logger.Errorf("register params[%v], error:%v", registerReq, err)
		CustomFail(ParameterCode, "parameter binding fail", res)
		return
	}

	err = handler.NewUser().Register(context.Background(), registerReq, registerRsp)
	if err != nil {
		logger.Errorf("call user service register error:%v", err)
		CustomFail(ErrorMap[err.Error()], err.Error(), res)
		return
	}
	Success(registerRsp, res)
}

// Responses:
//
//	200: Response
//
//swagger:route POST /user/verify user verifyUserReq
func (u *userAPI) CheckUserByPhoneOrEmail(req *restful.Request, res *restful.Response) {
	verifyReq := &client.UserVerifyReq{}
	verifyRsp := &client.UserVerifyRes{}
	err := req.ReadEntity(verifyReq)
	if err != nil {
		logger.Errorf("verify params[%v], error:%v", verifyReq, err)
		CustomFail(ParameterCode, "parameter binding fail", res)
		return
	}
	err = handler.NewUser().CheckUserByPhoneOrEmail(context.Background(), verifyReq, verifyRsp)
	if verifyRsp.Res {
		// true means that the user can register
		Success(true, res)
		return
	}
	// false means that the mobile or email already exists
	Success(false, res)
}

// Responses:
//
//	200: Response
//
//swagger:route POST /user/login user login
func (u *userAPI) Login(req *restful.Request, res *restful.Response) {
	loginReq := &client.LoginReq{}
	loginRsp := &client.LoginRes{}
	err := req.ReadEntity(loginReq)
	if err != nil {
		logger.Errorf("login params[%v], error:%v", req.Request.Body, err)
		CustomFail(ParameterCode, "parameter binding fail", res)
		return
	}
	err = bean.LicenseCheck()
	if err != nil {
		logger.Debug("license check fail")
		CustomFail(ErrorMap[err.Error()], err.Error(), res)
		return
	}
	// 向云平台登录   登录时判断账号在库里面是否存在，
	//不存在:登录云出错返回错误  登录云成功写本地数据库
	//存在：登录云失败不影响，登录云成功更新数据库（密码），
	err = uploadcloud.CloudCli.LoginCloud(loginReq.Name, loginReq.Password)
	if err != nil {
		// CustomFail(ParameterCode, "login fail", res)
		logger.Errorf("Login Cloud Fail,err:", err)
		// return
	}
	err = handler.NewUser().Login(context.Background(), loginReq, loginRsp)
	if err != nil {
		logger.Errorf("call user service login error:%v", err)
		CustomFail(ErrorMap[err.Error()], err.Error(), res)
		return
	}
	token, err := jwttoken.CreateToken("app", loginRsp.Id)
	if err != nil {
		logger.Errorf("create token error:%v", err)
		return
	}
	login := client.LoginAdmit{
		User:  loginRsp,
		Token: token.AccessToken,
	}
	Success(login, res)
}

// swagger:route POST /user/info user info
// Responses:
//
//	200: Response
func (u *userAPI) GetUserInfo(req *restful.Request, res *restful.Response) {
	userInfoReq := &client.GetUserInfoReq{}
	userinfoRsp := &client.GetUserInfoRes{}
	err := req.ReadEntity(userInfoReq)
	if err != nil {
		logger.Errorf("getUserInfo params[%v], error:%v", req.Request.Body, err)
		CustomFail(ParameterCode, "parameter binding fail", res)
		return
	}
	err = handler.NewUser().GetUserInfo(context.Background(), userInfoReq, userinfoRsp)
	if err != nil {
		logger.Errorf("user getUserInfo error:%v", err)
		CustomFail(ErrorMap[err.Error()], err.Error(), res)
		return
	}
	Success(userinfoRsp, res)
}

// swagger:route POST /user/create user global
// Responses:
//
//	200: Response
func (u *userAPI) Insert(req *restful.Request, res *restful.Response) {
	insertReq := &client.UserCrudReq{}
	insertRsp := &client.UserCrudRes{}
	err := req.ReadEntity(insertReq)
	if err != nil {
		logger.Errorf("create  params[%v], error:%v", req.Request.Body, err)
		CustomFail(ParameterCode, "parameter binding fail", res)
		return
	}
	err = handler.NewUser().Insert(context.Background(), insertReq, insertRsp)
	if err != nil {
		logger.Errorf("Insert error %+v", err)
		CustomFail(insertRsp.GetCode(), err.Error(), res)
		return
	}
	Success(nil, res)
}

// swagger:route POST /user/update user global
// Responses:
//
//	200: Response
func (u *userAPI) Update(req *restful.Request, res *restful.Response) {
	uReq := &client.UpdateReq{}
	uRsp := &client.UserCrudRes{}
	err := req.ReadEntity(uReq)
	if err != nil {
		logger.Errorf("update  params[%v], error:%v", req.Request.Body, err)
		CustomFail(ParameterCode, "parameter binding fail", res)
		return
	}
	err = handler.NewUser().Update(context.Background(), uReq, uRsp)
	if err != nil {
		logger.Errorf("Update error %+v", err)
		CustomFail(uRsp.GetCode(), err.Error(), res)
		return
	}
	Success(nil, res)
}

// swagger:route POST /user/change user change
// Responses:
//
//	200: Response
func (u *userAPI) ChangePasswd(req *restful.Request, res *restful.Response) {
	changePasswdReq := &client.ChangePwdReq{}
	changePasswdRsp := &client.ChangePwdRes{}
	err := req.ReadEntity(changePasswdReq)
	if err != nil {
		logger.Errorf("user changePwd params:%v, error:%v", changePasswdReq, err)
		CustomFail(ParameterCode, "parameter binding fail", res)
		return
	}
	err = handler.NewUser().ChangePwd(context.Background(), changePasswdReq, changePasswdRsp)
	if err != nil {
		logger.Errorf("ChangePwd error %+v", err)
		CustomFail(changePasswdRsp.GetCode(), err.Error(), res)
		return
	}
	Success(nil, res)
}

// swagger:route POST /user/list user list
// Responses:
//
//	200: Response
func (u *userAPI) List(req *restful.Request, res *restful.Response) {
	lReq := &client.UserListReq{}
	lRsp := &client.UserListRes{}
	err := req.ReadEntity(lReq)
	if err != nil {
		logger.Errorf("bind list params[%v] error:%v", lReq, err)
		CustomFail(ParameterCode, "parameter binding fail", res)
		return
	}
	//参数绑定失败
	err = handler.NewUser().List(context.Background(), lReq, lRsp)
	if err != nil {
		logger.Errorf("List error %+v", err)
		CustomFail(lRsp.GetCode(), err.Error(), res)
		return
	}
	Success(lRsp, res)
}

// swagger:route POST /user/reset user resetReq
// Responses:
//
//	200: Response
func (u *userAPI) ResetPwd(req *restful.Request, res *restful.Response) {
	resetReq := &client.ResetPwdReq{}
	resetRsp := &client.ResetPwdRes{}
	err := req.ReadEntity(resetReq)
	if err != nil {
		CustomFail(ParameterCode, "parameter binding fail", res)
		return
	}
	err = handler.NewUser().ResetPwd(context.Background(), resetReq, resetRsp)
	if err != nil {
		logger.Errorf("ResetPwd error %+v", err)
		CustomFail(resetRsp.GetCode(), err.Error(), res)
		return
	}
	Success(nil, res)
}

func (u *userAPI) Delete(req *restful.Request, res *restful.Response) {
	delReq := &client.DeleteReq{}
	delRsp := &client.UserCrudRes{}
	err := req.ReadEntity(delReq)
	if err != nil {
		CustomFail(ParameterCode, "parameter binding fail", res)
		return
	}
	err = handler.NewUser().Delete(context.Background(), delReq, delRsp)
	if err != nil {
		logger.Errorf("Delete error %+v", err)
		CustomFail(delRsp.GetCode(), err.Error(), res)
		return
	}
	Success(nil, res)
}

func (u *userAPI) UpdateStatus(req *restful.Request, res *restful.Response) {
	statusReq := &client.StatusReq{}
	statusRsp := &client.StatusRes{}
	err := req.ReadEntity(statusReq)
	if err != nil {
		CustomFail(ParameterCode, "parameter binding fail", res)
		return
	}
	err = handler.NewUser().UpdateStatus(context.Background(), statusReq, statusRsp)
	if err != nil {
		logger.Errorf("UpdateStatus error %+v", err)
		CustomFail(statusRsp.GetCode(), err.Error(), res)
		return
	}
	Success(nil, res)
}

func init() {
	RegistHandler("/user/list", UserAPI.List)
	RegistHandler("/user/register", UserAPI.Register)
	RegistHandler("/user/login", UserAPI.Login)
	RegistHandler("/user/info", UserAPI.GetUserInfo)
	RegistHandler("/user/create", UserAPI.Insert)
	RegistHandler("/user/update", UserAPI.Update)
	RegistHandler("/user/change", UserAPI.ChangePasswd)
	RegistHandler("/user/reset", UserAPI.ResetPwd)
	RegistHandler("/user/verify", UserAPI.CheckUserByPhoneOrEmail)
	RegistHandler("/user/delete", UserAPI.Delete)
	RegistHandler("/user/status", UserAPI.UpdateStatus)
}

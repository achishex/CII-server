package webapi

import "adasgitlab.autel.com/tools/cuav_server/entity/bean"

var (
	ParameterCode int32 = 1014
)

var ErrorMap = map[string]int32{
	// User Relation
	"user name is not exists":               1000,
	"register user fail":                    1001,
	"username or password can not be empty": 1002,
	"user does not exists":                  1003,
	"the password is incorrect":             1004,
	"this user is disable":                  1005,
	"username all ready exists":             1006,
	"create user fail":                      1007,
	"update fail":                           1008,
	"count total record fail":               1009,
	"query list fail":                       1010,
	"reset password fail":                   1011,
	"delete fail":                           1012,
	"login fail":                            1013,
	"parameter binding fail":                1014,
	bean.NoLicense:                          bean.NoLicenseCode,
	bean.InvalidLicense:                     bean.InvalidLicenseCode,
	bean.ExpiredLicense:                     bean.ExpiredLicenseCode,
}

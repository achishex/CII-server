package webapi

import (
	"context"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"github.com/emicklei/go-restful"
)

type smsApi struct{}

var (
	SmsApi = new(smsApi)
)

// swagger:route POST /sms/send sms verify
// Responses:
//
//	200: Response
func (s *smsApi) Send(req *restful.Request, res *restful.Response) {
	smsReq := &client.SmsSendReq{}
	smsRsp := &client.SmsSendRes{}
	err := req.ReadEntity(smsReq)
	if err != nil {
		logger.Errorf("sms send code params[%v],error:%v", smsReq, err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	err = handler.NewSms().Send(context.Background(), smsReq, smsRsp)
	if err != nil {
		errCode := GetErrCode(err)
		ParameterBindFail(errCode, err.Error(), res)
		return
	}
	if smsRsp.Limited {
		errMsg := "SMS sent exceeds the daily limit"
		ParameterBindFail(ErrCode[errMsg], errMsg, res)
		return
	}
	Success(smsRsp, res)
}

// swagger:route POST /sms/verify sms verify
// Responses:
//
//	200: Response
func (s *smsApi) Verify(req *restful.Request, res *restful.Response) {
	smsReq := &client.CheckReq{}
	smsRsp := &client.CheckRes{}
	err := req.ReadEntity(smsReq)
	if err != nil {
		logger.Errorf("sms send code params[%v],error:%v", smsReq, err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	err = handler.NewSms().CheckVerificationCode(context.Background(), smsReq, smsRsp)
	if err != nil {
		logger.Errorf("sms verify params[%v],error:%v", smsReq, err)
		errCode := GetErrCode(err)
		ParameterBindFail(errCode, err.Error(), res)
		return
	}
	Result(err, res)
}

// swagger:route POST /sms/send sms verify
// Responses:
//
//	200: Response
func (s *smsApi) Notify(req *restful.Request, res *restful.Response) {
	smsReq := &client.SmsNotifyReq{}
	smsRsp := &client.SmsSendRes{}
	err := req.ReadEntity(smsReq)
	if err != nil {
		logger.Errorf("smsApi ReadEntity error: %v", err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	err = handler.NewSms().Notify(context.Background(), smsReq, smsRsp)
	if err != nil {
		errCode := GetErrCode(err)
		ParameterBindFail(errCode, err.Error(), res)
		return
	}
	Success(smsRsp, res)
}

func init() {
	RegistHandler("/sms/send", SmsApi.Send)
	RegistHandler("/sms/verify", SmsApi.Verify)
	RegistHandler("/sms/notify", SmsApi.Notify)
}

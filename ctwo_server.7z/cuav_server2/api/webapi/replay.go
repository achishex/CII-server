package webapi

import (
	"context"
	"net/http"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"github.com/emicklei/go-restful"
)

var (
	ReplayApi = new(Replay)
)

type Replay struct {
	PlaybackCancel func()
}

// Playback 雷达模拟数据使用 开始模拟数据
func (p *Replay) Playback(req *restful.Request, res *restful.Response) {
	replayReq := &client.ReplayReq{}
	replayRsp := &client.ReplayRes{}
	if err := req.ReadEntity(replayReq); err != nil {
		ParameterBindFail(http.StatusBadRequest, err.Error(), res)
		return
	}
	logger.Infof("Playback req %+v", replayReq)
	err := handler.ReplayApi.Replay(context.Background(), replayReq, replayRsp)
	logger.Infof("Playback rsp %+v", replayRsp)
	if err != nil {
		CustomFail(http.StatusInternalServerError, err.Error(), res)
		return
	}
	Success(nil, res)

}

// PlaybackStop 停止雷达模拟数据
func (p *Replay) PlaybackStop(req *restful.Request, res *restful.Response) {
	replayReq := &client.ReplayStopReq{}
	replayRsp := &client.ReplayStopRes{}
	err := handler.ReplayApi.ReplayStop(context.Background(), replayReq, replayRsp)
	if err != nil {
		CustomFail(http.StatusInternalServerError, err.Error(), res)
		return
	}
	Success(nil, res)

}

func init() {
	RegistHandler("/radar-data/playback", ReplayApi.Playback)
	RegistHandler("/radar-data/playback/stop", ReplayApi.PlaybackStop)
}

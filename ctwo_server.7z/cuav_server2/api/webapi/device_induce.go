package webapi

import (
	"context"

	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"github.com/emicklei/go-restful"
)

// SetInduce 导航诱骗  开始工作模式
func (e *deviceManager) SetInduce(req *restful.Request, res *restful.Response) {
	deviceReq := &client.InduceRequest{}
	deviceRsp := &client.InduceResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().StartInduce(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// GetInduceVer 导航诱骗  获取版本号、sn、IP
func (e *deviceManager) GetInduceVer(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GetInduceVerRequest{}
	deviceRsp := &client.GetInduceVerResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().GetInduceVer(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// EnableInduce 导航诱骗启用、禁用
func (e *deviceManager) EnableInduce(req *restful.Request, res *restful.Response) {
	deviceReq := &client.EnableInduceRequest{}
	deviceRsp := &client.EnableInduceResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().EnableInduce(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// GetInduceConfig 导航诱骗获取本地配置
func (e *deviceManager) GetInduceConfig(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GetInduceConfigRequest{}
	deviceRsp := &client.GetInduceConfigResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().GetInduceConfig(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// SetInduceConfig 导航诱骗设置配置、保存本地
func (e *deviceManager) SetInduceConfig(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SetInduceConfigRequest{}
	deviceRsp := &client.SetInduceConfigResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SetInduceConfig(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}
func init() {
	//导航诱骗
	RegistHandler("/device/induce", DeviceManagerApi.SetInduce)
	//导航诱骗获取设备版本
	RegistHandler("/device/get-induce-ver", DeviceManagerApi.GetInduceVer)
	//导航诱骗 启用1  禁用2
	RegistHandler("/device/enable-induce", DeviceManagerApi.EnableInduce)
	//导航诱骗   前端获取上次保存的数据
	RegistHandler("device/induce/get-config", DeviceManagerApi.GetInduceConfig)
	//导航诱骗   前端设置参数配置
	RegistHandler("device/induce/set-config", DeviceManagerApi.SetInduceConfig)
}

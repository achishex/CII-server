package webapi

import (
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"github.com/emicklei/go-restful"
)

var uriHandle map[string]restful.RouteFunction

// RegistHandler 注册http接口和对应处理函数
func RegistHandler(uri string, handle restful.RouteFunction) {
	if uriHandle == nil {
		uriHandle = make(map[string]restful.RouteFunction)
	}
	if v, ok := uriHandle[uri]; ok {
		logger.Errorf("uri handle exist uri[%v] handle[%v]", uri, v)
		return
	}
	uriHandle[uri] = handle
}

// InitRouter 初始化http路由
func InitRouter() *restful.WebService {
	ws := new(restful.WebService)
	ws.Filter(GlobalLogging)
	ws.Path("/")

	for k, v := range uriHandle {
		ws.Route(ws.POST(k).To(v))
	}

	return ws
}

func GlobalLogging(req *restful.Request, resp *restful.Response, chain *restful.FilterChain) {
	start := time.Now()
	defer func() {
		end := time.Now()
		if err := recover(); err != nil {
			logger.Infof("[restful] %v %v latency: %v recover: [%v]", req.Request.Method, req.Request.URL, end.Sub(start), err)
		} else {
			logger.Infof("[restful] %v %v latency: %v", req.Request.Method, req.Request.URL, end.Sub(start))
		}
	}()
	chain.ProcessFilter(req, resp)
}

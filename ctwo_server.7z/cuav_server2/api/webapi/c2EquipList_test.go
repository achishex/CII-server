package webapi

import (
	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
	"context"
	"net/http"
	"net/http/httptest"
	"reflect"
	"strings"
	"testing"

	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/test"
	"github.com/agiledragon/gomonkey"
	"github.com/emicklei/go-restful"
	"github.com/stretchr/testify/assert"
)

func Test_equipApi_Insert(t *testing.T) {
	// Mock 日志
	test.LoggerMock()

	s := &handler.EquipList{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(s), "Insert", func(_ *handler.EquipList, _ context.Context, req *client.EquipCrudReq, res *client.EquipCrudRes) error {
		return nil
	})
	defer patches.Reset()

	data := `{"sn":"radar12345656", "name":"radaraaa"}`
	req := httptest.NewRequest(http.MethodPost, "/equip/create", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		e    *equipApi
		args args
	}{
		{
			name: "Case1",
			e:    &equipApi{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			tt.e.Insert(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}

func Test_equipApi_Update(t *testing.T) {
	// Mock 日志
	test.LoggerMock()
	s := &handler.EquipList{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(s), "Update", func(_ *handler.EquipList, _ context.Context, req *client.EquipCrudReq, res *client.EquipCrudRes) error {
		return nil
	})
	defer patches.Reset()

	data := `{"sn":"radar12345656", "name":"radaraaa"}`
	req := httptest.NewRequest(http.MethodPost, "/equip/update", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		e    *equipApi
		args args
	}{
		{
			name: "Case1",
			e:    &equipApi{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			e := &equipApi{}
			e.Update(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}

func Test_equipApi_Delete(t *testing.T) {
	// Mock 日志
	test.LoggerMock()
	s := &handler.EquipList{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(s), "Delete", func(_ *handler.EquipList, _ context.Context, req *client.EquipDeleteReq, res *client.EquipCrudRes) error {
		return nil
	})
	defer patches.Reset()

	data := `{"ids":[1,2]}`
	req := httptest.NewRequest(http.MethodPost, "/equip/delete", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		e    *equipApi
		args args
	}{
		{
			name: "Case1",
			e:    &equipApi{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			e := &equipApi{}
			e.Delete(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}

func setUp() {
	test.LoggerMock()
	dbFile := "../../config/cuav.db"
	db.Init(dbFile)
}
func tearDown() {
	//add others...
}

func TestMain(m *testing.M) {
	setUp()
	m.Run()
	tearDown()
}

func TestDeleteEquipListToBackup(t *testing.T) {
	idsResp := []*bean.EquipList{}
	equipReq := &client.EquipDeleteReq{
		Ids: []int32{1},
	}
	handler.NewEquipList().FindByIds(context.Background(), equipReq, &idsResp)
	handler.NewEquipList().InsertOrUpdateBackupTab(context.Background(), idsResp)
}

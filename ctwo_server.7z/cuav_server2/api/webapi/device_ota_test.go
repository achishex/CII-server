package webapi

import (
	"context"
	"net/http"
	"net/http/httptest"
	"reflect"
	"strings"
	"testing"

	"adasgitlab.autel.com/tools/cuav_plugin/broker/memory"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
	"adasgitlab.autel.com/tools/cuav_server/test"
	"github.com/agiledragon/gomonkey"
	"github.com/emicklei/go-restful"
	"github.com/stretchr/testify/assert"
)

func Test_deviceManager_DownloadOtaPkg(t *testing.T) {
	test.LoggerMock()
	mq.EquipMessageBoxBroker = memory.NewBroker()
	data := `{"fileKey":"12", "deviceType":1}`
	req := httptest.NewRequest(http.MethodPost, "/device/ota/downloadOtaPkg", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	a := &handler.DeviceCenter{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(a), "DownloadOtaPkg", func(_ *handler.DeviceCenter, _ context.Context, req *client.DownloadOtaPkgRequest, rsp *client.DownloadOtaPkgResponse) error {
		return nil
	})
	defer patches.Reset()

	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		e    *deviceManager
		args args
	}{
		{
			name: "Case1",
			e:    &deviceManager{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			e := &deviceManager{}
			e.DownloadOtaPkg(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}

func Test_deviceManager_OtaRequestUpgrade(t *testing.T) {
	test.LoggerMock()
	mq.EquipMessageBoxBroker = memory.NewBroker()
	data := `{"sn":"12", "deviceType":1, "fileName":"radar_v1.10.1"}`
	req := httptest.NewRequest(http.MethodPost, "/device/ota/request-upgrade", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	a := &handler.DeviceCenter{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(a), "OtaRequestUpgrade", func(_ *handler.DeviceCenter, _ context.Context, req *client.RequestUpgradeRequest, rsp *client.RequestUpgradeResponse) error {
		return nil
	})
	defer patches.Reset()

	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		e    *deviceManager
		args args
	}{
		{
			name: "Case1",
			e:    &deviceManager{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			e := &deviceManager{}
			e.OtaRequestUpgrade(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}

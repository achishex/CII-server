package webapi

import (
	"context"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"github.com/emicklei/go-restful"
	"google.golang.org/protobuf/types/known/emptypb"
)

type emailApi struct{}

var (
	EmailApi = new(emailApi)
)

// Responses:
//
//	200: Response
//
//swagger:route POST /email/send email sendReq
func (s *emailApi) Send(req *restful.Request, res *restful.Response) {
	emailReq := &client.SendReq{}
	emailRsp := &client.SendRes{}
	err := req.ReadEntity(emailReq)
	if err != nil {
		logger.Errorf("email send code params[%v],error:%v", emailReq, err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	err = handler.NewEmail().Send(context.Background(), emailReq, emailRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
	} else {
		Success(emailRsp, res)
	}
}

// Responses:
//
//	200: Response
//
//swagger:route POST /email/verify email verifyReq
func (s *emailApi) Verify(req *restful.Request, res *restful.Response) {
	emailReq := &client.VerifyReq{}
	emailRsp := &emptypb.Empty{}
	err := req.ReadEntity(emailReq)
	if err != nil {
		logger.Errorf("email verify params[%v],error:%v", emailReq, err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	err = handler.NewEmail().Verify(context.Background(), emailReq, emailRsp)
	if err != nil {
		errCode := GetErrCode(err)
		ParameterBindFail(errCode, err.Error(), res)
		return
	}
	Result(err, res)
}

func (s *emailApi) Notify(req *restful.Request, res *restful.Response) {
	emailReq := &client.NotifyReq{}
	emailRsp := &client.SendRes{}
	err := req.ReadEntity(emailReq)
	if err != nil {
		logger.Errorf("emailApi ReadEntity error: %v", err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	err = handler.NewEmail().Notify(context.Background(), emailReq, emailRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
	} else {
		Success(emailRsp, res)
	}
}

func init() {
	RegistHandler("/email/send", EmailApi.Send)
	RegistHandler("/email/verify", EmailApi.Verify)
	RegistHandler("/email/notify", EmailApi.Notify)
}

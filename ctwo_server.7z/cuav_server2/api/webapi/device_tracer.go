package webapi

import (
	"context"

	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"github.com/emicklei/go-restful"
)

// DroneIDGetVersionInfo 获取版本tracer信息   20
func (e *deviceManager) DroneIDGetVersionInfo(req *restful.Request, res *restful.Response) {
	deviceReq := &client.DroneIDGetVersionInfoRequest{}
	deviceRsp := &client.DroneIDGetVersionInfoResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().DroneIDGetVersionInfo(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// TracerGetVersionInfo 获取版本tracer信息  AB
func (e *deviceManager) TracerGetVersionInfo(req *restful.Request, res *restful.Response) {
	deviceReq := &client.TracerGetVersionInfoRequest{}
	deviceRsp := &client.TracerGetVersionInfoResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().TracerGetVersionInfo(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// TracerGetInfo 获取Tracer设备信息
func (e *deviceManager) TracerGetInfo(req *restful.Request, res *restful.Response) {
	deviceReq := &client.TracerGetInfoRequest{}
	deviceRsp := &client.TracerGetInfoResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err := handler.NewDeviceCenter().TracerGetInfo(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		CustomFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// TracerGetWorkMode 获取Tracer工作模式
func (e *deviceManager) TracerGetWorkMode(req *restful.Request, res *restful.Response) {
	deviceReq := &client.TracerGetWorkModeRequest{}
	deviceRsp := &client.TracerGetWorkModeResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err := handler.NewDeviceCenter().TracerGetWorkMode(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		CustomFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// TracerSetOrientationMode 设置Tracer定向模式
func (e *deviceManager) TracerSetOrientationMode(req *restful.Request, res *restful.Response) {
	deviceReq := &client.TracerSetOrientationModeRequest{}
	deviceRsp := &client.TracerSetOrientationModeResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().TracerSetOrientationMode(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		CustomFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// TracerCli 向Tracer发送cmd
func (e *deviceManager) TracerCli(req *restful.Request, res *restful.Response) {
	deviceReq := &client.TracerCliRequest{}
	deviceRsp := &client.TracerCliResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().TracerCli(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		CustomFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// TracerSetHideMode 向Tracer发送隐蔽模式
func (e *deviceManager) TracerSetHideMode(req *restful.Request, res *restful.Response) {
	deviceReq := &client.TracerSetHideModeRequest{}
	deviceRsp := &client.TracerSetHideModeResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().TracerSetHideMode(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		CustomFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// TracerSetAlarm 向Tracer设置告警等级
func (e *deviceManager) TracerSetAlarm(req *restful.Request, res *restful.Response) {
	deviceReq := &client.TracerSetAlarmRequest{}
	deviceRsp := &client.TracerSetAlarmResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().TracerSetAlarm(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		CustomFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

func (e *deviceManager) GetOrientationDroneList(req *restful.Request, res *restful.Response) {
	deviceReq := &client.TracerSOrientationDroneReq{}
	deviceRsp := &client.TracerSOrientationDroneResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().GetOrientRecordItems(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		CustomFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

func init() {
	RegistHandler("/device/tracer/set-alarm", DeviceManagerApi.TracerSetAlarm)
	RegistHandler("/device/tracer/set-hide-mode", DeviceManagerApi.TracerSetHideMode)
	RegistHandler("/device/droneID/get-version-info", DeviceManagerApi.DroneIDGetVersionInfo) //前端未使用
	RegistHandler("/device/tracer/get-version-info", DeviceManagerApi.TracerGetVersionInfo)
	RegistHandler("/device/tracer/info", DeviceManagerApi.TracerGetInfo)
	//获取tracer工作模式
	RegistHandler("/device/tracer/get-work-mode", DeviceManagerApi.TracerGetWorkMode)
	//设置tracer定向模式
	RegistHandler("/device/tracer/ser-orientation-mode", DeviceManagerApi.TracerSetOrientationMode)
	//向tracer发送CMD命令
	RegistHandler("/device/tracer/cli", DeviceManagerApi.TracerCli)
	//查询tracerS定向无人机的记录; 默认查询时间是 4.5个小时;
	RegistHandler("/device/tracer/orientation-drone-list", DeviceManagerApi.GetOrientationDroneList)
}

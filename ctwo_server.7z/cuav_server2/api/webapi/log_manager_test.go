package webapi

import (
	"context"
	"net/http"
	"net/http/httptest"
	"reflect"
	"strings"
	"testing"

	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"github.com/agiledragon/gomonkey"
	"github.com/emicklei/go-restful"
	"github.com/stretchr/testify/assert"
)

func Test_deviceManager_GetLocalLogList(t *testing.T) {
	data := `{"Sn":"v1.0.0.15"}`
	req := httptest.NewRequest(http.MethodPost, "/device/local/log/list", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	e := &handler.DeviceCenter{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(e), "GetLocalLogs", func(_ *handler.DeviceCenter, _ context.Context, req *client.GetLocalLogRequest, rsp *client.GetLocalLogResponse) error {
		return nil
	})
	defer patches.Reset()

	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		e    *deviceManager
		args args
	}{
		{
			name: "Case1",
			e:    &deviceManager{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			e := &deviceManager{}
			e.GetLocalLogList(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}

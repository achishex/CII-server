package webapi

import (
	"context"
	"net/http"
	"net/http/httptest"
	"reflect"
	"strings"
	"testing"

	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/test"
	"github.com/agiledragon/gomonkey"
	"github.com/emicklei/go-restful"
	"github.com/stretchr/testify/assert"
)

func Test_deviceManager_List(t *testing.T) {
	// Mock 日志
	test.LoggerMock()

	data := `{"id":12, "phone":"5000", "email":"13424"}`
	req := httptest.NewRequest(http.MethodPost, "/device/list", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	a := &handler.EquipList{}
	e := &handler.DeviceCenter{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(a), "List", func(_ *handler.EquipList, _ context.Context, req *client.EquipListReq, res *client.EquipListRes) error {
		item := &client.List{
			Id:       123,
			Sn:       "12243214",
			IsEnable: common.DeviceEnable,
			IsOnline: 1,
		}
		res.Equips = append(res.Equips, item)
		return nil
	})
	patches.ApplyMethod(reflect.TypeOf(e), "GetEquipList", func(_ *handler.DeviceCenter, _ context.Context, req *client.GetEquipListRequest, rsp *client.GetEquipListResponse) error {
		item := &client.EquipInfo{
			Sn: "12243214",
			Ip: "123.134.2.1",
		}
		rsp.Equips = append(rsp.Equips, item)
		return nil
	})
	defer patches.Reset()

	type args struct {
		in0 *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		e    *deviceManager
		args args
	}{
		{
			name: "Case1",
			e:    &deviceManager{},
			args: args{
				in0: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			e := &deviceManager{}
			e.List(tt.args.in0, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}

func Test_deviceManager_AddSimulateDevice(t *testing.T) {
	// Mock 日志
	test.LoggerMock()

	data := `{"status":1, "msgtype":225}`
	req := httptest.NewRequest(http.MethodPost, "/device/add-simulate-device", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	e := &handler.DeviceCenter{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(e), "AddSimulateDevice", func(_ *handler.DeviceCenter, _ context.Context, req *client.AddSimulateDeviceRequest, rsp *client.AddSimulateDeviceResponse) error {
		return nil
	})
	defer patches.Reset()

	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		e    *deviceManager
		args args
	}{
		{
			name: "Case1",
			e:    &deviceManager{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			//e := &deviceManager{}
			//e.AddSimulateDevice(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}

func Test_deviceManager_C2Update(t *testing.T) {
	data := `{"version":"v1.0.0.15"}`
	req := httptest.NewRequest(http.MethodPost, "/c2/version/update", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	e := &handler.DeviceCenter{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(e), "DownC2Apk", func(_ *handler.DeviceCenter, _ context.Context, req *client.DownC2ApkRequest, rsp *client.DownC2ApkResponse) error {
		return nil
	})
	defer patches.Reset()

	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		e    *deviceManager
		args args
	}{
		{
			name: "Case1",
			e:    &deviceManager{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			e := &deviceManager{}
			e.C2Update(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}

package webapi

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"context"
	"github.com/emicklei/go-restful"
)

type whitelistApi struct {
}

var (
	WhitelistApi = new(whitelistApi)
)

// swagger:route POST /whitelist/create whitelist commonReq
// Responses:
//
//	200: Response
func (w *whitelistApi) Insert(req *restful.Request, res *restful.Response) {
	whiteReq := &client.WhiteCrudReq{}
	whiteRsp := &client.WhiteCrudRes{}
	err := req.ReadEntity(whiteReq)
	if err != nil {
		logger.Errorf("bind create params[%v] error:%v", whiteReq, err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	err = handler.NewWhiteList().Insert(context.Background(), whiteReq, whiteRsp)
	go handler.SendDevWhiteListToSfl()
	//发送白名单给tracer设备
	go handler.SendDevWhiteList()
	Result(err, res)

}

// swagger:route POST /whitelist/update whitelist commonReq
// Responses:
//
//	200: Response
func (w *whitelistApi) Update(req *restful.Request, res *restful.Response) {
	whiteReq := &client.WhiteCrudReq{}
	whiteRsp := &client.WhiteCrudRes{}
	err := req.ReadEntity(whiteReq)
	if err != nil {
		logger.Errorf("bind update  params[%v] error:%v", whiteReq, err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	err = handler.NewWhiteList().Update(context.Background(), whiteReq, whiteRsp)

	go handler.SendDevWhiteList()
	go handler.SendDevWhiteListToSfl()
	Result(err, res)

}

// swagger:route POST /whitelist/delete whitelist deleteReq
// Responses:
//
//	200: Response
func (w *whitelistApi) Delete(req *restful.Request, res *restful.Response) {
	whiteReq := &client.WhiteDeleteReq{}
	whiteRsp := &client.WhiteCrudRes{}
	err := req.ReadEntity(whiteReq)
	if err != nil {
		logger.Errorf("bind delete params[%v] error:%v", whiteReq, err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	err = handler.NewWhiteList().Deletes(context.Background(), whiteReq, whiteRsp)

	//发送白名单给tracer设备
	go handler.SendDevWhiteList()
	go handler.SendDevWhiteListToSfl()
	Result(err, res)

}

// swagger:route POST /whitelist/list whitelist list
// Responses:
//
//	200: Response
func (w *whitelistApi) List(req *restful.Request, res *restful.Response) {
	whiteReq := &client.WhiteListReq{}
	whiteRsp := &client.WhiteListRes{}
	err := req.ReadEntity(whiteReq)
	if err != nil {
		logger.Errorf("bind list  params[%v] error:%v", whiteReq, err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	err = handler.NewWhiteList().List(context.Background(), whiteReq, whiteRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	go handler.SendDevWhiteListToSfl()
	//发送白名单给tracer设备
	go handler.SendDevWhiteList()
	Success(whiteRsp, res)
}

func init() {
	RegistHandler("/whitelist/create", WhitelistApi.Insert)
	RegistHandler("/whitelist/update", WhitelistApi.Update)
	RegistHandler("/whitelist/delete", WhitelistApi.Delete)
	RegistHandler("/whitelist/list", WhitelistApi.List)
}

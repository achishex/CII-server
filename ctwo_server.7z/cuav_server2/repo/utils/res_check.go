package utils

import (
	"net/http"
	_ "net/http/pprof"
	"os"
	"runtime"
	"strconv"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
)

type SkyFendC2ResCheck struct {
	RunPort int32
}

func NewSkyFendC2ResCheck() *SkyFendC2ResCheck {
	s := &SkyFendC2ResCheck{
		RunPort: 8787,
	}
	return s
}

func (s *SkyFendC2ResCheck) Run() {
	go func() {
		http.ListenAndServe("0.0.0.0:"+strconv.Itoa(int(s.RunPort)), nil)
	}()
}
func CheckC2BackendRes() {
	NewSkyFendC2ResCheck().Run()
}

func MonitorGoUseRes() {
	go func() {
		for range time.NewTicker(5 * time.Second).C {
			var mem runtime.MemStats
			runtime.ReadMemStats(&mem)
			logger.Infof("pid: %v, mem usage: %+v", os.Getpid(), mem)
		}
	}()
}

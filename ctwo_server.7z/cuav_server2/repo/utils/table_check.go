package utils

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
	"gorm.io/gorm"
)

func CheckAndCreateTab[T any](dbGorm *gorm.DB, tabName string, tableItem *T, devType int32) {
	// 检查新表是否已存在，如果不存在则创建
	if !dbGorm.Migrator().HasTable(tabName) {
		err := dbGorm.Table(tabName).AutoMigrate(tableItem)
		if err != nil {
			logger.Errorf("create New Table:%v, err: %v", tabName, err)
		}
		if devType != 0 {
			record := bean.RecordList{
				DevType:         devType,
				DetectTableName: tabName,
			}
			if err := db.GetDB().Table(bean.RecordList{}.TableName()).Create(&record).Error; err != nil {
				logger.Errorf("Write To Db RecordList data, sfl write to db fail, e: %v", err)
			}
		}
	}
}

type CheckCondCall func(db *gorm.DB) bool

func WithIndexCond[T any](item *T, indexName string) CheckCondCall {
	return func(db *gorm.DB) bool {
		return db.Migrator().HasIndex(item, indexName) // field name.
	}
}
func WithColFieldCond[T any](item *T, fieldName string) CheckCondCall {
	return func(db *gorm.DB) bool {
		return db.Migrator().HasColumn(item, fieldName)
	}
}
func WithColFieldCond2[T any](tabName, fieldName string) CheckCondCall {
	return func(db *gorm.DB) bool {
		return db.Migrator().HasColumn(tabName, fieldName)
	}
}
func WithTableCond[T any](item *T, tabName string) CheckCondCall {
	return func(db *gorm.DB) bool {
		return db.Migrator().HasTable(tabName)
	}
}

func CheckTabCondCreateTab[T any](dbgrom *gorm.DB, tabName string, tableItem *T, checkFuncs ...CheckCondCall) {
	for _, check := range checkFuncs {
		if check(dbgrom) {
			continue
		}

		err := dbgrom.Table(tabName).AutoMigrate(tableItem)
		if err != nil {
			logger.Errorf("create New Table:%v, err: %v", tabName, err)
		}
		record := bean.RecordList{
			DevType:         int32(common.DEV_V2DRONEID),
			DetectTableName: tabName,
		}
		if err = db.GetDB().Table(bean.RecordList{}.TableName()).Create(&record).Error; err != nil {
			logger.Errorf("Write To Db RecordList data, tracer write to db fail, e: %v", err)
		}
		break
	}
}

func CheckAndDeleteTab[T any](db *gorm.DB, tabName string, tableItem *T) {
	// 检查新表是否已存在，如果exist then drop it
	if db.Migrator().HasTable(tabName) {
		err := db.Migrator().DropTable(tabName)
		if err != nil {
			logger.Errorf("create New Table:%v, err: %v", tabName, err)
		}
	}
}

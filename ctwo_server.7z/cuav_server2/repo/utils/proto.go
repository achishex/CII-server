package utils

//type EntityProtoAccess struct {
//	ContentType string
//}
//
//func (e EntityProtoAccess) Read(req *restful.Request, v interface{}) error {
//	body, err := io.ReadAll(req.Request.Body)
//	if err != nil {
//		if err == io.EOF {
//			return nil
//		}
//		return err
//	}
//	defer req.Request.Body.Close()
//
//	message, ok := v.(proto.Message)
//	if !ok {
//		return errors.New("invalid request")
//	}
//	err = proto.Unmarshal(body, message)
//	if err != nil {
//		return err
//	}
//	return nil
//}
//
//func (e EntityProtoAccess) Write(resp *restful.Response, status int, v interface{}) error {
//	return writeProto(resp, status, e.ContentType, v)
//}
//
//func writeProto(resp *restful.Response, status int, contentType string, v interface{}) error {
//	entity, ok := v.(common.Response)
//	if !ok {
//		return errors.New("invalid response")
//	}
//	if entity.Data != nil {
//		message, ok := entity.Data.(proto.Message)
//		if !ok {
//			return errors.New("invalid response data")
//		}
//		output, err := proto.Marshal(message)
//		if err != nil {
//			return err
//		}
//		entity.Data = output
//	}
//
//	out, err := jsoniter.Marshal(entity)
//	if err != nil {
//		return err
//	}
//	resp.Header().Set(restful.HEADER_ContentType, contentType)
//	resp.WriteHeader(status)
//	_, err = resp.Write(out)
//	return err
//}

//func NewEntityProtoAccess(contentType string) *EntityProtoAccess {
//	return &EntityProtoAccess{ContentType: contentType}
//}

package kafka

import (
	"github.com/Shopify/sarama"
)

// GetKafkaProducer 获取kafka生产者
func GetKafkaProducer(addr string) (client sarama.SyncProducer, err error) {

	// Kafka生产者配置
	config := sarama.NewConfig()
	config.Producer.RequiredAcks = sarama.WaitForAll          // 发送完数据需要leader和follow都确认
	config.Producer.Partitioner = sarama.NewRandomPartitioner // 新选出⼀个partition
	config.Producer.Return.Successes = true                   // 成功交付的消息将在success channel返回

	// 新建一个生产者对象
	client, err = sarama.NewSyncProducer([]string{addr}, config)
	if err != nil {
		return
	}
	return
}

// SendToKafka 发送消息
func SendToKafka(data, topic string, client sarama.SyncProducer) (err error) {

	msg := &sarama.ProducerMessage{}
	msg.Topic = topic
	msg.Value = sarama.StringEncoder(data)

	_, _, err = client.SendMessage(msg)

	if err != nil {
		return
	}

	return
}

// package db 数据库操作封装
package db

import (
	"database/sql"
	"path"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"github.com/qustavo/dotsql"
	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
)

var (
	defaultDbPath = "config/"
)

var db *gorm.DB

// Init 初始化DB
func Init(dbPath string) error {
	var err error
	db, err = initDB(dbPath)
	if err != nil {
		return err
	}
	return nil
}

// GetDB 获取DB
func GetDB() *gorm.DB {
	if db != nil {
		return db
	}
	return nil
}

// initDB 初始化数据库
func initDB(dbFile string) (*gorm.DB, error) {
	defaultDbPath = path.Dir(dbFile)
	var err error
	db, err = gorm.Open(sqlite.Open(dbFile), &gorm.Config{})
	if err != nil {
		logger.Errorf("Open sqlite error:%v", err)
		return nil, err
	}
	db.Exec("PRAGMA journal_mode=WAL;")
	conn, err := db.DB()
	if err != nil {
		logger.Errorf("Get db conn error: %v", err)
	}
	conn.SetMaxOpenConns(100)
	conn.SetMaxIdleConns(10)
	conn.SetConnMaxIdleTime(time.Minute * 60)
	return db, nil
}

// InitSqlite 初始化sqlite数据库
func InitSqlite(dbFile string) (*sql.DB, error) {
	defaultDbPath = path.Dir(dbFile)
	var err error
	db, err = gorm.Open(sqlite.Open(dbFile), &gorm.Config{})
	if err != nil {
		logger.Errorf("Open sqlite error:%v", err)
		return nil, err
	}
	db.Exec("PRAGMA journal_mode=WAL;")

	conn, err := db.DB()
	if err != nil {
		logger.Errorf("Get db conn error: %v", err)
		return nil, err
	}
	conn.SetMaxOpenConns(100)
	conn.SetMaxIdleConns(10)
	conn.SetConnMaxIdleTime(time.Minute * 60)
	return conn, nil
}

func SqliteExecSqlFile(dbFile string, sqlFile string, sqlName string) error {
	dbFile = path.Join(defaultDbPath, dbFile)
	sqlFile = path.Join(defaultDbPath, sqlFile)
	db, err := sql.Open("sqlite3", dbFile)
	if err != nil {
		return err
	}
	dot, err := dotsql.LoadFromFile(sqlFile)
	if err != nil {
		return err
	}
	_, err = dot.Exec(db, sqlName)
	if err != nil {
		return err
	}
	return nil
}

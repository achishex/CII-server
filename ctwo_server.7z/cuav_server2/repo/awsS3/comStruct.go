package awsS3

import (
	"net/http"
	"os"
	"sync"
	"time"

	"github.com/aws/aws-sdk-go-v2/service/s3"
)

type CustomReader struct {
	fp      *os.File
	size    int64
	read    int64
	signMap map[int64]struct{}
	mux     sync.Mutex
}
type FileType int

const (
	LOG FileType = 1
	OTA FileType = 2
)

type DevType int

const (
	NONE    DevType = 0
	RADAR   DevType = 1
	GUN     DevType = 2
	DRONEID DevType = 3
)
const (
	BucketC2WinName              string = "c2apkwindows"
	PreFixC2WindowsCN            string = "c2windows/c2windows_CN/"
	PreFixC2WindowsRussian       string = "c2windows/c2windows_Russian/"
	PreFixNoLogoC2WindowsCN      string = "nologoc2apkwindows/nologo_c2apkwindows_CN/"
	PreFixNoLogoC2WindowsRussian string = "nologoc2apkwindows/nologo_c2apkwindows_Russian/"
)

const (
	TestBucketC2              string = "testc2apk"
	TestPreFixC2CN            string = "testc2apklogo/testc2apklogo_cn/"
	TestPreFixC2Russian       string = "testc2apklogo/testc2apknologo_russian/"
	TestPreFixNoLogoC2CN      string = "testc2apknologo/testc2apknologo_cn/"
	TestPreFixNoLogoC2Russian string = "testc2apknologo/testc2apknologo_russian/"
)

type Code int

const (
	ERROR Code = 7
	SUC   Code = 0
)

// 上传使用的结构体
type LogUploadPreSignUrlReq struct {
	FileName   string `json:"file_name"`   // 文件名
	Sn         string `json:"sn"`          // 设备sn号
	MacNo      string `json:"mac_no"`      // mac设备号
	MacAddr    string `json:"mac_addr"`    // mac地址
	UserName   string `json:"user_name"`   // 用户名
	FileType   int8   `json:"file_type"`   // 文件类型 1日志 2升级包
	FileSize   int64  `json:"file_size"`   // 文件大小
	DeviceType int8   `json:"device_type"` // 设备类型 0未知 1雷达 2反制抢 3droneID
}

// 下载日志使用的结构体
type RequestData struct {
	FileName   string `json:"file_name"`   // 文件名
	FileType   int8   `json:"file_type"`   // 文件类型 1日志 2升级包
	DeviceType int8   `json:"device_type"` // 设备类型 0未知 1雷达 2反制抢 3droneID
	Sn         string `json:"sn"`
	PkgType    int32  `json:"pkg_type"` //升级包语言类型：1 俄文
	Platform   string `json:"platform"` //C2升级包平台
}

// 下载C2apk使用的结构体
type RequestC2Apk struct {
	FileName string `json:"file_name"` // 文件名
}

// 获取c2apk桶里所有对象使用的结构体
type RequestC2ApkAll struct {
	BucketName string `json:"bucket_name"` // 桶名
	PkgType    int32  `json:"pkg_type"`    //升级包语言类型：1 俄文
	Prefix     string `json:"prefix"`      //文件夹路径
}
type RequestC2ApkAllResp struct {
	FileName []*string `json:"file_name_list"` // 文件名
}

// 获取C2升级信息
type RequestC2UpgradeDes struct {
	Version  string `json:"version"`
	PkgType  int32  `json:"pkg_type"`
	Platform string `json:"platform"`
}
type RequestC2UpgradeDesRes struct {
	UpgradeDes        string `json:"upgrade_des"`
	IsForceUpgrade    bool   `json:"is_force_upgrade"`
	UpgradeDesChinese string `json:"upgrade_des_chinese"`
	UpgradeDesEnglish string `json:"upgrade_des_english"`
	UpgradeDesRussian string `json:"upgrade_des_russian"`
}

// 获取Tracer升级信息
type RequestTracerInfoReq struct {
	DevType int `json:"devType"`
}
type RequestTracerInfoRes struct {
	Info []TracerInfo
}
type TracerInfo struct {
	Version    string `json:"version"`
	UpgradeDes string `json:"upgrade_des"`
}

type TracerUpgradeInfo struct {
	List []TracerUpgradeList `json:"list"`
}
type TracerUpgradeList struct {
	Version            string `json:"version"`
	UpgradeDesc        string `json:"upgrade_des"`
	UpgradeDescChinese string `json:"upgrade_des_chinese"`
	UpgradeDescEnglish string `json:"upgrade_des_english"`
	UpgradeDescRussian string `json:"upgrade_des_russian"`
}

// 删除文件的结构体
type FileDeleteReq struct {
	FileType   int8   `json:"file_type"`   // 文件类型 1日志 2升级包
	FileKey    string `json:"file_key"`    // 文件Key
	FileName   string `json:"file_name"`   // 文件名
	DeviceType int8   `json:"device_type"` // 设备类型 0未知 1雷达 2反制抢 3droneID
	Sn         string `json:"sn"`
}

//返回响应使用的结构体

type PreSignUrlResp struct {
	Method  string      `json:"method"`
	URL     string      `json:"url"`
	FileKey string      `json:"fileKey"`
	Header  http.Header `json:"header"`
}
type PreSignUrlRespCom struct {
	Code int         `json:"code"`
	Data interface{} `json:"data"`
	Msg  string      `json:"msg"`
}

// -------------------------
type PresignedS3 struct {
	PresignClientS3 *s3.PresignClient
}

type FileListReq struct {
	Page     int    `json:"page"`      // 页码
	PageSize int    `json:"pageSize"`  // 每页大小
	FileType int8   `json:"file_type"` // 文件类型 1日志 2升级包
	MacNo    string `json:"mac_no"`    // mac设备号
}

type GetDirResp struct {
	Code int            `json:"code"`
	Data GetDirListResp `json:"data"`
	Msg  string         `json:"msg"`
}
type GetDirListResp struct {
	List     []ListStr `json:"list"`
	Total    int       `json:"total"`
	Page     int       `json:"page"`
	PageSize int       `json:"pageSize"`
}
type ListStr struct {
	ID         uint      `gorm:"primarykey"` // 主键ID
	CreatedAt  time.Time // 创建时间
	UpdatedAt  time.Time // 更新时间
	FileKey    string    `json:"file_key"`    // 文件key
	FileName   string    `json:"file_name"`   // 文件名
	Sn         string    `json:"sn"`          // 设备sn号
	S3Url      string    `json:"s3_url"`      // S3中存储地址
	MacNo      string    `json:"mac_no"`      // mac设备号
	MacAddr    string    `json:"mac_addr"`    // mac地址
	UserName   string    `json:"user_name"`   // 用户名
	FileType   string    `json:"file_type"`   // 文件类型
	FileSize   int       `json:"file_size"`   // 文件大小
	DeviceType int8      `json:"device_type"` // 更新包类型 0未知 1雷达 2反制抢 3droneID
	Status     int8      `json:"status"`      // 上传状态 0待上传 1上传成功 2上传失败
}
type C2LicenseReq struct {
	MacAddr string `json:"mac_addr"` // Mac地址
}

type GetLicenseResp struct {
	Code int                `json:"code"`
	Data GetLicenseListResp `json:"data"`
	Msg  string             `json:"msg"`
}
type GetLicenseListResp struct {
	List     []LicenseListStr `json:"list"`
	Total    int              `json:"total"`
	Page     int              `json:"page"`
	PageSize int              `json:"pageSize"`
}

type LicenseListStr struct {
	ID          uint      `gorm:"primarykey"` // 主键ID
	CreatedAt   time.Time // 创建时间
	UpdatedAt   time.Time // 更新时间
	LicenseId   string    `json:"license_id"`   // license序列号
	MacAddr     string    `json:"mac_addr"`     // mac地址
	StartTime   string    `json:"start_time"`   // license开始使用时间
	StopTime    string    `json:"stop_time"`    // license到期时间
	LastTime    string    `json:"last_time"`    // 最新一次上报时间
	Expires     int32     `json:"expires"`      //有效时间
	LicenseType string    `json:"license_type"` //1正式版 2试用版  3测试版
	UserName    string    `json:"user_name"`    //用户名称
	UserPhone   string    `json:"user_phone"`   //用户电话
	UserEmail   string    `json:"user_email"`   //用户电子邮件
}

package awsS3

import (
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/ota"
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"github.com/awsdocs/aws-doc-sdk-examples/gov2/s3/scenarios"
)

type Response struct {
	Code int         `json:"code"`
	Data interface{} `json:"data"`
	Msg  string      `json:"msg"`
}

// PresigningUploadFile 预签名方式上传文件
func PresigningUploadFile(fileType FileType, devType DevType, userName, sn, filePath, fileName string) error {
	logger.Info("------>Begin Upload File")

	addr, err := GetMacAddr()
	if err != nil {
		logger.Error("Get Mac Addr err:%v", err)
	}
	uploadFile, err := os.Open(filePath + fileName)
	if err != nil {
		logger.Error("Open file [%v] err:%v", filePath+fileName, err)
		return err
	}
	defer uploadFile.Close()

	info, err := uploadFile.Stat()
	if err != nil {
		logger.Error("File Stat err:%v", err)
		return err
	}
	if info.Size() == 0 {
		return errors.New("文件内容为空,上传失败。")
	}
	// 创建HTTP请求
	url := "http://ec2-52-83-173-24.cn-northwest-1.compute.amazonaws.com.cn:80/logFile/uploadPreSignUrl"
	reqData := LogUploadPreSignUrlReq{
		FileName:   fileName,
		Sn:         sn,
		MacNo:      addr,
		UserName:   userName,
		FileType:   int8(fileType),
		FileSize:   info.Size(),
		DeviceType: int8(devType),
	}
	jsonStr, _ := json.Marshal(reqData)
	logger.Info("reqData:", reqData)

	req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonStr))
	if err != nil {
		logger.Error("DownLoadFile New Request err:%v", err)
		return err
	}

	req.Header.Set("Content-Type", "application/json")

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		logger.Error("Client Do err:%v", err)
		return err
	}
	defer resp.Body.Close()

	// 读取HTTP响应体
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		logger.Error("ioutil ReadAll err:%v", err)
		return err
	}
	var data PreSignUrlRespCom
	err = json.Unmarshal(body, &data)
	if err != nil {
		logger.Error("Unmarshal err:%v", err)
		return err
	}
	//var httpRequester scenarios.HttpRequester
	dataStr, err := json.Marshal(data.Data)
	if err != nil {
		logger.Error("err json.Marshal:%v \n", err)
		return err
	}
	var dataRes PreSignUrlResp
	if err = json.Unmarshal(dataStr, &dataRes); err != nil {
		logger.Error("err json.Unmarshal(dataStr, &data):%v \n", err)
		return err
	}
	logger.Info("rsp data:", dataRes)
	//获取到上传文件地址,开始上传文件
	upReq, err := http.NewRequest(dataRes.Method, dataRes.URL, nil)
	if err != nil {
		logger.Error("err http.NewRequest:%v \n", err)
		return err
	}
	for k, vs := range dataRes.Header {
		for _, v := range vs {
			upReq.Header.Add(k, v)
		}
	}
	if contLen := upReq.Header.Get("Content-Length"); len(contLen) > 0 {
		upReq.ContentLength, _ = strconv.ParseInt(contLen, 10, 64)
	}
	upReq.Body = uploadFile

	resp, err = client.Do(upReq)
	if err != nil {
		logger.Error("err client.Do(upReq):%v \n", err)
		return err
	}
	//putResponse, err := httpRequester.Put(data.Data.URL, info.Size(), uploadFile)
	//if err != nil {
	//	logger.Error("Http Put err:%v", err)
	//	return err
	//}

	//todo 调接口，返回上传状态
	logger.Info("%v object %v with presigned URL returned %v.", dataRes.Method, fileName, resp.StatusCode)
	logger.Info("Upload file Suc.")
	logger.Info("------>End Upload File")
	return nil
}

// PresigningDownLoadFile 预签名方式下载日志文件
func PresigningDownLoadFile(fileType FileType, devType DevType, sn, fileName string) ([]byte, error) {
	logger.Info("------>Begin DownLoad File")
	client := &http.Client{}

	reqData := RequestData{
		FileName:   fileName,
		FileType:   int8(fileType),
		DeviceType: int8(devType),
		Sn:         sn,
	}
	// 创建HTTP请求
	url := "http://ec2-52-83-173-24.cn-northwest-1.compute.amazonaws.com.cn:80/logFile/downloadPreSignUrl"

	jsonStr, _ := json.Marshal(reqData)
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonStr))
	if err != nil {
		logger.Error("DownLoadFile New Request err:%v", err)
		return nil, err
	}

	req.Header.Set("Content-Type", "application/json")

	resp, err := client.Do(req)
	if err != nil {
		logger.Error("Client Do err:%v", err)
		return nil, err
	}
	defer resp.Body.Close()

	// 读取HTTP响应体
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		logger.Error("ioutil ReadAll err:%v", err)
		return nil, err
	}

	var data PreSignUrlRespCom
	err = json.Unmarshal(body, &data)
	if err != nil {
		logger.Error("Unmarshal err:%v", err)
		return nil, err
	}
	//var httpRequester scenarios.HttpRequester
	dataStr, err := json.Marshal(data.Data)
	if err != nil {
		logger.Error("err json.Marshal:%v \n", err)
		return nil, err
	}
	var dataRes PreSignUrlResp
	if err = json.Unmarshal(dataStr, &dataRes); err != nil {
		logger.Error("err json.Unmarshal(dataStr, &data):%v \n", err)
		return nil, err
	}
	logger.Info("rsp data:", dataRes)

	var httpRequester scenarios.HttpRequester
	//获取到下载文件地址，开始下载文件
	getResponse, err := httpRequester.Get(dataRes.URL)
	if err != nil {
		logger.Error("Http Get fail", err)
		return nil, err
	}
	defer getResponse.Body.Close()
	downloadBody, err := io.ReadAll(getResponse.Body)
	if err != nil {
		logger.Error("Io ReadAll fail", err)
		return nil, err
	}
	logger.Info("Down load Suc")
	logger.Info("------>End DownLoad File")
	return downloadBody, nil
}

// PresigningDownLoadApk 预签名方式下载C2APK
func PresigningDownLoadApk(fileName string, isHaveLogo bool, isHome bool, pkgType int32, platform string) (string, error) {
	logger.Info("------>Begin DownLoad C2 APK :", isHaveLogo, pkgType, fileName)
	client := &http.Client{}

	reqData := RequestData{
		FileName: fileName,
		PkgType:  pkgType,
		Platform: platform,
	}
	url := ""
	// 创建HTTP请求
	if isHome { //国内
		if isHaveLogo {
			url = "http://ec2-52-83-173-24.cn-northwest-1.compute.amazonaws.com.cn:80/c2Package/downloadPreSignUrl"
		} else {
			url = "http://ec2-52-83-173-24.cn-northwest-1.compute.amazonaws.com.cn:80/c2PackageNoLogo/downloadPreSignUrl"
		}
	} else { //国外
		if isHaveLogo {
			url = "http://ec2-13-250-116-240.ap-southeast-1.compute.amazonaws.com/c2Package/downloadPreSignUrl"
		} else {
			url = "http://ec2-13-250-116-240.ap-southeast-1.compute.amazonaws.com/c2PackageNoLogo/downloadPreSignUrl"
		}
	}

	jsonStr, _ := json.Marshal(reqData)
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonStr))
	if err != nil {
		logger.Error("DownLoadFile New Request err:%v", err)
		return "", err
	}

	req.Header.Set("Content-Type", "application/json")

	resp, err := client.Do(req)
	if err != nil {
		logger.Error("Client Do err:%v", err)
		return "", err
	}
	defer resp.Body.Close()

	// 读取HTTP响应体
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		logger.Error("ioutil ReadAll err:%v", err)
		return "", err
	}

	var data PreSignUrlRespCom
	err = json.Unmarshal(body, &data)
	if err != nil {
		logger.Error("Unmarshal err:%v", err)
		return "", err
	}
	//var httpRequester scenarios.HttpRequester
	dataStr, err := json.Marshal(data.Data)
	if err != nil {
		logger.Error("err json.Marshal:%v \n", err)
		return "", err
	}
	var dataRes PreSignUrlResp
	if err = json.Unmarshal(dataStr, &dataRes); err != nil {
		logger.Error("err json.Unmarshal(dataStr, &data):%v \n", err)
		return "", err
	}
	logger.Info("rsp data:", dataRes)

	logger.Info("------>End DownLoad C2Apk")
	return dataRes.URL, nil
}

// TestPresigningDownLoadApk 预签名方式下载C2APK
func TestPresigningDownLoadApk(fileName string, isHaveLogo bool, isHome bool, pkgType int32, platform string) (string, error) {
	logger.Info("------>Begin DownLoad C2 APK :", isHaveLogo, pkgType, fileName)
	client := &http.Client{}

	reqData := RequestData{
		FileName: fileName,
		PkgType:  pkgType,
		Platform: platform,
	}
	url := ""
	if isHaveLogo {
		url = "http://ec2-52-83-173-24.cn-northwest-1.compute.amazonaws.com.cn:80/c2Package/test/downloadPreSignUrl"
	} else {
		url = "http://ec2-52-83-173-24.cn-northwest-1.compute.amazonaws.com.cn:80/c2Package/test/nologo/downloadPreSignUrl"
	}

	jsonStr, _ := json.Marshal(reqData)
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonStr))
	if err != nil {
		logger.Error("DownLoadFile New Request err:%v", err)
		return "", err
	}

	req.Header.Set("Content-Type", "application/json")

	resp, err := client.Do(req)
	if err != nil {
		logger.Error("Client Do err:%v", err)
		return "", err
	}
	defer resp.Body.Close()

	// 读取HTTP响应体
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		logger.Error("ioutil ReadAll err:%v", err)
		return "", err
	}

	var data PreSignUrlRespCom
	err = json.Unmarshal(body, &data)
	if err != nil {
		logger.Error("Unmarshal err:%v", err)
		return "", err
	}
	//var httpRequester scenarios.HttpRequester
	dataStr, err := json.Marshal(data.Data)
	if err != nil {
		logger.Error("err json.Marshal:%v \n", err)
		return "", err
	}
	var dataRes PreSignUrlResp
	if err = json.Unmarshal(dataStr, &dataRes); err != nil {
		logger.Error("err json.Unmarshal(dataStr, &data):%v \n", err)
		return "", err
	}
	logger.Info("rsp data:", dataRes)

	logger.Info("------>End DownLoad C2Apk")
	return dataRes.URL, nil
}

// PresigningDeleteFile    预签名方式删除文件
func PresigningDeleteFile(fileType FileType, devType DevType, sn, fileName string) (Code, error) {
	logger.Info("------>Begin Delete File")
	reqData := FileDeleteReq{
		FileName:   fileName,
		FileType:   int8(fileType),
		DeviceType: int8(devType),
		Sn:         sn,
	}
	// 创建HTTP请求
	url := "http://ec2-52-83-173-24.cn-northwest-1.compute.amazonaws.com.cn/file/delete"

	jsonStr, _ := json.Marshal(reqData)
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonStr))
	if err != nil {
		logger.Error("Delete File New Request err:%v", err)
		return ERROR, err
	}

	req.Header.Set("Content-Type", "application/json")

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		logger.Error("Client Do err:%v", err)
		return ERROR, err
	}
	defer resp.Body.Close()

	// 读取HTTP响应体
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		logger.Error("ioutil ReadAll err:%v", err)
		return ERROR, err
	}
	var data PreSignUrlRespCom
	err = json.Unmarshal(body, &data)
	if err != nil {
		logger.Error("Unmarshal err:%v", err)
		return ERROR, err
	}
	if data.Code != 0 {
		logger.Error("data Code:%v", data.Code)
		return ERROR, err
	}
	logger.Info("Delete File Suc")
	logger.Info("------>End Delete File")
	return SUC, nil
}

// 获取桶中所有对象
func GetBucketObject(isHaveLogo bool, isHome bool, pkgType int32) []string {
	logger.Info("------>Begin Get Bucket Object,", pkgType)
	client := &http.Client{}
	buckName := ""
	url := ""

	if isHome { //国内
		if isHaveLogo {
			buckName = "c2apk"
			url = "http://ec2-52-83-173-24.cn-northwest-1.compute.amazonaws.com.cn:80/c2Package/getAllObject"
			if pkgType == 1 {
				buckName = "c2apkrussian"
			}
		} else {
			buckName = "nologoc2apk"
			url = "http://ec2-52-83-173-24.cn-northwest-1.compute.amazonaws.com.cn:80/c2PackageNoLogo/getAllObject"
			if pkgType == 1 {
				buckName = "nologoc2apkrussian"
			}
		}
	} else { //国外
		if isHaveLogo {
			buckName = "c2apk"
			url = "http://ec2-13-250-116-240.ap-southeast-1.compute.amazonaws.com/c2Package/getAllObject"
			if pkgType == 1 {
				buckName = "c2apkrussian"
			}
		} else {
			buckName = "nologoc2apk"
			url = "http://ec2-13-250-116-240.ap-southeast-1.compute.amazonaws.com/c2PackageNoLogo/getAllObject"
			if pkgType == 1 {
				buckName = "nologoc2apkrussian"
			}
		}
	}
	reqData := RequestC2ApkAll{
		BucketName: buckName,
		PkgType:    pkgType,
	}
	// 创建HTTP请求
	jsonStr, _ := json.Marshal(reqData)
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonStr))
	if err != nil {
		logger.Error("DownLoadFile New Request err:%v", err)
		return nil
	}

	req.Header.Set("Content-Type", "application/json")

	resp, err := client.Do(req)
	if err != nil {
		logger.Error("Client Do err:%v", err)
		return nil
	}
	defer resp.Body.Close()

	// 读取HTTP响应体
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		logger.Error("ioutil ReadAll err:%v", err)
		return nil
	}

	var data PreSignUrlRespCom
	err = json.Unmarshal(body, &data)
	if err != nil {
		logger.Error("Unmarshal err:%v", err)
		return nil
	}
	var strArray []string
	if dataArray, ok := data.Data.([]interface{}); ok {
		// 遍历 dataArray，将每个元素转换为 string 类型
		for _, item := range dataArray {
			if strings.Contains(item.(string), ".json") {
				continue
			}
			if str, ok := item.(string); ok {
				strArray = append(strArray, str)
			}
		}
	} else {
		logger.Errorf("data.Data is not an array: %v", data.Data)
	}
	logger.Info("rsp data:", strArray)

	logger.Info("------>End DownLoad C2Apk")
	return strArray
}

// 获取桶中Windows所有对象
func GetBucketObjectWindows(isHaveLogo bool, isHome bool, pkgType int32) []string {
	logger.Info("------>Begin Get Bucket Object,", pkgType)
	client := &http.Client{}
	url := ""
	prefix := ""
	buckName := BucketC2WinName
	if isHome { //国内
		if isHaveLogo {
			prefix = PreFixC2WindowsCN
			url = "http://ec2-52-83-173-24.cn-northwest-1.compute.amazonaws.com.cn:80/c2Package/getAllObject"
			if pkgType == 1 {
				prefix = PreFixC2WindowsRussian
			}
		} else {
			prefix = PreFixNoLogoC2WindowsCN
			url = "http://ec2-52-83-173-24.cn-northwest-1.compute.amazonaws.com.cn:80/c2PackageNoLogo/getAllObject"
			if pkgType == 1 {
				prefix = PreFixNoLogoC2WindowsRussian
			}
		}
	} else { //国外
		if isHaveLogo {
			prefix = PreFixC2WindowsCN
			url = "http://ec2-13-250-116-240.ap-southeast-1.compute.amazonaws.com/c2Package/getAllObject"
			if pkgType == 1 {
				prefix = PreFixC2WindowsRussian
			}
		} else {
			prefix = PreFixNoLogoC2WindowsCN
			url = "http://ec2-13-250-116-240.ap-southeast-1.compute.amazonaws.com/c2PackageNoLogo/getAllObject"
			if pkgType == 1 {
				prefix = PreFixNoLogoC2WindowsRussian
			}
		}
	}

	reqData := RequestC2ApkAll{
		BucketName: buckName,
		PkgType:    pkgType,
		Prefix:     prefix,
	}
	logger.Info("------------> Get All Bucket:", reqData)
	// 创建HTTP请求
	jsonStr, _ := json.Marshal(reqData)
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonStr))
	if err != nil {
		logger.Error("DownLoadFile New Request err:%v", err)
		return nil
	}

	req.Header.Set("Content-Type", "application/json")

	resp, err := client.Do(req)
	if err != nil {
		logger.Error("Client Do err:%v", err)
		return nil
	}
	defer resp.Body.Close()

	// 读取HTTP响应体
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		logger.Error("ioutil ReadAll err:%v", err)
		return nil
	}

	var data PreSignUrlRespCom
	err = json.Unmarshal(body, &data)
	if err != nil {
		logger.Error("Unmarshal err:%v", err)
		return nil
	}
	var strArray []string
	if dataArray, ok := data.Data.([]interface{}); ok {
		// 遍历 dataArray，将每个元素转换为 string 类型
		for _, item := range dataArray {
			if strings.Contains(item.(string), ".json") {
				continue
			}
			if str, ok := item.(string); ok {
				strArray = append(strArray, str)
			}
		}
	} else {
		logger.Errorf("data.Data is not an array: %v", data.Data)
	}
	logger.Info("rsp data:", strArray)

	logger.Info("------>End DownLoad C2Apk")
	return strArray
}

// 获取桶中Windows所有对象
func TestGetBucketObject(isHaveLogo bool, isHome bool, pkgType int32) []string {
	logger.Info("------>Test Begin Get Bucket Object,", pkgType)
	client := &http.Client{}
	url := ""
	prefix := ""
	buckName := TestBucketC2
	url = "http://ec2-52-83-173-24.cn-northwest-1.compute.amazonaws.com.cn:80/c2Package/test/getAllObject"
	if isHaveLogo {
		prefix = TestPreFixC2CN
		if pkgType == 1 {
			prefix = TestPreFixC2Russian
		}
	} else {
		prefix = TestPreFixNoLogoC2CN
		if pkgType == 1 {
			prefix = TestPreFixNoLogoC2Russian
		}
	}

	reqData := RequestC2ApkAll{
		BucketName: buckName,
		PkgType:    pkgType,
		Prefix:     prefix,
	}
	logger.Info("------------> Get All Bucket:", reqData)
	// 创建HTTP请求
	jsonStr, _ := json.Marshal(reqData)
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonStr))
	if err != nil {
		logger.Error("DownLoadFile New Request err:%v", err)
		return nil
	}

	req.Header.Set("Content-Type", "application/json")

	resp, err := client.Do(req)
	if err != nil {
		logger.Error("Client Do err:%v", err)
		return nil
	}
	defer resp.Body.Close()

	// 读取HTTP响应体
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		logger.Error("ioutil ReadAll err:%v", err)
		return nil
	}

	var data PreSignUrlRespCom
	err = json.Unmarshal(body, &data)
	if err != nil {
		logger.Error("Unmarshal err:%v", err)
		return nil
	}
	var strArray []string
	if dataArray, ok := data.Data.([]interface{}); ok {
		// 遍历 dataArray，将每个元素转换为 string 类型
		for _, item := range dataArray {
			if strings.Contains(item.(string), ".json") {
				continue
			}
			if str, ok := item.(string); ok {
				strArray = append(strArray, str)
			}
		}
	} else {
		logger.Errorf("data.Data is not an array: %v", data.Data)
	}
	logger.Info("rsp data:", strArray)

	logger.Info("------>End DownLoad C2Apk")
	return strArray
}

// 获取C2升级信息
func GetC2UpgradeDes(version string, isHome bool, isHavelogo bool, pkgType int32, platform string) (string, bool, string, string, string) {
	logger.Info("------>Begin Get  C2UpgradeDes")
	client := &http.Client{}
	url := ""
	if isHome { //国内
		if isHavelogo == true {
			url = "http://ec2-52-83-173-24.cn-northwest-1.compute.amazonaws.com.cn:80/c2Package/getUpgradeDes"
		} else {
			url = "http://ec2-52-83-173-24.cn-northwest-1.compute.amazonaws.com.cn:80/c2PackageNoLogo/getUpgradeDes"
		}
	} else { //国外
		if isHavelogo == true {
			url = "http://ec2-13-250-116-240.ap-southeast-1.compute.amazonaws.com/c2Package/getUpgradeDes"
		} else {
			url = "http://ec2-13-250-116-240.ap-southeast-1.compute.amazonaws.com/c2PackageNoLogo/getUpgradeDes"
		}
	}

	reqData := RequestC2UpgradeDes{
		Version:  version,
		PkgType:  pkgType,
		Platform: platform,
	}

	// 创建HTTP请求
	jsonStr, _ := json.Marshal(reqData)
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonStr))
	if err != nil {
		logger.Error("DownLoadFile New Request err:%v", err)
		return "", false, "", "", ""
	}

	req.Header.Set("Content-Type", "application/json")

	resp, err := client.Do(req)
	if err != nil {
		logger.Error("Client Do err:%v", err)
		return "", false, "", "", ""
	}
	defer resp.Body.Close()

	// 读取HTTP响应体
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		logger.Error("ioutil ReadAll err:%v", err)
		return "", false, "", "", ""
	}

	var data PreSignUrlRespCom
	err = json.Unmarshal(body, &data)
	if err != nil {
		logger.Error("Unmarshal err:%v", err)
		return "", false, "", "", ""
	}
	dataStr, err := json.Marshal(data.Data)
	if err != nil {
		logger.Error("err json.Marshal:%v \n", err)
		return "", false, "", "", ""
	}
	var dataRes RequestC2UpgradeDesRes
	if err = json.Unmarshal(dataStr, &dataRes); err != nil {
		logger.Error("err json.Unmarshal(dataStr, &data):%v \n", err)
		return "", false, "", "", ""
	}
	logger.Info("rsp data:", dataRes)

	logger.Info("------>End Get  C2UpgradeDes")
	return dataRes.UpgradeDes, dataRes.IsForceUpgrade, dataRes.UpgradeDesChinese, dataRes.UpgradeDesEnglish, dataRes.UpgradeDesRussian
}

// Test获取C2升级信息
func TestGetC2UpgradeDes(version string, isHome bool, isHavelogo bool, pkgType int32, platform string) (string, bool, string, string, string) {
	logger.Info("------>Begin Get  C2UpgradeDes")
	client := &http.Client{}
	url := "http://ec2-52-83-173-24.cn-northwest-1.compute.amazonaws.com.cn:80/c2Package/test/getUpgradeDes"

	reqData := RequestC2UpgradeDes{
		Version:  version,
		PkgType:  pkgType,
		Platform: platform,
	}

	// 创建HTTP请求
	jsonStr, _ := json.Marshal(reqData)
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonStr))
	if err != nil {
		logger.Error("DownLoadFile New Request err:%v", err)
		return "", false, "", "", ""
	}

	req.Header.Set("Content-Type", "application/json")

	resp, err := client.Do(req)
	if err != nil {
		logger.Error("Client Do err:%v", err)
		return "", false, "", "", ""
	}
	defer resp.Body.Close()

	// 读取HTTP响应体
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		logger.Error("ioutil ReadAll err:%v", err)
		return "", false, "", "", ""
	}

	var data PreSignUrlRespCom
	err = json.Unmarshal(body, &data)
	if err != nil {
		logger.Error("Unmarshal err:%v", err)
		return "", false, "", "", ""
	}
	dataStr, err := json.Marshal(data.Data)
	if err != nil {
		logger.Error("err json.Marshal:%v \n", err)
		return "", false, "", "", ""
	}
	var dataRes RequestC2UpgradeDesRes
	if err = json.Unmarshal(dataStr, &dataRes); err != nil {
		logger.Error("err json.Unmarshal(dataStr, &data):%v \n", err)
		return "", false, "", "", ""
	}
	logger.Info("rsp data:", dataRes)

	logger.Info("------>End Get  C2UpgradeDes")
	return dataRes.UpgradeDes, dataRes.IsForceUpgrade, dataRes.UpgradeDesChinese, dataRes.UpgradeDesEnglish, dataRes.UpgradeDesRussian
}

func GetTracerUpgradeJson(deviceType int32, path string) (*TracerUpgradeInfo, error) {
	rspList := &TracerUpgradeInfo{}
	rspListInfo := make([]TracerUpgradeList, 0)

	rspTracerP, err := GetUpgradeInfo(ota.DeviceTypeTracerP, path)
	if err != nil {
		logger.Error("GetUpgradeInfo tracerP err:", err)
	}
	if rspTracerP != nil {
		for _, listP := range rspTracerP.List {
			rspListInfo = append(rspListInfo, listP)
		}
	}
	//else {
	//	rspTracerP, err = ota.GetLocalUpgradeInfo(ota.DeviceTypeTracerP, path)
	//	if err != nil {
	//		logger.Error("GetLocalUpgradeInfo tracerP err:", err)
	//	}
	//	if rspTracerP != nil {
	//		for _, listP := range rspTracerP.List {
	//			rspListInfo = append(rspListInfo, listP)
	//		}
	//	}
	//
	//}
	rspTracerS, err := GetUpgradeInfo(ota.DeviceTypeTracerS, path)
	if err != nil {
		logger.Error("GetUpgradeInfo tracerS err:", err)
	}
	if rspTracerS != nil {
		for _, listS := range rspTracerS.List {
			rspListInfo = append(rspListInfo, listS)
		}
	}
	rspList.List = rspListInfo
	logger.Info("Rsp info is :", rspList.List)
	return rspList, nil
}
func GetUpgradeInfo(deviceType int32, path string) (*TracerUpgradeInfo, error) {
	var result *TracerUpgradeInfo
	filePath := ota.LocalOtaPkgPathMap[deviceType]
	if filePath == "" {
		return nil, errors.New("file path is err")
	}
	path = filepath.Join(path, filePath)

	logger.Info("------>Begin download Tracer Json:", path)
	url := "http://ec2-52-83-173-24.cn-northwest-1.compute.amazonaws.com.cn:80/otaPackage/getUpgradeInfo"
	reqData := RequestTracerInfoReq{
		DevType: int(deviceType),
	}

	jsonData, err := json.Marshal(reqData)
	if err != nil {
		logger.Errorf("json.Marshal err: %v", err)
		return nil, err
	}
	request, _ := http.NewRequest("POST", url, bytes.NewBuffer(jsonData))
	request.Header.Set("Content-Type", "application/json")

	client := &http.Client{
		Timeout: time.Second * 3,
	}
	response, err := client.Do(request)
	if err != nil || response == nil {
		logger.Errorf("get json file err:", err)
		return nil, err
	}

	defer response.Body.Close()

	rsp := Response{}
	if err := json.NewDecoder(response.Body).Decode(&rsp); err != nil {
		logger.Errorf("err json.NewDecoder:%v \n", err)
		return nil, err
	}
	if rsp.Code != 0 {
		return nil, errors.New(rsp.Msg)
	}
	dataStr, err := json.Marshal(rsp.Data)
	if err != nil {
		logger.Errorf("err json.Marshal:%v \n", err)
		return nil, err
	}

	if err = json.Unmarshal(dataStr, &result); err != nil {
		logger.Errorf("err json.Unmarshal(dataStr, &result):%v \n", err)
		return nil, err
	}

	filename := ""

	if deviceType == ota.DeviceTypeTracerS {
		filename = "tracerS.json"
	}
	if deviceType == ota.DeviceTypeTracerP {
		filename = "tracerP.json"
	}
	marshalData, err := json.MarshalIndent(result.List, "", "\t")
	if err := os.MkdirAll(path, 0666); err != nil {
		logger.Errorf("failed to os.Create, %v \n", err)
		return nil, err
	}
	f, err := os.Create(filepath.Join(path, filename))
	if err != nil {
		logger.Errorf("Local err: %v \n", err)
		return nil, err
	}
	defer f.Close()
	_, _ = f.Write(marshalData)
	return result, nil
}

func GetDirFile(fileType FileType) (error, GetDirResp) {
	logger.Info("------>Begin GetDir File")
	var data GetDirResp

	//addr, err := GetMacAddr()
	//if err != nil {
	//	logger.Info("Get Mac Addr err:%v", err)
	//}
	reqData := FileListReq{
		FileType: int8(fileType),
	}
	// 创建HTTP请求
	url := "http://ec2-52-83-173-24.cn-northwest-1.compute.amazonaws.com.cn/file/list"

	jsonStr, _ := json.Marshal(reqData)
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonStr))
	if err != nil {
		logger.Error("GetDirFile New Request err: ", err)
		return err, data
	}

	req.Header.Set("Content-Type", "application/json")

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		logger.Error("Client Do err: ", err)
		return err, data
	}
	defer resp.Body.Close()

	// 读取HTTP响应体
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		logger.Error("ioutil ReadAll err: ", err)
		return err, data
	}

	err = json.Unmarshal(body, &data)
	if err != nil {
		logger.Error("Unmarshal err: ", err)
		return err, data
	}
	if data.Code != 0 {
		logger.Error("data Code: ", data.Code)
		return err, data
	}

	logger.Info("GetDir File Suc")
	logger.Info("------>End GetDir File")
	return nil, data
}

func GetLicenseList() (error, GetLicenseResp) {
	logger.Info("------>Begin Get License List")
	var data GetLicenseResp

	//addr, err := GetMacAddr()
	//if err != nil {
	//	logger.Info("Get Mac Addr err:%v", err)
	//}
	reqData := FileListReq{}
	// 创建HTTP请求
	url := "http://ec2-52-83-173-24.cn-northwest-1.compute.amazonaws.com.cn/c2License/getAllLicense"

	jsonStr, _ := json.Marshal(reqData)
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonStr))
	if err != nil {
		logger.Error("Get License List New Request err: ", err)
		return err, data
	}

	req.Header.Set("Content-Type", "application/json")

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		logger.Error("Client Do err: ", err)
		return err, data
	}
	defer resp.Body.Close()

	// 读取HTTP响应体
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		logger.Error("ioutil ReadAll err: ", err)
		return err, data
	}

	err = json.Unmarshal(body, &data)
	if err != nil {
		logger.Error("Unmarshal err: ", err)
		return err, data
	}
	if data.Code != 0 {
		logger.Error("data Code: ", data.Code)
		return err, data
	}

	logger.Info("Get License List Suc")
	logger.Info("------>End Get License List")
	return nil, data
}
func InsertLicense(macAddr string) error {
	logger.Info("------>Begin Insert License")

	//addr, err := GetMacAddr()
	//if err != nil {
	//	logger.Info("Get Mac Addr err:%v", err)
	//}
	reqData := C2LicenseReq{
		MacAddr: macAddr,
	}
	// 创建HTTP请求
	url := "http://ec2-52-83-173-24.cn-northwest-1.compute.amazonaws.com.cn/c2License/insertLicense"

	jsonStr, _ := json.Marshal(reqData)
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonStr))
	if err != nil {
		logger.Error("Insert License New Request err: ", err)
		return err
	}

	req.Header.Set("Content-Type", "application/json")

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		logger.Error("Client Do err: ", err)
		return err
	}
	defer resp.Body.Close()

	// 读取HTTP响应体
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		logger.Error("ioutil ReadAll err: ", err)
		return err
	}
	var data PreSignUrlRespCom
	err = json.Unmarshal(body, &data)
	logger.Info("data  Code is :", data.Code)
	logger.Info("data  Msg is :", data.Msg)
	if err != nil {
		logger.Error("Unmarshal err: ", err)
		return err
	}
	if data.Msg != "ok" {
		logger.Error("data Code: ", data.Code)
		return err
	}

	logger.Info("Insert License Suc")
	logger.Info("------>End Insert License")
	return nil
}

func (r *CustomReader) Read(p []byte) (int, error) {
	return r.fp.Read(p)
}

// GetMacAddr 获取本机的MAC地址
func GetMacAddr() (string, error) {
	// 获取本机的网络接口列表
	ifaces, err := net.Interfaces()
	if err != nil {
		return "", err
	}

	// 遍历网络接口列表，查找第一个硬件地址不为空的接口
	for _, iface := range ifaces {
		if iface.HardwareAddr != nil {
			return iface.HardwareAddr.String(), nil
		}
	}

	return "", fmt.Errorf("failed to find MAC address")
}

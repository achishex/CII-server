package threading

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"fmt"
	"runtime/debug"
)

// GoSafe 安全运行一个任务
func GoSafe(fn func()) {
	go RunSafe(fn)
}

// GoRecover is used with defer to do cleanup on panics.
// Use it like:
//
//	defer GoRecover(func() {})
func GoRecover(cleanups ...func()) {
	for _, cleanup := range cleanups {
		cleanup()
	}
	if p := recover(); p != nil {
		logger.Errorf(fmt.Sprintf("%s\n%s", fmt.Sprint(p), string(debug.Stack())))
	}
}

// RunSafe runs the given fn, recovers if fn panics
func RunSafe(fn func()) {
	defer GoRecover()
	fn()
}

package threading

import (
	"adasgitlab.autel.com/tools/cuav_server/test"
	"testing"
	"time"
)

func TestGoRoutines(t *testing.T) {
	test.LoggerMock()
	GoSafe(func() {
		var x *int = nil
		*x = 100
	})
	time.Sleep(10 * time.Millisecond)
}

package cache

import (
	"adasgitlab.autel.com/tools/cuav_plugin/cache/file"
	"adasgitlab.autel.com/tools/cuav_plugin/cache/memory"
	"go-micro.dev/v4/cache"
)

var (
	MemoryCache cache.Cache
	FileCache   cache.Cache
)

// Init 初始化缓存组件
//
// path: 持久化存储的地址
func Init(path string) {
	MemoryCache = memory.NewCache()
	FileCache = file.NewCache(path)
}

// Get 获取缓存组件
func Get() cache.Cache {
	return MemoryCache
}

// GetPersist 获取持久化的缓存组件
func GetPersist() cache.Cache {
	return FileCache
}

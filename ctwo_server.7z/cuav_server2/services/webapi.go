package services

import (
	"context"
	"fmt"
	"net/http"
	"os"
	"strconv"
	"sync"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_plugin/registry/memory"
	"adasgitlab.autel.com/tools/cuav_server/api/webapi"
	"adasgitlab.autel.com/tools/cuav_server/entity/config"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
	"github.com/emicklei/go-restful"
	"go-micro.dev/v4/web"
)

func StartWebApi(ctx context.Context, wg *sync.WaitGroup, stopChan chan int) {
	webApiServer(ctx, wg)
	stopChan <- 1
}

func webApiServer(ctx context.Context, wg *sync.WaitGroup) {
	// 初始化Broker
	mq.InitMemoryBroker()
	// 启动服务
	app := web.NewService(
		web.Server(&http.Server{}),
		web.Name(config.GetGlobalConfig().MicroSvc.WebApiSvc),
		web.Version(config.GetGlobalConfig().MicroSvc.Version),
		web.Registry(memory.NewRegistry()),
		web.Id(config.GetGlobalConfig().MicroSvc.WebApiSvc+"-1"),
		web.Address(config.GetGlobalConfig().Server.RestfulApiIp+":"+strconv.Itoa(config.GetGlobalConfig().Server.RestfulApiPort)),
		web.Metadata(map[string]string{"version": config.GetGlobalConfig().MicroSvc.Version, "protocol": "http"}),
		web.AfterStart(func() error {
			wg.Done()
			return nil
		}),
		web.AfterStop(func() error {
			logger.Info("webApi退出")
			return nil
		}),
		web.Context(ctx),
	)
	err := app.Init()
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error init webApi: %v\n", err)
		return
	}

	restful.DefaultResponseContentType(restful.MIME_JSON)
	//pb := utils.NewEntityProtoAccess("application/proto")
	//restful.RegisterEntityAccessor("application/proto", pb)
	wc := restful.NewContainer()
	cors := restful.CrossOriginResourceSharing{
		ExposeHeaders:  []string{"X-My-Header"},
		AllowedHeaders: []string{"Content-Type", "Accept"},
		AllowedMethods: []string{"GET", "POST"},
		CookiesAllowed: false,
		Container:      wc}
	wc.Filter(cors.Filter)
	wc.Filter(wc.OPTIONSFilter)
	ws := webapi.InitRouter()
	wc.Add(ws)
	app.Handle("/", wc)
	if err := app.Run(); err != nil {
		fmt.Fprintf(os.Stderr, "Error run webApi: %v\n", err)
	}

}

package services

import (
	"context"
	"os"
	"time"

	"adasgitlab.autel.com/tools/cuav_server/repo/kafka"
	"github.com/Shopify/sarama"
	"github.com/nxadm/tail"
)

var (
	KafkaProducer sarama.SyncProducer
)

// StartSyncLogSrv 监听日志文件并同步
func StartSyncLogSrv(logFilePath, addr, topic string, ctx context.Context) {
	// 监听日志文件变化
	t, err := tail.TailFile(logFilePath, tail.Config{
		Follow:    true,
		Location:  &tail.SeekInfo{Offset: 0, Whence: os.SEEK_END},
		MustExist: false,
		Poll:      true,
		Logger:    tail.DiscardingLogger,
	})
	if err != nil {
		return
	}
	KafkaProducer, err = kafka.GetKafkaProducer(addr)
	if err != nil {
		return
	}
	for {
		select {
		case line := <-t.Lines: // 监听文件变化
			LoopSendToKafka(line.Text, topic, addr, KafkaProducer)

		case <-ctx.Done():
			// 退出
			return
		}
	}
}

// LoopSendToKafka 向kafka发送数据，如果断网等原因发送失败等待120s尝试重发
func LoopSendToKafka(data, topic, addr string, client sarama.SyncProducer) {
	err := kafka.SendToKafka(data, topic, client)
	if err == nil {
		// 发送成功退出
		return
	}
	for {
		time.Sleep(time.Second * 120)
		// 尝试重连kafka
		KafkaProducer, err = kafka.GetKafkaProducer(addr)
		if err != nil {
			continue
		}
		err = kafka.SendToKafka(data, topic, KafkaProducer)
		if err == nil {
			// 发送成功退出
			return
		}
	}
}

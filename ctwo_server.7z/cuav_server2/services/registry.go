package services

import (
	"go-micro.dev/v4/server"
)

func WithId(id string) server.Option {
	return func(opt *server.Options) {
		opt.Id = id
	}
}

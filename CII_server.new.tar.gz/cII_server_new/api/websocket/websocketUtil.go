package websocket

import (
	"context"
	"errors"
	"fmt"
	"net/http"
	"sync"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/threatlevel"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
	"github.com/gin-gonic/gin"
	"github.com/gorilla/websocket"
	jsoniter "github.com/json-iterator/go"
	broker2 "go-micro.dev/v4/broker"
)

type WebSocketServer struct {
	ServerAddr   common.IpAddr
	mux          sync.Mutex
	server       *http.Server
	done         chan struct{}
	postureCache sync.Map
}

func (w *WebSocketServer) Start() {
	w.mux.Lock()
	defer w.mux.Unlock()
	w.done = make(chan struct{})
	engine := gin.Default()
	_ = engine.SetTrustedProxies(nil)

	// 设备心跳
	engine.GET("/ws/equipment/status", w.NewConnectionEquipStatus)
	// 雷达TCP消息盒子
	engine.GET("/ws/equipment/messagebox", w.NewConnectionEquipMessagebox)
	// 雷达TCP跟踪目标
	engine.GET("/ws/radar/track", w.NewConnectionRadarTrack)
	// 雷达TCP跟踪目标威胁等级
	engine.GET("/ws/radar/track/fuse", w.NewConnectionFuseRadarAndGun)
	// 雷达TCP姿态信息
	engine.GET("/ws/radar/posture", w.NewConnectionRadarPosture)
	// 雷达TCP波控信息
	engine.GET("/ws/radar/beam/config", w.NewConnectionRadarBeamConfig)
	// 枪心跳
	engine.GET("/ws/gun/heart", w.NewConnectionGunHeart)
	// 枪droneid心跳
	engine.GET("/ws/droneid/heart", w.NewConnectionDroneIdHeart)
	// v2 droneID heartbeat
	engine.GET("/ws/v2/droneid/heart", w.NewConnectionV2DroneIdHeart)
	// NSF4000
	engine.GET("/ws/nsf4000", w.NewConnectionNSF4000)
	// Tracer  detect
	engine.GET("/ws/v2/droneid/detect", w.NewConnectionV2DroneIdDetect)
	//Fpv   车载反制器
	engine.GET("/ws/fpv/msg", w.NewConnectionFpvMsg)
	//SFL   云台
	engine.GET("/ws/sfl/msg", w.NewConnectionSflMsg)
	//Agx   雷达融合平台
	engine.GET("/ws/agx/msg", w.NewConnectionAgxMsg)
	//Sfl200
	engine.GET("/ws/sfl200/msg", w.NewConnectionSfl200Msg)
	//数据回放
	engine.GET("/ws/replay/msg", w.NewReplayTransMsg)

	//dataMark
	engine.GET("/ws/data/mark", w.NewConnectionDataMark)

	addr := fmt.Sprintf("%s:%d", w.ServerAddr.Ip, w.ServerAddr.Port)
	w.server = &http.Server{
		Addr:    addr,
		Handler: engine,
	}
	go func() {
		if err := w.server.ListenAndServe(); err != nil {
			logger.Error("listen and serve error: ", err)
		}
	}()
	go func() {
		<-w.done
		ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
		defer cancel()
		if err := w.server.Shutdown(ctx); err != nil {
			logger.Error("server shutdown error: ", err)
		}
	}()
}

func (w *WebSocketServer) Close() {
	w.mux.Lock()
	defer w.mux.Unlock()
	if w.done != nil {
		close(w.done)
		w.done = nil
	}
}

var upGrader = &websocket.Upgrader{
	CheckOrigin: func(r *http.Request) bool { return true },
}

// ============================== Equipment status webSocket=================================

func (w *WebSocketServer) NewConnectionEquipStatus(c *gin.Context) {
	conn, err := upGrader.Upgrade(c.Writer, c.Request, nil)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"msg": "websocket server error! " + err.Error()})
		return
	}
	w.server.RegisterOnShutdown(func() {
		conn.Close()
	})
	logger.Debug("equip status websocket connect from: ", c.RemoteIP())

	// concurrent write
	mu := sync.Mutex{}
	sub, _ := mq.EquipmentStatusBroker.Subscribe(mq.EquipmentStatusTopic, func(event broker2.Event) error {
		mu.Lock()
		defer mu.Unlock()
		err = conn.WriteMessage(websocket.TextMessage, event.Message().Body)
		if err != nil {
			return fmt.Errorf("equip status websocket write message error: %v", err)
		}
		return nil
	})
	defer sub.Unsubscribe()

	for {
		_, message, err := conn.ReadMessage()
		if err != nil {
			logger.Error("equip status websocket err: ", err)
			conn.Close()
			break
		}
		logger.Debugf("equip status websocket receive message from[%v]: %v", c.RemoteIP(), message)
	}
}

// ============================== Equipment Messagebox webSocket=================================

func (w *WebSocketServer) NewConnectionEquipMessagebox(c *gin.Context) {
	conn, err := upGrader.Upgrade(c.Writer, c.Request, nil)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"msg": "websocket server error! " + err.Error()})
		return
	}
	w.server.RegisterOnShutdown(func() {
		conn.Close()
	})
	logger.Debug("equip messagebox websocket connect from: ", c.RemoteIP())

	// concurrent write
	mu := sync.Mutex{}
	sub, _ := mq.EquipMessageBoxBroker.Subscribe(mq.EquipMessageBoxTopic, func(event broker2.Event) error {
		mu.Lock()
		defer mu.Unlock()
		err = conn.WriteMessage(websocket.TextMessage, event.Message().Body)
		if err != nil {
			return fmt.Errorf("equip messagebox websocket write message error: %v", err)
		}
		return nil
	})
	defer sub.Unsubscribe()

	for {
		_, message, err := conn.ReadMessage()
		if err != nil {
			logger.Error("equip messagebox websocket err: ", err)
			conn.Close()
			break
		}
		logger.Debugf("equip messagebox websocket receive message from[%v]: %v", c.RemoteIP(), message)
	}
}

// ============================== radar track webSocket=================================

func (w *WebSocketServer) NewConnectionRadarTrack(c *gin.Context) {
	conn, err := upGrader.Upgrade(c.Writer, c.Request, nil)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"msg": "websocket server error! " + err.Error()})
		return
	}
	w.server.RegisterOnShutdown(func() {
		conn.Close()
	})
	logger.Debug("radar track websocket connect from: ", c.RemoteIP())

	// concurrent write
	mu := sync.Mutex{}
	sub, _ := mq.RadarTrackBroker.Subscribe(mq.RadarTrackTopic, func(event broker2.Event) error {
		mu.Lock()
		defer mu.Unlock()
		err = conn.WriteMessage(websocket.TextMessage, event.Message().Body)
		if err != nil {
			return fmt.Errorf("radar track websocket write message error: %v", err)
		}
		return nil
	})
	defer sub.Unsubscribe()

	for {
		_, message, err := conn.ReadMessage()
		if err != nil {
			logger.Error("radar track websocket err: ", err)
			conn.Close()
			break
		}
		logger.Debugf("radar track websocket receive message from[%v]: %v", c.RemoteIP(), message)
	}
}

// ============================== radar track fuse webSocket=================================

var (
	DefaultEleScanCenter int32   = 0
	DefaultEleScanScope  int32   = 40
	DefaultPitching      float64 = 20
)

type Posture struct {
	EleScanCenter int32
	EleScanScope  int32
	Pitching      float64
}

type RadarTrackMessagebox struct {
	Sn   string                                       `json:"sn"`
	Info []*common.DbRawAutelRadarPlotTrackBodyEntity `json:"info"`
}

type RadarFuseLevel struct {
	Sn    string `json:"sn"`
	ObjId uint32 `json:"obj_id"`
	Level int    `json:"level"`
}

func (w *WebSocketServer) NewConnectionFuseRadarAndGun(c *gin.Context) {
	conn, err := upGrader.Upgrade(c.Writer, c.Request, nil)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"msg": "websocket server error! " + err.Error()})
		return
	}
	w.server.RegisterOnShutdown(func() {
		conn.Close()
	})
	logger.Debug("radar track fuse websocket connect from: ", c.RemoteIP())

	pool := &sync.Pool{New: func() interface{} {
		return new(RadarTrackMessagebox)
	}}
	// concurrent write
	mu := sync.Mutex{}
	element := &threatlevel.JudgeElement{}
	sub, _ := mq.RadarTrackBroker.Subscribe(mq.RadarTrackTopic, func(event broker2.Event) error {
		entity := pool.Get().(*RadarTrackMessagebox)
		defer pool.Put(entity)
		err := jsoniter.Unmarshal(event.Message().Body, &entity)
		if err != nil {
			return fmt.Errorf("RadarTrackMessagebox Unmarshal error: %v", err)
		}
		if v, ok := w.postureCache.Load(entity.Sn); ok {
			element.EleScanCenter = v.(*Posture).EleScanCenter
			element.EleScanScope = v.(*Posture).EleScanScope
			element.Pitching = v.(*Posture).Pitching
		} else {
			element.EleScanCenter = DefaultEleScanCenter
			element.EleScanScope = DefaultEleScanScope
			element.Pitching = DefaultPitching
		}
		levels := make([]*RadarFuseLevel, 0)
		for i := 0; i < len(entity.Info); i++ {
			element.X = entity.Info[i].X
			element.Y = entity.Info[i].Y
			element.Z = entity.Info[i].Z
			element.Vx = entity.Info[i].VX
			element.Vy = entity.Info[i].VY
			level := threatlevel.MaxThreatLevel(element)
			entity.Info[i].Level = level
			levels = append(levels, &RadarFuseLevel{
				Sn:    entity.Sn,
				ObjId: entity.Info[i].Obj_id,
				Level: entity.Info[i].Level,
			})
		}
		mu.Lock()
		defer mu.Unlock()
		err = conn.WriteJSON(common.EquipmentMessageBoxEntity{
			Sn:   entity.Sn,
			Info: levels,
		})
		if err != nil {
			return fmt.Errorf("radar track fuse websocket write message error: %v", err)
		}
		return nil
	})
	defer sub.Unsubscribe()

	for {
		_, message, err := conn.ReadMessage()
		if err != nil {
			logger.Error("radar track fuse websocket err: ", err)
			conn.Close()
			break
		}
		logger.Debugf("radar track fuse websocket receive message from[%v]: %v", c.RemoteIP(), message)
	}
}

// ============================== radar posture webSocket=================================

type RadarPostureMessagebox struct {
	Name      string                          `json:"name"`
	Sn        string                          `json:"sn"`
	Info      common.RadarUploadPostureEntity `json:"info"`
	EquipType int                             `json:"equip_type"`
	MsgType   int                             `json:"msg_type"`
}

func (w *WebSocketServer) NewConnectionRadarPosture(c *gin.Context) {
	conn, err := upGrader.Upgrade(c.Writer, c.Request, nil)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"msg": "websocket server error! " + err.Error()})
		return
	}
	w.server.RegisterOnShutdown(func() {
		conn.Close()
	})
	logger.Debug("radar posture websocket connect from: ", c.RemoteIP())

	pool := &sync.Pool{New: func() interface{} {
		return new(RadarPostureMessagebox)
	}}
	// concurrent write
	mu := sync.Mutex{}
	sub, _ := mq.RadarPostureBroker.Subscribe(mq.RadarPostureTopic, func(event broker2.Event) error {
		mu.Lock()
		defer mu.Unlock()
		err = conn.WriteMessage(websocket.TextMessage, event.Message().Body)
		if err != nil {
			logger.Error("radar posture websocket write message error %v", err)
			return errors.New("radar posture websocket write message error")
		}
		entity := pool.Get().(*RadarPostureMessagebox)
		defer pool.Put(entity)
		err := jsoniter.Unmarshal(event.Message().Body, &entity)
		if err != nil {
			logger.Error("posture EquipmentMessageBoxEntity Unmarshal error: %v", err)
			return errors.New("posture EquipmentMessageBoxEntity Unmarshal error")
		}
		if entity.Sn == "" {
			return nil
		}
		// 更新posture cache
		if v, ok := w.postureCache.Load(entity.Sn); ok {
			v.(*Posture).Pitching = entity.Info.Pitching
		} else {
			w.postureCache.Store(entity.Sn, &Posture{Pitching: entity.Info.Pitching})
		}
		return nil
	})
	defer sub.Unsubscribe()

	for {
		_, message, err := conn.ReadMessage()
		if err != nil {
			logger.Error("radar posture websocket err: ", err)
			conn.Close()
			break
		}
		logger.Debugf("radar posture websocket receive message from[%v]: %v", c.RemoteIP(), message)
	}
}

// =================================RadarBeamConfig  webSocket===============================================
func (w *WebSocketServer) NewConnectionRadarBeamConfig(c *gin.Context) {
	conn, err := upGrader.Upgrade(c.Writer, c.Request, nil)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"msg": "websocket server error! " + err.Error()})
		return
	}
	w.server.RegisterOnShutdown(func() {
		conn.Close()
	})
	logger.Debug("radar msg websocket connect from: ", c.RemoteIP())

	mu := sync.Mutex{}
	sub, _ := mq.RadarBeamConfigBroker.Subscribe(mq.RadarBeamConfigTopic, func(event broker2.Event) error {
		mu.Lock()
		defer mu.Unlock()
		err = conn.WriteMessage(websocket.TextMessage, event.Message().Body)
		if err != nil {
			return fmt.Errorf("radar msg websocket write message error: %v", err)
		}
		return nil
	})
	defer sub.Unsubscribe()

	for {
		_, message, err := conn.ReadMessage()
		if err != nil {
			logger.Error("Agx msg websocket err: ", err)
			conn.Close()
			break
		}
		logger.Debugf("Agx msg websocket receive message from[%v]: %v", c.RemoteIP(), message)
	}
}

// =================================DataMark  webSocket===============================================
func (w *WebSocketServer) NewConnectionDataMark(c *gin.Context) {
	conn, err := upGrader.Upgrade(c.Writer, c.Request, nil)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"msg": "websocket server error! " + err.Error()})
		return
	}
	w.server.RegisterOnShutdown(func() {
		conn.Close()
	})
	logger.Debug("data mark msg websocket connect from: ", c.RemoteIP())

	mu := sync.Mutex{}
	sub, _ := mq.DataReplayMark.Subscribe(mq.DataReplayMarkTopic, func(event broker2.Event) error {
		mu.Lock()
		defer mu.Unlock()
		err = conn.WriteMessage(websocket.TextMessage, event.Message().Body)
		if err != nil {
			return fmt.Errorf("data mark msg websocket write message error: %v", err)
		}
		return nil
	})
	defer sub.Unsubscribe()

	for {
		_, message, err := conn.ReadMessage()
		if err != nil {
			logger.Error("data mark msg websocket err: ", err)
			conn.Close()
			break
		}
		logger.Debugf("data mark msg websocket receive message from[%v]: %v", c.RemoteIP(), message)
	}
}

// ============================== Gun Heart webSocket=================================

func (w *WebSocketServer) NewConnectionGunHeart(c *gin.Context) {
	conn, err := upGrader.Upgrade(c.Writer, c.Request, nil)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"msg": "websocket server error! " + err.Error()})
		return
	}
	w.server.RegisterOnShutdown(func() {
		conn.Close()
	})
	logger.Debug("gun heart websocket connect from: ", c.RemoteIP())

	// concurrent write
	mu := sync.Mutex{}
	sub, _ := mq.GunHeartBroker.Subscribe(mq.GunHeartTopic, func(event broker2.Event) error {
		mu.Lock()
		defer mu.Unlock()
		err = conn.WriteMessage(websocket.TextMessage, event.Message().Body)
		if err != nil {
			return fmt.Errorf("gun heart websocket write message error: %v", err)
		}
		return nil
	})
	defer sub.Unsubscribe()

	for {
		_, message, err := conn.ReadMessage()
		if err != nil {
			logger.Error("gun heart websocket err: ", err)
			conn.Close()
			break
		}
		logger.Debugf("gun heart websocket receive message from[%v]: %v", c.RemoteIP(), message)
	}
}

// ============================== drone id heart webSocket=================================

func (w *WebSocketServer) NewConnectionDroneIdHeart(c *gin.Context) {
	conn, err := upGrader.Upgrade(c.Writer, c.Request, nil)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"msg": "websocket server error! " + err.Error()})
		return
	}
	w.server.RegisterOnShutdown(func() {
		conn.Close()
	})
	logger.Debug("drone id heart websocket connect from: ", c.RemoteIP())
	// concurrent write
	mu := sync.Mutex{}
	sub, _ := mq.GunDroneIdBroker.Subscribe(mq.GunDroneIdTopic, func(event broker2.Event) error {
		mu.Lock()
		defer mu.Unlock()
		err = conn.WriteMessage(websocket.TextMessage, event.Message().Body)
		if err != nil {
			return fmt.Errorf("drone id heart websocket write message error: %v", err)
		}
		return nil
	})
	defer sub.Unsubscribe()

	for {
		_, message, err := conn.ReadMessage()
		if err != nil {
			logger.Error("drone id heart websocket err: ", err)
			conn.Close()
			break
		}
		logger.Debugf("drone id heart websocket receive message from[%v]: %v", c.RemoteIP(), message)
	}
}

func (w *WebSocketServer) NewConnectionV2DroneIdHeart(c *gin.Context) {
	conn, err := upGrader.Upgrade(c.Writer, c.Request, nil)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"msg": "websocket server error! " + err.Error()})
		return
	}
	w.server.RegisterOnShutdown(func() {
		conn.Close()
	})
	logger.Debug("v2 drone id heart websocket connect from: ", c.RemoteIP())

	mu := sync.Mutex{}
	sub, _ := mq.V2DroneIdBroker.Subscribe(mq.V2DroneIdTopic, func(event broker2.Event) error {
		mu.Lock()
		defer mu.Unlock()
		err = conn.WriteMessage(websocket.TextMessage, event.Message().Body)
		if err != nil {
			return fmt.Errorf("v2 drone id heart websocket write message error: %v", err)
		}
		return nil
	})
	defer sub.Unsubscribe()

	for {
		_, message, err := conn.ReadMessage()
		if err != nil {
			logger.Error("v2 drone id heart websocket err: ", err)
			conn.Close()
			break
		}
		logger.Debugf("v2 drone id heart websocket receive message from[%v]: %v", c.RemoteIP(), message)
	}
}

// =================================drone id Detect===============================================
func (w *WebSocketServer) NewConnectionV2DroneIdDetect(c *gin.Context) {
	conn, err := upGrader.Upgrade(c.Writer, c.Request, nil)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"msg": "websocket server error! " + err.Error()})
		return
	}
	w.server.RegisterOnShutdown(func() {
		conn.Close()
	})
	logger.Debug("v2 drone id Detect websocket connect from: ", c.RemoteIP())

	mu := sync.Mutex{}
	sub, _ := mq.TracerDetectBroker.Subscribe(mq.TracerDetectTopic, func(event broker2.Event) error {
		mu.Lock()
		defer mu.Unlock()
		err = conn.WriteMessage(websocket.TextMessage, event.Message().Body)
		if err != nil {
			return fmt.Errorf("v2 drone id Detect websocket write message error: %v", err)
		}
		return nil
	})
	defer sub.Unsubscribe()

	for {
		_, message, err := conn.ReadMessage()
		if err != nil {
			logger.Error("v2 drone id Detect websocket err: ", err)
			conn.Close()
			break
		}
		logger.Debugf("v2 drone id Detect websocket receive message from[%v]: %v", c.RemoteIP(), message)
	}
}

// ============================== NSF4000 webSocket=================================

func (w *WebSocketServer) NewConnectionNSF4000(c *gin.Context) {
	conn, err := upGrader.Upgrade(c.Writer, c.Request, nil)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"msg": "websocket server error! " + err.Error()})
		return
	}
	w.server.RegisterOnShutdown(func() {
		conn.Close()
	})
	logger.Debug("rf drone websocket connect from: ", c.RemoteIP())

	// concurrent write
	mu := sync.Mutex{}
	sub, _ := mq.NSF4000Broker.Subscribe(mq.NSF4000Topic, func(event broker2.Event) error {
		mu.Lock()
		defer mu.Unlock()
		err = conn.WriteMessage(websocket.TextMessage, event.Message().Body)
		if err != nil {
			return fmt.Errorf("drone id heart websocket write message error: %v", err)
		}
		return nil
	})
	defer sub.Unsubscribe()

	for {
		_, message, err := conn.ReadMessage()
		if err != nil {
			logger.Error("drone id heart websocket err: ", err)
			conn.Close()
			break
		}
		logger.Debugf("drone id heart websocket receive message from[%v]: %v", c.RemoteIP(), message)
	}
}

// =================================FpvMsg  webSocker===============================================
func (w *WebSocketServer) NewConnectionFpvMsg(c *gin.Context) {
	conn, err := upGrader.Upgrade(c.Writer, c.Request, nil)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"msg": "websocket server error! " + err.Error()})
		return
	}
	w.server.RegisterOnShutdown(func() {
		conn.Close()
	})
	logger.Debug("Fpv msg websocket connect from: ", c.RemoteIP())

	mu := sync.Mutex{}
	sub, _ := mq.FpvMsgBroker.Subscribe(mq.FpvTopic, func(event broker2.Event) error {
		mu.Lock()
		defer mu.Unlock()
		err = conn.WriteMessage(websocket.TextMessage, event.Message().Body)
		if err != nil {
			return fmt.Errorf("Fpv msg websocket write message error: %v", err)
		}
		return nil
	})
	defer sub.Unsubscribe()

	for {
		_, message, err := conn.ReadMessage()
		if err != nil {
			logger.Error("Fpv msg websocket err: ", err)
			conn.Close()
			break
		}
		logger.Debugf("Fpv msg websocket receive message from[%v]: %v", c.RemoteIP(), message)
	}
}

// =================================SFLMsg  webSocker===============================================
func (w *WebSocketServer) NewConnectionSflMsg(c *gin.Context) {
	conn, err := upGrader.Upgrade(c.Writer, c.Request, nil)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"msg": "websocket server error! " + err.Error()})
		return
	}
	w.server.RegisterOnShutdown(func() {
		conn.Close()
	})
	logger.Debug("Sfl msg websocket connect from: ", c.RemoteIP())

	mu := sync.Mutex{}
	sub, _ := mq.SflMsgBroker.Subscribe(mq.SflTopic, func(event broker2.Event) error {
		mu.Lock()
		defer mu.Unlock()
		err = conn.WriteMessage(websocket.TextMessage, event.Message().Body)
		if err != nil {
			return fmt.Errorf("Sfl msg websocket write message error: %v", err)
		}
		return nil
	})
	defer sub.Unsubscribe()

	for {
		_, message, err := conn.ReadMessage()
		if err != nil {
			logger.Error("Sfl msg websocket err: ", err)
			conn.Close()
			break
		}
		logger.Debugf("Sfl msg websocket receive message from[%v]: %v", c.RemoteIP(), message)
	}
}

// =================================AgxMsg  webSocket===============================================
func (w *WebSocketServer) NewConnectionAgxMsg(c *gin.Context) {
	conn, err := upGrader.Upgrade(c.Writer, c.Request, nil)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"msg": "websocket server error! " + err.Error()})
		return
	}
	w.server.RegisterOnShutdown(func() {
		conn.Close()
	})
	logger.Debug("Agx msg websocket connect from: ", c.RemoteIP())

	mu := sync.Mutex{}
	sub, _ := mq.AgxMsgBroker.Subscribe(mq.AgxTopic, func(event broker2.Event) error {
		mu.Lock()
		defer mu.Unlock()
		err = conn.WriteMessage(websocket.TextMessage, event.Message().Body)
		if err != nil {
			return fmt.Errorf("Agx msg websocket write message error: %v", err)
		}
		return nil
	})
	defer sub.Unsubscribe()

	for {
		_, message, err := conn.ReadMessage()
		if err != nil {
			logger.Error("Agx msg websocket err: ", err)
			conn.Close()
			break
		}
		logger.Debugf("Agx msg websocket receive message from[%v]: %v", c.RemoteIP(), message)
	}
}

// =================================Sfl200Msg  webSocket===============================================
func (w *WebSocketServer) NewConnectionSfl200Msg(c *gin.Context) {
	conn, err := upGrader.Upgrade(c.Writer, c.Request, nil)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"msg": "websocket server error! " + err.Error()})
		return
	}
	w.server.RegisterOnShutdown(func() {
		conn.Close()
	})
	logger.Debug("Agx msg websocket connect from: ", c.RemoteIP())

	mu := sync.Mutex{}
	sub, _ := mq.AgxMsgBroker.Subscribe(mq.Sfl200Topic, func(event broker2.Event) error {
		mu.Lock()
		defer mu.Unlock()
		err = conn.WriteMessage(websocket.TextMessage, event.Message().Body)
		if err != nil {
			return fmt.Errorf("Sfl200 msg websocket write message error: %v", err)
		}
		return nil
	})
	defer sub.Unsubscribe()

	for {
		_, message, err := conn.ReadMessage()
		if err != nil {
			logger.Error("Sfl200 msg websocket err: ", err)
			conn.Close()
			break
		}
		logger.Debugf("Sfl200 msg websocket receive message from[%v]: %v", c.RemoteIP(), message)
	}
}

// NewReplayTransMsg() replay trans message.
func (w *WebSocketServer) NewReplayTransMsg(c *gin.Context) {
	conn, err := upGrader.Upgrade(c.Writer, c.Request, nil)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"msg": "websocket server error! " + err.Error()})
		return
	}
	w.server.RegisterOnShutdown(func() {
		conn.Close()
	})
	logger.Debug("replay trans websocket connect from: ", c.RemoteIP())

	mu := sync.Mutex{} //1. 先发布;
	sub, _ := mq.DataReplayMix.Subscribe(mq.ReplayTransMsgTopic, func(event broker2.Event) error {
		mu.Lock()
		defer mu.Unlock()
		err = conn.WriteMessage(websocket.TextMessage, event.Message().Body)
		if err != nil {
			return fmt.Errorf("replay msg websocket write message error: %v", err)
		}
		return nil
	})
	defer sub.Unsubscribe()

	for {
		_, message, err := conn.ReadMessage()
		if err != nil {
			logger.Error("replay msg websocket err: ", err)
			conn.Close()
			break
		}
		logger.Debugf("replay msg websocket receive message from[%v]: %v", c.RemoteIP(), message)
	}
}

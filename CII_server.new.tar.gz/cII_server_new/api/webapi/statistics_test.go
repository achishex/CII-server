package webapi

import (
	"context"
	"net/http"
	"net/http/httptest"
	"reflect"
	"strings"
	"testing"

	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/test"
	"github.com/agiledragon/gomonkey"
	"github.com/emicklei/go-restful"
	"github.com/stretchr/testify/assert"
)

func Test_statisticApi_EventList(t *testing.T) {
	// Mock 日志
	test.LoggerMock()

	data := `{"begin_time":"2023-09-03 15:18:30", "end_time":"2023-09-04 15:18:30"}`
	req := httptest.NewRequest(http.MethodPost, "/statistic/list", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	a := &handler.Statist{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(a), "EventList", func(_ *handler.Statist, _ context.Context, req *client.EventReq, res *client.EventRsp) error {
		return nil
	})
	defer patches.Reset()

	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		s    *statisticApi
		args args
	}{
		{
			name: "Case1",
			s:    &statisticApi{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			s := &statisticApi{}
			s.EventList(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}

func Test_statisticApi_QueryDataBySql(t *testing.T) {
	// Mock 日志
	test.LoggerMock()

	data := `{"sql":"xxxxxx", "start":1, "limit":10}`
	req := httptest.NewRequest(http.MethodPost, "/statistic/query-db-data", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	a := &handler.Statist{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(a), "QueryBySql", func(_ *handler.Statist, _ context.Context, req *client.QueryBySqlRequest, res *client.QueryBySqlResponse) error {
		return nil
	})
	defer patches.Reset()

	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		s    *statisticApi
		args args
	}{
		{
			name: "Case1",
			s:    &statisticApi{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			s := &statisticApi{}
			s.QueryDataBySql(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}

func Test_statisticApi_Schedule(t *testing.T) {
	// Mock 日志
	test.LoggerMock()

	data := `{"period":1}`
	req := httptest.NewRequest(http.MethodPost, "/statistic/schedule", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	a := &handler.Statist{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(a), "EventCollect", func(_ *handler.Statist, _ context.Context, req *client.CollectReq, res *client.CollectRes) error {
		return nil
	})
	defer patches.Reset()

	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		s    *statisticApi
		args args
	}{
		{
			name: "Case1",
			s:    &statisticApi{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			s := &statisticApi{}
			s.Schedule(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}

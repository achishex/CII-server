package webapi

import (
	"context"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"github.com/emicklei/go-restful"

	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
)

// GetSbp100DevInfo 获取sbp100设备信息
func (e *deviceManager) GetSbp100DevInfo(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GetSbp100DevInfoRequest{}
	deviceRsp := &client.GetSbp100DevInfoResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().GetSbp100DevInfo(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		logger.Errorf("GetSbp100DevInfo error: %v", err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// Sbp100TurnOnOff sbp100开启、关闭开关
func (e *deviceManager) Sbp100TurnOnOff(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sbp100TurnOnOffRequest{}
	deviceRsp := &client.Sbp100TurnOnOffResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().Sbp100TurnOnOff(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		logger.Errorf("Sbp100TurnOnOff error: %v", err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// Sbp100FireZero sbp100打击点修正
func (e *deviceManager) Sbp100FireZero(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sbp100FireZeroRequest{}
	deviceRsp := &client.Sbp100FireZeroResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().Sbp100FireZero(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		logger.Errorf("Sbp100FireZero error: %v", err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// Sbp100FireRange sbp100开启、关闭测距
func (e *deviceManager) Sbp100FireRange(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sbp100FireRangeRequest{}
	deviceRsp := &client.Sbp100FireRangeResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().Sbp100FireRange(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		logger.Errorf("Sbp100FireRange error: %v", err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// Sbp100OnOffLight sbp100开启、关闭照明
func (e *deviceManager) Sbp100OnOffLight(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sbp100OnOffLightRequest{}
	deviceRsp := &client.Sbp100OnOffLightResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().Sbp100OnOffLight(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		logger.Errorf("Sbp100OnOffLight error: %v", err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// Sbp100FireMainLaser sbp100开启、停止打击
func (e *deviceManager) Sbp100FireMainLaser(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sbp100FireMainLaserRequest{}
	deviceRsp := &client.Sbp100FireMainLaserResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().Sbp100FireMainLaser(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		logger.Errorf("Sbp100FireMainLaser error: %v", err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// SelectUavToLaserDevice 下发指定目标给激光设备
func (e *deviceManager) SelectUavToLaserDevice(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SelectUavToLaserDeviceReq{}
	deviceRsp := &client.SelectUavToLaserDeviceRsp{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().SelectUavToLaserDevice(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		logger.Errorf("SelectUavToLaserDevice error: %v", err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

func init() {
	RegistHandler("/device/sbp100/device-info", DeviceManagerApi.GetSbp100DevInfo)
	RegistHandler("/device/sbp100/turn-onoff", DeviceManagerApi.Sbp100TurnOnOff)
	RegistHandler("/device/sbp100/fire-zero", DeviceManagerApi.Sbp100FireZero)
	RegistHandler("/device/sbp100/fire-range", DeviceManagerApi.Sbp100FireRange)
	RegistHandler("/device/sbp100/on-off-light", DeviceManagerApi.Sbp100OnOffLight)
	RegistHandler("/device/sbp100/fire-main-laser", DeviceManagerApi.Sbp100FireMainLaser)
	RegistHandler("/device/agx/select-uav-to-laser-device", DeviceManagerApi.SelectUavToLaserDevice)
}

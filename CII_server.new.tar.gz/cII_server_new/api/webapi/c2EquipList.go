package webapi

import (
	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"context"
	"fmt"
	"strings"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"github.com/emicklei/go-restful"
)

type equipApi struct {
}

var (
	EquipApi = new(equipApi)
)

// Responses:
//
//	200: Response
//
//swagger:route POST /equip/create equip commonEq
func (e *equipApi) Insert(req *restful.Request, res *restful.Response) {
	equipReq := &client.EquipCrudReq{}
	equipRsp := &client.EquipCrudRes{}
	err := req.ReadEntity(equipReq)
	if err != nil {
		logger.Errorf("plot head create params:%v, error:%v", equipReq, err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	err = handler.NewEquipList().Insert(context.Background(), equipReq, equipRsp)
	Result(err, res)
}

// Responses:
//
//	200: Response
//
//swagger:route POST /equip/update equip commonEq
func (e *equipApi) Update(req *restful.Request, res *restful.Response) {
	equipReq := &client.EquipCrudReq{}
	equipRsp := &client.EquipCrudRes{}
	err := req.ReadEntity(equipReq)
	if err != nil {
		logger.Errorf("plot head update params:%v, error:%v", equipReq, err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	err = handler.NewEquipList().Update(context.Background(), equipReq, equipRsp)
	Result(err, res)
}

// Responses:
//
//	200: Response
//
//swagger:route POST /equip/delete equip deleteReq
func (e *equipApi) Delete(req *restful.Request, res *restful.Response) {
	equipReq := &client.EquipDeleteReq{}
	equipRsp := &client.EquipCrudRes{}
	err := req.ReadEntity(equipReq)
	if err != nil {
		logger.Errorf("equip list delete params:%v, error:%v", equipReq, err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	//
	idsResp := []*bean.EquipList{}
	handler.NewEquipList().FindByIds(context.Background(), equipReq, &idsResp)
	err = handler.NewEquipList().Delete(context.Background(), equipReq, equipRsp)
	//
	func(queryItem []*bean.EquipList) {
		if len(queryItem) <= 0 {
			return
		}
		for _, item := range queryItem {
			if item == nil {
				continue
			}
			if strings.Compare(item.Etype, "Fpv") == 0 {
				cachekeyFpv := fmt.Sprintf("%d_%s", common.DEV_FPV, item.Sn)
				handler.DevStatusMap.Delete(cachekeyFpv)
			}
			if strings.Compare(item.Etype, "DroneID") == 0 {
				cachekeyDroneID := fmt.Sprintf("%d_%s", common.DEV_V2DRONEID, item.Sn)
				handler.DevStatusMap.Delete(cachekeyDroneID)
			}
			if strings.Compare(item.Etype, "Sfl") == 0 {
				cachekeySfl := fmt.Sprintf("%d_%s", common.DEV_SFL, item.Sn)
				handler.DevStatusMap.Delete(cachekeySfl)
			}
			if strings.Compare(item.Etype, "radar") == 0 {
				cachekeyRadar := fmt.Sprintf("%d_%s", common.DEV_RADAR, item.Sn)
				handler.DevStatusMap.Delete(cachekeyRadar)
			}
			if strings.Compare(item.Etype, "Spoofer") != 0 {
				continue
			}

			err = handler.NewDeviceCenter().DeleteInduceConfig(context.Background(), item.Sn)
			if err != nil {
				logger.Errorf("delete induce config from db fail, e: %v", err)
			}
		}
	}(idsResp)

	//插入或者更新到删除备份表中
	handler.NewEquipList().InsertOrUpdateBackupTab(context.Background(), idsResp)
	Result(err, res)
}

func init() {
	RegistHandler("/equip/create", EquipApi.Insert)
	RegistHandler("/equip/update", EquipApi.Update)
	RegistHandler("/equip/delete", EquipApi.Delete)
}

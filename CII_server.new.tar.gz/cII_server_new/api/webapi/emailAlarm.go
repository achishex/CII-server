package webapi

import (
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"context"
	"github.com/emicklei/go-restful"
)

// EmailAlarmSelectDevice 邮件告警选择设备
func (e *deviceManager) EmailAlarmSelectDevice(req *restful.Request, res *restful.Response) {
	deviceReq := &client.EmailAlarmSettingRequest{}
	deviceRsp := &client.EmailAlarmSettingResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().EmailAlarmSelectDevice(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}

	Success(deviceRsp, res)
}

// GetEmailAlarmConfig 获取邮件告警配置
func (e *deviceManager) GetEmailAlarmConfig(req *restful.Request, res *restful.Response) {
	deviceReq := &client.EmailAlarmSettingGetRequest{}
	deviceRsp := &client.EmailAlarmSettingGetResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().GetEmailAlarmConfig(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}

	Success(deviceRsp, res)
}

// UpdateEmailAlarm 更新邮件告警
func (e *deviceManager) UpdateEmailAlarm(req *restful.Request, res *restful.Response) {
	deviceReq := &client.EmailAlarmUpdateEmailRequest{}
	deviceRsp := &client.EmailAlarmUpdateEmailResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().UpdateEmailAlarm(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}

	Success(deviceRsp, res)
}

func init() {
	RegistHandler("/device/email-alarm/select-device", DeviceManagerApi.EmailAlarmSelectDevice)
	RegistHandler("/device/email-alarm/get-config", DeviceManagerApi.GetEmailAlarmConfig)
	RegistHandler("/device/email-alarm/update-email", DeviceManagerApi.UpdateEmailAlarm)
}

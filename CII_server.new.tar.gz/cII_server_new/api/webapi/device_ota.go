package webapi

import (
	"context"

	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"github.com/emicklei/go-restful"
)

// DownloadOtaPkg 下载ota固件升级包
func (e *deviceManager) DownloadOtaPkg(req *restful.Request, res *restful.Response) {
	deviceReq := &client.DownloadOtaPkgRequest{}
	deviceRsp := &client.DownloadOtaPkgResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().DownloadOtaPkg(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// PauseDownloadOtaPkg 暂停下载ota固件升级包
func (e *deviceManager) PauseDownloadOtaPkg(req *restful.Request, res *restful.Response) {
	deviceReq := &client.PauseDownloadOtaRequest{}
	deviceRsp := &client.PauseDownloadOtaResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().PauseDownloadOtaPkg(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// ContinueDownloadOtaPkg 继续下载ota固件升级包
func (e *deviceManager) ContinueDownloadOtaPkg(req *restful.Request, res *restful.Response) {
	deviceReq := &client.ContinueDownloadOtaRequest{}
	deviceRsp := &client.ContinueDownloadOtaResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().ContinueDownloadOtaPkg(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// GetLocalOtaPkgList 获取本地ota固件升级包列表
func (e *deviceManager) GetLocalOtaPkgList(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GetOtaPkgListRequest{}
	deviceRsp := &client.GetOtaPkgListResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().GetLocalOtaPkgList(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// GetCloudOtaPkgList 获取云ota固件升级包列表
func (e *deviceManager) GetCloudOtaPkgList(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GetOtaPkgListRequest{}
	deviceRsp := &client.GetOtaPkgListResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().GetCloudOtaPkgList(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// OtaRequestUpgrade ota固件升级
func (e *deviceManager) OtaRequestUpgrade(req *restful.Request, res *restful.Response) {
	deviceReq := &client.RequestUpgradeRequest{}
	deviceRsp := &client.RequestUpgradeResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().OtaRequestUpgrade(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// GetUpgradeStatus 获取固件升级状态  未使用
func (e *deviceManager) GetUpgradeStatus(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GetUpgradeStatusRequest{}
	deviceRsp := &client.GetUpgradeStatusResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().GetUpgradeStatus(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// CheckPkgIsLatest 获取固件升级状态
func (e *deviceManager) CheckPkgIsLatest(req *restful.Request, res *restful.Response) {
	deviceReq := &client.CheckPkgIsLatestRequest{}
	deviceRsp := &client.CheckPkgIsLatestResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().CheckPkgIsLatest(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// CheckLatestPkgExist 检查本地是否有最新版本升级包
func (e *deviceManager) CheckLatestPkgExist(req *restful.Request, res *restful.Response) {
	deviceReq := &client.CheckLatestPkgExistRequest{}
	deviceRsp := &client.CheckLatestPkgExistResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().CheckLatestPkgExist(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// GetLatestVersion 根据设备类型获取最新的ota升级包版本
func (e *deviceManager) GetLatestVersion(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GetLatestVersionRequest{}
	deviceRsp := &client.GetLatestVersionResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().GetLatestVersion(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// GetLatestFileName 根据设备类型获取最新的ota升级包版本
func (e *deviceManager) GetLatestFileName(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GetLatestFileNameRequest{}
	deviceRsp := &client.GetLatestFileNameResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().GetLatestFileName(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// PullOtaLatestVersionPkg 获取升级包最新版本
func (e *deviceManager) PullOtaLatestVersionPkg(req *restful.Request, res *restful.Response) {
	processDeviceManager[client.OtaDevicePkgPullRequest, client.OtaDevicePkgPullResponse](req, res, handler.NewDeviceCenter().GetOtaLatestVersionPkg)
}

func init() {
	// 下载固件升级包
	RegistHandler("/device/ota/downloadOtaPkg", DeviceManagerApi.DownloadOtaPkg)
	// 暂停下载ota固件升级包
	RegistHandler("/device/ota/pauseDownloadOtaPkg", DeviceManagerApi.PauseDownloadOtaPkg)
	// 继续下载ota固件升级包
	RegistHandler("/device/ota/continueDownloadOtaPkg", DeviceManagerApi.ContinueDownloadOtaPkg)

	// ota固件升级
	RegistHandler("/device/ota/request-upgrade", DeviceManagerApi.OtaRequestUpgrade)

	// 获取本地ota固件升级包列表
	RegistHandler("/device/ota/getLocalOtaPkgList", DeviceManagerApi.GetLocalOtaPkgList)
	// 获取云端ota固件升级包列表
	RegistHandler("/device/ota/getCloudOtaPkgList", DeviceManagerApi.GetCloudOtaPkgList)

	// 获取固件升级状态
	RegistHandler("/device/ota/getUpgradeStatus", DeviceManagerApi.GetUpgradeStatus) //前端未使用

	// 检查升级包版本是否为最新
	RegistHandler("/device/ota/checkPkgIsLatest", DeviceManagerApi.CheckPkgIsLatest)
	// 检查本地是否有最新版本升级包
	RegistHandler("/device/ota/checkLatestPkgExist", DeviceManagerApi.CheckLatestPkgExist)
	// 根据设备类型获取最新的ota升级包版本
	RegistHandler("/device/ota/getLatestVersion", DeviceManagerApi.GetLatestVersion)
	// 根据设备类型获取最新的ota升级包文件名
	RegistHandler("/device/ota/getLatestFileName", DeviceManagerApi.GetLatestFileName)
	// 升级管理中：升级管理界面入口
	RegistHandler("/device/ota/latestPkgPull", DeviceManagerApi.PullOtaLatestVersionPkg)
}

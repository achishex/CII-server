// c2绑定云平台站点
package webapi

import (
	"context"
	"strconv"
	"strings"

	"github.com/emicklei/go-restful"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"

	"adasgitlab.autel.com/tools/cuav_server/logic/uploadcloud"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
)

var C2BindSite = new(c2BindSite)

type c2BindSite struct{}

var (
	serverInternalError = 500
)

// 身份验证
func (c *c2BindSite) Authentication(req *restful.Request, res *restful.Response) {
	authReq := &client.C2LoginRequest{}
	authRsp := &client.C2LoginResponse{}
	err := req.ReadEntity(authReq)
	if err != nil {
		logger.Errorf("Authentication params[%+v], err:%v", authReq, err)
		ParameterBindFail(400, err.Error(), res)
		return
	}
	if err = uploadcloud.CloudCli.C2LoginCloud(context.Background(), authReq, authRsp); err != nil {
		logger.Errorf("Authentication C2LoginCloud err: %v", err)
		errCode, errMessage := generateError(err)
		ParameterBindFail(int32(errCode), errMessage, res)
		return
	}
	Success(authRsp, res)
}

func (c *c2BindSite) GetBindSiteList(req *restful.Request, res *restful.Response) {
	getBindSiteListReq := &client.C2BindSiteListRequest{}
	getBindSiteListRsp := &client.C2BindSiteListResponse{}
	err := req.ReadEntity(getBindSiteListReq)
	if err != nil {
		logger.Errorf("GetBindSiteList params[%+v], err:%v", getBindSiteListReq, err)
		ParameterBindFail(400, err.Error(), res)
		return
	}
	if err = uploadcloud.CloudCli.GetBindSiteList(context.Background(), getBindSiteListReq, getBindSiteListRsp); err != nil {
		logger.Errorf("GetBindSiteList err:%v", err)
		errCode, errMessage := generateError(err)
		ParameterBindFail(int32(errCode), errMessage, res)
		return
	}
	Success(getBindSiteListRsp, res)
}

func (c *c2BindSite) C2SiteBind(req *restful.Request, res *restful.Response) {
	c2SiteBindReq := &client.C2BindCloudSiteRequest{}
	c2SiteBindRsp := &client.C2BindCloudSiteResponse{}
	err := req.ReadEntity(c2SiteBindReq)
	if err != nil {
		logger.Errorf("C2SiteBind params[%+v], err:%v", c2SiteBindReq, err)
		ParameterBindFail(400, err.Error(), res)
		return
	}
	if err := uploadcloud.CloudCli.C2SiteBind(context.Background(), c2SiteBindReq, c2SiteBindRsp); err != nil {
		logger.Errorf("C2SiteBind err:%v", err)
		errCode, errMessage := generateError(err)
		ParameterBindFail(int32(errCode), errMessage, res)
		return
	}
	Success(c2SiteBindRsp, res)
}

func (c *c2BindSite) C2SiteUnBind(req *restful.Request, res *restful.Response) {
	c2SiteUnBindReq := &client.C2UnBindCloudSiteRequest{}
	c2SiteUnBindRsp := &client.C2UnBindCloudSiteResponse{}
	err := req.ReadEntity(c2SiteUnBindReq)
	if err != nil {
		logger.Errorf("C2SiteUnBind params[%+v], err:%v", c2SiteUnBindReq, err)
		ParameterBindFail(400, err.Error(), res)
		return
	}
	if err := uploadcloud.CloudCli.C2SiteUnBind(context.Background(), c2SiteUnBindReq, c2SiteUnBindRsp); err != nil {
		logger.Errorf("C2SiteUnBind err:%v", err)
		errCode, errMessage := generateError(err)
		ParameterBindFail(int32(errCode), errMessage, res)
		return
	}
	Success(c2SiteUnBindRsp, res)
}

func (c *c2BindSite) QueryBindStatus(req *restful.Request, res *restful.Response) {
	queryBindStatusReq := &client.QueryBindStatusRequest{}
	queryBindStatusRsp := &client.QueryBindStatusResponse{}
	err := req.ReadEntity(queryBindStatusReq)
	if err != nil {
		logger.Errorf("QueryBindStatus params[%+v], err:%v", queryBindStatusReq, err)
		ParameterBindFail(400, err.Error(), res)
		return
	}
	if err := uploadcloud.CloudCli.QueryBindStatus(context.Background(), queryBindStatusReq, queryBindStatusRsp); err != nil {
		logger.Errorf("QueryBindStatus err:%v", err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(queryBindStatusRsp, res)
}

func generateError(err error) (int, string) {
	if !strings.Contains(err.Error(), "#") {
		return serverInternalError, err.Error()
	}
	arr := strings.Split(err.Error(), "#")
	if len(arr) != 2 {
		return serverInternalError, err.Error()
	}
	errMessage := arr[1]
	errCode, err := strconv.Atoi(arr[0])
	if err != nil {
		return serverInternalError, err.Error()
	}
	return errCode, errMessage
}

func init() {
	RegistHandler("/rest/v1/access/device/login", C2BindSite.Authentication)
	RegistHandler("/rest/v1/access/site/bindable/list", C2BindSite.GetBindSiteList)
	RegistHandler("/rest/v1/access/site/bind", C2BindSite.C2SiteBind)
	RegistHandler("/rest/v1/access/site/unbind", C2BindSite.C2SiteUnBind)
	RegistHandler("/rest/v1/access/site/bind/status", C2BindSite.QueryBindStatus)
}

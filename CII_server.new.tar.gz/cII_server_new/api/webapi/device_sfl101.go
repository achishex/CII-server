package webapi

import (
	"context"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"github.com/emicklei/go-restful"

	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
)

// Sfl101GetVersionInfo 获取版本号
func (e *deviceManager) Sfl101GetVersionInfo(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl101GetVersionRequest{}
	deviceRsp := &client.Sfl101GetVersionResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().Sfl101GetVersionInfo(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}

	Success(deviceRsp, res)
}

// Sfl101StopHit 发送停止打击
func (e *deviceManager) Sfl101StopHit(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl101StopHitRequest{}
	deviceRsp := &client.Sfl101StopHitResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().Sfl101StopHitSet(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// Sfl101SetGNSS ...
func (e *deviceManager) Sfl101SetGNSS(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl101SetGNSSRequest{}
	deviceRsp := &client.Sfl101SetGNSSResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	logger.Debug("Sfl101SetGNSS ------- req ", deviceReq)
	err := handler.NewDeviceCenter().Sfl101GNSSSet(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	logger.Debug("Sfl101SetGNSS ------- deviceRsp", deviceRsp)
	Success(deviceRsp, res)
}

// Sfl101GetGNSS ...
func (e *deviceManager) Sfl101GetGNSS(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl101GetGNSSRequest{}
	deviceRsp := &client.Sfl101GetGNSSResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	logger.Debug("Sfl101GetGNSS ------- deviceReq ", deviceReq)
	err := handler.NewDeviceCenter().Sfl101GNSSGet(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	logger.Debug("Sfl101GetGNSS deviceRsp ----  ", deviceRsp)
	Success(deviceRsp, res)
}

// Sfl101HitAngle 发送打击点信息配置
func (e *deviceManager) Sfl101HitAngle(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl101HitAngleRequest{}
	deviceRsp := &client.Sfl101HitAngleResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().Sfl101HitAngleSet(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// Sfl101OnOff 发送开关机指令
func (e *deviceManager) Sfl101OnOff(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl101OnOffRequest{}
	deviceRsp := &client.Sfl101OnOffResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().Sfl101OnOffSet(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// Sfl101Resetting 发送一键复位指令
func (e *deviceManager) Sfl101Resetting(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl101ResetRequest{}
	deviceRsp := &client.Sfl101ResetResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().Sfl101ReSet(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// Sfl101GetStatus 发送获取角度、工作模式、打击时长、打击范围
func (e *deviceManager) Sfl101GetStatus(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl101GetStatusRequest{}
	deviceRsp := &client.Sfl101GetStatusResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().Sfl101GetStatus(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// Sfl101GetPower 发送获取开关机指令
func (e *deviceManager) Sfl101GetPower(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl101GetPowerRequest{}
	deviceRsp := &client.Sfl101GetPowerResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().Sfl101GetPower(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// Sfl101DetectInfo 发送获取侦测信息
func (e *deviceManager) Sfl101DetectInfo(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl101DetectInfoRequest{}
	deviceRsp := &client.Sfl101DetectInfoResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().Sfl101DetectInfo(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// Sfl101DetectInfoExport 发送侦测信息导出
func (e *deviceManager) Sfl101DetectInfoExport(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl101DetectInfoExportRequest{}
	deviceRsp := &client.Sfl101DetectInfoExportResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().Sfl101DetectInfoExport(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// Sfl101HitUav 发送选中无人机打击
func (e *deviceManager) Sfl101HitUav(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl101SendHitUavRequest{}
	deviceRsp := &client.Sfl101SendHitUavResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().Sfl101SendHitUav(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// Sfl101SetHitMode 发送设置工作模式：手动、自动
func (e *deviceManager) Sfl101SetHitMode(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl101SetHitModeRequest{}
	deviceRsp := &client.Sfl101SetHitModeResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().Sfl101SetHitMode(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// Sfl101GetHitMode 发送获取工作模式：手动、自动
func (e *deviceManager) Sfl101GetHitMode(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl101GetHitModeRequest{}
	deviceRsp := &client.Sfl101GetHitModeResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().Sfl101GetHitMode(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// 启动/停止打击
func (e *deviceManager) Sfl101TurnHit(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl101TurnHitRequest{}
	deviceRsp := &client.Sfl101TurnHitResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().Sfl101TurnHit(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// 水平方向转动
func (e *deviceManager) Sfl101HorizontalTurn(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl101HorizontalTurnRequest{}
	deviceRsp := &client.Sfl101HorizontalTurnResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().Sfl101HorizontalTurn(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// 垂直方向转动
func (e *deviceManager) Sfl101VerticalTurn(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl101VerticalTurnRequest{}
	deviceRsp := &client.Sfl101VerticalTurnResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().Sfl101VerticalTurn(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// Sfl101HitMode 发送打击模式配置
func (e *deviceManager) Sfl101HitMode(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl101HitModeRequest{}
	deviceRsp := &client.Sfl101HitModeResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().Sfl101HitModeSet(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// Sfl101CrashStop 哨兵塔急停
func (e *deviceManager) Sfl101CrashStop(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl101CrashStopRequest{}
	deviceRsp := &client.Sfl101CrashStopResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().Sfl101CrashStop(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// Sfl101SetNoise 设置底噪采集
func (e *deviceManager) Sfl101SetNoise(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl101SetNoiseRequest{}
	deviceRsp := &client.Sfl101SetNoiseResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().Sfl101SetNoise(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// Sfl101GetFreqNodeList 获取频点列表
func (e *deviceManager) Sfl101GetFreqNodeList(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl101GetFreqListRequest{}
	deviceRsp := &client.Sfl101GetFreqListResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().Sfl101GetFreqNodeList(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// Sfl101SetFreqCmd 下发时频图采集指令
func (e *deviceManager) Sfl101SetFreqCmd(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl101SetFreqCmdRequest{}
	deviceRsp := &client.Sfl101SetFreqCmdResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().Sfl101SetFreqCmd(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// Sfl101SetPreciseHit 设置精准打击特性
func (e *deviceManager) Sfl101SetPreciseHit(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl101SetPreciseHitRequest{}
	deviceRsp := &client.Sfl101SetPreciseHitResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().Sfl101SetPreciseHit(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// Sfl101GetPreciseHit 获取精准打击特性
func (e *deviceManager) Sfl101GetPreciseHit(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl101GetPreciseHitRequest{}
	deviceRsp := &client.Sfl101GetPreciseHitResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().Sfl101GetPreciseHit(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// Sfl101SetInvalidFreq 设置无效无人机频点
func (e *deviceManager) Sfl101SetInvalidFreq(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl101SetInvalidFreqRequest{}
	deviceRsp := &client.Sfl101SetInvalidFreqResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().Sfl101SetInvalidFreq(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// Sfl101GetInvalidFreq 获取无效无人机频点
func (e *deviceManager) Sfl101GetInvalidFreq(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl101GetInvalidFreqRequest{}
	deviceRsp := &client.Sfl101GetInvalidFreqResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().Sfl101GetInvalidFreq(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// Sfl101SetHitRadius 设置自动打击的半径
func (e *deviceManager) Sfl101SetHitRadius(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl101SetAutoHitRadiusRequest{}
	deviceRsp := &client.Sfl101SetAutoHitRadiusResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().Sfl101SetHitRadius(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// Sfl101GetHitRadius 获取自动打击的半径
func (e *deviceManager) Sfl101GetHitRadius(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl101GetAutoHitRadiusRequest{}
	deviceRsp := &client.Sfl101GetAutoHitRadiusResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().Sfl101GetHitRadius(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// Sfl101SetSwitchParameter 设置开关参数
func (e *deviceManager) Sfl101SetSwitchParameter(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl101SetSwitchParameterRequest{}
	deviceRsp := &client.Sfl101SetSwitchParameterResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().Sfl101SetSwitchParameter(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// Sfl101GetSwitchParameter 获取开关参数
func (e *deviceManager) Sfl101GetSwitchParameter(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl101GetSwitchParameterRequest{}
	deviceRsp := &client.Sfl101GetSwitchParameterResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().Sfl101GetSwitchParameter(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// Sfl101SetPosture 设置标定设备姿态
func (e *deviceManager) Sfl101SetPosture(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl101SetPostureRequest{}
	deviceRsp := &client.Sfl101SetPostureResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().Sfl101SetPosture(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// Sfl101GetPosture 获取标定设备姿态
func (e *deviceManager) Sfl101GetPosture(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl101GetPostureRequest{}
	deviceRsp := &client.Sfl101GetPostureResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().Sfl101GetPosture(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

func init() {
	RegistHandler("/device/sfl101/get-version-info", DeviceManagerApi.Sfl101GetVersionInfo)
	//停止当前打击
	RegistHandler("/device/sfl101/stop-hit", DeviceManagerApi.Sfl101StopHit)
	//设置打击参数信息
	RegistHandler("/device/sfl101/hit-angle", DeviceManagerApi.Sfl101HitAngle)
	//开机、关机
	RegistHandler("/device/sfl101/on-off", DeviceManagerApi.Sfl101OnOff)
	//一键云台复位
	RegistHandler("/device/sfl101/resetting", DeviceManagerApi.Sfl101Resetting)
	//侦测看板
	RegistHandler("/device/sfl101/detect-info", DeviceManagerApi.Sfl101DetectInfo)
	//导出侦测看板
	RegistHandler("/device/sfl101/detect-info-export", DeviceManagerApi.Sfl101DetectInfoExport)
	//选中无人机手动打击
	RegistHandler("/device/sfl101/hit-uav", DeviceManagerApi.Sfl101HitUav)
	//获取设备状态
	RegistHandler("/device/sfl101/get-status", DeviceManagerApi.Sfl101GetStatus)
	//获取开关机状态
	RegistHandler("/device/sfl101/get-onoff", DeviceManagerApi.Sfl101GetPower)

	//设置是否自动打击
	RegistHandler("/device/sfl101/set-hit-mode", DeviceManagerApi.Sfl101SetHitMode)
	//获取是否自动打击
	RegistHandler("/device/sfl101/get-hit-mode", DeviceManagerApi.Sfl101GetHitMode)

	//获取设备GNSS位置
	RegistHandler("/device/sfl101/setGNSS", DeviceManagerApi.Sfl101SetGNSS)
	//设置设备GNSS位置
	RegistHandler("/device/sfl101/getGNSS", DeviceManagerApi.Sfl101GetGNSS)

	//启动/停止打击
	RegistHandler("/device/sfl101/turn-hit", DeviceManagerApi.Sfl101TurnHit)
	//水平方向转动
	RegistHandler("/device/sfl101/horizontal-turn", DeviceManagerApi.Sfl101HorizontalTurn)
	//垂直方向转动
	RegistHandler("/device/sfl101/vertical-turn", DeviceManagerApi.Sfl101VerticalTurn)
	//设置打击模式
	RegistHandler("/device/sfl101/hit-mode-set", DeviceManagerApi.Sfl101HitMode)
	//哨兵塔急停
	RegistHandler("/device/sfl101/crash-stop", DeviceManagerApi.Sfl101CrashStop)

	//设置底噪采集
	RegistHandler("/device/sfl101/set-noise", DeviceManagerApi.Sfl101SetNoise)
	//获取频点列表
	RegistHandler("/device/sfl101/detect-freq-node-list", DeviceManagerApi.Sfl101GetFreqNodeList)

	//时频图采集指令 D1
	RegistHandler("/device/sfl101/set-freq-cmd", DeviceManagerApi.Sfl101SetFreqCmd)

	//设置精准打击特性
	RegistHandler("/device/sfl101/set-precise", DeviceManagerApi.Sfl101SetPreciseHit)
	//获取精准打击特性
	RegistHandler("/device/sfl101/get-precise", DeviceManagerApi.Sfl101GetPreciseHit)

	//设置无效无人机频点
	RegistHandler("/device/sfl101/set-invalid-freq", DeviceManagerApi.Sfl101SetInvalidFreq)
	//获取无效无人机频点
	RegistHandler("/device/sfl101/get-invalid-freq", DeviceManagerApi.Sfl101GetInvalidFreq)

	//设置自动打击的半径
	RegistHandler("/device/sfl101/set-hit-radius", DeviceManagerApi.Sfl101SetHitRadius)
	//获取自动打击的半径
	RegistHandler("/device/sfl101/get-hit-radius", DeviceManagerApi.Sfl101GetHitRadius)

	//设置开关参数
	RegistHandler("/device/sfl101/set-switch-parameter", DeviceManagerApi.Sfl101SetSwitchParameter)
	//获取开关参数
	RegistHandler("/device/sfl101/get-switch-parameter", DeviceManagerApi.Sfl101GetSwitchParameter)

	//设置标定设备姿态
	RegistHandler("/device/sfl101/set-posture", DeviceManagerApi.Sfl101SetPosture)
	//获取标定设备姿态
	RegistHandler("/device/sfl101/get-posture", DeviceManagerApi.Sfl101GetPosture)
}

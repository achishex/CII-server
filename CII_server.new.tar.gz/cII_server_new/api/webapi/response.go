package webapi

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"github.com/emicklei/go-restful"
)

func Success(data interface{}, resp *restful.Response) {
	success := common.Response{
		ErrorCode: 0,
		Message:   "ok",
		Data:      data,
	}
	if err := resp.WriteEntity(success); err != nil {
		logger.Errorf("write entity error:%v", err)
	}
}

func CustomFail(code int32, msg string, resp *restful.Response) {
	var data string
	fail := common.Response{
		ErrorCode: code,
		Message:   msg,
		Data:      data,
	}
	if err := resp.WriteEntity(fail); err != nil {
		logger.Errorf("write entity error:%v", err)
	}
}

func ParameterBindFail(code int32, msg string, resp *restful.Response) {
	var data string
	fail := common.Response{
		ErrorCode: code,
		Message:   msg,
		Data:      data,
	}
	if err := resp.WriteEntity(fail); err != nil {
		logger.Errorf("write entity error:%v", err)
	}
}

func Result(err error, res *restful.Response) {
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
	} else {
		Success(nil, res)
	}
}

func ResultList(err error, res *restful.Response, list interface{}) {
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
	} else {
		Success(list, res)
	}
}

type Custom struct {
	Id     string `json:"id"`
	Code   int    `json:"code"`
	Detail string `json:"detail"`
	Status string `json:"status"`
}

package webapi

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"context"
	"github.com/emicklei/go-restful"
)

// SetNoise 设置底噪采集
func (e *deviceManager) SetNoise(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GunsPlatformSetNoiseRequest{}
	deviceResp := &client.GunsPlatformSetNoiseResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err := handler.NewDeviceCenter().GunsPlatformSetNoise(context.Background(), deviceReq, deviceResp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceResp, res)
}

// DetectFreqNodeList 获取频点列表
func (e *deviceManager) DetectFreqNodeList(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GunsPlatformGetFreqListRequest{}
	deviceRsp := &client.GunsPlatformGetFreqListResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().GunsPlatformGetFreqNodeList(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// SetFreqCmd 下发时频图采集指令
func (e *deviceManager) SetFreqCmd(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GunsPlatformSetFreqCmdRequest{}
	deviceRsp := &client.GunsPlatformSetFreqCmdResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().GunsPlatformSetFreqCmd(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// GunsPlatformGetVersionInfo 获取版本号
func (e *deviceManager) GunsPlatformGetVersionInfo(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GunsPlatformGetVersionRequest{}
	deviceRsp := &client.GunsPlatformGetVersionResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().GunsPlatformGetVersionInfo(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}

	Success(deviceRsp, res)
}

// GunsPlatformStopHit 发送停止打击
func (e *deviceManager) GunsPlatformStopHit(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GunsPlatformStopHitRequest{}
	deviceRsp := &client.GunsPlatformStopHitResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().GunsPlatformStopHitSet(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// GunsPlatformSetGNSS ...
func (e *deviceManager) GunsPlatformSetGNSS(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GunsPlatformSetGNSSRequest{}
	deviceRsp := &client.GunsPlatformSetGNSSResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	logger.Debug("GunsPlatformSetGNSS ------- req ", deviceReq)
	err := handler.NewDeviceCenter().GunsPlatformGNSSSet(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	logger.Debug("GunsPlatformSetGNSS ------- deviceRsp", deviceRsp)
	Success(deviceRsp, res)
}

// GunsPlatformGetGNSS ...
func (e *deviceManager) GunsPlatformGetGNSS(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GunsPlatformGetGNSSRequest{}
	deviceRsp := &client.GunsPlatformGetGNSSResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	logger.Debug("GunsPlatformGetGNSS ------- deviceReq ", deviceReq)
	err := handler.NewDeviceCenter().GunsPlatformGNSSGet(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	logger.Debug("GunsPlatformGetGNSS deviceRsp ----  ", deviceRsp)
	Success(deviceRsp, res)
}

// GunsPlatformHitAngle 发送打击点信息配置
func (e *deviceManager) GunsPlatformHitAngle(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GunsPlatformHitAngleRequest{}
	deviceRsp := &client.GunsPlatformHitAngleResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().GunsPlatformHitAngleSet(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// GunsPlatformOnOff 发送开关机指令
func (e *deviceManager) GunsPlatformOnOff(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GunsPlatformOnOffRequest{}
	deviceRsp := &client.GunsPlatformOnOffResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().GunsPlatformOnOffSet(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// GunsPlatformResetting 发送一键复位指令
func (e *deviceManager) GunsPlatformResetting(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GunsPlatformResetRequest{}
	deviceRsp := &client.GunsPlatformResetResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().GunsPlatformReSet(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// GunsPlatformGetStatus 发送获取角度、工作模式、打击时长、打击范围
func (e *deviceManager) GunsPlatformGetStatus(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GunsPlatformGetStatusRequest{}
	deviceRsp := &client.GunsPlatformGetStatusResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().GunsPlatformGetStatus(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// GunsPlatformGetPower 发送获取开关机指令
func (e *deviceManager) GunsPlatformGetPower(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GunsPlatformGetPowerRequest{}
	deviceRsp := &client.GunsPlatformGetPowerResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().GunsPlatformGetPower(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// GunsPlatformHitUav 发送选中无人机打击
func (e *deviceManager) GunsPlatformHitUav(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GunsPlatformSendHitUavRequest{}
	deviceRsp := &client.GunsPlatformSendHitUavResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().GunsPlatformSendHitUav(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// GunsPlatformSetHitMode 发送设置工作模式：手动、自动
func (e *deviceManager) GunsPlatformSetHitMode(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GunsPlatformSetHitModeRequest{}
	deviceRsp := &client.GunsPlatformSetHitModeResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().GunsPlatformSetHitMode(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// GunsPlatformGetHitMode 发送获取工作模式：手动、自动
func (e *deviceManager) GunsPlatformGetHitMode(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GunsPlatformGetHitModeRequest{}
	deviceRsp := &client.GunsPlatformGetHitModeResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().GunsPlatformGetHitMode(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// 启动/停止打击
func (e *deviceManager) GunsPlatformTurnHit(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GunsPlatformTurnHitRequest{}
	deviceRsp := &client.GunsPlatformTurnHitResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().GunsPlatformTurnHit(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// 水平方向转动
func (e *deviceManager) GunsPlatformHorizontalTurn(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GunsPlatformHorizontalTurnRequest{}
	deviceRsp := &client.GunsPlatformHorizontalTurnResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().GunsPlatformHorizontalTurn(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// 垂直方向转动
func (e *deviceManager) GunsPlatformVerticalTurn(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GunsPlatformVerticalTurnRequest{}
	deviceRsp := &client.GunsPlatformVerticalTurnResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().GunsPlatformVerticalTurn(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// GunsPlatformHitMode 发送打击模式配置
func (e *deviceManager) GunsPlatformHitMode(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GunsPlatformHitModeRequest{}
	deviceRsp := &client.GunsPlatformHitModeResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().GunsPlatformHitModeSet(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// GunsPlatformCrashStop 哨兵塔急停
func (e *deviceManager) GunsPlatformCrashStop(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GunsPlatformCrashStopRequest{}
	deviceRsp := &client.GunsPlatformCrashStopResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().GunsPlatformCrashStop(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// GunsPlatformSetPreciseHit 设置精准打击特性
func (e *deviceManager) GunsPlatformSetPreciseHit(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GunsPlatformSetPreciseHitRequest{}
	deviceRsp := &client.GunsPlatformSetPreciseHitResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().GunsPlatformSetPreciseHit(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// GunsPlatformGetPreciseHit 获取精准打击特性
func (e *deviceManager) GunsPlatformGetPreciseHit(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GunsPlatformGetPreciseHitRequest{}
	deviceRsp := &client.GunsPlatformGetPreciseHitResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().GunsPlatformGetPreciseHit(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// GunsPlatformSetInvalidFreq 设置无效无人机频点
func (e *deviceManager) GunsPlatformSetInvalidFreq(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GunsPlatformSetInvalidFreqRequest{}
	deviceRsp := &client.GunsPlatformSetInvalidFreqResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().GunsPlatformSetInvalidFreq(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// GunsPlatformGetInvalidFreq 获取无效无人机频点
func (e *deviceManager) GunsPlatformGetInvalidFreq(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GunsPlatformGetInvalidFreqRequest{}
	deviceRsp := &client.GunsPlatformGetInvalidFreqResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().GunsPlatformGetInvalidFreq(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// GunsPlatformSetHitRadius 设置自动打击的半径
func (e *deviceManager) GunsPlatformSetHitRadius(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GunsPlatformSetAutoHitRadiusRequest{}
	deviceRsp := &client.GunsPlatformSetAutoHitRadiusResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().GunsPlatformSetHitRadius(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// GunsPlatformGetHitRadius 获取自动打击的半径
func (e *deviceManager) GunsPlatformGetHitRadius(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GunsPlatformGetAutoHitRadiusRequest{}
	deviceRsp := &client.GunsPlatformGetAutoHitRadiusResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().GunsPlatformGetHitRadius(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// GunsPlatformSetSwitchParameter 设置开关参数
func (e *deviceManager) GunsPlatformSetSwitchParameter(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GunsPlatformSetSwitchParameterRequest{}
	deviceRsp := &client.GunsPlatformSetSwitchParameterResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().GunsPlatformSetSwitchParameter(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// GunsPlatformGetSwitchParameter 获取开关参数
func (e *deviceManager) GunsPlatformGetSwitchParameter(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GunsPlatformGetSwitchParameterRequest{}
	deviceRsp := &client.GunsPlatformGetSwitchParameterResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().GunsPlatformGetSwitchParameter(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}
func init() {
	// 设置底噪采集
	RegistHandler("/device/gun-platform/set-noise", DeviceManagerApi.SetNoise)
	// 获取频点列表
	RegistHandler("/device/gun-platform/detect-freq-node-list", DeviceManagerApi.DetectFreqNodeList)
	// 时频图采集指令
	RegistHandler("/device/gun-platform/set-freq-cmd", DeviceManagerApi.SetFreqCmd)
	// 获取版本信息
	RegistHandler("/device/gun-platform/get-version-info", DeviceManagerApi.GunsPlatformGetVersionInfo)
	//停止当前打击
	RegistHandler("/device/gun-platform/stop-hit", DeviceManagerApi.GunsPlatformStopHit)
	//设置打击参数信息
	RegistHandler("/device/gun-platform/hit-angle", DeviceManagerApi.GunsPlatformHitAngle)
	//开机、关机
	RegistHandler("/device/gun-platform/on-off", DeviceManagerApi.GunsPlatformOnOff)
	//一键云台复位
	RegistHandler("/device/gun-platform/resetting", DeviceManagerApi.GunsPlatformResetting)
	//选中无人机手动打击
	RegistHandler("/device/gun-platform/hit-uav", DeviceManagerApi.GunsPlatformHitUav)
	//获取设备状态
	RegistHandler("/device/gun-platform/get-status", DeviceManagerApi.GunsPlatformGetStatus)
	//获取开关机状态
	RegistHandler("/device/gun-platform/get-onoff", DeviceManagerApi.GunsPlatformGetPower)

	//设置是否自动打击
	RegistHandler("/device/gun-platform/set-hit-mode", DeviceManagerApi.GunsPlatformSetHitMode)
	//获取是否自动打击
	RegistHandler("/device/gun-platform/get-hit-mode", DeviceManagerApi.GunsPlatformGetHitMode)

	//获取设备GNSS位置
	RegistHandler("/device/gun-platform/setGNSS", DeviceManagerApi.GunsPlatformSetGNSS)
	//设置设备GNSS位置
	RegistHandler("/device/gun-platform/getGNSS", DeviceManagerApi.GunsPlatformGetGNSS)

	//启动/停止打击
	RegistHandler("/device/gun-platform/turn-hit", DeviceManagerApi.GunsPlatformTurnHit)
	//水平方向转动
	RegistHandler("/device/gun-platform/horizontal-turn", DeviceManagerApi.GunsPlatformHorizontalTurn)
	//垂直方向转动
	RegistHandler("/device/gun-platform/vertical-turn", DeviceManagerApi.GunsPlatformVerticalTurn)
	//设置打击模式
	RegistHandler("/device/gun-platform/hit-mode-set", DeviceManagerApi.GunsPlatformHitMode)
	//哨兵塔急停
	RegistHandler("/device/gun-platform/crash-stop", DeviceManagerApi.GunsPlatformCrashStop)

	//设置精准打击特性
	RegistHandler("/device/gun-platform/set-precise", DeviceManagerApi.GunsPlatformSetPreciseHit)
	//获取精准打击特性
	RegistHandler("/device/gun-platform/get-precise", DeviceManagerApi.GunsPlatformGetPreciseHit)

	//设置无效无人机频点
	RegistHandler("/device/gun-platform/set-invalid-freq", DeviceManagerApi.GunsPlatformSetInvalidFreq)
	//获取无效无人机频点
	RegistHandler("/device/gun-platform/get-invalid-freq", DeviceManagerApi.GunsPlatformGetInvalidFreq)

	//设置自动打击的半径
	RegistHandler("/device/gun-platform/set-hit-radius", DeviceManagerApi.GunsPlatformSetHitRadius)
	//获取自动打击的半径
	RegistHandler("/device/gun-platform/get-hit-radius", DeviceManagerApi.GunsPlatformGetHitRadius)

	//设置开关参数
	RegistHandler("/device/gun-platform/set-switch-parameter", DeviceManagerApi.GunsPlatformSetSwitchParameter)
	//获取开关参数
	RegistHandler("/device/gun-platform/get-switch-parameter", DeviceManagerApi.GunsPlatformGetSwitchParameter)

}

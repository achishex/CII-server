package webapi

import (
	"context"

	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"github.com/emicklei/go-restful"
)

// GetLocalLogList 本地日志接口
func (e *deviceManager) GetLocalLogList(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GetLocalLogRequest{}
	deviceRsp := &client.GetLocalLogResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().GetLocalLogs(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

func (e *deviceManager) DelLocalLog(req *restful.Request, res *restful.Response) {
	deviceReq := &client.DelLocalLogRequest{}
	deviceRsp := &client.DelLocalLogResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().DelLocalLogs(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// GetDeviceLogList 设备日志接口
func (e *deviceManager) GetDeviceLogList(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GetDeviceLogListRequest{}
	deviceRsp := &client.DeviceLogList{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().GetDeviceLogList(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

func (e *deviceManager) GetDeviceLog(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GetDeviceLogRequest{}
	deviceRsp := &client.GetDeviceLogResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().GetDeviceLog(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

func (e *deviceManager) DeleteDeviceLog(req *restful.Request, res *restful.Response) {
	deviceReq := &client.DeleteDeviceLogRequest{}
	deviceRsp := &client.DeleteDeviceLogResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().DeleteDeviceLog(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// GetDeviceLogListCloud 云日志接口
func (e *deviceManager) GetDeviceLogListCloud(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GetDeviceLogListCloudRequest{}
	deviceRsp := &client.GetDeviceLogListCloudResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().GetDeviceLogListCloud(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

func (e *deviceManager) UploadDeviceLog(req *restful.Request, res *restful.Response) {
	deviceReq := &client.UploadDeviceLogCloudRequest{}
	deviceRsp := &client.UploadDeviceLogCloudResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().UploadDeviceLogCloud(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

func (e *deviceManager) DownloadDeviceLog(req *restful.Request, res *restful.Response) {
	deviceReq := &client.DownloadDeviceLogCloudRequest{}
	deviceRsp := &client.DownloadDeviceLogCloudResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().DownloadDeviceLogCloud(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

func (e *deviceManager) DeleteCloudDeviceLog(req *restful.Request, res *restful.Response) {
	deviceReq := &client.DeleteDeviceLogCloudRequest{}
	deviceRsp := &client.DeleteDeviceLogCloudResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err = handler.NewDeviceCenter().DeleteDeviceLogCloud(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

func (e *deviceManager) SyncDeviceStatus(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SyncDeviceStatusRequest{}
	deviceRsp := &client.SyncDeviceStatusResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err = handler.NewDeviceCenter().SyncDeviceStatus(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

func (e *deviceManager) SyncCloudStatus(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SyncCloudStatusRequest{}
	deviceRsp := &client.SyncCloudStatusResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err = handler.NewDeviceCenter().SyncCloudStatus(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

func (e *deviceManager) SyncDeviceLog(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SyncDeviceLogRequest{}
	deviceRsp := &client.SyncDeviceLogResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err = handler.NewDeviceCenter().SyncDeviceLog(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

func (e *deviceManager) SyncLocalLog(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SyncLocalLogRequest{}
	deviceRsp := &client.SyncLocalLogResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err = handler.NewDeviceCenter().SyncLocalLog(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

func init() {
	//本地日志操作
	RegistHandler("/device/local/log/list", DeviceManagerApi.GetLocalLogList)
	RegistHandler("/device/local/log/delete", DeviceManagerApi.DelLocalLog)
	//设备日志操作
	RegistHandler("/device/types/log/list", DeviceManagerApi.GetDeviceLogList)
	RegistHandler("/device/types/log/get", DeviceManagerApi.GetDeviceLog)
	RegistHandler("/device/types/log/delete", DeviceManagerApi.DeleteDeviceLog)
	//云日志操作
	RegistHandler("/device/cloud/loglist", DeviceManagerApi.GetDeviceLogListCloud)
	RegistHandler("/device/cloud/upload", DeviceManagerApi.UploadDeviceLog)
	RegistHandler("/device/cloud/download", DeviceManagerApi.DownloadDeviceLog)
	RegistHandler("/device/cloud/delete", DeviceManagerApi.DeleteCloudDeviceLog)
	RegistHandler("/cloud/sync/log", DeviceManagerApi.SyncLocalLog)
	RegistHandler("/cloud/sync/status", DeviceManagerApi.SyncCloudStatus)
	//同步日志接口
	RegistHandler("/device/sync/status", DeviceManagerApi.SyncDeviceStatus)
	RegistHandler("/device/sync/log", DeviceManagerApi.SyncDeviceLog)
}

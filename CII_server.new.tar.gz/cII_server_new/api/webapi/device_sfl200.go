package webapi

import (
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"context"
	"github.com/emicklei/go-restful"
)

// Sfl200SetWorkMode 设置工作模式
func (e *deviceManager) Sfl200SetWorkMode(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl200SetWorkModeRequest{}
	deviceRsp := &client.Sfl200SetWorkModeResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().Sfl200SetWorkMode(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}

	Success(deviceRsp, res)
}

// Sfl200GetWorkMode 获取工作模式
func (e *deviceManager) Sfl200GetWorkMode(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl200GetWorkModeRequest{}
	deviceRsp := &client.Sfl200GetWorkModeResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().Sfl200GetWorkMode(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}

	Success(deviceRsp, res)
}

// Sfl200SetAutoHitConfig 自动察打模式指令参数配置
func (e *deviceManager) Sfl200SetAutoHitConfig(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl200SetAutoHitConfigRequest{}
	deviceRsp := &client.Sfl200SetAutoHitConfigResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().Sfl200SetAutoHitConfig(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}

	Success(deviceRsp, res)
}

// Sfl200GetAutoHitConfig 自动察打模式指令参数获取
func (e *deviceManager) Sfl200GetAutoHitConfig(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl200GetAutoHitConfigRequest{}
	deviceRsp := &client.Sfl200GetAutoHitConfigResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().Sfl200GetAutoHitConfig(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}

	Success(deviceRsp, res)
}

// Sfl200PtzFollowUav 目标PTZ跟踪
func (e *deviceManager) Sfl200PtzFollowUav(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl200PtzFollowUavRequest{}
	deviceRsp := &client.Sfl200PtzFollowUavResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().Sfl200PtzFollowUav(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}

	Success(deviceRsp, res)
}

// Sfl200DealUav 目标打击处置
func (e *deviceManager) Sfl200DealUav(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl200DealUavRequest{}
	deviceRsp := &client.Sfl200DealUavResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().Sfl200DealUav(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}

	Success(deviceRsp, res)
}

// Sfl200FreqDirect 频谱目标定向
func (e *deviceManager) Sfl200FreqDirect(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl200FreqDirectRequest{}
	deviceRsp := &client.Sfl200FreqDirectResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().Sfl200FreqDirect(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}

	Success(deviceRsp, res)
}

// Sfl200FreqDirectHit 频谱目标定向打击
func (e *deviceManager) Sfl200FreqDirectHit(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl200FreqDirectHitRequest{}
	deviceRsp := &client.Sfl200FreqDirectHitResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().Sfl200FreqDirectHit(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}

	Success(deviceRsp, res)
}

// Sfl200StartStopHit 开关打击
func (e *deviceManager) Sfl200StartStopHit(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl200StartStopHitRequest{}
	deviceRsp := &client.Sfl200StartStopHitResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().Sfl200StartStopHit(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}

	Success(deviceRsp, res)
}

// Sfl200TurnSfl 转台手动控制
func (e *deviceManager) Sfl200TurnSfl(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl200TurnSflRequest{}
	deviceRsp := &client.Sfl200TurnSflResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().Sfl200TurnSfl(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}

	Success(deviceRsp, res)
}

// Sfl200StartNsf4000 开启导航诱骗干扰
func (e *deviceManager) Sfl200StartNsf4000(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl200StartNsf4000Request{}
	deviceRsp := &client.Sfl200StartNsf4000Response{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().Sfl200StartNsf4000(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}

	Success(deviceRsp, res)
}

// Sfl200SystemWorkSetting 系统工作参数配置
func (e *deviceManager) Sfl200SystemWorkSetting(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl200SystemWorkSettingRequest{}
	deviceRsp := &client.Sfl200SystemWorkSettingResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().Sfl200SystemWorkSetting(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}

	Success(deviceRsp, res)
}

// Sfl200SystemWorkGet 系统工作参数读取
func (e *deviceManager) Sfl200SystemWorkGet(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl200SystemWorkGetRequest{}
	deviceRsp := &client.Sfl200SystemWorkGetResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().Sfl200SystemWorkGet(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}

	Success(deviceRsp, res)
}

// Sfl200GetVersionInfo 获取SFL200版本号
func (e *deviceManager) Sfl200GetVersionInfo(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Sfl200GetVersionRequest{}
	deviceRsp := &client.Sfl200GetVersionResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().Sfl200GetVersionInfo(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}

	Success(deviceRsp, res)
}
func init() {
	//设置工作模式
	RegistHandler("/device/sfl200/set-work-mode", DeviceManagerApi.Sfl200SetWorkMode)
	//获取工作模式
	RegistHandler("/device/sfl200/get-work-mode", DeviceManagerApi.Sfl200GetWorkMode)
	//自动察打模式指令参数配置
	RegistHandler("/device/sfl200/set-auto-hit-config", DeviceManagerApi.Sfl200SetAutoHitConfig)
	//自动察打模式指令参数获取
	RegistHandler("/device/sfl200/get-auto-hit-config", DeviceManagerApi.Sfl200GetAutoHitConfig)
	//目标PTZ跟踪
	RegistHandler("/device/sfl200/ptz-follow-uav", DeviceManagerApi.Sfl200PtzFollowUav)
	//目标打击处置
	RegistHandler("/device/sfl200/deal-uav", DeviceManagerApi.Sfl200DealUav)
	//频谱目标定向
	RegistHandler("/device/sfl200/freq-direct", DeviceManagerApi.Sfl200FreqDirect)
	//频谱目标定向打击
	RegistHandler("/device/sfl200/freq-direct-hit", DeviceManagerApi.Sfl200FreqDirectHit)
	//开关打击
	RegistHandler("/device/sfl200/start-stop-hit", DeviceManagerApi.Sfl200StartStopHit)
	//转台手动控制
	RegistHandler("/device/sfl200/turn-sfl", DeviceManagerApi.Sfl200TurnSfl)
	//开启导航诱骗干扰
	RegistHandler("/device/sfl200/start-nsf4000", DeviceManagerApi.Sfl200StartNsf4000)
	//系统工作参数配置
	RegistHandler("/device/sfl200/system-work-setting", DeviceManagerApi.Sfl200SystemWorkSetting)
	//系统工作参数读取
	RegistHandler("/device/sfl200/system-work-get", DeviceManagerApi.Sfl200SystemWorkGet)
	//获取SFL200版本号
	RegistHandler("/device/sfl200/get-version-info", DeviceManagerApi.Sfl200GetVersionInfo)
}

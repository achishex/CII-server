package webapi

import (
	"context"

	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"github.com/emicklei/go-restful"
)

type Urd360Manager struct {
	Urd360Ctl *handler.Urd360Service
}

var (
	Urd360ManagerApi = &Urd360Manager{
		Urd360Ctl: handler.NewUrd360Service(),
	}
)

func (u *Urd360Manager) Urd360StartMonitor(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Urd360StartMonitorRequest{}
	deviceRsp := &client.Urd360StartMonitorResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := u.Urd360Ctl.StartMonitor(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		CustomFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

func (u *Urd360Manager) Urd360StopMonitor(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Urd360StopMonitorRequest{}
	deviceRsp := &client.Urd360StopMonitorResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := u.Urd360Ctl.StopMonitor(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		CustomFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

func (u *Urd360Manager) Urd360UpdateConfig(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Urd360UpdateConfigRequest{}
	deviceRsp := &client.Urd360UpdateConfigResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := u.Urd360Ctl.UpdateConfig(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		CustomFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

func (u *Urd360Manager) Urd360GetConfig(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Urd360GetConfigRequest{}
	deviceRsp := &client.Urd360GetConfigResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := u.Urd360Ctl.GetConfig(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		CustomFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

func (u *Urd360Manager) Urd360Enable(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Urd360EnableRequest{}
	deviceRsp := &client.Urd360EnableResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := u.Urd360Ctl.Enable(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		CustomFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

func (u *Urd360Manager) Urd360StartSpectrum(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Urd360StartSpectrumRequest{}
	deviceRsp := &client.Urd360StartSpectrumResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := u.Urd360Ctl.StartSpectrum(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		CustomFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

func (u *Urd360Manager) Urd360StopSpectrum(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Urd360StopSpectrumRequest{}
	deviceRsp := &client.Urd360StopSpectrumResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := u.Urd360Ctl.StopSpectrum(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		CustomFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

func init() {
	RegistHandler("/device/urd360/monitor/start", Urd360ManagerApi.Urd360StartMonitor)
	RegistHandler("/device/urd360/monitor/stop", Urd360ManagerApi.Urd360StopMonitor)
	RegistHandler("/device/urd360/config/update", Urd360ManagerApi.Urd360UpdateConfig)
	RegistHandler("/device/urd360/config/get", Urd360ManagerApi.Urd360GetConfig)
	RegistHandler("/device/urd360/enable", Urd360ManagerApi.Urd360Enable)
	RegistHandler("/device/urd360/spectrum/start", Urd360ManagerApi.Urd360StartSpectrum)
	RegistHandler("/device/urd360/spectrum/stop", Urd360ManagerApi.Urd360StopSpectrum)
}

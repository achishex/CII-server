package webapi

import (
	"context"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"

	"github.com/emicklei/go-restful"

	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
)

// DroneIDGetVersionInfo 获取版本tracer信息   20
func (e *deviceManager) DroneIDGetVersionInfo(req *restful.Request, res *restful.Response) {
	deviceReq := &client.DroneIDGetVersionInfoRequest{}
	deviceRsp := &client.DroneIDGetVersionInfoResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().DroneIDGetVersionInfo(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// TracerGetVersionInfo 获取版本tracer信息  AB
func (e *deviceManager) TracerGetVersionInfo(req *restful.Request, res *restful.Response) {
	deviceReq := &client.TracerGetVersionInfoRequest{}
	deviceRsp := &client.TracerGetVersionInfoResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	defer func() {
		logger.Infof("call time: %v", time.Now())
	}()

	err := handler.NewDeviceCenter().TracerGetVersionInfo(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// TracerGetInfo 获取Tracer设备信息
func (e *deviceManager) TracerGetInfo(req *restful.Request, res *restful.Response) {
	deviceReq := &client.TracerGetInfoRequest{}
	deviceRsp := &client.TracerGetInfoResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err := handler.NewDeviceCenter().TracerGetInfo(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		CustomFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// TracerGetWorkMode 获取Tracer工作模式
func (e *deviceManager) TracerGetWorkMode(req *restful.Request, res *restful.Response) {
	deviceReq := &client.TracerGetWorkModeRequest{}
	deviceRsp := &client.TracerGetWorkModeResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err := handler.NewDeviceCenter().TracerGetWorkMode(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		CustomFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// TracerSetOrientationMode 设置Tracer定向模式
func (e *deviceManager) TracerSetOrientationMode(req *restful.Request, res *restful.Response) {
	deviceReq := &client.TracerSetOrientationModeRequest{}
	deviceRsp := &client.TracerSetOrientationModeResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().TracerSetOrientationMode(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		CustomFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// TracerCli 向Tracer发送cmd
func (e *deviceManager) TracerCli(req *restful.Request, res *restful.Response) {
	deviceReq := &client.TracerCliRequest{}
	deviceRsp := &client.TracerCliResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().TracerCli(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		CustomFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// TracerSetHideMode 向Tracer发送隐蔽模式
func (e *deviceManager) TracerSetHideMode(req *restful.Request, res *restful.Response) {
	deviceReq := &client.TracerSetHideModeRequest{}
	deviceRsp := &client.TracerSetHideModeResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().TracerSetHideMode(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		CustomFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// TracerSetAlarm 向Tracer设置告警等级
func (e *deviceManager) TracerSetAlarm(req *restful.Request, res *restful.Response) {
	deviceReq := &client.TracerSetAlarmRequest{}
	deviceRsp := &client.TracerSetAlarmResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().TracerSetAlarm(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		CustomFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

func (e *deviceManager) GetOrientationDroneList(req *restful.Request, res *restful.Response) {
	deviceReq := &client.TracerSOrientationDroneReq{}
	deviceRsp := &client.TracerSOrientationDroneResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().GetOrientRecordItems(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		CustomFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// TracerSetVideoParam 向Tracer设置视频参数
func (e *deviceManager) TracerSetVideoParam(req *restful.Request, res *restful.Response) {
	deviceReq := &client.TracerSetVideoParamRequest{}
	deviceRsp := &client.TracerSetVideoParamResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().TracerSetVideoParam(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		CustomFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// TracerGetDetectFreqList	获取侦测频点列表
func (e *deviceManager) TracerGetDetectFreqList(req *restful.Request, res *restful.Response) {
	deviceReq := &client.TracerGetFreqListRequest{}
	deviceRsp := &client.TracerGetFreqListResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().TracerDetectFreqList(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		CustomFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// TracerSetNoiseFloor 向Tracer设置噪底检测频点
func (e *deviceManager) TracerSetNoiseFloor(req *restful.Request, res *restful.Response) {
	deviceReq := &client.TracerSetNoiseFloorRequest{}
	deviceRsp := &client.TracerSetNoiseFloorResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().TracerSetNoiseFloor(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		CustomFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// TracerCollectData 请求tracer 数据收集命令
func (e *deviceManager) TracerCollectData(req *restful.Request, res *restful.Response) {
	deviceReq := &client.CollectDataRequest{}
	deviceRsp := &client.CollectDataResponse{}
	//
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	//
	err := handler.NewDeviceCenter().TracerCollectData(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		CustomFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// TracerLogExport 导出Tracer日志
func (e *deviceManager) TracerLogExport(req *restful.Request, res *restful.Response) {
	deviceReq := &client.TracerLogExportRequest{}
	deviceRsp := &client.TracerLogExportResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		logger.Errorf("TracerLogExport request err:%v", err)
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err := handler.NewDeviceCenter().TracerLogExport(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		logger.Errorf("TracerLogExport err:%v", err)
		CustomFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// TracerSetTimeFreq 新频谱设置
func (e *deviceManager) TracerSetTimeFreq(req *restful.Request, res *restful.Response) {
	deviceReq := &client.TracerSetTimeFreqRequest{}
	deviceRsp := &client.TracerSetTimeFreqResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		logger.Errorf("TracerSetTimeFreq request err:%v", err)
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err := handler.NewDeviceCenter().TracerSetTimeFreq(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		logger.Errorf("TracerSetTimeFreq err:%v", err)
		CustomFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}
func (e *deviceManager) DemoTestCall(req *restful.Request, res *restful.Response) {
	processDeviceManager[client.DemoTestReq, client.DemoTestResp](req, res, handler.NewDeviceCenter().DemoTestCall)
}
func (e *deviceManager) SetFreqSpectrum(req *restful.Request, res *restful.Response) {
	processDeviceManager[client.FreqSpectrumSetReq, client.FreqSpectrumSetResp](req, res, handler.NewDeviceCenter().TracerSetFreqSpectrum)
}
func (e *deviceManager) GetFreqSpectrum(req *restful.Request, res *restful.Response) {
	processDeviceManager[client.FreqSpectrumGetReq, client.FreqSpectrumGetResp](req, res, handler.NewDeviceCenter().TracerGetFreqSpectrum)
}
func (e *deviceManager) SetInvalidFreqRange(req *restful.Request, res *restful.Response) {
	processDeviceManager[client.SetInvalidFreqRangeReq, client.SetInvalidFreqRangeRsp](req, res, handler.NewDeviceCenter().TracerSetInvalidFreqRange)
}
func (e *deviceManager) GetInvalidFreqRange(req *restful.Request, res *restful.Response) {
	processDeviceManager[client.GetInvalidFreqRangeReq, client.GetInvalidFreqRangeRsp](req, res, handler.NewDeviceCenter().TracerGetInvalidFreqRange)
}

func (e *deviceManager) SetProtocolParsedParam(req *restful.Request, res *restful.Response) {
	processDeviceManager[client.SetProtocolParseParamReq, client.SetProtocolParseParamRsp](req, res, handler.NewDeviceCenter().TracerSetProtocolParseParam)
}

func (e *deviceManager) GetProtocolParsedParam(req *restful.Request, res *restful.Response) {
	processDeviceManager[client.GetProtocolParseParamReq, client.GetProtocolParseParamRsp](req, res, handler.NewDeviceCenter().TracerGetProtocolParseParam)
}

func init() {
	RegistHandler("/device/tracer/set-alarm", DeviceManagerApi.TracerSetAlarm)
	RegistHandler("/device/tracer/set-hide-mode", DeviceManagerApi.TracerSetHideMode)
	RegistHandler("/device/droneID/get-version-info", DeviceManagerApi.DroneIDGetVersionInfo) //前端未使用
	RegistHandler("/device/tracer/get-version-info", DeviceManagerApi.TracerGetVersionInfo)
	RegistHandler("/device/tracer/info", DeviceManagerApi.TracerGetInfo)
	//获取tracer工作模式
	RegistHandler("/device/tracer/get-work-mode", DeviceManagerApi.TracerGetWorkMode)
	//设置tracer定向模式
	RegistHandler("/device/tracer/ser-orientation-mode", DeviceManagerApi.TracerSetOrientationMode)
	//向tracer发送CMD命令
	RegistHandler("/device/tracer/cli", DeviceManagerApi.TracerCli)
	//查询tracerS定向无人机的记录; 默认查询时间是 4.5个小时;
	RegistHandler("/device/tracer/orientation-drone-list", DeviceManagerApi.GetOrientationDroneList)
	// 设置视频参数
	RegistHandler("/device/tracer/set-video-param", DeviceManagerApi.TracerSetVideoParam)
	// 设置噪底检测(tracerP/TracerS)
	RegistHandler("/device/tracer/set-noise-floor", DeviceManagerApi.TracerSetNoiseFloor)
	// 发起数据收集命令
	RegistHandler("/device/tracer/collect_data", DeviceManagerApi.TracerCollectData)
	//	获取侦测频点列表
	RegistHandler("/device/tracer/detect-freq-node-list", DeviceManagerApi.TracerGetDetectFreqList)
	// tracer日志导出
	RegistHandler("/device/tracer/export-log", DeviceManagerApi.TracerLogExport)
	// tracer设置时频扫描
	RegistHandler("/device/tracer/set-time-freq", DeviceManagerApi.TracerSetTimeFreq)
	// C2配置频谱侦测参数
	RegistHandler("/device/tracer/set-freq-spectrum", DeviceManagerApi.SetFreqSpectrum)
	// C2获取频谱侦测参数
	RegistHandler("/device/tracer/get-freq-spectrum", DeviceManagerApi.GetFreqSpectrum)
	// 设置无效的无人机频点
	RegistHandler("/device/tracer/set-invalid-freq-range", DeviceManagerApi.SetInvalidFreqRange)
	// 获取无效的无人机频点
	RegistHandler("/device/tracer/get-invalid-freq-range", DeviceManagerApi.GetInvalidFreqRange)
	// 配置协议解析侦测参数
	RegistHandler("/device/tracer/set-proto-parse-param", DeviceManagerApi.SetProtocolParsedParam)
	// 获取协议解析侦测参数
	RegistHandler("/device/tracer/get-proto-parse-param", DeviceManagerApi.GetProtocolParsedParam)
	//
	RegistHandler("/device/tracer/demo-test", DeviceManagerApi.DemoTestCall)
}

package webapi

import (
	"context"

	"github.com/emicklei/go-restful"

	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
)

var FenceAPI = new(fenceAPI)

type fenceAPI struct{}

func (f *fenceAPI) AddFence(req *restful.Request, res *restful.Response) {
	addFenceReq := &client.AddFenceRequest{}
	addFenceRsp := &client.AddFenceResponse{}
	err := req.ReadEntity(addFenceReq)
	if err != nil {
		logger.Errorf("AddFence params[%+v], err:%v", addFenceReq, err)
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err = handler.NewFenceControl().AddFence(context.Background(), addFenceReq, addFenceRsp)
	if err != nil {
		logger.Errorf("AddFence err: %v", err)
		CustomFail(addFenceRsp.GetStatus(), err.Error(), res)
		return
	}
	Success(addFenceRsp, res)
}

func (f *fenceAPI) UpdateFence(req *restful.Request, res *restful.Response) {
	updateFenceReq := &client.UpdateFenceRequest{}
	updateFenceRsp := &client.UpdateFenceResponse{}
	err := req.ReadEntity(updateFenceReq)
	if err != nil {
		logger.Errorf("UpdateFence params[%+v], err:%v", updateFenceReq, err)
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err = handler.NewFenceControl().UpdateFence(context.Background(), updateFenceReq, updateFenceRsp)
	if err != nil {
		logger.Errorf("UpdateFence err: %v", err)
		CustomFail(updateFenceRsp.GetStatus(), err.Error(), res)
		return
	}
	Success(updateFenceRsp, res)
}

func (f *fenceAPI) GetFenceList(req *restful.Request, res *restful.Response) {
	getFenceListReq := &client.GetFenceListRequest{}
	getFenceListRsp := &client.GetFenceListResponse{}
	err := req.ReadEntity(getFenceListReq)
	if err != nil {
		logger.Errorf("GetFenceList params[%+v], err:%v", getFenceListReq, err)
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err = handler.NewFenceControl().GetFenceList(context.Background(), getFenceListReq, getFenceListRsp)
	if err != nil {
		logger.Errorf("GetFenceList err: %v", err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(getFenceListRsp, res)
}

func (f *fenceAPI) GetFenceDetail(req *restful.Request, res *restful.Response) {
	getFenceReq := &client.GetFenceDetailRequest{}
	getFenceRsp := &client.GetFenceDetailResponse{}
	err := req.ReadEntity(getFenceReq)
	if err != nil {
		logger.Errorf("GetFenceDetail params[%+v], err:%v", getFenceReq, err)
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err = handler.NewFenceControl().GetFenceDetail(context.Background(), getFenceReq, getFenceRsp)
	if err != nil {
		logger.Errorf("GetFenceDetail err: %v", err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(getFenceRsp, res)
}

func (f *fenceAPI) DeleteFence(req *restful.Request, res *restful.Response) {
	delFenceReq := &client.DeleteFenceRequest{}
	delFenceRsp := &client.DeleteFenceResponse{}
	err := req.ReadEntity(delFenceReq)
	if err != nil {
		logger.Errorf("DeleteFence params[%+v], err:%v", delFenceReq, err)
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err = handler.NewFenceControl().DeleteFence(context.Background(), delFenceReq, delFenceRsp)
	if err != nil {
		logger.Errorf("DeleteFence err: %v", err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(delFenceRsp, res)
}

func init() {
	RegistHandler("/rest/v1/business/fence/add", FenceAPI.AddFence)
	RegistHandler("/rest/v1/business/fence/update", FenceAPI.UpdateFence)
	RegistHandler("/rest/v1/business/fence/list", FenceAPI.GetFenceList)
	RegistHandler("/rest/v1/business/fence/get", FenceAPI.GetFenceDetail)
	RegistHandler("/rest/v1/business/fence/delete", FenceAPI.DeleteFence)
}

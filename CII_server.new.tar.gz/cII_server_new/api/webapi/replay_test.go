package webapi

import (
	"context"
	"net/http"
	"net/http/httptest"
	"reflect"
	"strings"
	"testing"

	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/test"
	"github.com/agiledragon/gomonkey"
	"github.com/emicklei/go-restful"
	"github.com/stretchr/testify/assert"
)

func TestReplay_Playback(t *testing.T) {
	// Mock 日志
	test.LoggerMock()

	data := `{"plotTracks":{"offset":5,"limit":1,"period":2}, "status":{"offset":5,"limit":1,"period":2}}`
	req := httptest.NewRequest(http.MethodPost, "/radar-data/playback", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	a := &handler.Replay{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(a), "Replay", func(_ *handler.Replay, _ context.Context, req *client.ReplayReq, res *client.ReplayRes) error {
		return nil
	})
	defer patches.Reset()

	type fields struct {
		PlaybackCancel func()
	}
	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name   string
		fields fields
		args   args
	}{
		{
			name: "Case1",
			fields: fields{
				PlaybackCancel: func() {},
			},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			p := &Replay{
				PlaybackCancel: tt.fields.PlaybackCancel,
			}
			p.Playback(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}

func TestReplay_PlaybackStop(t *testing.T) {
	// Mock 日志
	test.LoggerMock()

	data := `{"plot_tracks":{"offset":5,"limit":1,"period":2}, "status":{"offset":5,"limit":1,"period":2}}`
	req := httptest.NewRequest(http.MethodPost, "/radar-data/playback/stop", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	a := &handler.Replay{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(a), "ReplayStop", func(_ *handler.Replay, _ context.Context, req *client.ReplayStopReq, res *client.ReplayStopRes) error {
		return nil
	})
	defer patches.Reset()

	type fields struct {
		PlaybackCancel func()
	}
	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name   string
		fields fields
		args   args
	}{
		{
			name: "Case1",
			fields: fields{
				PlaybackCancel: func() {},
			},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			p := &Replay{
				PlaybackCancel: tt.fields.PlaybackCancel,
			}
			p.PlaybackStop(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}

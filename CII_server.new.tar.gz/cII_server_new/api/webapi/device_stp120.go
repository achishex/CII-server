package webapi

import (
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"github.com/emicklei/go-restful"
)

func (e *deviceManager) DevStp120OnSwitch(req *restful.Request, res *restful.Response) {
	processDeviceManager[client.Stp120OnOffRequest, client.Stp120OnOffResponse](req, res, handler.NewDeviceCenter().Stp120OnSwitch)

}

func (e *deviceManager) DevStp120Reboot(req *restful.Request, res *restful.Response) {
	processDeviceManager[client.Stp120RebootRequest, client.Stp120RebootResponse](req, res, handler.NewDeviceCenter().Stp120Reboot)
}
func (e *deviceManager) DevGetGNSS(req *restful.Request, res *restful.Response) {
	processDeviceManager[client.Stp120GetGNSSRequest, client.Stp120GetGNSSResponse](req, res, handler.NewDeviceCenter().GetGNSS)
}
func (e *deviceManager) DevSetGNSS(req *restful.Request, res *restful.Response) {
	processDeviceManager[client.Stp120SetGNSSRequest, client.Stp120SetGNSSResponse](req, res, handler.NewDeviceCenter().SetGNSS)
}
func (e *deviceManager) DevGetVersion(req *restful.Request, res *restful.Response) {
	processDeviceManager[client.Stp120GetVersionRequest, client.Stp120GetVersionResponse](req, res, handler.NewDeviceCenter().Stp120GetVersion)
}

func init() {
	// 开机和关机
	RegistHandler("/device/stp120/on-off", DeviceManagerApi.DevStp120OnSwitch)
	// 重启
	RegistHandler("/device/stp120/reboot", DeviceManagerApi.DevStp120Reboot)
	// 位置信息查询
	RegistHandler("/device/stp120/getGNSS", DeviceManagerApi.DevGetGNSS)
	// 位置信息修改
	RegistHandler("/device/stp120/setGNSS", DeviceManagerApi.DevSetGNSS)
	// 获取版本信息
	RegistHandler("/device/stp120/get-version-info", DeviceManagerApi.DevGetVersion)
}

package webapi

import (
	"context"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"github.com/emicklei/go-restful"

	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
)

type deviceManager struct {
}

var (
	DeviceManagerApi = new(deviceManager)
)

// List 前端获取设备列表
func (e *deviceManager) List(_ *restful.Request, res *restful.Response) {
	list := &client.EquipListRes{}
	err := handler.NewEquipList().List(context.Background(), &client.EquipListReq{}, list)
	if list != nil && len(list.Equips) > 0 {
		equipRsp := &client.GetEquipListResponse{}
		err = handler.NewDeviceCenter().GetEquipList(context.Background(), &client.GetEquipListRequest{}, equipRsp)
		nameMap := make(map[string]*client.EquipInfo, 0)
		if equipRsp != nil && equipRsp.Equips != nil {
			for _, v := range equipRsp.Equips {
				nameMap[v.Sn] = v
			}
		}
		for _, v := range list.Equips {
			if eq, ok := nameMap[v.Sn]; ok {
				//v.Ip = eq.Ip
				v.Etype = eq.Etype
				v.CrtTime = eq.CrtTime
				v.UpdateTime = eq.UpdateTime
				v.IsOnline = eq.IsOnline
				v.TcpPort = eq.TcpPort
			} else {
				//离线
				v.IsOnline = 1
			}
		}
	}
	ResultList(err, res, list)
}

// AddSimulateDevice 运行雷达、tracer模拟数据
func (e *deviceManager) AddSimulateDevice(req *restful.Request, res *restful.Response) {
	deviceReq := &client.AddSimulateDeviceRequest{}
	deviceRsp := &client.AddSimulateDeviceResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		logger.Errorf("parse AddSimulateDevice params[%v] error:%v", deviceReq, err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	logger.Infof("add sim device, req: %+v", deviceReq)
	err = handler.NewDeviceCenter().AddSimulateDevice(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// C2Update C2版本更新
func (e *deviceManager) C2Update(req *restful.Request, res *restful.Response) {
	deviceReq := &client.DownC2ApkRequest{}
	deviceRsp := &client.DownC2ApkResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	bean.GAppVersion = deviceReq.Version
	err = handler.NewDeviceCenter().DownC2Apk(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// C2SystemUpdate C2自研平板系统更新
func (e *deviceManager) C2SystemUpdate(req *restful.Request, res *restful.Response) {
	deviceReq := &client.DownC2SystemRequest{}
	deviceRsp := &client.DownC2SystemResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().DownC2System(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// C2License C2License功能    暂未使用
func (e *deviceManager) C2License(req *restful.Request, res *restful.Response) {
	deviceReq := &client.ReqC2LicenseRequest{}
	deviceRsp := &client.ReqC2LicenseResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().ReqC2License(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// Export 无人机白名单导出
func (e *deviceManager) Export(req *restful.Request, res *restful.Response) {
	deviceReq := &client.ExportWhiteListRequest{}
	deviceRsp := &client.ExportWhiteListResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().ExportWhiteList(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// Import 无人机白名单批量导入
func (e *deviceManager) Import(req *restful.Request, res *restful.Response) {
	deviceReq := &client.ImportWhiteListRequest{}
	deviceRsp := &client.ImportWhiteListResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().ImportWhiteList(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// StartUdpBroadCast C2开始发广播
func (e *deviceManager) StartUdpBroadCast(req *restful.Request, res *restful.Response) {
	deviceReq := &client.StartUdpBroadCastRequest{}
	deviceRsp := &client.StartUdpBroadCastResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().StartUdpBroadCast(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// StopUdpBroadCast C2停止广播
func (e *deviceManager) StopUdpBroadCast(req *restful.Request, res *restful.Response) {
	deviceReq := &client.StopUdpBroadCastRequest{}
	deviceRsp := &client.StopUdpBroadCastResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().StopUdpBroadCast(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// ConfirmDeviceConn 前端已经不使用
func (e *deviceManager) ConfirmDeviceConn(req *restful.Request, res *restful.Response) {

	Success(nil, res)
}

// SetEnable 设备启用禁用
func (e *deviceManager) SetEnable(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SetDeviceStatusRequest{}
	deviceRsp := &client.SetDeviceStatusResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}

	if err = handler.NewDeviceCenter().SetDeviceStatus(context.Background(), deviceReq, deviceRsp); err != nil {
		logger.Errorf("SetDeviceStatus error:%v", err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	setStatusRes := &client.SetEnableRes{}
	err = handler.NewEquipList().SetEnableState(context.Background(), &client.SetEnableReq{Sn: deviceReq.Sn, Status: deviceReq.Status}, setStatusRes)
	if err != nil {
		logger.Errorf("SetEnableState error:%v", err)
		ParameterBindFail(500, err.Error(), res)
		return
	}

	Success(setStatusRes, res)
}

// GetReplayDataShedule 获取设备是否有无人机数据
func (e *deviceManager) GetReplayDataShedule(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GetReplayDataScheduleRequest{}
	deviceRsp := &client.GetReplayDataScheduleResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().GetReplayDataSchedule(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		CustomFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// GetReplayData 获取设备一段时间的无人机数据
func (e *deviceManager) GetReplayData(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GetReplayDataRequest{}
	deviceRsp := &client.GetReplayDataResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err := handler.NewDeviceCenter().GetReplayData(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		CustomFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// DataMarkers 时间标记接口
func (e *deviceManager) DataMarkers(req *restful.Request, res *restful.Response) {
	deviceReq := &client.DataMarkersRequest{}
	deviceRsp := &client.DataMarkersResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err := handler.NewDeviceCenter().DataMarkers(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		CustomFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// GenFakeData  开始生成模拟数据
func (e *deviceManager) GenFakeData(req *restful.Request, res *restful.Response) {
	request := &client.GenFakeReq{}
	resp := &client.GenFakeDataResp{}
	if err := req.ReadEntity(request); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	handler.GenFakeDataLogic(request, resp)

	Success(resp, res) //need to put framework, not rewrite in every implement.
}

func init() {
	//导出白名单
	RegistHandler("/whitelist/export", DeviceManagerApi.Export)
	//导入白名单
	RegistHandler("/whitelist/import", DeviceManagerApi.Import)
	//c2下载升级包
	RegistHandler("/c2/version/update", DeviceManagerApi.C2Update)
	//c2自研平板OTA升级
	RegistHandler("/c2/system/update", DeviceManagerApi.C2SystemUpdate)
	//设备列表
	RegistHandler("/device/list", DeviceManagerApi.List)
	RegistHandler("/device/add-simulate-device", DeviceManagerApi.AddSimulateDevice)
	RegistHandler("/device/start-udp-broadcast", DeviceManagerApi.StartUdpBroadCast) //前端不需要调用
	RegistHandler("/device/stop-udp-broadcast", DeviceManagerApi.StopUdpBroadCast)   //前端不需要调用
	RegistHandler("/device/confirm-device-conn", DeviceManagerApi.ConfirmDeviceConn) //前端不需要调用
	//c2获取license
	RegistHandler("/device/req/license", DeviceManagerApi.C2License) //前端未使用
	RegistHandler("/device/set-enable", DeviceManagerApi.SetEnable)
	//获取设备是否有侦测无人机数据
	RegistHandler("/device/data/schedule", DeviceManagerApi.GetReplayDataShedule)
}

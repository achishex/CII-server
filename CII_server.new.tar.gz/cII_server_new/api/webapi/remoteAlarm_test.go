package webapi

import (
	"context"
	"net/http"
	"net/http/httptest"
	"reflect"
	"strings"
	"testing"

	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/test"
	"github.com/agiledragon/gomonkey"
	"github.com/emicklei/go-restful"
	"github.com/stretchr/testify/assert"
)

func Test_alarmApi_Update(t *testing.T) {
	// Mock 日志
	test.LoggerMock()

	data := `{"id":12, "phone":"5000", "email":"13424"}`
	req := httptest.NewRequest(http.MethodPost, "/alarm/update", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	a := &handler.RemoteAlarm{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(a), "Update", func(_ *handler.RemoteAlarm, _ context.Context, req *client.AlarmCrudReq, res *client.AlarmCrudRes) error {
		return nil
	})

	defer patches.Reset()

	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		a    *alarmApi
		args args
	}{
		{
			name: "Case1",
			a:    &alarmApi{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			a := &alarmApi{}
			a.Update(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}

func Test_alarmApi_GetAlarm(t *testing.T) {
	// Mock 日志
	test.LoggerMock()

	data := `{"id":12, "phone":"5000", "email":"13424"}`
	req := httptest.NewRequest(http.MethodPost, "/alarm", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	a := &handler.RemoteAlarm{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(a), "GetAlarm", func(_ *handler.RemoteAlarm, _ context.Context, req *client.AlarmReq, res *client.AlarmRes) error {
		return nil
	})
	defer patches.Reset()

	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		a    *alarmApi
		args args
	}{
		{
			name: "Case1",
			a:    &alarmApi{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			a := &alarmApi{}
			a.GetAlarm(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}

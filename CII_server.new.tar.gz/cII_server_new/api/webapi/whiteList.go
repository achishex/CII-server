package webapi

import (
	"context"
	"fmt"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"github.com/emicklei/go-restful"

	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/logic/uploadcloud/down"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
)

type whitelistApi struct {
}

var (
	WhitelistApi = new(whitelistApi)
)

// swagger:route POST /whitelist/create whitelist commonReq
// Responses:
//
//	200: Response
func (w *whitelistApi) Insert(req *restful.Request, res *restful.Response) {
	whiteReq := &client.WhiteCrudReq{}
	whiteRsp := &client.WhiteCrudRes{}
	err := req.ReadEntity(whiteReq)
	if err != nil {
		logger.Errorf("bind create params[%v] error:%v", whiteReq, err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	//中程、近程雷视标定敌友军
	if whiteReq.DevType == common.DEV_SRP200 || whiteReq.DevType == int32(common.DEV_AGX) {
		logger.Debugf("srp200 insert white param:%v", whiteReq)
		//role 无人机角色： 1-敌军 2-友军 3-未知 4-中立
		if whiteReq.Role != handler.ENEMY && whiteReq.Role != handler.FRIEND {
			ParameterBindFail(400, "srp200 insert white param invalid", res)
			return
		}
		var typ int32
		if whiteReq.Role == handler.ENEMY {
			typ = handler.ENEMY_CALIBRATION
		}
		if whiteReq.Role == handler.FRIEND {
			typ = handler.FRIEND_CALIBRATION
		}
		if whiteReq.Id == 0 || whiteReq.DevSn == "" {
			ParameterBindFail(400, "srp200 insert white param invalid", res)
			return
		}

		agxSelectUavReq := &client.AgxSelectUavRequest{
			Sn:        whiteReq.DevSn,
			Type:      typ,
			ObjId:     whiteReq.Id,
			EquipType: whiteReq.DevType,
		}
		agxSelectUavResp := &client.AgxSelectUavResponse{}
		err := handler.NewDeviceCenter().AgxSelectUav(context.Background(), agxSelectUavReq, agxSelectUavResp)
		if err != nil {
			logger.Errorf("send srp200 calibration err:%v", err)
			ParameterBindFail(500, err.Error(), res)
			return
		}
		if agxSelectUavResp.Status != 0 {
			msg := fmt.Sprintf("send srp200 calibration err, got result:%v", agxSelectUavResp.Status)
			logger.Errorf(msg)
			ParameterBindFail(500, msg, res)
			return
		}
		Result(nil, res)
		return
	}
	down.GwhiteList = down.WhiteWebChange
	err = handler.NewWhiteList().Insert(context.Background(), whiteReq, whiteRsp)
	go handler.SendDevWhiteListToSfl()
	//发送白名单给tracer设备
	go handler.SendDevWhiteList()
	go handler.Sfl200SendDevWhiteList()
	Result(err, res)
}

// swagger:route POST /whitelist/update whitelist commonReq
// Responses:
//
//	200: Response
func (w *whitelistApi) Update(req *restful.Request, res *restful.Response) {
	whiteReq := &client.WhiteCrudReq{}
	whiteRsp := &client.WhiteCrudRes{}
	err := req.ReadEntity(whiteReq)
	if err != nil {
		logger.Errorf("bind update  params[%v] error:%v", whiteReq, err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	err = handler.NewWhiteList().Update(context.Background(), whiteReq, whiteRsp)
	down.GwhiteList = down.WhiteWebChange
	go handler.SendDevWhiteList()
	go handler.SendDevWhiteListToSfl()
	go handler.Sfl200SendDevWhiteList()
	Result(err, res)

}

// swagger:route POST /whitelist/delete whitelist deleteReq
// Responses:
//
//	200: Response
func (w *whitelistApi) Delete(req *restful.Request, res *restful.Response) {
	whiteReq := &client.WhiteDeleteReq{}
	whiteRsp := &client.WhiteCrudRes{}
	err := req.ReadEntity(whiteReq)
	if err != nil {
		logger.Errorf("bind delete params[%v] error:%v", whiteReq, err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	err = handler.NewWhiteList().Deletes(context.Background(), whiteReq, whiteRsp)
	down.GwhiteList = down.WhiteWebChange
	//发送白名单给tracer设备
	go handler.SendDevWhiteList()
	go handler.SendDevWhiteListToSfl()
	go handler.Sfl200SendDevWhiteList()
	Result(err, res)

}

// swagger:route POST /whitelist/list whitelist list
// Responses:
//
//	200: Response
func (w *whitelistApi) List(req *restful.Request, res *restful.Response) {
	whiteReq := &client.WhiteListReq{}
	whiteRsp := &client.WhiteListRes{}
	err := req.ReadEntity(whiteReq)
	if err != nil {
		logger.Errorf("bind list  params[%v] error:%v", whiteReq, err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	err = handler.NewWhiteList().List(context.Background(), whiteReq, whiteRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	go handler.SendDevWhiteListToSfl()
	//发送白名单给tracer设备
	go handler.SendDevWhiteList()
	//go handler.Sfl200SendDevWhiteList()
	Success(whiteRsp, res)
}

func init() {
	RegistHandler("/whitelist/create", WhitelistApi.Insert)
	RegistHandler("/whitelist/update", WhitelistApi.Update)
	RegistHandler("/whitelist/delete", WhitelistApi.Delete)
	RegistHandler("/whitelist/list", WhitelistApi.List)
}

package webapi

import (
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"github.com/emicklei/go-restful"
)

func GetDetectFreqNodeList(req *restful.Request, res *restful.Response) {

}

func (e *deviceManager) DevGetDetectFreqNodeList(req *restful.Request, res *restful.Response) {
	processDeviceManager[client.GetFreqListRequest, client.GetFreqListResponse](req, res, handler.NewDeviceCenter().GetDetectFreqNodeList)
}
func (e *deviceManager) DevSetFreqCmd(req *restful.Request, res *restful.Response) {
	processDeviceManager[client.DeviceSetFreqCmdRequest, client.DeviceSetFreqCmdResponse](req, res, handler.NewDeviceCenter().SetFreqCmd)
}
func (e *deviceManager) DevPerformanceEvaluate(req *restful.Request, res *restful.Response) {
	processDeviceManager[client.EnvBaseNoiseRequest, client.EnvBaseNoiseResponse](req, res, handler.NewDeviceCenter().PerformanceEvaluate)
}
func (e *deviceManager) DevPerformanceEvaluateSet(req *restful.Request, res *restful.Response) {
	processDeviceManager[client.PerformanceEvaluateReferenceRequest, client.PerformanceEvaluateReferenceResponse](req, res, handler.NewDeviceCenter().PerformanceEvaluateSet)
}

func (e *deviceManager) DevBoardFunctionStart(req *restful.Request, res *restful.Response) {
	processDeviceManager[client.StartSwitchOnRequestBatchReq, client.StartSwitchOnRequestBatchResponse](req, res, handler.NewDeviceCenter().BoardFunctionStart)
}

func init() {
	//所有设备-获取频点列表
	RegistHandler("/device/detect-freq-node-list", DeviceManagerApi.DevGetDetectFreqNodeList)
	// 所有设备-设置实时频谱图上报
	RegistHandler("/device/set-freq-cmd", DeviceManagerApi.DevSetFreqCmd)
	// 所有设备-侦测评估
	RegistHandler("/device/detect-performance-evaluate", DeviceManagerApi.DevPerformanceEvaluate)
	//设置评估参考值设置
	RegistHandler("/device/performance-evaluate/reference-set", DeviceManagerApi.DevPerformanceEvaluateSet)
	//面板公共开启，包括：设置时频图上报；侦测性能评估开启； 性能评估参考值设置
	RegistHandler("/device/board-function-start", DeviceManagerApi.DevBoardFunctionStart)
}

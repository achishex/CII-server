package webapi

import (
	"context"
	"net/http"
	"net/http/httptest"
	"reflect"
	"strings"
	"testing"

	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/test"
	"github.com/agiledragon/gomonkey"
	"github.com/emicklei/go-restful"
	"github.com/stretchr/testify/assert"
	"google.golang.org/protobuf/types/known/emptypb"
)

func Test_emailApi_Send(t *testing.T) {
	// Mock 日志
	test.LoggerMock()

	data := `{"email":"12345678", "numberType":1}`
	req := httptest.NewRequest(http.MethodPost, "/email/send", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	s := &handler.Email{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(s), "Send", func(_ *handler.Email, _ context.Context, req *client.SendReq, resp *client.SendRes) error {
		return nil
	})
	defer patches.Reset()

	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		s    *emailApi
		args args
	}{
		{
			name: "Case1",
			s:    &emailApi{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			s := &emailApi{}
			s.Send(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}

func Test_emailApi_Verify(t *testing.T) {
	// Mock 日志
	test.LoggerMock()

	data := `{"email":"12345678", "code":"sdf"}`
	req := httptest.NewRequest(http.MethodPost, "/email/verify", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	s := &handler.Email{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(s), "Verify", func(_ *handler.Email, _ context.Context, req *client.VerifyReq, resp *emptypb.Empty) error {
		return nil
	})
	defer patches.Reset()

	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		s    *emailApi
		args args
	}{
		{
			name: "Case1",
			s:    &emailApi{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			s := &emailApi{}
			s.Verify(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}

func Test_emailApi_Notify(t *testing.T) {
	// Mock 日志
	test.LoggerMock()

	data := `{"email":"12345678", "code":"sdf"}`
	req := httptest.NewRequest(http.MethodPost, "/email/notify", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	s := &handler.Email{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(s), "Notify", func(_ *handler.Email, _ context.Context, req *client.NotifyReq, resp *client.SendRes) error {
		return nil
	})
	defer patches.Reset()

	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		s    *emailApi
		args args
	}{
		{
			name: "Case1",
			s:    &emailApi{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			s := &emailApi{}
			s.Notify(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}

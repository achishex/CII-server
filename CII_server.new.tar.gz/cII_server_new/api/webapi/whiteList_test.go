package webapi

import (
	"context"
	"net/http"
	"net/http/httptest"
	"reflect"
	"strings"
	"testing"

	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/test"
	"github.com/agiledragon/gomonkey"
	"github.com/emicklei/go-restful"
	"github.com/stretchr/testify/assert"
)

func Test_whitelistApi_Insert(t *testing.T) {
	// Mock 日志
	test.LoggerMock()

	data := `{"id":12, "frequency":"5000", "sn":"13424"}`
	req := httptest.NewRequest(http.MethodPost, "/whitelist/create", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	a := &handler.Whites{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(a), "Insert", func(_ *handler.Whites, _ context.Context, req *client.WhiteCrudReq, res *client.WhiteCrudRes) error {
		return nil
	})
	defer patches.Reset()

	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		w    *whitelistApi
		args args
	}{
		{
			name: "Case1",
			w:    &whitelistApi{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			//w := &whitelistApi{}
			//w.Insert(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}

func Test_whitelistApi_Update(t *testing.T) {
	// Mock 日志
	test.LoggerMock()

	data := `{"id":12, "frequency":"5000", "sn":"13424"}`
	req := httptest.NewRequest(http.MethodPost, "/whitelist/update", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	a := &handler.Whites{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(a), "Update", func(_ *handler.Whites, _ context.Context, req *client.WhiteCrudReq, res *client.WhiteCrudRes) error {
		return nil
	})
	defer patches.Reset()

	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		w    *whitelistApi
		args args
	}{
		{
			name: "Case1",
			w:    &whitelistApi{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			//w := &whitelistApi{}
			//w.Update(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}

func Test_whitelistApi_Delete(t *testing.T) {
	// Mock 日志
	test.LoggerMock()

	data := `{"id":12, "frequency":"5000", "sn":"13424"}`
	req := httptest.NewRequest(http.MethodPost, "/whitelist/delete", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	a := &handler.Whites{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(a), "Deletes", func(_ *handler.Whites, _ context.Context, req *client.WhiteDeleteReq, res *client.WhiteCrudRes) error {
		return nil
	})
	defer patches.Reset()

	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		w    *whitelistApi
		args args
	}{
		{
			name: "Case1",
			w:    &whitelistApi{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			//w := &whitelistApi{}
			//w.Delete(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}

func Test_whitelistApi_List(t *testing.T) {
	// Mock 日志
	test.LoggerMock()

	data := `{"id":12, "frequency":"5000", "sn":"13424"}`
	req := httptest.NewRequest(http.MethodPost, "/whitelist/list", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	a := &handler.Whites{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(a), "List", func(_ *handler.Whites, _ context.Context, req *client.WhiteListReq, res *client.WhiteListRes) error {
		return nil
	})
	defer patches.Reset()

	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		w    *whitelistApi
		args args
	}{
		{
			name: "Case1",
			w:    &whitelistApi{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			w := &whitelistApi{}
			w.List(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}

package webapi

import (
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"context"
	"github.com/emicklei/go-restful"
)

// StartStopHit 开始停止打击
func (e *deviceManager) StartStopHit(req *restful.Request, res *restful.Response) {
	deviceReq := &client.StartStopHitRequest{}
	deviceRsp := &client.StartStopHitResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SvhStartStopHit(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// GetFreqConfig 获取外挂打击模块打击频段参数
func (e *deviceManager) GetFreqConfig(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SvhGetFreqConfigRequest{}
	deviceRsp := &client.SvhGetFreqConfigResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SvhGetFreqConfig(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// SetFreqConfig 设置外挂打击模块打击频段参数
func (e *deviceManager) SetFreqConfig(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SvhSetFreqConfigRequest{}
	deviceRsp := &client.SvhSetFreqConfigResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SvhSetFreqConfig(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// AddDelFreqConfig 增加/删除打击频段参数
func (e *deviceManager) AddDelFreqConfig(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SvhAddDelFreqConfigRequest{}
	deviceRsp := &client.SvhAddDelFreqConfigResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SvhAddDelFreqConfig(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// ResetFreqConfig 恢复出厂默认打击频段参数
func (e *deviceManager) ResetFreqConfig(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SvhResetFreqConfigRequest{}
	deviceRsp := &client.SvhResetFreqConfigResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SvhResetFreqConfig(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// SvhGetVersionInfo SVH设备获取版本号
func (e *deviceManager) SvhGetVersionInfo(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SvhGetVersionRequest{}
	deviceRsp := &client.SvhGetVersionResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SvhGetVersionInfo(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

func init() {
	//开始停止打击
	RegistHandler("/device/svh/start-stop-hit", DeviceManagerApi.StartStopHit)
	//获取外挂打击模块打击频段参数
	RegistHandler("/device/svh/get-freq-config", DeviceManagerApi.GetFreqConfig)
	//设置外挂打击模块打击频段参数
	RegistHandler("/device/svh/set-freq-config", DeviceManagerApi.SetFreqConfig)
	//增加/删除打击频段参数
	RegistHandler("/device/svh/add-del-freq-config", DeviceManagerApi.AddDelFreqConfig)
	//恢复出厂默认打击频段参数
	RegistHandler("/device/svh/reset-freq-config", DeviceManagerApi.ResetFreqConfig)
	//获取版本号
	RegistHandler("/device/svh/get-version-info", DeviceManagerApi.SvhGetVersionInfo)
}

package webapi

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"context"
	"github.com/emicklei/go-restful"
)

// SetDeviceManagerParams 请求公共处理接口
func processDeviceManager[REQ any, RSP any](req *restful.Request, res *restful.Response, ReqProcess func(ctx context.Context, in *REQ, out *RSP) error) {
	reqData, respData := new(REQ), new(RSP)

	if err := req.ReadEntity(reqData); err != nil {
		logger.Errorf("set param fail, err:%v", err)
		ParameterBindFail(400, err.Error(), res)
		return
	}
	logger.Infof("reqData: %+v", *reqData)

	if err := ReqProcess(context.Background(), reqData, respData); err != nil {
		logger.Errorf("err:%v", err)
		CustomFail(500, err.Error(), res)
	}
	Success(respData, res)
}

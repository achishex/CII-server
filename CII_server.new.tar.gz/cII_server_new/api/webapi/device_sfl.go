package webapi

import (
	"context"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"github.com/emicklei/go-restful"

	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
)

// SflGetVersionInfo 获取版本号
func (e *deviceManager) SflGetVersionInfo(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflGetVersionRequest{}
	deviceRsp := &client.SflGetVersionResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SflGetVersionInfo(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}

	Success(deviceRsp, res)
}

// SflStopHit 发送停止打击
func (e *deviceManager) SflStopHit(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflStopHitRequest{}
	deviceRsp := &client.SflStopHitResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SflStopHitSet(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// SflSetGNSS ...
func (e *deviceManager) SflSetGNSS(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflSetGNSSRequest{}
	deviceRsp := &client.SflSetGNSSResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	logger.Debug("SflSetGNSS ------- req ", deviceReq)
	err := handler.NewDeviceCenter().SflGNSSSet(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	logger.Debug("SflSetGNSS ------- deviceRsp", deviceRsp)
	Success(deviceRsp, res)
}

// SflGetGNSS ...
func (e *deviceManager) SflGetGNSS(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflGetGNSSRequest{}
	deviceRsp := &client.SflGetGNSSResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	logger.Debug("SflGetGNSS ------- deviceReq ", deviceReq)
	err := handler.NewDeviceCenter().SflGNSSGet(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	logger.Debug("SflGetGNSS deviceRsp ----  ", deviceRsp)
	Success(deviceRsp, res)
}

// SflHitAngle 发送打击点信息配置
func (e *deviceManager) SflHitAngle(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflHitAngleRequest{}
	deviceRsp := &client.SflHitAngleResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SflHitAngleSet(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// SflOnOff 发送开关机指令
func (e *deviceManager) SflOnOff(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflOnOffRequest{}
	deviceRsp := &client.SflOnOffResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SflOnOffSet(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// SflResetting 发送一键复位指令
func (e *deviceManager) SflResetting(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflResetRequest{}
	deviceRsp := &client.SflResetResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SflReSet(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// SflGetStatus 发送获取角度、工作模式、打击时长、打击范围
func (e *deviceManager) SflGetStatus(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflGetStatusRequest{}
	deviceRsp := &client.SflGetStatusResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SflGetStatus(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// SflGetPower 发送获取开关机指令
func (e *deviceManager) SflGetPower(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflGetPowerRequest{}
	deviceRsp := &client.SflGetPowerResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SflGetPower(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// SflDetectInfo 发送获取侦测信息
func (e *deviceManager) SflDetectInfo(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflDetectInfoRequest{}
	deviceRsp := &client.SflDetectInfoResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SflDetectInfo(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// SflDetectInfoExport 发送侦测信息导出
func (e *deviceManager) SflDetectInfoExport(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflDetectInfoExportRequest{}
	deviceRsp := &client.SflDetectInfoExportResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SflDetectInfoExport(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// SflHitUav 发送选中无人机打击
func (e *deviceManager) SflHitUav(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflSendHitUavRequest{}
	deviceRsp := &client.SflSendHitUavResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SflSendHitUav(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// SflSetHitMode 发送设置工作模式：手动、自动
func (e *deviceManager) SflSetHitMode(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflSetHitModeRequest{}
	deviceRsp := &client.SflSetHitModeResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SflSetHitMode(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// SflGetHitMode 发送获取工作模式：手动、自动
func (e *deviceManager) SflGetHitMode(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflGetHitModeRequest{}
	deviceRsp := &client.SflGetHitModeResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SflGetHitMode(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// 启动/停止打击
func (e *deviceManager) SflTurnHit(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflTurnHitRequest{}
	deviceRsp := &client.SflTurnHitResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SflTurnHit(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// 水平方向转动
func (e *deviceManager) SflHorizontalTurn(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflHorizontalTurnRequest{}
	deviceRsp := &client.SflHorizontalTurnResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SflHorizontalTurn(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// 垂直方向转动
func (e *deviceManager) SflVerticalTurn(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflVerticalTurnRequest{}
	deviceRsp := &client.SflVerticalTurnResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SflVerticalTurn(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// SflHitMode 发送打击模式配置
func (e *deviceManager) SflHitMode(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflHitModeRequest{}
	deviceRsp := &client.SflHitModeResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SflHitModeSet(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// SflCrashStop 哨兵塔急停
func (e *deviceManager) SflCrashStop(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflCrashStopRequest{}
	deviceRsp := &client.SflCrashStopResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SflCrashStop(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// SflSetNoise 设置底噪采集
func (e *deviceManager) SflSetNoise(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflSetNoiseRequest{}
	deviceRsp := &client.SflSetNoiseResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SflSetNoise(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// SflGetFreqNodeList 获取频点列表
func (e *deviceManager) SflGetFreqNodeList(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflGetFreqListRequest{}
	deviceRsp := &client.SflGetFreqListResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SflGetFreqNodeList(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// SflSetFreqCmd 下发时频图采集指令
func (e *deviceManager) SflSetFreqCmd(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflSetFreqCmdRequest{}
	deviceRsp := &client.SflSetFreqCmdResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SflSetFreqCmd(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// SflSetPreciseHit 设置精准打击特性
func (e *deviceManager) SflSetPreciseHit(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflSetPreciseHitRequest{}
	deviceRsp := &client.SflSetPreciseHitResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SflSetPreciseHit(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// SflGetPreciseHit 获取精准打击特性
func (e *deviceManager) SflGetPreciseHit(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflGetPreciseHitRequest{}
	deviceRsp := &client.SflGetPreciseHitResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SflGetPreciseHit(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// SflSetInvalidFreq 设置无效无人机频点
func (e *deviceManager) SflSetInvalidFreq(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflSetInvalidFreqRequest{}
	deviceRsp := &client.SflSetInvalidFreqResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SflSetInvalidFreq(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// SflGetInvalidFreq 获取无效无人机频点
func (e *deviceManager) SflGetInvalidFreq(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflGetInvalidFreqRequest{}
	deviceRsp := &client.SflGetInvalidFreqResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SflGetInvalidFreq(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// SflSetHitRadius 设置自动打击的半径
func (e *deviceManager) SflSetHitRadius(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflSetAutoHitRadiusRequest{}
	deviceRsp := &client.SflSetAutoHitRadiusResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SflSetHitRadius(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// SflGetHitRadius 获取自动打击的半径
func (e *deviceManager) SflGetHitRadius(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflGetAutoHitRadiusRequest{}
	deviceRsp := &client.SflGetAutoHitRadiusResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SflGetHitRadius(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// SflSetSwitchParameter 设置开关参数
func (e *deviceManager) SflSetSwitchParameter(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflSetSwitchParameterRequest{}
	deviceRsp := &client.SflSetSwitchParameterResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SflSetSwitchParameter(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// SflGetSwitchParameter 获取开关参数
func (e *deviceManager) SflGetSwitchParameter(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflGetSwitchParameterRequest{}
	deviceRsp := &client.SflGetSwitchParameterResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SflGetSwitchParameter(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// SflSetPosture 设置标定设备姿态
func (e *deviceManager) SflSetPosture(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflSetPostureRequest{}
	deviceRsp := &client.SflSetPostureResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SflSetPosture(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// SflGetPosture 获取标定设备姿态
func (e *deviceManager) SflGetPosture(req *restful.Request, res *restful.Response) {
	deviceReq := &client.SflGetPostureRequest{}
	deviceRsp := &client.SflGetPostureResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().SflGetPosture(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

func init() {
	RegistHandler("/device/sfl/get-version-info", DeviceManagerApi.SflGetVersionInfo)
	//停止当前打击
	RegistHandler("/device/sfl/stop-hit", DeviceManagerApi.SflStopHit)
	//设置打击参数信息
	RegistHandler("/device/sfl/hit-angle", DeviceManagerApi.SflHitAngle)
	//开机、关机
	RegistHandler("/device/sfl/on-off", DeviceManagerApi.SflOnOff)
	//一键云台复位
	RegistHandler("/device/sfl/resetting", DeviceManagerApi.SflResetting)
	//侦测看板
	RegistHandler("/device/sfl/detect-info", DeviceManagerApi.SflDetectInfo)
	//导出侦测看板
	RegistHandler("/device/sfl/detect-info-export", DeviceManagerApi.SflDetectInfoExport)
	//选中无人机手动打击
	RegistHandler("/device/sfl/hit-uav", DeviceManagerApi.SflHitUav)
	//获取设备状态
	RegistHandler("/device/sfl/get-status", DeviceManagerApi.SflGetStatus)
	//获取开关机状态
	RegistHandler("/device/sfl/get-onoff", DeviceManagerApi.SflGetPower)

	//设置是否自动打击
	RegistHandler("/device/sfl/set-hit-mode", DeviceManagerApi.SflSetHitMode)
	//获取是否自动打击
	RegistHandler("/device/sfl/get-hit-mode", DeviceManagerApi.SflGetHitMode)

	//获取设备GNSS位置
	RegistHandler("/device/sfl/setGNSS", DeviceManagerApi.SflSetGNSS)
	//设置设备GNSS位置
	RegistHandler("/device/sfl/getGNSS", DeviceManagerApi.SflGetGNSS)

	//启动/停止打击
	RegistHandler("/device/sfl/turn-hit", DeviceManagerApi.SflTurnHit)
	//水平方向转动
	RegistHandler("/device/sfl/horizontal-turn", DeviceManagerApi.SflHorizontalTurn)
	//垂直方向转动
	RegistHandler("/device/sfl/vertical-turn", DeviceManagerApi.SflVerticalTurn)
	//设置打击模式
	RegistHandler("/device/sfl/hit-mode-set", DeviceManagerApi.SflHitMode)
	//哨兵塔急停
	RegistHandler("/device/sfl/crash-stop", DeviceManagerApi.SflCrashStop)

	//设置底噪采集
	RegistHandler("/device/sfl/set-noise", DeviceManagerApi.SflSetNoise)
	//获取频点列表
	RegistHandler("/device/sfl/detect-freq-node-list", DeviceManagerApi.SflGetFreqNodeList)

	//时频图采集指令 D1
	RegistHandler("/device/sfl/set-freq-cmd", DeviceManagerApi.SflSetFreqCmd)

	//设置精准打击特性
	RegistHandler("/device/sfl/set-precise", DeviceManagerApi.SflSetPreciseHit)
	//获取精准打击特性
	RegistHandler("/device/sfl/get-precise", DeviceManagerApi.SflGetPreciseHit)

	//设置无效无人机频点
	RegistHandler("/device/sfl/set-invalid-freq", DeviceManagerApi.SflSetInvalidFreq)
	//获取无效无人机频点
	RegistHandler("/device/sfl/get-invalid-freq", DeviceManagerApi.SflGetInvalidFreq)

	//设置自动打击的半径
	RegistHandler("/device/sfl/set-hit-radius", DeviceManagerApi.SflSetHitRadius)
	//获取自动打击的半径
	RegistHandler("/device/sfl/get-hit-radius", DeviceManagerApi.SflGetHitRadius)

	//设置开关参数
	RegistHandler("/device/sfl/set-switch-parameter", DeviceManagerApi.SflSetSwitchParameter)
	//获取开关参数
	RegistHandler("/device/sfl/get-switch-parameter", DeviceManagerApi.SflGetSwitchParameter)

	//设置标定设备姿态
	RegistHandler("/device/sfl/set-posture", DeviceManagerApi.SflSetPosture)
	//获取标定设备姿态
	RegistHandler("/device/sfl/get-posture", DeviceManagerApi.SflGetPosture)
}

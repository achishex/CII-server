package webapi

import (
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"context"
	"github.com/emicklei/go-restful"
)

// TracerGunGetFreqList 获取频点列表
func (e *deviceManager) TracerGunGetFreqList(req *restful.Request, res *restful.Response) {
	deviceReq := &client.TracerGunGetFreqListRequest{}
	deviceRsp := &client.TracerGunGetFreqListResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().TracerGunGetFreqList(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// TracerGunSetFreqList 设置频点列表
func (e *deviceManager) TracerGunSetFreqList(req *restful.Request, res *restful.Response) {
	deviceReq := &client.TracerGunSetFreqListRequest{}
	deviceRsp := &client.TracerGunSetFreqListResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().TracerGunSetFreqList(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// TracerGunResetFreqList 初始化频点列表
func (e *deviceManager) TracerGunResetFreqList(req *restful.Request, res *restful.Response) {
	deviceReq := &client.TracerGunResetFreqListRequest{}
	deviceRsp := &client.TracerGunResetFreqListResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().TracerGunResetFreqList(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

func (e *deviceManager) TracerGunGetInfo(req *restful.Request, res *restful.Response) {
	deviceReq := &client.TracerGunGetInfoRequest{}
	deviceRsp := &client.TracerGunGetInfoResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err := handler.NewDeviceCenter().TraceGunGetInfo(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		CustomFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}
func (e *deviceManager) TracerGunAddDelFreqParams(req *restful.Request, res *restful.Response) {
	deviceReq := &client.TracerGunAddDelFreqRequest{}
	deviceRsp := &client.TracerGunAddDelFreqResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().TracerGunDelAddFreqList(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// TracerGunSetJamStatus 设置打击模式
func (e *deviceManager) TracerGunSetJamStatus(req *restful.Request, res *restful.Response) {
	deviceReq := &client.TracerGunSetJamStatusRequest{}
	deviceRsp := &client.TracerGunSetJamStatusResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().TracerGunSetJamStatus(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// TracerGunGetJamStatus 获取打击模式
func (e *deviceManager) TracerGunGetJamStatus(req *restful.Request, res *restful.Response) {
	deviceReq := &client.TracerGunGetJamStatusRequest{}
	deviceRsp := &client.TracerGunGetJamStatusResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().TracerGunGetJamStatus(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

func init() {
	// TracerGunGetFreqList 获取频点列表
	RegistHandler("/device/tracer-gun/get-freq-list", DeviceManagerApi.TracerGunGetFreqList)
	// TracerGunSetFreqList 设置频点列表
	RegistHandler("/device/tracer-gun/set-freq-list", DeviceManagerApi.TracerGunSetFreqList)
	// TracerGunResetFreqList 初始化频点列表
	RegistHandler("/device/tracer-gun/reset-freq-list", DeviceManagerApi.TracerGunResetFreqList)
	//TracerGunSetJamStatus 设置打击模式
	RegistHandler("/device/tracer-gun/set-jam-status", DeviceManagerApi.TracerGunSetJamStatus)
	// TracerGunGetJamStatus 获取打击模式
	RegistHandler("/device/tracer-gun/get-jam-status", DeviceManagerApi.TracerGunGetJamStatus)
	// TracerGunAddDelFreqParams 增加/删除打击频段参数
	RegistHandler("/device/tracer-gun/add-del-freq-param", DeviceManagerApi.TracerGunAddDelFreqParams)
	//TracerGunGetInfo 获取配置参数
	RegistHandler("/device/tracer-gun/info", DeviceManagerApi.TracerGunGetInfo)
}

package webapi

import (
	"context"
	"net/http"
	"net/http/httptest"
	"reflect"
	"strings"
	"testing"

	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/test"
	"github.com/agiledragon/gomonkey"
	"github.com/emicklei/go-restful"
	"github.com/stretchr/testify/assert"
)

func Test_smsApi_Send(t *testing.T) {
	// Mock 日志
	test.LoggerMock()

	data := `{"phone":"12345678", "numberType":1}`
	req := httptest.NewRequest(http.MethodPost, "/sms/send", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	s := &handler.Sms{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(s), "Send", func(_ *handler.Sms, _ context.Context, _ *client.SmsSendReq, _ *client.SmsSendRes) error {
		return nil
	})
	defer patches.Reset()

	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		s    *smsApi
		args args
	}{
		{
			name: "Case1",
			s:    &smsApi{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			s := &smsApi{}
			s.Send(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}

func Test_smsApi_Verify(t *testing.T) {
	// Mock 日志
	test.LoggerMock()

	data := `{"phone":"12345678", "numberType":1}`
	req := httptest.NewRequest(http.MethodPost, "/sms/verify", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	s := &handler.Sms{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(s), "CheckVerificationCode", func(_ *handler.Sms, _ context.Context, req *client.CheckReq, resp *client.CheckRes) error {
		return nil
	})
	defer patches.Reset()

	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		s    *smsApi
		args args
	}{
		{
			name: "Case1",
			s:    &smsApi{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			s := &smsApi{}
			s.Verify(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}

func Test_smsApi_Notify(t *testing.T) {
	// Mock 日志
	test.LoggerMock()

	data := `{"phone":"3445436", "templateType":1}`
	req := httptest.NewRequest(http.MethodPost, "/sms/notify", strings.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	rsp := httptest.NewRecorder()

	s := &handler.Sms{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(s), "Notify", func(_ *handler.Sms, _ context.Context, req *client.SmsNotifyReq, resp *client.SmsSendRes) error {
		return nil
	})
	defer patches.Reset()

	type args struct {
		req *restful.Request
		res *restful.Response
	}
	tests := []struct {
		name string
		s    *smsApi
		args args
	}{
		{
			name: "Case1",
			s:    &smsApi{},
			args: args{
				req: restful.NewRequest(req),
				res: restful.NewResponse(rsp),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			s := &smsApi{}
			s.Notify(tt.args.req, tt.args.res)
			assert.Equal(t, http.StatusOK, tt.args.res.StatusCode())
		})
	}
}

package webapi

import (
	"context"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"github.com/emicklei/go-restful"
)

type dataReplayOps struct {
}

var (
	DataReplayOpsApi = new(dataReplayOps)
)

// GetReplayData 获取设备一段时间的无人机数据
func (e *dataReplayOps) GetReplayData(req *restful.Request, res *restful.Response) {
	deviceReq := &client.GetReplayDataRequest{}
	deviceRsp := &client.GetReplayDataResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err := handler.NewDeviceCenter().GetReplayData(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		CustomFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// DataMarkers 时间标记接口
func (e *dataReplayOps) DataMarkers(req *restful.Request, res *restful.Response) {
	deviceReq := &client.DataMarkersRequest{}
	deviceRsp := &client.DataMarkersResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err := handler.NewDeviceCenter().DataMarkers(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		CustomFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}
func (e *dataReplayOps) GetDeviceListByTime(req *restful.Request, res *restful.Response) {
	deviceReq := &client.ReplayDeviceListRequest{}
	deviceRsp := &client.ReplayDeviceListResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err := handler.NewDeviceCenter().GetDeviceTypeList(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		CustomFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res) //need to put framework, not rewrite in every implement.
}

// GetVaulidTime  获取设备是否有有价值的数据，用于前端画出有价值的进度条
func (e *dataReplayOps) GetVaulidTime(req *restful.Request, res *restful.Response) {
	request := &client.DeviceDetailListReq{}
	resp := &client.DeviceDetailListResp{}
	if err := req.ReadEntity(request); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err := handler.NewDeviceCenter().DeviceDetailList(context.Background(), request, resp)
	if err != nil {
		CustomFail(500, err.Error(), res)
		return
	}
	Success(resp, res) //need to put framework, not rewrite in every implement.
}

// GenFakeData  开始生成模拟数据
func (e *dataReplayOps) GenFakeData(req *restful.Request, res *restful.Response) {
	request := &client.GenFakeReq{}
	resp := &client.GenFakeDataResp{}
	if err := req.ReadEntity(request); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	handler.GenFakeDataLogic(request, resp)

	Success(resp, res) //need to put framework, not rewrite in every implement.
}

// ReplayStartOrStop 开始或停止数据回放
func (e *dataReplayOps) ReplayStartOrStop(req *restful.Request, res *restful.Response) {
	inReq := new(client.ReplayDeviceStartStopRequest)
	inResp := new(client.ReplayDeviceOpResponse)

	if e := req.ReadEntity(inReq); e != nil {
		ParameterBindFail(400, e.Error(), res)
		return
	}

	logger.Infof("replay req msg: %+v", inReq.String())

	handler.GetBusinessTaskProc(inReq.GetOps()).Call(inReq, inResp)

	logger.Infof("replay response msg: %+v", inResp)

	inResp.Ops = inReq.Ops
	Success(inResp, res) //need to put framework, not rewrite in every implement.
}

// ReplayPauseOrRestart 暂停或者重启数据回放
func (e *dataReplayOps) ReplayPauseOrRestart(req *restful.Request, res *restful.Response) {
	inReq := new(client.ReplayDevicePauseOpRequest)
	inResp := new(client.ReplayDevicePauseOpResponse)

	if e := req.ReadEntity(inReq); e != nil {
		ParameterBindFail(400, e.Error(), res)
		return
	}
	logger.Infof("pause req msg: %+v", inReq)
	handler.GetReplayControlHandler(inReq.GetOps()).Control(inResp)
	logger.Infof("pause response msg: %+v", inResp)

	inResp.Ops = inReq.Ops
	Success(inResp, res) //need to put framework, not rewrite in every implement.
}

func (e *dataReplayOps) DateMarkerDateTime(req *restful.Request, res *restful.Response) {
	deviceRsp := &client.DateMarkerAllResponse{}
	err := handler.NewDeviceCenter().QueryDateMarkersAllTime(context.Background(), deviceRsp)
	logger.Infof("marker date time response: %+v", deviceRsp)

	if err != nil {
		CustomFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

func init() {
	//根据时间范围查找监测设备类型
	RegistHandler("/device/replay/list", DataReplayOpsApi.GetDeviceListByTime)
	//2.获取设备信息接口
	RegistHandler("/device/replay/validtime", DataReplayOpsApi.GetVaulidTime)
	//数据回放，生成假数据接口
	//RegistHandler("/device/replay/genfakedata", DataReplayOpsApi.GenFakeData)
	//数据回放数据
	RegistHandler("/device/data/replay", DataReplayOpsApi.GetReplayData)
	//时间标记接口
	RegistHandler("/device/data/markers", DataReplayOpsApi.DataMarkers)

	//回放数据接口: 开始/结束
	RegistHandler("/data/replay/start_stop", DataReplayOpsApi.ReplayStartOrStop)
	//回放数据几口：暂停、重开
	RegistHandler("/data/replay/pause_restart", DataReplayOpsApi.ReplayPauseOrRestart)
	//取dateMarker日期
	RegistHandler("/data/replay/datemarker_datetime", DataReplayOpsApi.DateMarkerDateTime)
}

package webapi

import (
	"context"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"github.com/emicklei/go-restful"
)

type statisticApi struct {
}

var (
	StatisticApi = new(statisticApi)
)

// Responses:
//
//	200: Response
//
//swagger:route POST /statistic/list statistic event
func (s *statisticApi) EventList(req *restful.Request, res *restful.Response) {
	staticReq := &client.EventReq{}
	staticRsp := &client.EventRsp{}
	err := req.ReadEntity(staticReq)
	if err != nil {
		logger.Errorf("parse statistic event list params[%v] error:%v", staticReq, err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	err = handler.NewStatistics().EventList(context.Background(), staticReq, staticRsp)
	ResultList(err, res, staticRsp)

}

func (s *statisticApi) QueryDataBySql(req *restful.Request, res *restful.Response) {
	staticReq := &client.QueryBySqlRequest{}
	staticRsp := &client.QueryBySqlResponse{}
	err := req.ReadEntity(staticReq)
	if err != nil {
		logger.Errorf("parse QueryDataBySql event list params[%v] error:%v", staticReq, err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	err = handler.NewStatistics().QueryBySql(context.Background(), staticReq, staticRsp)
	ResultList(err, res, staticRsp)
}

// Schedule 定时数据统计
func (s *statisticApi) Schedule(req *restful.Request, res *restful.Response) {
	staticReq := &client.CollectReq{}
	staticRsp := &client.CollectRes{}
	err := req.ReadEntity(staticReq)
	if err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err = handler.NewStatistics().EventCollect(context.Background(), staticReq, staticRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
	}
	Success(staticRsp, res)

}

func init() {
	RegistHandler("/statistic/list", StatisticApi.EventList)               //给前端返回数据的接口
	RegistHandler("/statistic/query-db-data", StatisticApi.QueryDataBySql) //暗门查数据库的接口
	RegistHandler("/statistic/schedule", StatisticApi.Schedule)            //后端启动  定时分析
}

package webapi

import (
	"context"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"github.com/emicklei/go-restful"
)

type alarmApi struct {
}

var (
	AlarmApi = new(alarmApi)
)

// Responses:
//
//	200: Response
//
//swagger:route POST /alarm/update alarm commonAlarm
func (a *alarmApi) Update(req *restful.Request, res *restful.Response) {
	alarmReq := &client.AlarmCrudReq{}
	alarmRsp := &client.AlarmCrudRes{}
	err := req.ReadEntity(alarmReq)
	if err != nil {
		logger.Errorf("update remote alarm param[%v] error:%v", alarmReq, err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	err = handler.NewRemoteAlarm().Update(context.Background(), alarmReq, alarmRsp)
	Result(err, res)
}

// Responses:
//
//	200: Response
//
//swagger:route POST /alarm alarm alarm
func (a *alarmApi) GetAlarm(req *restful.Request, res *restful.Response) {
	alarmReq := &client.AlarmReq{}
	alarmRsp := &client.AlarmRes{}
	err := handler.NewRemoteAlarm().GetAlarm(context.Background(), alarmReq, alarmRsp)
	if err != nil {
		logger.Errorf("query error:%v", err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(alarmRsp, res)
}

func init() {
	RegistHandler("/alarm/update", AlarmApi.Update)
	RegistHandler("/alarm", AlarmApi.GetAlarm)
}

package webapi

import (
	"context"

	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"github.com/emicklei/go-restful"
)

// FpvSendSetHitMode 发送设置打击模式
func (e *deviceManager) FpvSendSetHitMode(req *restful.Request, res *restful.Response) {
	deviceReq := &client.FpvSendSetHitModeRequest{}
	deviceRsp := &client.FpvSendSetHitModeResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().FpvSendSetHitMode(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// FpvSendGetHitMode 获取打击模式
func (e *deviceManager) FpvSendGetHitMode(req *restful.Request, res *restful.Response) {
	deviceReq := &client.FpvSendGetHitModeRequest{}
	deviceRsp := &client.FpvSendGetHitModeResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().FpvSendGetHitMode(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// FpvSendHitUav 发送打击指令
func (e *deviceManager) FpvSendHitUav(req *restful.Request, res *restful.Response) {
	deviceReq := &client.FpvSendHitRequest{}
	deviceRsp := &client.FpvSendHitResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().FpvSendHitUav(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// FpvSendStopHit 停止打击指令
func (e *deviceManager) FpvSendStopHit(req *restful.Request, res *restful.Response) {
	deviceReq := &client.FpvSendStopHitRequest{}
	deviceRsp := &client.FpvSendStopHitResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().FpvSendStopHit(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// FpvSendSetHitTime 设置打击时长
func (e *deviceManager) FpvSendSetHitTime(req *restful.Request, res *restful.Response) {
	deviceReq := &client.FpvSendSetHitTimeRequest{}
	deviceRsp := &client.FpvSendSetHitTimeResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().FpvSendSetHitTime(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// FpvSendGetHitTime 获取打击时长
func (e *deviceManager) FpvSendGetHitTime(req *restful.Request, res *restful.Response) {
	deviceReq := &client.FpvSendGetHitTimeRequest{}
	deviceRsp := &client.FpvSendGetHitTimeResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().FpvSendGetHitTime(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// FpvCli 向Fpv发送cmd
func (e *deviceManager) FpvCli(req *restful.Request, res *restful.Response) {
	deviceReq := &client.FpvCliRequest{}
	deviceRsp := &client.FpvCliResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().FpvCli(context.TODO(), deviceReq, deviceRsp)
	if err != nil {
		CustomFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// FpvGetVersionInfo 获取Fpv版本号
func (e *deviceManager) FpvGetVersionInfo(req *restful.Request, res *restful.Response) {
	deviceReq := &client.FpvSendGetVersionRequest{}
	deviceRsp := &client.FpvSendGetVersionResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().FpvSendGetVersion(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}
func (e *deviceManager) FpvVideoControl(req *restful.Request, res *restful.Response) {
	deviceReq := &client.FpvVideoControlReq{}
	deviceRsp := &client.FpvVideoControlResp{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	handler.NewDeviceCenter().FpvVideoControl(context.Background(), deviceReq, deviceRsp)
	Success(deviceRsp, res)
}

func init() {
	RegistHandler("/device/fpv/get-version-info", DeviceManagerApi.FpvGetVersionInfo)
	RegistHandler("/device/fpv/set-hit-mode", DeviceManagerApi.FpvSendSetHitMode)
	RegistHandler("/device/fpv/get-hit-mode", DeviceManagerApi.FpvSendGetHitMode)

	RegistHandler("/device/fpv/send-hit", DeviceManagerApi.FpvSendHitUav)
	RegistHandler("/device/fpv/stop-hit", DeviceManagerApi.FpvSendStopHit)

	RegistHandler("/device/fpv/set-hit-time", DeviceManagerApi.FpvSendSetHitTime)
	RegistHandler("/device/fpv/get-hit-time", DeviceManagerApi.FpvSendGetHitTime)
	//向FPV发送CMD命令
	RegistHandler("/device/fpv/cli", DeviceManagerApi.FpvCli)

	//手动控制视频流
	RegistHandler("/device/fpv/video-control", DeviceManagerApi.FpvVideoControl)

}

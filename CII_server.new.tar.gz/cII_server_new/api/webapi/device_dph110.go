package webapi

import (
	"context"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"github.com/emicklei/go-restful"

	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
)

// DPH110SetConfig 配置DPH110参数
func (e *deviceManager) DPH110SetConfig(req *restful.Request, res *restful.Response) {
	deviceReq := &client.RadarSetConfigRequest{}
	deviceRsp := &client.RadarSetConfigResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().DPH110SetConfig(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		logger.Errorf("DPH110 set config error: %v", err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// DPH110GetConfig 获取DPH110配置参数回复
func (e *deviceManager) DPH110GetConfig(req *restful.Request, res *restful.Response) {
	deviceReq := &client.RadarGetConfigRequest{}
	deviceRsp := &client.RadarGetConfigResponse{}
	err := req.ReadEntity(deviceReq)
	if err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err = handler.NewDeviceCenter().DPH110GetConfig(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		logger.Errorf("DPH110 get config error: %v", err)
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

func init() {
	RegistHandler("/device/dph/set-config", DeviceManagerApi.DPH110SetConfig)
	RegistHandler("/device/dph/get-config", DeviceManagerApi.DPH110GetConfig)
}

package webapi

import (
	"context"

	"github.com/emicklei/go-restful"

	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
)

// AgxSelectUav Agx  选中无人机命令下发
func (e *deviceManager) AgxSelectUav(req *restful.Request, res *restful.Response) {
	deviceReq := &client.AgxSelectUavRequest{}
	deviceRsp := &client.AgxSelectUavResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().AgxSelectUav(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// AgxCalibration Agx  下发标定指令
func (e *deviceManager) AgxCalibration(req *restful.Request, res *restful.Response) {
	deviceReq := &client.AgxCalibrationRequest{}
	deviceRsp := &client.AgxCalibrationRespone{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().AgxCalibration(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// AgxSetCalibrationPara Agx  设置标定参数
func (e *deviceManager) AgxSetCalibrationPara(req *restful.Request, res *restful.Response) {
	deviceReq := &client.AgxSetCalibrationParaRequest{}
	deviceRsp := &client.AgxSetCalibrationParaRespone{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().AgxSetCalibrationPara(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// AgxGetCalibrationPara Agx  获取标定参数
func (e *deviceManager) AgxGetCalibrationPara(req *restful.Request, res *restful.Response) {
	deviceReq := &client.AgxGetCalibrationParaRequest{}
	deviceRsp := &client.AgxGetCalibrationParaRespone{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().AgxGetCalibrationPara(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// AgxSelectSflUav Agx  选中Sfl无人机命令下发
func (e *deviceManager) AgxSelectSflUav(req *restful.Request, res *restful.Response) {
	deviceReq := &client.AgxSelectSflUavRequest{}
	deviceRsp := &client.AgxSelectSflUavResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().AgxSelectSflUav(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// AgxTrackClassification Agx  分类跟踪目标类别
func (e *deviceManager) AgxTrackClassification(req *restful.Request, res *restful.Response) {
	deviceReq := &client.AgxTrackClassificationRequest{}
	deviceRsp := &client.AgxTrackClassificationResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().AgxTrackClassification(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// AgxGetPTZMsg Agx获取rtsp推流地址
func (e *deviceManager) AgxGetPTZMsg(req *restful.Request, res *restful.Response) {
	deviceReq := &client.AgxPTZMsgRequest{}
	deviceRsp := &client.AgxPTZMsgResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().AgxGetPTZMsgDev(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// AgxGetPTZMsg Agx  PTZ控制请求
func (e *deviceManager) AgxPTZConctrlReq(req *restful.Request, res *restful.Response) {
	deviceReq := &client.AgxPTZControlRequest{}
	deviceRsp := &client.AgxPTZControlResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().AgxPTZConctrlReq(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// AgxControlPTZZoomReq
func (e *deviceManager) AgxControlPTZZoomReq(req *restful.Request, res *restful.Response) {
	deviceReq := &client.AgxZoomControlRequest{}
	deviceRsp := &client.AgxZoomControlResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().AgxControlPTZZoomReq(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// AgxControlPTZZoomReq
func (e *deviceManager) AgxUserStatusSet(req *restful.Request, res *restful.Response) {
	deviceReq := &client.AgxUserStatuSetRequest{}
	deviceRsp := &client.AgxUserStatuSetResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().AgxUserStatusSet(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// AgxGetVersion Agx  获取版本信息
func (e *deviceManager) AgxGetVersion(req *restful.Request, res *restful.Response) {
	deviceReq := &client.AgxGetVersionRequest{}
	deviceRsp := &client.AgxGetVersionResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().AgxGetVersion(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// AgxGetInfo Agx获取雷视设备信息
func (e *deviceManager) AgxGetInfo(req *restful.Request, res *restful.Response) {
	deviceReq := &client.AgxGetInfoRequest{}
	deviceRsp := &client.AgxGetInfoResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}

	err := handler.NewDeviceCenter().AgxGetInfo(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// Srp100Calibration srp100开始、中断标定
func (e *deviceManager) Srp100Calibration(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Srp100CalibrationRequest{}
	deviceRsp := &client.Srp100CalibrationResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err := handler.NewDeviceCenter().Srp100Calibration(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// Srp100GetCalibration 获取srp100标定状态
func (e *deviceManager) Srp100GetCalibrationStatus(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Srp100GetCalibrationStatusRequest{}
	deviceRsp := &client.Srp100GetCalibrationStatusResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err := handler.NewDeviceCenter().Srp100GetCalibrationStatus(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// Srp100UserHandTargetPoint 用户下发手点像素目标值
func (e *deviceManager) Srp100UserHandTargetPoint(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Srp100UserHandTargetPointRequest{}
	deviceRsp := &client.Srp100UserHandTargetPointResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err := handler.NewDeviceCenter().Srp100UserHandTargetPoint(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// Srp100GetCalibrationResult 查询标定结果
func (e *deviceManager) Srp100GetCalibrationResult(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Srp100GetCalibrationResultRequest{}
	deviceRsp := &client.Srp100GetCalibrationResultResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err := handler.NewDeviceCenter().Srp100GetCalibrationResult(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

// 目标已锁定，是否确认当前锁定
func (e *deviceManager) Srp100ConfirmCalibration(req *restful.Request, res *restful.Response) {
	deviceReq := &client.Srp100ConfirmCalibrationRequest{}
	deviceRsp := &client.Srp100ConfirmCalibrationResponse{}
	if err := req.ReadEntity(deviceReq); err != nil {
		ParameterBindFail(400, err.Error(), res)
		return
	}
	err := handler.NewDeviceCenter().Srp100ConfirmCalibration(context.Background(), deviceReq, deviceRsp)
	if err != nil {
		ParameterBindFail(500, err.Error(), res)
		return
	}
	Success(deviceRsp, res)
}

func init() {

	RegistHandler("/device/agx/select-uav", DeviceManagerApi.AgxSelectUav)

	RegistHandler("/device/agx/calibration", DeviceManagerApi.AgxCalibration)
	RegistHandler("/device/agx/set-calibration-para", DeviceManagerApi.AgxSetCalibrationPara)
	RegistHandler("/device/agx/get-calibration-para", DeviceManagerApi.AgxGetCalibrationPara)

	//RegistHandler("/device/agx/sfl/select-uav", DeviceManagerApi.AgxSelectSflUav) //废弃

	RegistHandler("/device/agx/track-classification", DeviceManagerApi.AgxTrackClassification)

	RegistHandler("/device/agx/get-PTZ-msg", DeviceManagerApi.AgxGetPTZMsg)
	RegistHandler("/device/agx/PTZ-control-request", DeviceManagerApi.AgxPTZConctrlReq)

	RegistHandler("/device/agx/control-PTZ-zoom-request", DeviceManagerApi.AgxControlPTZZoomReq)
	RegistHandler("/device/agx/user-status-set", DeviceManagerApi.AgxUserStatusSet)

	RegistHandler("/device/agx/get-version", DeviceManagerApi.AgxGetVersion)
	//获取雷视基本信息
	RegistHandler("/device/agx/get-info", DeviceManagerApi.AgxGetInfo)

	//srp100 开始、退出标定
	RegistHandler("/device/srp100/calibration", DeviceManagerApi.Srp100Calibration)
	//获取 srp100 标定状态 废弃
	//RegistHandler("/device/srp100/get-calibration-status", DeviceManagerApi.Srp100GetCalibrationStatus)
	//用户下发手点像素目标值
	RegistHandler("/device/srp100/hand-point", DeviceManagerApi.Srp100UserHandTargetPoint)
	//查询标定结果
	RegistHandler("/device/srp100/get-calibration-result", DeviceManagerApi.Srp100GetCalibrationResult)
	//标定确认
	RegistHandler("/device/srp100/confirm-calibration", DeviceManagerApi.Srp100ConfirmCalibration)
}

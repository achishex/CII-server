package webapi

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"context"
	"fmt"
	"github.com/emicklei/go-restful"
	"os"
	"path/filepath"
	"runtime/pprof"
	"sync/atomic"
)

var (
	PerformanceStatsInstance = new(PerformanceStats)
)

var (
	StatStartOp int32 = 1 // 开始
	StatStopOp  int32 = 2 // 结束
	//
	StatRunning int32 = 1 //统计状态运行中
	StatUnRun   int32 = 0 //统计状态停止运行
)

var (
	cpuStatFile string = "cpu.prof"
	ConfigDir   string
)

type PerformanceStats struct {
	cpuRunning atomic.Int32
	cpuFile    *os.File
}

func (p *PerformanceStats) CpuStatProcess(ctx context.Context, in *client.StatCmdReq, out *client.StatCmdResponse) error {
	if in == nil || out == nil {
		logger.Errorf("input or output obj is nil")
		return fmt.Errorf("param is nil")
	}

	if in.GetOp() == StatStartOp {
		if p.cpuRunning.Load() == StatRunning {
			logger.Infof("repeated stat running request.")
			return nil
		}

		cpuStatFileDir := filepath.Join(ConfigDir, cpuStatFile)
		f, err := os.Create(cpuStatFileDir)
		if err != nil {
			logger.Errorf("open file: %v, err: %v", cpuStatFileDir, err)
			return err
		}
		logger.Infof("cpu stat file: %v", cpuStatFileDir)

		if err := pprof.StartCPUProfile(f); err != nil {
			logger.Errorf("start cpu profile fail, err: %v", err)
			f.Close()
			p.cpuFile = nil
			return err
		}

		p.cpuFile = f
		p.cpuRunning.Store(StatRunning)
		logger.Infof("start cpu profile...")
		return nil
	}

	if in.GetOp() == StatStopOp {
		pprof.StopCPUProfile()
		p.cpuRunning.Store(StatUnRun)
		if p.cpuFile != nil {
			p.cpuFile.Close()
			p.cpuFile = nil
		}
		logger.Infof("stop cpu profile...")
	}
	return nil
}

func (p *PerformanceStats) CpuStats(req *restful.Request, res *restful.Response) {
	processDeviceManager[client.StatCmdReq, client.StatCmdResponse](req, res, p.CpuStatProcess)
}

func init() {
	RegistHandler("/performance/start/cpu", PerformanceStatsInstance.CpuStats)
	RegistHandler("/performance/stop/cpu", PerformanceStatsInstance.CpuStats)
}

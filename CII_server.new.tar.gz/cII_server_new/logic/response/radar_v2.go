package response

import (
	"context"
	"errors"
	"reflect"

	"adasgitlab.autel.com/tools/slink_proto/slinkv1"
	"adasgitlab.autel.com/tools/slink_proto/slinkv2/generatecode/golang/bizproto"
	"adasgitlab.autel.com/tools/slink_proto/slinkv2/msgid"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"

	entity "adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/rpc/cmdhandler"
)

// RadarV2SetConfigResponse 设置雷达配置参数回复
func RadarV2SetConfigResponse(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	rsp, ok := data.(*bizproto.RadarC2SetConfigRsp)
	if !ok {
		dataType := reflect.TypeOf(data)
		logger.Errorf("dataType = %+v", dataType)
		logger.Errorf("covert RadarC2SetConfigRsp err")
		return nil, errors.New("covert RadarC2SetConfigRsp err")
	}
	return rsp, nil
}

// RadarV2GetConfigResponse 获取雷达配置参数
func RadarV2GetConfigResponse(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	rsp, ok := data.(*bizproto.RadarC2Config)
	if !ok {
		dataType := reflect.TypeOf(data)
		logger.Errorf("dataType = %+v", dataType)
		logger.Errorf("covert RadarC2Config err")
		return nil, errors.New("covert RadarC2Config err")
	}
	return rsp, nil
}

// RadarSetMaskResponse 雷达Mask配置操作回复
func RadarSetMaskResponse(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	rsp, ok := data.(*bizproto.RadarC2SetMaskRsp)
	if !ok {
		dataType := reflect.TypeOf(data)
		logger.Errorf("dataType = %+v", dataType)
		logger.Errorf("covert RadarMaskResponse err")
		return nil, errors.New("covert RadarMaskResponse err")
	}
	return rsp, nil
}

// RadarGetMaskResponse 获取雷达Mask回复
func RadarGetMaskResponse(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	rsp, ok := data.(*bizproto.RadarC2Mask)
	if !ok {
		dataType := reflect.TypeOf(data)
		logger.Errorf("dataType = %+v", dataType)
		logger.Errorf("covert RadarGetMaskResponse err")
		return nil, errors.New("covert RadarGetMaskResponse err")
	}
	return rsp, nil
}

func RadarOtaRsp(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	return data, nil
}

func init() {
	//雷达参数配置相关
	cmdhandler.Instance().RegisterHandler(entity.DEV_RADAR, msgid.RadarV2SetConfig, RadarV2SetConfigResponse)
	cmdhandler.Instance().RegisterHandler(entity.DEV_RADAR, msgid.RadarV2GetConfig, RadarV2GetConfigResponse)

	// 2024.05.28 测试反馈雷达无法正常OTA升级
	// 经排查，雷达与C2的协议升级到了 slink v2
	// 进一步确认，雷达目前实现的OTA 消息是 [slink v2 header] + [slink v1 payload]
	// 为了快速交付，C2进行monkey patch，待雷达后续迁移到wget ota升级方式
	// 	mavlink.RadarResetSystemResponse{}
	//	mavlink.GetVersionInfoResponse{}
	//	mavlink.RadarRequestUpgradeResponse{}
	//	mavlink.RadarSendUpdatePkgResponse{}
	//	mavlink.RadarVerifyImageResponse{}
	//	mavlink.RadarWriteUpdateDataResponse{}
	//	mavlink.RadarGetUpdateWriteStatusResponse{}
	//	mavlink.RadarRunAppResponse{}
	cmdhandler.Instance().RegisterHandler(entity.DEV_RADAR, slinkv1.RadarIdResetSystem, RadarOtaRsp)

	cmdhandler.Instance().RegisterHandler(entity.DEV_RADAR, slinkv1.RadarIdGetVersionInfo, RadarOtaRsp)

	cmdhandler.Instance().RegisterHandler(entity.DEV_RADAR, slinkv1.RadarIdRequestUpgrade, RadarOtaRsp)

	cmdhandler.Instance().RegisterHandler(entity.DEV_RADAR, slinkv1.RadarIdSendUpdatePkg, RadarOtaRsp)

	cmdhandler.Instance().RegisterHandler(entity.DEV_RADAR, slinkv1.RadarIdVerifyImage, RadarOtaRsp)

	cmdhandler.Instance().RegisterHandler(entity.DEV_RADAR, slinkv1.RadarIdWriteUpdateData, RadarOtaRsp)

	cmdhandler.Instance().RegisterHandler(entity.DEV_RADAR, slinkv1.RadarIdGetUpdateWriteStatus, RadarOtaRsp)

	cmdhandler.Instance().RegisterHandler(entity.DEV_RADAR, slinkv1.RadarIdRunApp, RadarOtaRsp)

	// 雷达Mask相关
	cmdhandler.Instance().RegisterHandler(entity.DEV_RADAR, msgid.RadarIdV2SetMask, RadarSetMaskResponse)
	cmdhandler.Instance().RegisterHandler(entity.DEV_RADAR, msgid.RadarIdV2GetMask, RadarGetMaskResponse)
}

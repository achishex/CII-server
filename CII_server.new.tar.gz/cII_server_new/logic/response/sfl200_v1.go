package response

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	entity "adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/rpc/cmdhandler"
	"adasgitlab.autel.com/tools/slink_proto/slinkv1"
	"context"
	"errors"
	"reflect"
)

// Sfl200SendWhiteSetRsp 黑白名单设置
func Sfl200SendWhiteSetRsp(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	logger.Debug("---->into receive Sfl200 White Set Rsp,sn:", sn)
	rsp, ok := data.(*slinkv1.Sfl200SendSetWhiteResponse)
	if !ok {
		dataType := reflect.TypeOf(data)
		logger.Errorf("dataType = %+v", dataType)
		logger.Errorf("covert Sfl200SendWhiteSetRsp err")
		return nil, errors.New("covert Sfl200SendWhiteSetRsp err")
	}
	return rsp, nil
}

// Sfl200SendSystemWorkModeGetRsp 参数获取
func Sfl200SendSystemWorkModeGetRsp(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	logger.Debug("---->into receive Sfl200 System WorkMode Get Rsp,sn:", sn)
	rsp, ok := data.(*slinkv1.Sfl200SendSystemWorkModeGetResponse)
	if !ok {
		dataType := reflect.TypeOf(data)
		logger.Errorf("dataType = %+v", dataType)
		logger.Errorf("covert Sfl200SendSystemWorkModeGetRsp err")
		return nil, errors.New("covert Sfl200SendSystemWorkModeGetRsp err")
	}
	return rsp, nil
}

// Sfl200SendSystemWorkModeSettingRsp 参数配置
func Sfl200SendSystemWorkModeSettingRsp(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	logger.Debug("---->into receive Sfl200 System WorkMode Set Rsp,sn:", sn)
	rsp, ok := data.(*slinkv1.Sfl200SendSystemWorkModeSetResponse)
	if !ok {
		dataType := reflect.TypeOf(data)
		logger.Errorf("dataType = %+v", dataType)
		logger.Errorf("covert Sfl200SendSystemWorkModeSettingRsp err")
		return nil, errors.New("covert Sfl200SendSystemWorkModeSettingRsp err")
	}
	return rsp, nil
}

// Sfl200StartNSF4000Work 开启导航诱骗干扰
func Sfl200StartNSF4000Work(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	logger.Debug("---->into receive Sfl200 Start NSF4000 Rsp,sn:", sn)
	rsp, ok := data.(*slinkv1.Sfl200SendStartNSF4000Response)
	if !ok {
		dataType := reflect.TypeOf(data)
		logger.Errorf("dataType = %+v", dataType)
		logger.Errorf("covert Sfl200StartNSF4000Work err")
		return nil, errors.New("covert Sfl200StartNSF4000Work err")
	}
	return rsp, nil
}

// Sfl200SendTurnSflRsp 转台手动控制
func Sfl200SendTurnSflRsp(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	logger.Debug("---->into receive Sfl200 Turn Sfl Rsp,sn:", sn)
	rsp, ok := data.(*slinkv1.Sfl200SendTurnSflResponse)
	if !ok {
		dataType := reflect.TypeOf(data)
		logger.Errorf("dataType = %+v", dataType)
		logger.Errorf("covert Sfl200SendTurnSflRsp err")
		return nil, errors.New("covert Sfl200SendTurnSflRsp err")
	}
	return rsp, nil
}

// Sfl200SendManualStopOrStartHitUavRsp 开关打击（纯手动）
func Sfl200SendManualStopOrStartHitUavRsp(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	logger.Debug("---->into receive Sfl200 Manual StopOrStart HitUav Rsp,sn:", sn)
	rsp, ok := data.(*slinkv1.Sfl200SendStartStopHitResponse)
	if !ok {
		dataType := reflect.TypeOf(data)
		logger.Errorf("dataType = %+v", dataType)
		logger.Errorf("covert Sfl200SendManualStopOrStartHitUavRsp err")
		return nil, errors.New("covert Sfl200SendManualStopOrStartHitUavRsp err")
	}
	return rsp, nil
}

// Sfl200SendHitFreqDirectRsp 频谱目标定向打击
func Sfl200SendHitFreqDirectRsp(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	logger.Debug("---->into receive Sfl200 Hit Freq Direct Rsp,sn:", sn)
	rsp, ok := data.(*slinkv1.Sfl200SendFreqDirectHitResponse)
	if !ok {
		dataType := reflect.TypeOf(data)
		logger.Errorf("dataType = %+v", dataType)
		logger.Errorf("covert Sfl200SendHitFreqDirectRsp err")
		return nil, errors.New("covert Sfl200SendHitFreqDirectRsp err")
	}
	return rsp, nil
}

// Sfl200SendFreqDirectRsp 频谱目标定向
func Sfl200SendFreqDirectRsp(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	logger.Debug("---->into receive Sfl200 Freq Direct Rsp,sn:", sn)
	rsp, ok := data.(*slinkv1.Sfl200SendFreqDirectResponse)
	if !ok {
		dataType := reflect.TypeOf(data)
		logger.Errorf("dataType = %+v", dataType)
		logger.Errorf("covert Sfl200SendFreqDirectRsp err")
		return nil, errors.New("covert Sfl200SendFreqDirectRsp err")
	}
	return rsp, nil
}

// Sfl200SendHitDealUavRsp 目标打击处置
func Sfl200SendHitDealUavRsp(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	logger.Debug("---->into receive Sfl200 Hit Deal Uav Rsp,sn:", sn)
	rsp, ok := data.(*slinkv1.Sfl200SendHitUavResponse)
	if !ok {
		dataType := reflect.TypeOf(data)
		logger.Errorf("dataType = %+v", dataType)
		logger.Errorf("covert Sfl200SendHitDealUavRsp err")
		return nil, errors.New("covert Sfl200SendHitDealUavRsp err")
	}
	return rsp, nil
}

// Sfl200SendPtzFollowUavRsp 目标PTZ跟踪
func Sfl200SendPtzFollowUavRsp(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	logger.Debug("---->into receive Sfl200 Ptz Follow Uav Rsp,sn:", sn)
	rsp, ok := data.(*slinkv1.Sfl200SendPtzFollowUavResponse)
	if !ok {
		dataType := reflect.TypeOf(data)
		logger.Errorf("dataType = %+v", dataType)
		logger.Errorf("covert Sfl200SendPtzFollowUavRsp err")
		return nil, errors.New("covert Sfl200SendPtzFollowUavRsp err")
	}
	return rsp, nil
}

// Sfl200SendAutoFindHitGetRsp 获取自动察打参数配置
func Sfl200SendAutoFindHitGetRsp(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	logger.Debug("---->into receive Sfl200 Auto Find HitGet Rsp,sn:", sn)
	rsp, ok := data.(*slinkv1.Sfl200SendAutoFindHitGetResponse)
	if !ok {
		dataType := reflect.TypeOf(data)
		logger.Errorf("dataType = %+v", dataType)
		logger.Errorf("covert Sfl200SendAutoFindHitGetRsp err")
		return nil, errors.New("covert Sfl200SendAutoFindHitGetRsp err")
	}
	return rsp, nil
}

// Sfl200SendAutoFindHitSetting 自动察打参数配置
func Sfl200SendAutoFindHitSetting(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	logger.Debug("---->into receive Sfl200 Auto Find HitSetting Rsp,sn:", sn)
	rsp, ok := data.(*slinkv1.Sfl200SendAutoFindHitSettingResponse)
	if !ok {
		dataType := reflect.TypeOf(data)
		logger.Errorf("dataType = %+v", dataType)
		logger.Errorf("covert Sfl200SendAutoFindHitSetting err")
		return nil, errors.New("covert Sfl200SendAutoFindHitSetting err")
	}
	return rsp, nil
}

// Sfl200SendWorkModeGettingRsp 工作模式获取
func Sfl200SendWorkModeGettingRsp(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	logger.Debug("---->into receive Sfl200 WorkMode Getting Rsp,sn:", sn)
	rsp, ok := data.(*slinkv1.Sfl200SendGetWorkModeResponse)
	if !ok {
		dataType := reflect.TypeOf(data)
		logger.Errorf("dataType = %+v", dataType)
		logger.Errorf("covert Sfl200SendWorkModeGettingRsp err")
		return nil, errors.New("covert Sfl200SendWorkModeGettingRsp err")
	}
	return rsp, nil
}

// Sfl200GetVersion 设备版本获取
func Sfl200GetVersion(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	logger.Debug("---->into receive Sfl200 Version Getting Rsp,sn:", sn)
	rsp, ok := data.(*slinkv1.Sfl200GetVersionResponse)
	if !ok {
		dataType := reflect.TypeOf(data)
		logger.Errorf("dataType = %+v", dataType)
		logger.Errorf("covert Sfl200GetVersionRsp err")
		return nil, errors.New("covert Sfl200GetVersionRsp err")
	}
	return rsp, nil
}

// Sfl200SendWorkModeSettingRsp 工作模式设置
func Sfl200SendWorkModeSettingRsp(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	logger.Debug("---->into receive Sfl200 WorkMode Setting Rsp,sn:", sn)
	rsp, ok := data.(*slinkv1.Sfl200SendSetWorkModeResponse)
	if !ok {
		dataType := reflect.TypeOf(data)
		logger.Errorf("dataType = %+v", dataType)
		logger.Errorf("covert Sfl200SendSetWorkModeResponse err")
		return nil, errors.New("covert Sfl200SendSetWorkModeResponse err")
	}
	return rsp, nil
}
func init() {
	cmdhandler.Instance().RegisterHandler(entity.DEV_SFL200, slinkv1.Sfl200SendWorkModeSetting, Sfl200SendWorkModeSettingRsp)
	cmdhandler.Instance().RegisterHandler(entity.DEV_SFL200, slinkv1.Sfl200SendWorkModeGetting, Sfl200SendWorkModeGettingRsp)
	cmdhandler.Instance().RegisterHandler(entity.DEV_SFL200, slinkv1.Sfl200SendAutoFindHitSetting, Sfl200SendAutoFindHitSetting)
	cmdhandler.Instance().RegisterHandler(entity.DEV_SFL200, slinkv1.Sfl200SendAutoFindHitGet, Sfl200SendAutoFindHitGetRsp)
	cmdhandler.Instance().RegisterHandler(entity.DEV_SFL200, slinkv1.Sfl200SendPtzFollowUav, Sfl200SendPtzFollowUavRsp)
	cmdhandler.Instance().RegisterHandler(entity.DEV_SFL200, slinkv1.Sfl200SendHitDealUav, Sfl200SendHitDealUavRsp)
	cmdhandler.Instance().RegisterHandler(entity.DEV_SFL200, slinkv1.Sfl200SendFreqDirect, Sfl200SendFreqDirectRsp)
	cmdhandler.Instance().RegisterHandler(entity.DEV_SFL200, slinkv1.Sfl200SendHitFreqDirect, Sfl200SendHitFreqDirectRsp)
	cmdhandler.Instance().RegisterHandler(entity.DEV_SFL200, slinkv1.Sfl200SendManualStopOrStartHitUav, Sfl200SendManualStopOrStartHitUavRsp)
	cmdhandler.Instance().RegisterHandler(entity.DEV_SFL200, slinkv1.Sfl200SendTurnSfl, Sfl200SendTurnSflRsp)
	cmdhandler.Instance().RegisterHandler(entity.DEV_SFL200, slinkv1.Sfl200StartNSF4000Work, Sfl200StartNSF4000Work)
	cmdhandler.Instance().RegisterHandler(entity.DEV_SFL200, slinkv1.Sfl200SendSystemWorkModeSetting, Sfl200SendSystemWorkModeSettingRsp)
	cmdhandler.Instance().RegisterHandler(entity.DEV_SFL200, slinkv1.Sfl200SendSystemWorkModeGet, Sfl200SendSystemWorkModeGetRsp)
	cmdhandler.Instance().RegisterHandler(entity.DEV_SFL200, slinkv1.Sfl200SendWhiteSet, Sfl200SendWhiteSetRsp)
	cmdhandler.Instance().RegisterHandler(entity.DEV_SFL200, slinkv1.Sfl200GetVersion, Sfl200GetVersion)
}

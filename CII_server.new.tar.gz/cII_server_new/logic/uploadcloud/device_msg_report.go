package uploadcloud

import (
	"context"
	"fmt"
	"strconv"
	"sync"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	jsoniter "github.com/json-iterator/go"
	broker2 "go-micro.dev/v4/broker"
	"google.golang.org/protobuf/proto"

	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/config"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/logic/uploadcloud/down"
	"adasgitlab.autel.com/tools/cuav_server/logic/uploadcloud/util"
	videostore "adasgitlab.autel.com/tools/cuav_server/logic/uploadcloud/videoStore"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/proto/cloudPlatform"
	"adasgitlab.autel.com/tools/cuav_server/proto/mavlink"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
)

var (
	//EnableLogInvildJSON 调试使用，每类设备仅通过一个topic进行通信，查看无效topic 消息
	EnableLogInvildJSON  = true
	gcheckC2ConfigTime   = time.Now()
	gSysConfig           = client.ConfigRes{}
	gIsFirstGetSysConfig = true
)

// ReportMsg 上报云端服务
func (ctrl *CloudTcpCli) ReportMsg() {
	logger.Debug("---")
	videostore.InitVideoStoreInstance()
	go ctrl.ReportC2SystemConfigMsg() //向云端上报系统配置消息

	go ctrl.ReportC2EquipListMsg() //向云端上报C2设备列表消息

	//每一个topic使用一个协程处理上报逻辑
	go ctrl.ReportSfl()                      //向云端上报 哨兵塔sfl 所有信息
	go ctrl.ReportFpv()                      //向云端上报 车载fpv 信息
	go ctrl.ReportNSF400()                   //向云端上报 导航诱导 信息
	go ctrl.ReportNSF400LLH()                //向云端上报 导航诱导 信息
	go ctrl.ReportTracerRF360DeviceStatusH() //向云端上报 设备状态 信息
	go ctrl.ReportTracerRF360DroneInfoH()    //向云端上报 无人机消息 信息
	go ctrl.ReportTracerRF360UrdSpectrumH()  //向云端上报 频谱信息 信息
	go ctrl.ReportSfl200()                   //向云端上报 哨兵塔sfl200 所有信息
	go ctrl.ReportDph110()                   //向云端上报 DPH110 所有信息

	ctrl.ReportRadarHeartMsg()      //向云端上报雷达心跳消息
	ctrl.ReportRadarPostureMsg()    //向云端上报雷达姿态消息
	ctrl.ReportRadarUavMsg()        //向云端上报雷达探测到无人机消息
	ctrl.ReportRadarBeamConfigMsg() //向云端上报雷达波控信息

	ctrl.ReportTracerHeartMsg()     //向云端上报Tracer心跳消息
	ctrl.ReportTracerUavMsg()       //向云端上报Tracer无人机消息
	ctrl.ReportTracerUavPlusMsg()   //向云端上报tracer无人机融合消息
	ctrl.ReportTracerUavSystemMsg() //向云端转发tracerP数据

	ctrl.ReportAgxMsg() //向云端上报AGX消息

	ctrl.ReportGunHeartMsg()    //向云端上报反制枪心跳消息
	ctrl.ReportGunUavMsg()      //向云端上报无人机信息
	ctrl.ReportDataReplayMark() //向云端上报标记内容

	// 事件上报
	ctrl.EventReport()

	// APP修改设备名称，向云端上报
	go ctrl.ReportC2EquipMsg()
}

func (ctrl *CloudTcpCli) ReportDataReplayMark() {
	//雷达心跳1s一次
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	mu := sync.Mutex{}
	_, _ = mq.DataReplayMark.Subscribe(mq.DataReplayMarkTopic, func(event broker2.Event) error {
		entity := common.EquipmentMessageBoxEntity{}
		err := jsoniter.Unmarshal(event.Message().Body, &entity)
		//logger.Info("event.Message().Body = ", event.Message().Body)
		if err != nil {
			return fmt.Errorf("report data mark Unmarshal error: %v", err)
		}
		if entity.MsgType == 0 {
			return nil
		}
		infoJson, _ := jsoniter.Marshal(entity.Info)
		mark := bean.DateMarkers{}
		err = jsoniter.Unmarshal(infoJson, &mark)
		//logger.Debug(" Unmarshal")
		if err != nil {
			if EnableLogInvildJSON {
				logger.Debug("report data mark Unmarshal info error: %v", err)
			}
			return fmt.Errorf("report data mark Unmarshal info error: %v", err)
		}
		mu.Lock()
		defer mu.Unlock()

		//给云端发送
		markData := make([]*cloudPlatform.MarkList, 0)
		markData = append(markData, &cloudPlatform.MarkList{
			Timestamp:  mark.TimeStamp,
			Level:      mark.Level,
			Tips:       mark.Tips,
			Operation:  int32(entity.MsgType),
			CreateTime: time.Now().UnixMilli(),
		})

		heartMessage := &cloudPlatform.DataReplayMark{
			Body: markData,
		}
		// encodedMessage
		encodedMessage, err := proto.Marshal(heartMessage)
		if err != nil {
			logger.Error("Protobuf编码失败:", err)
			return fmt.Errorf("report Radar Heart Marshal encodedMessage error: %v", err)
		}

		// 构建Message消息
		message := &cloudPlatform.Message{
			BaseInfo: &cloudPlatform.BaseInfo{
				MsgId:     1,
				Url:       DATAREPLAYMARK_WRL,
				Sn:        ctrl.C2Sn, //ctrl.C2Sn
				MsgType:   MSG_TYPE_REQUEST,
				ErrorCode: 0,
				LoginId:   ctrl.LoginId,
			},
			Data: encodedMessage,
		}
		// 对Message进行Protobuf编码
		encodedMessage, err = proto.Marshal(message)
		if err != nil {
			logger.Error("Protobuf编码失败:", err)
			return err
		}
		//对消息进行封装+head+crc
		encodedMessage = createPacket(encodedMessage)
		// 发送TCP消息
		if ctrl.Conn == nil || ctrl.IsLogin == false {
			return nil
		}
		_, err = ctrl.Conn.Write(encodedMessage)
		if err != nil {
			logger.Error("发送TCP消息失败:", err)
			return err
		}
		return nil
	})
}

func (ctrl *CloudTcpCli) ReportC2SystemConfigMsg() {
	// 设置定时器
	//定时上报系统配置消息
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
			go ctrl.ReportC2SystemConfigMsg()
		}
	}()
	go func() {
		timer := time.NewTicker(60 * time.Second)
		defer timer.Stop()
		for {
			select {
			case <-timer.C:
				configInfo := &client.ConfigRes{}
				err := handler.NewSystemConfig().GetSystemConfig(context.Background(), &client.ConfigReq{}, configInfo)
				//logger.Info("configInfo = ", configInfo)
				if err != nil {
					logger.Error("Get SystemConfig err: ", err)
					continue
				}
				configStr := config.C2ConfigStr{
					Id:            int64(configInfo.Id),
					Longitude:     configInfo.Longitude,
					Latitude:      configInfo.Latitude,
					Heading:       int64(configInfo.Heading),
					WarningRadius: configInfo.WarningRadius,
					CounterRadius: configInfo.CounterRadius,
					FenceRadius:   configInfo.FenceRadius,
					ScannerRadius: configInfo.ScannerRadius,
					Height:        configInfo.Height,
					C2Longitude:   configInfo.C2Longitude,
					C2Latitude:    configInfo.C2Latitude,
				}
				handler.C2Config.Set("c2config", configStr)
				//给云端发送
				configData := make([]*cloudPlatform.Config, 0)
				configData = append(configData, &cloudPlatform.Config{
					Id:            int64(configInfo.Id),
					Longitude:     configInfo.Longitude,
					Latitude:      configInfo.Latitude,
					Heading:       int64(configInfo.Heading),
					WarningRadius: configInfo.WarningRadius,
					CounterRadius: configInfo.CounterRadius,
					FenceRadius:   configInfo.FenceRadius,
					ScannerRadius: configInfo.ScannerRadius,
					C2Longitude:   configInfo.C2Longitude,
					C2Latitude:    configInfo.C2Latitude,
					CreateTime:    time.Now().UnixMilli(),
					Height:        configInfo.Height,
				})
				logger.Debug("configData = ", configData)
				equipMessage := &cloudPlatform.C2SystemConfigList{
					Body: configData,
				}
				// encodedMessage
				encodedMessage, err := proto.Marshal(equipMessage)
				if err != nil {
					logger.Error("Protobuf编码失败:", err)
					continue
				}

				// 构建Message消息
				message := &cloudPlatform.Message{
					BaseInfo: &cloudPlatform.BaseInfo{
						MsgId:     1,
						Url:       C2_SYSTEM_CONFIG_URL,
						Sn:        ctrl.C2Sn, //ctrl.C2Sn
						MsgType:   MSG_TYPE_REQUEST,
						ErrorCode: 0,
						LoginId:   ctrl.LoginId,
					},
					Data: encodedMessage,
				}
				// 对Message进行Protobuf编码
				encodedMessage, err = proto.Marshal(message)
				if err != nil {
					logger.Error("Protobuf编码失败:", err)
					continue
				}
				//对消息进行封装+head+crc
				encodedMessage = createPacket(encodedMessage)
				// 发送TCP消息
				if ctrl.Conn == nil || ctrl.IsLogin == false {
					continue
				}
				_, err = ctrl.Conn.Write(encodedMessage)
				if err != nil {
					logger.Error("发送TCP消息失败:", err)
					ctrl.clearConn()
					continue
				}
			}
		}
	}()

	//每有修改上报系统配置消息
	// 监听 map 变化的通道
	changeChan := make(chan struct{})

	// 启动一个 goroutine 持续监听 map 的变化
	go func() {
		prevItems := make(map[string]config.C2ConfigStr)
		for {
			time.Sleep(1 * time.Second)

			// 检查当前 map 的数据与上一次的数据是否一致
			handler.C2Config.Mu.RLock()
			isChanged := !config.IsMapEqual(handler.C2Config.Config, prevItems)
			handler.C2Config.Mu.RUnlock()

			if isChanged {
				// 发送变化通知
				changeChan <- struct{}{}
			}

			handler.C2Config.Mu.RLock()
			prevItems = config.CopyMap(handler.C2Config.Config)
			handler.C2Config.Mu.RUnlock()
		}
	}()
	for {
		select {
		case <-changeChan:
			//map变化  上报消息

			configInfo, _ := handler.C2Config.Get("c2config")
			//给云端发送
			configData := make([]*cloudPlatform.Config, 0)
			configData = append(configData, &cloudPlatform.Config{
				Id:            int64(configInfo.Id),
				Longitude:     configInfo.Longitude,
				Latitude:      configInfo.Latitude,
				Heading:       int64(configInfo.Heading),
				WarningRadius: configInfo.WarningRadius,
				CounterRadius: configInfo.CounterRadius,
				FenceRadius:   configInfo.FenceRadius,
				ScannerRadius: configInfo.ScannerRadius,
				CreateTime:    time.Now().UnixMilli(),
				Height:        configInfo.Height,
				C2Longitude:   configInfo.C2Longitude,
				C2Latitude:    configInfo.C2Latitude,
			})

			equipMessage := &cloudPlatform.C2SystemConfigList{
				Body: configData,
			}
			// encodedMessage
			encodedMessage, err := proto.Marshal(equipMessage)
			if err != nil {
				logger.Error("Protobuf编码失败:", err)
				continue
			}

			// 构建Message消息
			message := &cloudPlatform.Message{
				BaseInfo: &cloudPlatform.BaseInfo{
					MsgId:     1,
					Url:       C2_SYSTEM_CONFIG_URL,
					Sn:        ctrl.C2Sn, //ctrl.C2Sn
					MsgType:   MSG_TYPE_REQUEST,
					ErrorCode: 0,
					LoginId:   ctrl.LoginId,
				},
				Data: encodedMessage,
			}
			// 对Message进行Protobuf编码
			encodedMessage, err = proto.Marshal(message)
			if err != nil {
				logger.Error("Protobuf编码失败:", err)
				continue
			}
			//对消息进行封装+head+crc
			encodedMessage = createPacket(encodedMessage)
			// 发送TCP消息
			if ctrl.Conn == nil || ctrl.IsLogin == false {
				continue
			}
			logger.Info("configInfo change = ", configInfo)
			_, err = ctrl.Conn.Write(encodedMessage)
			if err != nil {
				logger.Error("发送TCP消息失败:", err)
				continue
			}

		}
	}
}

func (ctrl *CloudTcpCli) ReportC2EquipListMsg() {
	// 设置定时器
	timer := time.NewTicker(10 * time.Second)
	defer timer.Stop()
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
			go ctrl.ReportC2EquipListMsg()
		}
	}()
	for {
		select {
		case <-timer.C:
			dbequips := &client.EquipListRes{}
			err := handler.NewEquipList().List(context.Background(), &client.EquipListReq{}, dbequips)
			//logger.Info("dbequips = ", dbequips)
			if err != nil {
				logger.Error("Get EquipList err: ", err)
				continue
			}
			//给云端发送
			equipData := make([]*cloudPlatform.Equip, 0)
			for _, equip := range dbequips.Equips {
				if equip.Sn == "" {
					continue
				}
				tempName := equip.Name
				if equip.Name == "" {
					logger.Debug("equip = ", equip)
					if equip.Etype == common.Drone {
						tempName = common.DroneName + strconv.Itoa(int(equip.Id))
					} else if equip.Etype == common.Radar {
						tempName = common.RadarName + strconv.Itoa(int(equip.Id))
					} else if equip.Etype == common.Sfl {
						tempName = common.SflName + strconv.Itoa(int(equip.Id))
					} else if equip.Etype == common.NSF400 {
						tempName = common.NSF400Name + strconv.Itoa(int(equip.Id))
					} else if equip.Etype == common.TracerRFurd360 {
						tempName = common.TracerRFurd360Name + strconv.Itoa(int(equip.Id))
					} else if equip.Etype == common.Agx {
						tempName = common.AgxName + strconv.Itoa(int(equip.Id))
					} else if equip.Etype == common.Sfl200 {
						tempName = common.Sfl200Name + strconv.Itoa(int(equip.Id))
					} else {
						logger.Errorf("illegal equip ", equip)
					}
				}
				sfl200ChildMap.Store(equip.Sn, tempName)

				equipData = append(equipData, &cloudPlatform.Equip{
					Id:             int32(equip.Id),
					Etype:          equip.Etype,
					Ip:             equip.Ip,
					Vendor:         "",
					Name:           tempName,
					Sn:             equip.Sn,
					Enable:         equip.IsEnable,
					RadarRelevance: equip.RadarRelevance,
					CreateTime:     time.Now().UnixMilli(),
					ParentSn:       equip.ParentSn,
					SubDevType:     int32(equip.SubDevType),
				})
			}
			logger.Debug("equipData =  ", equipData)
			equipMessage := &cloudPlatform.EquipList{
				Body: equipData,
			}
			// encodedMessage
			encodedMessage, err := proto.Marshal(equipMessage)
			if err != nil {
				logger.Error("Protobuf编码失败:", err)
				continue
			}

			// 构建Message消息
			message := &cloudPlatform.Message{
				BaseInfo: &cloudPlatform.BaseInfo{
					MsgId:     1,
					Url:       C2_EQUIP_LIST_URL,
					Sn:        ctrl.C2Sn, //ctrl.C2Sn
					MsgType:   MSG_TYPE_REQUEST,
					ErrorCode: 0,
					LoginId:   ctrl.LoginId,
				},
				Data: encodedMessage,
			}
			// 对Message进行Protobuf编码
			encodedMessage, err = proto.Marshal(message)
			if err != nil {
				logger.Error("Protobuf编码失败:", err)
				continue
			}
			//对消息进行封装+head+crc
			encodedMessage = createPacket(encodedMessage)
			// 发送TCP消息
			if ctrl.Conn == nil || ctrl.IsLogin == false {
				continue
			}
			_, err = ctrl.Conn.Write(encodedMessage)
			if err != nil {
				logger.Error("发送TCP消息失败:", err)
				ctrl.clearConn()
				continue
			}
		}
	}

}

func (ctrl *CloudTcpCli) ReportRadarHeartMsg() {
	//雷达心跳1s一次
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	mu := sync.Mutex{}
	_, _ = mq.EquipmentStatusBroker.Subscribe(mq.EquipmentStatusTopic, func(event broker2.Event) error {
		entity := common.EquipmentMessageBoxEntity{}
		err := jsoniter.Unmarshal(event.Message().Body, &entity)
		//logger.Debug("event.Message().Body = ", event.Message().Body)
		if err != nil {
			return fmt.Errorf("report Radar Heart Unmarshal error: %v", err)
		}
		if entity.MsgType == 0 {
			return nil
		}
		infoJson, _ := jsoniter.Marshal(entity.Info)
		heart := bean.RadarTcpHeart{}
		//logger.Debug("start Unmarshal")
		err = jsoniter.Unmarshal(infoJson, &heart)
		if err != nil {
			if EnableLogInvildJSON {
				logger.Debug("report Radar Heart Unmarshal info error: %v", err)
			}
			return fmt.Errorf("report Radar Heart Unmarshal info error: %v", err)
		}
		heart.Sn = entity.Sn
		mu.Lock()
		defer mu.Unlock()

		if heart.IsOnline == 0 {
			heart.IsOnline = 1
		} else if heart.IsOnline == 1 {
			heart.IsOnline = 2
		}
		//给云端发送
		heartData := make([]*cloudPlatform.RadarHeartData, 0)
		heartData = append(heartData, &cloudPlatform.RadarHeartData{
			Sn:          heart.Sn,
			Online:      int32(heart.IsOnline), //1在线、2离线
			Electricity: heart.Electricity,
			CreateTime:  time.Now().UnixMilli(),
			Status:      int32(heart.Status),
			SysStatus:   heart.SysStatus,
		})
		logger.Debug("heartData =", heartData)
		heartMessage := &cloudPlatform.RadarHeartList{
			Body: heartData,
		}
		// encodedMessage
		encodedMessage, err := proto.Marshal(heartMessage)
		if err != nil {
			logger.Error("Protobuf编码失败:", err)
			return fmt.Errorf("report Radar Heart Marshal encodedMessage error: %v", err)
		}

		// 构建Message消息
		message := &cloudPlatform.Message{
			BaseInfo: &cloudPlatform.BaseInfo{
				MsgId:     1,
				Url:       RADAR_HEART_URL,
				Sn:        ctrl.C2Sn, //ctrl.C2Sn
				MsgType:   MSG_TYPE_REQUEST,
				ErrorCode: 0,
				LoginId:   ctrl.LoginId,
			},
			Data: encodedMessage,
		}
		// 对Message进行Protobuf编码
		encodedMessage, err = proto.Marshal(message)
		if err != nil {
			logger.Error("Protobuf编码失败:", err)
			return err
		}
		//对消息进行封装+head+crc
		encodedMessage = createPacket(encodedMessage)
		// 发送TCP消息
		if ctrl.Conn == nil || ctrl.IsLogin == false {
			return nil
		}
		_, err = ctrl.Conn.Write(encodedMessage)
		if err != nil {
			logger.Error("发送TCP消息失败:", err)
			ctrl.clearConn()
			return err
		}
		return nil
	})
}

func (ctrl *CloudTcpCli) ReportRadarPostureMsg() {
	//姿态信息100ms一次
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()

	mu := sync.Mutex{}
	_, _ = mq.RadarPostureBroker.Subscribe(mq.RadarPostureTopic, func(event broker2.Event) error {
		entity := common.EquipmentMessageBoxEntity{}
		err := jsoniter.Unmarshal(event.Message().Body, &entity)
		//logger.Debug("event.Message().Body = ", event.Message().Body)
		if err != nil {
			return fmt.Errorf("report Radar Posture Unmarshal error: %v", err)
		}

		infoJson, _ := jsoniter.Marshal(entity.Info)
		posture := bean.RadarTcpPostureInfo{}
		//logger.Debug("start Unmarshal")
		err = jsoniter.Unmarshal(infoJson, &posture)
		if err != nil {
			if EnableLogInvildJSON {
				logger.Debug("report Radar Posture  Unmarshal info error: %v", err)
			}
			return fmt.Errorf("report Radar Posture  Unmarshal info error: %v", err)
		}
		posture.Sn = entity.Sn
		mu.Lock()
		defer mu.Unlock()

		//给云端发送
		postureData := make([]*cloudPlatform.RadarPostureData, 0)
		postureData = append(postureData, &cloudPlatform.RadarPostureData{
			Sn:         posture.Sn,
			Heading:    &(posture.Heading),
			Pitching:   &(posture.Pitching),
			Rolling:    &(posture.Rolling),
			Longitude:  &(posture.Longitude),
			Latitude:   &(posture.Latitude),
			CreateTime: time.Now().UnixMilli(),
			Altitude:   &(posture.Altitude),
		})
		//logger.Debug("posture.Sn, = ", posture.Sn)
		logger.Debug("postureData = ", postureData)
		postureMessage := &cloudPlatform.RadarPostureList{
			Body: postureData,
		}

		// encodedMessage
		encodedMessage, err := proto.Marshal(postureMessage)
		if err != nil {
			logger.Error("Protobuf编码失败:", err)
			return fmt.Errorf("report Radar posture Marshal encodedMessage error: %v", err)
		}

		// 构建Message消息
		message := &cloudPlatform.Message{
			BaseInfo: &cloudPlatform.BaseInfo{
				MsgId:     1,
				Url:       RADAR_POSTURE_URL,
				Sn:        ctrl.C2Sn, //ctrl.C2Sn
				MsgType:   MSG_TYPE_REQUEST,
				ErrorCode: 0,
				LoginId:   ctrl.LoginId,
			},
			Data: encodedMessage,
		}
		// 对Message进行Protobuf编码
		encodedMessage, err = proto.Marshal(message)
		if err != nil {
			logger.Error("Protobuf编码失败:", err)
			return err
		}
		//对消息进行封装+head+crc
		encodedMessage = createPacket(encodedMessage)
		// 发送TCP消息
		if ctrl.Conn == nil || ctrl.IsLogin == false {
			return nil
		}
		_, err = ctrl.Conn.Write(encodedMessage)
		if err != nil {
			logger.Error("发送TCP消息失败:", err)
			return err
		}

		return nil
	})
}

func (ctrl *CloudTcpCli) ReportRadarBeamConfigMsg() {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	_, _ = mq.RadarBeamConfigBroker.Subscribe(mq.RadarBeamConfigTopic, func(event broker2.Event) error {
		//logger.Debug("Receive Radar beam")
		comCli := &client.ClientReport{}
		err := proto.Unmarshal(event.Message().Body, comCli)
		if err != nil {
			logger.Error("radar beam Cli Unmarshal err:", err)
			return err
		}
		beam := &client.RadarBeamSteerConfig{}
		err = proto.Unmarshal(comCli.Data, beam)
		if err != nil {
			logger.Error("radar beam Unmarshal err:", err)
			return err
		}
		//给云端发送
		beamData := make([]*cloudPlatform.RadarBeamConfigData, 0)
		beamData = append(beamData, &cloudPlatform.RadarBeamConfigData{
			Sn:            beam.Header.Sn,
			AziScanCenter: beam.Data.AziScanCenter,
			AziScanScope:  beam.Data.AziScanScope,
			EleScanCenter: beam.Data.EleScanCenter,
			EleScanScope:  beam.Data.EleScanScope,
			CreateTime:    time.Now().UnixMilli(),
			ScanRadius:    beam.Data.RadarScanRadius,
		})
		logger.Debug("beamData =", beamData)
		beamMessage := &cloudPlatform.RadarBeamConfigList{
			Body: beamData,
		}
		// encodedMessage
		encodedMessage, err := proto.Marshal(beamMessage)
		if err != nil {
			logger.Error("Protobuf编码失败:", err)
			return fmt.Errorf("report Radar posture Marshal encodedMessage error: %v", err)
		}

		// 构建Message消息
		message := &cloudPlatform.Message{
			BaseInfo: &cloudPlatform.BaseInfo{
				MsgId:     1,
				Url:       RADAR_BEAM_URL,
				Sn:        ctrl.C2Sn, //ctrl.C2Sn
				MsgType:   MSG_TYPE_REQUEST,
				ErrorCode: 0,
				LoginId:   ctrl.LoginId,
			},
			Data: encodedMessage,
		}
		// 对Message进行Protobuf编码
		encodedMessage, err = proto.Marshal(message)
		if err != nil {
			logger.Error("Protobuf编码失败:", err)
			return err
		}
		//对消息进行封装+head+crc
		encodedMessage = createPacket(encodedMessage)
		// 发送TCP消息
		if ctrl.Conn == nil || ctrl.IsLogin == false {
			return nil
		}
		_, err = ctrl.Conn.Write(encodedMessage)
		if err != nil {
			logger.Error("发送TCP消息失败:", err)
			return err
		}

		return nil
	})
}

func (ctrl *CloudTcpCli) ReportRadarUavMsg() {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	//logger.Debug(".")
	mu := sync.Mutex{}
	_, _ = mq.RadarTrackBroker.Subscribe(mq.RadarTrackTopic, func(event broker2.Event) error {
		entity := common.EquipmentMessageBoxEntity{}
		err := jsoniter.Unmarshal(event.Message().Body, &entity)
		if err != nil {
			return fmt.Errorf(" Report Radar Uav Unmarshal error: %v", err)
		}
		infoJson, _ := jsoniter.Marshal(entity.Info)
		trackTarget := make([]bean.RadarTcpTrackTarget, 0)
		//logger.Debug("start Unmarshal")
		err = jsoniter.Unmarshal(infoJson, &trackTarget)
		if err != nil {
			if EnableLogInvildJSON {
				logger.Debug("report Radar Posture  Unmarshal info error: %v", err)
			}
			return fmt.Errorf(" Report Radar Uav Unmarshal info error: %v", err)
		}

		mu.Lock()
		defer mu.Unlock()
		//给云端发送
		temp := time.Now().UnixMilli()
		uavData := make([]*cloudPlatform.RadarUavData, 0)
		for _, uavInfo := range trackTarget {
			uavInfo.Sn = entity.Sn
			uavData = append(uavData, &cloudPlatform.RadarUavData{
				ObjId:          int32(uavInfo.Obj_id),
				Sn:             uavInfo.Sn,
				X:              uavInfo.X,
				Y:              uavInfo.Y,
				Z:              uavInfo.Z,
				Velocity:       uavInfo.Velocity,
				Azimuth:        uavInfo.Azimuth,
				Alive:          int32(uavInfo.Alive),
				ExistingProb:   float64(uavInfo.ExistingProb),
				StateType:      int32(uavInfo.State_type),
				CreateTime:     temp,
				Classification: int32(uavInfo.Classification),
				ClassifyProb:   int32(uavInfo.Classfy_prob),
				Longitude:      uavInfo.Longitude,
				Latitude:       uavInfo.Latitude,
				DroneName:      uavInfo.DroneName,
			})
		}
		logger.Debug("uavData = ", uavData)
		uavMessage := &cloudPlatform.RadarUavList{
			Body: uavData,
		}

		// encodedMessage
		encodedMessage, err := proto.Marshal(uavMessage)
		if err != nil {
			logger.Error("Protobuf编码失败:", err)
			return fmt.Errorf("report Radar uav Marshal encodedMessage error: %v", err)
		}

		// 构建Message消息
		message := &cloudPlatform.Message{
			BaseInfo: &cloudPlatform.BaseInfo{
				MsgId:     1,
				Url:       RADAR_UAV_URL,
				Sn:        ctrl.C2Sn, //ctrl.C2Sn
				MsgType:   MSG_TYPE_REQUEST,
				ErrorCode: 0,
				LoginId:   ctrl.LoginId,
			},
			Data: encodedMessage,
		}
		// 对Message进行Protobuf编码
		encodedMessage, err = proto.Marshal(message)
		if err != nil {
			logger.Error("Protobuf编码失败:", err)
			return err
		}
		//对消息进行封装+head+crc
		encodedMessage = createPacket(encodedMessage)
		// 发送TCP消息
		if ctrl.Conn == nil || ctrl.IsLogin == false {
			return nil
		}

		_, err = ctrl.Conn.Write(encodedMessage)

		if err != nil {
			logger.Error("发送TCP消息失败:", err)
			return err
		}
		return nil
	})
}

func (ctrl *CloudTcpCli) ReportTracerHeartMsg() {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	//Tracer心跳
	//logger.Info(".")
	mu := sync.Mutex{}
	_, _ = mq.EquipmentStatusBroker.Subscribe(mq.V2DroneIdTopic, func(event broker2.Event) error {
		entity := common.EquipmentMessageBoxEntity{}
		err := jsoniter.Unmarshal(event.Message().Body, &entity)
		if err != nil {
			return fmt.Errorf(" Report Tracer Heart Unmarshal error: %v", err)
		}
		if entity.MsgType == 0 {
			return nil
		}
		infoJson, _ := jsoniter.Marshal(entity.Info)
		heart := &mavlink.DroneIDReport{}
		//logger.Debug("start Unmarshal")
		err = jsoniter.Unmarshal(infoJson, &heart)
		if err != nil {
			if EnableLogInvildJSON {
				logger.Debug("report Radar Posture  Unmarshal info error: %v", err)
			}
			return fmt.Errorf(" Report Tracer Heart Unmarshal info error: %v", err)
		}
		heart.Sn = entity.Sn
		mu.Lock()
		defer mu.Unlock()

		if heart.IsOnline == 0 {
			heart.IsOnline = 1
		} else if heart.IsOnline == 1 {
			heart.IsOnline = 2
		}
		//给云端发送
		heartData := make([]*cloudPlatform.TraceHeartData, 0)
		heartData = append(heartData, &cloudPlatform.TraceHeartData{
			Sn:            heart.Sn,
			Online:        int32(heart.IsOnline), //1在线、2离线
			Electricity:   int32(heart.Electricity),
			WorkMode:      int32(heart.WorkMode),
			WorkStatus:    int32(heart.WorkStatus),
			AlarmLevel:    int32(heart.AlarmLevel),
			CreateTime:    time.Now().UnixMilli(),
			BuzzerOn:      int32(heart.BuzzerOn),
			VibrationOn:   int32(heart.VibrationOn),
			StealthModeOn: int32(heart.StealthModeOn),
			TracerType:    int32(heart.TracerType),
		})
		logger.Debug("heartData = ", heartData)
		heartMessage := &cloudPlatform.TraceHeartList{
			Body: heartData,
		}

		if _, ok := down.GTracerPropertyStatus.Load(heart.Sn); !ok {
			logger.Debug("fisrt heartData = ", heartData)
			down.GTracerPropertyStatus.Store(heart.Sn, common.Drone)
		}

		// encodedMessage
		encodedMessage, err := proto.Marshal(heartMessage)
		if err != nil {
			logger.Error("Protobuf编码失败:", err)
			return fmt.Errorf("report Radar Heart Marshal encodedMessage error: %v", err)
		}

		// 构建Message消息
		message := &cloudPlatform.Message{
			BaseInfo: &cloudPlatform.BaseInfo{
				MsgId:     1,
				Url:       TRACER_HEART_URL,
				Sn:        ctrl.C2Sn, //ctrl.C2Sn
				MsgType:   MSG_TYPE_REQUEST,
				ErrorCode: 0,
				LoginId:   ctrl.LoginId,
			},
			Data: encodedMessage,
		}
		// 对Message进行Protobuf编码
		encodedMessage, err = proto.Marshal(message)
		if err != nil {
			logger.Error("Protobuf编码失败:", err)
			return err
		}
		//对消息进行封装+head+crc
		encodedMessage = createPacket(encodedMessage)
		// 发送TCP消息
		if ctrl.Conn == nil || ctrl.IsLogin == false {
			return nil
		}
		_, err = ctrl.Conn.Write(encodedMessage)
		if err != nil {
			logger.Error("发送TCP消息失败:", err)
			ctrl.clearConn()
			return err
		}

		return nil
	})
}

func (ctrl *CloudTcpCli) ReportTracerUavMsg() {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	//logger.Info(".")
	mu := sync.Mutex{}
	_, _ = mq.V2DroneIdBroker.Subscribe(mq.TracerDetectTopic, func(event broker2.Event) error {

		entity := common.EquipmentMessageBoxEntity{}
		err := jsoniter.Unmarshal(event.Message().Body, &entity)
		if err != nil {
			return fmt.Errorf(" Report Tracer Uav Unmarshal error: %v", err)
		}
		infoJson, _ := jsoniter.Marshal(entity.Info)
		uavData := make([]*cloudPlatform.TraceUavData, 0)
		if entity.MsgType == mavlink.TracerIdGetDetectRes {
			drone := &mavlink.TracerDetectReport{}
			err = jsoniter.Unmarshal(infoJson, &drone)
			if err != nil {
				if EnableLogInvildJSON {
					logger.Debug(" Report Tracer Uav Unmarshal info error: %v", err)
				}
				return fmt.Errorf(" Report Tracer Uav Unmarshal info error: %v", err)
			}
			mu.Lock()
			defer mu.Unlock()
			//给云端发送
			temp := time.Now().UnixMilli()
			for _, uavInfo := range drone.Description {
				uavData = append(uavData, &cloudPlatform.TraceUavData{
					Sn:                drone.Sn,
					MsgType:           1,
					OperatorLongitude: uavInfo.OperatorLongitude,
					OperatorLatitude:  uavInfo.OperatorLatitude,
					Freq:              uavInfo.Freq,
					Distance:          float64(uavInfo.Distance),
					DangerLevels:      int32(uavInfo.DangerLevels),
					Role:              uavInfo.Role,
					DroneName:         uavInfo.DroneName,
					SerialNum:         uavInfo.SerialNum,
					DroneLongitude:    uavInfo.DroneLongitude,
					DroneLatitude:     uavInfo.DroneLatitude,
					DroneHeight:       uavInfo.DroneHeight,
					DroneSpeed:        uavInfo.DroneSpeed,
					DroneYawAngle:     uavInfo.DroneYawAngle,
					CreateTime:        temp,
					DroneType:         uavInfo.DroneType,
				})
			}

		} else if entity.MsgType == mavlink.TracerIdGetRemoteIdDetectRes {
			drone := &mavlink.TracerRemoteDetectReport{}
			err = jsoniter.Unmarshal(infoJson, &drone)
			if err != nil {
				return fmt.Errorf(" Report Tracer Uav Unmarshal info error: %v", err)
			}
			mu.Lock()
			defer mu.Unlock()
			//给云端发送
			for _, uavInfo := range drone.Description {
				uavData = append(uavData, &cloudPlatform.TraceUavData{
					Sn:                drone.Sn,
					MsgType:           2,
					OperatorLongitude: uavInfo.OperatorLongitude,
					OperatorLatitude:  uavInfo.OperatorLatitude,
					Freq:              uavInfo.Freq,
					Distance:          float64(uavInfo.Distance),
					DangerLevels:      int32(uavInfo.DangerLevels),
					Role:              uavInfo.Role,
					DroneName:         uavInfo.DroneName,
					SerialNum:         uavInfo.SerialNum,
					DroneLongitude:    uavInfo.DroneLongitude,
					DroneLatitude:     uavInfo.DroneLatitude,
					DroneHeight:       uavInfo.DroneHeight,
					DroneSpeed:        uavInfo.DroneSpeed,
					DroneYawAngle:     uavInfo.DroneYawAngle,
					CreateTime:        time.Now().UnixMilli(),
					DroneType:         uavInfo.DroneType,
				})
			}

		} else if entity.MsgType == mavlink.TracerIdGetFreqDetectRes {
			drone := &mavlink.TracerFreqDetectReport{}
			err = jsoniter.Unmarshal(infoJson, &drone)
			if err != nil {
				return fmt.Errorf(" Report Tracer Uav Unmarshal info error: %v", err)
			}
			mu.Lock()
			defer mu.Unlock()
			//给云端发送
			for _, uavInfo := range drone.Description {
				uavData = append(uavData, &cloudPlatform.TraceUavData{
					Sn:           drone.Sn,
					MsgType:      3,
					QxPower:      drone.QxPower,
					DxPower:      drone.DxPower,
					DxHorizon:    drone.DxHorizon,
					UavNumber:    int32(uavInfo.UavNumber),
					DroneHorizon: uavInfo.DroneHorizon,
					Freq:         uavInfo.UFreq,
					DangerLevels: int32(uavInfo.UDangerLevels),
					DroneName:    uavInfo.DroneName,
					CreateTime:   time.Now().UnixMilli(),
					IsSptOrient:  int32(uavInfo.IsSptOrient),
					OrientState:  int32(uavInfo.OrientState),
					DroneType:    uavInfo.DroneType,
				})
			}
		}
		logger.Debugf("Report Tracer Uav Data: %v", uavData)
		uavMessage := &cloudPlatform.TraceUavList{
			Body: uavData,
		}
		// encodedMessage
		encodedMessage, err := proto.Marshal(uavMessage)
		if err != nil {
			logger.Error("Protobuf编码失败:", err)
			return fmt.Errorf("report Radar uav Marshal encodedMessage error: %v", err)
		}

		// 构建Message消息
		message := &cloudPlatform.Message{
			BaseInfo: &cloudPlatform.BaseInfo{
				MsgId:     1,
				Url:       TRACER_UAV_URL,
				Sn:        ctrl.C2Sn, //ctrl.C2Sn
				MsgType:   MSG_TYPE_REQUEST,
				ErrorCode: 0,
				LoginId:   ctrl.LoginId,
			},
			Data: encodedMessage,
		}
		// 对Message进行Protobuf编码
		encodedMessage, err = proto.Marshal(message)
		if err != nil {
			logger.Error("Protobuf编码失败:", err)
			return err
		}
		//对消息进行封装+head+crc
		encodedMessage = createPacket(encodedMessage)
		// 发送TCP消息
		if ctrl.Conn == nil || ctrl.IsLogin == false {
			return nil
		}
		_, err = ctrl.Conn.Write(encodedMessage)
		if err != nil {
			logger.Error("发送TCP消息失败:", err)
			return err
		}
		return nil
	})
}

func (ctrl *CloudTcpCli) ReportTracerUavPlusMsg() {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	mu := sync.Mutex{}
	_, _ = mq.V2DroneIdBroker.Subscribe(mq.TracerDetectTopic, func(event broker2.Event) error {

		entity := common.EquipmentMessageBoxEntity{}
		err := jsoniter.Unmarshal(event.Message().Body, &entity)
		if err != nil {
			return fmt.Errorf(" Report Tracer Uav Unmarshal error: %v", err)
		}
		infoJson, _ := jsoniter.Marshal(entity.Info)
		uavData := make([]*cloudPlatform.TraceUavPlusData, 0)
		logger.Debugf("entity.MsgType = %+v", entity.MsgType)
		if entity.MsgType == mavlink.TracerIdGetDronIdRemoteIdDetectRes {
			drone := &mavlink.TracerDronIdRemoteIdDetectReport{}
			err = jsoniter.Unmarshal(infoJson, &drone)
			logger.Debugf("drone = %+v", drone)
			if err != nil {
				if EnableLogInvildJSON {
					logger.Debug(" Report Tracer Uav Unmarshal info error: %v", err)
				}
				return fmt.Errorf(" Report Tracer Uav Unmarshal info error: %v", err)
			}
			mu.Lock()
			defer mu.Unlock()
			//给云端发送
			nowTime := time.Now()
			temp := nowTime.UnixMilli()
			if time.Since(gcheckC2ConfigTime).Seconds() > 10 || gIsFirstGetSysConfig {
				configInfo := &client.ConfigRes{}
				err := handler.NewSystemConfig().GetSystemConfig(context.Background(), &client.ConfigReq{}, configInfo)
				logger.Info("configInfo = ", configInfo)
				if err != nil {
					logger.Error("Get SystemConfig err: ", err)
				}
				gcheckC2ConfigTime = nowTime
				gIsFirstGetSysConfig = false
				gSysConfig.C2Latitude = configInfo.C2Latitude
				gSysConfig.C2Longitude = configInfo.C2Longitude
				gSysConfig.Height = configInfo.Height

			}
			srcLocation := util.LonLatLocation{
				Longitude: gSysConfig.C2Longitude,
				Latitude:  gSysConfig.C2Latitude,
				Altitude:  gSysConfig.Height,
			}

			for i, u := range drone.Description {
				dstLocation := util.LonLatLocation{
					Longitude: u.Longitude,
					Latitude:  u.Latitude,
					Altitude:  u.Altitude,
				}
				angle, err := util.CalcAngleByLocation(&srcLocation, &dstLocation)
				if err != nil {
					logger.Error("err = ", err)
				}
				uavData = append(uavData, &cloudPlatform.TraceUavPlusData{
					DroneName:         u.Name,
					SerialNum:         u.SerialNum,
					Direction:         u.Direction,
					Speed:             u.Speed,
					VerticalSpeed:     u.VerticalSpeed,
					Height:            u.Height,
					Longitude:         u.Longitude,
					Latitude:          u.Latitude,
					PilotLongitude:    u.PilotLongitude,
					PilotLatitude:     u.PilotLatitude,
					HomeLongitude:     u.HomeLongitude,
					HomeLatitude:      u.HomeLatitude,
					Altitude:          u.Altitude,
					SignalFreqDid:     u.SignalFreqDid,
					SignalPowerDidCh1: int32(u.SignalPowerDidCh1),
					SignalPowerDidCh2: int32(u.SignalPowerDidCh2),
					SN:                drone.Sn,
					CreateTime:        temp,
					Azimuth:           angle.AzimuthAngle,
					Elevation:         angle.PitchAngle,
					GpsClock:          u.GpsClock,
					TimestampRid:      u.TimestampRid,
					TargetMask:        int32(u.TargetMask),
					DroneType:         u.DroneType,
				})
				logger.Debugf("uavData = ", uavData[i])
			}

		}
		uavMessage := &cloudPlatform.TraceUavPlusList{
			Body: uavData,
		}
		// encodedMessage
		encodedMessage, err := proto.Marshal(uavMessage)
		if err != nil {
			logger.Error("Protobuf编码失败:", err)
			return fmt.Errorf("report Radar uav Marshal encodedMessage error: %v", err)
		}

		// 构建Message消息
		message := &cloudPlatform.Message{
			BaseInfo: &cloudPlatform.BaseInfo{
				MsgId:     1,
				Url:       TRACER_UAV_PLUS_URL,
				Sn:        ctrl.C2Sn, //ctrl.C2Sn
				MsgType:   MSG_TYPE_REQUEST,
				ErrorCode: 0,
				LoginId:   ctrl.LoginId,
			},
			Data: encodedMessage,
		}
		// 对Message进行Protobuf编码
		encodedMessage, err = proto.Marshal(message)
		if err != nil {
			logger.Error("Protobuf编码失败:", err)
			return err
		}
		//对消息进行封装+head+crc
		encodedMessage = createPacket(encodedMessage)
		// 发送TCP消息
		if ctrl.Conn == nil || ctrl.IsLogin == false {
			return nil
		}
		_, err = ctrl.Conn.Write(encodedMessage)
		if err != nil {
			logger.Error("发送TCP消息失败:", err)
			return err
		}
		return nil
	})
}

func (ctrl *CloudTcpCli) ReportTracerUavSystemMsg() {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	logger.Info("reportTracerUavSystemList to cloud")
	mu := sync.Mutex{}
	_, _ = mq.V2DroneIdBroker.Subscribe(mq.TracerDetectTopic, func(event broker2.Event) error {
		logger.Info("report TracerUavSystem List")
		entity := common.EquipmentMessageBoxEntity{}
		err := jsoniter.Unmarshal(event.Message().Body, &entity)
		if err != nil {
			return fmt.Errorf(" Report TraceUavSystemList Unmarshal error: %v", err)
		}
		infoJson, _ := jsoniter.Marshal(entity.Info)
		uavData := make([]*cloudPlatform.TraceUavSystemData, 0)
		if entity.MsgType == mavlink.TracerIdGetUasSystemInfoRes {
			drone := &mavlink.TracerDetectUavSystemDataReport{}
			err = jsoniter.Unmarshal(infoJson, &drone)
			if err != nil {
				if EnableLogInvildJSON {
					logger.Debug(" Report TraceUavSystemList Unmarshal info error: %v", err)
				}
				return fmt.Errorf(" Report Tracer Uav Unmarshal info error: %v", err)
			}
			mu.Lock()
			defer mu.Unlock()
			//给云端发送
			temp := time.Now().UnixMilli()
			uavData = append(uavData, &cloudPlatform.TraceUavSystemData{
				Sn:         drone.Sn,
				Data:       drone.Description,
				CreateTime: temp,
			})

		}
		uavMessage := &cloudPlatform.TraceUavSystemList{
			Body: uavData,
		}
		// encodedMessage
		encodedMessage, err := proto.Marshal(uavMessage)
		if err != nil {
			logger.Error("Protobuf编码失败:", err)
			return fmt.Errorf("reportTraceUavSystemList Marshal encodedMessage error: %v", err)
		}

		// 构建Message消息
		message := &cloudPlatform.Message{
			BaseInfo: &cloudPlatform.BaseInfo{
				MsgId:     1,
				Url:       TRACER_UAV_TRANSMIT_URL,
				Sn:        ctrl.C2Sn, //ctrl.C2Sn
				MsgType:   MSG_TYPE_REQUEST,
				ErrorCode: 0,
				LoginId:   ctrl.LoginId,
			},
			Data: encodedMessage,
		}
		// 对Message进行Protobuf编码
		encodedMessage, err = proto.Marshal(message)
		if err != nil {
			logger.Error("Protobuf编码失败:", err)
			return err
		}
		//对消息进行封装+head+crc
		encodedMessage = createPacket(encodedMessage)
		// 发送TCP消息
		if ctrl.Conn == nil || ctrl.IsLogin == false {
			return nil
		}
		_, err = ctrl.Conn.Write(encodedMessage)
		if err != nil {
			logger.Error("发送TCP消息失败:", err)
			return err
		}
		logger.Info("report TracerUavSystem Suc")
		return nil
	})
}

func (ctrl *CloudTcpCli) ReportGunHeartMsg() {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	logger.Info(".")
	mu := sync.Mutex{}
	_, _ = mq.GunDroneIdBroker.Subscribe(mq.GunDroneIdTopic, func(event broker2.Event) error {

		entity := common.EquipmentMessageBoxEntity{}
		err := jsoniter.Unmarshal(event.Message().Body, &entity)
		if err != nil {
			return fmt.Errorf("consumeDroneHeartInfo Unmarshal error: %v", err)
		}
		infoJson, _ := jsoniter.Marshal(entity.Info)
		drone := &DroneIdHeartBeat{}
		err = jsoniter.Unmarshal(infoJson, &drone)
		if err != nil {
			if EnableLogInvildJSON {
				logger.Debug("consumeDroneHeartInfo Unmarshal info error: %v", err)
			}
			return fmt.Errorf("consumeDroneHeartInfo Unmarshal info error: %v", err)
		}
		mu.Lock()
		defer mu.Unlock()
		//给云端发送
		heartData := make([]*cloudPlatform.GunHeartData, 0)
		uavData := make([]*cloudPlatform.GunUavData, 0)
		tempSn := drone.Sn
		for _, uavInfo := range drone.Info {
			uavData = append(uavData, &cloudPlatform.GunUavData{
				Sn:                 tempSn,
				ProductType:        int32(uavInfo.ProductType),
				DroneName:          uavInfo.DroneName,
				SerialNum:          uavInfo.SerialNum,
				DroneLongitude:     uavInfo.DroneLongitude,
				DroneLatitude:      uavInfo.DroneLatitude,
				DroneHeight:        uavInfo.DroneHeight,
				DroneYawAngle:      uavInfo.DroneYawAngle,
				DroneSpeed:         uavInfo.DroneSpeed,
				DroneVerticalSpeed: uavInfo.DroneVerticalSpeed,
				PilotLongitude:     uavInfo.PilotLongitude,
				PilotLatitude:      uavInfo.PilotLatitude,
				UFreq:              uavInfo.UFreq,
				UDistance:          int32(uavInfo.UDistance),
				UDangerLevels:      int32(uavInfo.UDangerLevels),
				CreateTime:         time.Now().UnixMilli(),
			})
		}
		logger.Debug("entity.MsgType  = ", entity.MsgType)
		uavMessage := &cloudPlatform.GunUavList{
			Body: uavData,
		}
		// encodedMessage
		encodedMessage, err := proto.Marshal(uavMessage)
		if err != nil {
			logger.Error("Protobuf编码失败:", err)
			return fmt.Errorf("report Radar uav Marshal encodedMessage error: %v", err)
		}

		// 构建Message消息
		message := &cloudPlatform.Message{
			BaseInfo: &cloudPlatform.BaseInfo{
				MsgId:     1,
				Url:       GUN_UAV_URL,
				Sn:        ctrl.C2Sn, //ctrl.C2Sn
				MsgType:   MSG_TYPE_REQUEST,
				ErrorCode: 0,
				LoginId:   ctrl.LoginId,
			},
			Data: encodedMessage,
		}
		// 对Message进行Protobuf编码
		encodedMessage, err = proto.Marshal(message)
		if err != nil {
			logger.Error("Protobuf编码失败:", err)
			return err
		}
		//对消息进行封装+head+crc
		encodedMessage = createPacket(encodedMessage)
		// 发送TCP消息
		if ctrl.Conn == nil || ctrl.IsLogin == false {
			return nil
		}

		_, err = ctrl.Conn.Write(encodedMessage)

		if err != nil {
			logger.Error("发送TCP消息失败:", err)
			return err
		}
		heartData = append(heartData, &cloudPlatform.GunHeartData{
			Sn:          tempSn,
			Online:      1,
			Electricity: int32(drone.Electricity),
			WorkStatus:  int32(drone.WorkStatus),
			AlarmLevel:  int32(drone.AlarmLevel),
			CreateTime:  time.Now().UnixMilli(),
		})

		uavMessage1 := &cloudPlatform.GunUavList{
			Body: uavData,
		}
		// encodedMessage
		encodedMessage1, err := proto.Marshal(uavMessage1)
		if err != nil {
			logger.Error("Protobuf编码失败:", err)
			return fmt.Errorf("report Radar uav Marshal encodedMessage error: %v", err)
		}

		// 构建Message消息
		message1 := &cloudPlatform.Message{
			BaseInfo: &cloudPlatform.BaseInfo{
				MsgId:     1,
				Url:       GUN_HEART_URL,
				Sn:        ctrl.C2Sn, //ctrl.C2Sn
				MsgType:   MSG_TYPE_REQUEST,
				ErrorCode: 0,
			},
			Data: encodedMessage1,
		}
		// 对Message进行Protobuf编码
		encodedMessage1, err = proto.Marshal(message1)
		if err != nil {
			logger.Error("Protobuf编码失败:", err)
			return err
		}
		//对消息进行封装+head+crc
		encodedMessage1 = createPacket(encodedMessage1)
		// 发送TCP消息
		if ctrl.Conn == nil {
			return nil
		}

		_, err = ctrl.Conn.Write(encodedMessage1)

		if err != nil {
			logger.Error("发送TCP消息失败:", err)
			return err
		}
		return nil
	})
}

type DroneIdHeartBeat struct {
	TimeStamp      uint32                `json:"timeStamp"`
	Sn             string                `json:"sn"`
	ScreenStatus   uint8                 `json:"screenStatus"`
	Electricity    uint8                 `json:"electricity"`
	SignalStrength uint8                 `json:"signalStrength"`
	WorkStatus     uint8                 `json:"workStatus"`
	AlarmLevel     uint8                 `json:"alarmLevel"`
	HitFreq        uint8                 `json:"hitFreq"`
	DetectFreq     uint32                `json:"detectFreq"`
	X              uint16                `json:"x"`
	Y              uint16                `json:"y"`
	Z              uint16                `json:"z"`
	GunLongitude   float64               `json:"gunLongitude"`
	GunLatitude    float64               `json:"gunLatitude"`
	GunAltitude    int32                 `json:"gunAltitude"`
	SatellitesNum  uint16                `json:"satellitesNum"`
	GunDirection   float64               `json:"gunDirection"`
	UDroneNum      uint8                 `json:"uDroneNum"`
	Elevation      float64               `json:"elevation"`
	Info           []bean.GunTcpHeartUav `json:"info"`
}

func (ctrl *CloudTcpCli) ReportGunUavMsg() {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()

}

func (ctrl *CloudTcpCli) ReportC2EquipMsg() {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	_, _ = mq.EquipmentBroker.Subscribe(mq.EquipmentUpdateTopic, func(event broker2.Event) error {
		//logger.Debug("event.Message().Body = ", event.Message().Body)
		entity := client.Equip{}
		err := proto.Unmarshal(event.Message().Body, &entity)
		if err != nil {
			return fmt.Errorf("ReportC2EquipMsg Unmarshal error: %v", err)
		}
		equipData := make([]*cloudPlatform.Equip, 0)
		equipData = append(equipData, &cloudPlatform.Equip{
			Id:             int32(entity.Id),
			Etype:          entity.Etype,
			Ip:             entity.Ip,
			Vendor:         "",
			Name:           entity.Name,
			Sn:             entity.Sn,
			Enable:         entity.Enable,
			RadarRelevance: entity.RadarRelevance,
			ParentSn:       entity.ParentSn,
			CreateTime:     time.Now().UnixMilli(),
		})

		logger.Debug("equipData =  ", equipData)
		equipMessage := &cloudPlatform.EquipList{
			Body: equipData,
		}
		// encodedMessage
		encodedMessage, err := proto.Marshal(equipMessage)
		if err != nil {
			logger.Error("Protobuf编码失败:", err)
			return err
		}

		// 构建Message消息
		message := &cloudPlatform.Message{
			BaseInfo: &cloudPlatform.BaseInfo{
				MsgId:     1,
				Url:       C2_EQUIP_LIST_URL,
				Sn:        ctrl.C2Sn, //ctrl.C2Sn
				MsgType:   MSG_TYPE_REQUEST,
				ErrorCode: 0,
				LoginId:   ctrl.LoginId,
			},
			Data: encodedMessage,
		}
		// 对Message进行Protobuf编码
		encodedMessage, err = proto.Marshal(message)
		if err != nil {
			logger.Error("Protobuf编码失败:", err)
			return err
		}
		//对消息进行封装+head+crc
		encodedMessage = createPacket(encodedMessage)
		// 发送TCP消息
		if ctrl.Conn == nil || ctrl.IsLogin == false {
			return nil
		}
		_, err = ctrl.Conn.Write(encodedMessage)
		if err != nil {
			logger.Error("发送TCP消息失败:", err)
			return err
		}
		return nil
	})
}

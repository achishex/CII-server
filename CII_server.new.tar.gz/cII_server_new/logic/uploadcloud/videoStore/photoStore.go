package videostore

import (
	"fmt"
	"os/exec"
	"strings"
	"sync"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/credentials"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/s3"
	ffmpeg "github.com/u2takey/ffmpeg-go"
)

const (
	Uploading  = 1
	UploadDone = 2
)

// PhotoDetail  ...
type PhotoDetail struct {
	URL          string
	DevSN        string
	UploadStatus int32
	TimeStamp    int64
	DownloadUrl  string
	Bucket       string
}

// UavPhotoMsg ...
type UavPhotoMsg struct {
	DevSn          string
	Classification int32
	ObjID          int32
	S3PrePath      string
}

type GPhotoMapT struct {
	m map[string]PhotoDetail
	sync.RWMutex
}

func (m *GPhotoMapT) set(k string, v PhotoDetail) {
	defer m.Unlock()
	m.Lock()
	m.m[k] = v
}
func (m *GPhotoMapT) delete(k string) {
	defer m.Unlock()
	m.Lock()
	delete(m.m, k)
}
func (m *GPhotoMapT) Get(k string) (PhotoDetail, bool) {
	defer m.RUnlock()
	m.RLock()
	if val, ok := m.m[k]; ok {
		return val, true
	}
	return PhotoDetail{}, false
}

var (
	//GPhotoMap key: devSn + classification + objId ; value: PhotoDetail
	// GPhotoMap = map[string]PhotoDetail{}
	// photoMap  = make(map[string]PhotoDetail)
	GPhotoMap = GPhotoMapT{m: make(map[string]PhotoDetail)}
)

func (v *videoS3Object) GenDownloadUrl(path string) (string, error) {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("error : %v", r)
			logger.Error("error:", err)
		}
	}()

	Ak := gstaticS3Token.ak
	Sk := gstaticS3Token.sk
	Region := gstaticS3Token.region
	Bucket := gstaticS3Token.bucket
	token := gstaticS3Token.token

	sess := session.Must(session.NewSession())

	svc := s3.New(sess, &aws.Config{
		Region:      aws.String(Region),
		Credentials: credentials.NewStaticCredentials(Ak, Sk, token),
	})

	// 生成预签名URL的请求
	req, _ := svc.GetObjectRequest(&s3.GetObjectInput{
		Bucket: &Bucket, // 替换为你的S3桶名称
		Key:    &path,   // 替换为你想要下载的对象的键
	})

	urlStr, err := req.Presign(60 * time.Minute)
	if err != nil {
		fmt.Println("Failed to sign request,", err)
		return "", err
	}
	fmt.Println("The pre-signed URL is:", urlStr)
	return urlStr, nil

}

type VideoCheck struct {
	chkTime time.Time
	status  int //0: first check 1:video ok 2:video not found
}

func ping(ip string) bool {
	// 执行 ping 命令
	cmd := exec.Command("ping", ip)
	output, err := cmd.CombinedOutput()
	if err != nil {
		fmt.Println("Error:", err)
		return false
	}

	// 检查输出中是否包含 "0% packet loss" 来确定是否ping通
	if strings.Contains(string(output), "TTL=") {
		return true
	}
	fmt.Println("output = ", string(output))
	return false
}

var gFfmpegVideoCheck = VideoCheck{chkTime: time.Now(), status: 0}
var gFfmpegVideoIp = "192.168.2.4"

func isExistVideoStream() bool {
	if gFfmpegVideoCheck.status == 0 {
		gFfmpegVideoCheck.status = 2
		if ping(gFfmpegVideoIp) {
			gFfmpegVideoCheck.status = 1
			return true
		}
		return false

	}
	if time.Since(gFfmpegVideoCheck.chkTime) < 3*time.Minute {
		if gFfmpegVideoCheck.status == 1 {
			return true
		}
		return false
	} else {
		gFfmpegVideoCheck.chkTime = time.Now()
		if ping(gFfmpegVideoIp) {
			gFfmpegVideoCheck.status = 1
			return true
		}
		gFfmpegVideoCheck.status = 2
		return false
	}
}

func (v *videoS3Object) GoSaveToLocalPhotoAndPushToS3(uavPhoto UavPhotoMsg) error {
	logger.Debugf("start gen photo url: %+v", uavPhoto)
	go func() {
		defer func() {
			if r := recover(); r != nil {
				err := fmt.Sprintf("SaveToLocalVideo : %v", r)
				logger.Error("PushToS3 :", err)
			}
		}()
		if !isExistVideoStream() {
			return
		}
		KID := fmt.Sprintf("%s_%d_%d", uavPhoto.DevSn, uavPhoto.Classification, uavPhoto.ObjID)
		localPath := fmt.Sprintf("%s_%d.jpg", KID, time.Now().UnixMilli())
		remotePath := fmt.Sprintf("%s%s-%s", uavPhoto.S3PrePath, gstaticS3Token.prefix, localPath)
		logger.Debug("localPath = ", localPath, "  remotePath = ", remotePath)
		var updateStatus PhotoDetail
		updateStatus.DevSN = uavPhoto.DevSn
		updateStatus.URL = remotePath
		updateStatus.UploadStatus = Uploading
		updateStatus.Bucket = gstaticS3Token.bucket
		isOldPhotoExit := false
		// if _, ok := GPhotoMap[KID]; !ok {
		if _, ok := GPhotoMap.Get(KID); !ok {
			//上次不存在图片，存储状态为更新中
			// GPhotoMap[KID] = updateStatus
			GPhotoMap.set(KID, updateStatus)
		} else {
			isOldPhotoExit = true
		}
		err := v.saveToLocalPhoto(localPath)
		if err != nil {
			logger.Error("saveToLocalVideo err = ", err)
			if !isOldPhotoExit {
				// delete(GPhotoMap, KID)
				GPhotoMap.delete(KID)
			}

		} else {
			var err error
			if gstaticS3Token.token != "" {
				logger.Error("gstaticS3Token.token is nil ", gstaticS3Token.token)
				err = v.PushToS3WithToken(localPath, remotePath, true)
			} else {
				err = v.PushToS3(localPath, remotePath, true)
			}
			downloadPath, err := v.GenDownloadUrl(remotePath)
			if err != nil {
				logger.Error("gen download url fail,err = ", err)
				// delete(GPhotoMap, KID)
				if !isOldPhotoExit {
					// delete(GPhotoMap, KID)
					GPhotoMap.delete(KID)
				}
			} else {
				logger.Debug("gen download url ok, downloadpath = ", downloadPath)
				updateStatus.DownloadUrl = downloadPath
			}
			if err != nil {
				logger.Error("push photo err = ", err)
				// delete(GPhotoMap, KID)
				if !isOldPhotoExit {
					// delete(GPhotoMap, KID)
					GPhotoMap.delete(KID)
				}
			} else {
				updateStatus.UploadStatus = UploadDone
				updateStatus.TimeStamp = time.Now().UnixMilli()
				// GPhotoMap[KID] = updateStatus
				GPhotoMap.set(KID, updateStatus)
			}
		}
	}()

	return nil
}

func (v *videoS3Object) saveToLocalPhoto(outputImage string) error {
	defer func() {
		if r := recover(); r != nil {
			logger.Debug("panic: checkVideo", r)
		}
	}()

	pullffmpeg := "tools\\ffmpeg.exe"
	logger.Debug("pullffmpeg = ", pullffmpeg)

	VideoURL := "rtsp://admin:Autel123@192.168.2.4:554/channel=0,stream=0"
	err := ffmpeg.Input(VideoURL).Output(outputImage, ffmpeg.KwArgs{"vframes": 1, "q:v": 2}).
		SetFfmpegPath(pullffmpeg).OverWriteOutput().WithTimeout(time.Duration(9 * int64(time.Second))).Run()
	if err != nil {
		logger.Debug("save local photo faild ....")
		return err
	}
	logger.Debug("save local photo success,outputImage = ", outputImage)
	return nil
}

// ffmpeg -i rtsp://admin:Autel123@192.168.2.4:554/channel=0,stream=0 -vframes 1 -q:v 2 output.jpg

//rtsp://admin:Autel123@192.168.2.4:554/channel=0,stream=0

package videostore

import (
	"fmt"
	"testing"

	"adasgitlab.autel.com/tools/cuav_plugin/config/file"
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/config"
	"adasgitlab.autel.com/tools/cuav_server/logic/uploadcloud/mqtt"
	"adasgitlab.autel.com/tools/cuav_server/test"
)

func doCaptureT() {
	test.LoggerMock()
	go func() {
		cuavConfigFile := "../../../config/cuav-config.yaml"
		cfg := file.NewConfig(cuavConfigFile)
		err := cfg.Init(config.GetGlobalConfig())
		if err != nil {
			fmt.Println("初始化配置失败：", err)
			return
		}
		InitVideoStoreInstance()
		VsSingleton.doCapture("fakeC2Sn", "fakeCn", "C:\\Users\\a23543\\Videos\\agx\\TO_30_2_-1816037944067551232@1721810572142.mp4", "fakeEventID")
	}()

	s := mqtt.NewAdaptorWithAuth("cn.cloud.skyfend.com:30010", "C2@3fdfcaa0-f546-4653-9c66-a8e6bc7bc1b0@c2app129233", "3fdfcaa0-f546-4653-9c66-a8e6bc7bc1b0", "3fdfcaa0-f546-4653-9c66-a8e6bc7bc1b0")

	s.AddSubHandlers(nil)
	cRet := s.Connect()
	logger.Debug("cRet = ", cRet)
	PubEventImageToMqtt(s, "3fdfcaa0-f546-4653-9c66-a8e6bc7bc1b0")
}

func TestDoCapture(t *testing.T) {
	// doCaptureT()
}

//go:build !windows
// +build !windows

package videostore

import (
	"crypto/md5"
	"encoding/csv"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"os/exec"
	"runtime"
	"runtime/debug"
	"strconv"
	"strings"
	"sync"
	"time"

	"adasgitlab.autel.com/tools/cuav_plugin/broker"
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/config"
	"adasgitlab.autel.com/tools/cuav_server/logic/uploadcloud/mqtt"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/proto/mavlink"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
	uuid "github.com/satori/go.uuid"
	ffmpeg "github.com/u2takey/ffmpeg-go"
	"google.golang.org/protobuf/proto"
)

type eventLog struct {
	*csv.Writer
	FileName string
}

const (
	awsS3   = 1
	minioS3 = 2
)

type s3Config struct {
	BucketName string
	Region     string
	Ak         string
	Sk         string
	StoreType  int64
	Endpoint   string
}

type videoConfig struct {
	//本地视频流地址
	InVideoURL string
	//视频最大保存时间
	MaxTime string
	//ffmpeg 文件路径
	FfmpegPath string
}
type storeConfig struct {
	videoConfig
	S3Con s3Config
}

type videoS3Object struct {
	//本地视频流地址
	InVideoURL string
	//视频最大保存时间
	MaxTime string
	//ffmpeg 文件路径
	FfmpegPath string
	EventMap   sync.Map
	Log        eventLog
	S3Con      s3Config
}

const (
	autoExit    = "autoExit"
	outTimeExit = "outTimeExit"
)

var GPreFixS3 = "TO_30_2_"
var IsHasPrefix = false

const (
	mqtt_V3 int32 = 3
)

type tokenS3 struct {
	bucket   string
	ak       string
	sk       string
	token    string
	provider string
	region   string
	prefix   string
}

var (
	gstaticS3Token tokenS3
)
var vsSingletonOnce sync.Once

// VsSingleton ...
var VsSingleton *videoS3Object

// InitVideoStoreInstance ...
func InitVideoStoreInstance() {
	var videoLogPath string
	v := storeConfig{}
	logger.Debugf("Initializing video,config.GetGlobalConfig().AgxPTZ =", config.GetGlobalConfig().AgxPTZ)
	if config.GetGlobalConfig().AgxPTZ != nil {
		if len(config.GetGlobalConfig().AgxPTZ.VideoURL) != 0 {
			v.InVideoURL = config.GetGlobalConfig().AgxPTZ.VideoURL
		} else {
			v.InVideoURL = "rtsp://admin:Autel123@192.168.2.6:554/h264/ch33/main/av_steam" //default configuration
		}
		logger.Debug("config.GetGlobalConfig().AgxPTZ.VideoTimeOut = ", config.GetGlobalConfig().AgxPTZ.VideoTimeOut)
		if len(config.GetGlobalConfig().AgxPTZ.VideoTimeOut) != 0 {
			v.MaxTime = config.GetGlobalConfig().AgxPTZ.VideoTimeOut
		} else {
			v.MaxTime = "60"
		}
		if len(config.GetGlobalConfig().AgxPTZ.FfmpegPath) != 0 {
			v.FfmpegPath = config.GetGlobalConfig().AgxPTZ.FfmpegPath
		} else {
			v.FfmpegPath = "./ffmpeg.exe"
		}
		if len(config.GetGlobalConfig().AgxPTZ.VideoLogPath) != 0 {
			videoLogPath = config.GetGlobalConfig().AgxPTZ.VideoLogPath
		}

		if len(config.GetGlobalConfig().AgxPTZ.BucketName) != 0 {
			v.S3Con.BucketName = config.GetGlobalConfig().AgxPTZ.BucketName
		} else {
			v.S3Con.BucketName = "c2-eventvideo-fzwtest"
		}
		if len(config.GetGlobalConfig().AgxPTZ.Region) != 0 {
			v.S3Con.Region = config.GetGlobalConfig().AgxPTZ.Region
		} else {
			v.S3Con.Region = "cn-northwest-1"
		}
		if len(config.GetGlobalConfig().AgxPTZ.Ak) != 0 {
			v.S3Con.Ak = config.GetGlobalConfig().AgxPTZ.Ak
		} else {
			v.S3Con.Ak = "AKIAVVMOXO7XBDF4DBXL"
		}
		if len(config.GetGlobalConfig().AgxPTZ.Sk) != 0 {
			v.S3Con.Sk = config.GetGlobalConfig().AgxPTZ.Sk
		} else {
			v.S3Con.Sk = "08U2LuWaFV1el5DhdIaTGEyfXpvgMIs7hhzbd5rg"
		}
		if config.GetGlobalConfig().AgxPTZ.StoreType != 0 {
			v.S3Con.StoreType = config.GetGlobalConfig().AgxPTZ.StoreType
		} else {
			v.S3Con.StoreType = 1
		}
		if len(config.GetGlobalConfig().AgxPTZ.Endpoint) != 0 {
			v.S3Con.Endpoint = config.GetGlobalConfig().AgxPTZ.Endpoint
		} else {
			v.S3Con.Endpoint = "http://cn.cloud-dev.skyfend.com:1981"
		}
	}
	logger.Info("videoS3Object config Msg ", v)
	VsSingleton = newVideoS3ObjectInstance(v).withLog(videoLogPath)
}

func (v *videoS3Object) withLog(filePath string) *videoS3Object {
	if len(filePath) == 0 {
		return v
	}
	v.Log = eventLog{FileName: filePath}
	file, err := os.Create(v.Log.FileName)
	if err != nil {
		msg := fmt.Sprintf("create file video log file fail: %v\n", err)
		logger.Debug(msg)
	}

	v.Log.Writer = csv.NewWriter(file)
	defer v.Log.Flush()

	v.Log.Writer.Write([]string{"Event ID", "startTime", "endTime", "totalTime", "exitType", "fileMd5Sum"})
	return v
}

func (v *videoS3Object) GoSaveToLocalVideoAndPushToS3(eventID, sn string) error {

	go func() {
		defer func() {
			if r := recover(); r != nil {
				err := fmt.Errorf("SaveToLocalVideo : %v", r)
				logger.Error("PushToS3 :", err)
			}
		}()
		err := v.SaveToLocalVideo(eventID)
		if err != nil {
			logger.Error("saveToLocalVideo err = ", err)
		} else {
			var err error
			localPath, remotePath := fmt.Sprintf("%s.mp4", eventID), fmt.Sprintf("%s-%s.mp4", gstaticS3Token.prefix, eventID)
			if gstaticS3Token.token != "" {
				err = v.PushToS3WithToken(localPath, remotePath, true)
			} else {
				err = v.PushToS3(localPath, remotePath, true)
			}

			if err != nil {
				logger.Error("pushToS3 err = ", err)
			} else {
				logger.Debug("pushToS3 succeeded,EventID = ", eventID, " sn = ", sn)
				if gstaticS3Token.token != "" {
					// path := fmt.Sprintf("%s-%s", gstaticS3Token.prefix, eventID)
					// v.agxDetectVideoPushToS3EventReport(path, sn)
					if gstaticS3Token.token != "" {
						// path := fmt.Sprintf("%s-%s", gstaticS3Token.prefix, eventID)
						// v.agxDetectVideoPushToS3EventReport(path, sn)
						GPreFixS3 = gstaticS3Token.prefix
						IsHasPrefix = true
						logger.Debug("eventID = ", eventID)
						v.agxDetectVideoPushToS3EventReport(eventID, sn)
					} else {
						v.agxDetectVideoPushToS3EventReport(eventID, sn)
					}
				} else {
					v.agxDetectVideoPushToS3EventReport(eventID, sn)
				}

			}
		}
	}()

	return nil
}

func (v *videoS3Object) GoCancelCaptureVideo(eventID string) error {

	go func() {
		defer func() {
			if r := recover(); r != nil {
				err := fmt.Errorf("SaveToLocalVideo : %v", r)
				logger.Error("PushToS3 :", err)
			}
		}()
		v.CancelCaptureVideo(eventID)
	}()

	return nil
}

func (v *videoS3Object) SaveToLocalVideo(eventID string) error {

	supportOS := "windows"
	osName := runtime.GOOS

	if osName != supportOS {
		eMsg := fmt.Sprintf("unsupported ! system is not windows,system is %s\n", osName)
		return errors.New(eMsg)
	}
	logger.Debug("v.FfmpegPath = ", v.FfmpegPath)
	fileName := fmt.Sprintf("%s.mp4", eventID)
	FfmpegHandler := ffmpeg.Input(v.InVideoURL,
		ffmpeg.KwArgs{"t": v.MaxTime, "rtsp_transport": "tcp"}).OverWriteOutput().ErrorToStdOut().Output(fileName, ffmpeg.KwArgs{
		"vcodec": "copy",
	}).SetFfmpegPath(v.FfmpegPath).Compile()

	v.EventMap.Store(eventID, FfmpegHandler)

	startTime := time.Now()
	exitType := outTimeExit
	logger.Debug("ffmpeg store video path =", fileName)
	logger.Debug("FfmpegHandler = ", FfmpegHandler)
	err := FfmpegHandler.Run()
	if err != nil {
		exitType = autoExit
		logger.Debug("ffmpeg store video path,run exit msg:", err)
	}
	v.EventMap.Delete(eventID)

	endTime := time.Now()
	totalTime := endTime.Sub(startTime).Seconds()
	if v.Log.Writer != nil {
		v.saveEventToCSV(eventID, startTime.Format("2006-01-02 15:04:05"), endTime.Format("2006-01-02 15:04:05"), strconv.FormatFloat(totalTime, 'f', -1, 64), exitType, v.videoMd5(eventID))
	}
	return nil
}

func (v *videoS3Object) agxDetectVideoPushToS3EventReport(eventId, sn string) {
	var detectInfo []*client.AgxDetectInfoList

	dataInfo := &client.AgxDetectInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      sn,
			Sn:        sn,
			EquipType: int32(common.DEV_AGX),
			MsgType:   mavlink.AgxEventPushVideoDone,
		},
		Data:    detectInfo,
		EventId: eventId,
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgAgxDetectEventData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}
	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Infof("agx detect disappear event report: %v", dataInfo)
}
func (v *videoS3Object) saveEventToCSV(eventID, startTime, endTime, totalTime, exitType, md5 string) {
	logger.Debug("save event to CSV, eventID: , startTime: , endTime: ", eventID, startTime, endTime)
	err := v.Log.Writer.Write([]string{eventID, startTime, endTime, totalTime, exitType, md5})
	defer v.Log.Flush()
	if err != nil {
		logger.Error("saveEventToCSV = %v", err)
	}
}

func (v *videoS3Object) videoMd5(eventID string) (md5String string) {

	filePath := fmt.Sprintf("%s.mp4", eventID)
	file, err := os.Open(filePath)
	if err != nil {
		fmt.Println("Error opening file:", err)
		return
	}
	defer file.Close()
	hash := md5.New()
	if _, err := io.Copy(hash, file); err != nil {
		fmt.Println("Error calculating MD5:", err)
		return
	}
	md5Hash := hash.Sum(nil)
	md5String = hex.EncodeToString(md5Hash)

	return
}

func (v *videoS3Object) CancelCaptureVideo(eventID string) error {

	osName := runtime.GOOS
	if osName == "windows" {
		eMsg := fmt.Sprintf("unsupported ! system is not Windows,system is %s\n", osName)
		return errors.New(eMsg)
	}

	var FfmpegHandler *exec.Cmd

	val, ok := v.EventMap.Load(eventID)
	if ok {
		FfmpegHandler = val.(*exec.Cmd)
	} else {
		return errors.New("unknown event")
	}
	err := FfmpegHandler.Cancel()
	if err != nil {
		errMsg := fmt.Sprintf("GenerateConsoleCtrlEvent: %v\n", err)
		return errors.New(errMsg)
	}

	return nil
}

// func (v *videoS3Object) PushToS3(localPath, remotePath string) error {
// 	defer func() {
// 		if r := recover(); r != nil {
// 			err := fmt.Errorf("error : %v", r)
// 			logger.Error("error:", err)
// 		}
// 	}()
// 	// localPath, remotePath := fmt.Sprintf("%s.mp4", eventID), fmt.Sprintf("%s.mp4", eventID)

// 	Ak := v.S3Con.Ak
// 	Sk := v.S3Con.Sk
// 	Region := v.S3Con.Region
// 	Bucket := v.S3Con.BucketName
// 	storeType := v.S3Con.StoreType

// 	var timeout time.Duration

// 	timeout = 30 * time.Second

// 	sess := session.Must(session.NewSession())
// 	var svc *s3.S3
// 	if storeType == awsS3 {
// 		svc = s3.New(sess, &aws.Config{
// 			Region:      aws.String(Region),
// 			Credentials: credentials.NewStaticCredentials(Ak, Sk, ""),
// 		})
// 	} else if storeType == minioS3 {
// 		svc = s3.New(sess, &aws.Config{
// 			Endpoint:         &v.S3Con.Endpoint,
// 			Region:           aws.String(Region),
// 			Credentials:      credentials.NewStaticCredentials(Ak, Sk, ""),
// 			S3ForcePathStyle: aws.Bool(true),
// 		})
// 	} else {
// 		errMsg := "unsupported store type"
// 		logger.Debug(errMsg)
// 		return errors.New(errMsg)
// 	}

// 	logger.Debugf("svc = ", svc)
// 	ctx := context.Background()
// 	var cancelFn func()
// 	if timeout > 0 {
// 		ctx, cancelFn = context.WithTimeout(ctx, timeout)
// 	}

// 	if cancelFn != nil {
// 		defer cancelFn()
// 	}

// 	fileContent, err := os.Open(localPath)
// 	if err != nil {
// 		fmt.Println("read file failed, err = ", err)
// 	}

// 	output, err := svc.PutObjectWithContext(ctx, &s3.PutObjectInput{
// 		Bucket: aws.String(Bucket),
// 		Key:    aws.String(remotePath),
// 		Body:   fileContent,
// 	})
// 	if err != nil {
// 		if aerr, ok := err.(awserr.Error); ok && aerr.Code() == request.CanceledErrorCode {
// 			fmt.Fprintf(os.Stderr, "upload canceled due to timeout, %v\n", err)
// 			msg := fmt.Sprintf("upload canceled due to timeout,%s\n", err.Error())
// 			return errors.New(msg)
// 		}
// 		fmt.Fprintf(os.Stderr, "failed to upload object, %v\n", err)
// 		msg := fmt.Sprintf("upload failed to upload object, %s\n", err.Error())
// 		return errors.New(msg)
// 	}
// 	fileEtag := *output.ETag
// 	fileMd5 := fmt.Sprintf("\"%s\"", v.videoMd5(localPath))
// 	if fileEtag != fileMd5 {
// 		return errors.New("remote upload file does error")
// 	}
// 	fileContent.Close()
// 	// err = os.Remove(localPath)
// 	if err != nil {
// 		msg := fmt.Sprintf("failed to remove: %v\n", err)
// 		return errors.New(msg)
// 	}
// 	return nil
// }

type mqttSubS3TokenMsgData struct {
	Result int    `json:"result"`
	Output Output `json:"output"`
}

type Output struct {
	Bucket          string      `json:"bucket"`
	Credentials     Credentials `json:"credentials"`
	Provider        string      `json:"provider"`
	Region          string      `json:"region"`
	ObjectKeyPrefix string      `json:"object_key_prefix"`
}

type Credentials struct {
	Expire          int    `json:"expire"`
	AccessKeyID     string `json:"access_key_id"`
	AccessKeySecret string `json:"access_key_secret"`
	SecurityToken   string `json:"security_token"`
}
type mqttSubS3TokenMsgV3 struct {
	Tid       string                `json:"tid"`
	Bid       string                `json:"bid"`
	MsgData   mqttSubS3TokenMsgData `json:"data"`
	Timestamp int64                 `json:"timestamp"`
	Method    string                `json:"method"`
}

func decodeMessageV3(payload []byte) (*mqttSubS3TokenMsgV3, error) {
	message := new(mqttSubS3TokenMsgV3)
	decoder := json.NewDecoder(strings.NewReader(string(payload)))
	if err := decoder.Decode(&message); err != nil {
		return nil, err
	}
	return message, nil
}

// func (v *videoS3Object) PushToS3WithToken(localPath, remotePath string) error {
// 	defer func() {
// 		if r := recover(); r != nil {
// 			err := fmt.Errorf("error : %v", r)
// 			logger.Error("error:", err)
// 		}
// 	}()
// 	// localPath, remotePath := fmt.Sprintf("%s.mp4", eventID), fmt.Sprintf("%s-%s.mp4", gstaticS3Token.prefix, eventID)
// 	logger.Debug("localPath", localPath, " remotePath", remotePath)
// 	Ak := gstaticS3Token.ak
// 	Sk := gstaticS3Token.sk
// 	Region := gstaticS3Token.region
// 	Bucket := gstaticS3Token.bucket
// 	token := gstaticS3Token.token

// 	var timeout time.Duration

// 	timeout = 30 * time.Second

// 	sess := session.Must(session.NewSession())
// 	var svc *s3.S3
// 	svc = s3.New(sess, &aws.Config{
// 		Region:      aws.String(Region),
// 		Credentials: credentials.NewStaticCredentials(Ak, Sk, token),
// 	})

// 	logger.Debugf("svc = ", svc)
// 	ctx := context.Background()
// 	var cancelFn func()
// 	if timeout > 0 {
// 		ctx, cancelFn = context.WithTimeout(ctx, timeout)
// 	}

// 	if cancelFn != nil {
// 		defer cancelFn()
// 	}

// 	fileContent, err := os.Open(localPath)
// 	if err != nil {
// 		fmt.Println("read file failed, err = ", err)
// 	}

// 	output, err := svc.PutObjectWithContext(ctx, &s3.PutObjectInput{
// 		Bucket: aws.String(Bucket),
// 		Key:    aws.String(remotePath),
// 		Body:   fileContent,
// 	})
// 	if err != nil {
// 		if aerr, ok := err.(awserr.Error); ok && aerr.Code() == request.CanceledErrorCode {
// 			fmt.Fprintf(os.Stderr, "upload canceled due to timeout, %v\n", err)
// 			msg := fmt.Sprintf("upload canceled due to timeout,%s\n", err.Error())
// 			return errors.New(msg)
// 		}
// 		fmt.Fprintf(os.Stderr, "failed to upload object, %v\n", err)
// 		msg := fmt.Sprintf("upload failed to upload object, %s\n", err.Error())
// 		return errors.New(msg)
// 	}
// 	fileEtag := *output.ETag
// 	fileMd5 := fmt.Sprintf("\"%s\"", v.videoMd5(localPath))
// 	if fileEtag != fileMd5 {
// 		return errors.New("remote upload file does error")
// 	}
// 	fileContent.Close()
// 	// err = os.Remove(localPath)
// 	// if err != nil {
// 	// 	msg := fmt.Sprintf("failed to remove: %v\n", err)
// 	// 	return errors.New(msg)
// 	// }
// 	return nil
// }

func TickGetS3Token(s *mqtt.Adaptor, c2sn string) {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("error : %v", r)
			logger.Error("error:", err)
		}
	}()
	ticker := time.NewTicker(1 * time.Second)

	for range ticker.C {
		getS3UploadAcces(s, c2sn)
		ticker.Reset(1 * time.Minute)
	}
}

func getS3UploadAcces(s *mqtt.Adaptor, c2sn string) {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("error : %v", r)
			logger.Error("error:", err)
		}
	}()
	logger.Debug("c2sn = ", c2sn)
	bid := uuid.NewV4().String()
	tid := uuid.NewV4().String()
	pubMsg := S3Request{
		BID:       bid,
		TID:       tid,
		Timestamp: time.Now().UnixMilli(),
		Gateway:   c2sn,
		Method:    "storage_config_get",
		Data: S3RequestData{
			Module: 1,
		},
	}
	bmsg, err := json.Marshal(pubMsg)
	if err != nil {
		logger.Error("josn marshal error", err)
	}

	logger.Debug("pubMsg = ", pubMsg)
	logger.Debug("bmsg = ", bmsg)
	topic := fmt.Sprintf("thing/product/%s/requests", c2sn)
	fmt.Println("topic = ", topic)
	s.Publish(topic, bmsg)
}

type S3Request struct {
	BID       string        `json:"bid"`
	TID       string        `json:"tid"`
	Timestamp int64         `json:"timestamp"`
	Gateway   string        `json:"gateway"`
	Method    string        `json:"method"`
	Data      S3RequestData `json:"data"`
}
type S3RequestData struct {
	Module int `json:"module"`
}

func DoS3Token_V3(m mqtt.Message) ([]byte, int32) {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
			debug.PrintStack() // 打印详细的堆栈信息
		}
	}()
	logger.Debug("doS3Token_V3 m = ", m.Payload())
	p, err := decodeMessageV3(m.Payload())
	logger.Debug("doS3Token_V3 p = ", p)
	if err != nil {
		logger.Error("decodeMessage error = ", err)
		return nil, mqtt_V3
	}
	gstaticS3Token.bucket = p.MsgData.Output.Bucket
	gstaticS3Token.ak = p.MsgData.Output.Credentials.AccessKeyID
	gstaticS3Token.sk = p.MsgData.Output.Credentials.AccessKeySecret
	gstaticS3Token.token = p.MsgData.Output.Credentials.SecurityToken
	gstaticS3Token.region = p.MsgData.Output.Region
	gstaticS3Token.prefix = p.MsgData.Output.ObjectKeyPrefix
	logger.Debugf("gstaticS3Token = %+v", gstaticS3Token)
	return nil, mqtt_V3

}

package videostore

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"os/exec"
	"regexp"
	"strconv"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/logic/uploadcloud/mqtt"
	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/awserr"
	"github.com/aws/aws-sdk-go/aws/credentials"
	"github.com/aws/aws-sdk-go/aws/request"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/s3"
	uuid "github.com/satori/go.uuid"
)

type eventS3UrlT struct {
	S3Path     string `json:"s3_path"`
	Index      int32  `json:"index"`
	CreateTime int64  `json:"create_time"`
}

type eventCaptureT struct {
	C2sn    string        `json:"c2sn"`
	Sn      string        `json:"sn"`
	MsgID   string        `json:"msgid"`
	EventID string        `json:"eventid"`
	S3Msg   []eventS3UrlT `json:"s3msg"`
}

var (
	gTmpDir           = "tmpdir"
	gVideoDir         = fmt.Sprintf("%s/video", gTmpDir)
	gPhotoDir         = fmt.Sprintf("%s/photo", gTmpDir)
	gS3RootDir        = "eventImage"
	gEventCaptureChan = make(chan eventCaptureT, 128)
)

func newVideoS3ObjectInstance(v storeConfig) *videoS3Object {
	vsSingletonOnce.Do(func() {
		VsSingleton = new(videoS3Object)
		VsSingleton.InVideoURL = v.InVideoURL
		VsSingleton.MaxTime = v.MaxTime
		VsSingleton.FfmpegPath = v.FfmpegPath
		VsSingleton.S3Con = v.S3Con
	})

	err := os.Mkdir(gTmpDir, 0755)
	if err != nil {
		logger.Errorf("error creating temporary directory,error:", err)
	}
	err = os.Mkdir(gVideoDir, 0755)
	if err != nil {
		logger.Errorf("error creating temporary directory,error:", err)
	}
	err = os.Mkdir(gPhotoDir, 0755)
	if err != nil {
		logger.Errorf("error creating temporary directory,error:", err)
	}
	return VsSingleton
}

// 复制文件
func copyFile(src, dst string) error {
	sourceFile, err := os.Open(src)
	if err != nil {
		return err
	}
	defer sourceFile.Close()

	destFile, err := os.Create(dst)
	if err != nil {
		return err
	}
	defer destFile.Close()

	_, err = io.Copy(destFile, sourceFile)
	if err != nil {
		return err
	}

	// 确保文件内容已经写入磁盘
	err = destFile.Sync()
	if err != nil {
		return err
	}

	return nil
}

func eventImageTopic() string {
	return "mqtt/event/images"
}

func PubEventImageToMqtt(s *mqtt.Adaptor, c2sn string) {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("error : %v", r)
			logger.Error("error:", err)
		}
	}()
	logger.Debugf("PubEventImageToMqtt ,s = %+v", s, " c2sn = %s", c2sn)
	pTopic := eventImageTopic()
	for {
		msg := <-gEventCaptureChan
		smsg, err := json.Marshal(msg)
		if err != nil {
			logger.Error("error:", err)
			continue
		}
		ret := s.Publish(pTopic, smsg)
		logger.Debug("ret = ", ret)
	}
}
func (v *videoS3Object) doCapture(c2sn, sn, destVidwoFile, eventID string) {
	// //video path
	// destFile := filepath.Join(gVideoDir, fileName)
	// err := copyFile(fileName, destFile)
	// if err != nil {
	// 	logger.Errorf("Error copying file:", err)
	// }

	duration, err := getVideoDuration(destVidwoFile)
	if err != nil {
		logger.Errorf("Error getting video duration:", err)
		return
	}
	logger.Debug("duration = ", duration)
	times := []string{"00:00:00", formatDuration(duration / 2), formatDuration(duration - 1)}

	outputPath := fmt.Sprintf("%s/%s", gPhotoDir, eventID)
	logger.Debug("outputPath = ", outputPath)
	s3UrlList := make([]eventS3UrlT, 0)
	for i, t := range times {
		localImagePath := fmt.Sprintf("%s_%d.jpg", outputPath, i)
		logger.Debug("localPath = ", localImagePath, " eventID = ", eventID)
		err := captureFrame(destVidwoFile, localImagePath, t)
		if err != nil {
			logger.Errorf("Error capturing frame:", err)
			continue
		}
		//remotePath := fmt.Sprintf("%s/%s/%s/%s_%d.jpg", gS3RootDir, c2sn, sn, eventID, i)
		remotePath := fmt.Sprintf("%s/%s/%s/%s%s_%d.jpg", gS3RootDir, c2sn, sn, gstaticS3Token.prefix, eventID, i)
		logger.Debug("remotePath = ", remotePath)
		if gstaticS3Token.token != "" {
			if err = v.PushToS3WithToken(localImagePath, remotePath, false); err != nil {
				logger.Errorf("push s3 with token, err: %v, remotePath: %v", err, remotePath)
				continue
			}
		} else {
			if err = v.PushToS3(localImagePath, remotePath, false); err != nil {
				logger.Errorf("push s3 err: %v, remotePath: %v", err, remotePath)
				continue
			}
		}
		s3UrlList = append(s3UrlList, eventS3UrlT{S3Path: remotePath, Index: int32(i), CreateTime: time.Now().UTC().UnixMilli()})
	}
	var sendNotifyMsg eventCaptureT
	sendNotifyMsg.C2sn = c2sn
	sendNotifyMsg.EventID = eventID
	sendNotifyMsg.MsgID = uuid.NewV4().String()
	sendNotifyMsg.S3Msg = s3UrlList
	sendNotifyMsg.Sn = sn
	logger.Debugf("sendNotifyMsg = %+v", sendNotifyMsg)
	gEventCaptureChan <- sendNotifyMsg
	logger.Debug("Frames captured successfully.")
}

// 获取视频时长
func getVideoDuration(videoPath string) (float64, error) {
	cmd := exec.Command("tools\\ffmpeg.exe", "-i", videoPath, "-f", "null", "-")
	var out bytes.Buffer
	cmd.Stderr = &out
	err := cmd.Run()
	if err != nil {
		return 0, err
	}

	// 使用正则表达式提取时长信息
	re := regexp.MustCompile(`Duration: (\d{2}):(\d{2}):(\d{2})\.(\d{2})`)
	match := re.FindStringSubmatch(out.String())
	if match == nil {
		return 0, fmt.Errorf("duration not found")
	}

	hours, _ := strconv.Atoi(match[1])
	minutes, _ := strconv.Atoi(match[2])
	seconds, _ := strconv.Atoi(match[3])
	milliseconds, _ := strconv.Atoi(match[4])

	duration := float64(hours*3600+minutes*60+seconds) + float64(milliseconds)/100
	return duration, nil
}

// 格式化时长为 HH:MM:SS 格式的字符串
func formatDuration(seconds float64) string {
	h := int(seconds) / 3600
	m := (int(seconds) % 3600) / 60
	s := int(seconds) % 60
	return fmt.Sprintf("%02d:%02d:%02d", h, m, s)
}

// 截取视频在指定时间点的帧
func captureFrame(videoPath, outputFile, time string) error {
	cmd := exec.Command("tools\\ffmpeg.exe", "-i", videoPath, "-ss", time, "-vframes", "1", outputFile)
	return cmd.Run()
}
func (v *videoS3Object) PushToS3(localPath, remotePath string, isNeedToDelte bool) error {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("error : %v", r)
			logger.Error("error:", err)
		}
	}()
	// localPath, remotePath := fmt.Sprintf("%s.mp4", eventID), fmt.Sprintf("%s.mp4", eventID)
	logger.Debug("localPath = ", localPath, "remotePath = ", remotePath, " isNeedToDelte =", isNeedToDelte)
	Ak := v.S3Con.Ak
	Sk := v.S3Con.Sk
	Region := v.S3Con.Region
	Bucket := v.S3Con.BucketName
	storeType := v.S3Con.StoreType

	var timeout time.Duration

	timeout = 30 * time.Second

	sess := session.Must(session.NewSession())
	var svc *s3.S3
	if storeType == awsS3 {
		svc = s3.New(sess, &aws.Config{
			Region:      aws.String(Region),
			Credentials: credentials.NewStaticCredentials(Ak, Sk, ""),
		})
	} else if storeType == minioS3 {
		svc = s3.New(sess, &aws.Config{
			Endpoint:         &v.S3Con.Endpoint,
			Region:           aws.String(Region),
			Credentials:      credentials.NewStaticCredentials(Ak, Sk, ""),
			S3ForcePathStyle: aws.Bool(true),
		})
	} else {
		errMsg := "unsupported store type"
		logger.Debug("storeType = %v", storeType)
		return errors.New(errMsg)
	}

	logger.Debugf("svc = ", svc)
	ctx := context.Background()
	var cancelFn func()
	if timeout > 0 {
		ctx, cancelFn = context.WithTimeout(ctx, timeout)
	}

	if cancelFn != nil {
		defer cancelFn()
	}

	fileContent, err := os.Open(localPath)
	if err != nil {
		fmt.Println("read file failed, err = ", err)
	}

	output, err := svc.PutObjectWithContext(ctx, &s3.PutObjectInput{
		Bucket: aws.String(Bucket),
		Key:    aws.String(remotePath),
		Body:   fileContent,
	})
	if err != nil {
		if aerr, ok := err.(awserr.Error); ok && aerr.Code() == request.CanceledErrorCode {
			fmt.Fprintf(os.Stderr, "upload canceled due to timeout, %v\n", err)
			msg := fmt.Sprintf("upload canceled due to timeout,%s\n", err.Error())
			return errors.New(msg)
		}
		fmt.Fprintf(os.Stderr, "failed to upload object, %v\n", err)
		msg := fmt.Sprintf("upload failed to upload object, %s\n", err.Error())
		return errors.New(msg)
	}
	fileEtag := *output.ETag
	fileMd5 := fmt.Sprintf("\"%s\"", v.videoMd5(localPath))
	if fileEtag != fileMd5 {
		return errors.New("remote upload file does error")
	}
	fileContent.Close()
	if isNeedToDelte {
		err = os.Remove(localPath)
		if err != nil {
			msg := fmt.Sprintf("failed to remove: %v\n", err)
			return errors.New(msg)
		}
	}

	return nil
}

func EventPhotoMsgPub(s *mqtt.Adaptor) {
	s.Publish("fdd", []byte("fdfd"))
}

func (v *videoS3Object) PushToS3WithToken(localPath, remotePath string, isNeedToDelte bool) error {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("error : %v", r)
			logger.Error("error:", err)
		}
	}()
	// localPath, remotePath := fmt.Sprintf("%s.mp4", eventID), fmt.Sprintf("%s-%s.mp4", gstaticS3Token.prefix, eventID)
	logger.Debug("localPath: ", localPath, " remotePath: ", remotePath)
	Ak := gstaticS3Token.ak
	Sk := gstaticS3Token.sk
	Region := gstaticS3Token.region
	Bucket := gstaticS3Token.bucket
	token := gstaticS3Token.token

	var timeout time.Duration

	timeout = 30 * time.Second

	sess := session.Must(session.NewSession())
	var svc *s3.S3
	svc = s3.New(sess, &aws.Config{
		Region:      aws.String(Region),
		Credentials: credentials.NewStaticCredentials(Ak, Sk, token),
	})

	logger.Debugf("svc = ", svc)
	ctx := context.Background()
	var cancelFn func()
	if timeout > 0 {
		ctx, cancelFn = context.WithTimeout(ctx, timeout)
	}

	if cancelFn != nil {
		defer cancelFn()
	}

	fileContent, err := os.Open(localPath)
	if err != nil {
		fmt.Println("read file failed, err = ", err)
	}

	output, err := svc.PutObjectWithContext(ctx, &s3.PutObjectInput{
		Bucket: aws.String(Bucket),
		Key:    aws.String(remotePath),
		Body:   fileContent,
	})
	if err != nil {
		if aerr, ok := err.(awserr.Error); ok && aerr.Code() == request.CanceledErrorCode {
			fmt.Fprintf(os.Stderr, "upload canceled due to timeout, %v\n", err)
			msg := fmt.Sprintf("upload canceled due to timeout,%s\n", err.Error())
			return errors.New(msg)
		}
		fmt.Fprintf(os.Stderr, "failed to upload object, %v\n", err)
		msg := fmt.Sprintf("upload failed to upload object, %s\n", err.Error())
		return errors.New(msg)
	}
	fileEtag := *output.ETag
	fileMd5 := fmt.Sprintf("\"%s\"", v.videoMd5(localPath))
	if fileEtag != fileMd5 {
		return errors.New("remote upload file does error")
	}
	fileContent.Close()
	if isNeedToDelte {
		err = os.Remove(localPath)
		if err != nil {
			msg := fmt.Sprintf("failed to remove: %v\n", err)
			return errors.New(msg)
		}
	}

	return nil
}

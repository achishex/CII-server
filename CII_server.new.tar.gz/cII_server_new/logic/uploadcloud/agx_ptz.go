package uploadcloud

import (
	"fmt"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	broker2 "go-micro.dev/v4/broker"
	"google.golang.org/protobuf/proto"

	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/logic/uploadcloud/down"
	videostore "adasgitlab.autel.com/tools/cuav_server/logic/uploadcloud/videoStore"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/proto/cloudPlatform"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
)

func (ctrl *CloudTcpCli) ReportAgxMsg() {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	_, _ = mq.AgxMsgBroker.Subscribe(mq.AgxTopic, func(event broker2.Event) error {
		comCli := &client.ClientReport{}
		err := proto.Unmarshal(event.Message().Body, comCli)
		if err != nil {
			logger.Error("agx heart Cli Unmarshal err:", err)
			return err
		}
		if ctrl.Conn == nil || ctrl.IsLogin == false {
			return nil
		}
		switch comCli.MsgType {
		case common.ClientMsgIdAgxHeartData:
			ctrl.ReportAgxHeart(comCli.Data)
		case common.ClientMsgIdAgxDetectData:
			ctrl.ReportAgxUav(comCli.Data)
		case common.ClientMsgIdAgxDevStatusData:
			ctrl.ReportAgxDev(comCli.Data)
		case common.ClientMsgIdAgxPTZStatusData:
			ctrl.ReportAgxPtzState(comCli.Data)
		case common.ClientMsgIdAgxTransferSflDetectMsg:
			ctrl.ReportAgxTransferSflDetectMsg(comCli.Data)
		case common.ClientMsgIdAgxTransferSflHeartMsg:
			ctrl.ReportAgxTransferSflHeartMsg(comCli.Data)
		case common.ClientMsgIdPtzTrackTargetData:
			//ctrl.ReportAgxPerceptionMsg(comCli.Data)
			ctrl.ReportAgxPerceptionE0Msg(comCli.Data)
		}
		return nil
	})
}

func (c *CloudTcpCli) ReportAgxTransferSflHeartMsg(info []byte) {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	hb := &client.SflHeartInfo{}
	err := proto.Unmarshal(info, hb)
	if err != nil {
		logger.Error("report sfl proto Unmarshal error: %v", err)
		return
	}
	logger.Debug("start Unmarshal")
	agxSn := hb.Header.Sn //AGX  SN号
	sflSn := hb.Data.Sn   //SFL  SN号)

	//给云端发送
	hbData := make([]*cloudPlatform.AgxTransferSflHeartData, 0)
	hbData = append(hbData, &cloudPlatform.AgxTransferSflHeartData{
		Sn:            agxSn,
		SflSn:         sflSn,
		CreateTime:    time.Now().UnixMilli(),
		WorkStatus:    hb.Data.WorkStatus,
		Online:        reverseOnline(hb.Data.IsOnline),
		DetectFreq:    hb.Data.DetectFreq,
		Elevation:     hb.Data.Elevation,
		GunDirection:  hb.Data.GunDirection,
		GunLongitude:  hb.Data.GunLongitude,
		GunLatitude:   hb.Data.GunLatitude,
		GunAltitude:   int32(hb.Data.GunAltitude),
		SatellitesNum: hb.Data.SatellitesNum,
		FaultLevel:    hb.Data.FaultLevel,
		CtrlFault:     hb.Data.CtrlFault,
		AeagFault:     hb.Data.AeagFault,
		TracerFault:   hb.Data.TracerFault,
	})
	logger.Debug("hbData = ", hbData)
	data := &cloudPlatform.AgxTransferSflHeartList{
		Body: hbData,
	}

	// encodedMessage
	encodedMessage, err := proto.Marshal(data)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       AgxTransferSflHeartURL,
			Sn:        c.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   c.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return
	}
	//对消息进行封装+head+crc
	sendMessage := createPacket(encodedMessage)
	// 发送TCP消息
	if c.Conn == nil || c.IsLogin == false {
		return
	}
	_, err = c.Conn.Write(sendMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return
	}
	return
}

func (c *CloudTcpCli) ReportAgxTransferSflDetectMsg(info []byte) {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	oriData := client.SflDetectInfo{}
	err := proto.Unmarshal(info, &oriData)
	if err != nil {
		logger.Error("Protobuf 解码失败:", err)
		return
	}

	umData := oriData.Data
	agxSn := oriData.Header.Sn //AGX  SN号
	sflSn := oriData.Data.Sn   //SFL  SN号
	droneList := umData.List
	//给云端发送侦测到的无人机小组
	dData := make([]*cloudPlatform.AgxTransferSflUavData, 0)
	for _, drone := range droneList {
		dData = append(dData, &cloudPlatform.AgxTransferSflUavData{
			Sn:                 agxSn,
			SflSn:              sflSn,
			ProductType:        drone.ProductType,
			DroneName:          drone.DroneName,
			SerialNum:          drone.SerialNum,
			DroneLongitude:     drone.DroneLongitude,
			DroneLatitude:      drone.DroneLatitude,
			DroneHeight:        drone.DroneHeight,
			DroneYawAngle:      drone.DroneYawAngle,
			DroneSpeed:         drone.DroneSpeed,
			DroneVerticalSpeed: drone.DroneVerticalSpeed,
			SpeedDirection:     drone.SpeedDirection,
			DroneSailLongitude: drone.DroneSailLongitude,
			DroneSailLatitude:  drone.DroneSailLatitude,
			PilotLongitude:     drone.PilotLongitude,
			PilotLatitude:      drone.PilotLatitude,
			DroneHorizon:       drone.DroneHorizon,
			DronePitch:         drone.DronePitch,
			UFreq:              drone.UFreq,
			UDistance:          drone.UDistance,
			UDangerLevels:      drone.UDangerLevels,
			Role:               drone.Role,
			DetectionNum:       umData.DetectionNum,
			CreateTime:         time.Now().UnixMilli(),
		})
	}
	Message := &cloudPlatform.AgxTransferSflUavList{
		Body: dData,
	}

	// encodedMessage
	encodedMessage, err := proto.Marshal(Message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       AgxTransferSflUavURL,
			Sn:        c.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   c.LoginId,
		},
		Data: encodedMessage,
	}
	logger.Debug("<----->message = ", message)
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	logger.Debug("encodedMessage = ->", encodedMessage)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return
	}
	//对消息进行封装+head+crc
	encodedMessage = createPacket(encodedMessage)
	// 发送TCP消息
	if c.Conn == nil || c.IsLogin == false {
		return
	}

	_, err = c.Conn.Write(encodedMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return
	}
	return
}
func (ctrl *CloudTcpCli) ReportAgxPtzState(data []byte) {
	agxPtz := &client.AgxPTZStateInfo{}
	err := proto.Unmarshal(data, agxPtz)
	if err != nil {
		logger.Error("agx Ptz Unmarshal err:", err)
		return
	}
	//给云端发送
	ptzData := make([]*cloudPlatform.AgxPtzStateData, 0)
	ptzData = append(ptzData, &cloudPlatform.AgxPtzStateData{
		Sn:           agxPtz.Header.Sn,
		TimeStamp:    agxPtz.Data.TimeStamp,
		PtzLongitude: agxPtz.Data.PtzLongitude,
		PtzLatitude:  agxPtz.Data.PtzLatitude,
		PtzHeight:    agxPtz.Data.PtzHeight,
		Azimuth:      agxPtz.Data.Azimuth,
		Elevation:    agxPtz.Data.Elevation,
		OmegaAz:      agxPtz.Data.OmegaAz,
		OmegaEl:      agxPtz.Data.OmegaEl,
		Zoom:         agxPtz.Data.Zoom,
		CreateTime:   time.Now().UnixMilli(),
	})
	logger.Debug("ptzData =", ptzData)
	ptzMessage := &cloudPlatform.AgxPtzStateList{
		Body: ptzData,
	}
	// encodedMessage
	encodedMessage, err := proto.Marshal(ptzMessage)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       AgxPTZState,
			Sn:        ctrl.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   ctrl.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return
	}
	//对消息进行封装+head+crc
	encodedMessage = createPacket(encodedMessage)
	// 发送TCP消息
	if ctrl.Conn == nil || ctrl.IsLogin == false {
		return
	}
	_, err = ctrl.Conn.Write(encodedMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return
	}
}

func (ctrl *CloudTcpCli) ReportAgxHeart(data []byte) {
	heart := &client.AgxHeartBeatInfo{}
	err := proto.Unmarshal(data, heart)
	if err != nil {
		logger.Error("agx heart Unmarshal err:", err)
		return
	}
	if heart.Data.IsOnline == 0 {
		heart.Data.IsOnline = 1
	} else if heart.Data.IsOnline == 1 {
		heart.Data.IsOnline = 2
	}
	//给云端发送
	heartData := make([]*cloudPlatform.AgxHeartData, 0)
	heartData = append(heartData, &cloudPlatform.AgxHeartData{
		Sn:          heart.Header.Sn,
		Online:      heart.Data.IsOnline,
		Electricity: heart.Data.Electricity,
		CreateTime:  time.Now().UnixMilli(),
	})

	logger.Debug("heartData =", heartData)

	if len(heart.Header.Sn) != 0 {
		// var storeSn down.Sfl200PropertySnType
		// var storeType down.Sfl200PropertyDeviceType
		// var isExitParentDev bool

		// down.Gsfl200PropertyStatus.Range(func(key, value any) bool {
		// 	isExitParentDev = true
		// 	storeSn = key.(down.Sfl200PropertySnType)
		// 	storeType = value.(down.Sfl200PropertyDeviceType)
		// 	return true
		// })

		// if isExitParentDev {
		// 	down.Gsfl200PropertyStatus.Store(down.Sfl200PropertySnType{AgxSn: heart.Header.Sn, Sfl200Sn: storeSn.Sfl200Sn},
		// 		down.Sfl200PropertyDeviceType{AgxType: common.Agx, Sfl200Type: storeType.Sfl200Type})
		// }
		down.GAgxUndersfl200PropertyStatus.Store(heart.Header.Sn, common.Agx)
	}
	heartMessage := &cloudPlatform.AgxHeartList{
		Body: heartData,
	}
	// encodedMessage
	encodedMessage, err := proto.Marshal(heartMessage)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       AgxHeartURL,
			Sn:        ctrl.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   ctrl.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return
	}
	//对消息进行封装+head+crc
	encodedMessage = createPacket(encodedMessage)
	// 发送TCP消息
	if ctrl.Conn == nil || ctrl.IsLogin == false {
		return
	}
	_, err = ctrl.Conn.Write(encodedMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		ctrl.clearConn()
		return
	}
}

func (ctrl *CloudTcpCli) ReportAgxUav(data []byte) {
	// // 发送TCP消息
	// if ctrl.Conn == nil || ctrl.IsLogin == false {
	// 	return
	// }
	uav := &client.AgxDetectInfo{}
	err := proto.Unmarshal(data, uav)
	if err != nil {
		logger.Error("agx Uav Unmarshal err:", err)

	}
	//给云端发送
	uavData := make([]*cloudPlatform.AgxUavData, 0)
	for _, uavInfo := range uav.Data {
		var url string
		var downloadUrl string
		var bucketName string
		// 0x00：未识别 0x01：无人机	0x02：单兵	0x03：车辆	0x04：鸟类	0x05：直升机
		// if uavInfo.AssocBit1 == 1 &&
		// 	(uavInfo.Classification == 0x01 || uavInfo.Classification == 0x02 ||
		// 		uavInfo.Classification == 0x03 || uavInfo.Classification == 0x04 || uavInfo.Classification == 0x05) {
		// if uavInfo.AssocBit1 == 1 {
		/**/
		KID := fmt.Sprintf("%s_%d_%d", uav.Header.Sn, uavInfo.Classification, int32(uavInfo.ObjId))
		s3PrePath := fmt.Sprintf("/image/%s/%s/", ctrl.C2Sn, uav.Header.Sn)
		uavPhoto := videostore.UavPhotoMsg{
			DevSn:          uav.Header.Sn,
			Classification: uavInfo.Classification,
			ObjID:          int32(uavInfo.ObjId),
			S3PrePath:      s3PrePath,
		}

		if val, ok := videostore.GPhotoMap.Get(KID); ok {
			if val.UploadStatus == videostore.Uploading {
				logger.Debug("uploading photo, KID = ", KID)
			} else if time.Now().UnixMilli()-val.TimeStamp > 5*1000 {
				logger.Debug("photo timeout exceeded, KID = ", KID)
				// delete(videostore.GPhotoMap, KID)
				videostore.VsSingleton.GoSaveToLocalPhotoAndPushToS3(uavPhoto)
				url = val.URL
				downloadUrl = val.DownloadUrl
				bucketName = val.Bucket
			} else {
				url = val.URL
				downloadUrl = val.DownloadUrl
				bucketName = val.Bucket
			}
		} else {
			videostore.VsSingleton.GoSaveToLocalPhotoAndPushToS3(uavPhoto)
		}
		if url == "" {
			logger.Debug("not upload photo url,due to photo is uploading")
		}
		uavData = append(uavData, &cloudPlatform.AgxUavData{
			ObjId:            int32(uavInfo.ObjId),
			Sn:               uav.Header.Sn,
			X:                uavInfo.X,
			Y:                uavInfo.Y,
			Z:                uavInfo.Z,
			Velocity:         uavInfo.Velocity,
			Azimuth:          uavInfo.Azimuth,
			Alive:            int32(uavInfo.Alive),
			ExistingProb:     float64(uavInfo.ExistingProb), //1-100
			StateType:        uavInfo.StateType,
			CreateTime:       time.Now().UnixMilli(),
			PtzLock:          uavInfo.AssocBit1,
			Classification:   uavInfo.Classification,
			ClassfyProb:      int32(uavInfo.ClassfyProb),
			Longitude:        uavInfo.Longitude,
			Latitude:         uavInfo.Latitude,
			PhotoURL:         url,
			DownloadPhotoURL: downloadUrl,
			PhotoBucket:      bucketName,
			EventID:          uav.EventId,
			DroneName:        uavInfo.DroneName,
		})

	}
	if len(uavData) == 0 {
		//没无人机，不需要上报。
		return
	}
	logger.Debug("uavData =", uavData)
	uavMessage := &cloudPlatform.AgxUavList{
		Body: uavData,
	}
	// encodedMessage
	encodedMessage, err := proto.Marshal(uavMessage)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       AgxUavURL,
			Sn:        ctrl.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   ctrl.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return
	}
	//对消息进行封装+head+crc
	encodedMessage = createPacket(encodedMessage)
	// 发送TCP消息
	if ctrl.Conn == nil || ctrl.IsLogin == false {
		return
	}
	_, err = ctrl.Conn.Write(encodedMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return
	}
}

func (ctrl *CloudTcpCli) ReportAgxDev(data []byte) {
	dev := &client.AgxDevStateInfo{}
	err := proto.Unmarshal(data, dev)
	if err != nil {
		logger.Error("agx Dev Unmarshal err:", err)
		return
	}
	//给云端发送
	devList := make([]*cloudPlatform.AgxDevSn, 0)
	for _, devInfo := range dev.Data.List {
		devList = append(devList, &cloudPlatform.AgxDevSn{
			DevType: devInfo.DevType,
			DevSn:   devInfo.DevSn,
		})
	}
	devData := make([]*cloudPlatform.AgxDevData, 0)
	devData = append(devData, &cloudPlatform.AgxDevData{
		Sn:         dev.Header.Sn,
		List:       devList,
		CreateTime: time.Now().UnixMilli(),
	})
	logger.Debug("DevData =", devData)
	uavMessage := &cloudPlatform.AgxDevList{
		Body: devData,
	}
	// encodedMessage
	encodedMessage, err := proto.Marshal(uavMessage)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       AgxDevListURL,
			Sn:        ctrl.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   ctrl.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return
	}
	//对消息进行封装+head+crc
	encodedMessage = createPacket(encodedMessage)
	// 发送TCP消息
	if ctrl.Conn == nil || ctrl.IsLogin == false {
		return
	}
	_, err = ctrl.Conn.Write(encodedMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return
	}
}

func (c *CloudTcpCli) ReportAgxPerceptionMsg(info []byte) {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	pcData := &client.AgxPerceptionInfo{}
	err := proto.Unmarshal(info, pcData)
	if err != nil {
		logger.Error("report sfl proto Unmarshal error: %v", err)
		return
	}

	pcInfo := make([]*cloudPlatform.AgxPerceptionReportInfo, 0)
	for _, v := range pcData.Data.List {
		pcInfo = append(pcInfo, &cloudPlatform.AgxPerceptionReportInfo{
			Id:             v.Id,
			Classification: v.Classification,
			RectX:          v.RectX,
			RectY:          v.RectY,
			RectW:          v.RectW,
			RectH:          v.RectH,
			RectXV:         v.RectXV,
			RectYV:         v.RectYV,
			ClassFyProb:    v.ClassFyProb,
			Type:           v.Type,
			TypeProb:       v.TypeProb,
			LoadLever:      v.LoadLever,
			DangerLever:    v.DangerLever,
			Azimuth:        v.Azimuth,
			Elevation:      v.Elevation,
			Range:          v.Range,
			MotionType:     v.MotionType,
			BTracked:       v.BTracked,
			NewOldVersion:  v.NewOldVersion,
			VisFlag:        v.VisFlag,
			VisX:           v.VisX,
			VisY:           v.VisY,
			VisW:           v.VisW,
			VisH:           v.VisH,
			VisYV:          v.VisYV,
			VisXV:          v.VisXV,
			InfFlag:        v.InfFlag,
			InfX:           v.InfX,
			InfY:           v.InfY,
			InfW:           v.InfW,
			InfH:           v.InfH,
			InfXV:          v.InfXV,
			InfYV:          v.InfYV,
		})
	}

	//给云端发送
	perctList := make([]*cloudPlatform.AgxPerceptionData, 0)

	perctList = append(perctList, &cloudPlatform.AgxPerceptionData{
		Sn:         pcData.Header.Sn,
		TimeStamp:  pcData.Data.TimeStamp,
		ObjId:      pcData.Data.ObjId,
		TargetId:   pcData.Data.TargetId,
		Zoom:       pcData.Data.Zoom,
		HFov:       pcData.Data.HFov,
		VFov:       pcData.Data.VFov,
		List:       pcInfo,
		CreateTime: time.Now().UnixMilli(),
	})
	logger.Debug("perctData = ", perctList)
	data := &cloudPlatform.AgxPerceptionList{
		Body: perctList,
	}

	// encodedMessage
	encodedMessage, err := proto.Marshal(data)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       AgxPerceptionUrl,
			Sn:        c.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   c.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return
	}
	//对消息进行封装+head+crc
	sendMessage := createPacket(encodedMessage)
	// 发送TCP消息
	if c.Conn == nil || c.IsLogin == false {
		return
	}
	_, err = c.Conn.Write(sendMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return
	}
	return
}

func (c *CloudTcpCli) ReportAgxPerceptionE0Msg(info []byte) {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()

	pcData := &client.AgxPerceptionE0Info{}
	if err := proto.Unmarshal(info, pcData); err != nil {
		logger.Errorf("report agx perceptionE0 info fail, %v", err)
		return
	}
	if pcData.GetData() == nil {
		logger.Errorf("data is nil")
		return
	}
	if pcData.GetData().GetSn() == "" {
		logger.Errorf("sn is empty")
		return
	}
	pcInfo := &cloudPlatform.AgxPerceptionE0ReportInfo{
		TimeStamp: pcData.GetData().GetTimeStamp(),
		// 设备ID号
		DevId: pcData.GetData().GetDevId(),
		// 设备序列号
		Sn: pcData.GetData().GetSn(),
		// 引导帧序号
		GuidanceCount: pcData.GetData().GetGuidanceCount(),
		// 空闲：0;
		// 引导转动：1
		// 搜索目标：2
		// 锁定：3
		WorkingStatus: pcData.GetData().GetWorkingStatus(),
		// 视觉目标ID
		VisionTargetId: pcData.GetData().GetVisionTargetId(),
		// 视觉目标宽度方向像素坐标
		VisionTargetU: pcData.GetData().GetVisionTargetU(),
		// 视觉目标高度方向像素坐标
		VisionTargetV: pcData.GetData().GetVisionTargetV(),
		// 视觉目标宽度方向像素速度
		VisionTargetVelocityU: pcData.GetData().GetVisionTargetVelocityU(),
		// 视觉目标高度方向像素速度
		VisionTargetVelocityV: pcData.GetData().GetVisionTargetVelocityV(),
		// 融合目标ID
		FusionTargetId: pcData.GetData().GetFusionTargetId(),
		// 融合目标的相对径向距离
		TargetLocalRange: pcData.GetData().GetTargetLocalRange(),
		// 融合目标的相对水平面距离
		TargetLocalHorizontalRange: pcData.GetData().GetTargetLocalHorizontalRange(),
		// 融合目标的对地高度
		Height: pcData.GetData().GetHeight(),
		// PTZ水平角度
		GuidingLocalAzimuth: pcData.GetData().GetGuidingLocalAzimuth(),
		// PTZ俯仰角度
		GuidingLocalElevation: pcData.GetData().GetGuidingLocalElevation(),
		Longitude:             pcData.GetData().GetLongitude(),
		Latitude:              pcData.GetData().GetLatitude(),
		Altitude:              pcData.GetData().GetAltitude(),
		// 未知类别：0
		// 无人机：1
		// 行人：2
		// 车辆：3
		// 鸟：4
		// 客机：5
		// 其他：100
		// 分类无效：127
		FusionTargetClassification: pcData.GetData().GetFusionTargetClassification(),
		// 画中画: 0开启了，1未开启
		PipValid: pcData.GetData().GetPipValid(),
		// 备用
		Reserve: pcData.GetData().GetReserve(),
	}

	//定义云端数据内容
	perctList := make([]*cloudPlatform.AgxPerceptionE0ReportInfo, 0)
	perctList = append(perctList, pcInfo)
	logger.Debugf("e0 perctData = %v", perctList)
	data := &cloudPlatform.AgxPerceptionListE0{
		Body: perctList,
	}
	// encodedMessage
	encodedMessage, err := proto.Marshal(data)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       AgxPerceptionUrl,
			Sn:        c.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   c.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return
	}
	//对消息进行封装+head+crc
	sendMessage := createPacket(encodedMessage)
	// 发送TCP消息
	if c.Conn == nil || c.IsLogin == false {
		return
	}
	_, err = c.Conn.Write(sendMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return
	}
	return
}

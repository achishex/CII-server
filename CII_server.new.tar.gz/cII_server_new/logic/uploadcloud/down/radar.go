package down

import (
	"context"
	"encoding/json"
	"fmt"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"

	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/logic/uploadcloud/mqtt"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
)

// opsCode define
const (
	OPSRadarGetBeamConfig            = 1
	OPSRadarStartDetect              = 2
	OPSRadarEndDetect                = 3
	OPSRadarSetBeamSchedule          = 4
	OPSRadarPostureCalibration       = 5
	OPSRadarPostureCalibrationManual = 6
	OPSRadarGetVersionInfo           = 7
	OPSRadarSetClutterSuppression    = 8  // 设置杂波抑制参数
	OPSRadarSetConfig                = 9  // 雷达设置参数
	OPSRadarGetConfig                = 10 // 雷达获取参数
)

func radarPropertyTopicName() string {
	return propertySubTopic(common.Radar)
}

func radarSvcTopicName() string {
	return svcSubTopic(common.Radar)
}

func doRadarLogic(m mqtt.Message) ([]byte, int32) {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	logger.Debug("m = ", string(m.Payload()))
	p, err := decodeMessage(m.Payload())
	//json Marshal or UnMarshal error
	if p == nil {
		logger.Error("decodeMessage is nil")
		return nil, mqtt_V1
	}
	errJSONTypeMsg := errorMsg(jsonFail, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, jsonFailMsg)
	logger.Info("errMsg = ", errJSONTypeMsg)
	if err != nil {
		logger.Error("decodeMessage error = ", err)
		return encodeMessage(errJSONTypeMsg)
	}
	encodeOkmsg := make([]byte, 0)
	logger.Debug("p.MsgData.Data.OpsCode = ", p.MsgData.Data.OpsCode)
	switch p.MsgData.Data.OpsCode {
	case OPSRadarGetBeamConfig:
		req := &client.RadarGetBeamConfigRequest{}
		ctx := context.Background()
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("json Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.RadarGetBeamConfigResponse{}

		err = handler.NewDeviceCenter().RadarGetBeamConfig(ctx, req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg, _ := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg, mqtt_V1
		}
		// 获取杂波抑制信息
		getClutterSuppressionReq := &client.RadarGetClutterSuppressionRequest{
			Sn: req.Sn,
		}
		getClutterSuppressionResp := &client.RadarGetClutterSuppressionResponse{}
		err = handler.NewDeviceCenter().RadarGetClutterSuppression(ctx, getClutterSuppressionReq, getClutterSuppressionResp)
		logger.Debug("getClutterSuppressionResp = ", getClutterSuppressionResp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg, _ := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg, mqtt_V1
		}
		resp.DetectMode = getClutterSuppressionResp.DetectMode
		resp.Param = getClutterSuppressionResp.Param
		resp.Distance = getClutterSuppressionResp.Distance

		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		encodeOkmsg, _ = encodeMessage(smsg)
	case OPSRadarStartDetect:
		req := &client.RadarStartDetectRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("json marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("json Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.RadarStartDetectResponse{}

		err = handler.NewDeviceCenter().RadarStartDetect(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg, _ := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg, mqtt_V1
		}
		smsg := mqttPubMsg{}
		if resp.Status == 0 {
			resp := &radarStatusResponse{Status: statusSuccess}
			smsg = successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)

		} else {
			resp := &radarStatusResponse{Status: statusFail}
			smsg = successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		}
		encodeOkmsg, _ = encodeMessage(smsg)

	case OPSRadarEndDetect:
		req := &client.RadarEndDetectRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("json marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("json Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.RadarEndDetectResponse{}

		err = handler.NewDeviceCenter().RadarEndDetect(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg, _ := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg, mqtt_V1
		}
		smsg := mqttPubMsg{}
		if resp.Status == 0 {
			resp := &radarStatusResponse{Status: statusSuccess}
			smsg = successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)

		} else {
			resp := &radarStatusResponse{Status: statusFail}
			smsg = successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		}
		encodeOkmsg, _ = encodeMessage(smsg)
	case OPSRadarSetBeamSchedule:
		req := &client.RadarSetBeamScheduleRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("json marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("json Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.RadarSetBeamScheduleResponse{}

		err = handler.NewDeviceCenter().RadarSetBeamSchedule(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg, _ := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg, mqtt_V1
		}

		smsg := mqttPubMsg{}
		if resp.Status == 0 {
			resp := &radarStatusResponse{Status: statusSuccess}
			smsg = successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)

		} else {
			resp := &radarStatusResponse{Status: statusFail}
			smsg = successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		}
		encodeOkmsg, _ = encodeMessage(smsg)

	case OPSRadarPostureCalibration:
		req := &client.PostureCalibrationRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("json marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("json Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.PostureCalibrationResponse{}

		err = handler.NewDeviceCenter().PostureCalibration(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg, _ := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg, mqtt_V1
		}
		smsg := mqttPubMsg{}
		if resp.Status == 0 {
			resp := &radarStatusResponse{Status: statusSuccess}
			smsg = successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)

		} else {
			resp := &radarStatusResponse{Status: statusFail}
			smsg = successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		}
		encodeOkmsg, _ = encodeMessage(smsg)
	case OPSRadarPostureCalibrationManual:
		req := &client.PostureCalibrationManualRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("json marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("json Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.PostureCalibrationManualResponse{}

		err = handler.NewDeviceCenter().PostureCalibrationManual(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg, _ := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg, mqtt_V1
		}
		smsg := mqttPubMsg{}
		if resp.Status == 0 {
			resp := &radarStatusResponse{Status: statusSuccess}
			smsg = successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)

		} else {
			resp := &radarStatusResponse{Status: statusFail}
			smsg = successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		}
		encodeOkmsg, _ = encodeMessage(smsg)
	case OPSRadarGetVersionInfo:
		req := &client.RadarGetVersionInfoRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("json marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("json Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.RadarGetVersionInfoResponse{}

		err = handler.NewDeviceCenter().RadarGetVersionInfo(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg, _ := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg, mqtt_V1
		}
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		encodeOkmsg, _ = encodeMessage(smsg)
	case OPSRadarSetClutterSuppression:
		req := &client.RadarSetClutterSuppressionRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("json marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("json Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.RadarSetClutterSuppressionResponse{}

		err = handler.NewDeviceCenter().RadarSetClutterSuppression(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg, _ := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg, mqtt_V1
		}

		smsg := mqttPubMsg{}
		if resp.Status == 0 {
			resp := &radarStatusResponse{Status: statusSuccess}
			smsg = successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)

		} else {
			resp := &radarStatusResponse{Status: statusFail}
			smsg = successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		}
		encodeOkmsg, _ = encodeMessage(smsg)
	case OPSRadarSetConfig:
		req := &client.RadarSetConfigRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("json marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("json Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.RadarSetConfigResponse{}

		err = handler.NewDeviceCenter().RadarSetConfig(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg, _ := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg, mqtt_V1
		}

		smsg := mqttPubMsg{}
		if resp.Status == 0 {
			resp := &radarStatusResponse{Status: statusSuccess}
			smsg = successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)

		} else {
			resp.Status = statusFail
			smsg = successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		}
		encodeOkmsg, _ = encodeMessage(smsg)
	case OPSRadarGetConfig:
		req := &client.RadarGetConfigRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("json marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("json Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.RadarGetConfigResponse{}

		err = handler.NewDeviceCenter().RadarGetConfig(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg, _ := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg, mqtt_V1
		}
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		encodeOkmsg, _ = encodeMessage(smsg)

	default:
		unknownOps := errorMsg(unknowOpsCode, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, unknowOpsCodeMsg)
		return encodeMessage(unknownOps)
	}
	logger.Debug("encodeSmsg = ", encodeOkmsg)
	return encodeOkmsg, mqtt_V1
}

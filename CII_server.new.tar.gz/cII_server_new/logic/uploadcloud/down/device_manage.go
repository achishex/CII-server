package down

import (
	"context"
	"encoding/json"
	"fmt"
	"strconv"
	"strings"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"github.com/google/uuid"

	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/logic/uploadcloud/mqtt"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
)

// ref: https://confluence.autel.com/pages/viewpage.action?pageId=437190813
const (

	//device propety
	sga_C2_type = 1000 + iota
	sfl_type
	tracer_type
	tracerRf_type
	fpv_type
	gun_type
	nsf4000_type
	agx_type
	radar_type
	sfl200_type
	dph100_type
	//domain define
	c2Domain       = 4
	registerMethod = "device_register"
	deviceSecret   = ""
	index          = ""
)

func changeEtypeToType(etype string) int {
	switch etype {
	case common.Drone:
		return tracer_type
	case common.Radar:
		return radar_type
	case common.Sfl:
		return sfl_type
	case common.FPV:
		return fpv_type
	case common.NSF400:
		return nsf4000_type
	case common.TracerRFurd360:
		return tracerRf_type
	case common.Agx:
		return agx_type
	case common.Sfl200:
		return sfl200_type
	case common.DPH110:
		return dph100_type
	default:
		return 0
	}
}

// 定义设备结构体
type DeviceDetail struct {
	SN           string         `json:"sn"`
	Domain       int            `json:"domain"`
	Type         int            `json:"type"`
	SubType      int            `json:"sub_type"`
	ThingVersion string         `json:"thing_version"`
	DeviceSecret string         `json:"device_secret"`
	Nonce        string         `json:"nonce"`
	Index        string         `json:"index"`
	Name         string         `json:"name,omitempty"`
	Longitude    string         `json:"longitude"`
	Latitude     string         `json:"latitude"`
	SubDevices   []DeviceDetail `json:"sub_devices,omitempty"`
}

// 定义数据结构体
type Data struct {
	Domain       int            `json:"domain"`
	Type         int            `json:"type"`
	SubType      int            `json:"sub_type"`
	ThingVersion string         `json:"thing_version"`
	DeviceSecret string         `json:"device_secret"`
	Nonce        string         `json:"nonce"`
	Index        string         `json:"index"`
	Longitude    string         `json:"longitude"`
	Latitude     string         `json:"latitude"`
	SubDevices   []DeviceDetail `json:"sub_devices"`
}

// 定义主结构体
type RegisterRequest struct {
	TID       string `json:"tid"`
	BID       string `json:"bid"`
	Method    string `json:"method"`
	Timestamp int64  `json:"timestamp"`
	Data      Data   `json:"data"`
}

func genNonce() string {
	return ""
	// return uuid.New().String()
}

/*
	1,首次运行时候，查数据库获取数据值。将值存储到 map中，key 为 sn，value 为值。
		1.1 将所有设备 sn
		sn abc psn-> nil
		sn bbb psn-> nil
		sn ccc psn-> nil
		sn ddd psn-> abc

		range 所有设备，存在 psn非空的话，放到 childMap 中； psn 为空放到 parentMap 中。
		range parentMap， 在RegisterRequest.Data中添加dev信息，range childMap，查看是否有parentSN
		为该设备的，有的话直接append该设备，并从childMap中删除该设备。完成设备信息的获取。

	2，启动一个协程，定时一秒获取设备列表状态。如果状态 有更新，则进行更新，否则不需要。
	3，定时上报数据。10秒一次，如果设备数量有变更，再上报一条的设备状态中。
*/

func getEquipListPub(s *mqtt.Adaptor) {
	dbequips := &client.EquipListRes{}
	err := handler.NewEquipList().List(context.Background(), &client.EquipListReq{}, dbequips)
	logger.Info("dbequips = ", dbequips)
	if err != nil {
		logger.Error("Get EquipList err: ", err)
	}
	//获取设备版本号
	configInfo := &client.ConfigRes{}
	err = handler.NewSystemConfig().GetSystemConfig(context.Background(), &client.ConfigReq{}, configInfo)
	logger.Info("configInfo = ", configInfo)
	if err != nil {
		logger.Error("Get SystemConfig err: ", err)
	}
	var reg RegisterRequest
	reg.TID = uuid.NewString()
	reg.BID = uuid.NewString()
	reg.Method = registerMethod
	reg.Data.Domain = c2Domain
	reg.Data.Type = sga_C2_type
	reg.Data.SubType = 0
	reg.Data.ThingVersion = bean.GAppVersion
	logger.Debug("c2 system version", bean.GAppVersion)
	reg.Data.DeviceSecret = deviceSecret
	reg.Data.Nonce = genNonce()
	reg.Data.Longitude = strconv.FormatFloat(configInfo.C2Longitude, 'f', 6, 64)
	reg.Data.Latitude = strconv.FormatFloat(configInfo.C2Latitude, 'f', 6, 64)

	// parentDevMap := make(map[string]DeviceDetail, 0)
	parentDevMap := make(map[string]int, 0)
	childDevMap := make(map[string]DeviceDetail, 0)

	allDevMap := make(map[string]*client.List, 0)
	connectStr := "#+#"
	for _, v := range dbequips.Equips {
		allDevMap[v.Sn] = v
		var devDetail DeviceDetail
		devDetail.SN = v.Sn
		devDetail.Domain = c2Domain
		devDetail.Type = changeEtypeToType(v.Etype)
		devDetail.SubType = int(v.SubDevType)
		devDetail.ThingVersion = v.DevVersion
		devDetail.DeviceSecret = deviceSecret
		devDetail.Nonce = genNonce()
		devDetail.Index = index
		devDetail.Name = v.Name
		devDetail.Longitude = strconv.FormatFloat(configInfo.C2Longitude, 'f', 6, 64)
		devDetail.Latitude = strconv.FormatFloat(configInfo.C2Latitude, 'f', 6, 64)
		devDetail.SubDevices = make([]DeviceDetail, 0)
		if v.ParentSn == "" {
			// parentDevMap[v.Sn] = devDetail
			parentInC2SubDevIndex := len(reg.Data.SubDevices)
			reg.Data.SubDevices = append(reg.Data.SubDevices, devDetail)
			parentDevMap[v.Sn] = parentInC2SubDevIndex
			logger.Debug("parentInC2SubDevIndex = ", parentInC2SubDevIndex, " sn = ", v.Sn)
			logger.Debugf("first c2 sub dev = %+v", devDetail)
		} else {
			if index, ok := parentDevMap[v.ParentSn]; ok {
				reg.Data.SubDevices[index].SubDevices = append(reg.Data.SubDevices[index].SubDevices, devDetail)

				logger.Debugf("dev has been add  %+v ", devDetail)
			} else {
				childDevMap[v.ParentSn+connectStr+v.Sn] = devDetail
				logger.Debugf("add childDevMap, devDetail msg = %+v", devDetail)
				logger.Debug("childDev parent sn = ", v.ParentSn)
				logger.Debug("childDev sn = ", v.Sn)
			}
		}
	}
	type tupleInt struct {
		first  int
		second int
	}
	childDevMapIndex := make(map[string]tupleInt, 0)
	for k, v := range childDevMap {
		if index, ok := parentDevMap[strings.Split(k, connectStr)[0]]; ok {
			reg.Data.SubDevices[index].SubDevices = append(reg.Data.SubDevices[index].SubDevices, v)
			logger.Debugf("add sub dev %+v ", v)
			logger.Debug("add child sn = ", v.SN)
			childDevMapIndex[v.SN] = tupleInt{first: index, second: len(reg.Data.SubDevices[index].SubDevices) - 1}
			delete(childDevMap, k)
		} else {
			logger.Debugf("leave third sub dev may under agx of slf200, devDetail = %+v", v)
			logger.Debug("thrid sub dev sn = ", v.SN)
		}
		logger.Debug("dev sn = ", v.SN)
	}

	for k, v := range childDevMap {
		if index, ok := allDevMap[strings.Split(k, connectStr)[0]]; ok {
			// reg.Data.SubDevices[index].SubDevices = append(reg.Data.SubDevices[index].SubDevices, v)
			if value, ok := childDevMapIndex[strings.Split(k, connectStr)[0]]; ok {
				reg.Data.SubDevices[value.first].SubDevices[value.second].SubDevices = append(reg.Data.SubDevices[value.first].SubDevices[value.second].SubDevices, v)
				logger.Debug("dev sn = ", v.SN)
			} else {
				logger.Errorf("leave should in second sub dev, parent sn = %+v, msg = %+v", k, index)
				logger.Debug("dev sn = ", v.SN)
			}
		} else {
			logger.Errorf("db error = %+v", v)
			logger.Debug("dev sn = ", v.SN)
		}
	}

	logger.Debugf("reg msg = %+v", reg)
	bmsg, err := json.Marshal(reg)
	if err != nil {
		logger.Error("josn marshal error", err)
	}

	//logger.Debug("bmsg = ", bmsg)

	s.Publish(registerSubTopic_V2(), bmsg)
}

func checkEquipListRegister(ctx context.Context, s *mqtt.Adaptor) {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("error msg : %v", r)
			logger.Error("error msg :", err)
			checkEquipListRegister(ctx, s)
		}
	}()
	getEquipListPub(s)

	select {
	case <-bean.GupdateEquipListNotify:
		logger.Debug("recive equip add .")
		getEquipListPub(s)
	case <-ctx.Done():
		logger.Debug("rcv ctx done signal .")
		return

	}
}

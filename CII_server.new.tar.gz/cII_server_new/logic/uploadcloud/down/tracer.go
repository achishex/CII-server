package down

import (
	"context"
	"encoding/json"
	"fmt"
	"sync"
	"time"

	"adasgitlab.autel.com/tools/cuav_server/proto/cloudPlatform"
	"adasgitlab.autel.com/tools/cuav_server/proto/mavlink"
	uuid "github.com/satori/go.uuid"
	"google.golang.org/protobuf/proto"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/logic/uploadcloud/mqtt"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
)

// opsCode define
const (
	opsTracerSetAlarm           = 1
	opsTracerSetHideMode        = 2
	opsTracerGetVersionInfo     = 3
	opsTracerGetInfo            = 4
	opsTracerGetWorkMode        = 5
	opsTracerSetOrientationMode = 6
)

var (
	GTracerPropertyStatus   sync.Map
	gTracerStateMessageSync gsfl200StateType
	gTracerState            mqttTracerPubMsgData
)

type TracerSetConfigResponse struct {
	Result int32 `json:"result"` // 0: 成功，1：失败，2：超时
}

type mqttTracerPubMsg struct {
	Tid       string               `json:"tid"`
	Bid       string               `json:"bid"`
	Timestamp int64                `json:"timestamp"`
	NeedReply int64                `json:"need_reply"`
	Data      mqttTracerPubMsgData `json:"data"`
}

type mqttTracerPubMsgData struct {
	Sn           string            `json:"sn"`
	EType        string            `json:"etype"`
	TracerConfig *freqListResponse `json:"configPara"`
}

func tracerPPropertyTopicName() string {
	return propertySubTopic(common.Drone)
}

func tracerPSvcTopicName() string {
	return svcSubTopic(common.Drone)
}

func doTracerPLogic(m mqtt.Message) ([]byte, int32) {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	logger.Debug("m = ", m.Payload())
	p, err := decodeMessage(m.Payload())
	//json Marshal or UnMarshal error
	errJSONTypeMsg := errorMsg(jsonFail, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, jsonFailMsg)
	logger.Error("errMsg = ", errJSONTypeMsg)
	if err != nil {
		logger.Error("decodeMessage error = ", err)
		return encodeMessage(errJSONTypeMsg)
	}
	encodeOkmsg := make([]byte, 0)
	logger.Debug("p.MsgData.Data.OpsCode = ", p.MsgData.Data.OpsCode)
	switch p.MsgData.Data.OpsCode {
	case opsTracerSetAlarm:
		req := &client.TracerSetAlarmRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.TracerSetAlarmResponse{}

		err = handler.NewDeviceCenter().TracerSetAlarm(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg, _ := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg, mqtt_V1
		}
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		encodeOkmsg, _ = encodeMessage(smsg)
	case opsTracerSetHideMode:
		req := &client.TracerSetHideModeRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.TracerSetHideModeResponse{}

		err = handler.NewDeviceCenter().TracerSetHideMode(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg, _ := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg, mqtt_V1
		}
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		encodeOkmsg, _ = encodeMessage(smsg)
	case opsTracerGetVersionInfo:
		req := &client.TracerGetVersionInfoRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.TracerGetVersionInfoResponse{}

		err = handler.NewDeviceCenter().TracerGetVersionInfo(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg, _ := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg, mqtt_V1
		}
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		encodeOkmsg, _ = encodeMessage(smsg)
	case opsTracerGetInfo:
		req := &client.TracerGetInfoRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.TracerGetInfoResponse{}

		err = handler.NewDeviceCenter().TracerGetInfo(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg, _ := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg, mqtt_V1
		}
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		encodeOkmsg, _ = encodeMessage(smsg)
	case opsTracerGetWorkMode:
		req := &client.TracerGetWorkModeRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.TracerGetWorkModeResponse{}

		err = handler.NewDeviceCenter().TracerGetWorkMode(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg, _ := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg, mqtt_V1
		}
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		encodeOkmsg, _ = encodeMessage(smsg)
	case opsTracerSetOrientationMode:
		req := &client.TracerSetOrientationModeRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.TracerSetOrientationModeResponse{}

		err = handler.NewDeviceCenter().TracerSetOrientationMode(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg, _ := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg, mqtt_V1
		}
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		encodeOkmsg, _ = encodeMessage(smsg)
	default:
		unknownOps := errorMsg(unknowOpsCode, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, unknowOpsCodeMsg)
		return encodeMessage(unknownOps)
	}
	logger.Debug("encodeSmsg = ", encodeOkmsg)
	return encodeOkmsg, mqtt_V1
}

func doTracerPLogic_V3(m mqtt.Message) ([]byte, int32) {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()

	p, err := decodeMessageV3(m.Payload())
	logger.Info("p.Payload = ", string(m.Payload()))
	if p.URL != "/ws/v1/device/tracer/forward/uav" {
		return nil, mqtt_V3
	}
	if err != nil {
		logger.Error("decodeMessage error = ", err)
	}
	var deMsg cloudPlatform.TraceUavSystemList

	err = proto.Unmarshal(p.MsgData.Body, &deMsg)
	if err != nil {
		logger.Error("decodeMessage error = ", err)
		return nil, mqtt_V3
	}
	logger.Debugf("deMsg = %+v", deMsg.Body)
	for _, v := range deMsg.Body {
		logger.Debugf("v = %+v", v)
		r := &mavlink.TracerPSendToAGX{}
		r.Upload = v.Data
		handler.NewDeviceCenter().TracerPToAgx(r)
	}

	return nil, mqtt_V3
}

// 上报Tracer配置参数
func UploadTracerPropertyStatus(ctx context.Context, s *mqtt.Adaptor) {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("error msg : %v", r)
			logger.Error("error msg :", err)
			UploadTracerPropertyStatus(ctx, s)
		}
	}()
	time.Sleep(1 * time.Second)
	ticker := time.NewTicker(5 * time.Second)
	var IsNotFirstUpload bool
	defer ticker.Stop()
	for {
		select {
		case <-ticker.C:
			if s != nil {
				getTracerPropertyStatus(s, &IsNotFirstUpload)
			} else {
				logger.Error("error msg :mqtt handler not initialized")
			}
		case <-ctx.Done():
			return
		}
	}
}

func getTracerPropertyStatus(s *mqtt.Adaptor, IsNotFirstUpload *bool) {
	GTracerPropertyStatus.Range(func(key, value any) bool {
		tracerSn := key.(string)
		deviceType := value.(string)

		resp := &client.TracerGetFreqListResponse{}
		deviceReq := &client.TracerGetFreqListRequest{
			Sn: tracerSn,
		}

		err := handler.NewDeviceCenter().TracerDetectFreqList(context.Background(), deviceReq, resp)
		if err != nil {
			logger.Error("getTracerPropertyStatus TracerDetectFreqList error: ", err)
			return false
		}

		bid := uuid.NewV4().String()
		tid := uuid.NewV4().String()
		pubMsg := mqttTracerPubMsg{
			Bid:       bid,
			Tid:       tid,
			Timestamp: time.Now().UnixMilli(),
			NeedReply: 1,
			Data: mqttTracerPubMsgData{
				Sn:           tracerSn,
				EType:        deviceType,
				TracerConfig: &freqListResponse{FreqList: resp.FreqList},
			},
		}
		logger.Debugf("getTracerPropertyStatus pubMsg: %v", pubMsg)
		bMsg, err := json.Marshal(pubMsg)
		if err != nil {
			logger.Error("getTracerPropertyStatus Marshal pubMsg error: ", err)
		}

		// stateSubTopic_V2
		if !*IsNotFirstUpload {
			s.Publish(stateSubTopic_V2(), bMsg)
			gTracerStateMessageSync.Bid = bid
			gTracerStateMessageSync.Tid = tid
			gTracerStateMessageSync.IsWaitReply = true
			gTracerStateMessageSync.TryTime++
			gTracerState = pubMsg.Data
			logger.Debug("first upload msg of gTracerState is ", pubMsg.Data)
			for gTracerStateMessageSync.TryTime < MaxTryTime {
				time.Sleep(1 * time.Second)
				if !gTracerStateMessageSync.IsWaitReply {
					break
				}
				gTracerStateMessageSync.TryTime++
			}
			*IsNotFirstUpload = true
		} else {
			if !tracerConfigDeepEqual(gTracerState.TracerConfig, pubMsg.Data.TracerConfig) {
				s.Publish(stateSubTopic_V2(), bMsg)
				gTracerStateMessageSync.Bid = bid
				gTracerStateMessageSync.Tid = tid
				gTracerStateMessageSync.IsWaitReply = true
				gTracerStateMessageSync.TryTime++
				logger.Debug("new msg of gTracerState is ", pubMsg.Data)
				for gTracerStateMessageSync.TryTime < MaxTryTime {
					time.Sleep(1 * time.Second)
					if !gTracerStateMessageSync.IsWaitReply {
						break
					}
					gTracerStateMessageSync.TryTime++
				}
				gTracerState = pubMsg.Data
			} else {
				logger.Debug("old msg of gTracerState is ", gTracerState)
			}
		}
		return true
	})
}

func tracerConfigDeepEqual(src, dst *freqListResponse) bool {
	return equalSlices(src.FreqList, dst.FreqList)
}

package down

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	paho "github.com/eclipse/paho.mqtt.golang"

	"adasgitlab.autel.com/tools/cuav_server/logic/uploadcloud/mqtt"
	"adasgitlab.autel.com/tools/cuav_server/logic/uploadcloud/udp"
	videostore "adasgitlab.autel.com/tools/cuav_server/logic/uploadcloud/videoStore"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
)

var gC2sn = ""

const (
	success          = 0
	offline          = 70001
	deviceError      = 70002
	unknowOpsCode    = 70003
	jsonFail         = 70004
	syncFenceError   = 701000
	jsonFailMsg      = "request param invalid"
	unknowOpsCodeMsg = "unknow opsCode"
	successMsg       = "operation successful"
	offlineMsg       = "device offline"
)

// V2 define
const (
	errorJson  = 1
	opsFail    = 1
	unsportOps = 3
	ouverTime  = 4
	devOffline = 3
)

func propertySubTopic(deviceName string) string {
	topic := fmt.Sprintf("/mqtt/v1/cloud/%s/%s/property/set", deviceName, gC2sn)
	logger.Debug("topic = ", topic)
	return topic
}

func svcSubTopic(deviceName string) string {
	topic := fmt.Sprintf("/mqtt/v1/cloud/%s/%s/services/get", deviceName, gC2sn)
	logger.Debug("topic = ", topic)
	return topic
}
func propertySubTopic_V2() string {
	topic := fmt.Sprintf("thing/product/%s/property/set", gC2sn)
	logger.Debug("v2 topic = ", topic)
	return topic
}

func stateSubTopic_V2() string {
	topic := fmt.Sprintf("thing/product/%s/state", gC2sn)
	logger.Debug("v2 topic = ", topic)
	return topic
}
func stateReplySubTopic_V2() string {
	topic := fmt.Sprintf("thing/product/%s/state_reply", gC2sn)
	logger.Debug("v2 topic = ", topic)
	return topic
}

func propertySubTopic_V3() string {
	topic := fmt.Sprintf("thing/product/%s/osu", gC2sn)
	logger.Debug("v3 topic = ", topic)
	return topic
}

func servicesSubTopic_V2() string {
	topic := fmt.Sprintf("thing/product/%s/services", gC2sn)
	logger.Debug("v2 topic = ", topic)
	return topic
}

func s3SubTopic_V3() string {
	topic := fmt.Sprintf("thing/product/%s/requests_reply", gC2sn)
	logger.Debug("v3 topic = ", topic)
	return topic
}

func registerSubTopic_V2() string {
	topic := fmt.Sprintf("thing/product/%s/register", gC2sn)
	logger.Debug("v2 topic = ", topic)
	return topic
}

const (
	pingTopic = "/ping"
)

const (
	mqtt_V1 int32 = 1
	mqtt_V2 int32 = 2
	//state_reply: to diff from V2 different topic define, perf me @fzw
	mqtt_V2_stateReply int32 = 20002
	mqtt_V3            int32 = 3
)

type pingPayload struct {
	TimeStamp string `json:"timeStamp"`
	Sn        string `json:"sn"`
}

func ping(m mqtt.Message) ([]byte, int32) {
	// logger.Debug("m = ", m.Payload())
	p, _ := decodeMessage(m.Payload())
	// logger.Debug(p)
	// logger.Debug("sub ping message timestamp = ", p.Timestamp)
	curtime := time.Now().UnixMilli()
	gapTime := (curtime - p.Timestamp) / 1000
	// logger.Debug("gap time = ", gapTime)
	if gapTime > 1 {
		logger.Debug("bad network  = ", gapTime)
	}
	return m.Payload(), mqtt_V1
}

// RegisterSubHandlers ...
func RegisterSubHandlers(adaptor *mqtt.Adaptor) {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	if adaptor == nil {
		return
	}
	consumes := []mqtt.DoRoute{
		{
			Topic:   pingTopic,
			Handler: ping,
		},
		{
			Topic:   sflSvcTopicName(),
			Handler: doSflLogic,
		},
		{
			Topic:   sflPropertyTopicName(),
			Handler: doSflLogic,
		},
		{
			Topic:   agxSvcTopicName(),
			Handler: doAgxLogic,
		},
		{
			Topic:   agxPropertyTopicName(),
			Handler: doAgxLogic,
		},
		{
			Topic:   tracerPSvcTopicName(),
			Handler: doTracerPLogic,
		},
		{
			Topic:   tracerPPropertyTopicName(),
			Handler: doTracerPLogic,
		},
		{
			Topic:   nsf400PSvcTopicName(),
			Handler: donsf400Logic,
		},
		{
			Topic:   nsf400PropertyTopicName(),
			Handler: donsf400Logic,
		},
		{
			Topic:   urd360PSvcTopicName(),
			Handler: doUrd360Logic,
		},
		{
			Topic:   urd360PropertyTopicName(),
			Handler: doUrd360Logic,
		},
		// 单独雷达的配置指令，之前是嵌在agx下的，抽离出来
		{
			Topic:   radarSvcTopicName(),
			Handler: doRadarLogic,
		},
		{
			Topic:   radarPropertyTopicName(),
			Handler: doRadarLogic,
		},
		{
			Topic:   propertySubTopic_V2(),
			Handler: doSfl200Logic_V2,
		},
		{
			Topic:   servicesSubTopic_V2(),
			Handler: doFencesLogic,
		},
		{
			Topic:   propertySubTopic_V3(),
			Handler: doTracerPLogic_V3,
		},
		{
			Topic:   stateReplySubTopic_V2(),
			Handler: getSfl200PropertyStatusReply,
		},
		{
			Topic:   stateReplySubTopic_V2(),
			Handler: getAgxUnderSfl200PropertyStatusReply,
		},
		{
			Topic:   servicesSubTopic_V2(),
			Handler: doUavWhiteListLogic_V2,
		},
		{
			Topic:   s3SubTopic_V3(),
			Handler: videostore.DoS3Token_V3,
		},
	}
	adaptor.AddSubHandlers(consumes)
}

// MqttLoginConfig ...
type MqttLoginConfig struct {
	URL      string
	ClientID string
	Account  string
	Passwd   string
	C2sn     string
	Ctx      context.Context
}

type data struct {
	OpsCode int32       `json:"opsCode"`
	Payload interface{} `json:"payload"`
}

type msgSubData struct {
	Data data `json:"data"`
}

// // 目标PTZ跟踪
// type Sfl200PtzFollowUavRequest struct {
// 	Sn             string `json:"sn,omitempty"`
// 	Etype          string `json:"etype,omitempty"`
// 	SerialNum      string `json:"serialNum,omitempty"`
// 	Classification int32  `json:"classification,omitempty"`
// }

// // 目标PTZ跟踪
// type Sfl200DealUavRequest struct {
// 	Sn             string `json:"sn,omitempty"`
// 	Etype          int32  `json:"etype,omitempty"`
// 	SerialNum      string `json:"serialNum,omitempty"`
// 	Classification int32  `json:"classification,omitempty"`
// }

type msgSubDataV2 struct {
	Sfl200SetWorkModeRequest       *client.Sfl200SetWorkModeRequest       `json:"Sfl200SetWorkModeRequest,omitempty"`
	Sfl200SetAutoHitConfigRequest  *client.Sfl200SetAutoHitConfigRequest  `json:"Sfl200SetAutoHitConfigRequest,omitempty"`
	Sfl200PtzFollowUavRequest      *client.Sfl200PtzFollowUavRequest      `json:"Sfl200PtzFollowUavRequest,omitempty"`
	Sfl200DealUavRequest           *client.Sfl200DealUavRequest           `json:"Sfl200DealUavRequest,omitempty"`
	Sfl200FreqDirectRequest        *client.Sfl200FreqDirectRequest        `json:"Sfl200FreqDirectRequest,omitempty"`
	Sfl200FreqDirectHitRequest     *client.Sfl200FreqDirectHitRequest     `json:"Sfl200FreqDirectHitRequest,omitempty"`
	Sfl200StartStopHitRequest      *client.Sfl200StartStopHitRequest      `json:"Sfl200StartStopHitRequest,omitempty"`
	Sfl200TurnSflRequest           *client.Sfl200TurnSflRequest           `json:"Sfl200TurnSflRequest,omitempty"`
	Sfl200StartNsf4000Request      *client.Sfl200StartNsf4000Request      `json:"Sfl200StartNsf4000Request,omitempty"`
	Sfl200SystemWorkSettingRequest *client.Sfl200SystemWorkSettingRequest `json:"Sfl200SystemWorkSettingRequest,omitempty"`
	FenceList                      []*client.Fence                        `json:"fenceList,omitempty"`
	Sfl200AgxCalibrationParaSet    *client.AgxSetCalibrationParaRequest   `json:"Sfl200AgxCalibrationParaSet,omitempty"`
	WhiteItems                     []*ItemData                            `json:"uavBlackWhiteRuleList,omitempty"`
	Items                          *UavBlackWhiteRule                     `json:"items,omitempty"`
	DPH110SetConfigRequest         *client.RadarSetConfigRequest          `json:"DPH110SetConfigSet,omitempty"`
	TracerNoiseFloorSetRequest     *client.TracerNoiseSet                 `json:"TracerNoiseSet,omitempty"`
	SFLNoiseFloorSetRequest        *client.SFLNoiseSet                    `json:"SFLNoiseSet,omitempty"`
}

type msgSubStateReplyDataV2 struct {
	Result int `json:"result"`
}
type msgSubDataV3 struct {
	Body []byte `json:"body"`
}

type result struct {
	ErrorCode int32  `json:"errorCode"`
	ErrorMsg  string `json:"errorMsg"`
}

type msgpubData struct {
	Data   data   `json:"data"`
	Result result `json:"result"`
}

type mqttSubMsg struct {
	Tid       string     `json:"tid"`
	Bid       string     `json:"bid"`
	Sn        string     `json:"sn"`
	MsgData   msgSubData `json:"msgData"`
	Timestamp int64      `json:"timestamp"`
}
type mqttSubMsgV2 struct {
	Tid       string       `json:"tid"`
	Bid       string       `json:"bid"`
	MsgData   msgSubDataV2 `json:"data"`
	Timestamp int64        `json:"timestamp"`
	Method    string       `json:"method"`
}

type mqttSubStateReplyMsgV2 struct {
	Tid       string                 `json:"tid"`
	Bid       string                 `json:"bid"`
	MsgData   msgSubStateReplyDataV2 `json:"data"`
	Timestamp int64                  `json:"timestamp"`
	Gateway   string                 `json:"gateway"`
}

type mqttSubMsgV3 struct {
	Tid string `json:"tid"`
	// Bid       string       `json:"bid"`
	MsgData   msgSubDataV3 `json:"data"`
	Timestamp int64        `json:"timestamp"`
	URL       string       `json:"url"`
}
type mqttPubMsg struct {
	Tid       string     `json:"tid"`
	Bid       string     `json:"bid"`
	Sn        string     `json:"sn"`
	MsgData   msgpubData `json:"msgData"`
	Timestamp int64      `json:"timestamp"`
}

type mqttPubMsgV2 struct {
	Tid       string       `json:"tid"`
	Bid       string       `json:"bid"`
	MsgData   msgpubDataV2 `json:"data"`
	Timestamp int64        `json:"timestamp"`
}

type mqttPubSvcMsgV2 struct {
	Tid       string          `json:"tid"`
	Bid       string          `json:"bid"`
	MsgData   msgpubSvcDataV2 `json:"data"`
	Timestamp int64           `json:"timestamp"`
}

func decodeMessage(payload []byte) (*mqttSubMsg, error) {
	message := new(mqttSubMsg)
	decoder := json.NewDecoder(strings.NewReader(string(payload)))
	if err := decoder.Decode(&message); err != nil {
		return nil, err
	}
	return message, nil
}

func decodeMessageV2(payload []byte) (*mqttSubMsgV2, error) {
	message := new(mqttSubMsgV2)
	decoder := json.NewDecoder(strings.NewReader(string(payload)))
	if err := decoder.Decode(&message); err != nil {
		return nil, err
	}
	return message, nil
}
func decodeStateReplyMessageV2(payload []byte) (*mqttSubStateReplyMsgV2, error) {
	message := new(mqttSubStateReplyMsgV2)
	decoder := json.NewDecoder(strings.NewReader(string(payload)))
	if err := decoder.Decode(&message); err != nil {
		return nil, err
	}
	return message, nil
}
func decodeMessageV3(payload []byte) (*mqttSubMsgV3, error) {
	message := new(mqttSubMsgV3)
	decoder := json.NewDecoder(strings.NewReader(string(payload)))
	if err := decoder.Decode(&message); err != nil {
		logger.Error("decodeMessageV3 error = ", err)
		return nil, err
	}
	return message, nil
}

func encodeMessage(msg mqttPubMsg) ([]byte, int32) {
	bmsg, err := json.Marshal(msg)
	if err != nil {
		logger.Error("josn marshal error", err)
	}
	return bmsg, mqtt_V1
}

func encodeMessageV2(msg mqttPubMsgV2) []byte {
	bmsg, err := json.Marshal(msg)
	if err != nil {
		logger.Error("josn marshal error", err)
	}
	return bmsg
}

func encodeSvcMessageV2(msg mqttPubSvcMsgV2) []byte {
	bmsg, err := json.Marshal(msg)
	if err != nil {
		logger.Error("josn marshal error", err)
	}
	return bmsg
}

func encodeMessageErrJsonV2(msg mqttPubMsgV2) []byte {
	bmsg, err := json.Marshal(msg)
	if err != nil {
		logger.Error("josn marshal error", err)
	}
	return bmsg
}

func encodeSvcMessageErrJsonV2(msg mqttPubSvcMsgV2) []byte {
	bmsg, err := json.Marshal(msg)
	if err != nil {
		logger.Error("josn marshal error", err)
	}
	return bmsg
}

func MqttSvc(m MqttLoginConfig) {
	// s := mqtt.NewAdaptorWithAuth("tcp://localhost:1883", "client", "fzw", "12345678")
	logger.Debug("mqtt config :", m)
	s := mqtt.NewAdaptorWithAuth(m.URL, m.ClientID, m.Account, m.Passwd)
	gC2sn = m.C2sn
	logger.Debug("mqtt  = ", s)
	go MqttHandler(m.Ctx, s)
}

func ClearMqttConn(m MqttLoginConfig) {
	logger.Debug("clear mqtt conn")
	s := mqtt.NewAdaptorWithAuth(m.URL, m.ClientID, m.Account, m.Passwd)
	s.CreateClientOptions()
	s.Client = paho.NewClient(s.Opts)
	s.Client.Disconnect(500)
	logger.Debug("IsConnected: ", s.Client.IsConnected())
	s.Client = nil
}

func MqttHandler(ctx context.Context, s *mqtt.Adaptor) {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
			MqttHandler(ctx, s)
			time.Sleep(1 * time.Second)
		}
	}()
	logger.Debug("start connect mqtt broker")
	s.SetAutoReconnect(true)
	s.SetCleanSession(true)

	RegisterSubHandlers(s)

	cRet := s.Connect()
	logger.Debug("cRet = ", cRet)
	s.SetQoS(1)

	// go HandlerPub(ctx, s)
	go UploadSfl200PropertyStatus(ctx, s) //向云端上报 sfl200 属性信息
	go UploadAgxUnderSfl200PropertyStatus(ctx, s)
	go UploadDPH110PropertyStatus(ctx, s) //向云端上报 dph110 属性信息
	go UploadTracerPropertyStatus(ctx, s) // 向云端上报 tracer 属性信息
	go UploadSflPropertyStatus(ctx, s)    // 向云端上报 sfl 属性信息
	go tickerCheck(ctx, s)
	go checkEquipListRegister(ctx, s)
	go videostore.TickGetS3Token(s, gC2sn)
	go videostore.PubEventImageToMqtt(s, gC2sn)
	// RegisterSubHandlers(s)
	udp.UDPHandler = udp.NewUDPHandler()
}

func HandlerPub(ctx context.Context, s *mqtt.Adaptor) {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	ticker := time.NewTicker(10 * time.Second)
	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			nowtime := time.Now()
			var pload pingPayload
			pload.TimeStamp = nowtime.Format("2006-01-02 15:04:05")
			pload.Sn = gC2sn
			msg := mqttPubMsg{
				Tid: "0xffff",
				Bid: "0xffff",
				Sn:  s.Name(),
				MsgData: msgpubData{
					Data: data{
						OpsCode: 0xff,
						Payload: pload,
					},
					Result: result{
						ErrorCode: 0,
						ErrorMsg:  "ping message",
					},
				},
				Timestamp: nowtime.UnixMilli(),
			}
			logger.Debug("pub ping message,timestamp:", msg.Timestamp)
			pubMsg, _ := encodeMessage(msg)
			s.Publish(pingTopic, pubMsg)
		}
	}
}

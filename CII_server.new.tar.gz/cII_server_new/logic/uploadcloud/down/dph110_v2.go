package down

import (
	"context"
	"encoding/json"
	"fmt"
	"sync"
	"time"

	uuid "github.com/satori/go.uuid"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"

	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/logic/uploadcloud/mqtt"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
)

var (
	GDph110PropertyStatus   sync.Map
	gDph110stateMessageSync gsfl200StateType
	gDPH110State            mqttDPH110PubMsgData
)

type Dph110SetConfigResponse struct {
	Result int32 `json:"result"` // 0: 成功，1：失败，2：超时
}

type mqttDPH110PubMsg struct {
	Tid       string               `json:"tid"`
	Bid       string               `json:"bid"`
	Timestamp int64                `json:"timestamp"`
	NeedReply int64                `json:"need_reply"`
	Data      mqttDPH110PubMsgData `json:"data"`
}

type mqttDPH110PubMsgData struct {
	Sn           string                         `json:"sn"`
	EType        string                         `json:"etype"`
	Dph110Config *client.RadarGetConfigResponse `json:"dhp100Config"`
}

// 上报DPH110配置参数
func UploadDPH110PropertyStatus(ctx context.Context, s *mqtt.Adaptor) {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("error msg : %v", r)
			logger.Error("error msg :", err)
			UploadDPH110PropertyStatus(ctx, s)
		}
	}()
	time.Sleep(1 * time.Second)
	ticker := time.NewTicker(5 * time.Second)
	var IsNotFirstUpload bool
	defer ticker.Stop()
	for {
		select {
		case <-ticker.C:
			if s != nil {
				getDph110PropertyStatus(s, &IsNotFirstUpload)
			} else {
				logger.Error("error msg :mqtt handler not initialized")
			}
		case <-ctx.Done():
			return
		}
	}
}

func getDph110PropertyStatus(s *mqtt.Adaptor, IsNotFirstUpload *bool) {
	GDph110PropertyStatus.Range(func(key, value any) bool {
		dph110Sn := key.(string)
		dph110Type := value.(string)

		resp := &client.RadarGetConfigResponse{}
		deviceReq := &client.RadarGetConfigRequest{
			Sn: dph110Sn,
		}

		err := handler.NewDeviceCenter().DPH110GetConfig(context.Background(), deviceReq, resp)
		if err != nil {
			logger.Error("getDph110PropertyStatus DPH110GetConfig error: ", err)
			return false
		}

		bid := uuid.NewV4().String()
		tid := uuid.NewV4().String()
		pubMsg := mqttDPH110PubMsg{
			Bid:       bid,
			Tid:       tid,
			Timestamp: time.Now().UnixMilli(),
			NeedReply: 1,
			Data: mqttDPH110PubMsgData{
				Sn:           dph110Sn,
				EType:        dph110Type,
				Dph110Config: resp,
			},
		}
		logger.Debugf("getDph110PropertyStatus pubMsg: %v", pubMsg)
		bMsg, err := json.Marshal(pubMsg)
		if err != nil {
			logger.Error("getDph110PropertyStatus Marshal pubMsg error: ", err)
		}

		// stateSubTopic_V2
		if !*IsNotFirstUpload {
			s.Publish(stateSubTopic_V2(), bMsg)
			gDph110stateMessageSync.Bid = bid
			gDph110stateMessageSync.Tid = tid
			gDph110stateMessageSync.IsWaitReply = true
			gDph110stateMessageSync.TryTime++
			gDPH110State = pubMsg.Data
			logger.Debug("first upload msg of gDh110State is ", pubMsg.Data)
			for gDph110stateMessageSync.TryTime < MaxTryTime {
				time.Sleep(1 * time.Second)
				if !gDph110stateMessageSync.IsWaitReply {
					break
				}
				gDph110stateMessageSync.TryTime++
			}
			*IsNotFirstUpload = true
		} else {
			if !dph110ConfigDeepEqual(gDPH110State.Dph110Config, resp) {
				s.Publish(stateSubTopic_V2(), bMsg)
				gDph110stateMessageSync.Bid = bid
				gDph110stateMessageSync.Tid = tid
				gDph110stateMessageSync.IsWaitReply = true
				gDph110stateMessageSync.TryTime++
				logger.Debug("new msg of gSfl200State is ", pubMsg.Data)
				for gDph110stateMessageSync.TryTime < MaxTryTime {
					time.Sleep(1 * time.Second)
					if !gDph110stateMessageSync.IsWaitReply {
						break
					}
					gDph110stateMessageSync.TryTime++
				}
				gDPH110State = pubMsg.Data
			} else {
				logger.Debug("old msg of gDPH110State is ", gDPH110State)
			}
		}
		return true
	})
}

func dph110ConfigDeepEqual(src, dst *client.RadarGetConfigResponse) bool {
	if src.GetSn() == dst.GetSn() &&
		src.GetVersion() == dst.GetVersion() &&
		src.GetLongitude() == dst.GetLongitude() &&
		src.GetLatitude() == dst.GetLatitude() &&
		src.GetAltitude() == dst.GetAltitude() &&
		src.GetHeading() == dst.GetHeading() &&
		src.GetPitching() == dst.GetPitching() &&
		src.GetRolling() == dst.GetRolling() &&
		src.GetEleScanCenter() == dst.GetEleScanCenter() &&
		src.GetEleScanScope() == dst.GetEleScanScope() &&
		src.GetAziScanCenter() == dst.GetAziScanCenter() &&
		src.GetAziScanScope() == dst.GetAziScanScope() &&
		src.GetRadarScanRadius() == dst.GetRadarScanRadius() &&
		src.GetFilterLevel() == dst.GetFilterLevel() &&
		src.GetElectricity() == dst.GetElectricity() &&
		src.GetStatus() == dst.GetStatus() &&
		src.GetSysStatus() == dst.GetSysStatus() &&
		src.GetFChannel() == dst.GetFChannel() &&
		src.GetTChannel() == dst.GetTChannel() &&
		src.VersionType == dst.VersionType {
		return true
	}
	return false
}

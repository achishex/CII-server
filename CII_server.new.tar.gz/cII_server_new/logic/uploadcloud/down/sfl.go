package down

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"sync"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/logic/uploadcloud/mqtt"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	uuid "github.com/satori/go.uuid"
)

// opsCode define
const (
	opsGetVer       = 1 //预留，暂时未用到
	opsStopHit      = 2
	opsSetHit       = 3
	opsShutdown     = 4
	opsReset        = 5
	opsFindMsg      = 6
	opsExportMsg    = 7
	opsHitUav       = 8
	opsGetDevStatus = 9
	opsSflGetPower  = 10
	opsSetAutoHit   = 11
	opsGetAutoHit   = 12
	opsSflHitMode   = 13
)

var (
	GSflPropertyStatus   sync.Map
	gSflStateMessageSync gsfl200StateType
	gSflState            mqttSflPubMsgData
)

type mqttSflPubMsg struct {
	Tid       string            `json:"tid"`
	Bid       string            `json:"bid"`
	Timestamp int64             `json:"timestamp"`
	NeedReply int64             `json:"need_reply"`
	Data      mqttSflPubMsgData `json:"data"`
}

type mqttSflPubMsgData struct {
	Sn        string            `json:"sn"`
	EType     string            `json:"etype"`
	SflConfig *freqListResponse `json:"configPara"`
}

type freqListResponse struct {
	FreqList []uint32 `json:"freqList,omitempty"` //频点列表
}

func sflPropertyTopicName() string {
	return propertySubTopic(common.Sfl)
}

func sflSvcTopicName() string {
	return svcSubTopic(common.Sfl)
}

func getVersion(req *client.SflGetVersionRequest, rsp *client.SflGetVersionResponse) error {
	dev := handler.FindCacheDevice(req.Sn, common.DEV_SFL)
	logger.Debug("sn = ", req.Sn)
	if dev == nil {
		logger.Debug("sfl offline ")
		return errors.New("设备未在线")
	}

	d := &handler.Sfl{Device: dev}
	version, err := d.SendGetVersionInfo(req.Sn)
	if err != nil {
		return err
	}

	rsp.Sn = req.Sn
	rsp.Version = version
	return nil
}

func errorMsg(errorCode, opsCode int32, tid, bid, sn, errorMsg string) mqttPubMsg {
	msg := mqttPubMsg{
		Tid: tid,
		Bid: bid,
		Sn:  sn,
		MsgData: msgpubData{
			Result: result{
				ErrorCode: errorCode,
				ErrorMsg:  errorMsg,
			},
			Data: data{
				OpsCode: opsCode,
			},
		},
		Timestamp: time.Now().UnixMilli(),
	}
	logger.Debug("msg = ", msg)
	return msg
}

type version struct {
	Sn      string `json:"sn"`
	Version string `json:"version"`
}

func successfulMsg(errorCode, opsCode int32, tid, bid, sn, errorMsg string, payload interface{}) mqttPubMsg {
	return mqttPubMsg{
		Tid: tid,
		Bid: bid,
		Sn:  sn,
		MsgData: msgpubData{
			Result: result{
				ErrorCode: errorCode,
				ErrorMsg:  errorMsg,
			},
			Data: data{
				OpsCode: opsCode,
				Payload: payload,
			},
		},
		Timestamp: time.Now().UnixMilli(),
	}
}

// func sflGetStatus(req *client.SflGetStatusRequest, rsp *client.SflGetStatusResponse) error {
// 	dev := handler.FindCacheDevice(req.Sn, common.DEV_SFL)
// 	logger.Debug("dev = ", dev)
// 	if dev == nil {
// 		return errors.New("设备未在线")
// 	}

// 	d := &handler.Sfl{Device: dev}

// 	result, err := d.SendSflGetStatus()
// 	logger.Debug("result = ", result)
// 	logger.Debug("err = ", err)
// 	if err != nil {
// 		return err
// 	}
// 	rsp.Sn = req.Sn
// 	rsp.HitAngleEnd = result.HitAngleEnd
// 	rsp.HitAngleBegin = result.HitAngleBegin
// 	rsp.HitMode = result.HitMode
// 	rsp.HitPitch1 = result.HitPitch1
// 	rsp.HitPitch2 = result.HitPitch2
// 	rsp.HitTime = result.HitTime

// 	return nil
// }

func doSflLogic(m mqtt.Message) ([]byte, int32) {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	logger.Debug("m = ", m.Payload())
	p, err := decodeMessage(m.Payload())
	//json Marshal or UnMarshal error
	errJSONTypeMsg := errorMsg(jsonFail, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, jsonFailMsg)
	logger.Error("errMsg = ", errJSONTypeMsg)
	if err != nil {
		logger.Error("decodeMessage error = ", err)
		return encodeMessage(errJSONTypeMsg)
	}
	encodeOkmsg := make([]byte, 0)
	logger.Debug("p.MsgData.Data.OpsCode = ", p.MsgData.Data.OpsCode)
	switch p.MsgData.Data.OpsCode {
	case opsStopHit:
		req := &client.SflStopHitRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.SflStopHitResponse{}

		err = handler.NewDeviceCenter().SflStopHitSet(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg, _ := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg, mqtt_V1
		}
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		encodeOkmsg, _ = encodeMessage(smsg)
	case opsSetHit:
		req := &client.SflHitAngleRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.SflHitAngleResponse{}

		err = handler.NewDeviceCenter().SflHitAngleSet(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg, _ := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg, mqtt_V1
		}
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		encodeOkmsg, _ = encodeMessage(smsg)
	case opsShutdown:
		req := &client.SflOnOffRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.SflOnOffResponse{}

		err = handler.NewDeviceCenter().SflOnOffSet(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg, _ := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg, mqtt_V1
		}
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		encodeOkmsg, _ = encodeMessage(smsg)
	case opsReset:
		req := &client.SflResetRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.SflResetResponse{}

		err = handler.NewDeviceCenter().SflReSet(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg, _ := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg, mqtt_V1
		}
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		encodeOkmsg, _ = encodeMessage(smsg)
	case opsFindMsg:
		req := &client.SflDetectInfoRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.SflDetectInfoResponse{}

		err = handler.NewDeviceCenter().SflDetectInfo(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg, _ := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg, mqtt_V1
		}
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		encodeOkmsg, _ = encodeMessage(smsg)
	case opsExportMsg:
		req := &client.SflDetectInfoExportRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.SflDetectInfoExportResponse{}

		err = handler.NewDeviceCenter().SflDetectInfoExport(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg, _ := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg, mqtt_V1
		}
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		encodeOkmsg, _ = encodeMessage(smsg)
	case opsHitUav:
		req := &client.SflSendHitUavRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.SflSendHitUavResponse{}

		err = handler.NewDeviceCenter().SflSendHitUav(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg, _ := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg, mqtt_V1
		}
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		encodeOkmsg, _ = encodeMessage(smsg)
	case opsGetDevStatus:
		req := &client.SflGetStatusRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.SflGetStatusResponse{}

		err = handler.NewDeviceCenter().SflGetStatus(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg, _ := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg, mqtt_V1
		}
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		encodeOkmsg, _ = encodeMessage(smsg)
	case opsSflGetPower:
		req := &client.SflGetPowerRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.SflGetPowerResponse{}

		err = handler.NewDeviceCenter().SflGetPower(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg, _ := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg, mqtt_V1
		}
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		encodeOkmsg, _ = encodeMessage(smsg)
	case opsSetAutoHit:
		req := &client.SflSetHitModeRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.SflSetHitModeResponse{}

		err = handler.NewDeviceCenter().SflSetHitMode(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg, _ := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg, mqtt_V1
		}
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		encodeOkmsg, _ = encodeMessage(smsg)
	case opsGetAutoHit:
		req := &client.SflGetHitModeRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.SflGetHitModeResponse{}

		err = handler.NewDeviceCenter().SflGetHitMode(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg, _ := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg, mqtt_V1
		}
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)

		encodeOkmsg, _ = encodeMessage(smsg)

	case opsSflHitMode:
		req := &client.SflHitModeRequest{}
		var payloadByte []byte
		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
		if err != nil {
			logger.Error("josn marshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}
		err = json.Unmarshal(payloadByte, req)
		if err != nil {
			logger.Error("josn Unmarshal error", err)
			return encodeMessage(errJSONTypeMsg)
		}

		resp := &client.SflHitModeResponse{}

		err = handler.NewDeviceCenter().SflHitModeSet(context.Background(), req, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
			logger.Error("errMsg = ", errMsg)
			encodeMsg, _ := encodeMessage(errMsg)
			logger.Error("encodeMsg = ", encodeMsg)
			return encodeMsg, mqtt_V1
		}
		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
		encodeOkmsg, _ = encodeMessage(smsg)
	default:
		unknownOps := errorMsg(unknowOpsCode, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, unknowOpsCodeMsg)
		return encodeMessage(unknownOps)
	}
	logger.Debug("encodeSmsg = ", encodeOkmsg)
	return encodeOkmsg, mqtt_V1
}

// func doSflLogic(m mqtt.Message) []byte {
// 	defer func() {
// 		if r := recover(); r != nil {
// 			err := fmt.Errorf("panic: %v", r)
// 			logger.Error("panic:", err)
// 		}
// 	}()
// 	logger.Debug("m = ", m.Payload())
// 	p, err := decodeMessage(m.Payload())
// 	if err != nil {
// 		logger.Error("decodeMessage error = ", err)
// 		errMsg := errorMsg(fail, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, jsonFailMsg)
// 		logger.Error("errMsg = ", errMsg)
// 		return encodeMessage(errMsg)
// 	}
// 	logger.Debug("p.MsgData.Data.OpsCode = ", p.MsgData.Data.OpsCode)
// 	switch p.MsgData.Data.OpsCode {
// 	case 1:
// 		req := &client.SflGetVersionRequest{
// 			Sn: p.Sn,
// 		}
// 		resp := &client.SflGetVersionResponse{}

// 		err := getVersion(req, resp)
// 		logger.Debug("resp = ", resp)
// 		if err != nil {
// 			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
// 			logger.Debug("errMsg = ", errMsg)
// 			encodeMsg := encodeMessage(errMsg)
// 			logger.Debug("result = ", errMsg.MsgData.Result)
// 			logger.Debug("encodeMsg = ", encodeMsg)

// 			var msg mqttPubMsg
// 			json.Unmarshal(encodeMsg, &msg)
// 			logger.Debug("msg = ", msg)
// 			logger.Debug("OpsCode = ", msg.MsgData.Data.OpsCode)
// 			logger.Debug("Result = ", msg.MsgData.Result)

// 			return encodeMsg
// 		}
// 		pload := version{
// 			Sn:      p.Sn,
// 			Version: resp.Version,
// 		}
// 		bpload, err := json.Marshal(pload)
// 		if err != nil {
// 			logger.Error("josn marshal error", err)
// 		}
// 		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, bpload)
// 		encodeSmsg := encodeMessage(smsg)
// 		logger.Debug("encodeSmsg = ", encodeSmsg)
// 		return encodeSmsg
// 	case 9:
// 		req := &client.SflGetStatusRequest{}
// 		var payloadByte []byte
// 		payloadByte, err := json.Marshal(p.MsgData.Data.Payload)
// 		if err != nil {
// 			logger.Error("josn marshal error", err)
// 		}
// 		err = json.Unmarshal(payloadByte, req)
// 		if err != nil {
// 			logger.Error("josn Unmarshal error", err)
// 		}

// 		resp := &client.SflGetStatusResponse{}

// 		err = sflGetStatus(req, resp)
// 		logger.Debug("resp = ", resp)
// 		if err != nil {
// 			errMsg := errorMsg(offline, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, err.Error())
// 			logger.Debug("errMsg = ", errMsg)
// 			encodeMsg := encodeMessage(errMsg)
// 			logger.Debug("result = ", errMsg.MsgData.Result)
// 			logger.Debug("encodeMsg = ", encodeMsg)

// 			var msg mqttPubMsg
// 			json.Unmarshal(encodeMsg, &msg)
// 			logger.Debug("msg = ", msg)
// 			logger.Debug("OpsCode = ", msg.MsgData.Data.OpsCode)
// 			logger.Debug("Result = ", msg.MsgData.Result)

// 			return encodeMsg
// 		}
// 		smsg := successfulMsg(success, p.MsgData.Data.OpsCode, p.Tid, p.Bid, p.Sn, successMsg, resp)
// 		encodeSmsg := encodeMessage(smsg)
// 		logger.Debug("encodeSmsg = ", encodeSmsg)
// 		return encodeSmsg

// 	}

// 	return m.Payload()
// }

// 上报sfl配置参数
func UploadSflPropertyStatus(ctx context.Context, s *mqtt.Adaptor) {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("error msg : %v", r)
			logger.Error("error msg :", err)
			UploadSflPropertyStatus(ctx, s)
		}
	}()
	time.Sleep(1 * time.Second)
	ticker := time.NewTicker(5 * time.Second)
	var IsNotFirstUpload bool
	defer ticker.Stop()
	for {
		select {
		case <-ticker.C:
			if s != nil {
				getSflPropertyStatus(s, &IsNotFirstUpload)
			} else {
				logger.Error("error msg :mqtt handler not initialized")
			}
		case <-ctx.Done():
			return
		}
	}
}

func getSflPropertyStatus(s *mqtt.Adaptor, IsNotFirstUpload *bool) {
	GSflPropertyStatus.Range(func(key, value any) bool {
		deviceSn := key.(string)
		deviceType := value.(string)

		resp := &client.SflGetFreqListResponse{}
		deviceReq := &client.SflGetFreqListRequest{
			Sn: deviceSn,
			Op: 1,
		}

		err := handler.NewDeviceCenter().SflGetFreqNodeList(context.Background(), deviceReq, resp)
		if err != nil {
			logger.Error("getSflPropertyStatus SflGetFreqNodeList error: ", err)
			return false
		}

		bid := uuid.NewV4().String()
		tid := uuid.NewV4().String()
		pubMsg := mqttSflPubMsg{
			Bid:       bid,
			Tid:       tid,
			Timestamp: time.Now().UnixMilli(),
			NeedReply: 1,
			Data: mqttSflPubMsgData{
				Sn:        deviceSn,
				EType:     deviceType,
				SflConfig: &freqListResponse{FreqList: resp.FreqList},
			},
		}
		logger.Debugf("getSflPropertyStatus pubMsg: %v", pubMsg)
		bMsg, err := json.Marshal(pubMsg)
		if err != nil {
			logger.Error("getSflPropertyStatus Marshal pubMsg error: ", err)
		}

		// stateSubTopic_V2
		if !*IsNotFirstUpload {
			s.Publish(stateSubTopic_V2(), bMsg)
			gSflStateMessageSync.Bid = bid
			gSflStateMessageSync.Tid = tid
			gSflStateMessageSync.IsWaitReply = true
			gSflStateMessageSync.TryTime++
			gSflState = pubMsg.Data
			logger.Debug("first upload msg of gSflState is ", pubMsg.Data)
			for gSflStateMessageSync.TryTime < MaxTryTime {
				time.Sleep(1 * time.Second)
				if !gSflStateMessageSync.IsWaitReply {
					break
				}
				gSflStateMessageSync.TryTime++
			}
			*IsNotFirstUpload = true
		} else {
			if !sflConfigDeepEqual(gSflState.SflConfig, pubMsg.Data.SflConfig) {
				s.Publish(stateSubTopic_V2(), bMsg)
				gSflStateMessageSync.Bid = bid
				gSflStateMessageSync.Tid = tid
				gSflStateMessageSync.IsWaitReply = true
				gSflStateMessageSync.TryTime++
				logger.Debug("new msg of gSflState is ", pubMsg.Data)
				for gSflStateMessageSync.TryTime < MaxTryTime {
					time.Sleep(1 * time.Second)
					if !gSflStateMessageSync.IsWaitReply {
						break
					}
					gSflStateMessageSync.TryTime++
				}
				gSflState = pubMsg.Data
			} else {
				logger.Debug("old msg of gSflState is ", gSflState)
			}
		}
		return true
	})
}

func sflConfigDeepEqual(src, dst *freqListResponse) bool {
	return equalSlices(src.FreqList, dst.FreqList)
}

func equalSlices[T comparable](a, b []T) bool {
	if len(a) != len(b) {
		return false
	}
	bMap := make(map[T]struct{})
	for _, v := range b {
		bMap[v] = struct{}{}
	}

	for _, v := range a {
		if _, found := bMap[v]; !found {
			return false
		}
	}

	return true
}

package down

import (
	"context"
	"encoding/json"
	"fmt"
	"runtime/debug"
	"sync"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	uuid "github.com/satori/go.uuid"

	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/logic/uploadcloud/mqtt"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
)

type Sfl200SetWorkModeResponse struct {
	Status int32 `json:"result"` //1:成功  2:失败
}
type Sfl200SetAutoHitConfigResponse struct {
	Status int32 `json:"result"` //1:成功  2:失败
}
type Sfl200PtzFollowUavResponse struct {
	Status int32 `json:"result"` //1:成功  2:失败
}
type Sfl200DealUavResponse struct {
	Status int32 `json:"result"` //1:成功  2:失败
}
type Sfl200FreqDirectResponse struct {
	Status int32 `json:"result"` //1:成功  2:失败
}
type Sfl200FreqDirectHitResponse struct {
	Status int32 `json:"result"` //1:成功  2:失败
}
type Sfl200StartStopHitResponse struct {
	Status int32 `json:"result"` //1:成功  2:失败
}
type Sfl200TurnSflResponse struct {
	Status int32 `json:"result"` //1:成功  2:失败
}
type Sfl200StartNsf4000Response struct {
	Status int32 `json:"result"` //1:成功  2:失败
}
type Sfl200SystemWorkSettingResponse struct {
	Status int32 `json:"result"` //1:成功  2:失败
}

type AgxSetCalibrationParaRespone struct {
	Status int32 `json:"result"` //1:成功  2:失败
}
type SFLNoiseFloorSetResponse struct {
	Result int32 `json:"result"` //1:成功  2:失败
}
type TracerNoiseFloorSetResponse struct {
	Result int32 `json:"result"` //1:成功  2:失败
}
type msgpubDataV2 struct {
	ErrorResult *int `json:"errorResult,omitempty"`
	// Result                          int                              `json:"result"` //0-成功，701000--同步失败
	Sfl200SetWorkModeResponse       *Sfl200SetWorkModeResponse       `json:"Sfl200SetWorkModeResponse,omitempty"`
	Sfl200SetAutoHitConfigResponse  *Sfl200SetAutoHitConfigResponse  `json:"Sfl200SetAutoHitConfigResponse,omitempty"`
	Sfl200PtzFollowUavResponse      *Sfl200PtzFollowUavResponse      `json:"Sfl200PtzFollowUavResponse,omitempty"`
	Sfl200DealUavResponse           *Sfl200DealUavResponse           `json:"Sfl200DealUavResponse,omitempty"`
	Sfl200FreqDirectResponse        *Sfl200FreqDirectResponse        `json:"Sfl200FreqDirectResponse,omitempty"`
	Sfl200FreqDirectHitResponse     *Sfl200FreqDirectHitResponse     `json:"Sfl200FreqDirectHitResponse,omitempty"`
	Sfl200StartStopHitResponse      *Sfl200StartStopHitResponse      `json:"Sfl200StartStopHitResponse,omitempty"`
	Sfl200TurnSflResponse           *Sfl200TurnSflResponse           `json:"Sfl200TurnSflResponse,omitempty"`
	Sfl200StartNsf4000Response      *Sfl200StartNsf4000Response      `json:"Sfl200StartNsf4000Response,omitempty"`
	Sfl200SystemWorkSettingResponse *Sfl200SystemWorkSettingResponse `json:"Sfl200SystemWorkSettingResponse,omitempty"`
	AgxSetCalibrationParaRespone    *AgxSetCalibrationParaRespone    `json:"AgxSetCalibrationParaRespone,omitempty"`
	Dph110SetConfigResponse         *Dph110SetConfigResponse         `json:"Dph110SetConfigResponse,omitempty"`
	SFLNoiseFloorSetResponse        *SFLNoiseFloorSetResponse        `json:"SflNoiseSet,omitempty"`
	TracerNoiseFloorSetResponse     *TracerNoiseFloorSetResponse     `json:"TracerNoiseSet,omitempty"`
}

type msgpubSvcDataV2 struct {
	Result int `json:"result"` //0-成功，701000--同步失败
}

// 云平台 0：成功 1：失败： 2：超时
func changeC2FontToCloud(status int32) int32 {
	//1:成功  2:失败
	if status == 1 {
		return 0
	} else if status == 2 {
		return 1
	} else if status == 4 {
		return 2
	} else if status == 10 {
		return 4
	}
	return status
}

func doSfl200Logic_V2(m mqtt.Message) ([]byte, int32) {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
			debug.PrintStack() // 打印详细的堆栈信息
		}
	}()
	var errJson mqttPubMsgV2
	errJson.Bid = "noBid"
	errJson.Tid = "noTid"
	errJson.Timestamp = time.Now().UnixMilli()
	failCode := errorJson
	errJson.MsgData = msgpubDataV2{
		ErrorResult: &failCode,
	}
	p, err := decodeMessageV2(m.Payload())
	if err != nil {
		logger.Errorf("doSfl200Logic_V2 decode mqtt message %+v \n error: %s", m.Payload(), err.Error())
		return encodeMessageErrJsonV2(errJson), mqtt_V2
	}
	logger.Debugf("decodeMessageV2 p = %+v", p)
	encodeOkmsg := make([]byte, 0)
	if p.MsgData.Sfl200SetWorkModeRequest != nil {
		logger.Debug("p.MsgData.Sfl200SetWorkModeRequest = ", p.MsgData.Sfl200SetWorkModeRequest)

		resp := &client.Sfl200SetWorkModeResponse{}

		err = handler.NewDeviceCenter().Sfl200SetWorkMode(context.Background(), p.MsgData.Sfl200SetWorkModeRequest, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			if err.Error() == "wait task finish err" {
				logger.Error("Sfl200SetWorkMode error = ", err)
				resp.Status = ouverTime
			} else {
				logger.Error("Sfl200SetWorkMode error = ", err)
				resp.Status = devOffline
			}
		}
		smsg := mqttPubMsgV2{Tid: p.Tid, Bid: p.Bid, Timestamp: time.Now().UnixMilli(), MsgData: msgpubDataV2{
			Sfl200SetWorkModeResponse: &Sfl200SetWorkModeResponse{Status: changeC2FontToCloud(resp.Status)},
		}}
		encodeOkmsg = encodeMessageV2(smsg)
		logger.Debug("encodeOkmsg = ", encodeOkmsg)
		return encodeOkmsg, mqtt_V2
	} else if p.MsgData.Sfl200SetAutoHitConfigRequest != nil {
		logger.Debug("p.MsgData.Sfl200SetAutoHitConfigRequest = ", p.MsgData.Sfl200SetAutoHitConfigRequest)

		resp := &client.Sfl200SetAutoHitConfigResponse{}

		err = handler.NewDeviceCenter().Sfl200SetAutoHitConfig(context.Background(), p.MsgData.Sfl200SetAutoHitConfigRequest, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			if err.Error() == "wait task finish err" {
				logger.Error("Sfl200SetAutoHitConfig error = ", err)
				resp.Status = ouverTime
			} else {
				logger.Error("Sfl200SetAutoHitConfig error = ", err)
				resp.Status = devOffline
			}
		}
		smsg := mqttPubMsgV2{Tid: p.Tid, Bid: p.Bid, Timestamp: time.Now().UnixMilli(), MsgData: msgpubDataV2{
			Sfl200SetAutoHitConfigResponse: &Sfl200SetAutoHitConfigResponse{Status: changeC2FontToCloud(resp.Status)},
		}}
		encodeOkmsg = encodeMessageV2(smsg)
		logger.Debug("encodeOkmsg = ", encodeOkmsg)
		return encodeOkmsg, mqtt_V2
	} else if p.MsgData.Sfl200PtzFollowUavRequest != nil {
		logger.Debug("p.MsgData.Sfl200PtzFollowUavRequest = ", p.MsgData.Sfl200PtzFollowUavRequest)
		resp := &client.Sfl200PtzFollowUavResponse{}

		err = handler.NewDeviceCenter().Sfl200PtzFollowUav(context.Background(), p.MsgData.Sfl200PtzFollowUavRequest, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			if err.Error() == "wait task finish err" {
				logger.Error("Sfl200PtzFollowUav error = ", err)
				resp.Status = ouverTime
			} else {
				logger.Error("Sfl200PtzFollowUav error = ", err)
				resp.Status = devOffline
			}
		}
		smsg := mqttPubMsgV2{Tid: p.Tid, Bid: p.Bid, Timestamp: time.Now().UnixMilli(), MsgData: msgpubDataV2{
			Sfl200PtzFollowUavResponse: &Sfl200PtzFollowUavResponse{Status: changeC2FontToCloud(resp.Status)},
		}}
		encodeOkmsg = encodeMessageV2(smsg)
		logger.Debug("encodeOkmsg = ", encodeOkmsg)
		return encodeOkmsg, mqtt_V2
	} else if p.MsgData.Sfl200DealUavRequest != nil {
		logger.Debug("p.MsgData.Sfl200DealUavRequest = ", p.MsgData.Sfl200DealUavRequest)

		resp := &client.Sfl200DealUavResponse{}

		err = handler.NewDeviceCenter().Sfl200DealUav(context.Background(), p.MsgData.Sfl200DealUavRequest, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			if err.Error() == "wait task finish err" {
				logger.Error("Sfl200DealUav error = ", err)
				resp.Status = ouverTime
			} else {
				logger.Error("Sfl200DealUav error = ", err)
				resp.Status = devOffline
			}
		}
		smsg := mqttPubMsgV2{Tid: p.Tid, Bid: p.Bid, Timestamp: time.Now().UnixMilli(), MsgData: msgpubDataV2{
			Sfl200DealUavResponse: &Sfl200DealUavResponse{Status: changeC2FontToCloud(resp.Status)},
		}}
		encodeOkmsg = encodeMessageV2(smsg)
		logger.Debug("encodeOkmsg = ", encodeOkmsg)
		return encodeOkmsg, mqtt_V2
	} else if p.MsgData.Sfl200FreqDirectRequest != nil {
		logger.Debug("p.MsgData.Sfl200FreqDirectRequest = ", p.MsgData.Sfl200FreqDirectRequest)

		resp := &client.Sfl200FreqDirectResponse{}

		err = handler.NewDeviceCenter().Sfl200FreqDirect(context.Background(), p.MsgData.Sfl200FreqDirectRequest, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			if err.Error() == "wait task finish err" {
				logger.Error("Sfl200FreqDirect error = ", err)
				resp.Status = ouverTime
			} else {
				logger.Error("Sfl200FreqDirect error = ", err)
				resp.Status = devOffline
			}
		}
		smsg := mqttPubMsgV2{Tid: p.Tid, Bid: p.Bid, Timestamp: time.Now().UnixMilli(), MsgData: msgpubDataV2{
			Sfl200FreqDirectResponse: &Sfl200FreqDirectResponse{Status: changeC2FontToCloud(resp.Status)},
		}}
		encodeOkmsg = encodeMessageV2(smsg)
		logger.Debug("encodeOkmsg = ", encodeOkmsg)
		return encodeOkmsg, mqtt_V2
	} else if p.MsgData.Sfl200FreqDirectHitRequest != nil {
		logger.Debug("p.MsgData.Sfl200FreqDirectHitRequest = ", p.MsgData.Sfl200FreqDirectHitRequest)

		resp := &client.Sfl200FreqDirectHitResponse{}

		err = handler.NewDeviceCenter().Sfl200FreqDirectHit(context.Background(), p.MsgData.Sfl200FreqDirectHitRequest, resp)
		logger.Debug("resp = ", resp)

		if err != nil {
			if err.Error() == "wait task finish err" {
				logger.Error("Sfl200FreqDirectHit error = ", err)
				resp.Status = ouverTime
			} else {
				logger.Error("Sfl200FreqDirectHit error = ", err)
				resp.Status = devOffline
			}
		}

		smsg := mqttPubMsgV2{Tid: p.Tid, Bid: p.Bid, Timestamp: time.Now().UnixMilli(), MsgData: msgpubDataV2{
			Sfl200FreqDirectHitResponse: &Sfl200FreqDirectHitResponse{Status: changeC2FontToCloud(resp.Status)},
		}}
		logger.Debug("smsg = ", smsg)
		encodeOkmsg = encodeMessageV2(smsg)
		logger.Debug("encodeOkmsg = ", encodeOkmsg)
		return encodeOkmsg, mqtt_V2
	} else if p.MsgData.Sfl200StartStopHitRequest != nil {
		logger.Debug("p.MsgData.Sfl200StartStopHitRequest = ", p.MsgData.Sfl200StartStopHitRequest)

		resp := &client.Sfl200StartStopHitResponse{}

		err = handler.NewDeviceCenter().Sfl200StartStopHit(context.Background(), p.MsgData.Sfl200StartStopHitRequest, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			if err.Error() == "wait task finish err" {
				logger.Error("Sfl200StartStopHit error = ", err)
				resp.Status = ouverTime
			} else {
				logger.Error("Sfl200StartStopHit error = ", err)
				resp.Status = devOffline
			}
		}
		smsg := mqttPubMsgV2{Tid: p.Tid, Bid: p.Bid, Timestamp: time.Now().UnixMilli(), MsgData: msgpubDataV2{
			Sfl200StartStopHitResponse: &Sfl200StartStopHitResponse{Status: changeC2FontToCloud(resp.Status)},
		}}
		encodeOkmsg = encodeMessageV2(smsg)
		logger.Debug("encodeOkmsg = ", encodeOkmsg)
		return encodeOkmsg, mqtt_V2
	} else if p.MsgData.Sfl200TurnSflRequest != nil {
		logger.Debug("p.MsgData.Sfl200TurnSflRequest = ", p.MsgData.Sfl200TurnSflRequest)

		resp := &client.Sfl200TurnSflResponse{}

		err = handler.NewDeviceCenter().Sfl200TurnSfl(context.Background(), p.MsgData.Sfl200TurnSflRequest, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			if err.Error() == "wait task finish err" {
				logger.Error("Sfl200TurnSfl error = ", err)
				resp.Status = ouverTime
			} else {
				logger.Error("Sfl200TurnSfl error = ", err)
				resp.Status = devOffline
			}
		}
		smsg := mqttPubMsgV2{Tid: p.Tid, Bid: p.Bid, Timestamp: time.Now().UnixMilli(), MsgData: msgpubDataV2{
			Sfl200TurnSflResponse: &Sfl200TurnSflResponse{Status: changeC2FontToCloud(resp.Status)},
		}}
		encodeOkmsg = encodeMessageV2(smsg)
		logger.Debug("encodeOkmsg = ", encodeOkmsg)
		return encodeOkmsg, mqtt_V2
	} else if p.MsgData.Sfl200StartNsf4000Request != nil {
		logger.Debug("p.MsgData.Sfl200StartNsf4000Request = ", p.MsgData.Sfl200StartNsf4000Request)

		resp := &client.Sfl200StartNsf4000Response{}

		err = handler.NewDeviceCenter().Sfl200StartNsf4000(context.Background(), p.MsgData.Sfl200StartNsf4000Request, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			if err.Error() == "wait task finish err" {
				logger.Error("Sfl200StartNsf4000 error = ", err)
				resp.Status = ouverTime
			} else {
				logger.Error("Sfl200StartNsf4000 error = ", err)
				resp.Status = devOffline
			}
		}
		smsg := mqttPubMsgV2{Tid: p.Tid, Bid: p.Bid, Timestamp: time.Now().UnixMilli(), MsgData: msgpubDataV2{
			Sfl200StartNsf4000Response: &Sfl200StartNsf4000Response{Status: changeC2FontToCloud(resp.Status)},
		}}
		encodeOkmsg = encodeMessageV2(smsg)
		logger.Debug("encodeOkmsg = ", encodeOkmsg)
		return encodeOkmsg, mqtt_V2
	} else if p.MsgData.Sfl200SystemWorkSettingRequest != nil {
		logger.Debug("p.MsgData.Sfl200SystemWorkSettingRequest = ", p.MsgData.Sfl200SystemWorkSettingRequest)

		resp := &client.Sfl200SystemWorkSettingResponse{}

		err = handler.NewDeviceCenter().Sfl200SystemWorkSetting(context.Background(), p.MsgData.Sfl200SystemWorkSettingRequest, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			if err.Error() == "wait task finish err" {
				logger.Error("Sfl200SystemWorkSetting error = ", err)
				resp.Status = ouverTime
			} else {
				logger.Error("Sfl200SystemWorkSetting error = ", err)
				resp.Status = devOffline
			}
		}
		smsg := mqttPubMsgV2{Tid: p.Tid, Bid: p.Bid, Timestamp: time.Now().UnixMilli(), MsgData: msgpubDataV2{
			Sfl200SystemWorkSettingResponse: &Sfl200SystemWorkSettingResponse{Status: changeC2FontToCloud(resp.Status)},
		}}
		encodeOkmsg = encodeMessageV2(smsg)
		logger.Debug("encodeOkmsg = ", encodeOkmsg)
		return encodeOkmsg, mqtt_V2
	} else if p.MsgData.Sfl200AgxCalibrationParaSet != nil { //AgxSetCalibrationParaRequest
		logger.Debug("p.MsgData.AgxSetCalibrationParaRequest = ", p.MsgData.Sfl200AgxCalibrationParaSet)

		resp := &client.AgxSetCalibrationParaRespone{}

		err = handler.NewDeviceCenter().AgxSetCalibrationPara(context.Background(), p.MsgData.Sfl200AgxCalibrationParaSet, resp)
		logger.Debug("resp = ", resp)
		if err != nil {
			if err.Error() == "wait task finish err" {
				logger.Error("Sfl200SystemWorkSetting error = ", err)
				resp.Result = ouverTime
			} else {
				logger.Error("Sfl200SystemWorkSetting error = ", err)
				resp.Result = devOffline
			}
		}
		smsg := mqttPubMsgV2{Tid: p.Tid, Bid: p.Bid, Timestamp: time.Now().UnixMilli(), MsgData: msgpubDataV2{
			AgxSetCalibrationParaRespone: &AgxSetCalibrationParaRespone{Status: changeC2FontToCloud(resp.Result)},
		}}
		encodeOkmsg = encodeMessageV2(smsg)
		logger.Debug("encodeOkmsg = ", encodeOkmsg)
		return encodeOkmsg, mqtt_V2
	} else if p.MsgData.DPH110SetConfigRequest != nil {
		logger.Debug("p.MsgData.DPH110SetConfigRequest = ", p.MsgData.DPH110SetConfigRequest)

		resp := &client.RadarSetConfigResponse{} //pad端 0-成功 其他-失败

		err = handler.NewDeviceCenter().DPH110SetConfig(context.Background(), p.MsgData.DPH110SetConfigRequest, resp)
		logger.Debug("resp = ", resp)
		resp.Status = 1
		if err != nil {
			logger.Error("DPH110SetConfig error = ", err)
			resp.Status = 2
		}
		smsg := mqttPubMsgV2{Tid: p.Tid, Bid: p.Bid, Timestamp: time.Now().UnixMilli(), MsgData: msgpubDataV2{
			Dph110SetConfigResponse: &Dph110SetConfigResponse{Result: changeC2FontToCloud(int32(resp.Status))},
		}}
		encodeOkmsg = encodeMessageV2(smsg)
		logger.Debug("encodeOkmsg = ", string(encodeOkmsg))
		return encodeOkmsg, mqtt_V2
	} else if p.MsgData.SFLNoiseFloorSetRequest != nil { // sfl设置频点
		resp := &client.SFLNoiseFloorSetResponse{}
		if err := handler.NewDeviceCenter().SFLNoiseFloorSet(context.Background(), p.MsgData.SFLNoiseFloorSetRequest, resp); err != nil {
			logger.Errorf("doSfl200Logic_V2 SFLNoiseFloorSet error: %s", err.Error())
		}
		resp.Result = changeC2FontToCloud(resp.Result)
		smsg := mqttPubMsgV2{Tid: p.Tid, Bid: p.Bid, Timestamp: time.Now().UnixMilli(), MsgData: msgpubDataV2{
			SFLNoiseFloorSetResponse: &SFLNoiseFloorSetResponse{Result: resp.Result},
		}}
		encodeOkmsg = encodeMessageV2(smsg)
		return encodeOkmsg, mqtt_V2
	} else if p.MsgData.TracerNoiseFloorSetRequest != nil { // tracer设置频点
		resp := &client.TracerNoiseFloorSetResponse{}
		if err := handler.NewDeviceCenter().TracerNoiseFloorSet(context.Background(), p.MsgData.TracerNoiseFloorSetRequest, resp); err != nil {
			logger.Errorf("doSfl200Logic_V2 TracerNoiseFloorSet error: %s", err.Error())
		}
		resp.Result = changeC2FontToCloud(resp.Result)
		smsg := mqttPubMsgV2{Tid: p.Tid, Bid: p.Bid, Timestamp: time.Now().UnixMilli(), MsgData: msgpubDataV2{
			TracerNoiseFloorSetResponse: &TracerNoiseFloorSetResponse{Result: resp.Result},
		}}
		encodeOkmsg = encodeMessageV2(smsg)
		return encodeOkmsg, mqtt_V2
	}

	failCode = unsportOps
	errJson.MsgData = msgpubDataV2{
		ErrorResult: &failCode,
	}

	errJsonmsg := encodeMessageErrJsonV2(errJson)
	logger.Debug("errJsonmsg = ", errJsonmsg)
	return errJsonmsg, mqtt_V2

}

type mqttSfl200PubMsgData struct {
	Sn              string                                 `json:"sn"`
	Etype           string                                 `json:"etype"`
	AutoHitConfig   *client.Sfl200GetAutoHitConfigResponse `json:"autoHitConfig"`
	SystemWorkParam *client.Sfl200SystemWorkGetResponse    `json:"systemWorkParam"`
	WorkMode        *client.Sfl200GetWorkModeResponse      `json:"workMode"`
	// AgxGetCalibrationPara *client.AgxGetCalibrationParaRespone   `json:"agxGetCalibrationPara"`
}
type mqttAgxUnderSfl200PubMsgData struct {
	Sn                    string                               `json:"sn"`
	Etype                 string                               `json:"etype"`
	AgxGetCalibrationPara *client.AgxGetCalibrationParaRespone `json:"agxCalibrationPara"`
}
type mqttSfl200PubMsg struct {
	Tid       string               `json:"tid"`
	Bid       string               `json:"bid"`
	Timestamp int64                `json:"timestamp"`
	NeedReply int64                `json:"need_reply"`
	Data      mqttSfl200PubMsgData `json:"data"`
}
type mqttAgxUnderSfl200PubMsg struct {
	Tid       string                       `json:"tid"`
	Bid       string                       `json:"bid"`
	Timestamp int64                        `json:"timestamp"`
	NeedReply int64                        `json:"need_reply"`
	Data      mqttAgxUnderSfl200PubMsgData `json:"data"`
}

type Sfl200PropertySnType struct {
	Sfl200Sn string
	AgxSn    string
}

type Sfl200PropertyDeviceType struct {
	Sfl200Type string
	AgxType    string
}

var Gsfl200PropertyStatus sync.Map
var GAgxUndersfl200PropertyStatus sync.Map

func UploadSfl200PropertyStatus(ctx context.Context, s *mqtt.Adaptor) {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("error msg : %v", r)
			logger.Error("error msg :", err)
			UploadSfl200PropertyStatus(ctx, s)
		}
	}()
	time.Sleep(1 * time.Second)
	ticker := time.NewTicker(5 * time.Second)
	var IsNotFirstUpload bool
	defer ticker.Stop()
	for {
		select {
		case <-ticker.C:
			if s != nil {
				getSfl200PropertyStatus(s, &IsNotFirstUpload)
			} else {
				logger.Error("error msg :mqtt handler not initialized")
			}
		case <-ctx.Done():
			return
		}
	}
}
func UploadAgxUnderSfl200PropertyStatus(ctx context.Context, s *mqtt.Adaptor) {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("error msg : %v", r)
			logger.Error("error msg :", err)
			UploadAgxUnderSfl200PropertyStatus(ctx, s)
		}
	}()
	time.Sleep(1 * time.Second)
	ticker := time.NewTicker(5 * time.Second)
	var IsNotFirstUpload bool
	defer ticker.Stop()
	for {
		select {
		case <-ticker.C:
			if s != nil {
				getAgxunderSfl200PropertyStatus(s, &IsNotFirstUpload)
			} else {
				logger.Error("error msg :mqtt handler not initialized")
			}
		case <-ctx.Done():
			return
		}
	}
}

type gsfl200StateType struct {
	Bid         string
	Tid         string
	TryTime     int
	IsWaitReply bool
}

var gSfl200State mqttSfl200PubMsgData
var gsfl200stateMessageSync gsfl200StateType

var gAgxUnderSfl200State mqttAgxUnderSfl200PubMsgData
var gAgxUndersfl200stateMessageSync gsfl200StateType

const MaxTryTime = 3

func getSfl200PropertyStatus(s *mqtt.Adaptor, IsNotFirstUpload *bool) {
	Gsfl200PropertyStatus.Range(func(key, value any) bool {
		sfl200AndAgxSn := key.(Sfl200PropertySnType)
		sfl200AndAgxType := value.(Sfl200PropertyDeviceType)

		sfl200Sn := sfl200AndAgxSn.Sfl200Sn
		etype := sfl200AndAgxType.Sfl200Type
		logger.Debug("getSfl200PropertyStatus etype = ", etype)
		logger.Debug("getSFl sfl200Sn = ", sfl200Sn)

		resp := &client.Sfl200GetAutoHitConfigResponse{}
		deviceReq := &client.Sfl200GetAutoHitConfigRequest{}
		deviceReq.Sn = sfl200Sn

		err := handler.NewDeviceCenter().Sfl200GetAutoHitConfig(context.Background(), deviceReq, resp)
		if err != nil {
			logger.Error("Sfl200GetAutoHitConfig error = ", err)
			return false
		}
		logger.Debug("resp = ", resp)

		resp2 := &client.Sfl200SystemWorkGetResponse{}
		deviceReq2 := &client.Sfl200SystemWorkGetRequest{}
		deviceReq2.Sn = sfl200Sn

		err = handler.NewDeviceCenter().Sfl200SystemWorkGet(context.Background(), deviceReq2, resp2)
		if err != nil {
			logger.Error("Sfl200SystemWorkGet error = ", err)
			return false
		}
		logger.Debug("resp2 = ", resp2)

		resp3 := &client.Sfl200GetWorkModeResponse{}
		deviceReq3 := &client.Sfl200GetWorkModeRequest{}
		deviceReq3.Sn = sfl200Sn

		err = handler.NewDeviceCenter().Sfl200GetWorkMode(context.Background(), deviceReq3, resp3)
		if err != nil {
			logger.Error("Sfl200GetWorkMode error = ", err)
			return false
		}
		logger.Debug("resp3 = ", resp3)

		// resp4 := &client.AgxGetCalibrationParaRespone{}
		// deviceReq4 := &client.AgxGetCalibrationParaRequest{}
		// deviceReq4.Sn = sfl200AndAgxSn.AgxSn //

		// if len(deviceReq4.Sn) != 0 {
		// 	err = handler.NewDeviceCenter().AgxGetCalibrationPara(context.Background(), deviceReq4, resp4)
		// 	if err != nil {
		// 		logger.Error("AgxGetCalibrationPara error = ", err)
		// 		return false
		// 	}
		// 	logger.Debug("resp4 = ", resp4)
		// }

		bid := uuid.NewV4().String()
		tid := uuid.NewV4().String()
		pubMsg := mqttSfl200PubMsg{
			Bid:       bid,
			Tid:       tid,
			Timestamp: time.Now().UnixMilli(),
			NeedReply: 1,
			Data: mqttSfl200PubMsgData{
				Sn:              sfl200Sn,
				Etype:           etype,
				AutoHitConfig:   resp,
				SystemWorkParam: resp2,
				WorkMode:        resp3,
				// AgxGetCalibrationPara: resp4,
			},
		}
		bmsg, err := json.Marshal(pubMsg)
		if err != nil {
			logger.Error("josn marshal error", err)
		}

		logger.Debug("pubMsg = ", pubMsg)
		logger.Debug("bmsg = ", bmsg)
		// stateSubTopic_V2
		if !*IsNotFirstUpload {
			s.Publish(stateSubTopic_V2(), bmsg)
			gsfl200stateMessageSync.Bid = bid
			gsfl200stateMessageSync.Tid = tid
			gsfl200stateMessageSync.IsWaitReply = true
			gsfl200stateMessageSync.TryTime++
			gSfl200State = pubMsg.Data
			logger.Debug("new msg of gSfl200State is ", pubMsg.Data)
			for gsfl200stateMessageSync.TryTime < MaxTryTime {
				time.Sleep(1 * time.Second)
				if !gsfl200stateMessageSync.IsWaitReply {
					break
				}
				gsfl200stateMessageSync.TryTime++
			}
			*IsNotFirstUpload = true
		} else {
			if !autoHitConfigDeepEqual(gSfl200State.AutoHitConfig, resp) ||
				!systemWorkParamDeepEqual(gSfl200State.SystemWorkParam, resp2) ||
				!workModeDeepEqual(gSfl200State.WorkMode, resp3) {
				// !agxGetCAlibrationParaDeepEqual(gSfl200State.AgxGetCalibrationPara, resp4) {
				s.Publish(stateSubTopic_V2(), bmsg)
				gsfl200stateMessageSync.Bid = bid
				gsfl200stateMessageSync.Tid = tid
				gsfl200stateMessageSync.IsWaitReply = true
				gsfl200stateMessageSync.TryTime++
				logger.Debug("new msg of gSfl200State is ", pubMsg.Data)
				for gsfl200stateMessageSync.TryTime < MaxTryTime {
					time.Sleep(1 * time.Second)
					if !gsfl200stateMessageSync.IsWaitReply {
						break
					}
					gsfl200stateMessageSync.TryTime++
				}
				gSfl200State = pubMsg.Data
			} else {
				logger.Debug("old msg of gSfl200State is ", gSfl200State)
			}
		}
		return true
	})
}

func getAgxunderSfl200PropertyStatus(s *mqtt.Adaptor, IsNotFirstUpload *bool) {
	GAgxUndersfl200PropertyStatus.Range(func(key, value any) bool {
		AgxSn := key.(string)
		AgxType := value.(string)

		logger.Debug("AgxSn = ", AgxSn)
		logger.Debug("AgxType = ", AgxType)

		resp4 := &client.AgxGetCalibrationParaRespone{}
		deviceReq4 := &client.AgxGetCalibrationParaRequest{}
		deviceReq4.Sn = AgxSn

		err := handler.NewDeviceCenter().AgxGetCalibrationPara(context.Background(), deviceReq4, resp4)
		if err != nil {
			logger.Error("AgxGetCalibrationPara error = ", err)
			return false
		}
		logger.Debug("resp4 = ", resp4)

		bid := uuid.NewV4().String()
		tid := uuid.NewV4().String()
		pubMsg := mqttAgxUnderSfl200PubMsg{
			Bid:       bid,
			Tid:       tid,
			Timestamp: time.Now().UnixMilli(),
			NeedReply: 1,
			Data: mqttAgxUnderSfl200PubMsgData{
				Sn:                    AgxSn,
				Etype:                 AgxType,
				AgxGetCalibrationPara: resp4,
			},
		}
		bmsg, err := json.Marshal(pubMsg)
		if err != nil {
			logger.Error("josn marshal error", err)
		}

		logger.Debug("pubMsg = ", pubMsg)
		logger.Debug("bmsg = ", bmsg)
		// stateSubTopic_V2
		if !*IsNotFirstUpload {
			s.Publish(stateSubTopic_V2(), bmsg)
			gAgxUndersfl200stateMessageSync.Bid = bid
			gAgxUndersfl200stateMessageSync.Tid = tid
			gAgxUndersfl200stateMessageSync.IsWaitReply = true
			gAgxUndersfl200stateMessageSync.TryTime++
			gAgxUnderSfl200State = pubMsg.Data
			logger.Debug("new msg of gSfl200State is ", pubMsg.Data)
			for gAgxUndersfl200stateMessageSync.TryTime < MaxTryTime {
				time.Sleep(1 * time.Second)
				if !gAgxUndersfl200stateMessageSync.IsWaitReply {
					break
				}
				gAgxUndersfl200stateMessageSync.TryTime++
			}
			*IsNotFirstUpload = true
		} else {
			if !agxGetCAlibrationParaDeepEqual(gAgxUnderSfl200State.AgxGetCalibrationPara, resp4) {
				s.Publish(stateSubTopic_V2(), bmsg)
				gAgxUndersfl200stateMessageSync.Bid = bid
				gAgxUndersfl200stateMessageSync.Tid = tid
				gAgxUndersfl200stateMessageSync.IsWaitReply = true
				gAgxUndersfl200stateMessageSync.TryTime++
				logger.Debug("new msg of gSfl200State is ", pubMsg.Data)
				for gAgxUndersfl200stateMessageSync.TryTime < MaxTryTime {
					time.Sleep(1 * time.Second)
					if !gAgxUndersfl200stateMessageSync.IsWaitReply {
						break
					}
					gAgxUndersfl200stateMessageSync.TryTime++
				}
				gAgxUnderSfl200State = pubMsg.Data
			} else {
				logger.Debug("old msg of gSfl200State is ", gAgxUnderSfl200State)
			}
		}
		return true
	})
}

func autoHitConfigDeepEqual(src, dst *client.Sfl200GetAutoHitConfigResponse) bool {
	if src.SysCDMType == dst.SysCDMType &&
		src.SysCDWType == dst.SysCDWType &&
		src.SysCdWD1 == dst.SysCdWD1 &&
		src.SysCdWD2 == dst.SysCdWD2 &&
		src.SysCdWD3 == dst.SysCdWD3 &&
		src.SysCdWT1 == dst.SysCdWT1 &&
		src.SysCdWT2 == dst.SysCdWT2 &&
		src.SysCdWT3 == dst.SysCdWT3 &&
		src.SysDzWType == dst.SysDzWType &&
		src.SysDzPPdx == dst.SysDzPPdx &&
		src.SysYPEnable == dst.SysYPEnable &&
		src.SysYPCdt1 == dst.SysYPCdt1 &&
		src.SysYPCdt2 == dst.SysYPCdt2 &&
		src.SysYPMtd == dst.SysYPMtd {
		return true
	}
	return false
}

func systemWorkParamDeepEqual(src, dst *client.Sfl200SystemWorkGetResponse) bool {
	if src.SysGBGd == dst.SysGBGd &&
		src.SysGBIMode == dst.SysGBIMode &&
		src.SysGBJd == dst.SysGBJd &&
		src.SysGBWd == dst.SysGBWd &&
		src.SysGBJTime1 == dst.SysGBJTime1 &&
		src.SysGBJTime2 == dst.SysGBJTime2 &&
		src.SysGBJTime3 == dst.SysGBJTime3 &&
		src.SysGBJMode == dst.SysGBJMode &&
		src.SysGBJF0 == dst.SysGBJF0 &&
		src.SysGBJF1 == dst.SysGBJF1 &&
		src.SysGBJF2 == dst.SysGBJF2 &&
		src.SysGBJF3 == dst.SysGBJF3 &&
		src.SysGBJF4 == dst.SysGBJF4 &&
		src.SysGBJF5 == dst.SysGBJF5 &&
		src.SysGBJF6 == dst.SysGBJF6 &&
		src.SysGBJFPV1 == dst.SysGBJFPV1 &&
		src.SysGBJFPV2 == dst.SysGBJFPV2 {
		return true
	}
	return false
}

func workModeDeepEqual(src, dst *client.Sfl200GetWorkModeResponse) bool {
	logger.Debug("src.WorkMode = ", src.WorkMode, "dst.WorkMode = ", dst.WorkMode)
	if src.WorkMode == dst.WorkMode {
		return true
	}
	return false
}

func agxGetCAlibrationParaDeepEqual(src, dst *client.AgxGetCalibrationParaRespone) bool {
	logger.Debugf("src  = %+v: ", src, " dst = %+v : ", dst)
	if src.Altitude == dst.Altitude &&
		src.Heading == dst.Heading &&
		src.Latitude == dst.Latitude &&
		src.Longitude == dst.Longitude {
		return true
	}
	return false
}

func getSfl200PropertyStatusReply(m mqtt.Message) ([]byte, int32) {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
			debug.PrintStack() // 打印详细的堆栈信息
		}
	}()
	logger.Debug("decodeStateReplyMessageV2 m = ", m.Payload())
	p, err := decodeStateReplyMessageV2(m.Payload())
	logger.Debug("decodeStateReplyMessageV2 p = ", p)
	logger.Debug("err p = ", err)
	// gsfl200stateMessageBID = bid
	if gsfl200stateMessageSync.Bid == p.Bid {
		gsfl200stateMessageSync.IsWaitReply = false
		gsfl200stateMessageSync.TryTime = 0
	}

	return nil, mqtt_V2_stateReply
}

func getAgxUnderSfl200PropertyStatusReply(m mqtt.Message) ([]byte, int32) {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
			debug.PrintStack() // 打印详细的堆栈信息
		}
	}()
	logger.Debug("decodeStateReplyMessageV2 m = ", m.Payload())
	p, err := decodeStateReplyMessageV2(m.Payload())
	logger.Debug("decodeStateReplyMessageV2 p = ", p)
	logger.Debug("err p = ", err)
	// gsfl200stateMessageBID = bid
	if gAgxUndersfl200stateMessageSync.Bid == p.Bid {
		gAgxUndersfl200stateMessageSync.IsWaitReply = false
		gAgxUndersfl200stateMessageSync.TryTime = 0
	}

	return nil, mqtt_V2_stateReply
}

package down

import (
	"context"
	"encoding/json"
	"fmt"
	"runtime/debug"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	uuid "github.com/satori/go.uuid"

	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/logic/uploadcloud/mqtt"
)

type ItemData struct {
	SerialNum  string `json:"serialNum"`
	Vendor     string `json:"vendor"`
	Model      string `json:"model"`
	Role       int32  `json:"role"`
	Usage      int32  `json:"usage"`
	UsageDesc  string `json:"usageDesc"`
	Remark     string `json:"remark"`
	CreateTime int64  `json:"createTime"`
	UpdateTime int64  `json:"updateTime"`
	Status     int32  `json:"status"` // 1-存在，2-删除
}

type UavBlackWhiteRule struct {
	Itemlist []*ItemData `json:"itemList"`
	C2Sn     string      `json:"c2Sn"`
}

const (
	winit          int32 = 11
	wfirstSync     int32 = 12
	WhiteWebChange int32 = 13
)

var (
	GwhiteList = winit //11:initialize 12: first init done
)

func doUavWhiteListLogic_V2(m mqtt.Message) ([]byte, int32) {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
			debug.PrintStack() // 打印详细的堆栈信息
		}
	}()
	logger.Debug("decodeMessageV2 m = ", string(m.Payload()))
	p, err := decodeMessageV2(m.Payload())
	var errJson mqttPubSvcMsgV2
	errJson.Bid = "noBid"
	errJson.Tid = "noTid"
	errJson.Timestamp = time.Now().UnixMilli()
	failCode := errorJson
	errJson.MsgData = msgpubSvcDataV2{
		Result: failCode,
	}
	if err != nil {
		logger.Error("decodeMessage error = ", err)
		errJsonMsg := encodeSvcMessageErrJsonV2(errJson)
		logger.Debug("errJsonMsg = ", errJsonMsg)
		return errJsonMsg, mqtt_V2
	}
	// logger.Debug("decodeMessageV2 p = ", p)
	switch p.Method {
	case "blackWhiteRuleSync":
		return blackWhiteRuleSync(p)
	case "fence_sync":
		return FencesSync(p)
	}
	failCode = unsportOps
	errJson.MsgData = msgpubSvcDataV2{
		Result: failCode,
	}
	errJsonmsg := encodeSvcMessageErrJsonV2(errJson)
	logger.Debug("errJsonmsg = ", errJsonmsg)
	return errJsonmsg, mqtt_V2
}

func blackWhiteRuleSync(p *mqttSubMsgV2) ([]byte, int32) {
	logger.Debug("blackWhiteRuleSync")
	for i, v := range p.MsgData.WhiteItems {
		if len(v.SerialNum) == 0 {
			logger.Error("received empty sn, i = ", i)
		} else {
			logger.Debug("sn = ", v.SerialNum, " i= ", i)
		}
	}

	encodeOkmsg := make([]byte, 0)
	if p.MsgData.WhiteItems != nil {
		logger.Debug("p.MsgData.Items = ", p.MsgData.WhiteItems)
		logger.Debug("methord = ", p.Method)
		Itemlist := p.MsgData.WhiteItems

		//白名单数量不多，可以一次性查询所有已存在和已删除的，记录到map1(已存在)， map2(已删除)中，map的key为sn，value为数据库内容加
		whitelists := make([]*bean.DroneWhiteList, 0)
		err := handler.NewWhiteList().FindAll(&whitelists)
		if err != nil {
			logger.Errorf("err = ", err)
		}
		whitelistsLog := make([]*bean.WhiteListLog, 0)
		err = handler.NewWhiteListLog().FindAll(&whitelistsLog)
		if err != nil {
			logger.Errorf("err = ", err)
		}
		map1 := make(map[string]*bean.DroneWhiteList)
		map2 := make(map[string]*bean.WhiteListLog)
		for _, item := range whitelists {
			if item.Sn == "" {
				logger.Errorf("sn is empty,itme = %+v", item)
			} else {
				map1[item.Sn] = item
			}

		}
		for _, item := range whitelistsLog {
			if item.Sn == "" {
				logger.Errorf("sn is empty,itme = %+v", item)
			} else {
				map2[item.Sn] = item
			}
		}
		logger.Debug("map1 = ", map1)
		logger.Debug("map2 = ", map2)

		for _, cloud := range Itemlist {
			logger.Debugf("cloud = %+v", cloud)
			if local, exits := map1[cloud.SerialNum]; exits { //白名单在本地存在
				if cloud.Status == 1 { //白名单在云平台也存在
					if local.UpdatedAt.UnixMilli() > cloud.UpdateTime { //白名单在云平台存在，并且更新时间小于本地时间，则使用本地时间
						logger.Debug("白名单在云平台存在，并且更新时间小于本地时间，则使用本地时间")
						//Nothing need to do
					} else if local.UpdatedAt.UnixMilli() < cloud.UpdateTime {
						local.UpdatedAt = time.UnixMilli(cloud.UpdateTime) //白名单在云平台存在，并且更新时间大于本地时间，则使用云平台时间
						local.Model = cloud.Model
						local.Remarks = cloud.Remark
						local.Role = cloud.Role
						local.Usage = cloud.Usage
						local.UsageDesc = cloud.UsageDesc
						local.Vendor = cloud.Vendor
						map1[local.Sn] = local
						logger.Debug("wfirstSync 白名单在云平台存在，并且更新时间大于本地时间，则使用云平台时间")
						GwhiteList = wfirstSync
					} else {
						logger.Debug("白名单在云平台存在，并且更新时间等于本地时间，则不用做什么")
					}
				} else if cloud.Status == 2 {
					//白名单在云平台不存在，并且本地存在
					if local.UpdatedAt.UnixMilli() > cloud.UpdateTime {
						logger.Debug("白名单在云平台不存在，并且本地存在")
						//Nothing need to do
					} else {
						delete(map1, local.Sn) //map2不需要做同步记录，因为删除的记录，不需要再次同步到云平台，所以不需要记录到map2中。
						logger.Debug("map2不需要做同步记录，因为删除的记录，不需要再次同步到云平台，所以不需要记录到map2中。")
					}
				} else {
					logger.Error("item.Status = ", cloud.Status)
				}
			} else {
				if local, exits := map2[cloud.SerialNum]; exits { //白名单在本地刪除記錄存在
					if cloud.Status == 1 { //白名单在云平台也存在
						if local.UpdatedAt.UnixMilli() > cloud.UpdateTime { //白名单在云平台存在，并且更新时间小于本地时间，则使用本地时间
							logger.Debug("白名单在云平台存在，并且更新时间小于本地时间，则使用本地时间 ")
							//Nothing need to do
						} else {
							delete(map2, local.Sn)
							var store bean.DroneWhiteList
							store.CreatedAt = time.UnixMilli(cloud.CreateTime)
							store.UpdatedAt = time.UnixMilli(cloud.UpdateTime)
							store.ID = int32(len(map2))
							store.Vendor = cloud.Vendor
							store.Model = cloud.Model
							store.Remarks = cloud.Remark
							store.Role = cloud.Role
							store.UsageDesc = cloud.UsageDesc
							store.Usage = cloud.Usage

							map1[store.Sn] = &store
							logger.Debug("wfirstSync 白名单在云平台存在，并且更新时间大于本地时间，则使用云平台时间 ")
							GwhiteList = wfirstSync
						}
					} else {
						//云平台和本地都存在，且都标记为删除，不做处理 (云平台标记为删除，本地没有记录)
						logger.Debug("云平台和本地都存在，且都标记为删除，不做处理cloud.SerialNum = ", cloud.SerialNum)
					}
				} else { //更新的数据在本地白名单和本地删除记录白名单中都不存在
					if cloud.Status == 1 {
						var store bean.DroneWhiteList
						store.CreatedAt = time.UnixMilli(cloud.CreateTime)
						store.UpdatedAt = time.UnixMilli(cloud.UpdateTime)
						// store.ID = int32(len(map2))
						store.Vendor = cloud.Vendor
						store.Model = cloud.Model
						store.Remarks = cloud.Remark
						store.Role = cloud.Role
						store.UsageDesc = cloud.UsageDesc
						store.Usage = cloud.Usage
						store.Sn = cloud.SerialNum
						map1[store.Sn] = &store
						logger.Debugf("wfirstSync 更新的数据在本地白名单和本地删除记录白名单中都不存在, store cloud 1 = %+v", cloud)
						GwhiteList = wfirstSync
					} else if cloud.Status == 2 {
						var store bean.WhiteListLog
						store.CreatedAt = time.UnixMilli(cloud.CreateTime)
						store.UpdatedAt = time.UnixMilli(cloud.UpdateTime)
						// store.ID = int32(len(map2))
						store.Vendor = cloud.Vendor
						store.Model = cloud.Model
						store.Remarks = cloud.Remark
						store.Role = cloud.Role
						store.UsageDesc = cloud.UsageDesc
						store.Usage = cloud.Usage
						store.Sn = cloud.SerialNum
						map2[store.Sn] = &store
						logger.Debugf("wfirstSync 更新的数据在本地白名单和本地删除记录白名单中都不存在 store cloud 2 = %+v", cloud)
						GwhiteList = wfirstSync
					} else {
						logger.Error("云平台更新数据包含错误更新码，error cloud data = ", cloud)
					}

					// logger.Debug("更新的数据在本地白名单和本地删除记录白名单中都不存在")
				}
			}
		}
		logger.Debug("ops end map1 = ", map1)
		logger.Debug("ops end map2 = ", map2)
		//将白名单和白名单记录所有数据删除，将map1和map2数据更新到数据库中。
		{
			err := handler.NewWhiteList().DeleteAll()
			if err != nil {
				logger.Errorf("err = ", err)
			}
			var instore []*bean.DroneWhiteList
			for _, v := range map1 {
				instore = append(instore, v)
				logger.Debugf("v = %+v ", v)
			}
			err = handler.NewWhiteList().CreateAll(instore)
			if err != nil {
				err = handler.NewWhiteList().CreateAll(instore)
				logger.Errorf("err = ", err)
			}
			//map2
			err = handler.NewWhiteListLog().DeleteAll()
			if err != nil {
				logger.Errorf("err = ", err)
			}
			var instore2 []*bean.WhiteListLog
			for _, v := range map2 {
				instore2 = append(instore2, v)
			}
			err = handler.NewWhiteListLog().CreateAll(instore2)
			if err != nil {
				logger.Errorf("err = ", err)
			}
		}

		smsg := mqttPubSvcMsgV2{Tid: p.Tid, Bid: p.Bid, Timestamp: time.Now().UnixMilli(), MsgData: msgpubSvcDataV2{
			Result: 0,
		}}
		encodeOkmsg = encodeSvcMessageV2(smsg)
		logger.Debug("encodeOkmsg = ", encodeOkmsg)
		return encodeOkmsg, mqtt_V2
	}
	return nil, mqtt_V2
}

//定时1秒检查标志位是否有更新，有的话，发送mqtt通知给云平台
//增删改查中，该标志位也需要 嵌入web 调用中，这里才能知道

func tickerCheck(ctx context.Context, s *mqtt.Adaptor) {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("error msg : %v", r)
			logger.Error("error msg :", err)
			tickerCheck(ctx, s)
		}
	}()
	// time.Sleep(1 * time.Second)
	logger.Debug("come to tickerCheck ")
	ticker := time.NewTicker(1 * time.Second)
	defer ticker.Stop()
	for {
		select {
		case <-ticker.C:
			if s != nil {
				if GwhiteList == wfirstSync || GwhiteList == WhiteWebChange {
					logger.Debug("GwhiteList = ", GwhiteList)
					notifyWhite(s)
				}

			} else {
				logger.Error("error msg :mqtt handler not initialized")
			}
		case <-ctx.Done():
			return
		}
	}
}

func notifyWhite(s *mqtt.Adaptor) {

	whitelists := make([]*bean.DroneWhiteList, 0)
	err := handler.NewWhiteList().FindAll(&whitelists)
	if err != nil {
		logger.Errorf("err = ", err)
	}
	logger.Debug("whitelists = ", whitelists)
	whitelistsLog := make([]*bean.WhiteListLog, 0)
	err = handler.NewWhiteListLog().FindAll(&whitelistsLog)
	if err != nil {
		logger.Errorf("err = ", err)
	}
	logger.Debug("whitelistsLog = ", whitelistsLog)
	bid := uuid.NewV4().String()
	tid := uuid.NewV4().String()
	list := make([]*ItemData, 0)
	for _, item := range whitelists {
		list = append(list, &ItemData{
			SerialNum:  item.Sn,
			Vendor:     item.Vendor,
			Model:      item.Model,
			Role:       item.Role,
			Usage:      item.Usage,
			UsageDesc:  item.UsageDesc,
			Remark:     item.Remarks,
			CreateTime: item.CreatedAt.UnixMilli(),
			UpdateTime: item.UpdatedAt.UnixMilli(),
			Status:     1,
		})
	}
	for _, item := range whitelistsLog {
		list = append(list, &ItemData{
			SerialNum:  item.Sn,
			Vendor:     item.Vendor,
			Model:      item.Model,
			Role:       item.Role,
			Usage:      item.Usage,
			UsageDesc:  item.UsageDesc,
			Remark:     item.Remarks,
			CreateTime: item.CreatedAt.UnixMilli(),
			UpdateTime: item.UpdatedAt.UnixMilli(),
			Status:     2,
		})
	}
	logger.Debugf("list = %+v", list)
	// var data UavBlackWhiteRule
	// data.Itemlist = list
	// logger.Debug("data:", data)
	smsg := mqttSubMsgV2{Tid: bid, Bid: tid, Timestamp: time.Now().UnixMilli(), Method: "uavBlackWhiteRule",
		MsgData: msgSubDataV2{
			// WhiteItems: list,
			Items: &UavBlackWhiteRule{
				Itemlist: list,
				C2Sn:     gC2sn,
			},
		}}
	bmsg, err := json.Marshal(smsg)
	if err != nil {
		logger.Error("josn marshal error", err)
	}

	logger.Debug("bmsg = ", bmsg)
	GwhiteList = winit

	s.Publish(stateSubTopic_V2(), bmsg)

}

package down

import (
	"encoding/json"
	"fmt"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	jsoniter "github.com/json-iterator/go"
	"github.com/paulmach/orb/geojson"

	"adasgitlab.autel.com/tools/cuav_plugin/broker"

	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/logic/uploadcloud/mqtt"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
)

type properties struct {
	Type    string    `json:"type"`
	Color   []float64 `json:"color"`
	Outline struct {
		Type  string    `json:"type"`
		Color []float64 `json:"color"`
		Width int       `json:"width"`
		Style string    `json:"style"`
	} `json:"outline"`
	Style string `json:"style"`
}

// 若C2已在线，云端再次修改围栏区，包括新增，编辑，删除等操作，需通知APP
func doFencesLogic(m mqtt.Message) ([]byte, int32) {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	logger.Debugf("doFencesLogic m: %+v", string(m.Payload()))
	p, err := decodeMessageV2(m.Payload())
	logger.Debug("decodeMessageV2 p = ", p)
	var errJson mqttPubSvcMsgV2
	errJson.Bid = "noBid"
	errJson.Tid = "noTid"
	errJson.Timestamp = time.Now().UnixMilli()
	failCode := errorJson
	errJson.MsgData = msgpubSvcDataV2{
		Result: failCode,
	}
	if err != nil {
		logger.Error("decodeMessage error = ", err)
		errJsonMsg := encodeSvcMessageErrJsonV2(errJson)
		logger.Debug("errJsonMsg = ", errJsonMsg)
		return errJsonMsg, mqtt_V2
	}
	encodeMsg := make([]byte, 0)
	fenceIsDelMap := make(map[string]bool)
	layout := "2006-01-02 15:04:05"
	if p.Method == "fence_sync" {
		if len(p.MsgData.FenceList) > 0 {
			if err := db.GetDB().Model(&bean.Fences{}).Where("is_cloud = ?", true).Delete(&bean.Fences{}).Error; err != nil {
				logger.Errorf("fence_sync delete error: %v", err)
			}
			msg := mqttPubSvcMsgV2{
				Tid: p.Tid,
				Bid: p.Bid,
				MsgData: msgpubSvcDataV2{
					Result: success,
				},
				Timestamp: time.Now().UnixMilli(),
			}
			fencesList := make([]*bean.Fences, 0)
			for _, item := range p.MsgData.FenceList {
				if item.DeleteTime != 0 {
					fenceIsDelMap[item.FenceName] = true
				} else {
					fenceIsDelMap[item.FenceName] = false
				}
				//解析面颜色
				var (
					color      string
					deleteTime string
				)

				feature, err := geojson.UnmarshalFeature([]byte(item.Geometry))
				if err != nil {
					logger.Errorf("fence_sync geojson.Unmarshal Feature error: %v", err)
					break
				}
				propertiesByte, err := json.Marshal(feature.Properties)
				if err != nil {
					logger.Errorf("fence_sync json.Marshal Properties error: %v", err)
					break
				}
				var tmp properties
				if err = json.Unmarshal(propertiesByte, &tmp); err != nil {
					logger.Errorf("fence_sync json.Unmarshal Properties error: %v", err)
					break
				}
				if colorByte, err := json.Marshal(tmp.Outline.Color); err != nil {
					logger.Errorf("fence_sync json.Marshal Properties.Outline.Color error: %v", err)
				} else {
					color = string(colorByte)
				}
				if item.DeleteTime != 0 {
					deleteTime = time.Unix(item.DeleteTime/1000, 0).Format(layout)
				}
				fence := &bean.Fences{
					Name:              item.FenceName,
					AreaType:          item.FenceType,
					Perimeter:         item.FencePerimeter,
					Area:              item.FenceSquare,
					IsCloud:           true,
					IsDelete:          fenceIsDelMap[item.FenceName],
					CentroidLongitude: item.CentroidLongitude,
					CentroidLatitude:  item.CentroidLatitude,
					Geometry:          item.Geometry,
					CreateTime:        time.Unix(item.UpdateTime/1000, 0).Format(layout),
					UpdateTime:        time.Unix(item.UpdateTime/1000, 0).Format(layout),
					DeleteTime:        deleteTime,
					Color:             color,
					FenceType:         0, // todo 云端目前只支持多边形
				}
				fencesList = append(fencesList, fence)
			}

			err = db.GetDB().Model(&bean.Fences{}).CreateInBatches(fencesList, len(p.MsgData.FenceList)).Error
			if err != nil {
				logger.Errorf("fence sync err：%v", err)
				msg.MsgData.Result = syncFenceError
			}
			encodeMsg = encodeSvcMessageV2(msg)
			logger.Debugf("fence sync result：%+v", string(encodeMsg))
			if err == nil {
				fenceData, err := jsoniter.Marshal(p.MsgData.FenceList)
				if err != nil {
					logger.Errorf("fence sync Marshal err：%v", err)
				} else {
					report := &client.ClientReport{
						MsgType: common.ClientMsgFencesSyncData,
						Data:    fenceData,
					}
					_ = mq.FencesSyncBroker.Publish(mq.FencesSyncTopic, broker.NewMessage(report))
					logger.Infof("fence sync publish success：%+v", report)
				}
			}
			return encodeMsg, mqtt_V2
		}
	}
	return encodeSvcMessageErrJsonV2(errJson), mqtt_V2
}

func FencesSync(p *mqttSubMsgV2) ([]byte, int32) {
	logger.Debugf("fence sync")
	encodeMsg := make([]byte, 0)
	fenceIsDelMap := make(map[string]bool)
	layout := "2006-01-02 15:04:05"
	if len(p.MsgData.FenceList) > 0 {
		if err := db.GetDB().Model(&bean.Fences{}).Where("is_cloud = ?", true).Delete(&bean.Fences{}).Error; err != nil {
			logger.Errorf("fence_sync delete error: %v", err)
		}
		msg := mqttPubSvcMsgV2{
			Tid: p.Tid,
			Bid: p.Bid,
			MsgData: msgpubSvcDataV2{
				Result: success,
			},
			Timestamp: time.Now().UnixMilli(),
		}
		fencesList := make([]*bean.Fences, 0)
		for _, item := range p.MsgData.FenceList {
			if item.DeleteTime != 0 {
				fenceIsDelMap[item.FenceName] = true
			} else {
				fenceIsDelMap[item.FenceName] = false
			}
			//解析面颜色
			var (
				color      string
				deleteTime string
			)

			feature, err := geojson.UnmarshalFeature([]byte(item.Geometry))
			if err != nil {
				logger.Errorf("fence_sync geojson.Unmarshal Feature error: %v", err)
				break
			}
			propertiesByte, err := json.Marshal(feature.Properties)
			if err != nil {
				logger.Errorf("fence_sync json.Marshal Properties error: %v", err)
				break
			}
			var tmp properties
			if err = json.Unmarshal(propertiesByte, &tmp); err != nil {
				logger.Errorf("fence_sync json.Unmarshal Properties error: %v", err)
				break
			}
			if colorByte, err := json.Marshal(tmp.Outline.Color); err != nil {
				logger.Errorf("fence_sync json.Marshal Properties.Outline.Color error: %v", err)
			} else {
				color = string(colorByte)
			}
			if item.DeleteTime != 0 {
				deleteTime = time.Unix(item.DeleteTime/1000, 0).Format(layout)
			}
			fence := &bean.Fences{
				Name:              item.FenceName,
				AreaType:          item.FenceType,
				Perimeter:         item.FencePerimeter,
				Area:              item.FenceSquare,
				IsCloud:           true,
				IsDelete:          fenceIsDelMap[item.FenceName],
				CentroidLongitude: item.CentroidLongitude,
				CentroidLatitude:  item.CentroidLatitude,
				Geometry:          item.Geometry,
				CreateTime:        time.Unix(item.UpdateTime/1000, 0).Format(layout),
				UpdateTime:        time.Unix(item.UpdateTime/1000, 0).Format(layout),
				DeleteTime:        deleteTime,
				Color:             color,
				FenceType:         0, // todo 云端目前只支持多边形
			}
			fencesList = append(fencesList, fence)
		}

		err := db.GetDB().Model(&bean.Fences{}).CreateInBatches(fencesList, len(p.MsgData.FenceList)).Error
		if err != nil {
			logger.Errorf("fence sync err：%v", err)
			msg.MsgData.Result = syncFenceError
		}
		encodeMsg = encodeSvcMessageV2(msg)
		logger.Debugf("fence sync result：%+v", string(encodeMsg))
		if err == nil {
			fenceData, err := jsoniter.Marshal(p.MsgData.FenceList)
			if err != nil {
				logger.Errorf("fence sync Marshal err：%v", err)
			} else {
				report := &client.ClientReport{
					MsgType: common.ClientMsgFencesSyncData,
					Data:    fenceData,
				}
				_ = mq.FencesSyncBroker.Publish(mq.FencesSyncTopic, broker.NewMessage(report))
				logger.Infof("fence sync publish success：%+v", report)
			}
		}
		return encodeMsg, mqtt_V2
	}
	return nil, mqtt_V2
}

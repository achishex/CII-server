package uploadcloud

import (
	"fmt"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	broker2 "go-micro.dev/v4/broker"

	"google.golang.org/protobuf/proto"

	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/logic/uploadcloud/down"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/proto/cloudPlatform"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
)

func (c *CloudTcpCli) ReportDph110() {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	_, _ = mq.DPH110Broker.Subscribe(mq.DPH110Topic, func(event broker2.Event) error {
		entity := client.ClientReport{}
		err := proto.Unmarshal(event.Message().Body, &entity)
		if err != nil {
			return fmt.Errorf("report dph110 proto Unmarshal error: %v", err)
		}
		MsgType := entity.MsgType
		info := entity.Data
		logger.Debug("MsgType = ", MsgType)
		switch MsgType {
		case common.ClientMsgIDDPH110HeartBeat:
			return c.reportDph110State(info)
		case common.ClientMsgIDDPH110Posture:
			return c.reportDph110Posture(info)
		case common.ClientMsgIDDPH110Target:
			return c.reportDph110Target(info)
		case common.ClientMsgIDDPH110Track:
			return c.reportDph110Trace(info)
		default:
			err := fmt.Errorf("unrecognized msg type: %v", MsgType)
			logger.Error(err)
			return err
		}
	})
}

func (ctrl *CloudTcpCli) reportDph110State(info []byte) error {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	hb := &client.RadarStatusInfo{}
	err := proto.Unmarshal(info, hb)
	if err != nil {
		logger.Error("reportDph110State Unmarshal RadarStatusInfo error: ", err)
		return err
	}
	heartData := make([]*cloudPlatform.Dph110HeartData, 0)
	var isOnline int32
	if hb.Data.GetIsOnline() == 0 {
		isOnline = 1
	} else if hb.Data.GetIsOnline() == 1 {
		isOnline = 2
	}
	heartData = append(heartData, &cloudPlatform.Dph110HeartData{
		Sn:          hb.Data.SerialNum,
		Online:      isOnline, //云端 1-在线 2-离线
		Electricity: hb.Data.Electricity,
		CreateTime:  time.Now().UnixMilli(),
		Status:      hb.Data.Status,
		SysStatus:   hb.Data.SysStatus,
		DphVersion:  hb.Data.DphVersion,
		Ip:          hb.Data.Ip,
	})

	if hb.Data.SerialNum != "" {
		var isExit bool
		_, ok := down.GDph110PropertyStatus.Load(hb.Data.SerialNum)
		if ok {
			isExit = true
		}
		if !isExit {
			down.GDph110PropertyStatus.Store(hb.Data.SerialNum, common.DPH110)
		}
	}

	heartMessage := &cloudPlatform.Dph110HeartList{
		Body: heartData,
	}
	// encodedMessage
	encodedMessage, err := proto.Marshal(heartMessage)
	if err != nil {
		logger.Error("reportDph110State Marshal heartMessage err:", err)
		return err
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       Dph110HeartURL,
			Sn:        ctrl.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   ctrl.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("reportDph110State Marshal message err:", err)
		return err
	}
	//对消息进行封装+head+crc
	encodedMessage = createPacket(encodedMessage)
	// 发送TCP消息
	if ctrl.Conn == nil || ctrl.IsLogin == false {
		return nil
	}
	_, err = ctrl.Conn.Write(encodedMessage)
	if err != nil {
		logger.Error("reportDph110State 发送TCP消息失败:", err)
		ctrl.clearConn()
		return err
	}
	logger.Debugf("reportDph110State has reported, heartData: %v", heartData)
	return nil
}

func (ctrl *CloudTcpCli) reportDph110Posture(info []byte) error {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	hb := &client.RadarPosture{}
	err := proto.Unmarshal(info, hb)
	if err != nil {
		logger.Error("reportDph110Posture Unmarshal RadarPosture error: ", err)
		return err
	}
	postureData := make([]*cloudPlatform.Dph110PostureData, 0)
	postureData = append(postureData, &cloudPlatform.Dph110PostureData{
		Sn:         hb.Header.Sn,
		Heading:    hb.Data.Heading,
		Pitching:   hb.Data.Pitching,
		Rolling:    hb.Data.Rolling,
		Longitude:  hb.Data.Longitude,
		Latitude:   hb.Data.Latitude,
		CreateTime: time.Now().UnixMilli(),
		Altitude:   hb.Data.Altitude,
	})

	postureMessage := &cloudPlatform.Dph110PostureList{
		Body: postureData,
	}
	// encodedMessage
	encodedMessage, err := proto.Marshal(postureMessage)
	if err != nil {
		logger.Error("reportDph110Posture Marshal postureMessage err:", err)
		return err
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       Dph110PostureURL,
			Sn:        ctrl.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   ctrl.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("reportDph110Posture Marshal message err:", err)
		return err
	}
	//对消息进行封装+head+crc
	encodedMessage = createPacket(encodedMessage)
	// 发送TCP消息
	if ctrl.Conn == nil || ctrl.IsLogin == false {
		return nil
	}
	_, err = ctrl.Conn.Write(encodedMessage)
	if err != nil {
		logger.Error("reportDph110Posture 发送TCP消息失败:", err)
		ctrl.clearConn()
		return err
	}
	logger.Debugf("reportDph110Posture has reported, postureData: %v", postureData)
	return nil
}

func (ctrl *CloudTcpCli) reportDph110Target(info []byte) error {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	hb := &client.DPHTTargetInfo{}
	err := proto.Unmarshal(info, hb)
	if err != nil {
		logger.Error("reportDph110Target Unmarshal DPHTTargetInfo error: ", err)
		return err
	}

	//目标数据帧上报
	if err := ctrl.reportDph110Uav(hb); err != nil {
		logger.Error("reportDph110Target reportDph110Uav error: ", err)
		return err
	}
	//波束信息上报
	if err := ctrl.reportDph110BeamConfig(hb); err != nil {
		logger.Error("reportDph110Target reportDph110BeamConfig error: ", err)
		return err
	}
	logger.Debugf("reportDph110Target has reported, hb: %v", hb)
	return nil
}

func (ctrl *CloudTcpCli) reportDph110Uav(hb *client.DPHTTargetInfo) error {
	targetData := make([]*cloudPlatform.DPH110TargetData, 0)
	for _, item := range hb.Data.Items {
		tmp := &cloudPlatform.DPH110TargetData{
			TargetTrackDeleteFlag:       item.TargetTrackDeleteFlag,
			Id:                          item.Id,
			ForCastFrameNum:             item.ForCastFrameNum,
			TargetLossReason:            item.TargetLossReason,
			TargetUpdateTime:            item.TargetUpdateTime,
			TargetMeasuredDoppler:       item.TargetMeasuredDoppler,
			TargetMeasuredDistance:      item.TargetMeasuredDistance,
			Mag:                         item.Mag,
			Snr:                         item.Snr,
			Velocity:                    item.Velocity,
			Range:                       item.Range,
			Azimuth:                     item.Azimuth,
			Elevation:                   item.Elevation,
			Height:                      item.Height,
			AzimuthDeviation:            item.AzimuthDeviation,
			ElevationDeviation:          item.ElevationDeviation,
			PredictedSpeed:              item.PredictedSpeed,
			PredictedDistance:           item.PredictedDistance,
			PredictedAzimuth:            item.PredictedAzimuth,
			PredictedElevation:          item.PredictedElevation,
			PredictedHeight:             item.PredictedHeight,
			FilterSpeed:                 item.FilterSpeed,
			FilteredDistance:            item.FilteredDistance,
			FilteredAzimuth:             item.FilteredAzimuth,
			FilteredElevation:           item.FilteredElevation,
			FilteredHeight:              item.FilteredHeight,
			FilteredAverageSpeed:        item.FilteredAverageSpeed,
			FilteredAverageAcceleration: item.FilteredAverageAcceleration,
			EnvelopePoints:              item.EnvelopePoints,
			TrackPriority:               item.TrackPriority,
			Alive:                       item.Alive,
			Classification:              item.Classification,
			PitchBeamNumber:             item.PitchBeamNumber,
			NormalizedEnergy:            item.NormalizedEnergy,
			X:                           item.X,
			Y:                           item.Y,
			Z:                           item.Z,
			Longitude:                   item.Longitude,
			Latitude:                    item.Latitude,
			CreateTime:                  time.Now().UnixMilli(),
			Sn:                          hb.Header.Sn,
			ServoScanCycleCount:         hb.Data.ServoScanCycleCount,
			DroneName:                   item.DroneName,
		}
		targetData = append(targetData, tmp)
	}

	targetMessage := &cloudPlatform.DPH110TargetList{
		Body: targetData,
	}
	// encodedMessage
	encodedMessage, err := proto.Marshal(targetMessage)
	if err != nil {
		logger.Error("reportDph110Uav Marshal targetMessage err:", err)
		return err
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       Dph110UavURL,
			Sn:        ctrl.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   ctrl.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("reportDph110Uav Marshal message err:", err)
		return err
	}
	//对消息进行封装+head+crc
	encodedMessage = createPacket(encodedMessage)
	// 发送TCP消息
	if ctrl.Conn == nil || ctrl.IsLogin == false {
		return nil
	}
	_, err = ctrl.Conn.Write(encodedMessage)
	if err != nil {
		logger.Error("reportDph110Uav 发送TCP消息失败:", err)
		ctrl.clearConn()
		return err
	}
	logger.Debugf("reportDph110Uav has reported, targetData: %v", targetData)
	return nil
}

func (ctrl *CloudTcpCli) reportDph110BeamConfig(hb *client.DPHTTargetInfo) error {
	servoAngleData := make([]*cloudPlatform.DPH110ServoAngleData, 0)
	servoAngleData = append(servoAngleData, &cloudPlatform.DPH110ServoAngleData{
		CurrentServoAngle:   hb.Data.CurrentServoAngle - 90,
		ServoScanCycleCount: hb.Data.ServoScanCycleCount,
		FrameID:             hb.Data.FrameID,
		TrackObjNum:         hb.Data.TrackObjNum,
		Sn:                  hb.Header.Sn,
		AziScanCenter:       hb.Data.BeamConfig.AziScanCenter,
		AziScanScope:        hb.Data.BeamConfig.AziScanScope,
		EleScanCenter:       hb.Data.BeamConfig.EleScanCenter,
		EleScanScope:        hb.Data.BeamConfig.EleScanScope,
		CreateTime:          time.Now().UnixMilli(),
		ScanRadius:          hb.Data.BeamConfig.RadarScanRadius,
	})

	servoAngleMessage := &cloudPlatform.DPH110ServoAngleList{
		Body: servoAngleData,
	}
	// encodedMessage
	encodedMessage, err := proto.Marshal(servoAngleMessage)
	if err != nil {
		logger.Error("reportDph110BeamConfig Marshal servoAngleMessage err:", err)
		return err
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       Dph110BeamConfigURL,
			Sn:        ctrl.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   ctrl.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("reportDph110BeamConfig Marshal message err:", err)
		return err
	}
	//对消息进行封装+head+crc
	encodedMessage = createPacket(encodedMessage)
	// 发送TCP消息
	if ctrl.Conn == nil || ctrl.IsLogin == false {
		return nil
	}
	_, err = ctrl.Conn.Write(encodedMessage)
	if err != nil {
		logger.Error("reportDph110BeamConfig 发送TCP消息失败:", err)
		ctrl.clearConn()
		return err
	}
	logger.Debugf("reportDph110BeamConfig has reported, servoAngleData: %v", servoAngleData)
	return nil
}

func (ctrl *CloudTcpCli) reportDph110Trace(info []byte) error {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	hb := &client.DPHTTraceInfo{}
	err := proto.Unmarshal(info, hb)
	if err != nil {
		logger.Error("reportDph110Trace Unmarshal DPHTTraceInfo error: ", err)
		return err
	}
	traceData := make([]*cloudPlatform.DPH110TraceData, 0)
	tmp := &cloudPlatform.DPH110TraceData{
		ServoAngle:                  hb.Data.ServoAngle,
		FrameID:                     hb.Data.FrameID,
		TargetTrackDeleteFlag:       hb.Data.TargetTrackDeleteFlag,
		Id:                          hb.Data.Id,
		ForCastFrameNum:             hb.Data.ForCastFrameNum,
		TargetLossReason:            hb.Data.TargetLossReason,
		TargetUpdateTime:            hb.Data.TargetUpdateTime,
		TargetMeasuredDoppler:       hb.Data.TargetMeasuredDoppler,
		TargetMeasuredDistance:      hb.Data.TargetMeasuredDistance,
		Mag:                         hb.Data.Mag,
		Snr:                         hb.Data.Snr,
		Velocity:                    hb.Data.Velocity,
		Range:                       hb.Data.Range,
		Azimuth:                     hb.Data.Azimuth,
		Elevation:                   hb.Data.Elevation,
		Height:                      hb.Data.Height,
		AzimuthDeviation:            hb.Data.AzimuthDeviation,
		ElevationDeviation:          hb.Data.ElevationDeviation,
		PredictedSpeed:              hb.Data.PredictedSpeed,
		PredictedDistance:           hb.Data.PredictedDistance,
		PredictedAzimuth:            hb.Data.PredictedAzimuth,
		PredictedElevation:          hb.Data.PredictedElevation,
		PredictedHeight:             hb.Data.PredictedHeight,
		FilterSpeed:                 hb.Data.FilterSpeed,
		FilteredDistance:            hb.Data.FilteredDistance,
		FilteredAzimuth:             hb.Data.FilteredAzimuth,
		FilteredElevation:           hb.Data.FilteredElevation,
		FilteredHeight:              hb.Data.FilteredHeight,
		FilteredAverageSpeed:        hb.Data.FilteredAverageSpeed,
		FilteredAverageAcceleration: hb.Data.FilteredAverageAcceleration,
		Alive:                       hb.Data.Alive,
		Classification:              hb.Data.Classification,
		PitchBeamNumber:             hb.Data.PitchBeamNumber,
		NormalizedEnergy:            hb.Data.NormalizedEnergy,
		X:                           hb.Data.X,
		Y:                           hb.Data.Y,
		Z:                           hb.Data.Z,
		Longitude:                   hb.Data.Longitude,
		Latitude:                    hb.Data.Latitude,
		CreateTime:                  time.Now().UnixMilli(),
		Sn:                          hb.Header.Sn,
		DroneName:                   hb.Data.DroneName,
	}
	traceData = append(traceData, tmp)

	traceMessage := &cloudPlatform.DPH110TraceList{
		Body: traceData,
	}
	// encodedMessage
	encodedMessage, err := proto.Marshal(traceMessage)
	if err != nil {
		logger.Error("reportDph110Trace Marshal traceMessage err:", err)
		return err
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       Dph110TraceUavURL,
			Sn:        ctrl.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   ctrl.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("reportDph110Trace Marshal message err:", err)
		return err
	}
	//对消息进行封装+head+crc
	encodedMessage = createPacket(encodedMessage)
	// 发送TCP消息
	if ctrl.Conn == nil || ctrl.IsLogin == false {
		return nil
	}
	_, err = ctrl.Conn.Write(encodedMessage)
	if err != nil {
		logger.Error("reportDph110Trace 发送TCP消息失败:", err)
		ctrl.clearConn()
		return err
	}
	logger.Debugf("reportDph110Trace has reported, traceData: %v", traceData)
	return nil
}

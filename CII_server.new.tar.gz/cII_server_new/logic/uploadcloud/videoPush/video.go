package videopush

import (
	"context"
	"fmt"
	"net/url"
	"os"
	"os/exec"
	"strings"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	ffmpeg "github.com/u2takey/ffmpeg-go"
)

var winRunt string = `
@echo off

:start
echo Running ffmpeg...
tools\\ffmpeg -rtsp_transport tcp -i rtsp://admin:Autel123@192.168.2.4:554/channel=0,stream=0 -vcodec copy -acodec aac -bf 0 -f flv -fflags +genpts rtmp://%s:1935/live/%s

echo Ffmpeg exited. Restarting...
timeout /t 1 >nul
goto start
`

var winRunTest string = `
@echo off

:start
echo Running ffmpeg...

tools\\ffmpeg -re -i  tools\\123.mp4  -vcodec copy -acodec aac -bf 0 -f flv rtmp://%s:1935/live/%s

echo Ffmpeg exited. Restarting...
timeout /t 1 >nul
goto start
`

func getDomain(rawURL string) (string, error) {
	parsedURL, err := url.Parse(rawURL)
	if err != nil {
		return "", err
	}
	host := parsedURL.Host
	if strings.Contains(host, ":") {
		host = strings.Split(host, ":")[0]
	}
	return host, nil
}
func isWinRunBatRunning() bool {
	cmd := exec.Command("tasklist", "/FI", "IMAGENAME eq cmd.exe")
	output, err := cmd.Output()
	if err != nil {
		logger.Debug("Error checking win_run.bat process:", err)
		return false
	}
	return strings.Contains(string(output), "cmd.exe")
}

func killWinRunBat() error {
	defer func() {
		if r := recover(); r != nil {
			logger.Debug("panic: killWinRunBat", r)
		}
	}()
	cmd := exec.Command("taskkill", "/f", "/im", "cmd.exe")
	err := cmd.Run()
	if err != nil {
		logger.Debug("taskkill message:", err)
		return err
	}
	logger.Debug("win_run.bat process killed")
	return nil
}
func pushVideo(domain, siteID string) {
	filename := "tools\\win_run.bat"
	cloudDomain, _ := getDomain(domain)

	content := fmt.Sprintf(winRunt, cloudDomain, siteID)
	err := os.WriteFile(filename, []byte(content), 0644)
	if err != nil {
		logger.Debug("Error writing to file:", err)
		return
	}
	logger.Debug("File written successfully:", filename)
	ticker := time.NewTicker(1 * time.Millisecond)
	for range ticker.C {
		cmd := exec.Command(filename)
		err = cmd.Run()
		if err != nil {
			logger.Debug("run push video bat is fail,err = ", err)
			ticker.Reset(10 * time.Second)
		} else {
			break
		}
	}
	logger.Debug("start push video bat")
}

func pushVideoTest(domain, siteID string) {
	defer func() {
		if err := recover(); err != nil {
			logger.Error("pushVideoTest err:", err)
		}
	}()
	filename := "tools\\win_run_test.bat"
	cloudDomain, _ := getDomain(domain)

	content := fmt.Sprintf(winRunTest, cloudDomain, siteID)
	os.Remove(filename)

	err := os.WriteFile(filename, []byte(content), 0644)
	if err != nil {
		logger.Debug("Error writing to file:", err)
		return
	}
	logger.Debug("File written successfully:", filename)
	cmd := exec.Command(filename)
	err = cmd.Run()
	if err != nil {
		logger.Debug("run push video bat is fail,err = ", err)
		return
	}
}
func videoDaemon(domain, siteID string) {
	defer func() {
		if r := recover(); r != nil {
			logger.Debug("videoDaemon err", r)
		}
	}()

	ticker := time.NewTicker(10 * time.Second)
	for range ticker.C {
		logger.Debug("chekCheckVideo time ", time.Now().Format("2006-01-02T15:04:03"))
		checkVideo(domain, siteID)
	}
}

func checkVideo(domain, siteID string) {
	defer func() {
		if r := recover(); r != nil {
			logger.Debug("panic: checkVideo", r)
		}
	}()
	time.Sleep(100 * time.Millisecond)
	pullffmpeg := "tools\\ffmpeg.exe"
	cloudDomain, _ := getDomain(domain)
	baseURL := `rtmp://%s:1935/live/%s`
	VideoURL := fmt.Sprintf(baseURL, cloudDomain, siteID)
	logger.Debugf("pullffmpeg = %v, videoUrl: %v", pullffmpeg, VideoURL)

	tryNums := 3
	for tryNums > 0 {
		err := ffmpeg.Input(VideoURL).Output("tryPing.jpg", ffmpeg.KwArgs{"vframes": 1, "t": 8, "update": 1}).
			SetFfmpegPath(pullffmpeg).OverWriteOutput().WithTimeout(time.Duration(8 * int64(time.Second))).Run()
		if err != nil {
			logger.Debug("pull photo fail, err: ", err)
			tryNums--
		} else {
			break
		}
	}

	if tryNums <= 0 {
		logger.Debug("pull photo fail, kill ffmpeg")
		killFfmpeg()
	}
}

func isFfmpegRunning() bool {
	cmd := exec.Command("tasklist", "/FI", "IMAGENAME eq ffmpeg.exe")
	output, err := cmd.Output()
	if err != nil {
		logger.Debug("Error checking ffmpeg process:", err)
		return false
	}
	return strings.Contains(string(output), "ffmpeg.exe")
}

func killFfmpeg() error {
	defer func() {
		if r := recover(); r != nil {
			logger.Debug("panic: killFfmpeg", r)
		}
	}()
	programName := "ffmpeg.exe"

	cmd := exec.Command("taskkill", "/f", "/im", programName)
	err := cmd.Run()
	if err != nil {
		logger.Debug("taskkill message:", err)
		return err
	}

	logger.Debugf("%s 程序已成功关闭", programName)
	return nil
}

func PTZVideoSvc() {
	defer func() {
		if err := recover(); err != nil {
			logger.Error("PTZVideoSvc err:", err)
		}
	}()
	var siteMsg *bean.C2IdPlus
	for {
		time.Sleep(2 * time.Second)
		var c2id handler.C2UId
		id := int32(1)
		var err error
		siteMsg, err = c2id.QueryAllMsgByID(context.Background(), id)
		if err != nil {
			logger.Error("Error querying,id ", id)
		}
		logger.Debugf("siteMsg = %+v", siteMsg)
		if siteMsg.SiteID != 0 && len(siteMsg.Domain) != 0 {
			logger.Debugf("sitMsg.siteID: %v, siteMsg.Domain: %v", siteMsg.SiteID, siteMsg.Domain)
			break
		}
	}
	// go pushVideo(siteMsg.Domain, strconv.FormatInt(siteMsg.SiteID, 10))
	// // go pushVideoTest(siteMsg.Domain, strconv.FormatInt(siteMsg.SiteID, 10))
	// go videoDaemon(siteMsg.Domain, strconv.FormatInt(siteMsg.SiteID, 10))

	if isFfmpegRunning() {
		logger.Debug("ffmpeg.exe is already running")
		err := killFfmpeg()
		if err != nil {
			logger.Debug("Error killing win_run.bat:", err)
		}
	}

	go pushVideo(siteMsg.Domain, siteMsg.C2Id)
	// go pushVideoTest(siteMsg.Domain, siteMsg.C2Id)
	go videoDaemon(siteMsg.Domain, siteMsg.C2Id)
}

package uploadcloud

import (
	"bytes"
	"context"
	"crypto/tls"
	"crypto/x509"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"io/ioutil"
	"net"
	"net/http"
	"runtime"
	"runtime/debug"
	"strconv"
	"strings"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"google.golang.org/protobuf/proto"

	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/logic/uploadcloud/down"
	videopush "adasgitlab.autel.com/tools/cuav_server/logic/uploadcloud/videoPush"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/proto/cloudPlatform"
	"adasgitlab.autel.com/tools/cuav_server/repo/utils"
)

const (
	C2_SYSTEM_CONFIG_URL    = "/ws/v1/c2/system_config"
	C2_EQUIP_LIST_URL       = "/ws/v1/c2/equip_list"
	GUN_HEART_URL           = "/ws/v1/device/gun/heart"
	GUN_UAV_URL             = "/ws/v1/device/gun/uav"
	RADAR_HEART_URL         = "/ws/v1/device/radar/heart"
	RADAR_POSTURE_URL       = "/ws/v1/device/radar/posture"
	RADAR_UAV_URL           = "/ws/v1/device/radar/uav"
	RADAR_BEAM_URL          = "/ws/v1/device/radar/beam_config"
	TRACER_UAV_URL          = "/ws/v1/device/tracer/uav"
	TRACER_UAV_PLUS_URL     = "/ws/v1/device/tracer/plus/uav"
	TRACER_UAV_TRANSMIT_URL = "/ws/v1/device/tracer/forward/uav"
	TRACER_HEART_URL        = "/ws/v1/device/tracer/heart"
	TRACER_Noise_Freq_URL   = "/ws/v1/device/tracer/noise"
	C2_LOGIN_URL            = "/ws/v1/c2/system/login"
	HEART_URL               = "/ws/v1/c2/heart"
	DATAREPLAYMARK_WRL      = "/ws/v1/c2/data/mark"

	LOGIN_RSP_URL = "/ws/v1/c2/system/login/result"

	//c2绑定云端站点
	C2_LOGIN_CLOUD_URL    = "/rest/v1/access/tb-c2/login"
	C2_BIND_SITE_LIST_URL = "/rest/v1/access/site/bindable/list"
	C2_BIND_SITE_URL      = "/rest/v1/access/site/bind"
	C2_UNBIND_SITE_URL    = "/rest/v1/access/site/unbind"

	//SflHeartURL sfl 上报
	SflHeartURL            = "/ws/v1/device/sfl/heart"
	SflUavURL              = "/ws/v1/device/sfl/uav"
	SflHitURL              = "/ws/v1/device/sfl/hit"
	SflNoiseURL            = "/ws/v1/device/sfl/noise" //底噪采集
	FpvHeartURL            = "/ws/v1/device/fpv/heart"
	FpvUavURL              = "/ws/v1/device/fpv/uav"
	NsfStatusURL           = "/ws/v1/device/nsf4000/heart"
	TracerRFurdStatusURL   = "/ws/v1/device/tracer/rf/heart"
	TracerRFurdUavURL      = "/ws/v1/device/tracer/rf/uav"
	TracerRFurdspuctrumURL = "/ws/v1/device/tracer/rf/posture"
	Sfl200AgxUavUrl        = "/ws/v1/device/sfl200/agx/uav"
	Sfl200PtzUavUrl        = "/ws/v1/device/sfl200/ptz/uav"
	Sfl200DetectUrl        = "/ws/v1/device/sfl200/sfl/uav"
	Sfl200Heart            = "/ws/v1/device/sfl200/heart"

	//AGX消息上报
	AgxHeartURL      = "/ws/v1/device/agx/heart"
	AgxUavURL        = "/ws/v1/device/agx/uav"
	AgxDevListURL    = "/ws/v1/device/agx/dev_list"
	AgxPTZState      = "/ws/v1/device/agx/ptz_state"
	AgxPerceptionUrl = "/ws/v1/device/agx/perception"

	//中程雷达消息上报
	Dph110HeartURL      = "/ws/v1/device/dph110/heart"
	Dph110PostureURL    = "/ws/v1/device/dph110/posture"
	Dph110UavURL        = "/ws/v1/device/dph110/uav"
	Dph110BeamConfigURL = "/ws/v1/device/dph110/beam_config"
	Dph110TraceUavURL   = "/ws/v1/device/dph110/trace/uav"

	AgxTransferSflUavURL   = "/ws/v1/device/agx/sfl/uav"
	AgxTransferSflHeartURL = "/ws/v1/device/agx/sfl/heart"

	// 事件上报
	EventReportURL = "/ws/v1/event/report"
)
const (
	HEAD_SIZE       = 3
	MAX_BUFFER_SIZE = 1024 * 10 // 缓冲区最大大小，这里设置为10KB
)
const (
	ERROR_CODE_SUCCESS         = 0
	ERROR_CODE_ILLEGAL_REQUEST = 10016
	ERROR_CODE_NETTY_REQUEST   = 10023
)
const (
	MSG_TYPE_REQUEST        = 1
	MSG_TYPE_REQ_AND_REPLAY = 2
	MSG_TYPE_REPLAY         = 3
)

// var CloudCli *CloudTcpCli
var CloudCli = NewCloudTcpCli()

var (
	TOKEN_LENGTH             = 3
	success            int32 = 1
	failed             int32 = 2
	notBound                 = 2 //未绑定
	c2SNToCloudAddrMap map[string]string
)

type CloudTcpCli struct {
	Conn             net.Conn //netty连接
	Ctx              context.Context
	Cancel           context.CancelFunc
	Ctrl             CloudTcp
	IsLogin          bool
	CloudAddr        string
	CloudRestfulAddr string
	Token            string
	C2Sn             string
	C2Name           string
	C2PassWord       string
	TbCode           string
	LoginId          string
	MsgId            string
	MqttConfig       down.MqttLoginConfig
}

type CloudTcp interface {
	Handle(ctx context.Context, conn net.Conn)
}

type C2AccountLogin struct {
	Token      string
	ExpireTime float64
	Host       string
	Port       int
}
type C2LoginRequest struct {
	TbCode   string `json:"tbCode"`
	Account  string `json:"account"`
	Password string `json:"password"`
	C2Sn     string `json:"c2Sn"`
}

type C2LoginResponse struct {
	ErrorCode    int    `json:"errorCode"`
	ErrorMessage string `json:"errorMessage"`
	Data         struct {
		Token  string `json:"token"`
		Host   string `json:"host"`
		TbCode string `json:"tbCode"`
	} `json:"data"`
}
type C2GetNettyCon struct {
	C2Sn string `json:"c2Sn"`
}
type C2GetNettyConRsp struct {
	ErrorCode    int    `json:"errorCode"`
	ErrorMessage string `json:"errorMessage"`
	Data         struct {
		Host     string `json:"host"`
		MqttHost string `json:"mqttHost"`
	} `json:"data"`
}

type TokenPayload struct {
	Sid string `json:"sid"`
	Tid string `json:"tid"`
}

// C2绑定云平台
type C2LoginCloudRequest struct {
	TbCode   string `json:"tbCode"`   //企业编号
	Account  string `json:"account"`  //账号
	Password string `json:"password"` //密码,md5加密
}

type GetBindSiteListRequest struct {
	C2SN string `json:"c2Sn"` //C2编号
	Name string `json:"name"` //站点名称
}

type GetBindSiteListResponse struct {
	ErrorCode    int               `json:"errorCode"`
	ErrorMessage string            `json:"errorMessage"`
	Data         []GetBindSiteData `json:"data"`
}

type GetBindSiteData struct {
	Id   int64  `json:"id"`   //站点ID
	Name string `json:"name"` //站点名称
	Type int32  `json:"type"` //类型 1-当前C2绑定，0-未绑定
}

type C2SiteBindRequest struct {
	C2SN   string `json:"c2Sn"`   //C2编号
	SiteId int64  `json:"siteId"` //站点ID
}

type C2SiteBindResponse struct {
	ErrorCode    int    `json:"errorCode"`
	ErrorMessage string `json:"errorMessage"`
	Data         bool   `json:"data"`
}

type C2SiteUnBindRequest struct {
	C2SN string `json:"c2Sn"` //C2编号
}

func NewCloudTcpCli() *CloudTcpCli {
	tc := &CloudTcpCli{}
	tc.Ctx, tc.Cancel = context.WithCancel(context.Background())

	return tc
}

// ConnectCloudPlatform 连接、注册到云平台
func ConnectCloudPlatform() {
	if CloudCli == nil {
		CloudCli = NewCloudTcpCli()
	}
	// CloudCli = NewCloudTcpCli()
	go CloudCli.StartConnect()
	osName := runtime.GOOS
	if osName == "windows" {
		logger.Debug("push PTZ video, system := ", osName)
		go videopush.PTZVideoSvc()
	}

}

func (ctrl *CloudTcpCli) StartConnect() {
	defer func() {
		if r := recover(); r != nil {
			logger.Error("StartConnect panic error :", r, string(debug.Stack()))
			logger.Debug("ctrl = ", ctrl)
			time.Sleep(100 * time.Millisecond)
			ctrl.StartConnect()
			return
		}
	}()

	machineGuid := ""
	machineGuid = handler.GetDevGuid()
	if machineGuid != "" {
		ctrl.C2Sn = machineGuid
	} else {
		panic("No UUID found in database,try to retrieve")
	}
	logger.Info("machine Guid is :", machineGuid)

	// tick := time.NewTicker(5 * time.Second)
	tick := time.NewTicker(1 * time.Second)
	//定时发心跳
	go ctrl.CheckOnline()
	//上报数据
	go ctrl.ReportMsg()

	defer tick.Stop()
	for {
		select {
		case <-tick.C:
			queryByC2SNRsp := &client.QueryByC2SNRsp{}
			if err := handler.NewC2Id().QueryByC2SN(context.Background(), &client.QueryByC2SNReq{C2Id: ctrl.C2Sn}, queryByC2SNRsp); err != nil {
				logger.Errorf("QueryByC2SN sn: %s error: %v", ctrl.C2Sn, err)
				break
			}
			if queryByC2SNRsp.Token == "" {
				logger.Errorf("QueryByC2SN token is null")
				break
			}
			code := ctrl.C2GetNettyCon(queryByC2SNRsp.Token, queryByC2SNRsp.Domain)
			logger.Info("Cloud Addr :", ctrl.CloudAddr)
			logger.Info("MqttAddr Addr :", ctrl.MqttConfig.URL)
			// 解决C2重启，且云端没网络的情况
			_, ok := c2SNToCloudAddrMap[ctrl.C2Sn]
			if !ok && code == ERROR_CODE_NETTY_REQUEST {
				logger.Error("Cloud addr is nil")
				// 获取netty连接失败，删除绑定关系
				ctrl.Token = ""
				if err := handler.NewC2Id().UpdateByC2Id(context.Background(), ctrl.C2Sn, map[string]interface{}{
					"domain":    "",
					"site_name": "",
					"sid":       "",
					"tid":       "",
					"token":     "",
					"site_id":   0,
					"bind_time": "",
				}); err != nil {
					logger.Errorf("UpdateByC2Id error: %v", err)
					break
				}
				break
			}

			timeout := 60 * time.Second
			conn, err := DialWithTimeout(c2SNToCloudAddrMap[ctrl.C2Sn], timeout)
			if err != nil {
				logger.Error("Error connecting to CloudPlatform:", err)
				ctrl.clearConn()
				break
			}

			ctrl.Conn = conn
			logger.Info("Dial TCP connect netty")
			secret := common.Sha256Encrypt([]byte(ctrl.C2Sn), []byte(queryByC2SNRsp.Sid))
			password := common.ComputeMD5(common.Sha256Encrypt([]byte(queryByC2SNRsp.Tid), []byte(secret)))

			ctrl.MqttConfig.Passwd = password
			ctrl.MqttConfig.Account = ctrl.C2Sn
			if err := ctrl.LoginCloudPlatform(ctrl.C2Sn, password); err != nil {
				logger.Errorf("LoginCloudPlatform error: %v", err)
				break
			}
			var cancel context.CancelFunc
			ctrl.MqttConfig.Ctx, cancel = context.WithCancel(context.Background())
			ctrl.Cancel = cancel
			//MQTT指令下发服务
			go down.MqttSvc(ctrl.MqttConfig)
			//登录云平台
			ctrl.Handle(ctrl.Ctx, ctrl.Conn) //接收云平台数据
			ctrl.StopAllGoroutines()
		}
	}

}

func (ctrl *CloudTcpCli) StopAllGoroutines() {
	if ctrl.Cancel != nil {
		ctrl.Cancel()
	}
}

// DialWithTLS 证书处理 连接netty，废弃
func DialWithTLS(hostname string, certFile []byte, keyFile []byte, caFile []byte, timeout time.Duration) (net.Conn, error) {
	// 加载客户端证书和私钥
	cert, err := tls.X509KeyPair(certFile, keyFile)
	if err != nil {
		return nil, fmt.Errorf("failed to load client certificate and key: %w", err)
	}

	// 加载根证书（用于验证服务器证书）
	//caCert, err := os.ReadFile(caFile)
	//if err != nil {
	//	return nil, fmt.Errorf("failed to load CA certificate: %w", err)
	//}
	caPool := x509.NewCertPool()
	caPool.AppendCertsFromPEM(caFile)

	// 创建自定义的TLS配置
	config := &tls.Config{
		Certificates: []tls.Certificate{cert},
		RootCAs:      caPool,
	}

	// 创建带有超时的Dialer
	dialer := net.Dialer{
		Timeout: timeout,
	}

	// 建立TCP连接
	conn, err := tls.DialWithDialer(&dialer, "tcp", hostname, config)
	if err != nil {
		return nil, fmt.Errorf("failed to connect to %s: %w", hostname, err)
	}

	return conn, nil
}

func DialWithTimeout(hostname string, timeout time.Duration) (net.Conn, error) {
	conn, err := net.DialTimeout("tcp", hostname, timeout)
	if err != nil {
		// 检查是否是超时错误
		if netErr, ok := err.(net.Error); ok && netErr.Timeout() {
			logger.Errorf("Connection timed out: %v", err)
			return nil, fmt.Errorf("connection timed out: %v", err)
		}
		logger.Errorf("Dial failed: %v", err)
		return nil, fmt.Errorf("dial failed: %v", err)
	}
	return conn, nil
}

// CheckOnline 发消息给云平台-----------------------------------------------
func (ctrl *CloudTcpCli) CheckOnline() {
	tick := time.NewTicker(10 * time.Second)
	defer tick.Stop()
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
			go ctrl.CheckOnline()
		}
	}()
	for {
		select {
		case <-tick.C:

			message := &cloudPlatform.Message{
				BaseInfo: &cloudPlatform.BaseInfo{
					MsgId:     1,
					Url:       HEART_URL,
					Sn:        ctrl.C2Sn, //ctrl.C2Sn
					MsgType:   MSG_TYPE_REQUEST,
					ErrorCode: 0,
				},
			}

			// 对Message进行Protobuf编码
			encodedMessage, err := proto.Marshal(message)
			if err != nil {
				logger.Error("Protobuf编码失败:", err)
				continue
			}
			encodedMessage = createPacket(encodedMessage)
			if ctrl.Conn == nil || ctrl.IsLogin == false {
				continue
			}
			_, err = ctrl.Conn.Write(encodedMessage)
			if err != nil {
				logger.Error("Error connecting to CloudPlatform:", err)
				continue
			}
			logger.Info("Send Online Msg To Cloud mes:", message)

		}
	}
}

func (ctrl *CloudTcpCli) LoginCloudPlatform(username, password string) error {
	//tick := time.NewTicker(5 * time.Second)
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	logger.Info("Send Login To Cloud")

	loginMessage := &cloudPlatform.C2SystemLoginRequest{
		User: username,
		Pwd:  password,
	}

	// 对LoginMessage进行Protobuf编码
	encodedLoginMessage, err := proto.Marshal(loginMessage)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return err
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       C2_LOGIN_URL,
			Sn:        ctrl.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
		},
		Data: encodedLoginMessage,
	}

	// 对Message进行Protobuf编码
	encodedMessage, err := proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return err
	}
	// 发送TCP消息
	encodedMessage = createPacket(encodedMessage)
	if ctrl.Conn == nil {
		logger.Error("ctrl Conn is nil")
		return err
	}
	_, err = ctrl.Conn.Write(encodedMessage)
	if err != nil {
		logger.Error("发送TCP消息失败 Login:", err)
		ctrl.clearConn()
		return err
	}
	logger.Info("send Login success")
	return nil
}

// C2AccountLogin C2账户 登录
func (ctrl *CloudTcpCli) C2AccountLogin() {
	// tick := time.NewTicker(5 * time.Second)
	// tick := time.NewTicker(200 * time.Millisecond)
	nowTickTime, maxTickTime := 100, 5000 //milliseconds

	tick := time.NewTicker(time.Duration(nowTickTime) * time.Millisecond)

	defer tick.Stop()

	for {
		select {
		case <-tick.C:
			nowTickTime = nowTickTime * 2
			if nowTickTime > maxTickTime {
				nowTickTime = maxTickTime
			}
			tick.Reset(time.Duration(nowTickTime) * time.Millisecond)
			if ctrl.Token == "" && ctrl.IsLogin == false {
				user := &client.GetAllUserRes{}
				err := handler.NewUser().GetAllUser(context.Background(), &client.GetAllUserReq{}, user)
				if user == nil {
					continue
				}
				for _, userInfo := range user.User {
					if userInfo.Updater == "1" {
						ctrl.C2Name = userInfo.Name
						ctrl.C2PassWord = userInfo.Password
						ctrl.MqttConfig.Passwd = userInfo.Password

					}
				}
				logger.Info("Login cloud http is :", ctrl.C2Name, ctrl.C2PassWord)

				if ctrl.C2Name == "" {
					continue
				}
				url := "http://" + ctrl.CloudRestfulAddr + "/rest/v1/access/c2/tob-user/login"
				requestBody, err := json.Marshal(C2LoginRequest{
					Account: ctrl.C2Name,
					// 计算密码的 MD5 值
					Password: ctrl.C2PassWord,
					C2Sn:     ctrl.C2Sn, // ctrl.C2Sn
				})
				if err != nil {
					logger.Error("JSON marshaling failed:", err)
					continue
				}
				client := &http.Client{}
				req, err := http.NewRequest("POST", url, bytes.NewBuffer(requestBody))
				if err != nil {
					logger.Error("HTTP POST request failed:", err)
					return
				}
				req.Header.Set("Content-Type", "application/json")
				req.Header.Set("Language", "en-US")

				resp, err := client.Do(req)
				if err != nil {
					logger.Error("HTTP POST request failed:", err)
					nowTickTime = nowTickTime * 2
					if nowTickTime > maxTickTime {
						nowTickTime = maxTickTime
					}
					tick.Reset(time.Duration(nowTickTime) * time.Millisecond)
					continue
					// return
				}
				defer resp.Body.Close()

				responseBody, err := ioutil.ReadAll(resp.Body)
				if err != nil {
					logger.Error("Failed to read response body:", err)
					continue
				}

				var loginResponse C2LoginResponse
				err = json.Unmarshal(responseBody, &loginResponse)
				if err != nil {
					logger.Error("JSON unmarshaling failed:", err)
					continue
				}

				logger.Info("login Response", loginResponse)
				//ctrl.CloudAddr = loginResponse.Data.Host
				ctrl.Token = loginResponse.Data.Token
				ctrl.TbCode = loginResponse.Data.TbCode

				ctrl.MqttConfig.Passwd = ctrl.C2PassWord
				ctrl.MqttConfig.Account = ctrl.C2Name
				logger.Debug("ctrl.MqttConfig.Passwd  = ", ctrl.MqttConfig.Passwd)

			}
		}

	}
}

// C2GetNettyCon C2 获取netty链接
func (ctrl *CloudTcpCli) C2GetNettyCon(token, domain string) int {
	url := domain + "/rest/v1/access/c2/tob-user/netty"
	logger.Debug("c2 get url :", url)
	requestBody, err := json.Marshal(C2GetNettyCon{
		C2Sn: ctrl.C2Sn, //ctrl.C2Sn
	})
	if err != nil {
		logger.Errorf("JSON marshaling sn: %s err:", ctrl.C2Sn, err)
		return 0
	}
	authHeaderValue := "Bearer " + token

	client := &http.Client{}
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(requestBody))
	if err != nil {
		logger.Errorf("HTTP POST request %s err: %v", string(requestBody), err)
		return 0
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Authorization", authHeaderValue)

	resp, err := client.Do(req)
	if err != nil {
		logger.Errorf("HTTP Do request %s failed %v", ctrl.C2Sn, err)
		return 0
	}

	defer resp.Body.Close()
	responseBody, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		logger.Error("Failed to read response body:", err)
		return 0
	}

	var loginResponse C2GetNettyConRsp
	err = json.Unmarshal(responseBody, &loginResponse)
	if err != nil {
		logger.Error("JSON unmarshaling failed:", err)
		return 0
	}
	logger.Info("loginResponse = ", loginResponse)
	if c2SNToCloudAddrMap == nil {
		c2SNToCloudAddrMap = make(map[string]string)
	}
	// 云端返回10023,netty连接建立失败，其他情况认为成功
	if loginResponse.ErrorCode == ERROR_CODE_NETTY_REQUEST {
		delete(c2SNToCloudAddrMap, ctrl.C2Sn)
		return loginResponse.ErrorCode
	}
	ctrl.CloudAddr = loginResponse.Data.Host
	ctrl.MqttConfig.URL = loginResponse.Data.MqttHost
	ctrl.MqttConfig.ClientID = "C2@" + ctrl.C2Sn + "@c2app"
	ctrl.MqttConfig.C2sn = ctrl.C2Sn
	c2SNToCloudAddrMap[ctrl.C2Sn] = loginResponse.Data.Host
	logger.Info("C2GetNettyCon Cloud Addr :", ctrl.CloudAddr)
	return loginResponse.ErrorCode
}

// Handle 接收云平台消息----------------------------------
func (ctrl *CloudTcpCli) Handle(ctx context.Context, conn net.Conn) {
	buf := make([]byte, MAX_BUFFER_SIZE)
	for {
		ctrl.cacheConn(conn)
		length, err := ctrl.Conn.Read(buf)
		logger.Debug("err = ", err)
		if err != nil {
			// 通常遇到的错误是连接中断或被关闭，用io.EOF表示
			if err == io.EOF {
				logger.Info(" conn receive close:", err)
			} else {
				logger.Info(" conn receive err:", err)
			}
			ctrl.clearConn()
			//
			return
		}
		logger.Debug("length = ", length)
		if length <= 0 {
			continue
		}
		response := buf[:length]
		logger.Debug("response message is :", response)
		go ctrl.DealReceiveMessage(response)

	}

}

// DealReceiveMessage 处理云平台传来的数据
func (ctrl *CloudTcpCli) DealReceiveMessage(message []byte) {
	response := message[HEAD_SIZE:]
	logger.Debug("receive message is :", response)
	rspMes := &cloudPlatform.Message{}
	err := proto.Unmarshal(response, rspMes)
	if err != nil {
		logger.Error("Proto Unmarshal Fail:", err)
		return
	}

	logger.Info("Receive msg is :", rspMes.BaseInfo, rspMes.BaseInfo.ErrorCode)
	if rspMes.BaseInfo.ErrorCode == ERROR_CODE_ILLEGAL_REQUEST {
		ctrl.clearConn()
		logger.Info("error code is :", rspMes.BaseInfo.ErrorCode)
	}
	switch rspMes.BaseInfo.Url {
	case LOGIN_RSP_URL:
		ctrl.ReceiveLoginRsp(rspMes)
	case HEART_URL:
		logger.Info("receive cloud platform heart")
	default:
		logger.Error("Unknown Mes Url")
	}

}

func (ctrl *CloudTcpCli) ReceiveLoginRsp(mes *cloudPlatform.Message) {
	logger.Infof("receive login rsp type:%v,code:%v", mes.BaseInfo.MsgType, mes.BaseInfo.ErrorCode)
	//if mes.BaseInfo.MsgType == MSG_TYPE_REPLAY && mes.BaseInfo.ErrorCode == ERROR_CODE_SUCCESS {
	//	ctrl.IsLogin = true
	//}
	if mes.BaseInfo.ErrorCode != ERROR_CODE_SUCCESS {
		ctrl.clearConn()
	}
	loginRsp := &cloudPlatform.LoginResultMessage{}
	err := proto.Unmarshal(mes.Data, loginRsp)
	if err != nil {
		logger.Error("Proto Unmarshal Fail:", err)
		return
	}
	logger.Info("Login Result rsp id:", loginRsp.Id)
	ctrl.IsLogin = true
	ctrl.LoginId = loginRsp.Id
}

func (ctrl *CloudTcpCli) cacheConn(conn net.Conn) {
	ctrl.Conn = conn
}
func (ctrl *CloudTcpCli) clearConn() {
	ctrl.IsLogin = false
	if ctrl.Conn != nil {
		ctrl.Conn.Close() // need close the connect then reset object
	}
	ctrl.Conn = nil
}

// LoginCloud C2登录时  云平台操作
func (ctrl *CloudTcpCli) LoginCloud(name, password string) error {
	if ctrl == nil {
		return nil
	}
	// if ctrl != nil {
	// 	ctrl.clearConn()
	// }
	password = common.ComputeMD5(password)
	ctrl.Token = ""
	logger.Info("LoginCloud req:", name+password)
	queryByC2SNRsp := &client.QueryByC2SNRsp{}
	if err := handler.NewC2Id().QueryByC2SN(context.Background(), &client.QueryByC2SNReq{C2Id: ctrl.C2Sn}, queryByC2SNRsp); err != nil {
		logger.Errorf("LoginCloud QueryByC2SN err: %v", err)
		return err
	}
	if queryByC2SNRsp.Domain == "" {
		logger.Error("LoginCloud QueryByC2SNRsp.Domain is empty")
		return errors.New("LoginCloud QueryByC2SNRsp.Domain is empty")
	}

	url := "http://" + queryByC2SNRsp.Domain + C2_LOGIN_CLOUD_URL
	requestBody, err := json.Marshal(C2LoginRequest{
		Account: name,
		// 计算密码的 MD5 值
		Password: password,
		C2Sn:     ctrl.C2Sn, // 查库ctrl.C2Sn
	})
	t := C2LoginRequest{
		Account: name,
		// 计算密码的 MD5 值
		Password: password,
		C2Sn:     ctrl.C2Sn, // 查库ctrl.C2Sn
	}
	logger.Info("t ", t)
	logger.Info("url = ", url)
	if err != nil {
		logger.Error("JSON marshaling failed:", err)
		return err
	}

	IsExist := false
	userInfo := &client.GetAllUserRes{}
	err = handler.NewUser().GetAllUser(context.Background(), &client.GetAllUserReq{}, userInfo)
	for _, res := range userInfo.User {
		if res.Name == name {
			IsExist = true
		}
	}

	var loginResponse C2LoginResponse
	if IsExist { //用户存在 只返回成功
		responseBody, err := SendRequest(url, requestBody, nil)
		if err != nil {
			logger.Errorf("Send Request error %+v", err)
		}
		if err = json.Unmarshal(responseBody, &loginResponse); err != nil {
			logger.Error("JSON unmarshaling failed:", err)
		}
		logger.Info("user Exist:", loginResponse)
		if loginResponse.ErrorCode == ERROR_CODE_SUCCESS && err == nil && loginResponse.Data.Token != "" { //登录成功
			//密码更新
			err = handler.NewUser().InsertAndUpdate(context.Background(), &client.UserCrudReq{
				Name:     name,
				Password: password,
				Updater:  "1"}, &client.UserCrudRes{})
			if err != nil {
				logger.Errorf("Insert error %+v", err)
				return nil
			}
			//ctrl.C2Name = name
			//ctrl.MqttConfig.Passwd = password
			//ctrl.MqttConfig.Account = ctrl.C2Name
			//
			//ctrl.CloudAddr = loginResponse.Data.Host
			//ctrl.Token = loginResponse.Data.Token
			logger.Debugf("update password successfully")
			logger.Debug("ctrl = ", ctrl)
			return nil
		}

		err = handler.NewUser().InsertAndUpdate(context.Background(), &client.UserCrudReq{
			Name:    name,
			Updater: "1"}, &client.UserCrudRes{})
		if err != nil {
			logger.Errorf("Insert error %+v", err)
			return errors.New("login fail")
		}
		ctrl.clearConn()
		return nil
	} else {
		responseBody, err := SendRequest(url, requestBody, nil)
		if err != nil {
			logger.Errorf("Send Request error %+v", err)
			return errors.New("login fail")
		}
		if err = json.Unmarshal(responseBody, &loginResponse); err != nil {
			logger.Error("JSON unmarshaling failed:", err)
			return err
		}
		logger.Debug("http C2 login  rsp:", loginResponse)
		logger.Info("user not Exist:", loginResponse)
		if loginResponse.ErrorCode == ERROR_CODE_SUCCESS && err == nil && loginResponse.Data.Token != "" { //登录成功
			//ctrl.MqttConfig.Passwd = password
			//ctrl.MqttConfig.Account = ctrl.C2Name
			//账号密码存库
			err = handler.NewUser().InsertAndUpdate(context.Background(), &client.UserCrudReq{
				Name:     name,
				Password: password,
				Updater:  "1"}, &client.UserCrudRes{})
			if err != nil {
				logger.Errorf("Insert error %+v", err)
				return errors.New("login fail")
			}
			//ctrl.CloudAddr = loginResponse.Data.Host
			//ctrl.Token = loginResponse.Data.Token
			return nil
		} else {
			return errors.New("login fail")
		}

	}
}

func SendRequest(url string, requestBody []byte, header map[string]string) ([]byte, error) {
	timeout := 30 * time.Second
	// 创建一个HTTP客户端
	client := &http.Client{
		Timeout: timeout,
	}
	// 构造HTTP请求并发送
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(requestBody))
	if err != nil {
		logger.Error("create POST request failed:", err)
		return nil, err
	}
	req.Header.Set("Content-Type", "application/json")
	if header != nil {
		for k, v := range header {
			req.Header.Set(k, v)
		}
	}

	resp, err := client.Do(req)
	if err != nil {
		logger.Error("HTTP POST request failed:", err)
		return nil, err
	}
	defer resp.Body.Close()

	responseBody, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		logger.Error("Failed to read response body:", err)
		return nil, errors.New("login fail")
	}
	logger.Debugf("response body: %s", string(responseBody))
	return responseBody, nil
}

// C2LoginCloud C2登录
func (ctrl *CloudTcpCli) C2LoginCloud(ctx context.Context, req *client.C2LoginRequest, resp *client.C2LoginResponse) error {
	if ctrl.C2Sn == "" {
		machGuid := handler.GetDevGuid()
		if machGuid == "" {
			logger.Errorf("C2LoginCloud GetDevGuid is null")
			return errors.New("C2LoginCloud GetDevGuid is null")
		} else {
			ctrl.C2Sn = machGuid
		}
	}
	//去除空格
	req.Account = strings.TrimSpace(req.Account)
	req.Domain = strings.TrimSpace(req.Domain)
	req.TbCode = strings.TrimSpace(req.TbCode)
	req.Password = strings.TrimSpace(req.Password)
	logger.Infof("C2LoginCloud req: %+v", req)

	url := req.GetDomain() + C2_LOGIN_CLOUD_URL
	password := common.ComputeMD5(common.Sha256Encrypt([]byte(req.GetPassword()), []byte(req.Account)))
	requestBody, err := json.Marshal(C2LoginCloudRequest{
		TbCode:   req.GetTbCode(),
		Account:  req.GetAccount(),
		Password: password,
	})
	if err != nil {
		logger.Error("C2LoginCloud marshal err:", err)
		return err
	}
	var loginResponse C2LoginResponse
	responseBody, err := SendRequest(url, requestBody, nil)
	if err != nil {
		logger.Errorf("C2LoginCloud Send Request %v err %v", string(requestBody), err)
		return err
	}
	if err = json.Unmarshal(responseBody, &loginResponse); err != nil {
		logger.Error("C2LoginCloud Unmarshal failed:", err)
		return err
	}

	//登录成功
	if loginResponse.ErrorCode == ERROR_CODE_SUCCESS && err == nil && loginResponse.Data.Token != "" {
		ctrl.Token = loginResponse.Data.Token

		field := map[string]interface{}{
			"domain": req.GetDomain(),
		}

		if err := handler.NewC2Id().UpdateByC2Id(ctx, ctrl.C2Sn, field); err != nil {
			logger.Errorf("C2LoginCloud UpdateByC2Id err: %v", err)
			return err
		}
		resp.Status = success
		logger.Debugf("login successfully")
		return nil
	}
	return errors.New(fmt.Sprintf("%d#%s", loginResponse.ErrorCode, loginResponse.ErrorMessage))
}

// QueryBindStatus 查询当前是否绑定
func (ctrl *CloudTcpCli) QueryBindStatus(ctx context.Context, req *client.QueryBindStatusRequest, resp *client.QueryBindStatusResponse) error {
	if ctrl.C2Sn == "" {
		machGuid := handler.GetDevGuid()
		if machGuid == "" {
			logger.Errorf("QueryBindStatus GetDevGuid is null")
			return errors.New("QueryBindStatus GetDevGuid is null")
		} else {
			ctrl.C2Sn = machGuid
		}
	}
	//查询是否已绑定
	queryByC2SNRsp := &client.QueryByC2SNRsp{}
	if err := handler.NewC2Id().QueryByC2SN(ctx, &client.QueryByC2SNReq{C2Id: ctrl.C2Sn}, queryByC2SNRsp); err != nil {
		logger.Errorf("QueryBindStatus QueryByC2SN err %+v", err)
		return err
	}
	if queryByC2SNRsp.Domain == "" {
		logger.Debug("QueryBindStatus QueryByC2SN is null")
		return nil
	}
	if queryByC2SNRsp.SiteName != "" {
		resp.Data = &client.C2BindSiteData{
			Name:   queryByC2SNRsp.SiteName,
			Type:   1,
			Domain: queryByC2SNRsp.Domain,
		}
		return nil
	}
	return nil
}

// GetBindSiteList 查询可绑定站点
func (ctrl *CloudTcpCli) GetBindSiteList(ctx context.Context, req *client.C2BindSiteListRequest, resp *client.C2BindSiteListResponse) error {
	if ctrl.C2Sn == "" {
		machGuid := handler.GetDevGuid()
		if machGuid == "" {
			logger.Errorf("GetBindSiteList GetDevGuid is null")
			return errors.New("GetBindSiteList GetDevGuid is null")
		} else {
			ctrl.C2Sn = machGuid
		}
	}
	logger.Debugf("GetBindSiteList req:%+v", req)
	//查询是否已绑定
	queryByC2SNRsp := &client.QueryByC2SNRsp{}
	if err := handler.NewC2Id().QueryByC2SN(ctx, &client.QueryByC2SNReq{C2Id: ctrl.C2Sn}, queryByC2SNRsp); err != nil {
		logger.Errorf("GetBindSiteList QueryByC2SN err %+v", err)
		return err
	}
	if queryByC2SNRsp.Domain == "" {
		logger.Debug("GetBindSiteList QueryByC2SN is null")
		return nil
	}
	url := queryByC2SNRsp.Domain + C2_BIND_SITE_LIST_URL
	requestBody, err := json.Marshal(GetBindSiteListRequest{
		C2SN: ctrl.C2Sn,
	})
	if err != nil {
		logger.Error("GetBindSiteList marshal err:", err)
		return err
	}
	var bindSiteList GetBindSiteListResponse
	authHeaderValue := "Bearer " + ctrl.Token
	header := map[string]string{
		"Authorization": authHeaderValue,
	}
	responseBody, err := SendRequest(url, requestBody, header)
	if err != nil {
		logger.Errorf("GetBindSiteList SendRequest %v err: %v", string(requestBody), err)
		return err
	}
	if err = json.Unmarshal(responseBody, &bindSiteList); err != nil {
		logger.Error("GetBindSiteList Unmarshal failed:", err)
		return err
	}
	if bindSiteList.ErrorCode != 0 {
		logger.Errorf("GetBindSiteList failed: %+v", bindSiteList)
		return errors.New(fmt.Sprintf("%d#%s", bindSiteList.ErrorCode, bindSiteList.ErrorMessage))
	}
	//云端不支持分页
	if req.GetPageNum() < 1 {
		req.PageNum = 1
	}
	if req.GetPageSize() <= 0 {
		req.PageSize = 10
	}
	resp.Total = int32(len(bindSiteList.Data))
	if resp.Total == 0 {
		logger.Debug("GetBindSiteList result is null")
		return nil
	}

	startIndex := (req.PageNum - 1) * req.PageSize
	if startIndex >= resp.Total {
		logger.Errorf("GetBindSiteList no data for page %+v", req)
		return fmt.Errorf("GetBindSiteList no data for page %d", req.PageNum)
	}
	endIndex := startIndex + req.PageSize
	if endIndex > resp.Total {
		endIndex = resp.Total
	}
	// 切片操作来获取当前页的数据
	resp.List = make([]*client.C2BindSiteData, 0)
	list := bindSiteList.Data[startIndex:endIndex]
	for _, tmp := range list {
		if tmp.Type == 0 {
			tmp.Type = int32(notBound)
		}
		resp.List = append(resp.List, &client.C2BindSiteData{
			Id:     strconv.Itoa(int(tmp.Id)),
			Name:   tmp.Name,
			Type:   tmp.Type,
			Domain: queryByC2SNRsp.Domain,
		})
	}
	return nil
}

func (ctrl *CloudTcpCli) C2SiteBind(ctx context.Context, req *client.C2BindCloudSiteRequest, resp *client.C2BindCloudSiteResponse) error {
	if ctrl.C2Sn == "" {
		machGuid := handler.GetDevGuid()
		if machGuid == "" {
			logger.Error("C2SiteBind GetDevGuid is null")
			return errors.New("C2SiteBind GetDevGuid is null")
		} else {
			ctrl.C2Sn = machGuid
		}
	}
	logger.Debugf("C2SiteBind req:%+v", req)
	queryByC2SNRsp := &client.QueryByC2SNRsp{}
	if err := handler.NewC2Id().QueryByC2SN(ctx, &client.QueryByC2SNReq{C2Id: ctrl.C2Sn}, queryByC2SNRsp); err != nil {
		logger.Errorf("C2SiteBind QueryByC2SN err %+v", err)
		return err
	}
	if queryByC2SNRsp.Domain == "" {
		logger.Error("C2SiteBind QueryByC2SN is null")
		return errors.New("C2SiteBind QueryByC2SN is null")
	}

	url := queryByC2SNRsp.Domain + C2_BIND_SITE_URL
	siteId, err := strconv.ParseInt(req.GetSiteId(), 10, 64)
	if err != nil {
		logger.Errorf("C2SiteBind ParseInt err: %+v, siteId: %v", err, req.GetSiteId())
		return err
	}
	requestBody, err := json.Marshal(C2SiteBindRequest{
		C2SN:   ctrl.C2Sn,
		SiteId: siteId,
	})
	if err != nil {
		logger.Error("C2SiteBind marshal err:", err)
		return err
	}
	var c2SiteBindResp C2SiteBindResponse
	authHeaderValue := "Bearer " + ctrl.Token
	header := map[string]string{
		"Authorization": authHeaderValue,
	}
	responseBody, err := SendRequest(url, requestBody, header)
	if err != nil {
		logger.Errorf("C2SiteBind SendRequest %s err: %v", string(requestBody), err)
		return err
	}
	if err = json.Unmarshal(responseBody, &c2SiteBindResp); err != nil {
		logger.Error("C2SiteBind Unmarshal failed:", err)
		return err
	}

	if c2SiteBindResp.ErrorCode != 0 {
		logger.Errorf("C2SiteBind failed: %+v", c2SiteBindResp)
		return errors.New(fmt.Sprintf("%d#%s", c2SiteBindResp.ErrorCode, c2SiteBindResp.ErrorMessage))
	}

	if c2SiteBindResp.ErrorCode == 0 && c2SiteBindResp.Data {
		ctrl.CloudRestfulAddr = queryByC2SNRsp.Domain
		resp.Status = 1
		//绑定成功记录站点
		sid, tid, err := parseToken(ctrl.Token)
		if err != nil {
			logger.Errorf("C2SiteBind parseToken err %+v", err)
			return err
		}

		field := map[string]interface{}{
			"site_name": req.GetSiteName(),
			"sid":       sid,
			"tid":       tid,
			"token":     ctrl.Token,
			"site_id":   siteId,
			"bind_time": utils.ParseTimeToString(time.Now()),
		}
		if err := handler.NewC2Id().UpdateByC2Id(ctx, ctrl.C2Sn, field); err != nil {
			logger.Errorf("C2SiteBind UpdateByName err%+v", err)
			return err
		}
	} else {
		logger.Errorf("C2SiteBind failed: %+v", c2SiteBindResp)
		resp.Status = 2
	}
	return nil
}

func (ctrl *CloudTcpCli) C2SiteUnBind(ctx context.Context, req *client.C2UnBindCloudSiteRequest, resp *client.C2UnBindCloudSiteResponse) error {
	if ctrl.C2Sn == "" {
		machGuid := handler.GetDevGuid()
		if machGuid == "" {
			logger.Error("C2SiteUnBind GetDevGuid is null")
			return errors.New("C2SiteUnBind GetDevGuid is null")
		} else {
			ctrl.C2Sn = machGuid
		}
	}
	//根据登录账号查找域名
	queryByC2SNRsp := &client.QueryByC2SNRsp{}
	if err := handler.NewC2Id().QueryByC2SN(ctx, &client.QueryByC2SNReq{C2Id: ctrl.C2Sn}, queryByC2SNRsp); err != nil {
		logger.Errorf("C2SiteUnBind QueryByC2SN err %+v", err)
		return err
	}
	if queryByC2SNRsp.Domain == "" {
		logger.Errorf("C2SiteUnBind QueryByC2SN is null, C2Sn: %s", ctrl.C2Sn)
		return errors.New("C2SiteUnBind QueryByC2SN is null")
	}
	url := queryByC2SNRsp.Domain + C2_UNBIND_SITE_URL
	requestBody, err := json.Marshal(C2SiteUnBindRequest{
		C2SN: ctrl.C2Sn,
	})
	if err != nil {
		logger.Error("C2SiteUnBind marshal err:", err)
		return err
	}
	var c2SiteUnBindResp C2SiteBindResponse
	authHeaderValue := "Bearer " + queryByC2SNRsp.Token
	header := map[string]string{
		"Authorization": authHeaderValue,
	}
	responseBody, err := SendRequest(url, requestBody, header)
	if err != nil {
		logger.Errorf("C2SiteUnBind SendRequest %s err: %v", string(requestBody), err)
		return err
	}
	if err = json.Unmarshal(responseBody, &c2SiteUnBindResp); err != nil {
		logger.Error("C2SiteUnBind Unmarshal failed:", err)
		return err
	}
	if c2SiteUnBindResp.ErrorCode != 0 {
		logger.Error("C2SiteUnBind failed: %+v", c2SiteUnBindResp)
		return errors.New(fmt.Sprintf("%d#%s", c2SiteUnBindResp.ErrorCode, c2SiteUnBindResp.ErrorMessage))
	}

	if c2SiteUnBindResp.ErrorCode == 0 && c2SiteUnBindResp.Data {
		ctrl.Token = ""
		ctrl.clearConn()
		//close mqtt connect
		down.ClearMqttConn(ctrl.MqttConfig)
		resp.Status = 1
		field := map[string]interface{}{
			"domain":    "",
			"site_name": "",
			"sid":       "",
			"tid":       "",
			"token":     "",
			"site_id":   0,
			"bind_time": "",
		}
		if err := handler.NewC2Id().UpdateByC2Id(ctx, ctrl.C2Sn, field); err != nil {
			logger.Errorf("C2SiteUnBind UpdateByC2Id err: %v", err)
			return err
		}
	} else {
		logger.Errorf("C2SiteUnBind failed: %+v", c2SiteUnBindResp)
		resp.Status = 2
	}
	return nil
}

// createPacket 组包
func createPacket(data []byte) []byte {
	bodyByteLength := len(data)
	result := make([]byte, HEAD_SIZE+bodyByteLength)

	result[0] = 0xFD
	result[1] = byte(bodyByteLength & 0xFF)
	result[2] = byte((bodyByteLength >> 8) & 0xFF)
	copy(result[HEAD_SIZE:], data)
	return result
}

func parseToken(token string) (string, string, error) {
	tokenEle := strings.Split(token, ".")
	if len(tokenEle) != TOKEN_LENGTH {
		logger.Errorf("parseToken token format is incorrect: %s", token)
		return "", "", errors.New("parseToken token format is incorrect")
	}
	payloadRaw, err := base64.StdEncoding.DecodeString(tokenEle[1])
	if err != nil {
		logger.Errorf("parseToken failed to decode payload: %v", err)
		return "", "", err
	}

	var payload TokenPayload
	if err := json.Unmarshal(payloadRaw, &payload); err != nil {
		logger.Errorf("parseToken unmarshal err: %v", err)
		return "", "", err
	}
	logger.Debugf("parseToken payload: %+v", payload)
	return payload.Sid, payload.Tid, nil
}

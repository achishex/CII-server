package uploadcloud

import (
	"errors"
	"fmt"
	"strconv"
	"strings"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"github.com/golang/protobuf/proto"
	jsoniter "github.com/json-iterator/go"
	broker2 "go-micro.dev/v4/broker"

	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	videostore "adasgitlab.autel.com/tools/cuav_server/logic/uploadcloud/videoStore"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/proto/cloudPlatform"
	"adasgitlab.autel.com/tools/cuav_server/proto/mavlink"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
)

// radar
// DroneID
// Fpv
// Sfl
// Spoofer
// tracerRF
// Agx,
// RF
const (
	StrDeviceTypeSFL      = "Sfl"
	StrDeviceTypeDroneID  = "DroneID"
	StrDeviceTypeFpv      = "Fpv"
	StrDeviceTypeSpooofer = "Spoofer"
	StrDeviceTypeTracerRF = "tracerRF"
	StrDeviceTypeAgx      = "Agx"
	StrDeviceTypeRF       = "RF"
	StrDeviceTypeRADAR    = "radar"
	StrDeviceTypeSFL200   = "Sfl200"
)

// 1: 设备状态事件; subEventType: 10: 上线， 11 离线
// 2: 侦测状态事件; subEventType: 100: 出现无人机; 101： 无人机消息； 102： 通知视频流跟踪
// 3. 打击状态事件; 200: 成功， 201： 打击失败
// 4. ptz打击事件; 300: 成功， 301： 失败
// 5. Spoofer导航诱导事件:
const (
	EnumEventDeviceStatus = iota + 1
	EnumEventDetect       = 2
	EnumEventHit          = 3
	EnumEventPtzLock      = 4
	EnumEventInduce       = 5
)
const (
	EnumSubEventDeviceOnLine  = 10
	EnumSubEventDeviceOffLine = 11
	//
	EnumSubEventDetectAppear    = 100
	EnumSubEventDetectDisAppear = 101
	EnumSubEventPushVideoDone   = 102
	EnumSubEventInduceEnable    = 103
	EnumSubEventInduceDisable   = 104
	//
	EnumSubEventHitSucc = 200
	EnumSubEventHitFail = 201
	//
	EnumSubEventPtzLockSucc = 300
	EnumSubEventPtzLockFail = 301
)

var blockTrace = make(map[string]interface{})

func TracerLonLat() (lon, lat float32, err error) {
	cfg, exist := handler.C2Config.Get("c2config")
	if exist == false {
		return 0.0, 0.0, nil
	}
	return float32(cfg.Longitude), float32(cfg.Latitude), nil
}
func (c *CloudTcpCli) ReportTracerStatusEvent(info []byte) error {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	hb := &client.DroneStatusInfo{}
	err := proto.Unmarshal(info, hb)
	if err != nil {
		return fmt.Errorf("report tracer proto Unmarshal error: %v", err)
	}
	// hb := mavlink.SflHeartReport{}
	logger.Debug("start Unmarshal TracerStatusEvent")

	EventType, SubEventType := int32(EnumEventDeviceStatus), int32(EnumSubEventDeviceOnLine)
	EventId := hb.Data.GetEventId()

	lon, lat, e := TracerLonLat()
	if e != nil {
		logger.Errorf("get tracer lon, lat fail, sn: %v, e: %v", hb.Header.Sn, e)
	}

	var bodyData []byte
	if hb.Header.MsgType == mavlink.TracerEventOnLine {
		EventType = int32(EnumEventDeviceStatus)
		SubEventType = EnumSubEventDeviceOnLine

		logger.Infof("receive tracer online event.")

		bodyDataPtr := &cloudPlatform.DeviceOnLineDesc{
			Longitude: lon,
			Latitude:  lat,
		}
		//
		bodyDataBin, err := proto.Marshal(bodyDataPtr)
		if err == nil {
			bodyData = bodyDataBin
		}

	} else if hb.Header.MsgType == mavlink.TracerEventOffLine {
		EventType = int32(EnumEventDeviceStatus)
		SubEventType = EnumSubEventDeviceOffLine

		logger.Infof("receive tracer offline event.")

	} else {
		return nil
	}

	//给云端发送
	hbData := make([]*cloudPlatform.ReportEventData, 0)
	hbData = append(hbData, &cloudPlatform.ReportEventData{
		EventId:      EventId,
		EventType:    EventType,
		SubEventType: SubEventType,
		Sn:           hb.Header.Sn,
		DevType:      StrDeviceTypeDroneID,
		CreatTime:    time.Now().UnixMilli(),
		Data:         bodyData,
	})

	logger.Debug("ReportTracerStatusEvent hbData = ", hbData)
	data := &cloudPlatform.ReportEventList{
		Body: hbData,
	}

	// encodedMessage
	encodedMessage, err := proto.Marshal(data)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return fmt.Errorf("Marshal encodedMessage error: %v", err)
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       EventReportURL,
			Sn:        c.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   c.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return err
	}
	//对消息进行封装+head+crc
	sendMessage := createPacket(encodedMessage)
	// 发送TCP消息
	if c.Conn == nil || c.IsLogin == false {
		return nil
	}
	_, err = c.Conn.Write(sendMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return err
	}
	logger.Infof("send tracer status event report to cloud succ, msg: %v", message)
	return nil
}
func (c *CloudTcpCli) ReportTracerDetectEvent(info []byte) error {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()

	detect := &client.TracerDetectInfo{}
	err := proto.Unmarshal(info, detect)
	if err != nil {
		return fmt.Errorf("report tracer proto Unmarshal error: %v", err)
	}

	logger.Debug("start detect Unmarshal")

	EventType, SubEventType := int32(EnumEventDetect), int32(EnumSubEventDetectAppear)
	var bodyData []byte

	if detect.Header.MsgType == mavlink.TracerEventDetectAppear {
		if detect.Data == nil {
			logger.Errorf("detect uav is empty")
			return errors.New("detect uav is empty")
		}

		bodyDataPtr := &cloudPlatform.DetectUavDesc{
			Body: make([]*cloudPlatform.EventDetectUav, 0),
		}
		for _, v := range detect.GetData().GetInfo() {
			uav := &cloudPlatform.EventDetectUav{
				ProductType: v.ProductType,
				Name:        v.DroneName,
				SerialNum:   v.SerialNum,
				Longitude:   float32(v.DroneLongitude),
				Latitude:    float32(v.DroneLatitude),
				Role:        v.Role,
			}
			bodyDataPtr.Body = append(bodyDataPtr.Body, uav)
		}

		EventType = int32(EnumEventDetect)
		SubEventType = EnumSubEventDetectAppear

		bodyDataBin, err := proto.Marshal(bodyDataPtr)
		if err == nil {
			bodyData = bodyDataBin
		} else {
			logger.Errorf("marshal detect fail, e: %v", err)
			return errors.New("marshal fail")
		}
		logger.Infof("receive tracer detect uav event report")
	} else if detect.Header.MsgType == mavlink.TracerEventDetectDisappear {
		EventType = int32(EnumEventDetect)
		SubEventType = EnumSubEventDetectDisAppear

		logger.Infof("receive tracer detect disappear event.")
	} else {
		logger.Errorf("not support msgType: %v", detect.Header.MsgType)
		return fmt.Errorf("not support msgType: %v", detect.Header.MsgType)
	}
	EventId := detect.GetData().GetEventId()

	//给云端发送
	detectUav := make([]*cloudPlatform.ReportEventData, 0)
	detectUav = append(detectUav, &cloudPlatform.ReportEventData{
		EventId:      EventId,
		EventType:    EventType,
		SubEventType: SubEventType,
		Sn:           detect.Header.Sn,
		DevType:      StrDeviceTypeDroneID,
		CreatTime:    time.Now().UnixMilli(),
		Data:         bodyData,
	})

	logger.Debug("ReportTracerDetectEvent detectData = ", detectUav)
	data := &cloudPlatform.ReportEventList{
		Body: detectUav,
	}

	// encodedMessage
	encodedMessage, err := proto.Marshal(data)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return fmt.Errorf("Marshal encodedMessage error: %v", err)
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       EventReportURL,
			Sn:        c.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   c.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return err
	}
	//对消息进行封装+head+crc
	sendMessage := createPacket(encodedMessage)
	// 发送TCP消息
	if c.Conn == nil || c.IsLogin == false {
		return nil
	}
	_, err = c.Conn.Write(sendMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return err
	}

	logger.Infof("report tracer detect event to cloud success, %v", message)
	return nil
}

func (c *CloudTcpCli) EventReport() {
	go func() {
		for {
			time.Sleep(5 * time.Second)
			for k, v := range blockTrace {
				logger.Warnf("blockTrace EventReport: %s, %v", k, v)
			}
		}
	}()
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	_, _ = mq.EventReportBroker.Subscribe(mq.EventReportTopic, func(event broker2.Event) error {
		now := time.Now()
		finish := now
		ch := make(chan struct{})
		defer func() {
			finish = time.Now()
			<-ch
		}()

		go func() {
			time.Sleep(5 * time.Second)
			<-ch
		}()
		go func() {
			ch <- struct{}{}
			close(ch)
			duration := finish.Sub(now)
			if duration > 10*time.Second {
				blockTrace[event.Topic()] = duration.Seconds()
			}
		}()
		entity := client.ClientReport{}
		err := proto.Unmarshal(event.Message().Body, &entity)
		if err != nil {
			return fmt.Errorf("report sfl proto Unmarshal error: %v", err)
		}
		MsgType := entity.MsgType
		info := entity.Data
		switch MsgType {
		case common.ClientMsgTracerStatusEventData:
			return c.ReportTracerStatusEvent(info)
		case common.ClientMsgTracerDetectEventData:
			return c.ReportTracerDetectEvent(info)

		case common.ClientMsgSFlStatusEventData:
			return c.ReportSflStatusEvent(info)
		case common.ClientMsgSFlDetectEventData:
			return c.ReportSflDetectEvent(info)
		case common.ClientMsgSflHitEventData:
			return c.ReportSflHitStatusEvent(info)

		case common.ClientMsgAgxStatusEventData:
			return c.ReportAgxStatusEvent(info)
		case common.ClientMsgAgxDetectEventData:
			return c.ReportAgxDetectEvent(info)
		case common.ClientMsgAgzPtzLockEventData:
			return c.ReportAgxPtzLockUavEvent(info)

		case common.ClientMsgRadarStatusEventData:
			return c.ReportRadarStatusEvent(info)
		case common.ClientMsgRadarDetectEventData:
			return c.ReportRadarDetectEvent(info)

		case common.ClientMsgTracerRFStatusEventData:
			return c.ReportTracerRFStatusEvent(info)
		case common.ClientMsgTracerRFDetectEventData:
			return c.ReportTracerRFDetectEvent(info)

		case common.ClientMsgSpooferStatusEventData:
			return c.ReportSpooferStatusEvent(info)

		case common.ClientMsgSfl200StatusEventData:
			return c.ReportSfl200StatusEvent(info)
		case common.ClientMsgSFl200DetectEventData:
			return c.ReportSfl200DetectEvent(info)
		case common.ClientMsgSFl200AgxDetectEventData:
			return c.ReportSfl200AgxDetectEvent(info)
		case common.ClientMsgSfl200HitEventData:
			return c.ReportSfl200HitOverEvent(info)
		case common.ClientMsgSFl200AgzPtzLockEventData:
			return c.ReportSfl200AgxPtzLockUavEvent(info)
		case common.ClientMsgSTP120StatusEventData:
			return nil

		default:
			err := fmt.Errorf("unrecognized msg type: %v", MsgType)
			logger.Error(err)
			return err
		}
	})
}
func (c *CloudTcpCli) ReportSflHitStatusEvent(info []byte) error {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	hitStatus := &client.SflHitStateInfo{}
	err := proto.Unmarshal(info, hitStatus)
	if err != nil {
		return fmt.Errorf("report sfl proto Unmarshal error: %v", err)
	}
	logger.Debugf("start Unmarshal, SFL hit state: %v", hitStatus)

	sflHitStatusEventItems := []*cloudPlatform.SflHitStatusEventItem{}
	sflHitStatusEventItems = append(sflHitStatusEventItems, &cloudPlatform.SflHitStatusEventItem{
		SerialNum:      hitStatus.Data.SerialNum,
		DroneName:      hitStatus.Data.DroneName,
		DroneLongitude: hitStatus.Data.DroneLongitude,
		DroneLatitude:  hitStatus.Data.DroneLatitude,
		DroneHeight:    hitStatus.Data.DroneHeight,
		DroneYawAngle:  hitStatus.Data.DroneYawAngle,
	})

	sflHitStatusEventDesc := &cloudPlatform.SflHitStatusEventDesc{
		Body: sflHitStatusEventItems,
	}
	bodyData, err := proto.Marshal(sflHitStatusEventDesc)
	if err != nil {
		logger.Errorf("marsh hit  status data fail, e: %v", err)
	}

	EventType, SubEventType := int32(EnumEventHit), int32(EnumSubEventHitSucc)
	EventId := hitStatus.Data.GetEventId()
	if hitStatus.Header.MsgType == mavlink.SflEventHitSucc {

		EventType = int32(EnumEventHit)
		SubEventType = EnumSubEventHitSucc

		logger.Infof("receive sfl hit succ event.")

	} else if hitStatus.Header.MsgType == mavlink.SflEventHitFail {
		EventType = int32(EnumEventHit)
		SubEventType = EnumSubEventHitFail
		logger.Infof("receive sfl hit uav fail event.")
	}

	//给云端发送
	hitStatusCloudData := make([]*cloudPlatform.ReportEventData, 0)
	hitStatusCloudData = append(hitStatusCloudData, &cloudPlatform.ReportEventData{
		EventId:      EventId,
		EventType:    EventType,
		SubEventType: SubEventType,
		Sn:           hitStatus.Header.Sn,
		DevType:      StrDeviceTypeSFL,
		CreatTime:    time.Now().UnixMilli(),
		Data:         bodyData,
	})

	logger.Debug("hit status = ", hitStatusCloudData)
	data := &cloudPlatform.ReportEventList{
		Body: hitStatusCloudData,
	}

	// encodedMessage
	encodedMessage, err := proto.Marshal(data)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return fmt.Errorf("Marshal encodedMessage error: %v", err)
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       EventReportURL,
			Sn:        c.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   c.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return err
	}
	//对消息进行封装+head+crc
	sendMessage := createPacket(encodedMessage)
	// 发送TCP消息
	if c.Conn == nil || c.IsLogin == false {
		return nil
	}
	_, err = c.Conn.Write(sendMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return err
	}
	logger.Infof("send sfl hit status event to cloud success, data: %v", data)
	return nil
}
func (c *CloudTcpCli) ReportSflDetectEvent(info []byte) error {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	detect := &client.SflDetectInfo{}
	err := proto.Unmarshal(info, detect)
	if err != nil {
		return fmt.Errorf("report sfl proto Unmarshal error: %v", err)
	}
	logger.Debugf("start Unmarshal, data: %v", detect.Data)

	var bodyData []byte
	if detect.Header.MsgType == mavlink.SflEventDetectAppear {
		if detect.Data == nil || len(detect.Data.List) <= 0 {
			logger.Infof("has not any uav detect")
			return nil
		}

		var uavDetect []*cloudPlatform.EventDetectUav
		var dataDetect *cloudPlatform.DetectUavDesc
		var err error
		for _, v := range detect.Data.List {
			uavDetect = append(uavDetect, &cloudPlatform.EventDetectUav{
				ProductType: v.ProductType,
				Name:        v.DroneName,
				SerialNum:   v.SerialNum,
				Longitude:   float32(v.DroneLongitude),
				Latitude:    float32(v.DroneLatitude),
				Role:        v.Role,
			})
		}

		dataDetect = &cloudPlatform.DetectUavDesc{
			Body: uavDetect,
		}

		bodyData, err = proto.Marshal(dataDetect)
		if err != nil {
			logger.Errorf("marsh detect uav fail, e: %v", err)
			return nil
		}
		logger.Infof("sfl detect uas: %v", uavDetect)
	}

	EventType, SubEventType := int32(EnumEventDetect), int32(EnumSubEventDetectAppear)
	EventId := detect.Data.GetEventId()
	if detect.Header.MsgType == mavlink.SflEventDetectAppear {

		EventType = int32(EnumEventDetect)
		SubEventType = EnumSubEventDetectAppear

		logger.Infof("receive sfl detect uav appear event.")

	} else if detect.Header.MsgType == mavlink.SflEventDetectDisappear {
		EventType = int32(EnumEventDetect)
		SubEventType = EnumSubEventDetectDisAppear
		logger.Infof("receive sfl detect uav disappear event.")
	}

	//给云端发送
	detectData := make([]*cloudPlatform.ReportEventData, 0)
	detectData = append(detectData, &cloudPlatform.ReportEventData{
		EventId:      EventId,
		EventType:    EventType,
		SubEventType: SubEventType,
		Sn:           detect.Header.Sn,
		DevType:      StrDeviceTypeSFL,
		CreatTime:    time.Now().UnixMilli(),
		Data:         bodyData,
	})

	logger.Debug("detect = ", detectData)
	data := &cloudPlatform.ReportEventList{
		Body: detectData,
	}

	// encodedMessage
	encodedMessage, err := proto.Marshal(data)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return fmt.Errorf("Marshal encodedMessage error: %v", err)
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       EventReportURL,
			Sn:        c.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   c.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return err
	}
	//对消息进行封装+head+crc
	sendMessage := createPacket(encodedMessage)
	// 发送TCP消息
	if c.Conn == nil || c.IsLogin == false {
		return nil
	}
	_, err = c.Conn.Write(sendMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return err
	}
	logger.Infof("send sfl detect event to cloud success, data: %v", data)
	return nil
}

func (c *CloudTcpCli) ReportSflStatusEvent(info []byte) error {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	hb := &client.SflHeartInfo{}
	err := proto.Unmarshal(info, hb)
	if err != nil {
		return fmt.Errorf("report sfl proto Unmarshal error: %v", err)
	}
	logger.Debug("start Unmarshal SflStatus")

	EventType, SubEventType := int32(EnumEventDeviceStatus), int32(EnumSubEventDeviceOnLine)
	EventId := hb.Data.GetEventId()

	var bodyData []byte
	if hb.Header.MsgType == mavlink.SflEventMsgOnline {
		EventType = int32(EnumEventDeviceStatus)
		SubEventType = EnumSubEventDeviceOnLine

		bodyDataPtr := &cloudPlatform.DeviceOnLineDesc{
			Longitude: float32(hb.Data.GunLongitude),
			Latitude:  float32(hb.Data.GunLatitude),
		}
		//
		bodyDataBin, err := proto.Marshal(bodyDataPtr)
		if err == nil {
			bodyData = bodyDataBin
		}

		logger.Infof("receive sfl online event, data: %v", bodyDataPtr)

	} else if hb.Header.MsgType == mavlink.SflEventMsgOffLine {
		EventType = int32(EnumEventDeviceStatus)
		SubEventType = EnumSubEventDeviceOffLine

		logger.Infof("receive sfl offline event.")

	} else {
		return nil
	}

	//给云端发送
	hbData := make([]*cloudPlatform.ReportEventData, 0)
	hbData = append(hbData, &cloudPlatform.ReportEventData{
		EventId:      EventId,
		EventType:    EventType,
		SubEventType: SubEventType,
		Sn:           hb.Header.Sn,
		DevType:      StrDeviceTypeSFL,
		CreatTime:    time.Now().UnixMilli(),
		Data:         bodyData,
	})

	logger.Debug("hbData = ", hbData)
	data := &cloudPlatform.ReportEventList{
		Body: hbData,
	}

	// encodedMessage
	encodedMessage, err := proto.Marshal(data)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return fmt.Errorf("Marshal encodedMessage error: %v", err)
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       EventReportURL,
			Sn:        c.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   c.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return err
	}
	//对消息进行封装+head+crc
	sendMessage := createPacket(encodedMessage)
	// 发送TCP消息
	if c.Conn == nil || c.IsLogin == false {
		logger.Errorf("report cloud platform conn is nil")
		return nil
	}
	_, err = c.Conn.Write(sendMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return err
	}
	return nil
}

func (c *CloudTcpCli) ReportAgxStatusEvent(info []byte) error {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	hb := &client.AgxHeartBeatInfo{}
	err := proto.Unmarshal(info, hb)
	if err != nil {
		return fmt.Errorf("report sfl proto Unmarshal error: %v", err)
	}
	// hb := mavlink.SflHeartReport{}
	logger.Debug("start Unmarshal")

	// mu.Lock()
	// defer mu.Unlock()

	EventType, SubEventType := int32(EnumEventDeviceStatus), int32(EnumSubEventDeviceOnLine)
	EventId := hb.Data.GetEventId()

	var bodyData []byte
	if hb.Header.MsgType == mavlink.AgxEventOnLine {
		EventType = int32(EnumEventDeviceStatus)
		SubEventType = EnumSubEventDeviceOnLine

		logger.Infof("receive agx online event.")
		bodyDataPtr := &cloudPlatform.DeviceOnLineDesc{
			//Longitude: float32(hb.Data.GunLongitude),
			//Latitude:  float32(hb.Data.GunLatitude),
		}
		//
		bodyDataBin, err := proto.Marshal(bodyDataPtr)
		if err == nil {
			bodyData = bodyDataBin
		}

	} else if hb.Header.MsgType == mavlink.AgxEventOffOnLine {
		EventType = int32(EnumEventDeviceStatus)
		SubEventType = EnumSubEventDeviceOffLine

		logger.Infof("agx offline event.")

	} else {
		return nil
	}

	//给云端发送
	hbData := make([]*cloudPlatform.ReportEventData, 0)
	hbData = append(hbData, &cloudPlatform.ReportEventData{
		EventId:      EventId,
		EventType:    EventType,
		SubEventType: SubEventType,
		Sn:           hb.Header.Sn,
		DevType:      StrDeviceTypeAgx,
		CreatTime:    time.Now().UnixMilli(),
		Data:         bodyData,
	})

	logger.Debug("hbData = ", hbData)
	data := &cloudPlatform.ReportEventList{
		Body: hbData,
	}

	// encodedMessage
	encodedMessage, err := proto.Marshal(data)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return fmt.Errorf("Marshal encodedMessage error: %v", err)
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       EventReportURL,
			Sn:        c.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   c.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return err
	}
	//对消息进行封装+head+crc
	sendMessage := createPacket(encodedMessage)
	// 发送TCP消息
	if c.Conn == nil || c.IsLogin == false {
		return nil
	}
	_, err = c.Conn.Write(sendMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return err
	}
	return nil
}
func (c *CloudTcpCli) ReportAgxPtzLockUavEvent(info []byte) error {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()

	lockUav := &client.AgxPtzLockInfo{}
	err := proto.Unmarshal(info, lockUav)
	if err != nil {
		return fmt.Errorf("report agx proto Unmarshal error: %v", err)
	}
	logger.Debug("start Unmarshal")

	var bodyData []byte
	EventType, SubEventType := int32(EnumEventPtzLock), int32(EnumSubEventPtzLockSucc)
	EventId := lockUav.GetEventId()

	if lockUav.Header.MsgType == mavlink.AgxEventPtzLockUavSucc {
		EventType, SubEventType = int32(EnumEventPtzLock), EnumSubEventPtzLockSucc
		logger.Infof("agx ptz lock succ")

		var uavsToReport []*cloudPlatform.EventPtzLockUav
		var lockUavBody *cloudPlatform.EventPtzLockUavDesc = new(cloudPlatform.EventPtzLockUavDesc)

		for _, uavItems := range lockUav.Data {
			if uavItems == nil {
				continue
			}
			//
			uavsToReport = append(uavsToReport, &cloudPlatform.EventPtzLockUav{
				SerialNum: uavItems.SerialNum,
				Name:      uavItems.DroneName,
				Longitude: uavItems.Longitude,
				Latitude:  uavItems.Latitude,
				LockTime:  uavItems.LockedTime,
			})
		}
		logger.Infof("ptz lock uav succ, uav list: %v", uavsToReport)

		lockUavBody.Body = uavsToReport
		bodyDataBin, err := proto.Marshal(lockUavBody)
		if err == nil {
			bodyData = bodyDataBin

		} else {
			logger.Infof("marsh ptz lock uavs fail, e: %v", err)
			return fmt.Errorf("marsh detect uavs fail, e: %v", err)
		}

	} else if lockUav.Header.MsgType == mavlink.AgxEventPtzLockUavFail {
		EventType, SubEventType = int32(EnumEventPtzLock), EnumSubEventPtzLockFail
		logger.Infof("agx ptz lock fail")

	} else {
		logger.Infof("not support msg type, %v", lockUav.Header.MsgType)
		return nil
	}

	//给云端发送
	reportEventData := make([]*cloudPlatform.ReportEventData, 0)
	reportEventData = append(reportEventData, &cloudPlatform.ReportEventData{
		EventId:      EventId,
		EventType:    EventType,
		SubEventType: SubEventType,
		Sn:           lockUav.Header.Sn,
		DevType:      StrDeviceTypeAgx,
		CreatTime:    time.Now().UnixMilli(),
		Data:         bodyData,
	})

	logger.Debug("ptzLock = ", reportEventData)
	data := &cloudPlatform.ReportEventList{
		Body: reportEventData,
	}

	// encodedMessage
	encodedMessage, err := proto.Marshal(data)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return fmt.Errorf("Marshal encodedMessage error: %v", err)
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       EventReportURL,
			Sn:        c.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   c.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return err
	}
	//对消息进行封装+head+crc
	sendMessage := createPacket(encodedMessage)
	// 发送TCP消息
	if c.Conn == nil || c.IsLogin == false {
		logger.Infof("report connect is nil or is not login")
		return nil
	}
	_, err = c.Conn.Write(sendMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return err
	}

	logger.Infof("report agx ptz lock uav report")
	return nil
}

func (c *CloudTcpCli) ReportAgxDetectEvent(info []byte) error {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()

	detect := &client.AgxDetectInfo{}
	err := proto.Unmarshal(info, detect)
	if err != nil {
		return fmt.Errorf("report agx proto Unmarshal error: %v", err)
	}

	logger.Debug("start Unmarshal")
	EventType, SubEventType := int32(EnumEventDetect), int32(EnumSubEventDetectAppear)
	EventId := detect.GetEventId()

	var bodyData []byte
	uavs := make([]*cloudPlatform.EventDetectUav, 0)

	if detect.Header.MsgType == mavlink.AgxEventDetectAppear {
		EventType = int32(EnumEventDetect)
		SubEventType = EnumSubEventDetectAppear

		logger.Infof("agx detect appear event.")
		bodyDataPtr := &cloudPlatform.DetectUavDesc{}

		for _, v := range detect.Data {
			if v == nil {
				continue
			}
			if v.Classification == 0x04 {
				logger.Infof("is bird detect type, modify: %x to 0x00", v.Classification)
				v.Classification = 0x00
			}
			uavs = append(uavs, &cloudPlatform.EventDetectUav{
				SerialNum:      strconv.FormatInt(int64(v.ObjId), 10),
				Classification: v.Classification,
				X:              float32(v.X),
				Y:              float32(v.Y),
				Z:              float32(v.Z),
			})
		}
		logger.Infof("detect uav data: %v", uavs)

		bodyDataPtr.Body = uavs
		bodyDataBin, err := proto.Marshal(bodyDataPtr)
		if err == nil {
			bodyData = bodyDataBin
		} else {
			logger.Infof("marshal detect uavs fail, e: %v", err)
			return fmt.Errorf("marshal detect uavs fail, e: %v", err)
		}
		logger.Debug("eventid: ", EventId)
		videostore.VsSingleton.GoSaveToLocalVideoAndPushToS3(EventId, detect.Header.Sn)

	} else if detect.Header.MsgType == mavlink.AgxEventDetectDisappear {
		EventType = int32(EnumEventDetect)
		SubEventType = EnumSubEventDetectDisAppear

		logger.Infof("agx detect disappear event.")

		videostore.VsSingleton.GoCancelCaptureVideo(EventId)

	} else if detect.Header.MsgType == mavlink.AgxEventPushVideoDone {
		EventType = int32(EnumEventDetect)
		SubEventType = EnumSubEventPushVideoDone
		var fileURL string
		if videostore.IsHasPrefix {
			path := fmt.Sprintf("%s-%s", videostore.GPreFixS3, EventId)

			fileURL = fmt.Sprintf("%s.mp4", path)
		} else {
			fileURL = fmt.Sprintf("%s.mp4", EventId)
		}

		StoreType := strconv.FormatInt(videostore.VsSingleton.S3Con.StoreType, 10)
		bodyDataPtrList := make([]*cloudPlatform.ReportCloudVideo, 0)
		bodyDataPtr := &cloudPlatform.ReportCloudVideo{
			ProtoType:  StoreType,
			BucketName: videostore.VsSingleton.S3Con.BucketName,
			FileUrl:    fileURL,
		}
		bodyDataPtrList = append(bodyDataPtrList, bodyDataPtr)
		bodyDataPtrSend := &cloudPlatform.ReportCloudVideoList{}
		bodyDataPtrSend.Body = bodyDataPtrList

		bodyDataBin, err := proto.Marshal(bodyDataPtrSend)
		if err == nil {
			bodyData = bodyDataBin
		} else {
			logger.Infof("marshal detect uavs fail, e: %v", err)
			return fmt.Errorf("marshal detect uavs fail, e: %v", err)
		}

		logger.Infof("AgxEventPushVideoDone event.")
	} else {
		logger.Infof("not support msg type: %v", detect.Header.MsgType)
		return nil
	}

	//给云端发送
	hbData := make([]*cloudPlatform.ReportEventData, 0)
	hbData = append(hbData, &cloudPlatform.ReportEventData{
		EventId:      EventId,
		EventType:    EventType,
		SubEventType: SubEventType,
		Sn:           detect.Header.Sn,
		DevType:      StrDeviceTypeAgx,
		CreatTime:    time.Now().UnixMilli(),
		Data:         bodyData,
	})

	logger.Debug("hbData = ", hbData)
	data := &cloudPlatform.ReportEventList{
		Body: hbData,
	}

	// encodedMessage
	encodedMessage, err := proto.Marshal(data)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return fmt.Errorf("Marshal encodedMessage error: %v", err)
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       EventReportURL,
			Sn:        c.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   c.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return err
	}
	//对消息进行封装+head+crc
	sendMessage := createPacket(encodedMessage)
	// 发送TCP消息
	if c.Conn == nil || c.IsLogin == false {
		logger.Infof("report connect is nil or is not login")
		return nil
	}
	_, err = c.Conn.Write(sendMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return err
	}

	logger.Infof("report agx detect report, uavs: %v", uavs)
	return nil
}

// ReportRadarStatusEvent 雷达上下线事件上报云平台
func (c *CloudTcpCli) ReportRadarStatusEvent(info []byte) error {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	hb := &common.EquipmentMessageBoxEntity{}
	err := jsoniter.Unmarshal(info, hb)
	if err != nil {
		return fmt.Errorf("report radar proto Unmarshal error: %v", err)
	}
	heartByte, err := jsoniter.Marshal(hb.Info)
	if err != nil {
		logger.Errorf("ReportRadarStatusEvent marshal err:%+v", err)
		fmt.Errorf("ReportRadarStatusEvent marshal err: %v", err)
	}
	radarEntity := &common.RadarStatusEntity{}
	if err = jsoniter.Unmarshal(heartByte, radarEntity); err != nil {
		logger.Errorf("ReportRadarStatusEvent Unmarshal err:%+v", err)
		fmt.Errorf("ReportRadarStatusEvent Unmarshal err: %v", err)
	}

	EventType, SubEventType := int32(EnumEventDeviceStatus), int32(EnumSubEventDeviceOnLine)
	EventId := radarEntity.EventId

	var bodyData []byte
	if radarEntity.IsOnline == common.DevOnline {
		EventType = int32(EnumEventDeviceStatus)
		SubEventType = EnumSubEventDeviceOnLine

		logger.Infof("receive radar online event.")
		bodyDataPtr := &cloudPlatform.DeviceOnLineDesc{}
		bodyDataBin, err := proto.Marshal(bodyDataPtr)
		if err == nil {
			bodyData = bodyDataBin
		}
	} else if radarEntity.IsOnline == common.DevOffline {
		EventType = int32(EnumEventDeviceStatus)
		SubEventType = EnumSubEventDeviceOffLine

		logger.Infof("receive radar offline event.")
	} else {
		return fmt.Errorf("not support is_online type: %v", radarEntity.IsOnline)
	}

	//给云端发送
	hbData := make([]*cloudPlatform.ReportEventData, 0)
	hbData = append(hbData, &cloudPlatform.ReportEventData{
		EventId:      EventId,
		EventType:    EventType,
		SubEventType: SubEventType,
		Sn:           hb.Sn,
		DevType:      StrDeviceTypeRADAR,
		CreatTime:    time.Now().UnixMilli(),
		Data:         bodyData,
	})

	logger.Debug("ReportRadarStatusEvent hbData = ", hbData)
	data := &cloudPlatform.ReportEventList{
		Body: hbData,
	}

	// encodedMessage
	encodedMessage, err := proto.Marshal(data)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return fmt.Errorf("Marshal encodedMessage error: %v", err)
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       EventReportURL,
			Sn:        c.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   c.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return err
	}
	//对消息进行封装+head+crc
	sendMessage := createPacket(encodedMessage)
	// 发送TCP消息
	if c.Conn == nil || c.IsLogin == false {
		return nil
	}
	_, err = c.Conn.Write(sendMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return err
	}
	logger.Infof("send radar status event report to cloud success, msg: %+v", message)
	return nil
}

// ReportRadarDetectEvent 雷达侦测事件上报
func (c *CloudTcpCli) ReportRadarDetectEvent(info []byte) error {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	detect := &client.RadarTrackInfo{}
	err := proto.Unmarshal(info, detect)
	if err != nil {
		return fmt.Errorf("report radar proto Unmarshal error: %v", err)
	}
	logger.Debugf("start Unmarshal, data: %v", detect)

	var bodyData []byte
	if detect.Header.MsgType == mavlink.RadarEventDetectAppear {
		if detect.Data == nil || len(detect.Data) <= 0 {
			logger.Infof("has not any uav detect")
			return nil
		}

		var uavDetect []*cloudPlatform.EventDetectUav
		var dataDetect *cloudPlatform.DetectUavDesc
		var err error
		for _, v := range detect.Data {
			uavDetect = append(uavDetect, &cloudPlatform.EventDetectUav{
				SerialNum:      strconv.Itoa(int(v.ObjId)),
				Classification: v.Classification,
				X:              float32(v.X),
				Y:              float32(v.Y),
				Z:              float32(v.Z),
			})
		}

		dataDetect = &cloudPlatform.DetectUavDesc{
			Body: uavDetect,
		}

		bodyData, err = proto.Marshal(dataDetect)
		if err != nil {
			logger.Errorf("marsh detect uav fail, e: %v", err)
			return nil
		}
		logger.Infof("radar detect uas: %v", uavDetect)
	}

	EventType, SubEventType := int32(EnumEventDetect), int32(EnumSubEventDetectAppear)
	EventId := detect.GetEventId()
	if detect.Header.MsgType == mavlink.RadarEventDetectAppear {

		EventType = int32(EnumEventDetect)
		SubEventType = EnumSubEventDetectAppear
	} else if detect.Header.MsgType == mavlink.RadarEventDetectDisAppear {
		EventType = int32(EnumEventDetect)
		SubEventType = EnumSubEventDetectDisAppear
	}

	//给云端发送
	detectData := make([]*cloudPlatform.ReportEventData, 0)
	detectData = append(detectData, &cloudPlatform.ReportEventData{
		EventId:      EventId,
		EventType:    EventType,
		SubEventType: SubEventType,
		Sn:           detect.Header.Sn,
		DevType:      StrDeviceTypeRADAR,
		CreatTime:    time.Now().UnixMilli(),
		Data:         bodyData,
	})

	logger.Debug("ReportRadarDetectEvent detect = ", detectData)
	data := &cloudPlatform.ReportEventList{
		Body: detectData,
	}

	// encodedMessage
	encodedMessage, err := proto.Marshal(data)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return fmt.Errorf("Marshal encodedMessage error: %v", err)
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       EventReportURL,
			Sn:        c.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   c.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return err
	}
	//对消息进行封装+head+crc
	sendMessage := createPacket(encodedMessage)
	// 发送TCP消息
	if c.Conn == nil || c.IsLogin == false {
		return nil
	}
	_, err = c.Conn.Write(sendMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return err
	}
	logger.Infof("send radar detect event to cloud success, data: %+v", data)
	return nil
}

// ReportTracerRFStatusEvent 坤雷上下线事件上报
func (c *CloudTcpCli) ReportTracerRFStatusEvent(info []byte) error {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	hb := &client.UrdDeviceInfoUpload{}
	err := proto.Unmarshal(info, hb)
	if err != nil {
		return fmt.Errorf("report tracerRF proto Unmarshal error: %v", err)
	}

	EventType, SubEventType := int32(EnumEventDeviceStatus), int32(EnumSubEventDeviceOnLine)
	EventId := hb.Data.GetEventId()

	var bodyData []byte
	if hb.Header.MsgType == handler.TracerRFEventMsgOnline {
		EventType = int32(EnumEventDeviceStatus)
		SubEventType = EnumSubEventDeviceOnLine

		bodyDataPtr := &cloudPlatform.DeviceOnLineDesc{
			Longitude: hb.Data.Longitude,
			Latitude:  hb.Data.Latitude,
		}

		bodyDataBin, err := proto.Marshal(bodyDataPtr)
		if err == nil {
			bodyData = bodyDataBin
		}

	} else if hb.Header.MsgType == handler.TracerRFEventMsgOffLine {
		EventType = int32(EnumEventDeviceStatus)
		SubEventType = EnumSubEventDeviceOffLine
	} else {
		return fmt.Errorf("not support msgType:%v", hb.Header.MsgType)
	}

	//给云端发送
	hbData := make([]*cloudPlatform.ReportEventData, 0)
	hbData = append(hbData, &cloudPlatform.ReportEventData{
		EventId:      EventId,
		EventType:    EventType,
		SubEventType: SubEventType,
		Sn:           hb.Header.Sn,
		DevType:      StrDeviceTypeTracerRF,
		CreatTime:    time.Now().UnixMilli(),
		Data:         bodyData,
	})

	logger.Debug("ReportTracerRFStatusEvent hbData = ", hbData)
	data := &cloudPlatform.ReportEventList{
		Body: hbData,
	}

	// encodedMessage
	encodedMessage, err := proto.Marshal(data)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return fmt.Errorf("Marshal encodedMessage error: %v", err)
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       EventReportURL,
			Sn:        c.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   c.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return err
	}
	//对消息进行封装+head+crc
	sendMessage := createPacket(encodedMessage)

	// 发送TCP消息
	if c.Conn == nil || c.IsLogin == false {
		// 等待netty连接建立
		nowTickTime, maxTickTime := 100, 5000 //milliseconds
		tick := time.NewTicker(time.Duration(nowTickTime) * time.Millisecond)
		defer tick.Stop()
		timeout := time.After(1 * time.Second)
		for {
			select {
			case <-tick.C:
				if c.Conn != nil && c.IsLogin == true {
					goto lable
				}
				nowTickTime = nowTickTime * 2
				if nowTickTime > maxTickTime {
					nowTickTime = maxTickTime
				}
				tick.Reset(time.Duration(nowTickTime) * time.Millisecond)
			case <-timeout:
				logger.Error("timeout occurred!")
				return nil
			}
		}
	}
lable:
	_, err = c.Conn.Write(sendMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return err
	}
	logger.Infof("send tracerRF status event to cloud success, message: %+v", message)
	return nil
}

// ReportTracerRFDetectEvent 坤雷侦测事件上报
func (c *CloudTcpCli) ReportTracerRFDetectEvent(info []byte) error {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	detect := &common.EquipmentMessageBoxEntity{}
	err := jsoniter.Unmarshal(info, detect)
	if err != nil {
		return fmt.Errorf("report tracerRF Unmarshal error: %v", err)
	}
	logger.Debugf("start Unmarshal, data: %v", detect)

	var (
		bodyData []byte
		eventId  string
	)
	switch detect.MsgType {
	case handler.TracerRFEventDetectAppear, handler.TracerRFEventDetectDisappear:
		if detect.Info == nil {
			logger.Infof("has not any uav detect")
			return nil
		}
		b, err := jsoniter.Marshal(detect.Info)
		if err != nil {
			logger.Errorf("ReportTracerRFDetectEvent marshal err:%v", err)
			return err
		}
		urdDroneInfo := &handler.UrdDroneInfoUpload{}
		if err = jsoniter.Unmarshal(b, urdDroneInfo); err != nil {
			logger.Errorf("ReportTracerRFDetectEvent unmarshal err:%v", err)
			return err
		}
		eventId = urdDroneInfo.EventId

		TargetInfoTrim := strings.ReplaceAll(urdDroneInfo.TargetInfo, "\x00", "")
		TargetInfo := ProcessTarget(TargetInfoTrim)

		if urdDroneInfo.Id > 0 {
			var uavDetect []*cloudPlatform.EventDetectUav
			var dataDetect *cloudPlatform.DetectUavDesc
			var err error
			uavDetect = append(uavDetect, &cloudPlatform.EventDetectUav{
				//ProductType: urdDroneInfo.Id,
				Name:      TargetInfo,
				SerialNum: detect.Sn,
				Longitude: urdDroneInfo.Longitude,
				Latitude:  urdDroneInfo.Latitude,
			})

			dataDetect = &cloudPlatform.DetectUavDesc{
				Body: uavDetect,
			}

			bodyData, err = proto.Marshal(dataDetect)
			if err != nil {
				logger.Errorf("marshal detect uav fail, e: %v", err)
				return nil
			}
			logger.Infof("tracerRF detect uav: %v", uavDetect)
		}
	case handler.TracerRFEventSpectrum:
		if detect.Info == nil {
			logger.Infof("has not any spectrum")
			return nil
		}

		b, err := jsoniter.Marshal(detect.Info)
		if err != nil {
			logger.Errorf("ReportTracerRFDetectEvent marshal err:%v", err)
			return err
		}
		urdSpectrumInfo := &client.UrdSpectrumInfo{}
		if err = jsoniter.Unmarshal(b, urdSpectrumInfo); err != nil {
			logger.Errorf("ReportTracerRFDetectEvent unmarshal err:%v", err)
			return err
		}

		eventId = urdSpectrumInfo.EventId

		var (
			uavDetect  []*cloudPlatform.EventDetectUav
			dataDetect *cloudPlatform.DetectUavDesc
		)
		uavDetect = append(uavDetect, &cloudPlatform.EventDetectUav{
			SerialNum: detect.Sn,
			UrdX:      urdSpectrumInfo.X,
			UrdY:      urdSpectrumInfo.Y,
		})

		dataDetect = &cloudPlatform.DetectUavDesc{
			Body: uavDetect,
		}

		bodyData, err = proto.Marshal(dataDetect)
		if err != nil {
			logger.Errorf("marshal detect uav fail, e: %v", err)
			return nil
		}
		logger.Infof("tracerRF detect spectrum: %v", uavDetect)
	}

	EventType, SubEventType := int32(EnumEventDetect), int32(EnumSubEventDetectAppear)
	if detect.MsgType == handler.TracerRFEventDetectAppear || detect.MsgType == handler.TracerRFEventSpectrum {
		EventType = int32(EnumEventDetect)
		SubEventType = EnumSubEventDetectAppear
	} else if detect.MsgType == handler.TracerRFEventDetectDisappear {
		EventType = int32(EnumEventDetect)
		SubEventType = EnumSubEventDetectDisAppear
	}

	//给云端发送
	detectData := make([]*cloudPlatform.ReportEventData, 0)
	detectData = append(detectData, &cloudPlatform.ReportEventData{
		EventId:      eventId,
		EventType:    EventType,
		SubEventType: SubEventType,
		Sn:           detect.Sn,
		DevType:      StrDeviceTypeTracerRF,
		CreatTime:    time.Now().UnixMilli(),
		Data:         bodyData,
	})

	logger.Debug("ReportTracerRFDetectEvent detect = ", detectData)
	data := &cloudPlatform.ReportEventList{
		Body: detectData,
	}

	// encodedMessage
	encodedMessage, err := proto.Marshal(data)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return fmt.Errorf("Marshal encodedMessage error: %v", err)
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       EventReportURL,
			Sn:        c.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   c.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return err
	}
	//对消息进行封装+head+crc
	sendMessage := createPacket(encodedMessage)
	// 发送TCP消息
	if c.Conn == nil || c.IsLogin == false {
		return nil
	}
	_, err = c.Conn.Write(sendMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return err
	}
	logger.Infof("send tracerRF detect event to cloud success, data: %+v", data)
	return nil
}

// ReportSpooferStatusEvent Spoofer上下线事件上报
func (c *CloudTcpCli) ReportSpooferStatusEvent(info []byte) error {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	hb := &client.SpooferStatusInfo{}
	err := proto.Unmarshal(info, hb)
	if err != nil {
		return fmt.Errorf("report Spoofer proto Unmarshal error: %v", err)
	}

	EventType, SubEventType := int32(EnumEventDeviceStatus), int32(EnumSubEventDeviceOnLine)
	EventId := hb.GetData().GetEventId()

	var bodyData []byte
	if hb.GetData().IsOnline == 1 {
		EventType = int32(EnumEventDeviceStatus)
		SubEventType = EnumSubEventDeviceOnLine

		bodyDataPtr := &cloudPlatform.DeviceOnLineDesc{
			Longitude: float32(hb.GetData().Longititude),
			Latitude:  float32(hb.GetData().Latitude),
		}

		bodyDataBin, err := proto.Marshal(bodyDataPtr)
		if err == nil {
			bodyData = bodyDataBin
		}

	} else if hb.GetData().IsOnline == 2 {
		EventType = int32(EnumEventDeviceStatus)
		SubEventType = EnumSubEventDeviceOffLine
	} else {
		return fmt.Errorf("not support isOnline:%v", hb.Data.IsOnline)
	}

	//给云端发送
	hbData := make([]*cloudPlatform.ReportEventData, 0)
	hbData = append(hbData, &cloudPlatform.ReportEventData{
		EventId:      EventId,
		EventType:    EventType,
		SubEventType: SubEventType,
		Sn:           hb.Header.Sn,
		DevType:      StrDeviceTypeSpooofer,
		CreatTime:    time.Now().UnixMilli(),
		Data:         bodyData,
	})

	logger.Debug("ReportSpooferStatusEvent hbData = ", hbData)
	data := &cloudPlatform.ReportEventList{
		Body: hbData,
	}

	// encodedMessage
	encodedMessage, err := proto.Marshal(data)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return fmt.Errorf("Marshal encodedMessage error: %v", err)
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       EventReportURL,
			Sn:        c.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   c.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return err
	}
	//对消息进行封装+head+crc
	sendMessage := createPacket(encodedMessage)
	// 发送TCP消息
	if c.Conn == nil || c.IsLogin == false {
		return nil
	}
	_, err = c.Conn.Write(sendMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return err
	}
	logger.Infof("send spoofer status event to cloud success, message: %+v", message)
	return nil
}

// ReportSfl200StatusEvent sfl200上下线事件上报
func (c *CloudTcpCli) ReportSfl200StatusEvent(info []byte) error {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	hb := &client.Sfl200SystemStateInfo{}
	err := proto.Unmarshal(info, hb)
	if err != nil {
		return fmt.Errorf("report sfl200 proto Unmarshal error: %v", err)
	}

	eventType, subEventType := int32(EnumEventDeviceStatus), int32(EnumSubEventDeviceOnLine)
	eventId := hb.Data.GetEventId()

	var bodyData []byte
	if hb.Header.MsgType == common.Sfl200EventOnLine {
		eventType = int32(EnumEventDeviceStatus)
		subEventType = EnumSubEventDeviceOnLine

		bodyDataPtr := &cloudPlatform.DeviceOnLineDesc{
			Longitude: float32(hb.Data.GunLongitude),
			Latitude:  float32(hb.Data.GunLatitude),
		}
		bodyDataBin, err := proto.Marshal(bodyDataPtr)
		if err == nil {
			bodyData = bodyDataBin
		}

		logger.Infof("receive sfl200 online event, data: %v", bodyDataPtr)

	} else if hb.Header.MsgType == common.Sfl200EventOffLine {
		eventType = int32(EnumEventDeviceStatus)
		subEventType = EnumSubEventDeviceOffLine

		logger.Infof("receive sfl200 offline event.")
	} else {
		return fmt.Errorf("not support msgType: %v", hb.Header.MsgType)
	}

	//给云端发送
	hbData := make([]*cloudPlatform.ReportEventData, 0)
	hbData = append(hbData, &cloudPlatform.ReportEventData{
		EventId:      eventId,
		EventType:    eventType,
		SubEventType: subEventType,
		Sn:           hb.Header.Sn,
		DevType:      StrDeviceTypeSFL200,
		CreatTime:    time.Now().UnixMilli(),
		Data:         bodyData,
	})

	logger.Debug("ReportSfl200StatusEvent hbData = ", hbData)
	data := &cloudPlatform.ReportEventList{
		Body: hbData,
	}

	// encodedMessage
	encodedMessage, err := proto.Marshal(data)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return fmt.Errorf("Marshal encodedMessage error: %v", err)
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       EventReportURL,
			Sn:        c.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   c.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return err
	}
	//对消息进行封装+head+crc
	sendMessage := createPacket(encodedMessage)
	// 发送TCP消息
	if c.Conn == nil || c.IsLogin == false {
		logger.Errorf("report cloud platform conn is nil")
		return nil
	}
	_, err = c.Conn.Write(sendMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return err
	}
	logger.Infof("send sfl200 status event to cloud success, data: %+v", data)
	return nil
}

// ReportSfl200DetectEvent sfl200侦测事件上报
func (c *CloudTcpCli) ReportSfl200DetectEvent(info []byte) error {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	detect := &client.SflDetectInfo{}
	err := proto.Unmarshal(info, detect)
	if err != nil {
		return fmt.Errorf("report sfl200 proto Unmarshal error: %v", err)
	}
	logger.Debugf("start Unmarshal, data: %+v", detect.Data)

	var bodyData []byte
	eventType, subEventType := int32(EnumEventDetect), int32(EnumSubEventDetectAppear)
	eventId := detect.Data.GetEventId()

	if detect.Header.MsgType == common.Sfl200EventDetectAppear {
		eventType = int32(EnumEventDetect)
		subEventType = EnumSubEventDetectAppear
		if detect.Data == nil || len(detect.Data.List) <= 0 {
			logger.Infof("has not any uav detect")
			return nil
		}

		uavDetect := make([]*cloudPlatform.EventDetectUav, len(detect.Data.List))
		var err error
		for _, v := range detect.Data.List {
			uavDetect = append(uavDetect, &cloudPlatform.EventDetectUav{
				ProductType: v.ProductType,
				Name:        v.DroneName,
				SerialNum:   v.SerialNum,
				Longitude:   float32(v.DroneLongitude),
				Latitude:    float32(v.DroneLatitude),
				Role:        v.Role,
			})
		}

		dataDetect := &cloudPlatform.DetectUavDesc{
			Body: uavDetect,
		}

		bodyData, err = proto.Marshal(dataDetect)
		if err != nil {
			logger.Errorf("marshal detect uav fail, e: %v", err)
			return nil
		}
		logger.Debugf("sfl200 detect uav: %v", uavDetect)
	} else if detect.Header.MsgType == common.Sfl200EventDetectDisAppear {
		eventType = int32(EnumEventDetect)
		subEventType = EnumSubEventDetectDisAppear
		logger.Debugf("receive sfl200 detect uav disappear event.")
	}

	//给云端发送
	detectData := make([]*cloudPlatform.ReportEventData, 0)
	detectData = append(detectData, &cloudPlatform.ReportEventData{
		EventId:      eventId,
		EventType:    eventType,
		SubEventType: subEventType,
		Sn:           detect.Header.Sn,
		DevType:      StrDeviceTypeSFL200,
		CreatTime:    time.Now().UnixMilli(),
		Data:         bodyData,
	})

	logger.Debug("ReportSfl200DetectEvent detect = ", detectData)
	data := &cloudPlatform.ReportEventList{
		Body: detectData,
	}

	// encodedMessage
	encodedMessage, err := proto.Marshal(data)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return fmt.Errorf("Marshal encodedMessage error: %v", err)
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       EventReportURL,
			Sn:        c.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   c.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return err
	}
	//对消息进行封装+head+crc
	sendMessage := createPacket(encodedMessage)
	// 发送TCP消息
	if c.Conn == nil || c.IsLogin == false {
		return nil
	}
	_, err = c.Conn.Write(sendMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return err
	}
	logger.Infof("send sfl200 detect event to cloud success, data: %+v", data)
	return nil
}

// ReportSfl200AgxDetectEvent sfl200上报agx侦测无人机事件
func (c *CloudTcpCli) ReportSfl200AgxDetectEvent(info []byte) error {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()

	detect := &client.AgxDetectInfo{}
	err := proto.Unmarshal(info, detect)
	if err != nil {
		return fmt.Errorf("report sfl200 agx proto Unmarshal error: %v", err)
	}

	eventType, subEventType := int32(EnumEventDetect), int32(EnumSubEventDetectAppear)
	eventId := detect.GetEventId()

	var bodyData []byte
	if detect.Header.MsgType == common.Sfl200AgxDetectAppear {
		eventType = int32(EnumEventDetect)
		subEventType = EnumSubEventDetectAppear

		bodyDataPtr := &cloudPlatform.DetectUavDesc{
			Body: make([]*cloudPlatform.EventDetectUav, 0),
		}

		for _, v := range detect.Data {
			if v == nil {
				continue
			}
			//if v.Classification == 0x04 {
			//	logger.Infof("is bird detect type, modify: %x to 0x00", v.Classification)
			//	v.Classification = 0x00
			//}
			bodyDataPtr.Body = append(bodyDataPtr.Body, &cloudPlatform.EventDetectUav{
				SerialNum:      v.SerialNum,
				Classification: v.Classification,
				Name:           v.DroneName,
				Longitude:      float32(v.Longitude),
				Latitude:       float32(v.Latitude),
				X:              float32(v.X),
				Y:              float32(v.Y),
				Z:              float32(v.Z),
				Role:           v.Role,
			})
		}
		logger.Debugf("detect uav data: %+v", bodyDataPtr)

		bodyDataBin, err := proto.Marshal(bodyDataPtr)
		if err == nil {
			bodyData = bodyDataBin
		} else {
			logger.Errorf("marshal detect uavs fail, err: %v", err)
			return fmt.Errorf("marshal detect uavs fail, err: %v", err)
		}
		videostore.VsSingleton.GoSaveToLocalVideoAndPushToS3(eventId, detect.Header.Sn)

	} else if detect.Header.MsgType == common.Sfl200AgxDetectDisappear {
		eventType = int32(EnumEventDetect)
		subEventType = EnumSubEventDetectDisAppear
		logger.Debugf("sfl200 agx detect disappear event.")
		videostore.VsSingleton.GoCancelCaptureVideo(eventId)
	} else {
		logger.Debugf("sfl200 not support msg type: %v", detect.Header.MsgType)
		return nil
	}

	//给云端发送
	hbData := make([]*cloudPlatform.ReportEventData, 0)
	hbData = append(hbData, &cloudPlatform.ReportEventData{
		EventId:      eventId,
		EventType:    eventType,
		SubEventType: subEventType,
		Sn:           detect.Header.Sn,
		DevType:      StrDeviceTypeSFL200,
		CreatTime:    time.Now().UnixMilli(),
		Data:         bodyData,
	})

	logger.Debug("ReportSfl200AgxDetectEvent hbData = ", hbData)
	data := &cloudPlatform.ReportEventList{
		Body: hbData,
	}

	// encodedMessage
	encodedMessage, err := proto.Marshal(data)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return fmt.Errorf("Marshal encodedMessage error: %v", err)
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       EventReportURL,
			Sn:        c.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   c.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return err
	}
	//对消息进行封装+head+crc
	sendMessage := createPacket(encodedMessage)
	// 发送TCP消息
	if c.Conn == nil || c.IsLogin == false {
		logger.Infof("report connect is nil or is not login")
		return nil
	}
	_, err = c.Conn.Write(sendMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return err
	}

	logger.Infof("report sfl200 agx detect report, data: %+v", data)
	return nil
}

// ReportSfl200HitOverEvent sfl200打击事件上报
func (c *CloudTcpCli) ReportSfl200HitOverEvent(info []byte) error {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	hitStatus := &client.SflHitStateInfo{}
	err := proto.Unmarshal(info, hitStatus)
	if err != nil {
		return fmt.Errorf("report sfl200 SflHitStateInfo Unmarshal error: %v", err)
	}
	logger.Debugf("start Unmarshal, SFL hit state: %+v", hitStatus)

	sflHitStatusEventItems := make([]*cloudPlatform.SflHitStatusEventItem, 0)
	sflHitStatusEventItems = append(sflHitStatusEventItems, &cloudPlatform.SflHitStatusEventItem{
		SerialNum:      hitStatus.Data.SerialNum,
		DroneName:      hitStatus.Data.DroneName,
		DroneLongitude: hitStatus.Data.DroneLongitude,
		DroneLatitude:  hitStatus.Data.DroneLatitude,
		DroneHeight:    hitStatus.Data.DroneHeight,
		DroneYawAngle:  hitStatus.Data.DroneYawAngle,
	})

	sflHitStatusEventDesc := &cloudPlatform.SflHitStatusEventDesc{
		Body: sflHitStatusEventItems,
	}
	bodyData, err := proto.Marshal(sflHitStatusEventDesc)
	if err != nil {
		logger.Errorf("marshal hit status data fail, err: %v", err)
	}

	eventType, subEventType := int32(EnumEventHit), int32(EnumSubEventHitSucc)
	eventId := hitStatus.Data.GetEventId()
	if hitStatus.Header.MsgType == common.Sfl200EventHitSucc {
		eventType = int32(EnumEventHit)
		subEventType = EnumSubEventHitSucc
		logger.Debug("receive sfl200 hit succ event.")

	} else if hitStatus.Header.MsgType == common.Sfl200EventHitFail {
		eventType = int32(EnumEventHit)
		subEventType = EnumSubEventHitFail
		logger.Debug("receive sfl200 hit uav fail event.")
	}

	//给云端发送
	hitStatusCloudData := make([]*cloudPlatform.ReportEventData, 0)
	hitStatusCloudData = append(hitStatusCloudData, &cloudPlatform.ReportEventData{
		EventId:      eventId,
		EventType:    eventType,
		SubEventType: subEventType,
		Sn:           hitStatus.Header.Sn,
		DevType:      StrDeviceTypeSFL200,
		CreatTime:    time.Now().UnixMilli(),
		Data:         bodyData,
	})

	logger.Debug("ReportSfl200HitOverEvent hit = ", hitStatusCloudData)
	data := &cloudPlatform.ReportEventList{
		Body: hitStatusCloudData,
	}

	// encodedMessage
	encodedMessage, err := proto.Marshal(data)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return fmt.Errorf("Marshal encodedMessage error: %v", err)
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       EventReportURL,
			Sn:        c.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   c.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return err
	}
	//对消息进行封装+head+crc
	sendMessage := createPacket(encodedMessage)
	// 发送TCP消息
	if c.Conn == nil || c.IsLogin == false {
		return nil
	}
	_, err = c.Conn.Write(sendMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return err
	}
	logger.Infof("send sfl200 hit uav event to cloud success, data: %+v", data)
	return nil
}

// ReportSfl200AgxPtzLockUavEvent sfl200上报agx ptz锁定事件
func (c *CloudTcpCli) ReportSfl200AgxPtzLockUavEvent(info []byte) error {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()

	lockUav := &client.AgxPtzLockInfo{}
	err := proto.Unmarshal(info, lockUav)
	if err != nil {
		return fmt.Errorf("report sfl200 Unmarshal AgxPtzLockInfo error: %v", err)
	}

	var bodyData []byte
	eventType, subEventType := int32(EnumEventPtzLock), int32(EnumSubEventPtzLockSucc)
	eventId := lockUav.GetEventId()

	if lockUav.Header.MsgType == common.Sfl200AgxEventPtzLockUavSucc {
		eventType, subEventType = int32(EnumEventPtzLock), EnumSubEventPtzLockSucc

		lockUavs := make([]*cloudPlatform.EventPtzLockUav, 0)
		lockUavBody := &cloudPlatform.EventPtzLockUavDesc{}

		for _, uavItems := range lockUav.Data {
			if uavItems == nil {
				continue
			}
			lockUavs = append(lockUavs, &cloudPlatform.EventPtzLockUav{
				SerialNum: uavItems.SerialNum,
				Name:      uavItems.DroneName,
				Longitude: uavItems.Longitude,
				Latitude:  uavItems.Latitude,
				LockTime:  uavItems.LockedTime,
			})
		}
		logger.Infof("ptz lock uav succ, uav list: %v", lockUavs)

		lockUavBody.Body = lockUavs
		bodyDataBin, err := proto.Marshal(lockUavBody)
		if err == nil {
			bodyData = bodyDataBin
		} else {
			logger.Infof("marshal ptz lock uavs fail, err: %+v", err)
			return fmt.Errorf("marshal detect uavs fail, err: %v", err)
		}

	} else if lockUav.Header.MsgType == common.Sfl200AgxEventPtzLockUavFail {
		eventType, subEventType = int32(EnumEventPtzLock), EnumSubEventPtzLockFail
		logger.Debug("sfl200 agx ptz lock fail")
	} else {
		logger.Errorf("sfl200 not support msg type, %+v", lockUav.Header.MsgType)
		return nil
	}

	//给云端发送
	reportEventData := make([]*cloudPlatform.ReportEventData, 0)
	reportEventData = append(reportEventData, &cloudPlatform.ReportEventData{
		EventId:      eventId,
		EventType:    eventType,
		SubEventType: subEventType,
		Sn:           lockUav.Header.Sn,
		DevType:      StrDeviceTypeSFL200,
		CreatTime:    time.Now().UnixMilli(),
		Data:         bodyData,
	})

	logger.Debug("ReportSfl200AgxPtzLockUavEvent ptzLock = ", reportEventData)
	data := &cloudPlatform.ReportEventList{
		Body: reportEventData,
	}

	// encodedMessage
	encodedMessage, err := proto.Marshal(data)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return fmt.Errorf("Marshal encodedMessage error: %v", err)
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       EventReportURL,
			Sn:        c.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   c.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return err
	}
	//对消息进行封装+head+crc
	sendMessage := createPacket(encodedMessage)
	// 发送TCP消息
	if c.Conn == nil || c.IsLogin == false {
		logger.Infof("report connect is nil or is not login")
		return nil
	}
	_, err = c.Conn.Write(sendMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return err
	}
	logger.Infof("send sfl200 agx ptz lock uav event to cloud success, data: %+v", data)
	return nil
}

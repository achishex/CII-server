package uploadcloud

import (
	"fmt"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	jsoniter "github.com/json-iterator/go"
	broker2 "go-micro.dev/v4/broker"
	"google.golang.org/protobuf/proto"

	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/cloudPlatform"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
)

// ReportFpv 数据上报
func (c *CloudTcpCli) ReportNSF400() {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	_, _ = mq.NSF4000Broker.Subscribe(mq.NSF4000Topic, func(event broker2.Event) error {
		logger.Debug("event.Message().Body = ", event.Message().Body)

		// if len(c.Token) == 0 {
		// 	return nil
		// }
		entity := common.EquipmentMessageBoxEntity{}
		err := jsoniter.Unmarshal(event.Message().Body, &entity)

		if err != nil {
			return fmt.Errorf("report Radar Posture Unmarshal error: %v", err)
		}
		infoJSON, _ := jsoniter.Marshal(entity.MsgType)
		var MsgType int
		logger.Debug("start Unmarshal")
		err = jsoniter.Unmarshal(infoJSON, &MsgType)
		if err != nil {
			if EnableLogInvildJSON {
				logger.Debug("report sfl heartb Unmarshal info error: %v", err)
			}
			return fmt.Errorf("report Radar Posture  Unmarshal info error: %v", err)
		}
		sn := entity.Sn
		info := entity.Info
		msgtype := entity.MsgType

		return c.ReportNSF400DeviceStatus(sn, info, msgtype)

	})
}

// ReportNSF400LLH 上报车载设备状态
func (c *CloudTcpCli) ReportNSF400LLH() {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	_, _ = mq.NSF4000BrokerLLH.Subscribe(mq.NSF4000TopicLLH, func(event broker2.Event) error {
		logger.Debug("nsf400Pub event.Message().Body = ", event.Message().Body)
		// if len(c.Token) == 0 {
		// 	return nil
		// }
		entity := common.EquipmentMessageBoxEntity{}
		err := jsoniter.Unmarshal(event.Message().Body, &entity)

		if err != nil {
			return fmt.Errorf("report Radar Posture Unmarshal error: %v", err)
		}
		infoJSON, _ := jsoniter.Marshal(entity.MsgType)
		var MsgType int
		logger.Debug("start Unmarshal")
		err = jsoniter.Unmarshal(infoJSON, &MsgType)
		if err != nil {
			if EnableLogInvildJSON {
				logger.Debug("report sfl heartb Unmarshal info error: %v", err)
			}
			return fmt.Errorf("report Radar Posture  Unmarshal info error: %v", err)
		}
		sn := entity.Sn
		info := entity.Info
		msgtype := entity.MsgType

		return c.ReportNSF400DeviceStatus(sn, info, msgtype)

	})
}

// ReportNSF400DeviceStatus 上报车载设备状态
func (c *CloudTcpCli) ReportNSF400DeviceStatus(sn string, info interface{}, msgtype int) error {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()

	infoJSON, _ := jsoniter.Marshal(info)
	hb := handler.NSF4000Msg{}
	logger.Debug("start Unmarshal")
	err := jsoniter.Unmarshal(infoJSON, &hb)
	logger.Debug("hb = ", hb)
	if err != nil {
		if EnableLogInvildJSON {
			logger.Debug("report sfl heartb Unmarshal info error: %v", err)
		}
		return fmt.Errorf("report Radar Posture  Unmarshal info error: %v", err)
	}
	//给云端发送
	hbData := make([]*cloudPlatform.Nsf4000HeartData, 0)
	hbData = append(hbData, &cloudPlatform.Nsf4000HeartData{
		Sn:             sn,
		Online:         int32(hb.IsOnline),
		WorkStatus:     int32(hb.IsWorking),
		GpsStatus:      int32(hb.GpsStatus),
		Ephemeris:      int32(hb.Ephemeris),
		TimeSync:       int32(hb.TimeSync),
		Longitude:      hb.Longititude,
		Latitude:       hb.Latitude,
		Height:         hb.Height,
		CreateTime:     time.Now().UnixMilli(),
		MsgType:        int32(msgtype),
		Enable:         hb.Enable,
		WorkMode:       hb.WorkMode,
		Radius:         hb.Radius,
		Angle:          hb.Angle,
		OpsTime:        hb.OpsTime,
		CurrentBattery: hb.CurrentBattery,
		SubDevType:     hb.SubDevType,
	})
	logger.Debug("hbData = ", hbData)
	data := &cloudPlatform.Nsf4000HeartList{
		Body: hbData,
	}

	// encodedMessage
	encodedMessage, err := proto.Marshal(data)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return fmt.Errorf("Marshal encodedMessage error: %v", err)
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       NsfStatusURL,
			Sn:        c.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   c.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return err
	}
	//对消息进行封装+head+crc
	sendMessage := createPacket(encodedMessage)
	// 发送TCP消息
	if c.Conn == nil || c.IsLogin == false {
		return nil
	}
	_, err = c.Conn.Write(sendMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return err
	}

	return nil
}

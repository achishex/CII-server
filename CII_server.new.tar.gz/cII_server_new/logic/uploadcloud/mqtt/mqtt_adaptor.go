package mqtt

import (
	"crypto/rand"
	"crypto/tls"
	"crypto/x509"
	"fmt"
	"math/big"
	"os"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	paho "github.com/eclipse/paho.mqtt.golang"
)

// ErrNilClient is returned when a client action can't be taken because the struct has no client
var ErrNilClient = fmt.Errorf("no MQTT client available")

// Message is a message received from the broker.
type Message paho.Message

// Adaptor is the C2 Adaptor for MQTT
type Adaptor struct {
	name          string
	Host          string
	clientID      string
	username      string
	password      string
	useSSL        bool
	serverCert    string
	clientCert    string
	clientKey     string
	autoReconnect bool
	cleanSession  bool
	Client        paho.Client
	qos           int
	Opts          *paho.ClientOptions
}

// Rand returns a positive random int up to max
func Rand(max int) int {
	i, _ := rand.Int(rand.Reader, big.NewInt(int64(max)))
	return int(i.Int64())
}
func defaultName(name string) string {
	return fmt.Sprintf("%s-%X", name, Rand(int(^uint(0)>>1)))
}

// NewAdaptor creates a new mqtt adaptor with specified host and client id
func NewAdaptor(host string, clientID string) *Adaptor {
	return &Adaptor{
		name:          defaultName("MQTT"),
		Host:          host,
		autoReconnect: false,
		cleanSession:  true,
		useSSL:        false,
		clientID:      clientID,
	}
}

// NewAdaptorWithAuth creates a new mqtt adaptor with specified host, client id, username, and password.
func NewAdaptorWithAuth(host, clientID, username, password string) *Adaptor {
	return &Adaptor{
		name:          "MQTT",
		Host:          host,
		autoReconnect: true,
		cleanSession:  true,
		useSSL:        false,
		clientID:      clientID,
		username:      username,
		password:      password,
	}
}

// Name returns the MQTT Adaptor's name
func (a *Adaptor) Name() string { return a.name }

// SetName sets the MQTT Adaptor's name
func (a *Adaptor) SetName(n string) { a.name = n }

// Port returns the Host name
func (a *Adaptor) Port() string { return a.Host }

// AutoReconnect returns the MQTT AutoReconnect setting
func (a *Adaptor) AutoReconnect() bool { return a.autoReconnect }

// SetAutoReconnect sets the MQTT AutoReconnect setting
func (a *Adaptor) SetAutoReconnect(val bool) { a.autoReconnect = val }

// CleanSession returns the MQTT CleanSession setting
func (a *Adaptor) CleanSession() bool { return a.cleanSession }

// SetCleanSession sets the MQTT CleanSession setting. Should be false if reconnect is enabled. Otherwise all subscriptions will be lost
func (a *Adaptor) SetCleanSession(val bool) { a.cleanSession = val }

// UseSSL returns the MQTT server SSL preference
func (a *Adaptor) UseSSL() bool { return a.useSSL }

// SetUseSSL sets the MQTT server SSL preference
func (a *Adaptor) SetUseSSL(val bool) { a.useSSL = val }

// ServerCert returns the MQTT server SSL cert file
func (a *Adaptor) ServerCert() string { return a.serverCert }

// SetQoS sets the QoS value passed into the MTT client on Publish/Subscribe events
func (a *Adaptor) SetQoS(qos int) { a.qos = qos }

// SetServerCert sets the MQTT server SSL cert file
func (a *Adaptor) SetServerCert(val string) { a.serverCert = val }

// ClientCert returns the MQTT client SSL cert file
func (a *Adaptor) ClientCert() string { return a.clientCert }

// SetClientCert sets the MQTT client SSL cert file
func (a *Adaptor) SetClientCert(val string) { a.clientCert = val }

// ClientKey returns the MQTT client SSL key file
func (a *Adaptor) ClientKey() string { return a.clientKey }

// SetClientKey sets the MQTT client SSL key file
func (a *Adaptor) SetClientKey(val string) { a.clientKey = val }

// Connect returns true if connection to mqtt is established
func (a *Adaptor) Connect() error {
	a.Client = paho.NewClient(a.Opts)
	if token := a.Client.Connect(); token.Wait() && token.Error() != nil {
		return token.Error()
	}

	return nil
}

// Disconnect returns true if connection to mqtt is closed
func (a *Adaptor) Disconnect() error {
	if a.Client != nil {
		a.Client.Disconnect(500)
	}
	a.Client = nil
	return nil
}

// Finalize returns true if connection to mqtt is finalized successfully
func (a *Adaptor) Finalize() error {
	return a.Disconnect()
}

// Publish a message under a specific topic
func (a *Adaptor) Publish(topic string, message []byte) bool {
	_, err := a.PublishWithQOS(topic, a.qos, message)
	return err == nil
}

// PublishAndRetain publishes a message under a specific topic with retain flag
func (a *Adaptor) PublishAndRetain(topic string, message []byte) bool {
	if a.Client == nil {
		return false
	}

	a.Client.Publish(topic, byte(a.qos), true, message)
	return true
}

// PublishWithQOS allows per-publish QOS values to be set and returns a paho.Token
func (a *Adaptor) PublishWithQOS(topic string, qos int, message []byte) (paho.Token, error) {
	if a.Client == nil {
		return nil, ErrNilClient
	}

	token := a.Client.Publish(topic, byte(qos), false, message)
	return token, nil
}

// OnWithQOS allows per-subscribe QOS values to be set and returns a paho.Token
func (a *Adaptor) OnWithQOS(event string, qos int, f func(msg Message)) (paho.Token, error) {
	if a.Client == nil {
		return nil, ErrNilClient
	}

	token := a.Client.Subscribe(event, byte(qos), func(client paho.Client, msg paho.Message) {
		f(msg)
	})

	return token, nil
}

// On subscribes to a topic, and then calls the message handler function when data is received
func (a *Adaptor) On(event string, f func(msg Message)) bool {
	_, err := a.OnWithQOS(event, a.qos, f)
	return err == nil
}

// DoWithQOS allows per-subscribe QOS values to be set and returns a paho.Token
func (a *Adaptor) DoWithQOS(event string, qos int, f func(msg Message) []byte) (paho.Token, error) {
	if a.Client == nil {
		return nil, ErrNilClient
	}
	token := a.Client.Subscribe(event, byte(qos), func(client paho.Client, msg paho.Message) {
		replayMsg := f(msg)
		pubTopic := fmt.Sprintf("%s_replay", event)
		a.Publish(pubTopic, replayMsg)
	})

	return token, nil
}

// ,event string, f func(msg Message) []byte
// Do subscribes to a topic, and then calls the message handler function when data is received
func (a *Adaptor) Do(cr []DoRoute) bool {
	// _, err := a.DoWithQOS(event, a.qos, f)
	// return err == nil
	// logger.Debug("event2 = ", event)
	a.Opts.SetOnConnectHandler(func(c paho.Client) {

		for _, r := range cr {
			event := r.Topic
			f := r.Handler
			logger.Debug("event  =  ", event)
			a.Client.Subscribe(event, byte(a.qos), func(client paho.Client, msg paho.Message) {
				replayMsg, version := f(msg)
				var pubTopic string
				if version == 1 {
					pubTopic = fmt.Sprintf("%s_replay", event)
					a.Publish(pubTopic, replayMsg)
				} else if version == 2 {
					pubTopic = fmt.Sprintf("%s_reply", event)
					a.Publish(pubTopic, replayMsg)
				} else {
					//didn't need reply
				}

			})
		}

	})
	return true
}

func (a *Adaptor) CreateClientOptions() *paho.ClientOptions {
	opts := paho.NewClientOptions()
	opts.AddBroker(a.Host)
	opts.SetClientID(a.clientID)
	if a.username != "" && a.password != "" {
		opts.SetPassword(a.password)
		opts.SetUsername(a.username)
	}
	opts.AutoReconnect = a.autoReconnect
	opts.CleanSession = a.cleanSession
	opts.KeepAlive = 60
	if a.UseSSL() {
		opts.SetTLSConfig(a.newTLSConfig())
	}
	a.Opts = opts
	return opts
}

// newTLSConfig sets the TLS config in the case that we are using
// an MQTT broker with TLS
func (a *Adaptor) newTLSConfig() *tls.Config {
	// Import server certificate
	var certpool *x509.CertPool
	if len(a.ServerCert()) > 0 {
		certpool = x509.NewCertPool()
		pemCerts, err := os.ReadFile(a.ServerCert())
		if err == nil {
			certpool.AppendCertsFromPEM(pemCerts)
		}
	}

	// Import client certificate/key pair
	var certs []tls.Certificate
	if len(a.ClientCert()) > 0 && len(a.ClientKey()) > 0 {
		cert, err := tls.LoadX509KeyPair(a.ClientCert(), a.ClientKey())
		if err != nil {
			// TODO: proper error handling
			panic(err)
		}
		certs = append(certs, cert)
	}

	// Create tls.Config with desired tls properties
	return &tls.Config{
		// RootCAs = certs used to verify server cert.
		RootCAs: certpool,
		// ClientAuth = whether to request cert from server.
		// Since the server is set up for SSL, this happens
		// anyways.
		ClientAuth: tls.NoClientCert,
		// ClientCAs = certs used to validate client cert.
		ClientCAs: nil,
		// InsecureSkipVerify = verify that cert contents
		// match server. IP matches what is in cert etc.
		InsecureSkipVerify: false,
		// Certificates = list of certs client sends to server.
		Certificates: certs,
		// MinVersion contains the minimum TLS version that is acceptable.
		// TLS 1.2 is currently used as the minimum when acting as a client.
		MinVersion: tls.VersionTLS12,
	}
}

// DoRoute Topic: sub topic, handler: do logic fun
type DoRoute struct {
	Topic   string
	Handler func(msg Message) ([]byte, int32)
}

// AddSubHandlers 注册订阅路由
func (a *Adaptor) AddSubHandlers(c []DoRoute) {
	a.CreateClientOptions()
	// for _, r := range c {
	// a.Do(r.Topic, r.Handler)
	// }
	a.Do(c)
}

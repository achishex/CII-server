package uploadcloud

import (
	"fmt"
	"math"
	"sync"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	broker2 "go-micro.dev/v4/broker"
	"google.golang.org/protobuf/proto"

	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/logic/uploadcloud/down"
	videostore "adasgitlab.autel.com/tools/cuav_server/logic/uploadcloud/videoStore"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/proto/cloudPlatform"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
)

var (
	gsfl200lon = 113.998
	gsfl200la  = 22.597
)

// ReportSfl 数据上报
func (c *CloudTcpCli) ReportSfl200() {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	_, _ = mq.RadarPostureBroker.Subscribe(mq.Sfl200Topic, func(event broker2.Event) error {
		entity := client.ClientReport{}
		err := proto.Unmarshal(event.Message().Body, &entity)
		if err != nil {
			return fmt.Errorf("report sfl proto Unmarshal error: %v", err)
		}
		MsgType := entity.MsgType
		info := entity.Data
		logger.Debug("MsgType = ", MsgType)
		switch MsgType {
		case common.ClientMsgIDSfl200AgxDetectData:
			return c.Sfl200AgxDetect(info)
		case common.ClientMsgIDSfl200PTZData:
			return c.Sfl200PTZ(info)
		case common.ClientMsgIDSfl200SflDetectData:
			return c.Sfl200SflDetect(info)
		case common.ClientMsgIDSfl200SystemStateData:
			return c.Sfl200SystemState(info)
		default:
			err := fmt.Errorf("unrecognized msg type: %v", MsgType)
			logger.Error(err)
			return err
		}
	})
}

// ReportSflHeartBeat 上报哨兵塔sfl心跳
func (c *CloudTcpCli) Sfl200AgxDetect(info []byte) error {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	hb := &client.Sfl200AgxDetectInfo{}
	err := proto.Unmarshal(info, hb)
	if err != nil {
		return fmt.Errorf("report sfl proto Unmarshal error: %v", err)
	}
	// hb := mavlink.SflHeartReport{}
	//logger.Debug("start Unmarshal,hb = ", hb)
	//logger.Debug("hb.Data  = ", hb.Data)
	if len(hb.Data) == 0 {
		logger.Debug("no data available	", hb)
		return nil
	}

	// mu.Lock()
	// defer mu.Unlock()

	//给云端发送
	hbData := make([]*cloudPlatform.Sfl200AgxUavData, 0)
	for _, data := range hb.Data {
		var url string
		var downloadUrl string
		var bucketName string
		/**/
		logger.Debug("data Classification = ", data.Classification)
		// if data.Classification == 0x01 || data.Classification == 0x02 ||
		// 	data.Classification == 0x03 || data.Classification == 0x04 || data.Classification == 0x05 {
		KID := fmt.Sprintf("%s_%d_%d", hb.Header.Sn, data.Classification, int32(data.Id))

		s3PrePath := fmt.Sprintf("/image/%s/%s/", c.C2Sn, hb.Header.Sn)
		logger.Debug("s3PrePath = ", s3PrePath)
		logger.Debug("KID = ", KID)
		uavPhoto := videostore.UavPhotoMsg{
			DevSn:          hb.Header.Sn,
			Classification: int32(data.Classification),
			ObjID:          int32(data.Id),
			S3PrePath:      s3PrePath,
		}
		if val, ok := videostore.GPhotoMap.Get(KID); ok {
			if val.UploadStatus == videostore.Uploading {
				logger.Debug("uploading photo, KID = ", KID)
			} else if time.Now().UnixMilli()-val.TimeStamp > 5*1000 {
				logger.Debug("photo timeout exceeded, KID = ", KID)
				// delete(videostore.GPhotoMap, KID)
				videostore.VsSingleton.GoSaveToLocalPhotoAndPushToS3(uavPhoto)
				url = val.URL
				downloadUrl = val.DownloadUrl
				bucketName = val.Bucket
			} else {
				url = val.URL
				downloadUrl = val.DownloadUrl
				bucketName = val.Bucket
				logger.Debugf("getting photo s3 msg ok,url = %s,bucket = %s,downloadUrl = %s", url, bucketName, downloadUrl)
			}
		} else {
			logger.Debug("new boject,start gen photo URL")
			videostore.VsSingleton.GoSaveToLocalPhotoAndPushToS3(uavPhoto)
		}
		if url == "" {
			logger.Debug("not upload photo url,due to photo is uploading")
		}

		hbData = append(hbData, &cloudPlatform.Sfl200AgxUavData{
			Id:                 data.Id,
			DroneName:          data.DroneName,
			SerialNum:          data.Serialnum,
			Source:             data.Source,
			StateType:          data.StateType,
			ExistingProb:       data.ExistingProb,
			LifeTime:           data.LifeTime,
			ForcastTime:        data.ForcastTime,
			Classification:     data.Classification,
			ClassificationProb: data.ClassificationProb,
			GeoValid:           data.GeoValid,
			Longitude:          data.Longitude,
			Latitude:           data.Latitude,
			Altitude:           data.Altitude,
			Height:             data.Height,
			OrientationAngle:   data.OrientationAngle,
			AbsoluteSpeed:      data.AbsoluteSpeed,
			VerticalSpeed:      data.VerticalSpeed,
			MotionType:         data.MotionType,
			HomeLongitude:      data.HomeLongitude,
			HomeLatitude:       data.HomeLatitude,
			PilotLongitude:     data.PilotLongitude,
			PilotLatitude:      data.PilotLatitude,
			PilotAltitude:      data.PilotAltitude,
			Frequency:          data.Frequency,
			LoadLevel:          data.LoadLevel,
			DangerLevel:        data.DangerLevel,
			Priority:           data.Priority,
			TargetRange:        data.TargetRange,
			TargetAzimuth:      data.TargetAzimuth,
			TargetElevation:    data.TargetElevation,
			TargetArrivalTime:  data.TargetArrivalTime,
			Role:               data.Role,
			Sn:                 hb.Header.Sn,
			CreateTime:         time.Now().UnixMilli(),
			PhotoURL:           url,
			PhotoBucket:        bucketName,
			DownloadPhotoURL:   downloadUrl,
			EventID:            hb.EventID,
		})
	}

	logger.Debug("hbData = ", hbData)
	data := &cloudPlatform.Sfl200AgxUavList{
		Body: hbData,
	}

	// encodedMessage
	encodedMessage, err := proto.Marshal(data)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return fmt.Errorf("marshal encodedMessage error: %v", err)
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       Sfl200AgxUavUrl,
			Sn:        c.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   c.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return err
	}
	//对消息进行封装+head+crc
	sendMessage := createPacket(encodedMessage)
	// 发送TCP消息
	if c.Conn == nil || c.IsLogin == false {
		return nil
	}
	_, err = c.Conn.Write(sendMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return err
	}

	return nil
}

// ReportSflDetection sfl 侦测无人机信息
func (c *CloudTcpCli) Sfl200PTZ(info []byte) error {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	rcvMsg := client.Sfl200PTZDataInfo{}
	err := proto.Unmarshal(info, &rcvMsg)
	if err != nil {
		logger.Error("Protobuf 解码失败:", err)
		return err
	}
	list := rcvMsg.Data.PtzData
	//logger.Debug("list = > ", list)
	if len(list) == 0 {
		logger.Debug("no data available	", list)
		return nil
	}
	//给云端发送侦测到的无人机小组
	dData := make([]*cloudPlatform.SFl200PtZTrackTargetData, 0)
	for _, d := range list {
		dData = append(dData, &cloudPlatform.SFl200PtZTrackTargetData{
			ObjId:          rcvMsg.Data.TargetId,
			Classification: uint32(d.Classification),
			RectX:          d.RectX,
			RectY:          d.RectY,
			RectW:          d.RectW,
			RectH:          d.RectH,
			RectXv:         (d.RectXV),
			RectYv:         (d.RectYV),
			ClassifyProb:   (d.ClassfyProb),
			Type:           d.ClassType,
			TypeProb:       (d.TypeProb),
			LoadLevel:      d.LoadLever,
			DangerLevel:    d.DanagerLever,
			Azimuth:        (d.Azimuth),
			Elevation:      (d.Elevation),
			Range:          (d.Range),
			MotionType:     d.MotionType,
			BTracked:       d.BTracked,
			Sn:             rcvMsg.Header.Sn,
			CreateTime:     time.Now().UnixMilli(),
		})
	}

	Message := &cloudPlatform.SFl200PtZTrackTargetList{
		Body: dData,
	}

	logger.Debug("<----->dData = ", dData)
	// encodedMessage
	encodedMessage, err := proto.Marshal(Message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return fmt.Errorf("marshal encodedMessage error: %v", err)
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       Sfl200PtzUavUrl,
			Sn:        c.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   c.LoginId,
		},
		Data: encodedMessage,
	}
	//logger.Debug("<----->message = ", message)
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	//logger.Debug("encodedMessage = ->", encodedMessage)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return err
	}
	//对消息进行封装+head+crc
	encodedMessage = createPacket(encodedMessage)
	// 发送TCP消息
	if c.Conn == nil || !c.IsLogin {
		return nil
	}

	_, err = c.Conn.Write(encodedMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return err
	}

	return nil
}

// ReportSflSflHit sfl 侦测无人机信息
func (c *CloudTcpCli) Sfl200SflDetect(info []byte) error {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()

	report := client.Sfl200SflDetectInfo{}
	err := proto.Unmarshal(info, &report)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return fmt.Errorf("unmarshal encodedMessage error: %v", err)
	}
	list := report.Data.SflDetectData

	//给云端发送侦测到的无人机小组
	dData := make([]*cloudPlatform.Sfl200DetectData, 0)
	for _, d := range list {
		//logger.Debug("d.SerialNum  = ", d.SerialNum)
		dData = append(dData, &cloudPlatform.Sfl200DetectData{
			Sn:                 report.Header.Sn,
			ProductType:        (d.ProductType),
			DroneName:          d.DroneName,
			SerialNum:          d.SerialNum,
			DroneLongitude:     (d.DroneLongitude),
			DroneLatitude:      (d.DroneLatitude),
			DroneHeight:        (d.DroneHeight),
			DroneYawAngle:      (d.DroneYawAngle),
			DroneSpeed:         (d.DroneSpeed),
			DroneVerticalSpeed: (d.DroneVerticalSpeed),
			SpeedDirection:     (d.SpeedDirection),
			DroneSailLongitude: (d.DroneSailLongitude),
			DroneSailLatitude:  (d.DroneSailLatitude),
			PilotLongitude:     (d.PilotLongitude),
			PilotLatitude:      (d.PilotLatitude),
			DroneHorizon:       (d.DroneHorizon),
			DronePitch:         (d.DronePitch),
			UFreq:              (d.UFreq),
			UDistance:          (d.UDistance),
			UDangerLevels:      (d.UDangerLevels),
			UZc:                (d.UZC),
			UDirStatus:         (d.UDirStatus),
			UNumber:            d.UNumber,
			CreateTime:         time.Now().UnixMilli(),
			GpsClocks:          d.GpsClocks,
			TimeStampRid:       d.TimeStampRid,
			IdType:             d.IdType,
			WifiMac:            d.WifiMac,
		})
	}

	logger.Debug("dData  = ", dData)
	Message := &cloudPlatform.Sfl200DetectList{
		Body: dData,
	}

	// encodedMessage
	encodedMessage, err := proto.Marshal(Message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return fmt.Errorf("marshal encodedMessage error: %v", err)
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       Sfl200DetectUrl,
			Sn:        c.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   c.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return err
	}
	//对消息进行封装+head+crc
	encodedMessage = createPacket(encodedMessage)
	// 发送TCP消息
	if c.Conn == nil || !c.IsLogin {
		return nil
	}
	_, err = c.Conn.Write(encodedMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		return err
	}

	return nil
}

var sfl200ChildMap sync.Map

func FindCachesfl200ChildMap(sn string) string {

	if dev, ok := sfl200ChildMap.Load(sn); ok {
		return dev.(string)
	}
	return ""
}

func GetDevStatus(devType int32, sn string) (string, string) {
	var devTypStr string
	switch common.DeviceType(devType) {
	case 1:
		devTypStr = "雷达"

	case 2:
		devTypStr = "PTZ"

	case 3:
		devTypStr = "agx"

	case 4:
		devTypStr = "tracerP"
	case 5:
		devTypStr = "无线电设备"
	case 6:
		devTypStr = "哨兵塔"
	case 7:
		devTypStr = "诱骗背包"

	default:
		devTypStr = "未知设备类型"
	}
	return devTypStr, FindCachesfl200ChildMap(sn)
}

// ReportSflSflHit sfl 侦测无人机信息
func (c *CloudTcpCli) Sfl200SystemState(info []byte) error {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()

	report := client.Sfl200SystemStateInfo{}
	err := proto.Unmarshal(info, &report)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return fmt.Errorf("unmarshal encodedMessage error: %v", err)
	}
	devlist := report.Data.DevList
	dlist := make([]*cloudPlatform.Sfl200DeviceData, 0)
	//logger.Debug("devlist = ", devlist)
	//logger.Debug("report data = ", report.Data)
	if len(devlist) == 0 {
		logger.Debug("sfl200 system heart rate, devlist = ", devlist)
		return nil
	}
	for _, l := range devlist {
		devicetypeName, deviceName := GetDevStatus(int32(l.DevType), l.DevSn)
		//logger.Debug("l.DevType = ", l.DevType, " l.DevSn = ", l.DevSn)
		//logger.Debug("devicetypeName = ", devicetypeName, " deviceName = ", deviceName)
		dlist = append(dlist, &cloudPlatform.Sfl200DeviceData{
			Sn:             l.DevSn,
			DeviceTypeName: devicetypeName,
			DeviceName:     deviceName,
		})
	}
	// var dlistbody cloudPlatform.Sfl200DeviceList
	// dlistbody.Body = dlist

	// logger.Debug("dlistbody.Body = ", dlistbody.Body)
	// logger.Debug("dlistbody = ", dlistbody)

	//给云端发送侦测到的无人机小组
	dData := make([]*cloudPlatform.Sfl200SystemStateData, 0)
	dData = append(dData, &cloudPlatform.Sfl200SystemStateData{
		Sn:              report.Header.Sn,
		DevNum:          report.Data.DevNum,
		GunLongitude:    report.Data.GunLongitude,
		GunLatitude:     report.Data.GunLatitude,
		GunAltitude:     report.Data.GunAltitude,
		SatellitesNum:   (report.Data.SatellitesNum),
		SysWorkState1:   (report.Data.SysWorkState1),
		SysWorkState2:   (report.Data.SysWorkState2),
		SysWorkState3:   (report.Data.SysWorkState3),
		SysWorkState4:   (report.Data.SysWorkState4),
		SflState:        (report.Data.SflState),
		DeviceList:      dlist,
		WorkStatus:      report.Data.SflWorkStatus,
		WorkStatusParam: report.Data.WorkStatusParam,
		SflHitFreq:      report.Data.SflHitFreq,
		DetectFreq:      report.Data.DetectFreq,
		Elevation:       report.Data.Elevation,
		GunDirection:    report.Data.GunDirection,
		FaultLevel:      report.Data.FaultLevel,
		CtrlFault:       report.Data.CtrlFault,
		TracerFault:     report.Data.TracerFault,
		CreateTime:      time.Now().UnixMilli(),
	})
	gsfl200lon = report.Data.GunLongitude
	gsfl200la = report.Data.GunLatitude
	logger.Debugf("dData = ", dData)
	Message := &cloudPlatform.Sfl200SystemStateList{
		Body: dData,
	}

	if len(report.Header.Sn) != 0 {
		logger.Debug("report.Header.Sn = ", report.Header.Sn)
		// down.Gsfl200PropertyStatus.Store(report.Header.Sn, common.Sfl200)
		var isExitParentDev bool

		down.Gsfl200PropertyStatus.Range(func(key, value any) bool {
			isExitParentDev = true
			return true
		})
		if !isExitParentDev {
			down.Gsfl200PropertyStatus.Store(down.Sfl200PropertySnType{Sfl200Sn: report.Header.Sn}, down.Sfl200PropertyDeviceType{Sfl200Type: common.Sfl200})
		}

	}

	// encodedMessage
	encodedMessage, err := proto.Marshal(Message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return fmt.Errorf("Marshal encodedMessage error: %v", err)
	}

	// 构建Message消息
	message := &cloudPlatform.Message{
		BaseInfo: &cloudPlatform.BaseInfo{
			MsgId:     1,
			Url:       Sfl200Heart,
			Sn:        c.C2Sn, //ctrl.C2Sn
			MsgType:   MSG_TYPE_REQUEST,
			ErrorCode: 0,
			LoginId:   c.LoginId,
		},
		Data: encodedMessage,
	}
	// 对Message进行Protobuf编码
	encodedMessage, err = proto.Marshal(message)
	if err != nil {
		logger.Error("Protobuf编码失败:", err)
		return err
	}
	//对消息进行封装+head+crc
	encodedMessage = createPacket(encodedMessage)
	// 发送TCP消息
	if c.Conn == nil || !c.IsLogin {
		return nil
	}
	_, err = c.Conn.Write(encodedMessage)
	if err != nil {
		logger.Error("发送TCP消息失败:", err)
		c.clearConn()
		return err
	}

	return nil
}

type Point struct {
	Latitude  float64
	Longitude float64
}

func getDistanceByXY(x, y float64) float64 {
	return math.Sqrt(math.Pow(x, 2) + math.Pow(y, 2))
}

func GetLatLngByXY(mapCenter Point, x, y float64) Point {
	const earthRadius = 6371000 // 地球半径，单位：米

	// 计算目标点与地图中心点的距离和方位角
	dist := getDistanceByXY(x, y)
	angle := math.Atan2(x, y) * (180 / math.Pi)

	// 将方位角转换为弧度，并根据距离计算目标点的纬度和经度变化量
	radian := (angle - 90) * (math.Pi / 180)
	dLat := dist * math.Cos(radian) / earthRadius
	dLon := dist * math.Sin(radian) / (earthRadius * math.Cos(mapCenter.Latitude*math.Pi/180))

	// 计算转换后的目标点经纬度
	newLat := mapCenter.Latitude + (dLat * 180 / math.Pi)
	newLon := mapCenter.Longitude + (dLon * 180 / math.Pi)

	return Point{Latitude: newLat, Longitude: newLon}
}

func ConstructDroneName(namePrefix, sn, uNumber string) string {
	if sn != "" && len(sn) >= 4 {
		snSuffix := sn[len(sn)-4:]
		return namePrefix + "#" + snSuffix
	}
	return namePrefix + "#" + uNumber
}

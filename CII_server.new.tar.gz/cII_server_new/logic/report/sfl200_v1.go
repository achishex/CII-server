package report

import (
	"context"
	"errors"
	"fmt"
	"reflect"
	"sync"
	"time"

	"adasgitlab.autel.com/tools/cuav_plugin/broker"
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/slink_proto/slinkv1"
	"github.com/samber/lo"
	"google.golang.org/protobuf/proto"

	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
	"adasgitlab.autel.com/tools/cuav_server/repo/utils"
	"adasgitlab.autel.com/tools/cuav_server/rpc/cmdhandler"
	"adasgitlab.autel.com/tools/cuav_server/rpc/connmgr"
)

var Sfl200PtzMap sync.Map //存储ptz与无人机id到是否锁定映射

func init() {
	cmdhandler.Instance().RegisterHandler(common.DEV_SFL200, slinkv1.Sfl200UploadAgxDetect, Sfl200AgxDetect)
	cmdhandler.Instance().RegisterHandler(common.DEV_SFL200, slinkv1.Sfl200UploadPtzData, Sfl200PtzData)
	cmdhandler.Instance().RegisterHandler(common.DEV_SFL200, slinkv1.Sfl200UploadSflDetect, Sfl200SflDetect)
	cmdhandler.Instance().RegisterHandler(common.DEV_SFL200, slinkv1.Sfl200UploadSystemStatData, Sfl200SysStateData)
}

const (
	InvalidValueInt8   = 0xFF
	InvalidValueInt16  = 0x7FFF
	InvalidValueInt32  = 0x7FFFFFFF
	InvalidValueUInt16 = 0xFFFF
)

// Sfl200AgxDetect Sfl200上报Agx探测无人机结果
func Sfl200AgxDetect(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	logger.Debug("---->into receive Sfl200 Agx Detect,sn:", sn)
	rsp, ok := data.(*slinkv1.Sfl200FusionDetect)
	if !ok {
		logger.Errorf("covert Sfl200 up AgxDetectUav err")
		return nil, errors.New("covert Sfl200 up AgxDetectUav err")
	}
	//上报给前端消息
	//查白名单中的无人机，在Tracer侦测结果中添加无人机角色
	whiteList := &client.ListResAll{}
	err := handler.NewWhiteList().ListAll(context.Background(), &client.ListReqAll{}, whiteList)
	if err != nil {
		logger.Error("Get whiteList err: ", err)
		return nil, errors.New("whiteList ListAll err")
	}

	var dstDetectItems []*client.Sfl200AgxDetectSocketInfo
	for _, agx := range rsp.Description {
		var role int32
		for _, info := range whiteList.WhiteList {
			if info.Sn == handler.ByteToString(agx.Serialnum[:]) {
				role = info.Role
			}
		}
		if role == handler.ERRTYPE {
			role = handler.ENEMY
		}
		r := &client.Sfl200AgxDetectSocketInfo{
			Id:                 agx.ID,
			DroneName:          handler.ByteToString(agx.DroneName[:]),
			Serialnum:          handler.ByteToString(agx.Serialnum[:]),
			Source:             agx.Source,
			StateType:          uint32(agx.StateType),
			ExistingProb:       uint32(agx.ExistingProb),
			LifeTime:           float64(agx.LifeTime),
			ForcastTime:        float64(agx.ForcastTime),
			Classification:     uint32(agx.Classification),
			ClassificationProb: uint32(agx.ClassificationProb),
			GeoValid:           uint32(agx.GeoValid),
			Longitude:          agx.Longitude,
			Latitude:           agx.Latitude,
			Altitude:           agx.Altitude,
			Height:             agx.Height,
			OrientationAngle:   float64(agx.OrientationAngle),
			AbsoluteSpeed:      float64(agx.AbsoluteSpeed),
			VerticalSpeed:      float64(agx.VerticalSpeed),
			MotionType:         uint32(agx.MotionType),
			HomeLongitude:      agx.HomeLongitude,
			HomeLatitude:       agx.HomeLatitude,
			PilotLongitude:     agx.PilotLongitude,
			PilotLatitude:      agx.PilotLatitude,
			PilotAltitude:      agx.PilotAltitude,
			Frequency:          float64(agx.Frequency),
			LoadLevel:          uint32(agx.LoadLevel),
			DangerLevel:        uint32(agx.DangerLevel),
			Priority:           uint32(agx.Priority),
			TargetRange:        float64(agx.TargetRange),
			TargetAzimuth:      float64(agx.TargetAzimuth),
			TargetElevation:    float64(agx.TargetElevation),
			TargetArrivalTime:  float64(agx.TargetArrivalTime),
			Role:               role,
		}
		logger.Infof("Sfl200 up agx Info data: %+v", agx)
		if agx.StateType == 0 {
			logger.Info("Sfl200 up agx State Type is 0")
			continue
		}

		//计算无人机威胁等级
		if role != handler.FRIEND {
			fd, err := handler.NewAlarmControl().GetDroneThreatLevel(&handler.GetThreatLevelReq{
				DroneSn:        r.Serialnum,
				DroneObjId:     int64(r.Id),
				DroneLongitude: r.Longitude,
				DroneLatitude:  r.Latitude,
				DevSn:          sn,
			})
			if err != nil {
				logger.Errorf("Sfl200AgxDetect GetDroneThreatLevel error: %v", err)
			} else {
				r.AlarmId = fd.AlarmId
				r.ScenesId = fd.ScenesId
				r.EventId = fd.EventId
				r.ThreatLevel = fd.ThreatLevel
			}
		}
		dstDetectItems = append(dstDetectItems, r)
	}
	// sfl200上报Agx探测无人机事件
	cloudEventID := sfl200AgxDetectEvent(sn, dstDetectItems)
	msg := &client.Sfl200AgxDetectInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      sn,
			Sn:        sn,
			EquipType: int32(common.DEV_SFL200),
			MsgType:   slinkv1.Sfl200UploadAgxDetect,
		},
		Data:    dstDetectItems,
		EventID: cloudEventID,
	}
	msgOut, err := proto.Marshal(msg)
	if err != nil {
		logger.Error("marshal msg err:", err)
		return nil, errors.New(" Sfl200 up agx marshal msg err")
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIDSfl200AgxDetectData,
		Data:    msgOut,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return nil, errors.New(" Sfl200 up agx marshal report err")
	}

	_ = mq.Sfl200MsgBroker.Publish(mq.Sfl200Topic, broker.NewMessage(out))
	// // sfl200上报Agx探测无人机事件
	// sfl200AgxDetectEvent(sn, dstDetectItems)
	UpdateStatus(sn, common.DEV_SFL200)
	return nil, nil
}

// Sfl200PtzData Sfl200上报PTZ数据
func Sfl200PtzData(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	logger.Debug("---->into receive Sfl200 Ptz Data,sn:", sn)
	rsp, ok := data.(*slinkv1.Sfl200PtzDate)
	if !ok {
		logger.Errorf("covert Sfl200 upPtzDate err")
		return nil, errors.New("covert Sfl200 up PtzDate err")
	}
	//上报给前端消息
	dataInfo := &client.Sfl200PTZDataSocketInfo{
		ObjNum:       uint32(rsp.Info.ObjNum),
		TargetId:     rsp.Info.TargetId,
		PtzZoom:      float64(rsp.Info.PTzZoom),
		HFov:         float64(rsp.Info.HFov),
		VFov:         float64(rsp.Info.VFov),
		Azimuth:      float64(rsp.Info.Azimuth),
		Elevation:    float64(rsp.Info.Elevation),
		OmegaAz:      float64(rsp.Info.OmegaAz),
		OmegaEl:      float64(rsp.Info.OmegaEl),
		Zoom:         float64(rsp.Info.Zoom),
		AiStatus:     uint32(rsp.Info.AIStatus),
		AiType:       uint32(rsp.Info.AIType),
		AiObjId:      rsp.Info.AIObjId,
		AiSn:         handler.ByteToString(rsp.Info.AIsn[:]),
		AiWorkStatus: 0,
	}

	dataInfo.PtzData = make([]*client.PtzDataList, 0, len(rsp.Description))
	for _, ptzData := range rsp.Description {
		r := &client.PtzDataList{
			PtzId:          ptzData.Id,
			Classification: uint32(ptzData.Classification),
			RectX:          uint32(ptzData.RectX),
			RectY:          uint32(ptzData.RectY),
			RectW:          uint32(ptzData.RectW),
			RectH:          uint32(ptzData.RectH),
			RectXV:         uint32(ptzData.RectXV),
			RectYV:         uint32(ptzData.RectYV),
			ClassfyProb:    float64(ptzData.ClassifyProb),
			ClassType:      uint32(ptzData.Type),
			TypeProb:       float64(ptzData.TypeProb),
			LoadLever:      uint32(ptzData.LoadLever),
			DanagerLever:   uint32(ptzData.DangerLever),
			Azimuth:        float64(ptzData.Azimuth),
			Elevation:      float64(ptzData.Elevation),
			Range:          float64(ptzData.Range),
			MotionType:     uint32(ptzData.MotionType),
			BTracked:       uint32(ptzData.BTracked),
		}

		//记录目标是否被ptz锁定
		cacheKey := fmt.Sprintf("%s_%d", sn, r.PtzId)
		if ptzData.BTracked == 1 {
			Sfl200PtzMap.Store(cacheKey, ptzData.BTracked)
		}

		logger.Infof("Sfl200 up PTZ Info data: %+v", ptzData)
		dataInfo.PtzData = append(dataInfo.PtzData, r)
	}

	msg := &client.Sfl200PTZDataInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      sn,
			Sn:        sn,
			EquipType: int32(common.DEV_SFL200),
			MsgType:   slinkv1.Sfl200UploadPtzData,
		},
		Data: dataInfo,
	}
	msgOut, err := proto.Marshal(msg)
	if err != nil {
		logger.Error("marshal msg err:", err)
		return nil, errors.New(" Sfl200 up PTZ marshal msg err")
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIDSfl200PTZData,
		Data:    msgOut,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return nil, errors.New(" Sfl200 up PTZ marshal report err")
	}

	_ = mq.Sfl200MsgBroker.Publish(mq.Sfl200Topic, broker.NewMessage(out))
	UpdateStatus(sn, common.DEV_SFL200)
	return nil, nil
}

// Sfl200SflDetect Sfl200上报Sfl探测数据
func Sfl200SflDetect(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	logger.Debug("---->into receive Sfl200 Sfl Detect,sn:", sn)
	rsp, ok := data.(*slinkv1.Sfl200SflDetect)
	if !ok {
		logger.Errorf("covert Sfl200 UP SflDetect err")
		return nil, errors.New("covert Sfl200 up SflDetect err")
	}
	//上报给前端消息
	//查白名单中的无人机，在Tracer侦测结果中添加无人机角色
	whiteList := &client.ListResAll{}
	err := handler.NewWhiteList().ListAll(context.Background(), &client.ListReqAll{}, whiteList)
	if err != nil {
		logger.Error("Get whiteList err: ", err)
		return nil, errors.New("whiteList ListAll err")
	}

	dataInfo := &client.Sfl200SflDetectSocketInfo{}
	dataInfo.SflDetectData = make([]*client.SflDetectList, 0, len(rsp.Description))
	for _, sflData := range rsp.Description {
		if sflData.Source != 1 {
			continue
		}
		sflData = DetectCheckInputNum(sflData)
		var role int32
		for _, info := range whiteList.WhiteList {
			if info.Sn == handler.ByteToString(sflData.SerialNum[:]) {
				role = info.Role
			}
		}
		if role == handler.ERRTYPE {
			role = handler.ENEMY
		}

		r := &client.SflDetectList{
			ProductType:        int32(sflData.ProductType),
			DroneName:          handler.ByteToString(sflData.DroneName[:]),
			SerialNum:          handler.ByteToString(sflData.SerialNum[:]),
			DroneLongitude:     float64(sflData.DroneLongitude) / handler.DroneTion,
			DroneLatitude:      float64(sflData.DroneLatitude) / handler.DroneTion,
			DroneHeight:        float64(sflData.DroneHeight) / handler.DroneHeightTion,
			DroneYawAngle:      float64(sflData.DroneYawAngle) / handler.DroneYawTion,
			DroneSpeed:         float64(sflData.DroneSpeed) / handler.DroneSpeedTion,
			DroneVerticalSpeed: float64(sflData.DroneVerticalSpeed) / handler.DroneVerticalSpeedTion,
			SpeedDirection:     int32(sflData.SpeedDirection) / handler.DroneSpeedTion,
			DroneSailLongitude: float64(sflData.DroneSailLongitude) / handler.DroneSailLongitudeTion,
			DroneSailLatitude:  float64(sflData.DroneSailLatitude) / handler.DroneSailLatitudeTion,
			PilotLongitude:     float64(sflData.PilotLongitude) / handler.DroneTion,
			PilotLatitude:      float64(sflData.PilotLatitude) / handler.DroneTion,
			DroneHorizon:       float64(sflData.DroneHorizon) / handler.DroneHorizonTion,
			DronePitch:         float64(sflData.DronePitch) / handler.DronePitch,
			UFreq:              float64(sflData.UFreq) / handler.DetectFreqTion,
			UDistance:          int32(sflData.UDistance),
			UDangerLevels:      int32(sflData.UDangerLevels),
			Role:               role,
			UZC:                int32(sflData.UZC),
			UDirStatus:         int32(sflData.UDirStatus),
			UNumber:            uint32(sflData.UNumber),
			GpsClocks:          sflData.GpsClocks,
			TimeStampRid:       sflData.TimestampRid,
			IdType:             uint32(sflData.IDType),
			WifiMac:            string(sflData.WifiMac[:]),
		}
		r.DroneName = common.ConstructDroneName(r.DroneName, "", r.UNumber)
		if sflData.DroneHorizon == InvalidValueInt32 {
			r.DroneHorizon = handler.InvalidValue
		}
		if sflData.DroneHorizon == InvalidValueInt32 {
			r.DronePitch = handler.InvalidValue
		}

		//频谱不上报告警
		//计算无人机威胁等级
		//fd, err := handler.NewAlarmControl().GetDroneThreatLevel(r.SerialNum, 0, r.DroneLongitude, r.DroneLatitude)
		//if err != nil {
		//	logger.Errorf("Sfl200SflDetect GetDroneThreatLevel err: %+v", err)
		//} else {
		//	r.AlarmId = fd.AlarmId
		//	r.ScenesId = fd.ScenesId
		//	r.EventId = fd.EventId
		//	r.ThreatLevel = fd.ThreatLevel
		//}
		logger.Infof("Sfl200 up sfl Info data: %+v", r)
		dataInfo.SflDetectData = append(dataInfo.SflDetectData, r)

		//判断无人机是否打击成功，若成功上报打击成功事件
		sfl200HitEventReport(sn, r)
	}

	dataInfo.ObjNum = int32(len(dataInfo.SflDetectData))
	msg := &client.Sfl200SflDetectInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      sn,
			Sn:        sn,
			EquipType: int32(common.DEV_SFL200),
			MsgType:   slinkv1.Sfl200UploadSflDetect,
		},
		Data: dataInfo,
	}
	msgOut, err := proto.Marshal(msg)
	if err != nil {
		logger.Error("marshal msg err:", err)
		return nil, errors.New(" Sfl200 up SFL marshal msg err")
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIDSfl200SflDetectData,
		Data:    msgOut,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return nil, errors.New(" Sfl200 up SFL marshal report err")
	}

	_ = mq.Sfl200MsgBroker.Publish(mq.Sfl200Topic, broker.NewMessage(out))

	//sfl200侦测事件上报
	sfl200DetectAppearEvent(sn, dataInfo)
	//判断无人机是否消失，若消失则上报打击成功事件
	sfl200HitDisappearEventReport(sn, dataInfo.SflDetectData)
	UpdateStatus(sn, common.DEV_SFL200)
	return nil, nil
}
func DetectCheckInputNum(drone *slinkv1.Sfl200SflDetectDescription) *slinkv1.Sfl200SflDetectDescription {
	if drone.DroneLongitude == InvalidValueInt32 {
		drone.DroneLongitude = 0
	}
	if drone.DroneLatitude == InvalidValueInt32 {
		drone.DroneLatitude = 0
	}
	if drone.DroneHeight == InvalidValueInt16 {
		drone.DroneHeight = 0
	}
	if drone.DroneYawAngle == InvalidValueInt16 {
		drone.DroneYawAngle = 0
	}
	if drone.DroneSpeed == InvalidValueInt16 {
		drone.DroneSpeed = 0
	}
	if drone.DroneVerticalSpeed == InvalidValueInt16 {
		drone.DroneVerticalSpeed = 0
	}
	if drone.DroneSailLongitude == InvalidValueInt32 {
		drone.DroneSailLongitude = 0
	}
	if drone.DroneSailLatitude == InvalidValueInt32 {
		drone.DroneSailLatitude = 0
	}
	if drone.PilotLongitude == InvalidValueInt32 {
		drone.PilotLongitude = 0
	}
	if drone.PilotLatitude == InvalidValueInt32 {
		drone.PilotLatitude = 0
	}
	//if drone.DroneHorizon == InvalidValueInt32 {
	//	drone.DroneHorizon = 0
	//}
	//if drone.DronePitch == InvalidValueInt32 {
	//	drone.DronePitch = 0
	//}
	if drone.UDistance == InvalidValueUInt16 {
		drone.UDistance = 0
	}
	if drone.UDangerLevels == InvalidValueInt16 {
		drone.UDangerLevels = 0
	}
	if drone.UFreq == InvalidValueInt32 {
		drone.UFreq = 0
	}
	return drone
}

// Sfl200SysStateData Sfl200上报系统信息
func Sfl200SysStateData(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	logger.Debug("----> ,sn:", sn)
	rsp, ok := data.(*slinkv1.Sfl200SystemState)
	if !ok {
		logger.Errorf("covert Sfl200 UP SystemState err")
		return nil, errors.New("covert Sfl200 up SystemState err")
	}
	//上报给前端消息

	dataInfo := &client.Sfl200SystemStatSocketInfo{
		Sfl200Sn:        sn,
		DevNum:          uint32(rsp.Info.DevNum),
		GunLongitude:    float64(rsp.Info.GunLongitude) / handler.DroneTion,
		GunLatitude:     float64(rsp.Info.GunLatitude) / handler.DroneTion,
		GunAltitude:     float64(rsp.Info.GunAltitude),
		SatellitesNum:   int32(rsp.Info.SatellitesNum),
		SysWorkState1:   uint32(rsp.Info.SysWorkState1),
		SysWorkState2:   uint32(rsp.Info.SysWorkState2),
		SysWorkState3:   uint32(rsp.Info.SysWorkState3),
		SysWorkState4:   uint32(rsp.Info.SysWorkState4),
		SflState:        uint32(rsp.Info.SflState),
		SflWorkStatus:   uint32(rsp.Info.SflWorkStatus),
		WorkStatusParam: uint32(rsp.Info.WorkStatusParam),
		SflHitFreq:      uint32(rsp.Info.SflHitFreq),
		DetectFreq:      uint32(rsp.Info.DetectFreq),
		Elevation:       rsp.Info.Elevation,
		GunDirection:    rsp.Info.GunDirection,
		FaultLevel:      uint32(rsp.Info.FaultLevel),
		CtrlFault:       uint32(rsp.Info.CtrlFault),
		GunFault:        uint32(rsp.Info.AeagFault),
		TracerFault:     uint32(rsp.Info.TracerFault),
		SysWorkMode:     uint32(rsp.Info.SysWorkMode),
		SflHitId:        rsp.Info.SflHitId,
		SflHitType:      uint32(rsp.Info.SflHitType),
		IsOnline:        common.DevOnline,
	}
	dataInfo.DevList = make([]*client.DevList, 0, len(rsp.Info.DeviceList))
	for _, sysData := range rsp.Info.DeviceList {
		if handler.ByteToString(sysData.DeviceSn[:]) != "" && sysData.DeviceType != 0 {
			r := &client.DevList{
				DevType: uint32(sysData.DeviceType),
				DevSn:   handler.ByteToString(sysData.DeviceSn[:]),
			}
			logger.Infof("Sfl200 up sysData Info data: %+v", sysData)
			dataInfo.DevList = append(dataInfo.DevList, r)
		}
	}
	logger.Infof("Sfl200 up sysData Info data dataInfo: %+v", dataInfo)

	msg := &client.Sfl200SystemStateInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      sn,
			Sn:        sn,
			EquipType: int32(common.DEV_SFL200),
			MsgType:   slinkv1.Sfl200UploadSystemStatData,
		},
		Data: dataInfo,
	}
	msgOut, err := proto.Marshal(msg)
	if err != nil {
		logger.Error("marshal msg err:", err)
		return nil, errors.New(" Sfl200 up sysData marshal msg err")
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIDSfl200SystemStateData,
		Data:    msgOut,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return nil, errors.New(" Sfl200 up sysData marshal report err")
	}

	_ = mq.Sfl200MsgBroker.Publish(mq.Sfl200Topic, broker.NewMessage(out))

	//上报sfl200上线事件
	sfl200OnLineEventReport(sn, dataInfo)

	//保存打击的无人机信息
	if dataInfo.SflState == handler.HITOVER {
		if hitInfo, ok := handler.Sfl200FreqDirectHitMap.GetAll(sn); ok {
			for k, v := range hitInfo {
				timeNow := time.Now().UnixMilli()
				handler.Sfl200FreqDirectHitMap.UpdateHitOverTime(sn, k, timeNow)

				hitUav := &common.SflHitEventInfo{
					Sn:               sn,
					UavSn:            v.UavSn,
					ProductType:      v.ProductType,
					HitOverTime:      time.Now(),
					SessionId:        handler.GetGlobalSessionId(),
					DetectReportTime: time.Now(),
					DroneName:        v.DroneName,
					DroneLongitude:   v.DroneLongitude,
					DroneLatitude:    v.DroneLatitude,
					DroneHeight:      v.DroneHeight,
					DroneYawAngle:    v.DroneYawAngle,
				}
				handler.Sfl200FreqDirectHitMap.Clear()
				logger.Debugf("sfl200 hit over uav: %v", hitUav)
				cacheKey := handler.GetSfl200HitCacheKey(hitUav.UavSn, hitUav.DroneName, hitUav.ProductType)
				handler.Sfl200HitOverMapOnEvent.Store(cacheKey, hitUav)
			}
		}
	}
	//停止打击，删除Sfl200FreqDirectHitMap缓存
	if dataInfo.SflState != handler.HITING {
		handler.Sfl200FreqDirectHitMap.Clear()
	}

	UpdateStatus(sn, common.DEV_SFL200)

	sfl200List := make([]*client.Sfl200DevList, 0)
	for _, dev := range dataInfo.DevList {
		if dev.DevType == 0x01 { //过滤雷达设备
		} else {
			sfl200List = append(sfl200List, &client.Sfl200DevList{Sn: dev.DevSn, Sfl200Sn: sn, Sfl200Type: int32(common.DEV_SFL200)})
		}

	}
	err = handler.NewEquipList().UpdateSfl200Status(context.Background(), &client.UpdateSfl200StatusReq{List: sfl200List}, &client.UpdateSfl200StatusRes{})
	if err != nil {
		logger.Error("Update Sfl200 Status err: ", err)
	}
	return nil, nil
}

// sfl200OnLineEventReport sfl200在线事件上报
func sfl200OnLineEventReport(sn string, stateInfo *client.Sfl200SystemStatSocketInfo) {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_SFL200, sn)
	if cache, ok := handler.DevStatusMapOnEvent.Load(cacheKey); ok {
		dev := cache.(*handler.Device)
		dev.LastHeartTime = time.Now()
		dev.GetStatusInterval = time.Now()
		handler.DevStatusMapOnEvent.Store(cacheKey, cache)
		return
	}

	dev := &handler.Device{
		Sn:                sn,
		Status:            uint8(stateInfo.IsOnline),
		DevType:           common.DEV_SFL200,
		FirstHeartTime:    time.Now(),
		LastHeartTime:     time.Now(),
		IsEnable:          common.DeviceEnable,
		GetStatusInterval: time.Now(),
		SessionId:         handler.GetGlobalSessionId(),
	}
	handler.DevStatusMapOnEvent.Store(cacheKey, dev)
	dataInfo := &client.Sfl200SystemStateInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      sn,
			Sn:        sn,
			EquipType: int32(common.DEV_SFL200),
			MsgType:   common.Sfl200EventOnLine,
		},
		Data: &client.Sfl200SystemStatSocketInfo{
			Sfl200Sn:     stateInfo.Sfl200Sn,
			GunLongitude: stateInfo.GunLongitude,
			GunLatitude:  stateInfo.GunLatitude,
			IsOnline:     stateInfo.IsOnline,
			EventId:      utils.GetEventId(dev.SessionId),
		},
	}

	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgSfl200StatusEventData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Debugf("Sfl200 Online event report: %+v", report)
}

// sfl200DetectAppearEvent sfl200侦测事件上报
func sfl200DetectAppearEvent(sn string, detectInfo *client.Sfl200SflDetectSocketInfo) {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_SFL200, sn)
	if cache, ok := handler.DevDetectMapOnEvent.Load(cacheKey); ok {
		detect := cache.(*handler.DetectEvent)
		detect.LastReceiveTime = time.Now()
		return
	}

	if len(detectInfo.GetSflDetectData()) <= 0 {
		logger.Debugf("has not detect any uav")
		return
	}

	detect := &handler.DetectEvent{
		Sn:              sn,
		LastReceiveTime: time.Now(),
		DevType:         common.DEV_SFL200,
		SessionId:       handler.GetGlobalSessionId(),
	}
	handler.DevDetectMapOnEvent.Store(cacheKey, detect)

	eventId := utils.GetEventId(detect.SessionId)

	sfl200DetectInfo := &client.SflDetectInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      sn,
			Sn:        sn,
			EquipType: int32(common.DEV_SFL200),
			MsgType:   common.Sfl200EventDetectAppear,
		},
		Data: &client.GimbalCounterDetectSocketInfo{
			Sn:           sn,
			DetectionNum: detectInfo.ObjNum,
			List:         make([]*client.GimbalCounterDetectDroneInfo, 0),
			EventId:      eventId,
		},
	}

	for _, info := range detectInfo.SflDetectData {
		sfl200DetectInfo.Data.List = append(sfl200DetectInfo.Data.List, &client.GimbalCounterDetectDroneInfo{
			ProductType:        info.ProductType,
			DroneName:          info.DroneName,
			SerialNum:          info.SerialNum,
			DroneLongitude:     info.DroneLongitude,
			DroneLatitude:      info.DroneLatitude,
			DroneHeight:        info.DroneHeight,
			DroneYawAngle:      info.DroneYawAngle,
			DroneSpeed:         info.DroneSpeed,
			DroneVerticalSpeed: info.DroneVerticalSpeed,
			SpeedDirection:     info.SpeedDirection,
			DroneSailLongitude: info.DroneSailLongitude,
			DroneSailLatitude:  info.DroneSailLatitude,
			PilotLongitude:     info.PilotLongitude,
			PilotLatitude:      info.PilotLatitude,
			DroneHorizon:       info.DroneHorizon,
			DronePitch:         info.DronePitch,
			UFreq:              info.UFreq,
			UDistance:          info.UDistance,
			UDangerLevels:      info.UDangerLevels,
			Role:               info.Role,
			UZC:                info.UZC,
			UDirStatus:         info.UDirStatus,
			UNumber:            info.UNumber,
		})
	}
	msg, err := proto.Marshal(sfl200DetectInfo)
	if err != nil {
		logger.Error("marshal sfl200DetectInfo err:", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgSFl200DetectEventData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Debugf("sfl200 detect uav event has reported, devSn: %v,report:%+v", sn, sfl200DetectInfo)
	go handler.Sfl200SendDevWhiteList()
}

// sfl200HitEventReport 打击无人机时，无人机位置变动满足打击成功，上报打击成功事件
func sfl200HitEventReport(sn string, sflDetect *client.SflDetectList) {
	_, exist := handler.Sfl200FreqDirectHitMap.Get(sn, sflDetect.DroneName, sflDetect.SerialNum)
	if !exist {
		logger.Debugf("sfl200 add drone event: %+v", sflDetect)
		handler.Sfl200FreqDirectHitMap.Set(&client.Sfl200FreqDirectHitRequest{
			Sn:             sn,
			DroneSn:        sflDetect.SerialNum,
			DroneLongitude: float32(sflDetect.DroneLongitude),
			DroneLatitude:  float32(sflDetect.DroneLatitude),
			DroneHeight:    float32(sflDetect.DroneHeight),
			DroneYawAngle:  float32(sflDetect.DroneYawAngle),
			DroneName:      sflDetect.DroneName,
		})
	}

	if sflDetect == nil {
		logger.Debug("sfl200HitEventReport sflDetect is null")
		return
	}
	cacheKey := handler.GetSfl200HitCacheKey(sflDetect.SerialNum, sflDetect.DroneName, sflDetect.ProductType)
	cache, ok := handler.Sfl200HitOverMapOnEvent.Load(cacheKey)
	if !ok || cache == nil {
		logger.Debugf("sfl200HitEventReport cache not exist: %+v", cacheKey)
		return
	}
	hit, ok := cache.(*common.SflHitEventInfo)
	if !ok {
		logger.Debugf("sfl200HitEventReport value type err: %+v", reflect.TypeOf(cache))
		return
	}
	hitSuccess := handler.CalcHitOverStatus(int16(sflDetect.DroneHeight), uint16(sflDetect.UDistance))
	if !hitSuccess {
		//不满足打击成功事件
		hit.ProductType = sflDetect.ProductType
		hit.UavSn = sflDetect.SerialNum
		hit.DroneName = sflDetect.DroneName
		hit.DetectReportTime = time.Now()
		hit.DroneHeight = sflDetect.DroneHeight
		hit.DroneYawAngle = sflDetect.DroneYawAngle
		hit.DroneLatitude = sflDetect.DroneLatitude
		hit.DroneLongitude = sflDetect.DroneLongitude
		handler.Sfl200HitOverMapOnEvent.Store(cacheKey, hit)
		logger.Debugf("sfl200HitEventReport hit fail, cacheKey: %s, hit: %+v", cacheKey, hit)
		return
	}

	//满足打击成功，上报打击成功事件
	logger.Debugf("sfl200HitEventReport hit success, cacheKey: %s, devSn: %s", cacheKey, sn)
	eventId := utils.GetEventId(hit.SessionId)
	handler.Sfl200HitOverMapOnEvent.Delete(cacheKey)

	hitInfo := &client.SflHitStateInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      sn,
			Sn:        sn,
			EquipType: int32(common.DEV_SFL200),
			MsgType:   common.Sfl200EventHitSucc,
		},
		Data: &client.GimbalCounterHitSocketInfo{
			ProductType:    sflDetect.ProductType,
			DroneName:      sflDetect.DroneName,
			SerialNum:      sflDetect.SerialNum,
			DroneLongitude: sflDetect.DroneLongitude,
			DroneLatitude:  sflDetect.DroneLatitude,
			DroneHeight:    sflDetect.DroneHeight,
			DroneYawAngle:  sflDetect.DroneYawAngle,
			EventId:        eventId,
		},
	}
	logger.Debugf("sfl200HitEventReport hit success, hitInfo: %+v", hitInfo)

	msg, err := proto.Marshal(hitInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgSfl200HitEventData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Debugf("sfl200HitEventReport hit success, publish report msg: %+v", report)
}

// 打击无人机，若无人机消失，则打击成功，上报打击成功事件
func sfl200HitDisappearEventReport(sn string, detectInfo []*client.SflDetectList) {
	disappearUavList := make([]*common.SflHitEventInfo, 0)

	handler.Sfl200HitOverMapOnEvent.Range(func(key, value any) bool {
		hit, ok := value.(*common.SflHitEventInfo)
		if !ok {
			return true
		}

		var exist bool
		for _, info := range detectInfo {
			if info == nil {
				continue
			}
			if info.ProductType == hit.ProductType && info.DroneName == hit.DroneName && info.SerialNum == hit.UavSn {
				//无人机未消失，打击不成功
				exist = true
			}
		}
		if !exist {
			// 无人机消失，打击成功
			disappearUavList = append(disappearUavList, hit)
			logger.Debugf("sfl200HitDisappearEventReport hit uav disappear uavSn: %s, uavName: %s, productType: %s",
				hit.UavSn, hit.DroneName, hit.ProductType)
		}
		return true
	})

	for _, uav := range disappearUavList {
		if uav == nil {
			continue
		}
		eventId := utils.GetEventId(uav.SessionId)
		cacheKey := handler.GetSfl200HitCacheKey(uav.UavSn, uav.DroneName, uav.ProductType)
		handler.Sfl200HitOverMapOnEvent.Delete(cacheKey)

		// sfl200打击成功事件上报
		hitInfo := &client.SflHitStateInfo{
			Header: &client.EquipmentMessageBoxEntity{
				Name:      sn,
				Sn:        sn,
				EquipType: int32(common.DEV_SFL200),
				MsgType:   common.Sfl200EventHitSucc,
			},
			Data: &client.GimbalCounterHitSocketInfo{
				ProductType:    uav.ProductType,
				DroneName:      uav.DroneName,
				SerialNum:      uav.UavSn,
				DroneLongitude: uav.DroneLongitude,
				DroneLatitude:  uav.DroneLatitude,
				DroneHeight:    uav.DroneHeight,
				DroneYawAngle:  uav.DroneYawAngle,
				EventId:        eventId,
			},
		}
		logger.Debugf("sfl200HitDisappearEventReport hit success, hitInfo: %+v", hitInfo)

		msg, err := proto.Marshal(hitInfo)
		if err != nil {
			logger.Error("marshal hitInfo err:", err)
			return
		}

		report := &client.ClientReport{
			MsgType: common.ClientMsgSfl200HitEventData,
			Data:    msg,
		}
		out, err := proto.Marshal(report)
		if err != nil {
			logger.Error("marshal report err:", err)
			return
		}

		_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
		logger.Debugf("sfl200HitDisappearEventReport hit success, publish report msg: %+v", report)
	}
}

// sfl200AgxDetectEvent sfl200上报Agx侦测无人机事件
func sfl200AgxDetectEvent(sn string, detectItems []*client.Sfl200AgxDetectSocketInfo) string {
	logger.Debug("sfl200AgxDetectEvent sn = ", sn)
	cacheKey := handler.GetSfl200AgxDetectCacheKey(sn)
	if cache, ok := handler.DevDetectMapOnEvent.Load(cacheKey); ok {
		if detect, ok := cache.(*handler.DetectEvent); !ok {
			logger.Debugf("sfl200AgxDetectEvent value type err, got: %+v", reflect.TypeOf(cache))
			// return ""
		} else {
			detect.LastReceiveTime = time.Now()
			// 记录当前被锁定，且是第一次被锁定的无人机
			logger.Debugf("detectItems = %+v", detectItems)
			for _, uav := range detectItems {
				if uav == nil {
					logger.Errorf("uav is nil , uav = ", uav)
					continue
				}
				// 0: 就代表没有被PTZ锁定过，1就是有被锁定过
				var isLockedByPtz int
				cacheKey := fmt.Sprintf("%s_%d", sn, uav.Id)

				if value, ok := Sfl200PtzMap.Load(cacheKey); ok {
					if val, ok := value.(uint8); ok {
						isLockedByPtz = int(val)
					}
				}
				if isLockedByPtz == 0 {
					//uav.Source 为 1，表示无人机有被锁定过
					if (uav.Source & 1) != 1 {
						logger.Debug("uav not locked by ptz")
						isLockedByPtz = 1 // TODO Fixme @fzw 由于没上报锁定信息，钟工要求，只要侦测到就进行事件录屏。
						// continue
					} else {
						logger.Debug("uav locked by ptz")
						isLockedByPtz = 1
					}
				}

				if !handler.CheckUavLocked(detect.Items, uav.Id) {
					logger.Debugf("uav not been locked previously, this time is locked by ptz, uav: %v", uav.Id)
					detect.Items = append(detect.Items, &handler.DetectUavItem{
						ObjectId:    uav.Id,
						LockedTime:  time.Now(),
						LockedUavIs: int8(isLockedByPtz),
					})
				} else {
					logger.Debug("uav has been locked previously. objectID = ", uav.Id)
				}
				Sfl200PtzMap.Store(cacheKey, isLockedByPtz)
			}
			handler.DevDetectMapOnEvent.Store(cacheKey, cache)
			return detect.EventID
		}
	}
	logger.Debugf("sfl200 is first get uav event when online, cacheKey = ", cacheKey)

	if len(detectItems) <= 0 {
		logger.Debug("detect uav info is empty")
		return ""
	}
	detect := &handler.DetectEvent{
		Sn:               sn,
		LastReceiveTime:  time.Now(),
		DevType:          common.DEV_SFL200,
		SessionId:        handler.GetGlobalSessionId(),
		LockPtzSessionId: handler.GetGlobalSessionId(),
	}
	cloudEventID := utils.GetEventId(detect.SessionId)
	//记录被锁定的无人机
	for _, uav := range detectItems {
		// 0: 就代表没有被PTZ锁定过，1就是有被锁定过
		var isLockedByPtz int
		cacheKey := fmt.Sprintf("%s_%d", sn, uav.Id)
		if value, ok := Sfl200PtzMap.Load(cacheKey); ok {
			if val, ok := value.(uint8); ok {
				isLockedByPtz = int(val)
				if isLockedByPtz == 0 {
					if (uav.Source & 1) != 1 {
						logger.Debug("uav not locked by ptz")
					} else {
						logger.Debug("uav locked by ptz,uav.Source  = ", uav.Source)
						isLockedByPtz = 1
					}
				}
			}
		}
		isLockedByPtz = 1 //TODO: 	should remove when uav locked status upload
		if isLockedByPtz == 0 {
			continue
		}
		logger.Debugf("uav locked by ptz first, uav: %v", uav.Id)
		detect.EventID = cloudEventID
		detect.Items = append(detect.Items, &handler.DetectUavItem{
			ObjectId:    uav.Id,
			LockedTime:  time.Now(),
			LockedUavIs: int8(isLockedByPtz),
		})
	}
	handler.DevDetectMapOnEvent.Store(cacheKey, detect)

	eventDetectInfo := &client.AgxDetectInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      sn,
			Sn:        sn,
			EquipType: int32(common.DEV_SFL200),
			MsgType:   common.Sfl200AgxDetectAppear,
		},
		Data:    make([]*client.AgxDetectInfoList, len(detectItems)),
		EventId: cloudEventID,
	}

	for _, item := range detectItems {
		tmp := &client.AgxDetectInfoList{
			ObjId:            item.Id,
			Azimuth:          item.TargetAzimuth,
			Elevation:        item.TargetElevation,
			Velocity:         item.VerticalSpeed,
			Classification:   int32(item.Classification),
			ClassfyProb:      float64(item.ClassificationProb),
			ExistingProb:     float32(item.ExistingProb),
			AbsVel:           item.AbsoluteSpeed,
			OrientationAngle: item.OrientationAngle,
			Latitude:         item.Latitude,
			Longitude:        item.Longitude,
			StateType:        int32(item.StateType),
			MotionType:       int32(item.MotionType),
			DroneName:        item.DroneName,
			SerialNum:        item.Serialnum,
			Role:             item.Role,
		}
		eventDetectInfo.Data = append(eventDetectInfo.Data, tmp)
	}

	msg, err := proto.Marshal(eventDetectInfo)
	if err != nil {
		logger.Errorf("Marshal TracerDetectInfo err %v", err)
		return ""
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgSFl200AgxDetectEventData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return ""
	}
	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Debugf("sfl200 agx detect uav event has reported, devSn: %v,report:%+v", sn, eventDetectInfo)
	return cloudEventID
}

func UpdateStatus(sn string, devType common.DeviceType) {
	cacheKey := fmt.Sprintf("%d_%s", devType, sn)
	if cache, ok := handler.DevStatusMap.Load(cacheKey); ok {
		dev := cache.(*handler.Device)
		dev.LastHeartTime = time.Now()
		dev.Status = common.DevOnline
	} else {
		// 和其他设备心跳处理保持一致。
		dev := &handler.Device{
			Sn:                sn,
			Status:            common.DevOnline,
			DevType:           devType,
			FirstHeartTime:    time.Now(),
			LastHeartTime:     time.Now(),
			IsEnable:          handler.GetDevStatus(int32(devType), sn),
			GetStatusInterval: time.Now(),
		}
		handler.DevStatusMap.Store(cacheKey, dev)
		go getDeviceVersion(sn, devType)
	}
}

func getDeviceVersion(sn string, devType common.DeviceType) {
	switch devType {
	case common.DEV_RADAR:
		req := &client.RadarGetConfigRequest{
			Sn:          sn,
			VersionType: lo.ToPtr(int32(2)),
		}
		rsp := &client.RadarGetConfigResponse{}
		err := handler.NewDeviceCenter().RadarGetConfig(context.Background(), req, rsp)
		if err != nil {
			logger.Error("getDeviceVersion RadarGetConfig err: ", err)
		} else {
			if rsp.GetVersion() != "" {
				devIp := ""
				conn := connmgr.Instance().GetConn(sn)
				if conn != nil {
					devIp = conn.Conn.RemoteAddr().String()
				}
				//更新设备版本号
				if err := handler.NewEquipList().Update(context.Background(), &client.EquipCrudReq{
					Sn:         sn,
					DevVersion: rsp.GetVersion(),
					IsOnline:   true,
					Ip:         devIp,
				}, &client.EquipCrudRes{}); err != nil {
					logger.Error("Update radar T6 Version err: ", err)
				}
			}
		}
	case common.DEV_SFL200:
		req := &client.Sfl200GetVersionRequest{
			Sn: sn,
		}
		rsp := &client.Sfl200GetVersionResponse{}
		err := handler.NewDeviceCenter().Sfl200GetVersionInfo(context.Background(), req, rsp)
		if err != nil {
			logger.Error("getDeviceVersion Sfl200GetVersionInfo err: ", err)
		} else {
			if rsp.Sfl200Version != "" {
				//更新设备版本号
				if err := handler.NewEquipList().Update(context.Background(), &client.EquipCrudReq{
					Sn:         sn,
					DevVersion: rsp.Sfl200Version,
					IsOnline:   true,
				}, &client.EquipCrudRes{}); err != nil {
					logger.Error("Update SFL200 Version err: ", err)
				}
			}
		}
	}
}

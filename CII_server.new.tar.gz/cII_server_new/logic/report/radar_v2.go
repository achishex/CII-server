package report

import (
	"context"
	"fmt"
	"reflect"
	"sync"
	"time"

	"adasgitlab.autel.com/tools/cuav_plugin/broker"
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/slink_proto/slinkv2/generatecode/golang/bizproto"
	"adasgitlab.autel.com/tools/slink_proto/slinkv2/msgid"
	jsoniter "github.com/json-iterator/go"
	"google.golang.org/protobuf/proto"

	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/helper"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/proto/mavlink"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
	"adasgitlab.autel.com/tools/cuav_server/rpc/cmdhandler"
	"adasgitlab.autel.com/tools/cuav_server/rpc/codec"
)

// TrackInfoV2 追踪目标信息上报
func TrackInfoV2(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	if sn == "" {
		logger.Errorf("TrackInfoV2 radar sn is null")
		return nil, fmt.Errorf("TrackInfoV2 radar sn is null")
	}
	UpdateStatus(sn, common.DEV_RADAR)

	radarTrackResp, ok := data.(*bizproto.RadarTrack)
	if !ok {
		logger.Errorf("TrackInfoV2 covert RadarTrack err")
		return nil, fmt.Errorf("TrackInfoV2 covert RadarTrack err")
	}
	logger.Infof("TrackInfoV2 response %+v", radarTrackResp)

	var radarLongitude, radarLatitude float64
	if value, ok := handler.RadarLocationMap.Load(sn); !ok {
		logger.Errorf("TrackInfoV2 radar %s location is nil", sn)
	} else {
		if val, ok := value.(*handler.RadarLocation); !ok {
			logger.Errorf("TrackInfoV2 radar %s location type is error, got: %v", sn, reflect.TypeOf(value))
		} else {
			radarLongitude = val.Longitude
			radarLatitude = val.Latitude
		}
	}

	if radarLongitude == 0 && radarLatitude == 0 {
		// 如果设备的经纬度同时为0时，使用C2的经纬度计算无人机的经纬度
		configRes := &client.ConfigRes{}
		if err := handler.NewSystemConfig().GetSystemConfig(context.Background(), &client.ConfigReq{}, configRes); err != nil {
			logger.Errorf("TrackInfoV2 failed to get system config: %v", err)
		} else {
			radarLongitude = configRes.C2Longitude
			radarLatitude = configRes.C2Latitude
		}
	}

	radarTrackItems := radarTrackResp.Item
	if len(radarTrackItems) <= 0 {
		return nil, nil
	}
	plotTracks := make([]common.DbRawAutelRadarPlotTrackBodyEntity, 0)
	for i := 0; i < len(radarTrackItems); i++ {
		if radarTrackItems[i].StateType == 0 {
			continue
		}
		//x,y 转换成经纬度
		//point := common.Coord3D{
		//	X: float64(radarTrackItems[i].X),
		//	Y: float64(radarTrackItems[i].Y),
		//	Z: float64(radarTrackItems[i].Z),
		//}

		var droneLongitude, droneLatitude float64
		//droneLongitude, droneLatitude = common.ConvertToLatLon(radarLongitude, radarLatitude, point)
		//distance := common.CuaDistance(droneLatitude, droneLongitude, radarLatitudeV2, radarLongitudeV2)

		latLng, err := common.GetLatLngByXY(common.LatLng{
			Latitude:  radarLatitude,
			Longitude: radarLongitude,
		}, -float64(radarTrackItems[i].Y), float64(radarTrackItems[i].X))
		if err != nil {
			logger.Errorf("TrackInfoV2 GetLatLngByXY err: %v", err)
		} else {
			droneLongitude, droneLatitude = latLng.Longitude, latLng.Latitude
		}

		tmp := common.DbRawAutelRadarPlotTrackBodyEntity{
			Obj_id:            radarTrackItems[i].Id,
			Azimuth:           float64(radarTrackItems[i].Azimuth),
			Obj_dist_interpol: 0,
			Elevation:         float64(radarTrackItems[i].Elevation),
			Velocity:          float64(radarTrackItems[i].Velocity),
			Ambiguous:         int16(radarTrackItems[i].Ambiguous),
			Classification:    int16(radarTrackItems[i].Classification),
			Classfy_prob:      float64(radarTrackItems[i].ClassifyProb),
			ExistingProb:      float32(radarTrackItems[i].ExistingProb),
			Abs_vel:           float64(radarTrackItems[i].AbsVel),
			Orientation_angle: float64(radarTrackItems[i].OrientationAngle),
			Alive:             helper.TranBaseType[uint16, float32](radarTrackItems[i].Alive),
			Tws_tas_flag:      uint16(radarTrackItems[i].TwsTasFlag),
			X:                 float64(radarTrackItems[i].X),
			Y:                 float64(radarTrackItems[i].Y),
			Z:                 float64(radarTrackItems[i].Z),
			VX:                float64(radarTrackItems[i].Vx),
			VY:                float64(radarTrackItems[i].Vy),
			VZ:                float64(radarTrackItems[i].Vz),
			AX:                float64(radarTrackItems[i].Ax),
			AY:                float64(radarTrackItems[i].Ay),
			AZ:                float64(radarTrackItems[i].Az),
			X_variance:        float64(radarTrackItems[i].XVariance),
			Y_variance:        float64(radarTrackItems[i].YVariance),
			Z_variance:        float64(radarTrackItems[i].ZVariance),
			Vx_variance:       float64(radarTrackItems[i].VxVariance),
			Vy_variance:       float64(radarTrackItems[i].VyVariance),
			Vz_variance:       float64(radarTrackItems[i].VzVariance),
			Ax_variance:       float64(radarTrackItems[i].AxVariance),
			Ay_variance:       float64(radarTrackItems[i].AyVariance),
			Az_variance:       float64(radarTrackItems[i].AzVariance),
			State_type:        int16(radarTrackItems[i].StateType),
			Motion_type:       int16(radarTrackItems[i].MotionType),
			Forcast_frame_num: int16(radarTrackItems[i].ForcastFrameNum),
			Association_num:   int16(radarTrackItems[i].AssociationNum),
			Assoc_bit0:        radarTrackItems[i].AssocBit0,
			Assoc_bit1:        radarTrackItems[i].AssocBit1,
			Longitude:         common.Decimal(droneLongitude, 7),
			Latitude:          common.Decimal(droneLatitude, 7),
			//Distance:          distance,
		}

		tmp.DroneName = fmt.Sprintf("%s%d", handler.GenerateNamePrefix(int(tmp.Classification)), tmp.Obj_id)
		//告警过滤
		if tmp.Classification == 0x01 || tmp.Classification == 0x05 {
			//计算无人机威胁等级
			fd, err := handler.NewAlarmControl().GetDroneThreatLevel(&handler.GetThreatLevelReq{
				DroneSn:        "",
				DroneObjId:     int64(radarTrackItems[i].Id),
				DroneLongitude: droneLongitude,
				DroneLatitude:  droneLatitude,
				DevSn:          sn,
			})
			if err != nil {
				logger.Errorf("TrackInfoV2 get drone threat level error, droneId: %d, err: %v", radarTrackItems[i].Id, err)
			} else {
				tmp.AlarmId = fd.AlarmId
				tmp.EventId = fd.EventId
				tmp.ThreatLevel = fd.ThreatLevel
				tmp.ScenesId = fd.ScenesId
			}
		}

		plotTracks = append(plotTracks, tmp)
	}
	if len(plotTracks) <= 0 {
		return nil, nil
	}
	//atomic.AddInt64(&handler.RadarSpace, 1)
	//temp := atomic.LoadInt64(&handler.RadarSpace)
	//if temp == 9 {
	//	atomic.StoreInt64(&handler.RadarSpace, 0)
	//	logger.Info("Radar detect send ")
	//} else {
	//	logger.Info("Radar detect space ")
	//	return nil, nil
	//}

	equipModel, err := handler.GetEquipBySn(sn)
	name := sn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	radarTrackMsg := &common.EquipmentMessageBoxEntity{
		Name:      name,
		Sn:        sn,
		Info:      plotTracks,
		EquipType: int(common.DEV_RADAR),
		MsgType:   msgid.RadarIdV2Track,
	}
	if err == nil {
		radarTrackMsg.ParentSn = equipModel.ParentSn
		radarTrackMsg.ParentType = equipModel.ParentType
		radarTrackMsg.IsIntegrated = equipModel.IsIntegrated
	}
	_ = mq.RadarTrackBroker.Publish(mq.RadarTrackTopic, broker.NewMessage(radarTrackMsg))

	//收到雷达侦测到无人机数据，向数据库记录当天有记录
	_, exist := handler.RadarReplayMap.Get(sn)
	if !exist {
		handler.RadarReplayMap.Set(sn, sn, true)
		time1 := time.Now()
		resTime := time1.Format("20060102")
		handler.NewDevSchedule().Insert(context.Background(), &client.DevScheduleInsertReq{Sn: sn, Date: resTime, Information: 1}, &client.DevScheduleInsertRsp{})
	}

	go func() {
		handler.RadarDetectEvent(sn, plotTracks)
	}()

	logger.Info("TrackInfoV2 追踪目标信息上报: %v", plotTracks)
	return radarTrackResp, nil
}

// StateInfoV2 雷达状态信息上报
func StateInfoV2(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	radarStateResp, ok := data.(*bizproto.RadarState)
	if !ok {
		logger.Errorf("covert RadarState err")
		return nil, fmt.Errorf("covert RadarState err")
	}
	logger.Infof("StateInfoV2 response %+v", radarStateResp)

	if sn == "" {
		logger.Errorf("StateInfoV2 radar sn is null")
		return nil, fmt.Errorf("StateInfoV2 radar sn is null")
	}
	if radarStateResp != nil && radarStateResp.RadarLLA != nil {
		handler.RadarLocationMap.Store(sn, &handler.RadarLocation{
			Longitude: radarStateResp.RadarLLA.GetLatitude(),
			Latitude:  radarStateResp.RadarLLA.GetLongitude(),
		})
	}
	UpdateStatus(sn, common.DEV_RADAR)

	wg := &sync.WaitGroup{}
	wg.Add(3)
	// 雷达上传心跳包
	go reportRadarHeart(ctx, sn, radarStateResp, wg)
	// 波控配置信息上报
	go reportRadarBeamSteer(sn, radarStateResp, wg)
	// 雷达姿态信息上报
	go reportRadarPosture(sn, radarStateResp, wg)
	wg.Wait()

	return radarStateResp, nil
}

// MaskInfoV2 mask发生变化时，雷达会全量上报mask信息
func MaskInfoV2(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	radarMaskInfo, ok := data.(*bizproto.RadarC2Mask)
	if !ok {
		logger.Errorf("covert RadarC2Mask err")
		return nil, fmt.Errorf("covert RadarC2Mask err")
	}
	logger.Infof("MaskInfoV2 response %+v", radarMaskInfo)

	if sn == "" {
		logger.Errorf("MaskInfoV2 radar sn is null")
		return nil, fmt.Errorf("MaskInfoV2 radar sn is null")
	}

	UpdateStatus(sn, common.DEV_RADAR)
	itemMaskByte, err := jsoniter.Marshal(radarMaskInfo.ItemMask)
	if err != nil {
		logger.Errorf("MaskInfoV2 jsoniter.Marshal err: %v", err)
		return radarMaskInfo, err
	}
	isDel := radarMaskInfo.GetAllDelete() == 1
	allDelVal := radarMaskInfo.GetAllDelete()
	if allDelVal == 2 {
		allDelVal = 0
	} else if allDelVal == 3 {
		allDelVal = 1
	}
	//保存数据库
	if err = handler.NewRadarMaskModel().Insert(radarMaskInfo.GetSn(), string(itemMaskByte), isDel, int32(allDelVal)); err != nil {
		logger.Errorf("MaskInfoV2 insert radar mask err: %v", err)
		return radarMaskInfo, err
	}
	return radarMaskInfo, nil
}

func reportRadarHeart(ctx context.Context, sn string, radarStateResp *bizproto.RadarState, wg *sync.WaitGroup) {
	defer wg.Done()
	radarHeart := &common.RadarStatusEntity{
		Electricity: int32(radarStateResp.GetElectricity()),
		Status:      int(radarStateResp.GetStatus()),
		IsOnline:    common.DevOnline,
		SerialNum:   sn,
		SysStatus:   int32(radarStateResp.GetSysStatus()),
		VersionType: int32(codec.VersionTypeV2),
	}
	// TODO: 每次姿态上报都要去查表，需要优化
	//equipList := &client.EquipListRes{}
	//err := handler.NewEquipList().List(ctx, &client.EquipListReq{}, equipList)
	//if err != nil {
	//	logger.Errorf("StateInfoV2 get EquipList err: %v", err)
	//}
	//for _, equip := range equipList.Equips {
	//	if equip.Sn == sn {
	//		radarHeart.Ip = equip.Ip
	//	}
	//}

	equipModel, err := handler.GetEquipBySn(sn)
	if equipModel != nil {
		radarHeart.Ip = equipModel.Ip
	}
	name := sn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	radarHeartMsg := &common.EquipmentMessageBoxEntity{
		Name:      name,
		Sn:        sn,
		EquipType: int(common.DEV_RADAR),
		MsgType:   mavlink.RadarIdHeartbeat,
		Info:      radarHeart,
	}
	if err == nil {
		radarHeartMsg.ParentType = equipModel.ParentType
		radarHeartMsg.ParentSn = equipModel.ParentSn
		radarHeartMsg.IsIntegrated = equipModel.IsIntegrated
	}
	_ = mq.EquipmentStatusBroker.Publish(mq.EquipmentStatusTopic, broker.NewMessage(radarHeartMsg))
	// 雷达v2上报在线事件
	handler.RadarOnlineEvent(sn, radarHeart)
	logger.Infof("Radar Heart has reported, devSn: %+v,report:%+v,radarHeart:%+v", sn, radarHeartMsg, radarHeart)
}

func reportRadarBeamSteer(sn string, radarStateResp *bizproto.RadarState, wg *sync.WaitGroup) {
	defer wg.Done()
	aziScanCenter := radarStateResp.GetAziScanCenter()
	aziScanScope := radarStateResp.GetAziScanScope()
	eleScanScope := radarStateResp.GetEleScanScope()
	eleScanCenter := radarStateResp.GetEleScanCenter()
	radarScanRadius := helper.TranBaseType[int32, uint32](radarStateResp.GetRadarScanRadius())

	equipModel, err := handler.GetEquipBySn(sn)
	name := sn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	radarBeamSteerCfg := &client.RadarBeamSteerConfig{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        sn,
			EquipType: int32(common.DEV_RADAR),
			MsgType:   mavlink.RadarIdGetBeamSteerInfo,
		},
		Data: &client.RadarUploadBeamConfigEntity{
			AziScanCenter:   &aziScanCenter,
			AziScanScope:    &aziScanScope,
			EleScanCenter:   &eleScanCenter,
			EleScanScope:    &eleScanScope,
			RadarScanRadius: &radarScanRadius,
		},
	}
	if err == nil {
		radarBeamSteerCfg.Header.ParentType = int32(equipModel.ParentType)
		radarBeamSteerCfg.Header.ParentSn = equipModel.ParentSn
		radarBeamSteerCfg.Header.IsIntegrated = equipModel.IsIntegrated
	}
	radarBeamSteerMsg, err := proto.Marshal(radarBeamSteerCfg)
	if err != nil {
		logger.Errorf("StateInfoV2 marshal radarBeamSteerCfg err: %v", err)
	} else {
		radarBeamSteerReport := &client.ClientReport{
			MsgType: common.ClientMsgIDRadarBeamConfigData,
			Data:    radarBeamSteerMsg,
		}
		out, err := proto.Marshal(radarBeamSteerReport)
		if err != nil {
			logger.Errorf("StateInfoV2 marshal radarBeamSteerReport err: %v", err)
		} else {
			_ = mq.RadarBeamConfigBroker.Publish(mq.RadarBeamConfigTopic, broker.NewMessage(out))

			logger.Infof("Radar Beam has reported, devSn: %+v,report:%+v,radarBeamSteerCfg:%+v", sn, radarBeamSteerReport, radarBeamSteerCfg)
		}
	}
}

func reportRadarPosture(sn string, radarStateResp *bizproto.RadarState, wg *sync.WaitGroup) {
	defer wg.Done()
	if radarStateResp != nil && radarStateResp.Attitude != nil {
		if radarStateResp.GetAttitude().GetHeading() > handler.HeadingRan {
			logger.Errorf("雷达姿态异常数据: %+v", radarStateResp)
			// return nil, fmt.Errorf("雷达姿态异常数据")
		} else {
			var (
				isIntegrated int32
				parentType   int
				parentSn     string
			)
			// 雷达上报姿态信息
			equipModel, err := handler.GetEquipBySn(sn)
			name := sn
			if equipModel != nil && equipModel.Name != "" {
				name = equipModel.Name
			}
			if err == nil {
				isIntegrated = equipModel.IsIntegrated
				parentType = equipModel.ParentType
				parentSn = equipModel.ParentSn
			}
			temp := radarStateResp.GetAttitude().GetHeading()
			//只有雷达在非一体化雷视下，才需要补偿
			if parentSn != "" {
				parentEquip, err := handler.GetEquipBySn(parentSn)
				if err == nil {
					if parentEquip != nil && parentEquip.IsIntegrated == 0 {
						temp = radarStateResp.GetAttitude().GetHeading() + float64(handler.TempHeading)
					}
				}
			}
			radarPostureMsg := &common.EquipmentMessageBoxEntity{
				Name:         name,
				Sn:           sn,
				EquipType:    int(common.DEV_RADAR),
				MsgType:      mavlink.RadarIdUploadPosture,
				ParentType:   parentType,
				ParentSn:     parentSn,
				IsIntegrated: isIntegrated,
				Info: common.RadarUploadPostureEntity{
					Heading:   temp,
					Pitching:  radarStateResp.GetAttitude().GetPitching(),
					Rolling:   radarStateResp.GetAttitude().GetRolling(),
					Longitude: radarStateResp.GetRadarLLA().GetLongitude(),
					Latitude:  radarStateResp.GetRadarLLA().GetLatitude(),
					Altitude:  radarStateResp.GetRadarLLA().GetAltitude(),
				},
			}

			_ = mq.RadarPostureBroker.Publish(mq.RadarPostureTopic, broker.NewMessage(radarPostureMsg))
			logger.Infof("Radar Posture has reported, devSn: %+v,report:%+v", sn, radarPostureMsg)
		}
	}
}

func init() {
	cmdhandler.Instance().RegisterHandler(common.DEV_RADAR, msgid.RadarIdV2Track, TrackInfoV2)
	cmdhandler.Instance().RegisterHandler(common.DEV_RADAR, msgid.RadarIdV2State, StateInfoV2)
	cmdhandler.Instance().RegisterHandler(common.DEV_RADAR, msgid.RadarIdV2Mask, MaskInfoV2)
}

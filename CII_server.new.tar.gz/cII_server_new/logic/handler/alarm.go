package handler

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"math"
	"reflect"
	"strconv"
	"sync"
	"sync/atomic"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	geo "github.com/kellydunn/golang-geo"
	"github.com/paulmach/orb"
	"github.com/paulmach/orb/geojson"
	"github.com/paulmach/orb/planar"
	"gorm.io/gorm"

	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/utils"
)

const (
	noFences        = 1
	onlySetWarnArea = 2
	onlySetCoreArea = 3
	setWarnAndCore  = 4

	highUpper   = 100
	highLower   = 80
	middleUpper = 79
	middleLower = 50
	lowUpper    = 49
	lowLower    = 1
	//1-预警区 2-核心区
	warnAreaType = 1
	coreAreaType = 2

	twoHundredThreshold  = 200
	fiveHundredThreshold = 500
	twoThousandThreshold = 2000
)

var (
	IsAlarmMap sync.Map
	//存储drone到eventId的映射
	droneToEventIdMap sync.Map
	expirationMap     sync.Map
)

// mapWithExpiration 结构体用于存储键值对和过期时间
type mapWithExpiration struct {
	//存储drone到eventId的映射
	droneToEventIdMap sync.Map
	expirationMap     sync.Map
}

type GetThreatLevelReq struct {
	DroneSn        string
	DroneObjId     int64
	DroneLongitude float64
	DroneLatitude  float64
	DevSn          string
}

type AlarmControl struct{}

func NewAlarmControl() *AlarmControl {
	return &AlarmControl{}
}

type FenceDistance struct {
	AlarmId     string  `json:"alarmId"`
	FenceId     int64   `json:"fenceId"`
	Distance    float64 `json:"distance"`
	ThreatLevel int32   `json:"threatLevel"`
	ScenesId    int32   `json:"scenesId"`
	EventId     string  `json:"eventId"`
}

type Coordinate struct {
	Latitude  float64
	Longitude float64
}

type Point struct {
	X float64
	Y float64
}

// inPolygon 判断目标是否在给定的围栏区内
func (a *AlarmControl) inPolygon(geoJsonStr string, droneLongitude, droneLatitude float64) (bool, error) {
	feature, err := geojson.UnmarshalFeature([]byte(geoJsonStr))
	if err != nil {
		logger.Errorf("inPolygon UnmarshalFeature failed, err: %v", err)
		return false, err
	}
	polygons, err := unmarshalToOrbPolygon(feature.Geometry, feature.Geometry.GeoJSONType())
	if err != nil {
		logger.Errorf("inPolygon unmarshalToOrbPolygon failed, err: %v", err)
		return false, err
	}
	//logger.Debugf("inPolygon polygons: %+v", polygons)
	for _, fence := range polygons {
		contains := planar.PolygonContains(fence, orb.Point{droneLongitude, droneLatitude})
		if contains {
			logger.Debugf("inPolygon Point is in polygon: %v", contains)
			return true, err
		}
	}
	//contains := feature.Geometry.Bound().Contains(orb.Point{droneLongitude, droneLatitude})
	return false, nil
}

// unmarshalToOrbPolygon 将数据库geometry字段反序列化成orb.Polygon
func unmarshalToOrbPolygon(geometry orb.Geometry, geoJsonType string) ([]orb.Polygon, error) {
	polygons := make([]orb.Polygon, 0)
	if geoJsonType == "Polygon" {
		rings := make([]orb.Ring, 0)
		geometryByte, err := json.Marshal(geometry)
		if err != nil {
			logger.Errorf("inPolygon Marshal Geometry failed, err: %v", err)
			return nil, err
		}
		if err = json.Unmarshal(geometryByte, &rings); err != nil {
			logger.Errorf("inPolygon Unmarshal Ring failed, err: %v", err)
			return nil, err
		}
		for i := range rings {
			polygons = append(polygons, orb.Polygon{rings[i]})
		}
	} else if geoJsonType == "MultiPolygon" {
		rings := make([][]orb.Ring, 0)
		geometryByte, err := json.Marshal(geometry)
		if err != nil {
			logger.Errorf("inPolygon Marshal Geometry failed, err: %v", err)
			return nil, err
		}
		if err = json.Unmarshal(geometryByte, &rings); err != nil {
			logger.Errorf("inPolygon Unmarshal Ring failed, err: %v", err)
			return nil, err
		}
		for i := range rings {
			for j := range rings[i] {
				polygons = append(polygons, orb.Polygon{rings[i][j]})
			}
		}
	}
	return polygons, nil
}

// noFenceGetDistance 用户未设置围栏，计算目标到C2的距离
func (a *AlarmControl) noFenceGetDistance(droneLongitude, droneLatitude float64) (*FenceDistance, error) {
	configRes := &client.ConfigRes{}
	if err := NewSystemConfig().GetSystemConfig(context.Background(), &client.ConfigReq{}, configRes); err != nil {
		logger.Errorf("noFence failed to get system config: %v", err)
		return nil, err
	}
	//计算目标到C2的距离
	distance := geoDistance(droneLongitude, droneLatitude, configRes.C2Longitude, configRes.C2Latitude)
	logger.Debugf("noFenceGetThreatLevel user has not set a fence, distance: %v", distance)
	threatLevel := calculateThreatLevel(distance, noFences)
	fd := &FenceDistance{
		Distance:    distance,
		ThreatLevel: threatLevel,
		ScenesId:    noFences,
	}
	return fd, nil
}

// singleFenceGetDistance 用户只设置了预警区或者核心区
func (a *AlarmControl) singleFenceGetDistance(droneLongitude, droneLatitude float64, fences []*bean.Fences) (*FenceDistance, error) {
	var (
		count       int
		threatLevel int32 = lowUpper
		fenceId     int64
		intersect   bool
		fd          FenceDistance
	)
	logger.Debug("singleFenceGetTLevel user only set a single fence")
	for i := range fences {
		//判断目标是否进入围栏区内
		contains, err := a.inPolygon(fences[i].Geometry, droneLongitude, droneLatitude)
		if err != nil {
			logger.Errorf("singleFenceGetTLevel inPolygon err: %v", err)
			continue
		}
		if contains {
			threatLevel = highUpper
			fenceId = fences[i].ID
			count++
			logger.Debugf("singleFenceGetTLevel drone is in fence id: %d, name: %s", fences[i].ID, fences[i].Name)
			break
		}
	}
	//目标未进入围栏区内，计算目标到围栏区的最近距离
	if count == 0 {
		droneCoordinate := Coordinate{
			Latitude:  droneLatitude,
			Longitude: droneLongitude,
		}
		// 计算无人机形成的圆
		dronePoint, droneRadius := calculateDroneCircle(droneCoordinate, fiveHundredThreshold)

		for i := range fences {
			polygons, err := unmarshalToPoint(fences[i].Geometry)
			if err != nil {
				logger.Errorf("singleFenceGetTLevel unmarshalToOrbPolygon err: %v", err)
				continue
			}
			logger.Debugf("singleFenceGetTLevel unmarshalToOrbPolygon polygons: %+v", polygons)
			for _, polygon := range polygons {
				//判断圆与多边形是否有交集
				intersect = CirclePolygonIntersect(dronePoint, droneRadius, polygon)
				logger.Debugf("singleFenceGetTLevel checkIntersection: %v", intersect)
				if intersect {
					logger.Debugf("singleFenceGetTLevel checkIntersection fence id: %d, name: %s", fences[i].ID, fences[i].Name)
					fd.ThreatLevel = middleUpper
					fd.FenceId = fences[i].ID
					return &fd, nil
				}
			}
		}
	}
	fd.FenceId = fenceId
	fd.ThreatLevel = threatLevel
	return &fd, nil
}

// getDistanceWithinWarnAndCore 用户已设置预警区和核心区
func (a *AlarmControl) getDistanceWithinWarnAndCore(droneLongitude, droneLatitude float64, fences []*bean.Fences) (*FenceDistance, error) {
	var (
		count       int
		threatLevel int32
		fenceId     int64
		intersect   bool
		fd          FenceDistance
	)
	logger.Debug("getThreatLevel user has set warn area and core area")
	for i := range fences {
		//判断目标是否进入核心区
		if fences[i].AreaType == coreAreaType {
			contains, err := a.inPolygon(fences[i].Geometry, droneLongitude, droneLatitude)
			if err != nil {
				logger.Errorf("getDistanceWithinWarnAndCore inPolygon err: %v", err)
				continue
			}
			if contains {
				threatLevel = highUpper
				fenceId = fences[i].ID
				count++
				logger.Debugf("getDistanceWithinWarnAndCore enter the core area fence: %d, ", fences[i].ID)
				break
			}
		}
	}

	//目标未进入核心区，计算目标到核心区的最近距离
	if count == 0 {
		droneCoordinate := Coordinate{
			Latitude:  droneLatitude,
			Longitude: droneLongitude,
		}
		// 计算目标到核心区的最近距离是否<=500m
		dronePoint, droneRadius := calculateDroneCircle(droneCoordinate, fiveHundredThreshold)

		for i := range fences {
			if fences[i].AreaType == coreAreaType {
				polygons, err := unmarshalToPoint(fences[i].Geometry)
				if err != nil {
					logger.Errorf("getDistanceWithinWarnAndCore unmarshalToOrbPolygon err: %v", err)
					continue
				}
				//logger.Debugf("getDistanceWithinWarnAndCore unmarshalToOrbPolygon polygons: %+v", polygons)
				for _, polygon := range polygons {
					// 判断圆与多边形是否有交集
					intersect = CirclePolygonIntersect(dronePoint, droneRadius, polygon)
					if intersect {
						logger.Debugf("getDistanceWithinWarnAndCore CirclePolygonIntersect nearest distance less than 500m fence id: %d, name: %s", fences[i].ID, fences[i].Name)
						fd.ThreatLevel = 90
						fd.FenceId = fences[i].ID
						return &fd, nil
					}
				}
			}
		}

		// 判断目标到核心区的距离介于500m至2000m时
		droneRadius = twoThousandThreshold
		for i := range fences {
			if fences[i].AreaType == coreAreaType {
				polygons, err := unmarshalToPoint(fences[i].Geometry)
				if err != nil {
					logger.Errorf("getDistanceWithinWarnAndCore unmarshalToOrbPolygon err: %v", err)
					continue
				}
				logger.Debugf("getDistanceWithinWarnAndCore unmarshalToOrbPolygon polygons: %+v", polygons)
				for _, polygon := range polygons {
					// 判断圆与多边形是否有交集
					intersect = CirclePolygonIntersect(dronePoint, droneRadius, polygon)
					if intersect {
						logger.Debugf("getDistanceWithinWarnAndCore CirclePolygonIntersect nearest distance less than  2000m fence id: %d, name: %s", fences[i].ID, fences[i].Name)
						fd.ThreatLevel = middleUpper
						fd.FenceId = fences[i].ID
						return &fd, nil
					}
				}
			}
		}

		//判断目标是否进入预警区
		for i := range fences {
			if fences[i].AreaType == warnAreaType {
				//判断目标是否进入围栏区内
				contains, err := a.inPolygon(fences[i].Geometry, droneLongitude, droneLatitude)
				if err != nil {
					logger.Errorf("getDistanceWithinWarnAndCore inPolygon err: %v", err)
					continue
				}
				if contains {
					threatLevel = lowUpper
					fenceId = fences[i].ID
					logger.Debugf("getDistanceWithinWarnAndCore enters warn area in fence: %d", fences[i].ID)
					break
				}
			}
		}
	}

	fd.FenceId = fenceId
	fd.ThreatLevel = threatLevel
	fd.ScenesId = setWarnAndCore
	return &fd, nil
}

// getFenceDistance 计算目标到围栏区的距离
func (a *AlarmControl) getFenceDistance(droneLongitude, droneLatitude float64) (*FenceDistance, error) {
	fences, _, err := NewFenceModel().List(1000, 1)
	if err != nil {
		logger.Errorf("getFenceDistance failed to get fence list: %v", err)
		return nil, err
	}

	logger.Debugf("getFenceDistance fences length: %v", len(fences))
	//1. 若用户未设置围栏区
	//低威胁等级：目标距C2大于等于500m时。
	//中威胁等级：目标距C2 200至500m时。
	//高威胁等级：目标距C2小于等于200m时。
	if len(fences) == 0 {
		fd, err := a.noFenceGetDistance(droneLongitude, droneLatitude)
		if err != nil {
			logger.Errorf("getFenceDistance noFenceGetThreatLevel err: %v", err)
			return nil, err
		}
		return fd, nil
	}

	var warnCount, coreCount int
	for i := range fences {
		if fences[i].AreaType == warnAreaType {
			warnCount++
		} else if fences[i].AreaType == coreAreaType {
			coreCount++
		}
	}
	//2. 若用户已设置预警区但未设核心区
	//低威胁等级：目标进入侦测范围时。
	//中威胁等级：目标到预警区的最近距离小于等于500m时。
	//高威胁等级：目标进入预警区时。

	fencesCount := len(fences)
	if warnCount == fencesCount {
		fd, err := a.singleFenceGetDistance(droneLongitude, droneLatitude, fences)
		if err != nil {
			logger.Errorf("getFenceDistance onlySetWarnGetTLevel err: %v", err)
			return nil, err
		}
		fd.ScenesId = onlySetWarnArea
		return fd, nil
	}

	//3. 若用户已设置核心区但未设预警区
	//低威胁等级：目标进入侦测范围时。
	//中威胁等级：目标到核心区的最近距离小于等于500m时。
	//高威胁等级：目标进入核心区时。
	if coreCount == fencesCount {
		fd, err := a.singleFenceGetDistance(droneLongitude, droneLatitude, fences)
		if err != nil {
			logger.Errorf("getFenceDistance onlySetWarnGetTLevel err: %v", err)
			return nil, err
		}
		fd.ScenesId = onlySetCoreArea
		return fd, nil
	}
	//4. 若用户已设置预警区和核心区
	//无威胁等级（不触发告警）：目标在侦测范围内，但不在预警区内时。
	//低威胁等级：目标进入预警区时。
	//中威胁等级：目标到核心区的距离介于500m至2000m时。
	//高威胁等级：目标到核心区的最近距离小于等于500m及进入核心区时。
	fd, err := a.getDistanceWithinWarnAndCore(droneLongitude, droneLatitude, fences)
	if err != nil {
		logger.Errorf("getFenceDistance getThreatLevel err: %v", err)
		return nil, err
	}
	return fd, nil
}

func (a *AlarmControl) GetDroneThreatLevel(req *GetThreatLevelReq) (*FenceDistance, error) {
	logger.Debugf("GetDroneThreatLevel req %+v", req)
	if req.DroneSn == "" && req.DroneObjId == 0 {
		return nil, errors.New("drone sn or obj id is empty")
	}
	// tracer在智园经纬度为0，0，默认使用C2经纬度
	if req.DroneLongitude == 0 && req.DroneLatitude == 0 {
		res := &client.ConfigRes{}
		err := NewSystemConfig().GetSystemConfig(context.Background(), &client.ConfigReq{}, res)
		if err != nil || res == nil {
			logger.Errorf("GetDroneThreatLevel GetSystemConfig err: %v", err)
		} else {
			req.DroneLongitude = res.C2Longitude
			req.DroneLatitude = res.C2Latitude
		}
	}
	getDistanceRsp, err := a.getFenceDistance(req.DroneLongitude, req.DroneLatitude)
	if err != nil {
		logger.Errorf("GetDroneThreatLevel getFenceDistance err: %v", err)
		return nil, err
	}
	//logger.Debugf("GetDroneThreatLevel getFenceDistance rsp: %+v", getDistanceRsp)
	eventId := a.generateEventId(req.DroneSn, req.DevSn, req.DroneObjId)

	//插入数据库
	alarm := bean.Alarm{
		DroneSn:     req.DroneSn,
		DroneObjId:  req.DroneObjId,
		EventId:     eventId,
		FenceId:     getDistanceRsp.FenceId,
		Distance:    getDistanceRsp.Distance,
		ThreatLevel: getDistanceRsp.ThreatLevel,
		CreateTime:  utils.ParseTimeToString(time.Now()),
		ScenesId:    getDistanceRsp.ScenesId,
	}

	isAlarmKey := fmt.Sprintf("%s_%d_%d_%d", req.DroneSn, req.DroneObjId, getDistanceRsp.ThreatLevel, eventId)
	valI, ok := IsAlarmMap.Load(isAlarmKey)
	if !ok {
		alarmModel, err := NewAlarmModel().Last(req.DroneSn, getDistanceRsp.ThreatLevel, eventId, req.DroneObjId)
		if err != nil {
			if err == gorm.ErrRecordNotFound {
				alarmId, err := NewAlarmModel().Insert(alarm)
				if err != nil {
					logger.Errorf("GetDroneThreatLevel Insert err: %v", err)
					return nil, err
				}

				fd := FenceDistance{
					AlarmId:     strconv.FormatInt(alarmId, 10),
					FenceId:     getDistanceRsp.FenceId,
					Distance:    getDistanceRsp.Distance,
					ThreatLevel: getDistanceRsp.ThreatLevel,
					ScenesId:    getDistanceRsp.ScenesId,
					EventId:     strconv.FormatInt(eventId, 10),
				}
				IsAlarmMap.Store(isAlarmKey, &fd)
				logger.Info("GetDroneThreatLevel fd: %+v", fd)
				return &fd, nil
			}
			logger.Error("GetDroneThreatLevel failed to get alarm: ", err)
			return nil, err
		}

		fd := &FenceDistance{
			AlarmId:     strconv.FormatInt(alarmModel.ID, 10),
			FenceId:     alarmModel.FenceId,
			Distance:    alarmModel.Distance,
			ThreatLevel: alarmModel.ThreatLevel,
			ScenesId:    alarmModel.ScenesId,
			EventId:     strconv.FormatInt(alarmModel.EventId, 10),
		}
		IsAlarmMap.Store(isAlarmKey, fd)
		return fd, nil
	}

	fd, ok := valI.(*FenceDistance)
	if ok {
		return fd, nil
	}
	return nil, fmt.Errorf("GetDroneThreatLevel value type err: %v", ok)
}

func (a *AlarmControl) generateEventId(droneSn, devSn string, objId int64) int64 {
	var (
		eventId        int64
		alarmStartTime string //告警开始时间
		//todo: eventId过期时间与胡哥约定
		expireTime = 5 * time.Second
		err        error
	)
	cacheKey := fmt.Sprintf("%s_%s_%d", droneSn, devSn, objId)
	valueI, ok := droneToEventIdMap.Load(cacheKey)
	if !ok {
		eventId, alarmStartTime, err = NewAlarmModel().Find(droneSn, objId)
		if err != nil {
			logger.Errorf("generateEventId Find err: %v", err)
		}
		if eventId != 0 {
			if time.Since(utils.StringToTime(alarmStartTime)) > expireTime {
				eventId = 0
			} else {
				droneToEventIdMap.Store(cacheKey, eventId)
				expirationMap.Store(cacheKey, time.Now().Add(expireTime))
			}
		}
	} else {
		if val, ok := valueI.(int64); !ok {
			logger.Errorf("generateEventId value type err, got: %v", reflect.TypeOf(valueI))
			eventId = 0
		} else {
			eventId = val
			expirationMap.Store(cacheKey, time.Now().Add(expireTime))
		}
	}

	if eventId == 0 {
		sessionId := time.Now().UnixMilli()
		eventId = atomic.AddInt64(&sessionId, 1)
		droneToEventIdMap.Store(cacheKey, eventId)
		expirationMap.Store(cacheKey, time.Now().Add(expireTime))
	}
	return eventId
}

// todo 固定等级分数待修改
// calculateThreatLevel 计算目标威胁等级
func calculateThreatLevel(distance float64, scenes int) int32 {
	switch scenes {
	case noFences:
		if distance >= fiveHundredThreshold {
			//低威胁等级
			return lowUpper
		} else if distance > twoHundredThreshold && distance < fiveHundredThreshold {
			//中威胁等级
			return int32((distance-twoHundredThreshold)/(fiveHundredThreshold-twoHundredThreshold)*(middleUpper-middleLower) + middleLower)
		} else {
			//高威胁等级
			return int32((twoHundredThreshold-distance)/twoHundredThreshold*(highUpper-highLower) + highLower)
		}
	case setWarnAndCore:
		if distance <= fiveHundredThreshold {
			// 高威胁等级
			return int32(highLower + int(float64(highUpper-highLower)*(fiveHundredThreshold-distance)/fiveHundredThreshold))
			// return highLower
		} else if distance <= twoThousandThreshold && distance > fiveHundredThreshold {
			// 中威胁等级
			return int32((distance-fiveHundredThreshold)/(twoThousandThreshold-fiveHundredThreshold)*(middleUpper-middleLower) + middleLower)
		}
	}
	return 0
}

// geoDistance 计算两个坐标之间的距离
func geoDistance(droneLongitude, droneLatitude, C2Longitude, C2Latitude float64) float64 {
	point1 := geo.NewPoint(droneLatitude, droneLongitude)
	point2 := geo.NewPoint(C2Latitude, C2Longitude)
	return point1.GreatCircleDistance(point2) * 1000
}

// 将经纬度转换为平面坐标
func convertToPlaneCoordinate(coordinate Coordinate) Point {
	radius := 6371000.0 // 地球半径（单位：米）
	latRad := coordinate.Latitude * (math.Pi / 180.0)
	lonRad := coordinate.Longitude * (math.Pi / 180.0)
	x := radius * lonRad * math.Cos(latRad)
	y := radius * latRad
	return Point{X: x, Y: y}
}

func CirclePolygonIntersect(circleCenter Point, radius float64, polygon []Point) bool {
	// 判断圆心是否在多边形内部
	if isPointInPolygon(circleCenter, polygon) {
		return true
	}

	// 判断圆与多边形的边是否有交点
	for i := 0; i < len(polygon); i++ {
		p1 := polygon[i]
		p2 := polygon[(i+1)%len(polygon)]
		if isSegmentCircleIntersect(p1, p2, circleCenter, radius) {
			return true
		}
	}

	return false
}

// 判断点是否在多边形内部
func isPointInPolygon(point Point, polygon []Point) bool {
	crosses := 0
	for i := 0; i < len(polygon); i++ {
		p1 := polygon[i]
		p2 := polygon[(i+1)%len(polygon)]
		if (point.Y < p2.Y && point.Y >= p1.Y) || (point.Y < p1.Y && point.Y >= p2.Y) {
			x := (point.Y-p1.Y)*(p2.X-p1.X)/(p2.Y-p1.Y) + p1.X
			if x > point.X {
				crosses++
			}
		}
	}
	return crosses%2 != 0
}

// 判断线段和圆是否有交点
func isSegmentCircleIntersect(p1, p2, circleCenter Point, radius float64) bool {
	d := distanceToSegment(circleCenter, p1, p2)
	return d <= radius
}

// 计算点到线段的最近距离
func distanceToSegment(p, p1, p2 Point) float64 {
	if p1.X == p2.X && p1.Y == p2.Y {
		return math.Sqrt((p.X-p1.X)*(p.X-p1.X) + (p.Y-p1.Y)*(p.Y-p1.Y))
	}
	dot := (p.X-p1.X)*(p2.X-p1.X) + (p.Y-p1.Y)*(p2.Y-p1.Y)
	t1 := dot / ((p2.X-p1.X)*(p2.X-p1.X) + (p2.Y-p1.Y)*(p2.Y-p1.Y))
	if t1 < 0 {
		return math.Sqrt((p.X-p1.X)*(p.X-p1.X) + (p.Y-p1.Y)*(p.Y-p1.Y))
	}
	if t1 > 1 {
		return math.Sqrt((p.X-p2.X)*(p.X-p2.X) + (p.Y-p2.Y)*(p.Y-p2.Y))
	}
	x := p1.X + t1*(p2.X-p1.X)
	y := p1.Y + t1*(p2.Y-p1.Y)
	return math.Sqrt((p.X-x)*(p.X-x) + (p.Y-y)*(p.Y-y))
}

// 计算无人机形成的圆
func calculateDroneCircle(droneCoordinate Coordinate, radius float64) (Point, float64) {
	dronePoint := convertToPlaneCoordinate(droneCoordinate)
	return dronePoint, radius
}

// unmarshalToPoint 将数据库geometry字段反序列化成Point
func unmarshalToPoint(geoJsonStr string) ([][]Point, error) {
	var polygons = make([][]Point, 0)
	feature, err := geojson.UnmarshalFeature([]byte(geoJsonStr))
	if err != nil {
		logger.Errorf("unmarshalToPoint UnmarshalFeature err: %v", err)
		return nil, err
	}
	geometryByte, err := json.Marshal(feature.Geometry)
	if err != nil {
		logger.Errorf("unmarshalToPoint marshal GeoJSON err: %v", err)
		return nil, err
	}
	//logger.Debugf("unmarshalToPoint geometryByte: %v", string(geometryByte))
	if feature.Geometry.GeoJSONType() == "Polygon" {
		points := [][]orb.Point{}
		if err = json.Unmarshal(geometryByte, &points); err != nil {
			logger.Errorf("unmarshalToPoint unmarshal Point err: %v", err)
			return nil, err
		}
		for i := range points {
			polygon := make([]Point, len(points[i]))
			coordinateList := make([]Coordinate, len(points[i]))
			for j := range points[i] {
				coordinateList[j] = Coordinate{Latitude: points[i][j].Lat(), Longitude: points[i][j].Lon()}
				polygon[j] = convertToPlaneCoordinate(coordinateList[j])
			}
			polygons = append(polygons, polygon)
		}
	} else if feature.Geometry.GeoJSONType() == "MultiPolygon" {
		points := [][][]orb.Point{}
		if err = json.Unmarshal(geometryByte, &points); err != nil {
			logger.Errorf("unmarshalToPoint unmarshal Point err: %v", err)
			return nil, err
		}
		for i := range points {
			for j := range points[i] {
				polygon := make([]Point, len(points[i][j]))
				coordinateList := make([]Coordinate, len(points[i][j]))
				for k, tmp := range points[i][j] {
					coordinateList[k] = Coordinate{Latitude: tmp[1], Longitude: tmp[0]}
					polygon[k] = convertToPlaneCoordinate(coordinateList[k])
				}
				polygons = append(polygons, polygon)
			}
		}
	}
	return polygons, nil
}

// min 返回数组中的最小值
func min(arr []float64) float64 {
	if len(arr) == 0 {
		return 0
	}
	minDist := arr[0]
	for _, tmp := range arr {
		if tmp < minDist {
			minDist = tmp
		}
	}
	return minDist
}

// Set 设置键值对，并指定过期时间
func (m *mapWithExpiration) Set(key, value interface{}, expiration time.Duration) {
	m.droneToEventIdMap.Store(key, value)
	m.expirationMap.Store(key, time.Now().Add(expiration))
}

// Get 获取键对应的值
func (m *mapWithExpiration) Get(key interface{}) (interface{}, bool) {
	value, ok := m.droneToEventIdMap.Load(key)
	if !ok {
		logger.Errorf("mapWithExpiration Get key not found: %v", key)
		return nil, false
	}
	expiration, _ := m.expirationMap.Load(key)
	expirationTime := expiration.(time.Time)
	if time.Now().Before(expirationTime) {
		// 如果在过期时间内，更新过期时间
		m.expirationMap.Store(key, time.Now().Add(expirationTime.Sub(time.Now())))
		return value, true
	}
	logger.Errorf("mapWithExpiration Get key expired: %v", key)
	m.Delete(key)
	return nil, false
}

// Delete 删除键值对
func (m *mapWithExpiration) Delete(key interface{}) {
	m.droneToEventIdMap.Delete(key)
	m.expirationMap.Delete(key)
}

// expireKeys 检查并删除过期的键值对
func (m *mapWithExpiration) expireKeys() {
	ticker := time.NewTicker(10 * time.Second)
	for range ticker.C {
		m.expirationMap.Range(func(key, value interface{}) bool {
			if time.Now().After(value.(time.Time)) {
				m.Delete(key)
			}
			return true
		})
	}
}

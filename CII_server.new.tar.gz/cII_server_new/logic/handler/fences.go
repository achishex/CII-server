package handler

import (
	"context"
	"encoding/json"
	"strconv"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"

	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
)

type FenceControl struct{}

func NewFenceControl() *FenceControl {
	return &FenceControl{}
}

var (
	success    = 1 //成功
	fenceExist = 2 //围栏区已存在
	fail       = 3 //失败
	layout     = "2006-01-02 15:04:05"
)

func (f *FenceControl) AddFence(ctx context.Context, req *client.AddFenceRequest, res *client.AddFenceResponse) error {
	logger.Debugf("AddFence req: %+v", req)
	res.Status = int32(success)
	fencesList, err := NewFenceModel().FindByName(ctx, req.AreaName)
	if err != nil {
		res.Status = int32(fail)
		logger.Errorf("AddFence FindByName err: %+v, res: %+v", err, res)
		return err
	}
	if len(fencesList) > 0 {
		res.Status = int32(fenceExist)
		logger.Errorf("AddFence fence already exists, res: %+v", res)
		return nil
	}
	fences, err := NewFenceModel().Insert(ctx, req)
	if err != nil {
		res.Status = int32(fail)
		logger.Errorf("AddFence err: %+v, res: %+v", err, res)
		return err
	}
	res.Data = &client.FenceData{
		Id:                strconv.FormatInt(fences.ID, 10),
		AreaName:          fences.Name,
		AreaType:          fences.AreaType,
		Perimeter:         fences.Perimeter,
		Area:              fences.Area,
		CentroidLongitude: fences.CentroidLongitude,
		CentroidLatitude:  fences.CentroidLatitude,
		Geometry:          fences.Geometry,
		UpdateTime:        fences.UpdateTime,
		IsCloud:           false,
		Color:             req.Color,
		FenceType:         fences.FenceType,
		YRadius:           fences.YRadius,
		XRadius:           fences.XRadius,
	}
	logger.Debugf("AddFence resp: %+v", res)
	return nil
}

func (f *FenceControl) UpdateFence(ctx context.Context, req *client.UpdateFenceRequest, res *client.UpdateFenceResponse) error {
	logger.Debugf("UpdateFence req: %+v", req)
	res.Status = int32(success)
	if _, err := NewFenceModel().First(ctx, req.Id); err != nil {
		res.Status = int32(fail)
		logger.Errorf("UpdateFence err: %+v, res: %+v", err, res)
		return err
	}

	fencesList, err := NewFenceModel().FindByName(ctx, req.AreaName)
	if err != nil {
		res.Status = int32(fail)
		logger.Errorf("UpdateFence FindByName err: %+v, res: %+v", err, res)
		return err
	}

	alarmId, err := strconv.ParseInt(req.Id, 10, 64)
	if err != nil {
		res.Status = int32(fail)
		logger.Errorf("UpdateFence ParseInt err: %+v, res: %+v", err, res)
		return err
	}
	if len(fencesList) == 1 {
		if fencesList[0].ID != alarmId {
			res.Status = int32(fenceExist)
			logger.Errorf("UpdateFence fence already exists, res: %+v", res)
			return nil
		}
	}
	if len(fencesList) > 1 {
		res.Status = int32(fenceExist)
		logger.Errorf("UpdateFence fence already exists, res: %+v", res)
		return nil
	}

	var colorByte []byte
	colorByte, err = json.Marshal(req.Color)
	if err != nil {
		logger.Errorf("UpdateFence Marshal err: %+v", err)
	}
	field := bean.Fences{
		Name:              req.AreaName,
		AreaType:          req.AreaType,
		Perimeter:         req.Perimeter,
		Area:              req.Area,
		CentroidLongitude: req.CentroidLongitude,
		CentroidLatitude:  req.CentroidLatitude,
		Geometry:          req.Geometry,
		UpdateTime:        time.Now().Format(layout),
		Color:             string(colorByte),
	}

	if err := NewFenceModel().Update(ctx, req.Id, field); err != nil {
		res.Status = int32(fail)
		logger.Errorf("UpdateFence updates err: %+v, res: %+v", err, res)
		return err
	}

	fence, err := NewFenceModel().First(ctx, req.Id)
	if err != nil {
		res.Status = int32(fail)
		logger.Errorf("UpdateFence First err: %+v, res: %+v", err, res)
		return err
	}

	color := []float64{}
	if err = json.Unmarshal([]byte(fence.Color), &color); err != nil {
		logger.Errorf("UpdateFence Unmarshal err: %+v", err)
	}
	res.Data = &client.FenceData{
		Id:                req.Id,
		AreaName:          fence.Name,
		AreaType:          fence.AreaType,
		Perimeter:         fence.Perimeter,
		Area:              fence.Area,
		CentroidLongitude: fence.CentroidLongitude,
		CentroidLatitude:  fence.CentroidLatitude,
		Geometry:          fence.Geometry,
		UpdateTime:        fence.UpdateTime,
		IsCloud:           fence.IsCloud,
		Color:             color,
		FenceType:         fence.FenceType,
		YRadius:           fence.YRadius,
		XRadius:           fence.XRadius,
	}
	logger.Debugf("UpdateFence resp: %+v", res)
	return nil
}

func (f *FenceControl) GetFenceList(ctx context.Context, req *client.GetFenceListRequest, res *client.GetFenceListResponse) error {
	list := make([]*client.FenceData, 0)
	logger.Debugf("GetFenceList req: %+v", req)
	if req.PageNum <= 0 {
		req.PageNum = 1
	}
	if req.PageSize <= 0 {
		// todo 默认显示5条
		req.PageSize = 5
	}
	fences, count, err := NewFenceModel().List(int(req.PageSize), int(req.PageNum))
	if err != nil {
		logger.Errorf("GetFenceList List err: %+v", err)
		return err
	}

	for _, fence := range fences {
		color := make([]float64, 0)
		if err = json.Unmarshal([]byte(fence.Color), &color); err != nil {
			logger.Errorf("GetFenceList unmarshal err: %+v", err)
		}
		tmp := &client.FenceData{
			Id:                strconv.FormatInt(fence.ID, 10),
			AreaName:          fence.Name,
			AreaType:          fence.AreaType,
			Perimeter:         fence.Perimeter,
			Area:              fence.Area,
			CentroidLongitude: fence.CentroidLongitude,
			CentroidLatitude:  fence.CentroidLatitude,
			Geometry:          fence.Geometry,
			UpdateTime:        fence.UpdateTime,
			IsCloud:           fence.IsCloud,
			Color:             color,
			FenceType:         fence.FenceType,
			YRadius:           fence.YRadius,
			XRadius:           fence.XRadius,
		}
		list = append(list, tmp)
	}
	res.List = list
	res.Total = count
	logger.Debugf("GetFenceList resp: %+v", res)
	return nil
}

func (f *FenceControl) GetFenceDetail(ctx context.Context, req *client.GetFenceDetailRequest, res *client.GetFenceDetailResponse) error {
	logger.Debugf("GetFenceDetail req: %+v", req)
	fences, err := NewFenceModel().First(ctx, req.Id)
	if err != nil {
		logger.Errorf("GetFenceDetail First err: %+v", err)
		return err
	}
	color := make([]float64, 0)
	if err = json.Unmarshal([]byte(fences.Color), &color); err != nil {
		logger.Errorf("GetFenceDetail unmarshal err: %+v", err)
	}
	detail := &client.FenceData{
		Id:                strconv.FormatInt(fences.ID, 10),
		AreaName:          fences.Name,
		AreaType:          fences.AreaType,
		Perimeter:         fences.Perimeter,
		Area:              fences.Area,
		CentroidLongitude: fences.CentroidLongitude,
		CentroidLatitude:  fences.CentroidLatitude,
		Geometry:          fences.Geometry,
		UpdateTime:        fences.UpdateTime,
		IsCloud:           fences.IsCloud,
		Color:             color,
		FenceType:         fences.FenceType,
		YRadius:           fences.YRadius,
		XRadius:           fences.XRadius,
	}
	res.Detail = detail
	logger.Debugf("GetFenceDetail resp: %+v", res)
	return nil
}

func (f *FenceControl) DeleteFence(ctx context.Context, req *client.DeleteFenceRequest, res *client.DeleteFenceResponse) error {
	logger.Debugf("DeleteFence req: %+v", req)
	res.Status = int32(success)
	_, err := NewFenceModel().First(ctx, req.Id)
	if err != nil {
		res.Status = 2
		logger.Errorf("DeleteFence First err: %+v, res: %+v", err, res)
		return err
	}

	field := bean.Fences{
		IsDelete:   true,
		DeleteTime: time.Now().Format(layout),
	}
	if err := NewFenceModel().Update(ctx, req.Id, field); err != nil {
		res.Status = 2
		logger.Errorf("DeleteFence Update err: %+v, res: %+v", err, res)
		return err
	}
	logger.Debugf("DeleteFence resp: %+v", res)
	return nil
}

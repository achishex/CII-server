package handler

import (
	"context"
	"errors"
	"fmt"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
	"gorm.io/gorm"
)

const ALLROLE = 0

type Whites struct {
}

func NewWhiteList() *Whites {
	return &Whites{}
}

// 警用: 1, 政府:2, 安防: 3, 私人活动:4, 其他: 200
const (
	WhiteListUsagePolice     = 1
	WhiteListUsageGovernment = 2
	WhiteListUsageSafeGov    = 3
	WhiteListUsagePrivateAct = 4

	// WhiteListUsageOther other define
	WhiteListUsageOther = 200
)

func GetUsageDesc(u int32) string {
	return ""
}

func (w *Whites) Insert(ctx context.Context, req *client.WhiteCrudReq, res *client.WhiteCrudRes) error {
	if req.Sn == "" {
		logger.Errorf("create white list error: SN is nil")
		return errors.New("sn is nil")
	}
	if req.Usage <= 0 || (req.Usage > WhiteListUsagePrivateAct && req.Usage != WhiteListUsageOther) {
		logger.Errorf("create white list err, usage is empty")
		return errors.New("usage is nil")
	}
	if req.Usage == WhiteListUsageOther && len(req.UsageDesc) <= 0 {
		logger.Errorf("create white list err, usage is empty")
		return errors.New("usage is nil")
	}

	if len(req.UserName) <= 0 {
		logger.Errorf("create white list err, username is empty")
		return errors.New("userName is nil")
	}

	if req.Sn == "" {
		logger.Errorf("create white list err, sn is empty")
		return errors.New("sn is nil")
	}

	var model bean.DroneWhiteList
	model.Vendor = req.Vendor
	model.Frequency = req.Frequency
	model.Model = req.Model
	model.Sn = req.Sn
	model.Role = req.Role
	model.UserName = req.UserName
	model.Usage = req.Usage
	model.UsageDesc = req.UsageDesc
	model.Remarks = req.Remarks

	// check sn
	var drone bean.DroneWhiteList
	if err := db.GetDB().Model(&bean.DroneWhiteList{}).Where("sn = ?", req.Sn).First(&drone).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			if err := db.GetDB().Model(&bean.DroneWhiteList{}).Create(&model).Error; err != nil {
				logger.Errorf("create white list error: %v", err)
				return err
			}
			err := db.GetDB().Where("sn = ? ", req.Sn).Delete(&bean.WhiteListLog{}).Error
			if err != nil {
				logger.Debug("delete white list log , error: %v", err)
			}
			return nil
		}
		logger.Errorf("query whitelist error:", err)
		return err
	}

	// update record if sn exist
	loc, err := time.LoadLocation("Local")
	if err != nil {
		panic(err)
	}
	model.CreatedAt = time.Now().In(loc)
	model.UpdatedAt = time.Now().In(loc)
	r := db.GetDB().Model(&bean.DroneWhiteList{}).Where("sn=?", req.Sn).Updates(&model).RowsAffected
	if r == 0 {
		return fmt.Errorf("update white list error: sn=%v no-exist", req.Sn)
	}

	return nil
}

func (w *Whites) Update(ctx context.Context, req *client.WhiteCrudReq, res *client.WhiteCrudRes) error {
	var model bean.DroneWhiteList
	model.Vendor = req.Vendor
	model.Frequency = req.Frequency
	model.Model = req.Model
	model.Sn = req.Sn
	model.Role = req.Role
	model.UserName = req.UserName
	model.Usage = req.Usage
	model.UsageDesc = req.GetUsageDesc()
	model.Remarks = req.Remarks
	model.UpdatedAt = time.Now()

	r := db.GetDB().Model(&bean.DroneWhiteList{}).Where("sn=?", req.Sn).Updates(&model).RowsAffected
	if r == 0 {
		return fmt.Errorf("update white list error: sn=%v no-exist", req.Sn)
	}

	return nil
}

func (w *Whites) Deletes(ctx context.Context, req *client.WhiteDeleteReq, res *client.WhiteCrudRes) error {

	//get all msg before delete
	logger.Debug("sns = ", req.Sns)
	var drones []*bean.DroneWhiteList
	// for _, uavSn := range req.Sns {
	{
		err := db.GetDB().Model(&bean.DroneWhiteList{}).Where("sn IN (?)", req.Sns).Find(&drones).Error
		if err != nil {
			logger.Errorf("query list error:", err)
		}
	}
	// }
	//------

	err := db.GetDB().Where("sn IN (?)", req.Sns).Delete(&bean.DroneWhiteList{}).Error
	if err != nil {
		logger.Errorf("delete white list error: %v", err)
	}

	logger.Debugf("drones = %+v", drones)
	//记录删除的无人机，做数据同步
	for _, drone := range drones {

		// var model bean.DroneWhiteList
		var tmpDrone bean.WhiteListLog

		if err := db.GetDB().Model(&bean.WhiteListLog{}).Where("sn = ?", drone.Sn).First(&tmpDrone).Error; err != nil {
			if errors.Is(err, gorm.ErrRecordNotFound) {
				logger.Debug("err = ", err)
				var store bean.WhiteListLog
				store.CreatedAt = drone.CreatedAt
				store.UpdatedAt = time.Now()
				// store.ID = drone.ID
				store.Vendor = drone.Vendor
				store.Model = drone.Model
				store.Remarks = drone.Remarks
				store.Role = drone.Role
				store.UsageDesc = drone.UsageDesc
				store.Usage = drone.Usage
				store.Sn = drone.Sn
				if store.Sn != "" {
					if err := db.GetDB().Model(&bean.WhiteListLog{}).Create(&store).Error; err != nil {
						logger.Errorf("create WhiteListLog error: %v", err)
					}
				} else {
					logger.Debug("create whitelist, sn is nil")
				}

			}
			logger.Debug("query whitelist error:", err)
		} else {
			loc, err := time.LoadLocation("Local")
			if err != nil {
				logger.Error("err : ", err)
			}
			drone.CreatedAt = time.Now().In(loc)
			drone.UpdatedAt = time.Now().In(loc)
			r := db.GetDB().Model(&bean.WhiteListLog{}).Where("sn=?", drone.Sn).Updates(&drone).RowsAffected
			if r == 0 {
				logger.Errorf("update white list error: sn=%v no-exist", drone)
			} else {
				logger.Debug("r = ", r)
			}
		}

	}
	//---
	return nil
}

func (w *Whites) List(ctx context.Context, req *client.WhiteListReq, res *client.WhiteListRes) error {
	var drones []*bean.DroneWhiteList
	if req.Size <= 0 {
		req.Size = 20
	}

	if req.Role == ALLROLE {
		err := db.GetDB().Model(&bean.DroneWhiteList{}).Where("id > ?", req.Id).Limit(int(req.Size)).Order("id ASC").Find(&drones).Error
		if err != nil {
			logger.Errorf("query list error:", err)
			return err
		}
	} else {
		err := db.GetDB().Model(&bean.DroneWhiteList{}).Where("id > ? and role = ?", req.Id, req.Role).Limit(int(req.Size)).Order("id ASC").Find(&drones).Error
		if err != nil {
			logger.Errorf("query list error:", err)
			return err
		}
	}

	rows := int32(len(drones))
	if rows > 0 {
		if rows < req.Size {
			res.LastId = 0
		} else {
			res.LastId = drones[len(drones)-1].ID
		}
	} else {
		res.LastId = 0
	}

	for idx := range drones {
		w := client.WhiteList{
			Id:        drones[idx].ID,
			Vendor:    drones[idx].Vendor,
			Model:     drones[idx].Model,
			Frequency: drones[idx].Frequency,
			Sn:        drones[idx].Sn,
			Role:      drones[idx].Role,
			CreateAt:  drones[idx].CreatedAt.String(),
			UserName:  drones[idx].UserName,
			Usage:     drones[idx].Usage,
			UsageDesc: drones[idx].UsageDesc,
			Remarks:   drones[idx].Remarks,
		}
		res.WhiteList = append(res.WhiteList, &w)
	}
	return nil
}

func (w *Whites) IsWhitelist(sn string) (bool, error) {
	err := db.GetDB().Model(&bean.DroneWhiteList{}).Where("sn = ?", sn).First(&sn).Error
	if err != nil {
		return false, err
	}
	return true, nil
}

func (w *Whites) ListAll(ctx context.Context, req *client.ListReqAll, rsp *client.ListResAll) error {
	var list []*bean.DroneWhiteList
	err := db.GetDB().Model(&bean.DroneWhiteList{}).Find(&list).Error
	if err != nil {
		return errors.New("query list failed")
	}
	for _, v := range list {
		var model client.WhiteListAll
		w.generateRes(&model, *v)
		rsp.WhiteList = append(rsp.WhiteList, &model)
	}
	return nil
}
func (w *Whites) FindAll(rsp *[]*bean.DroneWhiteList) error {
	// var list []*bean.DroneWhiteList
	err := db.GetDB().Model(&bean.DroneWhiteList{}).Find(rsp).Error
	if err != nil {
		return errors.New("query list failed")
	}
	logger.Debugf("found,rsp: %+v", rsp)
	return nil
}

func (w *Whites) DeleteAll() error {

	err := db.GetDB().Where("id > 0 ").Delete(&bean.DroneWhiteList{}).Error
	if err != nil {
		return errors.New("delete all failed")
	}

	return nil
}

func (w *Whites) CreateAll(in []*bean.DroneWhiteList) error {

	err := db.GetDB().CreateInBatches(&in, len(in)).Error
	if err != nil {
		return err
	}

	return nil
}

func (w *Whites) generateRes(model *client.WhiteListAll, list bean.DroneWhiteList) {
	model.Id = list.ID
	model.Sn = list.Sn
	model.Frequency = list.Frequency
	model.Model = list.Model
	model.Vendor = list.Vendor
	model.Role = list.Role
}

type WhitesLog struct {
}

func NewWhiteListLog() *WhitesLog {
	return &WhitesLog{}
}
func (w *WhitesLog) FindAll(rsp *[]*bean.WhiteListLog) error {
	err := db.GetDB().Model(&bean.WhiteListLog{}).Find(rsp).Error
	if err != nil {
		return errors.New("query list failed")
	}

	return nil
}
func (w *WhitesLog) DeleteAll() error {

	err := db.GetDB().Where("id > 0 ").Delete(&bean.WhiteListLog{}).Error
	if err != nil {
		return errors.New("delete all failed")
	}

	return nil
}

func (w *WhitesLog) CreateAll(in []*bean.WhiteListLog) error {

	err := db.GetDB().CreateInBatches(&in, len(in)).Error
	if err != nil {
		return errors.New("create all failed")
	}

	return nil
}

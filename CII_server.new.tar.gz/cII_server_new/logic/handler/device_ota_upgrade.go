package handler

import (
	"adasgitlab.autel.com/tools/cuav_server/rpc/connmgr"
	"context"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"

	iphelper "adasgitlab.autel.com/tools/cuav_server/entity/helper"

	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/ota"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
)

// OtaRequestUpgrade ota固件升级
func (e *DeviceCenter) OtaRequestUpgrade(ctx context.Context, req *client.RequestUpgradeRequest, rsp *client.RequestUpgradeResponse) error {
	logger.Infof("OtaRequestUpgrade start %v", req)
	// 先查看设备是否正在升级中
	cacheKey := fmt.Sprintf("%d_%s", OtaDeviceTypeMap[req.DeviceType], req.Sn)
	if DevUpgradingMap.CheckIsUpgrading(cacheKey) {
		rsp.Status = 1
		rsp.Sn = req.Sn + " upgrading"
		return nil
	}

	var status int32
	var err error
	//// 先校验文件升级包是否存在
	devTypePath := ota.LocalOtaPkgPathMap[req.DeviceType]
	if req.PkgPath == "" {
		//req.PkgPath = ota.DefaultOtaPkgPath
		logger.Error("DownloadOtaPkg path is nil")
		return errors.New("pkgPath is nil")
	}
	if devTypePath == "" {
		logger.Error("OtaRequestUpgrade err设备类型有误")
		return errors.New("OtaRequestUpgrade err设备类型有误")
	}
	if filepath.Ext(req.FileName) != ".bin" {
		req.FileName = req.FileName + ".bin"
	}
	pkgPath := filepath.Join(req.PkgPath, devTypePath, req.FileName)
	logger.Infof("OtaRequestUpgrade PkgPath %v", pkgPath)
	exist, _ := ota.PathOrFileExists(pkgPath)
	if !exist {
		logger.Error("OtaRequestUpgrade err 更新包不存在")
		return errors.New("OtaRequestUpgrade err 更新包不存在")
	}
	result, err := ota.GetOtaCloudFileListUpgrade(req.PkgPath, 0)
	if err != nil {
		logger.Error("Get Ota CloudFile List Upgrade err:", err)
		return err
	}
	for _, info := range result.List {
		if strings.Contains(info.FileKey, req.FileName) {
			if len(info.C2Version) < 3 {
				break
			}
			compare := compareVersionC2(req.C2Version, info.C2Version)
			if compare < 0 { //设备OTA需要的C2版本高于、等于、当前版本
				rsp.Status = 20
				rsp.Sn = req.Sn
				return nil
			}
		}
	}
	//判断是否是固定设备SN OTA升级特定版本

	versionSnList, err := ota.GetOtaCloudFileVersionSnList(req.PkgPath)
	if err != nil {
		logger.Error("Get Ota Cloud File VersionSn List Upgrade err:", err)
		return err
	}
	isExist := false
	for _, listRsp := range versionSnList.VersionSnList {
		if listRsp.VersionName == req.FileName {
			isExist = true
		}
	}
	isUpgrade := false
	if isExist {
		for _, listRsp := range versionSnList.VersionSnList {
			if listRsp.VersionName == req.FileName && listRsp.DeviceSn == req.Sn {
				isUpgrade = true
			}
		}
	}
	if isUpgrade == true || isExist == false { //升级

	} else { //版本限制，不允许升级
		rsp.Status = 30
		rsp.Sn = req.Sn
		return nil
	}

	req.PkgPath = filepath.Join(req.PkgPath, devTypePath)
	// 复位更新
	switch req.DeviceType {
	case ota.DeviceTypeRadar: // 雷达
		status, err = e.radarResetSystemUpgrade(&client.ResetSystemRequest{
			Sn:       req.Sn,
			Type:     4,
			PkgPath:  req.PkgPath,
			FileName: req.FileName,
		})
		logger.Info("OtaRequestUpgrade status :", status)
		break

	case ota.DeviceTypeGun: // 抢
		logger.Info("OtaRequestUpgrade 抢开始复位升级")
		status, err = e.gunResetSystemUpgrade(&client.ResetSystemRequest{
			Sn:       req.Sn,
			Type:     4,
			PkgPath:  req.PkgPath,
			FileName: req.FileName,
		})

		logger.Info("OtaRequestUpgrade err status :", status)
		break
	case ota.DeviceTypeDroneID, ota.DeviceTypeTracerP, ota.DeviceTypeTracerS, ota.DeviceTypeTracerPro: // Tracer
		targetVersion := common.TracerWGetVersion
		dev := FindCacheDevice(req.Sn, common.DEV_V2DRONEID)

		if dev == nil {
			logger.Error("设备未在线")
		}
		tracer := &DroneID{Device: dev}
		_, appVer, _, _, _, err := tracer.TracerGetVersionInfo(req.Sn)
		if err != nil {
			logger.Error("Send Get Version Info err:", err)
			rsp.Status = 1
			rsp.Sn = req.Sn
			return nil
		}
		logger.Debug("Tracer version is:", appVer)
		re := regexp.MustCompile(`(?i)V\d+\.\d+\.\d+`)
		result := re.FindString(appVer)
		if result != "" {
			result = strings.ToUpper(result)
			logger.Info("Tracer version is :", result)
		}
		compareResult := compareVersion1(result, targetVersion)
		logger.Infof("tracer info IsSerial is:%v,compare:%v", IsSerialMap, compareResult)
		if !IsSerialMap && compareResult >= 0 {
			status, err = e.tracerWgetUpgrade(&client.ResetSystemRequest{
				Sn:         req.Sn,
				Type:       4,
				PkgPath:    req.PkgPath,
				FileName:   req.FileName,
				IsCrossSys: req.IsCrossSys,
			})
		} else {
			status, err = e.tracerResetSystemUpgrade(&client.ResetSystemRequest{
				Sn:         req.Sn,
				Type:       4,
				PkgPath:    req.PkgPath,
				FileName:   req.FileName,
				IsCrossSys: req.IsCrossSys,
			})
			logger.Info("OtaRequestUpgrade err status :", status)
			break
		}
	case ota.DeviceTypeFPV:
		status, err = e.fpvResetSystemUpgrade(&client.ResetSystemRequest{
			Sn:         req.Sn,
			Type:       4,
			PkgPath:    req.PkgPath,
			FileName:   req.FileName,
			IsCrossSys: req.IsCrossSys,
		})
	case ota.DeviceTypeSFL, ota.DeviceTypeSfl110:
		status, err = e.sflWgetUpgrade(&client.ResetSystemRequest{
			Sn:         req.Sn,
			Type:       4,
			PkgPath:    req.PkgPath,
			FileName:   req.FileName,
			IsCrossSys: req.IsCrossSys,
		})
	case ota.DeviceTypeSFL101:
		status, err = e.sfl101WgetUpgrade(&client.ResetSystemRequest{
			Sn:         req.Sn,
			Type:       4,
			PkgPath:    req.PkgPath,
			FileName:   req.FileName,
			IsCrossSys: req.IsCrossSys,
		})
	case ota.DeviceTypeSVH:
		status, err = e.svhWgetUpgrade(&client.ResetSystemRequest{
			Sn:         req.Sn,
			Type:       4,
			PkgPath:    req.PkgPath,
			FileName:   req.FileName,
			IsCrossSys: req.IsCrossSys,
		})
	case ota.DeviceTypeAgx:
		status, err = e.agxWgetUpgrade(&client.ResetSystemRequest{
			Sn:         req.Sn,
			Type:       4,
			PkgPath:    req.PkgPath,
			FileName:   req.FileName,
			IsCrossSys: req.IsCrossSys,
		})
	case ota.DeviceTypeGunCloud:
		status, err = e.gunCloudWgetUpgrade(&client.ResetSystemRequest{
			Sn:         req.Sn,
			Type:       4,
			PkgPath:    req.PkgPath,
			FileName:   req.FileName,
			IsCrossSys: req.IsCrossSys,
		})
	case ota.DeviceSTP120:
		status, err = e.stp120WgetUpgrade(&client.ResetSystemRequest{
			Sn:         req.Sn,
			Type:       4,
			PkgPath:    req.PkgPath,
			FileName:   req.FileName,
			IsCrossSys: req.IsCrossSys,
		})
	default:
		logger.Error("OtaRequestUpgrade DeviceType %d", req.DeviceType)
		return errors.New("设备类型暂不支持")
	}

	if err != nil {
		logger.Errorf("OtaRequestUpgrade 升级失败 err: %v", err.Error())
		return err
	}

	rsp.Status = status
	rsp.Sn = req.Sn

	return nil
}
func compareVersion1(version1, version2 string) int {
	v1 := parseVersion(version1)
	v2 := parseVersion(version2)

	for i := 0; i < len(v1) && i < len(v2); i++ {
		if v1[i] > v2[i] {
			return 1
		} else if v1[i] < v2[i] {
			return -1
		}
	}

	if len(v1) > len(v2) {
		return 1
	} else if len(v1) < len(v2) {
		return -1
	} else {
		return 0
	}
}

func parseVersion(version string) []int {
	parts := strings.Split(strings.TrimPrefix(version, "V"), ".")
	result := make([]int, len(parts))
	for i, part := range parts {
		fmt.Sscanf(part, "%d", &result[i])
	}
	return result
}

func compareVersionC2(version1, version2 string) int {
	v1 := parseVersionC2(version1)
	v2 := parseVersionC2(version2)

	minLength := len(v1)
	if len(v2) < minLength {
		minLength = len(v2)
	}

	for i := 0; i < minLength; i++ {
		if v1[i] > v2[i] {
			return 1
		} else if v1[i] < v2[i] {
			return -1
		}
	}

	if len(v1) > len(v2) {
		for i := minLength; i < len(v1); i++ {
			if v1[i] > 0 {
				return 1
			}
		}
	} else if len(v1) < len(v2) {
		for i := minLength; i < len(v2); i++ {
			if v2[i] > 0 {
				return -1
			}
		}
	}

	return 0
}

func parseVersionC2(version string) []int {
	vs := strings.Split(version, ".")
	vi := make([]int, len(vs))

	for i, v := range vs {
		vi[i], _ = strconv.Atoi(v)
	}

	return vi
}

// radarResetSystemUpgrade 雷达系统复位异步更新
func (e *DeviceCenter) radarResetSystemUpgrade(req *client.ResetSystemRequest) (int32, error) {
	logger.Info("radarResetSystemUpgrade Start")
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_RADAR, req.Sn)
	dev := FindCacheDevice(req.Sn, common.DEV_RADAR)
	if dev == nil {
		// slink v2
		if connmgr.Instance().GetConn(req.Sn) == nil {
			return 1, errors.New("设备未在线")
		}
	}
	radar := &Radar{Device: dev}
	if req.Type == 0 {
		req.Type = 4
	}
	// 修改状态为升级中 同步状态给前端
	DevUpgradingMap.SetStatus(cacheKey, true)
	// 写入升级状态
	UpdateOtaStatus(cacheKey, &UpgradeStatus{
		Sn:         req.Sn,
		DeviceType: int32(common.DEV_RADAR),
		Status:     UpgradeStatusReset,
		ErrMsg:     "系统复位重启中",
	})
	// 异步通过WebSocket向前端同步升级状态
	go OtaSyncUpgradeStatus(req.Sn, cacheKey, int32(common.DEV_RADAR))

	status, err := radar.RadarResetSystem(req)
	if err != nil {
		logger.Errorf("gunResetSystemUpgrade 系统复位失败 err: %v\n", err.Error())
		UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         req.Sn,
			DeviceType: int32(common.DEV_RADAR),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("系统复位失败 err: %s", err.Error()),
		})
		return 1, nil
	}

	if status == 0 { // 复位成功

		logger.Info("radarResetSystemUpgrade 系统复位成功")
		// 清除缓存中的连接
		radar.Close()
		DevStatusMap.Delete(cacheKey)

		// 兼容固定ip 根据ip保存一下设备信息
		ip := radar.RemoteIp
		logger.Info("radarResetSystemUpgrade RemoteAddr %s \n", ip)
		DevResetMap.Store(ip, dev)

		// 开启协程异步后续步骤升级步骤
		go e.radarUpgrade(req.Sn, cacheKey, filepath.Join(req.PkgPath, req.FileName))

	} else {
		UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         req.Sn,
			DeviceType: int32(common.DEV_RADAR),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("系统复位失败 status: %d", status),
		})
	}
	logger.Info("radarResetSystemUpgrade End")
	return status, nil
}

// radarUpgrade 异步升级
func (e *DeviceCenter) radarUpgrade(sn, cacheKey, pkgPathName string) {
	logger.Info("radarUpgrade Start")

	radar := new(Radar)

	// 等待设备连接C2每三秒尝试获取设备并查询设备是否进入boot升级模式
	radar, ok := e.radarLoopCheckIsInBootUpdateMod(sn, cacheKey, common.DEV_RADAR)
	if !ok {
		logger.Error("radarUpgrade 设备未进入boot升级模式")
		return
	}
	// 发送升级包 A7 A8
	if !e.radarSendPkgFile(radar, pkgPathName, cacheKey, sn) {
		logger.Error("radarUpgrade radarSendPkgFile 设备发送升级包失败")
		return
	}

	// 校验固件AC
	if !e.radarVerifyImage(radar, cacheKey, sn) {
		logger.Error("radarUpgrade radarVerifyImage 校验升级Ac包失败")
		return
	}
	// 写入固件A9
	if !e.radarWriteUpdateData(radar, cacheKey, sn) {
		logger.Error("radarUpgrade radarWriteUpdateData 写入固件A9失败")
		return
	}

	// 轮询查询写入状态A6直到写入成功
	if !e.radarGetUpdateWriteStatus(radar, cacheKey, sn) {
		logger.Error("radarUpgrade radarGetUpdateWriteStatus 写入状态失败")
		return
	}

	// AD运行app
	e.radarRunApp(radar, cacheKey, sn)
	logger.Info("radarUpgrade End")
	return
}

// radarLoopCheckIsInBootUpdateMod 每三秒尝试获取设备并查询设备是否进入boot升级模式
func (e *DeviceCenter) radarLoopCheckIsInBootUpdateMod(sn, cacheKey string, deviceType common.DeviceType) (*Radar, bool) {
	logger.Info("radarLoopCheckIsInBootUpdateMod start")
	ticker := time.NewTicker(time.Second * 3)
	timer := time.After(time.Second * 60 * 5)
	dev := new(Device)
	for {
		select {
		case <-ticker.C:
			conn := connmgr.Instance().GetConn(sn)
			if conn != nil {
				// 尝试获取设备版本
				runVer, appVer, bootVer, HwVer, protoVer, err := (&Radar{}).SendGetVersionInfoMonkeyPatch(sn)
				logger.Infof("radarLoopCheckIsInBootUpdateMod Ver: %v, %v, %v, %v, %v \n",
					runVer, appVer, bootVer, HwVer, protoVer)
				if err != nil || runVer != 0 {
					logger.Infof("radarLoopCheckIsInBootUpdateMod radar.SendGetVersionInfo runVer: %v err: %v \n", runVer, err)
					continue
				}
				logger.Infof("radarLoopCheckIsInBootUpdateMod Ver: %v, %v, %v, %v, %v \n",
					runVer, appVer, bootVer, HwVer, protoVer)
				return &Radar{}, true
			}
			dev = FindCacheDevice(sn, deviceType)
			if dev == nil || dev.Conn == nil {
				continue
			}
			// 保存为局部的Dev防止con连接被修改
			newDev := &Device{
				Name:        dev.Name,
				Sn:          dev.Sn,
				Conn:        dev.Conn,
				Status:      dev.Status,
				DevType:     dev.DevType,
				IsEnable:    dev.IsEnable,
				WaitTaskMap: dev.WaitTaskMap,
			}
			radar := &Radar{Device: newDev}
			// 尝试获取设备版本
			runVer, appVer, bootVer, HwVer, protoVer, err := radar.SendGetVersionInfo(dev.Sn)
			logger.Infof("radarLoopCheckIsInBootUpdateMod Ver: %v, %v, %v, %v, %v \n",
				runVer, appVer, bootVer, HwVer, protoVer)
			if err != nil || runVer != 0 {
				logger.Infof("radarLoopCheckIsInBootUpdateMod radar.SendGetVersionInfo runVer: %v err: %v \n", runVer, err)

				continue
			}
			logger.Infof("radarLoopCheckIsInBootUpdateMod Ver: %v, %v, %v, %v, %v \n",
				runVer, appVer, bootVer, HwVer, protoVer)
			return radar, true
		case <-timer:
			// 超时未进入boot模式
			UpdateOtaStatus(cacheKey, &UpgradeStatus{
				Sn:         sn,
				DeviceType: int32(common.DEV_RADAR),
				Status:     UpgradeStatusFailed,
				ErrMsg:     "设备未成功进入boot升级模式",
			})
			return nil, false
		}
	}
}

// radarRunApp AD运行app
func (e *DeviceCenter) radarRunApp(radar *Radar, cacheKey, sn string) {
	logger.Info("radarRunApp Start")
	runStatus, err := radar.RadarRunApp(sn)
	if err != nil {
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_RADAR),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("AD app运行错误 err: %v", err.Error()),
		})
		return
	}
	if runStatus != 0 {
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_RADAR),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("AD app运行状态错误 runStatus: %v", runStatus),
		})
		return
	}
	logger.Info("radarRunApp End")
	// 运行成功
	go UpdateOtaStatus(cacheKey, &UpgradeStatus{
		Sn:         sn,
		DeviceType: int32(common.DEV_RADAR),
		Status:     UpgradeStatusSuccess,
		Permil:     1000,
		ErrMsg:     "升级成功",
	})
	logger.Info("radarRunApp End")
}

// radarWriteUpdateData 写入固件A9
func (e *DeviceCenter) radarWriteUpdateData(radar *Radar, cacheKey, sn string) bool {
	logger.Info("radarWriteUpdateData Start")
	writeStatus, err := radar.RadarWriteUpdateData(sn)
	if err != nil {
		logger.Errorf("radarWriteUpdateData radar.RadarWriteUpdateData Err %v \n", err.Error())
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_RADAR),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("A9写入固件错误 err: %v", err.Error()),
		})
		return false
	}
	if writeStatus != 0 {
		logger.Errorf("radarWriteUpdateData writeStatus Err %v \n", writeStatus)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_RADAR),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("A9写入固件错误 writeStatus: %d", writeStatus),
		})
		return false
	}
	logger.Info("radarWriteUpdateData End")
	return true
}

// radarVerifyImage 校验升级包固件AC
func (e *DeviceCenter) radarVerifyImage(radar *Radar, cacheKey, sn string) bool {
	logger.Info("radarVerifyImage Start")
	verifyStatus, err := radar.RadarVerifyImage(sn)
	if err != nil {
		logger.Errorf("radarVerifyImage radar.RadarVerifyImage Err: %v \n", err.Error())
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_RADAR),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("AC校验升级固件错误 err: %v", err.Error()),
		})
		return false
	}
	if verifyStatus != 0 {
		logger.Errorf("radarVerifyImage radar.RadarVerifyImage verifyStatus Err: %v \n", verifyStatus)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_RADAR),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("AC校验升级固件状态错误 verifyStatus: %v", verifyStatus),
		})
		return false
	}
	logger.Info("radarVerifyImage End")
	return true
}

// radarSendPkgFile 发送升级包 A7 A8
func (e *DeviceCenter) radarSendPkgFile(radar *Radar, pkgPathName, cacheKey, sn string) bool {
	logger.Info("radarSendPkgFile Start")
	// 当前总进度千分比
	totalPermil := 50.0
	// 发送文件占总进度的百分比
	sendPermil := 300.0
	// 读取更新包文件
	f, err := os.Open(pkgPathName)
	if err != nil {
		logger.Errorf("radarSendPkgFile os.Open err: %v\n", err)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_RADAR),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("读取升级包错误： %v", err.Error()),
		})
		return false
	}
	defer f.Close()
	stat, _ := f.Stat()
	filesize := stat.Size()
	// 获取数据包前4k字节调用抢的A7请求升级接口发送前256个字节
	headerSize := 4096
	reqUpgradeBuf := make([]byte, headerSize)
	n, err := f.Read(reqUpgradeBuf)
	if err != nil && err != io.EOF {
		logger.Errorf("radarSendPkgFile f.Read err: %v, n: %v", err, n)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_RADAR),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("读取文件错误： %v", err.Error()),
		})
		return false
	}
	if len(reqUpgradeBuf) != n {
		logger.Errorf("radarSendPkgFile len(reqUpgradeBuf): %v, n: %v \n", len(reqUpgradeBuf), n)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:          sn,
			DeviceType:  int32(common.DEV_RADAR),
			Status:      UpgradeStatusFailed,
			PkgPathName: pkgPathName,
			ErrMsg:      fmt.Sprintf("读取文件错误 len(reqUpgradeBuf): %v, n: %v", len(reqUpgradeBuf), n),
		})
		return false
	}
	var reqUpData [256]uint8
	for i, b := range reqUpgradeBuf[:256] {
		reqUpData[i] = b
	}
	logger.Info("radarSendPkgFile len(reqUpData): ", len(reqUpData))
	status, err := radar.RadarRequestUpgrade(reqUpData, 3, sn)
	if err != nil || status != 0 {

		logger.Errorf("radarSendPkgFile radar.GunRequestUpgrade, status: %d, err: %v \n", status, err)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:          sn,
			DeviceType:  int32(common.DEV_RADAR),
			Status:      UpgradeStatusFailed,
			PkgPathName: pkgPathName,
			ErrMsg:      fmt.Sprintf("A7请求固件升级错误： %v, status: %v", err, status),
		})
		return false
	}
	permil := totalPermil + sendPermil*float64(headerSize)/float64(filesize)
	// 写入状态
	go UpdateOtaStatus(cacheKey, &UpgradeStatus{
		Sn:          sn,
		DeviceType:  int32(common.DEV_RADAR),
		Status:      UpgradeStatusSendPkg,
		PkgPathName: pkgPathName,
		Permil:      int64(permil),
		ErrMsg:      "向雷达发送升级包中",
	})
	// 将文件剩下的数据调A8发送固件数据接口
	buf := make([]byte, 4096)
	var offset = 0
	for {
		n, err := f.Read(buf)
		logger.Info("n: ", n)
		if n == 0 {
			// 发送完成
			go UpdateOtaStatus(cacheKey, &UpgradeStatus{
				Sn:          sn,
				DeviceType:  int32(common.DEV_RADAR),
				Status:      UpgradeStatusSendPkg,
				PkgPathName: pkgPathName,
				Permil:      int64(totalPermil + sendPermil),
				ErrMsg:      "向雷达发送升级包完成",
			})
			break
		}
		if err != nil && err != io.EOF {
			logger.Errorf("radarSendPkgFile f.Read err: %v \n", err)
			go UpdateOtaStatus(cacheKey, &UpgradeStatus{
				Sn:          sn,
				DeviceType:  int32(common.DEV_RADAR),
				Status:      UpgradeStatusFailed,
				PkgPathName: pkgPathName,
				ErrMsg:      fmt.Sprintf("读取升级包错误： %v", err.Error()),
			})
			return false
		}
		// 发送升级包数据
		sendPkgRes, err := radar.RadarSendUpdatePkg(uint32(offset), buf[:n], sn)
		if err != nil {
			logger.Errorf("radarSendPkgFile, sendPkgRes err: %v \n", err)
			go UpdateOtaStatus(cacheKey, &UpgradeStatus{
				Sn:          sn,
				DeviceType:  int32(common.DEV_RADAR),
				Status:      UpgradeStatusFailed,
				PkgPathName: pkgPathName,
				ErrMsg:      fmt.Sprintf("发送升级固件错误： err: %v", err.Error()),
			})
			return false
		}
		if sendPkgRes.Status != 0 {
			logger.Errorf("radarSendPkgFile sendPkgRes.Status: %v \n", sendPkgRes)
			go UpdateOtaStatus(cacheKey, &UpgradeStatus{
				Sn:          sn,
				DeviceType:  int32(common.DEV_RADAR),
				Status:      UpgradeStatusFailed,
				PkgPathName: pkgPathName,
				ErrMsg:      fmt.Sprintf("发送升级固件状态错误 status: %v", sendPkgRes.Status),
			})
			return false
		}
		offset += n
		permil = totalPermil + sendPermil*float64(headerSize+offset)/float64(filesize)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:          sn,
			DeviceType:  int32(common.DEV_RADAR),
			Status:      UpgradeStatusSendPkg,
			PkgPathName: pkgPathName,
			Permil:      int64(permil),
			ErrMsg:      "向雷达发送升级包中",
		})
	}
	return true
}

// 轮询查询固件写入状态
func (e *DeviceCenter) radarGetUpdateWriteStatus(radar *Radar, cacheKey, sn string) bool {
	logger.Info("radarGetUpdateWriteStatus start")
	totalPermil := 350
	writePermil := 500
	ticker := time.NewTicker(time.Second * 5)
	timer := time.After(time.Second * 60 * 20)
	defer ticker.Stop()
	exit := false
	for !exit {
		select {
		case <-ticker.C:
			// 调用A6
			writeRsp, err := radar.RadarGetUpdateWriteStatus(sn)
			if err != nil {
				logger.Errorf("radarGetUpdateWriteStatus radar.RadarGetUpdateWriteStatus Err \n", err.Error())

				go UpdateOtaStatus(cacheKey, &UpgradeStatus{
					Sn:         sn,
					DeviceType: int32(common.DEV_RADAR),
					Status:     UpgradeStatusFailed,
					ErrMsg:     fmt.Sprintf("A6获取写入状态错误 err: %v", err.Error()),
				})
				return false
			}
			if writeRsp.Status == 0 {
				logger.Infof("radarGetUpdateWriteStatus 更新写入状态 Status: %v, permil：%v", writeRsp.Status, writeRsp.Permil)
				// 更新写入状态
				permil := int64(writePermil)*int64(writeRsp.Permil)/1000 + int64(totalPermil)
				//fmt.Println("radarGetUpdateWriteStatus 更新写入状态 permil: ", permil)
				go UpdateOtaStatus(cacheKey, &UpgradeStatus{
					Sn:         sn,
					DeviceType: int32(common.DEV_RADAR),
					Status:     UpgradeStatusWritePkg,
					Permil:     permil,
					ErrMsg:     "写入升级包中",
				})
			} else if writeRsp.Status == 2 {
				logger.Info("radarGetUpdateWriteStatus 写入成功 writeRsp.Status", writeRsp.Status)
				// 写入成功
				go UpdateOtaStatus(cacheKey, &UpgradeStatus{
					Sn:         sn,
					DeviceType: int32(common.DEV_RADAR),
					Status:     UpgradeStatusWritePkg,
					Permil:     int64(totalPermil + writePermil),
					ErrMsg:     "写入升级包完成",
				})

				exit = true
			} else {
				logger.Errorf("radarGetUpdateWriteStatus A6获取写入状态错误 status: \n", writeRsp.Status)
				// 状态错误
				go UpdateOtaStatus(cacheKey, &UpgradeStatus{
					Sn:         sn,
					DeviceType: int32(common.DEV_RADAR),
					Status:     UpgradeStatusFailed,
					ErrMsg:     fmt.Sprintf("A6获取写入状态错误 status: %v", writeRsp.Status),
				})
				return false
			}

		case <-timer:
			logger.Error("radarGetUpdateWriteStatus 写入超时")
			// 超时
			go UpdateOtaStatus(cacheKey, &UpgradeStatus{
				Sn:         sn,
				DeviceType: int32(common.DEV_RADAR),
				Status:     UpgradeStatusFailed,
				ErrMsg:     fmt.Sprintf("写入读取超时"),
			})

			return false
		}
	}
	return true
}

// gunResetSystemUpgrade 抢系统复位异步更新
func (e *DeviceCenter) gunResetSystemUpgrade(req *client.ResetSystemRequest) (int32, error) {
	logger.Info("gunResetSystemUpgrade Start")
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_SCREEN, req.Sn)
	dev := FindCacheDevice(req.Sn, common.DEV_SCREEN)
	if dev == nil {
		logger.Error("设备未在线")
		return 1, errors.New("设备未在线")
	}

	// 修改状态为升级中 同步状态给前端
	DevUpgradingMap.SetStatus(cacheKey, true)
	// 写入升级状态
	UpdateOtaStatus(cacheKey, &UpgradeStatus{
		Sn:         req.Sn,
		DeviceType: int32(common.DEV_SCREEN),
		Status:     UpgradeStatusReset,
		ErrMsg:     "系统复位重启中",
	})
	// 异步通过WebSocket向前端同步升级状态
	go OtaSyncUpgradeStatus(req.Sn, cacheKey, int32(common.DEV_SCREEN))

	// 先给屏幕发复位命令
	screen := &Screen{Device: dev}
	_, err := screen.ScreenResetSystem(req)
	if err != nil {
		logger.Errorf("gunResetSystemUpgrade 屏幕复位失败 err: %v\n", err.Error())
		UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         req.Sn,
			DeviceType: int32(common.DEV_SCREEN),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("屏幕系统复位失败 err: %s", err.Error()),
		})
		return 1, nil
	}
	//time.Sleep(time.Second * 5)
	gun := &CounterGun{Device: dev}
	if req.Type == 0 {
		req.Type = 4
	}
	status, err := gun.GunResetSystem(req)
	if err != nil {
		logger.Errorf("gunResetSystemUpgrade 系统复位失败 err: %v\n", err.Error())
		UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         req.Sn,
			DeviceType: int32(common.DEV_SCREEN),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("枪系统复位失败 err: %s", err.Error()),
		})
		return 1, nil
	}

	if status == 0 { // 复位成功
		logger.Info("gunResetSystemUpgrade 系统复位成功")

		// 开启协程异步进行后续升级步骤
		go e.gunUpgrade(req.Sn, cacheKey, filepath.Join(req.PkgPath, req.FileName), req, dev)

	} else {
		UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         req.Sn,
			DeviceType: int32(common.DEV_SCREEN),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("枪系统复位失败 status: %d", status),
		})
	}
	logger.Info("gunResetSystemUpgrade End")
	return status, nil
}

// gunUpgrade 异步升级
func (e *DeviceCenter) gunUpgrade(sn, cacheKey, pkgPathName string, rq *client.ResetSystemRequest, gundev *Device) {
	logger.Info("gunUpgrade 开始升级")
	gun := new(CounterGun)

	// 每三秒尝试获取设备并查询设备是否进入boot升级模式
	gun, ok := e.gunLoopCheckIsInBootUpdateMod(sn, cacheKey, common.DEV_SCREEN, rq, gundev)
	if !ok {
		logger.Error("gunUpgrade 设备未进入boot升级模式")
		return
	}
	logger.Info("gunUpgrade 发送升级包 A7 A8")
	// 发送升级包 A7 A8
	if !e.gunSendPkgFile(gun, pkgPathName, cacheKey, sn) {
		logger.Error("gunUpgrade 设备发送升级包失败")
		return
	}

	logger.Info("gunUpgrade 校验固件AC")
	// 校验固件AC
	if !e.gunVerifyImage(gun, cacheKey, sn) {
		logger.Error("gunUpgrade 校验升级Ac包失败")
		return
	}
	logger.Info("gunUpgrade 写入固件A9")
	// 写入固件A9
	if !e.gunWriteUpdateData(gun, cacheKey, sn) {
		logger.Error("gunUpgrade 写入固件A9失败")
		return
	}

	logger.Info("gunUpgrade 轮询查询写入状态A6直到写入成功")
	// 轮询查询写入状态A6直到写入成功
	if !e.gunGetUpdateWriteStatus(gun, cacheKey, sn) {
		logger.Error("gunUpgrade 写入状态失败")
		return
	}

	logger.Info("gunUpgrade AD运行app")
	// AD运行app
	e.gunRunApp(gun, cacheKey, sn)
	return
}

// AD运行app
func (e *DeviceCenter) gunRunApp(gun *CounterGun, cacheKey, sn string) {
	logger.Info("gunRunApp Start")
	runStatus, err := gun.GunRunApp()
	if err != nil {
		logger.Errorf("gunRunApp err: ", err.Error())
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_SCREEN),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("AD app运行错误 err: %v", err.Error()),
		})
		return
	}
	if runStatus != 0 {
		logger.Errorf("AD app运行状态错误 runStatus: %v", runStatus)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_SCREEN),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("AD app运行状态错误 runStatus: %v", runStatus),
		})
		return
	}
	// 运行成功
	go UpdateOtaStatus(cacheKey, &UpgradeStatus{
		Sn:         sn,
		DeviceType: int32(common.DEV_SCREEN),
		Status:     UpgradeStatusSuccess,
		Permil:     1000,
		ErrMsg:     "升级成功",
	})
	logger.Info("gunRunApp End")
}

// 轮询查询固件写入状态
func (e *DeviceCenter) gunGetUpdateWriteStatus(gun *CounterGun, cacheKey, sn string) bool {
	logger.Info("gunGetUpdateWriteStatus start")
	totalPermil := 350
	writePermil := 500
	ticker := time.NewTicker(time.Second * 2)
	timer := time.After(time.Second * 60 * 20)
	defer ticker.Stop()
	exit := false
	for !exit {
		select {
		case <-ticker.C:
			logger.Info("gunGetUpdateWriteStatus 调用A6")
			// 调用A6
			writeRsp, err := gun.GunGetUpdateWriteStatus()
			if err != nil {
				logger.Errorf("A6获取写入状态错误 err: %v", err.Error())
				go UpdateOtaStatus(cacheKey, &UpgradeStatus{
					Sn:         sn,
					DeviceType: int32(common.DEV_SCREEN),
					Status:     UpgradeStatusFailed,
					ErrMsg:     fmt.Sprintf("A6获取写入状态错误 err: %v", err.Error()),
				})
				return false
			}
			if writeRsp.Status == 0 {
				// 更新写入状态
				permil := int64(writePermil)*int64(writeRsp.Permil)/1000 + int64(totalPermil)
				go UpdateOtaStatus(cacheKey, &UpgradeStatus{
					Sn:         sn,
					DeviceType: int32(common.DEV_SCREEN),
					Status:     UpgradeStatusWritePkg,
					Permil:     permil,
					ErrMsg:     "写入升级包中",
				})
			} else if writeRsp.Status == 2 {
				// 写入成功
				go UpdateOtaStatus(cacheKey, &UpgradeStatus{
					Sn:         sn,
					DeviceType: int32(common.DEV_SCREEN),
					Status:     UpgradeStatusWritePkg,
					Permil:     int64(totalPermil + writePermil),
					ErrMsg:     "写入升级包完成",
				})
				exit = true
			} else {
				// 状态错误
				go UpdateOtaStatus(cacheKey, &UpgradeStatus{
					Sn:         sn,
					DeviceType: int32(common.DEV_SCREEN),
					Status:     UpgradeStatusFailed,
					ErrMsg:     fmt.Sprintf("A6获取写入状态错误 status: %v", writeRsp.Status),
				})
				logger.Errorf("gunGetUpdateWriteStatus 状态错误", writeRsp.Status)
				return false
			}

		case <-timer:
			// 超时
			go UpdateOtaStatus(cacheKey, &UpgradeStatus{
				Sn:         sn,
				DeviceType: int32(common.DEV_SCREEN),
				Status:     UpgradeStatusFailed,
				ErrMsg:     fmt.Sprintf("写入超时"),
			})
			logger.Errorf("gunGetUpdateWriteStatus 写入超时")
			return false
		}
	}
	logger.Info("gunGetUpdateWriteStatus End")
	return true
}

// gunWriteUpdateData 写入固件A9
func (e *DeviceCenter) gunWriteUpdateData(gun *CounterGun, cacheKey, sn string) bool {
	logger.Info("gunWriteUpdateData start")
	writeStatus, err := gun.GunWriteUpdateData()
	if err != nil {
		logger.Errorf("gunWriteUpdateData writeStatus %v", err.Error())
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_SCREEN),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("A9写入固件错误 err: %v", err.Error()),
		})
		return false
	}
	logger.Infof("gunWriteUpdateData writeStatus %v", writeStatus)
	if writeStatus != 0 {
		logger.Infof("A9写入固件错误 writeStatus: %v", writeStatus)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_SCREEN),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("A9写入固件错误 writeStatus: %v", writeStatus),
		})
		return false
	}
	logger.Info("gunWriteUpdateData End")
	return true
}

// gunVerifyImage 校验升级包固件AC
func (e *DeviceCenter) gunVerifyImage(gun *CounterGun, cacheKey, sn string) bool {
	logger.Infof("gunVerifyImage start %v \n", cacheKey)
	verifyStatus, err := gun.GunVerifyImage()
	if err != nil {
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_SCREEN),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("AC校验升级固件错误 err: %v", err.Error()),
		})
		return false
	}
	logger.Infof("gunVerifyImage verifyStatus %v", verifyStatus)
	if verifyStatus != 0 {
		logger.Infof("gunVerifyImage AC校验升级固件状态错误 %v", verifyStatus)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_SCREEN),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("AC校验升级固件状态错误 verifyStatus: %v", verifyStatus),
		})
		return false
	}
	logger.Infof("gunVerifyImage end %v \n", verifyStatus)
	return true
}

// gunSendPkgFile 发送升级包 A7 A8
func (e *DeviceCenter) gunSendPkgFile(gun *CounterGun, pkgPathName, cacheKey, sn string) bool {
	logger.Info("gunSendPkgFile start", pkgPathName, cacheKey)
	// 当前总进度千分比
	totalPermil := 50.0
	// 发送文件占总进度的百分比
	sendPermil := 300.0
	// 读取更新包文件
	f, err := os.Open(pkgPathName)
	if err != nil {
		logger.Errorf("gunSendPkgFile os.Open err: %v\n", err)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_SCREEN),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("读取升级包错误： %v", err.Error()),
		})
		return false
	}
	defer f.Close()
	stat, _ := f.Stat()
	filesize := stat.Size()
	logger.Infof("gunSendPkgFile filesize %v", filesize)
	// 获取数据包前4k字节调用抢的A7请求升级接口发送前256个字节
	headerSize := 4096
	reqUpgradeBuf := make([]byte, headerSize)
	n, err := f.Read(reqUpgradeBuf)
	if err != nil && err != io.EOF {
		logger.Errorf("gunSendPkgFile f.Read err: %v, n: %v", err, n)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_SCREEN),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("读取文件错误： %v", err.Error()),
		})
		return false
	}

	if len(reqUpgradeBuf) != n {
		logger.Errorf("gunSendPkgFile len(reqUpgradeBuf): %v, n: %v \n", len(reqUpgradeBuf), n)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:          sn,
			DeviceType:  int32(common.DEV_SCREEN),
			Status:      UpgradeStatusFailed,
			PkgPathName: pkgPathName,
			ErrMsg:      fmt.Sprintf("读取文件错误 len(reqUpgradeBuf): %v, n: %v", len(reqUpgradeBuf), n),
		})
		return false
	}
	var reqUpData [256]uint8
	for i, b := range reqUpgradeBuf[:256] {
		reqUpData[i] = b
	}
	logger.Infof("gunSendPkgFile reqUpData %v", reqUpData)
	status, err := gun.GunRequestUpgrade(reqUpData, 3)
	if err != nil || status != 0 {
		logger.Errorf("gunSendPkgFile gun.GunRequestUpgrade, status: %d, err: %v \n", status, err)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:          sn,
			DeviceType:  int32(common.DEV_SCREEN),
			Status:      UpgradeStatusFailed,
			PkgPathName: pkgPathName,
			ErrMsg:      fmt.Sprintf("A7请求固件升级错误： %v, status: %v", err, status),
		})
		return false
	}
	permil := totalPermil + sendPermil*float64(headerSize)/float64(filesize)
	// 写入状态
	logger.Infof("gunSendPkgFile permil %v", permil)
	go UpdateOtaStatus(cacheKey, &UpgradeStatus{
		Sn:         sn,
		DeviceType: int32(common.DEV_SCREEN),
		Status:     UpgradeStatusSendPkg,
		Permil:     int64(permil),
		ErrMsg:     "向枪发送升级包中",
	})
	// 将文件剩下的数据调A8发送固件数据接口
	buf := make([]byte, 4096)
	var offset = 0
	for {
		n, err := f.Read(buf)
		logger.Info("n: ", n)
		if n == 0 {
			// 发送完成
			logger.Info("gunSendPkgFile done")
			go UpdateOtaStatus(cacheKey, &UpgradeStatus{
				Sn:          sn,
				DeviceType:  int32(common.DEV_SCREEN),
				Status:      UpgradeStatusSendPkg,
				PkgPathName: pkgPathName,
				Permil:      int64(totalPermil + sendPermil),
				ErrMsg:      "向枪发送升级包完成",
			})
			break
		}
		if err != nil && err != io.EOF {
			logger.Errorf("gunSendPkgFile GunSendUpdatePkg f.Read err: %v \n", err)
			go UpdateOtaStatus(cacheKey, &UpgradeStatus{
				Sn:          sn,
				DeviceType:  int32(common.DEV_SCREEN),
				Status:      UpgradeStatusFailed,
				PkgPathName: pkgPathName,
				ErrMsg:      fmt.Sprintf("读取升级包错误： %v", err.Error()),
			})
			return false
		}
		// 发送升级包数据
		sendPkgRes, err := gun.GunSendUpdatePkg(uint32(offset), buf[:n])
		if err != nil {
			logger.Errorf("gunSendPkgFile, sendPkgRes err: %v \n", err)
			go UpdateOtaStatus(cacheKey, &UpgradeStatus{
				Sn:          sn,
				DeviceType:  int32(common.DEV_SCREEN),
				Status:      UpgradeStatusFailed,
				PkgPathName: pkgPathName,
				ErrMsg:      fmt.Sprintf("发送升级固件错误： err: %v", err.Error()),
			})
			return false
		}
		if sendPkgRes.Status != 0 {
			logger.Errorf("gunSendPkgFile sendPkgRes.Status: %v \n", sendPkgRes)
			go UpdateOtaStatus(cacheKey, &UpgradeStatus{
				Sn:          sn,
				DeviceType:  int32(common.DEV_SCREEN),
				Status:      UpgradeStatusFailed,
				PkgPathName: pkgPathName,
				ErrMsg:      fmt.Sprintf("发送升级固件状态错误 status: %v", sendPkgRes.Status),
			})
			return false
		}
		offset += n
		permil = totalPermil + sendPermil*float64(headerSize+offset)/float64(filesize)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:          sn,
			DeviceType:  int32(common.DEV_SCREEN),
			Status:      UpgradeStatusSendPkg,
			PkgPathName: pkgPathName,
			Permil:      int64(permil),
			ErrMsg:      "向枪发送升级包中",
		})
		logger.Infof("gunSendPkgFile sendPermil", sendPermil)
	}
	logger.Info("gunSendPkgFile end")
	return true
}

// gunLoopCheckIsInBootUpdateMod 每三秒尝试获取设备并查询设备是否进入boot升级模式
func (e *DeviceCenter) gunLoopCheckIsInBootUpdateMod(sn, cacheKey string, deviceType common.DeviceType, rq *client.ResetSystemRequest, gundev *Device) (*CounterGun, bool) {
	logger.Info("Gun LoopCheckIsInBootUpdateMod start")
	ticker := time.NewTicker(time.Second * 3)
	timer := time.After(time.Second * 60 * 5)
	tickerReset := time.NewTicker(time.Second * 50)
	defer ticker.Stop()
	defer tickerReset.Stop()
	for {
		select {
		case <-ticker.C:
			var dev *Device
			dev = FindCacheDevice(sn, deviceType)
			if dev == nil || dev.Conn == nil {
				logger.Infof("[gun] 获取设备连接失败 sn:%v", sn)
				continue
			}
			// 保存为局部的Dev防止con连接被修改
			newDev := &Device{
				Name:        dev.Name,
				Sn:          dev.Sn,
				Conn:        dev.Conn,
				Status:      dev.Status,
				DevType:     dev.DevType,
				IsEnable:    dev.IsEnable,
				WaitTaskMap: dev.WaitTaskMap,
			}
			gun := &CounterGun{Device: newDev}
			// 尝试获取设备版本
			runVer, appVer, bootVer, HwVer, protoVer, err := gun.SendGetAEAGSoftVer(sn)
			logger.Infof("gunLoopCheckIsInBootUpdateMod Ver: %v, %v, %v, %v, %v \n",
				runVer, appVer, bootVer, HwVer, protoVer)
			logger.Infof("gunLoopCheckIsInBootUpdateMod err: %v \n", err)
			if err != nil || runVer != 0 {
				logger.Infof("gunLoopCheckIsInBootUpdateMod gun.SendGetAEAGSoftVer runVer: %v err: %v \n", runVer, err)
				continue
			}
			logger.Infof("gunLoopCheckIsInBootUpdateMod Ver: %v, %v, %v, %v, %v \n",
				runVer, appVer, bootVer, HwVer, protoVer)
			return gun, true
		case <-tickerReset.C:
			dev := FindCacheDevice(sn, deviceType)
			if dev == nil || dev.Conn == nil {
				logger.Infof("获取设备连接失败")
				continue
			}
			// 保存为局部的Dev防止con连接被修改
			newDev := &Device{
				Name:        dev.Name,
				Sn:          dev.Sn,
				Conn:        dev.Conn,
				Status:      dev.Status,
				DevType:     dev.DevType,
				IsEnable:    dev.IsEnable,
				WaitTaskMap: dev.WaitTaskMap,
			}
			gun := &CounterGun{Device: newDev}
			_, err := gun.GunResetSystem(rq)
			if err != nil {
				logger.Errorf("gunResetSystemUpgrade 系统复位失败 err: %v\n", err.Error())
				UpdateOtaStatus(cacheKey, &UpgradeStatus{
					Sn:         sn,
					DeviceType: int32(common.DEV_SCREEN),
					Status:     UpgradeStatusFailed,
					ErrMsg:     fmt.Sprintf("枪系统复位失败 err: %s", err.Error()),
				})
			}
		case <-timer:
			// 超时未进入boot模式
			go UpdateOtaStatus(cacheKey, &UpgradeStatus{
				Sn:         sn,
				DeviceType: int32(common.DEV_SCREEN),
				Status:     UpgradeStatusFailed,
				ErrMsg:     "设备未成功进入boot升级模式",
			})
			return nil, false
		}
	}
}

// tracerResetSystemUpgrade Tracer系统复位异步更新
func (e *DeviceCenter) tracerResetSystemUpgrade(req *client.ResetSystemRequest) (int32, error) {
	logger.Info("tracerResetSystemUpgrade Start")
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_V2DRONEID, req.Sn)
	dev := FindCacheDevice(req.Sn, common.DEV_V2DRONEID)
	if dev == nil {
		logger.Error("设备未在线")
		return 1, errors.New("设备未在线")
	}
	tracer := &DroneID{Device: dev}

	//if req.IsCrossSys != 1 {
	//	isUpdate, err := CheckTracerDevType(tracer, req.FileName)
	//	if err != nil || isUpdate == false {
	//		logger.Error(" update err:", err)
	//		return 1, err
	//	}
	//}
	if req.Type == 0 {
		req.Type = 4
	}
	// 修改状态为升级中 同步状态给前端
	DevUpgradingMap.SetStatus(cacheKey, true)
	// 写入升级状态
	UpdateOtaStatus(cacheKey, &UpgradeStatus{
		Sn:         req.Sn,
		DeviceType: int32(common.DEV_V2DRONEID),
		Status:     UpgradeStatusReset,
		ErrMsg:     "系统复位重启中",
	})
	// 异步通过WebSocket向前端同步升级状态
	go OtaSyncUpgradeStatus(req.Sn, cacheKey, int32(common.DEV_V2DRONEID))

	// 复位进入boot升级模式
	status, err := tracer.TracerResetSystem(req)
	if err != nil {
		logger.Errorf("TracerResetSystemUpgrade 系统复位失败 err: %v\n", err.Error())
		UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         req.Sn,
			DeviceType: int32(common.DEV_V2DRONEID),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("系统复位失败 err: %s", err.Error()),
		})
		return 1, nil
	}

	if status == 0 { // 复位成功
		logger.Info("TracerResetSystemUpgrade 系统复位成功")
		// 清除缓存中的连接
		tracer.Close()
		DevStatusMap.Delete(cacheKey)
		// tracer boot 模式没有心跳 先将设备保存到复位map中
		ip := tracer.RemoteIp
		logger.Infof("radarResetSystemUpgrade RemoteAddr %s \n", ip)
		DevResetMap.Store(ip, dev)
		// 开启协程异步进行后续升级步骤
		go e.tracerUpgrade(req.Sn, cacheKey, filepath.Join(req.PkgPath, req.FileName))

	} else {
		UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         req.Sn,
			DeviceType: int32(common.DEV_V2DRONEID),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("系统复位失败 status: %d", status),
		})
	}
	logger.Info("tracerResetSystemUpgrade End")
	return status, nil
}

// tracerWgetUpgrade Tracer Wget升级
func (e *DeviceCenter) tracerWgetUpgrade(req *client.ResetSystemRequest) (int32, error) {

	logger.Info("tracerWgetUpgrade Start:", req)
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_V2DRONEID, req.Sn)
	dev := FindCacheDevice(req.Sn, common.DEV_V2DRONEID)
	if dev == nil {
		logger.Error("设备未在线")
		return 1, errors.New("设备未在线")
	}
	tracer := &DroneID{Device: dev}
	if req.Type == 0 {
		req.Type = 4
	}
	// 修改状态为升级中 同步状态给前端
	DevUpgradingMap.SetStatus(cacheKey, true)
	// 写入升级状态
	UpdateOtaStatus(cacheKey, &UpgradeStatus{
		Sn:         req.Sn,
		DeviceType: int32(common.DEV_V2DRONEID),
		Status:     UpgradeStatusSendPkg,
		ErrMsg:     "向系统发升级包中",
	})
	// 异步通过WebSocket向前端同步升级状态
	go OtaSyncUpgradeStatus(req.Sn, cacheKey, int32(common.DEV_V2DRONEID))
	go func() {
		ctx, cancel := context.WithCancel(context.Background())
		defer cancel()
		var c2Ip string
		localIPInfos, err := iphelper.GetLocalIPInfos()
		if err != nil {
			logger.Errorf("get IP err err %v", err)
			return
		}
		defaultIP := ""
		for _, ipInfo := range localIPInfos {
			logger.Infof("ip Info is %v,remote Ip is :%v", ipInfo.LocalIP, tracer.RemoteIp)
			isSame := isSamePrefix(ipInfo.LocalIP, tracer.RemoteIp)
			if isSame {
				c2Ip = ipInfo.LocalIP
			}
			if strings.Contains(ipInfo.LocalIP, "169.254") { //平板没有IP时 使用公认的169.254网段
				defaultIP = ipInfo.LocalIP
			}
		}
		if c2Ip == "" {
			c2Ip = defaultIP
		}
		fileServer := http.FileServer(http.Dir(req.PkgPath))

		server := &http.Server{
			Addr:    c2Ip + ":8081",
			Handler: fileServer,
		}
		go func() {
			logger.Info("file server start:", server.Addr)
			if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
				logger.Error("file server start err:", err)
			}
		}()
		// 开启协程异步进行后续升级步骤
		//go e.tracerUpgrade(req.Sn, cacheKey, filepath.Join(req.PkgPath, req.FileName))
		stopChan := make(chan struct{})
		//执行其他操作
		defer close(stopChan)
		// 启动一个新的协程来等待关闭信号
		go func() {
			// 等待接收到关闭信号
			<-stopChan

			logger.Info("HTTP service stop")
			timeoutCtx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
			defer cancel()

			if err := server.Shutdown(timeoutCtx); err != nil {
				logger.Error("HTTP service stop  err：", err)
			}
			logger.Info("HTTP is close")
		}()

		if !e.tracerSendUpgradeF1(tracer, cacheKey, req.Sn, req.FileName, c2Ip) {
			logger.Error("download file err  F1")
			return
		}
		if !e.tracerSendUpgradeF2(ctx, tracer, cacheKey, req.Sn, req.FileName) {
			logger.Error("download file err  F2")
			return
		}

		if !e.tracerSendUpgradeF3(tracer, cacheKey, req.Sn) {
			logger.Error("download file err  F3")
		}

		logger.Info("tracerWgetUpgrade End")
	}()

	return 0, nil
}
func isSamePrefix(ip1, ip2 string) bool {
	prefix1 := getPrefix(ip1)
	prefix2 := getPrefix(ip2)

	return prefix1 == prefix2
}

func getPrefix(ip string) string {
	parts := strings.Split(ip, ".")
	if len(parts) < 3 {
		return ""
	}
	return strings.Join(parts[:3], ".")
}

// tracerSendUpgradeF1 发送请求固件升级
func (e *DeviceCenter) tracerSendUpgradeF1(tracer *DroneID, cacheKey, sn string, fileName string, c2Ip string) bool {
	logger.Info("tracerSend Upgrade F1 start")
	time.Sleep(time.Second * 1)
	writeStatus, err := tracer.TracerSendUpgradeF1(fileName, c2Ip)
	if err != nil {
		logger.Errorf("tracerWriteUpdateData writeStatus %v", err.Error())
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_V2DRONEID),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("A9写入固件错误 err: %v", err.Error()),
		})
		return false
	}
	logger.Infof("tracerSend Upgrade F1 writeStatus %v", writeStatus)
	if writeStatus != 0 {
		logger.Infof("tracerSendU pgrade F1 writeStatus err: %v", writeStatus)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_V2DRONEID),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("A9写入固件错误 writeStatus: %v", writeStatus),
		})
		return false
	}
	if writeStatus == 0 {
		logger.Infof("tracerSendU pgrade F1 writeStatus suc: %v", writeStatus)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:          sn,
			DeviceType:  int32(common.DEV_V2DRONEID),
			Status:      UpgradeStatusSendPkg,
			PkgPathName: fileName,
			ErrMsg:      "向Tracer发送升级包中",
		})
	}
	logger.Info("tracerSend Upgrade F1 End")
	return true
}

// tracerSendUpgradeF2 发送请求固件升级
func (e *DeviceCenter) tracerSendUpgradeF2(ctx context.Context, tracer *DroneID, cacheKey, sn string, pkgName string) bool {
	logger.Info("tracerSend Upgrade F2 start")
	timer1 := time.NewTicker(1 * time.Second)
	tryCount := 0
	var writeStatus int32
	var err error
	for {
		select {
		case <-timer1.C:
			writeStatus, err = tracer.TracerSendUpgradeF2()
			if err != nil {
				logger.Errorf("tracerWriteUpdateData writeStatus %v", err.Error())
				tryCount++
				if tryCount >= 5 {
					go UpdateOtaStatus(cacheKey, &UpgradeStatus{
						Sn:         sn,
						DeviceType: int32(common.DEV_V2DRONEID),
						Status:     UpgradeStatusFailed,
						ErrMsg:     fmt.Sprintf("F2 get err: %v", err.Error()),
					})
					return false
				}
			}
			logger.Infof("tracerSend Upgrade F2 writeStatus %v", writeStatus)
			if writeStatus == -1 { //失败继续执行 不给前端返回
				continue
			}
			if writeStatus <= 95 {
				logger.Infof("tracerSend get F2 writeStatus : %v", writeStatus)
				go UpdateOtaStatus(cacheKey, &UpgradeStatus{
					Sn:          sn,
					DeviceType:  int32(common.DEV_V2DRONEID),
					Status:      UpgradeStatusSendPkg,
					PkgPathName: pkgName,
					Permil:      int64(writeStatus * 10),
					ErrMsg:      "向Tracer发送升级包中",
				})
			}
			if writeStatus == 100 {
				logger.Infof("tracerSend get F2 writeStatus finish: %v", writeStatus)
				go UpdateOtaStatus(cacheKey, &UpgradeStatus{
					Sn:          sn,
					DeviceType:  int32(common.DEV_V2DRONEID),
					Status:      UpgradeStatusSendPkg,
					PkgPathName: pkgName,
					Permil:      int64((writeStatus - 5) * 10),
					ErrMsg:      "向Tracer发送升级包中",
				})
				return true
			}
		case <-ctx.Done():
			return false
		}
	}

}

// tracerSendUpgradeF3 发送请求固件升级
func (e *DeviceCenter) tracerSendUpgradeF3(tracer *DroneID, cacheKey, sn string) bool {
	logger.Info("tracerSend Upgrade F3 start")
	writeStatus, err := tracer.TracerSendUpgradeF3()
	if err != nil {
		logger.Errorf("tracerWriteUpdateData writeStatus %v", err.Error())
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_V2DRONEID),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("F3 download err: %v", err.Error()),
		})
		return false
	}
	logger.Infof("tracerSend Upgrade F3 writeStatus %v", writeStatus)
	if writeStatus != 0 {
		logger.Infof("tracerSend Upgrade F3 writeStatus err: %v", writeStatus)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_V2DRONEID),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("F3 download writeStatus: %v", writeStatus),
		})
		return false
	}
	if writeStatus == 0 {
		logger.Infof("tracerSend Upgrade F3 writeStatus Finish %v", writeStatus)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_V2DRONEID),
			Status:     UpgradeStatusSuccess,
			Permil:     1000,
			ErrMsg:     "向tracer发送升级包完成",
		})
	}
	logger.Info("tracerSend Upgrade F3 End")
	return true
}

// tracerUpgrade 异步升级
func (e *DeviceCenter) tracerUpgrade(sn, cacheKey, pkgPathName string) {
	logger.Info("tracerUpgrade 开始升级")

	tracer := new(DroneID)

	// 每三秒尝试获取设备并查询设备是否进入boot升级模式
	tracer, ok := e.tracerLoopCheckIsInBootUpdateMod(sn, cacheKey, common.DEV_V2DRONEID)
	if !ok {
		logger.Error("tracerUpgrade 设备未进入boot升级模式")
		return
	}
	logger.Info("tracerUpgrade 发送升级包 A7 A8")
	// 发送升级包 A7 A8
	if !e.tracerSendPkgFile(tracer, pkgPathName, cacheKey, sn) {
		logger.Error("tracerUpgrade 设备发送升级包失败")
		return
	}

	logger.Info("tracerUpgrade 校验固件AC")
	// 校验固件AC
	if !e.tracerVerifyImage(tracer, cacheKey, sn) {
		logger.Error("tracerUpgrade 校验升级Ac包失败")
		return
	}
	logger.Info("tracerUpgrade 写入固件A9")
	// 写入固件A9
	if !e.tracerWriteUpdateData(tracer, cacheKey, sn) {
		logger.Error("tracerUpgrade 写入固件A9失败")
		return
	}

	logger.Info("tracerUpgrade 轮询查询写入状态A6直到写入成功")
	// 轮询查询写入状态A6直到写入成功
	if !e.tracerGetUpdateWriteStatus(tracer, cacheKey, sn) {
		logger.Error("tracerUpgrade 写入状态失败")
		return
	}

	logger.Info("tracerUpgrade AD运行app")
	// AD运行app
	e.tracerRunApp(tracer, cacheKey, sn, pkgPathName)
	return
}

// tracerRunApp AD运行app
func (e *DeviceCenter) tracerRunApp(tracer *DroneID, cacheKey, sn string, pkgPathName string) {
	logger.Info("tracerRunApp Start")
	runStatus, err := tracer.TracerRunApp()
	if err != nil {
		logger.Errorf("tracerRunApp err: ", err.Error())
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_V2DRONEID),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("AD app运行错误 err: %v", err.Error()),
		})
		return
	}
	if runStatus != 0 {
		logger.Errorf("AD app运行状态错误 runStatus: %v", runStatus)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_V2DRONEID),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("AD app运行状态错误 runStatus: %v", runStatus),
		})
		return
	}
	// 运行成功
	go UpdateOtaStatus(cacheKey, &UpgradeStatus{
		Sn:         sn,
		DeviceType: int32(common.DEV_V2DRONEID),
		Status:     UpgradeStatusSuccess,
		Permil:     1000,
		ErrMsg:     "升级成功",
	})
	logger.Info("tracerRunApp End")
}

// tracerGetUpdateWriteStatus 轮询查询固件写入状态
func (e *DeviceCenter) tracerGetUpdateWriteStatus(tracer *DroneID, cacheKey, sn string) bool {
	logger.Info("tracerGetUpdateWriteStatus start")
	totalPermil := 990
	writePermil := 995
	ticker := time.NewTicker(time.Second * 2)
	timer := time.After(time.Second * 60 * 20)
	defer ticker.Stop()
	exit := false
	for !exit {
		select {
		case <-ticker.C:
			logger.Info("tracerGetUpdateWriteStatus 调用A6")
			// 调用A6
			writeRsp, err := tracer.TracerGetUpdateWriteStatus()
			if err != nil {
				logger.Errorf("A6获取写入状态错误 err: %v", err.Error())
				go UpdateOtaStatus(cacheKey, &UpgradeStatus{
					Sn:         sn,
					DeviceType: int32(common.DEV_V2DRONEID),
					Status:     UpgradeStatusFailed,
					ErrMsg:     fmt.Sprintf("A6获取写入状态错误 err: %v", err.Error()),
				})
				return false
			}
			if writeRsp.Status == 0 {
				// 更新写入状态
				permil := int64(writePermil)*int64(writeRsp.Permil)/1000 + int64(totalPermil)
				go UpdateOtaStatus(cacheKey, &UpgradeStatus{
					Sn:         sn,
					DeviceType: int32(common.DEV_V2DRONEID),
					Status:     UpgradeStatusWritePkg,
					Permil:     permil,
					ErrMsg:     "写入升级包中",
				})
			} else if writeRsp.Status == 2 {
				// 写入成功
				go UpdateOtaStatus(cacheKey, &UpgradeStatus{
					Sn:         sn,
					DeviceType: int32(common.DEV_V2DRONEID),
					Status:     UpgradeStatusWritePkg,
					Permil:     int64(totalPermil + writePermil),
					ErrMsg:     "写入升级包完成",
				})
				exit = true
			} else {
				// 状态错误
				go UpdateOtaStatus(cacheKey, &UpgradeStatus{
					Sn:         sn,
					DeviceType: int32(common.DEV_V2DRONEID),
					Status:     UpgradeStatusFailed,
					ErrMsg:     fmt.Sprintf("A6获取写入状态错误 status: %v", writeRsp.Status),
				})
				logger.Errorf("tracerGetUpdateWriteStatus 状态错误", writeRsp.Status)
				return false
			}

		case <-timer:
			// 超时
			go UpdateOtaStatus(cacheKey, &UpgradeStatus{
				Sn:         sn,
				DeviceType: int32(common.DEV_V2DRONEID),
				Status:     UpgradeStatusFailed,
				ErrMsg:     fmt.Sprintf("写入超时"),
			})
			logger.Errorf("tracerGetUpdateWriteStatus 写入超时")
			return false
		}
	}
	logger.Info("tracerGetUpdateWriteStatus End")
	return true
}

// tracerWriteUpdateData 写入固件A9
func (e *DeviceCenter) tracerWriteUpdateData(tracer *DroneID, cacheKey, sn string) bool {
	logger.Info("tracerWriteUpdateData start")
	writeStatus, err := tracer.TracerWriteUpdateData()
	if err != nil {
		logger.Errorf("tracerWriteUpdateData writeStatus %v", err.Error())
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_V2DRONEID),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("A9写入固件错误 err: %v", err.Error()),
		})
		return false
	}
	logger.Infof("tracerWriteUpdateData writeStatus %v", writeStatus)
	if writeStatus != 0 {
		logger.Infof("A9写入固件错误 writeStatus: %v", writeStatus)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_V2DRONEID),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("A9写入固件错误 writeStatus: %v", writeStatus),
		})
		return false
	}
	logger.Info("tracerWriteUpdateData End")
	return true
}

// tracerVerifyImage 校验升级包固件AC
func (e *DeviceCenter) tracerVerifyImage(tracer *DroneID, cacheKey, sn string) bool {
	logger.Infof("tracerVerifyImage start %v \n", cacheKey)
	verifyStatus, err := tracer.TracerVerifyImage()
	if err != nil {
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_V2DRONEID),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("AC校验升级固件错误 err: %v", err.Error()),
		})
		return false
	}
	logger.Infof("tracerVerifyImage verifyStatus %v", verifyStatus)
	if verifyStatus != 0 {
		logger.Infof("tracerVerifyImage AC校验升级固件状态错误 %v", verifyStatus)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_V2DRONEID),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("AC校验升级固件状态错误 verifyStatus: %v", verifyStatus),
		})
		return false
	}
	logger.Infof("tracerVerifyImage end %v \n", verifyStatus)
	return true
}

// tracerSendPkgFile 发送升级包 A7 A8
func (e *DeviceCenter) tracerSendPkgFile(tracer *DroneID, pkgPathName, cacheKey, sn string) bool {
	logger.Info("tracerSendPkgFile start", pkgPathName, cacheKey)
	// 当前总进度千分比
	totalPermil := 50.0
	// 发送文件占总进度的百分比
	sendPermil := 940.0
	// 读取更新包文件
	f, err := os.Open(pkgPathName)
	defer f.Close()
	if err != nil {
		logger.Errorf("tracerSendPkgFile os.Open err: %v\n", err)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_V2DRONEID),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("读取升级包错误： %v", err.Error()),
		})
		return false
	}

	stat, _ := f.Stat()
	filesize := stat.Size()
	logger.Infof("tracerSendPkgFile filesize %v", filesize)
	// 获取数据包前4k字节调用抢的A7请求升级接口发送前256个字节
	headerSize := 4096
	reqUpgradeBuf := make([]byte, headerSize)
	n, err := f.Read(reqUpgradeBuf)
	if err != nil && err != io.EOF {
		logger.Errorf("tracerSendPkgFile f.Read err: %v, n: %v", err, n)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_V2DRONEID),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("读取文件错误： %v", err.Error()),
		})
		return false
	}

	if len(reqUpgradeBuf) != n {
		logger.Errorf("tracerSendPkgFile len(reqUpgradeBuf): %v, n: %v \n", len(reqUpgradeBuf), n)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:          sn,
			DeviceType:  int32(common.DEV_V2DRONEID),
			Status:      UpgradeStatusFailed,
			PkgPathName: pkgPathName,
			ErrMsg:      fmt.Sprintf("读取文件错误 len(reqUpgradeBuf): %v, n: %v", len(reqUpgradeBuf), n),
		})
		return false
	}
	var reqUpData [256]uint8
	for i, b := range reqUpgradeBuf[:256] {
		reqUpData[i] = b
	}
	logger.Infof("tracerSendPkgFile reqUpData %v", reqUpData)
	status, err := tracer.TracerRequestUpgrade(reqUpData, 3)
	if err != nil || status != 0 {
		logger.Errorf("tracerSendPkgFile tracer.TracerRequestUpgrade, status: %d, err: %v \n", status, err)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:          sn,
			DeviceType:  int32(common.DEV_V2DRONEID),
			Status:      UpgradeStatusFailed,
			PkgPathName: pkgPathName,
			ErrMsg:      fmt.Sprintf("A7请求固件升级错误： %v, status: %v", err, status),
		})
		return false
	}
	permil := totalPermil + sendPermil*float64(headerSize)/float64(filesize)
	// 写入状态
	logger.Infof("tracerSendPkgFile permil %v", permil)
	go UpdateOtaStatus(cacheKey, &UpgradeStatus{
		Sn:         sn,
		DeviceType: int32(common.DEV_V2DRONEID),
		Status:     UpgradeStatusSendPkg,
		Permil:     int64(permil),
		ErrMsg:     "向枪发送升级包中",
	})
	//向Tracer发送0xAE消息，获取下载固件数据包最大字节数
	//lenBuff, err := tracer.TracerGetUpdateTimeoutRetryTime()
	//if lenBuff.ImagePkgLenMax == 0 {
	//	lenBuff.ImagePkgLenMax = 4096
	//}
	// 将文件剩下的数据调A8发送固件数据接口
	buf := make([]byte, 4096)
	var offset = 0
	for {
		n, err := f.Read(buf)
		if n == 0 {
			// 发送完成
			logger.Info("tracerSendPkgFile done")
			go UpdateOtaStatus(cacheKey, &UpgradeStatus{
				Sn:          sn,
				DeviceType:  int32(common.DEV_V2DRONEID),
				Status:      UpgradeStatusSendPkg,
				PkgPathName: pkgPathName,
				Permil:      int64(totalPermil + sendPermil),
				ErrMsg:      "向Tracer发送升级包完成",
			})
			break
		}
		if err != nil && err != io.EOF {
			logger.Errorf("tracerSendPkgFile f.Read err: %v \n", err)
			go UpdateOtaStatus(cacheKey, &UpgradeStatus{
				Sn:          sn,
				DeviceType:  int32(common.DEV_V2DRONEID),
				Status:      UpgradeStatusFailed,
				PkgPathName: pkgPathName,
				ErrMsg:      fmt.Sprintf("读取升级包错误： %v", err.Error()),
			})
			return false
		}
		// 发送升级包数据
		sendPkgRes, err := tracer.TracerSendUpdatePkg(uint32(offset), buf[:n])
		if err != nil {
			logger.Errorf("tracerSendPkgFile, sendPkgRes err: %v \n", err)
			go UpdateOtaStatus(cacheKey, &UpgradeStatus{
				Sn:          sn,
				DeviceType:  int32(common.DEV_V2DRONEID),
				Status:      UpgradeStatusFailed,
				PkgPathName: pkgPathName,
				ErrMsg:      fmt.Sprintf("发送升级固件错误： err: %v", err.Error()),
			})
			return false
		}
		if sendPkgRes.Status != 0 && sendPkgRes.Status != 128 {
			logger.Errorf("tracerSendPkgFile sendPkgRes: %v \n", sendPkgRes)
			go UpdateOtaStatus(cacheKey, &UpgradeStatus{
				Sn:          sn,
				DeviceType:  int32(common.DEV_V2DRONEID),
				Status:      UpgradeStatusFailed,
				PkgPathName: pkgPathName,
				ErrMsg:      fmt.Sprintf("发送升级固件状态错误 status: %v", sendPkgRes.Status),
			})
			return false
		}

		offset += n
		permil = totalPermil + sendPermil*float64(headerSize+offset)/float64(filesize)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:          sn,
			DeviceType:  int32(common.DEV_V2DRONEID),
			Status:      UpgradeStatusSendPkg,
			PkgPathName: pkgPathName,
			Permil:      int64(permil),
			ErrMsg:      "向Tracer发送升级包中",
		})
		logger.Info("tracerSendPkgFile sendPermil:", permil)
	}
	logger.Info("tracerSendPkgFile end")
	return true
}

// tracerLoopCheckIsInBootUpdateMod 每三秒尝试获取设备并查询设备是否进入boot升级模式
func (e *DeviceCenter) tracerLoopCheckIsInBootUpdateMod(sn, cacheKey string, deviceType common.DeviceType) (*DroneID, bool) {
	logger.Info("tracerLoopCheckIsInBootUpdateMod start")
	ticker := time.NewTicker(time.Second * 3)
	timer := time.After(time.Second * 60 * 5)
	dev := new(Device)
	for {
		select {
		case <-ticker.C:
			dev = FindCacheDevice(sn, deviceType)
			if dev == nil || dev.Conn == nil || dev.WaitTaskMap == nil {
				logger.Info("tracerLoopCheckIsInBootUpdateMod 获取设备连接失败")
				continue
			}
			// 保存为局部的Dev防止con连接被修改
			newDev := &Device{
				Name:        dev.Name,
				Sn:          dev.Sn,
				Conn:        dev.Conn,
				Status:      dev.Status,
				DevType:     dev.DevType,
				IsEnable:    dev.IsEnable,
				WaitTaskMap: dev.WaitTaskMap,
			}
			tracer := &DroneID{Device: newDev}
			// 尝试获取设备版本
			runVer, appVer, bootVer, HwVer, protoVer, err := tracer.TracerGetVersionInfo(dev.Sn)
			logger.Infof("tracerLoopCheckIsInBootUpdateMod Ver: %v, %v, %v, %v, %v \n",
				runVer, appVer, bootVer, HwVer, protoVer)
			logger.Infof("tracerLoopCheckIsInBootUpdateMod err: %v \n", err)
			if err != nil || runVer != 0 {
				logger.Infof("tracerLoopCheckIsInBootUpdateMod runVer: %v err: %v \n", runVer, err)
				continue
			}
			logger.Infof("tracerLoopCheckIsInBootUpdateMod Ver: %v, %v, %v, %v, %v \n",
				runVer, appVer, bootVer, HwVer, protoVer)
			return tracer, true
		case <-timer:
			// 超时未进入boot模式
			go UpdateOtaStatus(cacheKey, &UpgradeStatus{
				Sn:         sn,
				DeviceType: int32(common.DEV_V2DRONEID),
				Status:     UpgradeStatusFailed,
				ErrMsg:     "设备未成功进入boot升级模式",
			})
			return nil, false
		}
	}
}

// fpvResetSystemUpgrade fpv系统复位异步更新
func (e *DeviceCenter) fpvResetSystemUpgrade(req *client.ResetSystemRequest) (int32, error) {
	logger.Info("fpv Reset System Upgrade Start")
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_FPV, req.Sn)
	dev := FindCacheDevice(req.Sn, common.DEV_FPV)
	if dev == nil {
		logger.Error("设备未在线")
		return 1, errors.New("设备未在线")
	}
	fpv := &Fpv{Device: dev}

	if req.Type == 0 {
		req.Type = 4
	}
	// 修改状态为升级中 同步状态给前端
	DevUpgradingMap.SetStatus(cacheKey, true)
	// 写入升级状态
	UpdateOtaStatus(cacheKey, &UpgradeStatus{
		Sn:         req.Sn,
		DeviceType: int32(common.DEV_FPV),
		Status:     UpgradeStatusReset,
		ErrMsg:     "系统复位重启中",
	})
	// 异步通过WebSocket向前端同步升级状态
	go OtaSyncUpgradeStatus(req.Sn, cacheKey, int32(common.DEV_FPV))

	// 复位进入boot升级模式
	status, err := fpv.FpvResetSystem()
	if err != nil {
		logger.Errorf("FpvResetSystem 系统复位失败 err: %v\n", err.Error())
		UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         req.Sn,
			DeviceType: int32(common.DEV_FPV),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("系统复位失败 err: %s", err.Error()),
		})
		return 1, nil
	}

	if status == 0 { // 复位成功
		logger.Info("Fpv Reset System 系统复位成功")
		// 清除缓存中的连接
		fpv.Close()
		DevStatusMap.Delete(cacheKey)
		// tracer boot 模式没有心跳 先将设备保存到复位map中
		ip := fpv.RemoteIp
		logger.Infof("Fpv ResetSystem Upgrade RemoteAddr %s \n", ip)
		DevResetMap.Store(ip, dev)
		// 开启协程异步进行后续升级步骤
		go e.fpvUpgrade(req.Sn, cacheKey, filepath.Join(req.PkgPath, req.FileName))

	} else {
		UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         req.Sn,
			DeviceType: int32(common.DEV_FPV),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("系统复位失败 status: %d", status),
		})
	}
	logger.Info("fpv Reset System Upgrade End")
	return status, nil
}

// tracerUpgrade 异步升级
func (e *DeviceCenter) fpvUpgrade(sn, cacheKey, pkgPathName string) {
	logger.Info("fpv Upgrade 开始升级")

	fpv := new(Fpv)

	// 每三秒尝试获取设备并查询设备是否进入boot升级模式
	fpv, ok := e.fpvLoopCheckIsInBootUpdateMod(sn, cacheKey, common.DEV_FPV)
	if !ok {
		logger.Error("fpv Upgrade 设备未进入boot升级模式")
		return
	}
	logger.Info("fpv Upgrade 发送升级包 A7 A8")
	// 发送升级包 A7 A8
	if !e.fpvSendPkgFile(fpv, pkgPathName, cacheKey, sn) {
		logger.Error("fpvUpgrade 设备发送升级包失败")
		return
	}

	logger.Info("fpvUpgrade 校验固件AC")
	// 校验固件AC
	if !e.fpvVerifyImage(fpv, cacheKey, sn) {
		logger.Error("fpvUpgrade 校验升级Ac包失败")
		return
	}
	logger.Info("fpvUpgrade 写入固件A9")
	// 写入固件A9
	if !e.fpvWriteUpdateData(fpv, cacheKey, sn) {
		logger.Error("tracerUpgrade 写入固件A9失败")
		return
	}

	logger.Info("fpvUpgrade 轮询查询写入状态A6直到写入成功")
	// 轮询查询写入状态A6直到写入成功
	if !e.fpvGetUpdateWriteStatus(fpv, cacheKey, sn) {
		logger.Error("fpvUpgrade 写入状态失败")
		return
	}

	logger.Info("tracerUpgrade AD运行app")
	// AD运行app
	e.fpvRunApp(fpv, cacheKey, sn, pkgPathName)
	return
}

// fpvRunApp AD运行app
func (e *DeviceCenter) fpvRunApp(fpv *Fpv, cacheKey, sn string, pkgPathName string) {
	logger.Info("fpv Run App Start")
	runStatus, err := fpv.FpvRunApp()
	if err != nil {
		logger.Errorf("fpv Run App err: ", err.Error())
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_FPV),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("AD app运行错误 err: %v", err.Error()),
		})
		return
	}
	if runStatus != 0 {
		logger.Errorf("AD app运行状态错误 runStatus: %v", runStatus)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_FPV),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("AD app运行状态错误 runStatus: %v", runStatus),
		})
		return
	}
	// 运行成功
	go UpdateOtaStatus(cacheKey, &UpgradeStatus{
		Sn:         sn,
		DeviceType: int32(common.DEV_FPV),
		Status:     UpgradeStatusSuccess,
		Permil:     1000,
		ErrMsg:     "升级成功",
	})
	logger.Info("fpvRunApp End")
}

// tracerGetUpdateWriteStatus 轮询查询固件写入状态
func (e *DeviceCenter) fpvGetUpdateWriteStatus(fpv *Fpv, cacheKey, sn string) bool {
	logger.Info("fpvGetUpdateWriteStatus start")
	totalPermil := 990
	writePermil := 995
	ticker := time.NewTicker(time.Second * 2)
	timer := time.After(time.Second * 60 * 20)
	defer ticker.Stop()
	exit := false
	for !exit {
		select {
		case <-ticker.C:
			logger.Info("fpvGetUpdateWriteStatus 调用A6")
			// 调用A6
			writeRsp, err := fpv.FpvGetUpdateWriteStatus()
			if err != nil {
				logger.Errorf("A6获取写入状态错误 err: %v", err.Error())
				go UpdateOtaStatus(cacheKey, &UpgradeStatus{
					Sn:         sn,
					DeviceType: int32(common.DEV_FPV),
					Status:     UpgradeStatusFailed,
					ErrMsg:     fmt.Sprintf("A6获取写入状态错误 err: %v", err.Error()),
				})
				return false
			}
			if writeRsp.Status == 0 {
				// 更新写入状态
				permil := int64(writePermil)*int64(writeRsp.Permil)/1000 + int64(totalPermil)
				go UpdateOtaStatus(cacheKey, &UpgradeStatus{
					Sn:         sn,
					DeviceType: int32(common.DEV_FPV),
					Status:     UpgradeStatusWritePkg,
					Permil:     permil,
					ErrMsg:     "写入升级包中",
				})
			} else if writeRsp.Status == 2 {
				// 写入成功
				go UpdateOtaStatus(cacheKey, &UpgradeStatus{
					Sn:         sn,
					DeviceType: int32(common.DEV_FPV),
					Status:     UpgradeStatusWritePkg,
					Permil:     int64(totalPermil + writePermil),
					ErrMsg:     "写入升级包完成",
				})
				exit = true
			} else {
				// 状态错误
				go UpdateOtaStatus(cacheKey, &UpgradeStatus{
					Sn:         sn,
					DeviceType: int32(common.DEV_FPV),
					Status:     UpgradeStatusFailed,
					ErrMsg:     fmt.Sprintf("A6获取写入状态错误 status: %v", writeRsp.Status),
				})
				logger.Errorf("fpvGetUpdateWriteStatus 状态错误", writeRsp.Status)
				return false
			}

		case <-timer:
			// 超时
			go UpdateOtaStatus(cacheKey, &UpgradeStatus{
				Sn:         sn,
				DeviceType: int32(common.DEV_FPV),
				Status:     UpgradeStatusFailed,
				ErrMsg:     fmt.Sprintf("写入超时"),
			})
			logger.Errorf("fpvGetUpdateWriteStatus 写入超时")
			return false
		}
	}
	logger.Info("fpvGetUpdateWriteStatus End")
	return true
}

// fpvWriteUpdateData 写入固件A9
func (e *DeviceCenter) fpvWriteUpdateData(fpv *Fpv, cacheKey, sn string) bool {
	logger.Info("fpvWriteUpdateData start")
	writeStatus, err := fpv.FpvWriteUpdateData()
	if err != nil {
		logger.Errorf("fpvWriteUpdateData writeStatus %v", err.Error())
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_FPV),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("A9写入固件错误 err: %v", err.Error()),
		})
		return false
	}
	logger.Infof("fpvWriteUpdateData writeStatus %v", writeStatus)
	if writeStatus != 0 {
		logger.Infof("A9写入固件错误 writeStatus: %v", writeStatus)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_FPV),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("A9写入固件错误 writeStatus: %v", writeStatus),
		})
		return false
	}
	logger.Info("fpvWriteUpdateData End")
	return true
}

// fpvVerifyImage 校验升级包固件AC
func (e *DeviceCenter) fpvVerifyImage(fpv *Fpv, cacheKey, sn string) bool {
	logger.Infof("fpvVerifyImage start %v \n", cacheKey)
	verifyStatus, err := fpv.FpvVerifyImage()
	if err != nil {
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_FPV),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("AC校验升级固件错误 err: %v", err.Error()),
		})
		return false
	}
	logger.Infof("fpvVerifyImage verifyStatus %v", verifyStatus)
	if verifyStatus != 0 {
		logger.Infof("fpvVerifyImage AC校验升级固件状态错误 %v", verifyStatus)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_FPV),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("AC校验升级固件状态错误 verifyStatus: %v", verifyStatus),
		})
		return false
	}
	logger.Infof("fpvVerifyImage end %v \n", verifyStatus)
	return true
}

// fpvSendPkgFile 发送升级包 A7 A8
func (e *DeviceCenter) fpvSendPkgFile(fpv *Fpv, pkgPathName, cacheKey, sn string) bool {
	logger.Info("fpvSendPkgFile start", pkgPathName, cacheKey)
	// 当前总进度千分比
	totalPermil := 50.0
	// 发送文件占总进度的百分比
	sendPermil := 940.0
	// 读取更新包文件
	f, err := os.Open(pkgPathName)
	defer f.Close()

	if err != nil {
		logger.Errorf("fpvSendPkgFile os.Open err: %v\n", err)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_FPV),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("读取升级包错误： %v", err.Error()),
		})
		return false
	}

	stat, _ := f.Stat()
	filesize := stat.Size()
	logger.Infof("fpvSendPkgFile filesize %v", filesize)
	// 获取数据包前4k字节调用抢的A7请求升级接口发送前256个字节
	headerSize := 4096
	reqUpgradeBuf := make([]byte, headerSize)
	n, err := f.Read(reqUpgradeBuf)
	if err != nil && err != io.EOF {
		logger.Errorf("fpvSendPkgFile f.Read err: %v, n: %v", err, n)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_FPV),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("读取文件错误： %v", err.Error()),
		})
		return false
	}

	if len(reqUpgradeBuf) != n {
		logger.Errorf("fpvSendPkgFile len(reqUpgradeBuf): %v, n: %v \n", len(reqUpgradeBuf), n)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:          sn,
			DeviceType:  int32(common.DEV_FPV),
			Status:      UpgradeStatusFailed,
			PkgPathName: pkgPathName,
			ErrMsg:      fmt.Sprintf("读取文件错误 len(reqUpgradeBuf): %v, n: %v", len(reqUpgradeBuf), n),
		})
		return false
	}
	var reqUpData [256]uint8
	for i, b := range reqUpgradeBuf[:256] {
		reqUpData[i] = b
	}
	logger.Infof("fpvSendPkgFile reqUpData %v", reqUpData)
	status, err := fpv.FpvRequestUpgrade(reqUpData, 3)
	if err != nil || status != 0 {
		logger.Errorf("fpvSendPkgFile fpv.FpvRequestUpgrade, status: %d, err: %v \n", status, err)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:          sn,
			DeviceType:  int32(common.DEV_FPV),
			Status:      UpgradeStatusFailed,
			PkgPathName: pkgPathName,
			ErrMsg:      fmt.Sprintf("A7请求固件升级错误： %v, status: %v", err, status),
		})
		return false
	}
	permil := totalPermil + sendPermil*float64(headerSize)/float64(filesize)
	// 写入状态
	logger.Infof("fpvSendPkgFile permil %v", permil)
	go UpdateOtaStatus(cacheKey, &UpgradeStatus{
		Sn:         sn,
		DeviceType: int32(common.DEV_FPV),
		Status:     UpgradeStatusSendPkg,
		Permil:     int64(permil),
		ErrMsg:     "向FPV发送升级包中",
	})
	//向Tracer发送0xAE消息，获取下载固件数据包最大字节数
	//lenBuff, err := tracer.TracerGetUpdateTimeoutRetryTime()
	//if lenBuff.ImagePkgLenMax == 0 {
	//	lenBuff.ImagePkgLenMax = 4096
	//}
	// 将文件剩下的数据调A8发送固件数据接口
	buf := make([]byte, 4096)
	var offset = 0
	for {
		n, err := f.Read(buf)
		if n == 0 {
			// 发送完成
			logger.Info("fpvSendPkgFile done")
			go UpdateOtaStatus(cacheKey, &UpgradeStatus{
				Sn:          sn,
				DeviceType:  int32(common.DEV_FPV),
				Status:      UpgradeStatusSendPkg,
				PkgPathName: pkgPathName,
				Permil:      int64(totalPermil + sendPermil),
				ErrMsg:      "向Fpv发送升级包完成",
			})
			break
		}
		if err != nil && err != io.EOF {
			logger.Errorf("fpvSendPkgFile f.Read err: %v \n", err)
			go UpdateOtaStatus(cacheKey, &UpgradeStatus{
				Sn:          sn,
				DeviceType:  int32(common.DEV_FPV),
				Status:      UpgradeStatusFailed,
				PkgPathName: pkgPathName,
				ErrMsg:      fmt.Sprintf("读取升级包错误： %v", err.Error()),
			})
			return false
		}
		// 发送升级包数据
		sendPkgRes, err := fpv.FpvSendUpdatePkg(uint32(offset), buf[:n])
		if err != nil {
			logger.Errorf("fpvSendPkgFile, sendPkgRes err: %v \n", err)
			go UpdateOtaStatus(cacheKey, &UpgradeStatus{
				Sn:          sn,
				DeviceType:  int32(common.DEV_FPV),
				Status:      UpgradeStatusFailed,
				PkgPathName: pkgPathName,
				ErrMsg:      fmt.Sprintf("发送升级固件错误： err: %v", err.Error()),
			})
			return false
		}
		if sendPkgRes.Status != 0 && sendPkgRes.Status != 128 {
			logger.Errorf("fpvSendPkgFile sendPkgRes: %v \n", sendPkgRes)
			go UpdateOtaStatus(cacheKey, &UpgradeStatus{
				Sn:          sn,
				DeviceType:  int32(common.DEV_FPV),
				Status:      UpgradeStatusFailed,
				PkgPathName: pkgPathName,
				ErrMsg:      fmt.Sprintf("发送升级固件状态错误 status: %v", sendPkgRes.Status),
			})
			return false
		}

		offset += n
		permil = totalPermil + sendPermil*float64(headerSize+offset)/float64(filesize)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:          sn,
			DeviceType:  int32(common.DEV_FPV),
			Status:      UpgradeStatusSendPkg,
			PkgPathName: pkgPathName,
			Permil:      int64(permil),
			ErrMsg:      "向Fpv发送升级包中",
		})
		logger.Info("fpvSendPkgFile sendPermil:", sendPermil)
	}
	logger.Info("fpvSendPkgFile end")
	return true
}

// fpvLoopCheckIsInBootUpdateMod 每三秒尝试获取设备并查询设备是否进入boot升级模式
func (e *DeviceCenter) fpvLoopCheckIsInBootUpdateMod(sn, cacheKey string, deviceType common.DeviceType) (*Fpv, bool) {
	logger.Info("fpvLoopCheckIsInBootUpdateMod start")
	ticker := time.NewTicker(time.Second * 3)
	timer := time.After(time.Second * 60 * 5)
	dev := new(Device)
	for {
		select {
		case <-ticker.C:
			dev = FindCacheDevice(sn, deviceType)
			if dev == nil || dev.Conn == nil || dev.WaitTaskMap == nil {
				logger.Info("fpvLoopCheckIsInBootUpdateMod 获取设备连接失败")
				continue
			}
			// 保存为局部的Dev防止con连接被修改
			newDev := &Device{
				Name:        dev.Name,
				Sn:          dev.Sn,
				Conn:        dev.Conn,
				Status:      dev.Status,
				DevType:     dev.DevType,
				IsEnable:    dev.IsEnable,
				WaitTaskMap: dev.WaitTaskMap,
			}
			fpv := &Fpv{Device: newDev}
			// 尝试获取设备版本
			runVer, appVer, bootVer, HwVer, protoVer, err := fpv.FpvGetVersionInfo()
			logger.Infof("fpv LoopCheckIsInBootUpdateMod Ver: %v, %v, %v, %v, %v \n",
				runVer, appVer, bootVer, HwVer, protoVer)
			logger.Infof("fpv LoopCheckIsInBootUpdateMod err: %v \n", err)
			if err != nil || runVer != 0 {
				logger.Infof("fpvLoopCheckIsInBootUpdateMod runVer: %v err: %v \n", runVer, err)
				continue
			}
			logger.Infof("fpv LoopCheckIsInBootUpdateMod Ver: %v, %v, %v, %v, %v \n",
				runVer, appVer, bootVer, HwVer, protoVer)
			return fpv, true
		case <-timer:
			// 超时未进入boot模式
			go UpdateOtaStatus(cacheKey, &UpgradeStatus{
				Sn:         sn,
				DeviceType: int32(common.DEV_FPV),
				Status:     UpgradeStatusFailed,
				ErrMsg:     "设备未成功进入boot升级模式",
			})
			return nil, false
		}
	}
}

// ------------SFL OTA升级

// sflWgetUpgrade Tracer Wget升级
func (e *DeviceCenter) sflWgetUpgrade(req *client.ResetSystemRequest) (int32, error) {
	logger.Info("sflWgetUpgrade Start:", req)
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_SFL, req.Sn)
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		logger.Error("设备未在线")
		return 1, errors.New("设备未在线")
	}
	sfl := &Sfl{Device: dev}
	if req.Type == 0 {
		req.Type = 4
	}
	// 修改状态为升级中 同步状态给前端
	DevUpgradingMap.SetStatus(cacheKey, true)
	// 写入升级状态
	UpdateOtaStatus(cacheKey, &UpgradeStatus{
		Sn:         req.Sn,
		DeviceType: int32(common.DEV_SFL),
		Status:     UpgradeStatusSendPkg,
		ErrMsg:     "向系统发升级包中",
	})
	// 异步通过WebSocket向前端同步升级状态
	go OtaSyncUpgradeStatus(req.Sn, cacheKey, int32(common.DEV_SFL))
	go func() {
		ctx, cancel := context.WithCancel(context.Background())
		defer cancel()
		var c2Ip string
		localIPInfos, err := iphelper.GetLocalIPInfos()
		if err != nil {
			logger.Errorf("get IP err err %v", err)
			return
		}
		defaultIP := ""
		for _, ipInfo := range localIPInfos {
			logger.Infof("ip Info is %v,remote Ip is :%v", ipInfo.LocalIP, sfl.RemoteIp)
			isSame := isSamePrefix(ipInfo.LocalIP, sfl.RemoteIp)
			if isSame {
				c2Ip = ipInfo.LocalIP
			}
			if strings.Contains(ipInfo.LocalIP, "169.254") {
				defaultIP = ipInfo.LocalIP
			}
		}
		if c2Ip == "" {
			c2Ip = defaultIP
		}

		fileServer := http.FileServer(http.Dir(req.PkgPath))

		server := &http.Server{
			Addr:    c2Ip + ":8081",
			Handler: fileServer,
		}
		// 用于表示服务器状态的变量
		go func() {
			logger.Info("file server start:", server.Addr)
			if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
				logger.Error("file server start err:", err)
			}
		}()

		// 开启协程异步进行后续升级步骤
		//go e.tracerUpgrade(req.Sn, cacheKey, filepath.Join(req.PkgPath, req.FileName))
		stopChan := make(chan struct{})
		//执行其他操作
		defer close(stopChan)
		// 启动一个新的协程来等待关闭信号
		go func() {
			// 等待接收到关闭信号
			<-stopChan

			logger.Info("HTTP service stop")
			timeoutCtx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
			defer cancel()

			if err := server.Shutdown(timeoutCtx); err != nil {
				logger.Error("HTTP service stop  err：", err)
			}
			logger.Info("HTTP is close")
		}()

		if !e.sflSendUpgradeF1(sfl, cacheKey, req.Sn, req.FileName, c2Ip) {
			logger.Error("download file err  F1")
			return
		}
		if !e.sflSendUpgradeF2(ctx, sfl, cacheKey, req.Sn, req.FileName) {
			logger.Error("download file err  F2")
			return
		}

		if !e.sflSendUpgradeF3(sfl, cacheKey, req.Sn) {
			logger.Error("download file err  F3")
		}

		logger.Info("sflWgetUpgrade End")
	}()

	return 0, nil
}

// sflSendUpgradeF1 发送请求固件升级
func (e *DeviceCenter) sflSendUpgradeF1(sfl *Sfl, cacheKey, sn string, fileName string, c2Ip string) bool {
	logger.Info("SflSend Upgrade F1 start")
	time.Sleep(time.Second * 3)
	writeStatus, err := sfl.SflSendUpgradeF1(fileName, c2Ip)
	if err != nil {
		logger.Errorf("SflWriteUpdateData writeStatus %v", err.Error())
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_SFL),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("F1  err: %v", err.Error()),
		})
		return false
	}
	logger.Infof("SflSend Upgrade F1 writeStatus %v", writeStatus)
	if writeStatus != 0 {
		logger.Infof("SflSendU pgrade F1 writeStatus err: %v", writeStatus)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_SFL),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("F1 writeStatus: %v", writeStatus),
		})
		return false
	}
	if writeStatus == 0 {
		logger.Infof("SflSend Upgrade F1 writeStatus suc: %v", writeStatus)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:          sn,
			DeviceType:  int32(common.DEV_SFL),
			Status:      UpgradeStatusSendPkg,
			PkgPathName: fileName,
			ErrMsg:      "向Sfl发送升级包中",
		})
	}
	logger.Info("SflSend Upgrade F1 End")
	return true
}

// sflSendUpgradeF2 发送请求固件升级
func (e *DeviceCenter) sflSendUpgradeF2(ctx context.Context, sfl *Sfl, cacheKey, sn string, pkgName string) bool {
	logger.Info("sflSend Upgrade F2 start")
	timer1 := time.NewTicker(1 * time.Second)
	for {
		select {
		case <-timer1.C:
			writeStatus, err := sfl.SflSendUpgradeF2()
			if err != nil {
				logger.Errorf("sflWriteUpdateData writeStatus %v", err.Error())
				go UpdateOtaStatus(cacheKey, &UpgradeStatus{
					Sn:         sn,
					DeviceType: int32(common.DEV_SFL),
					Status:     UpgradeStatusFailed,
					ErrMsg:     fmt.Sprintf("F2 get err: %v", err.Error()),
				})
				return false
			}
			logger.Infof("sflSend Upgrade F2 writeStatus %v", writeStatus)
			if writeStatus <= 95 && writeStatus != -1 {
				logger.Infof("sflSend get F2 writeStatus : %v", writeStatus)
				go UpdateOtaStatus(cacheKey, &UpgradeStatus{
					Sn:          sn,
					DeviceType:  int32(common.DEV_SFL),
					Status:      UpgradeStatusSendPkg,
					PkgPathName: pkgName,
					Permil:      int64(writeStatus * 10),
					ErrMsg:      "向sfl发送升级包中",
				})
			}
			if writeStatus == 100 {
				logger.Infof("sflSend get F2 writeStatus finish: %v", writeStatus)
				go UpdateOtaStatus(cacheKey, &UpgradeStatus{
					Sn:          sn,
					DeviceType:  int32(common.DEV_SFL),
					Status:      UpgradeStatusSendPkg,
					PkgPathName: pkgName,
					Permil:      int64((writeStatus - 5) * 10),
					ErrMsg:      "向sfl发送升级包中",
				})
				return true
			}
		case <-ctx.Done():
			return false
		}
	}

}

// stp120SendUpgradeF1 发送请求固件升级
func (e *DeviceCenter) stp120SendUpgradeF1(stp120 *STP120, cacheKey, sn string, fileName string, c2Ip string) bool {
	logger.Info("Stp120 Send Upgrade F1 start")
	time.Sleep(time.Second * 3)
	writeStatus, err := stp120.SendUpgradeF1(fileName, c2Ip)
	if err != nil {
		logger.Errorf("Stp120 WriteUpdateData writeStatus %v", err.Error())
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_STP120),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("F1  err: %v", err.Error()),
		})
		return false
	}
	logger.Infof("Stp120 Send Upgrade F1 writeStatus %v", writeStatus)
	if writeStatus != 0 {
		logger.Infof("Stp120 SendU pgrade F1 writeStatus err: %v", writeStatus)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_STP120),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("F1 writeStatus: %v", writeStatus),
		})
		return false
	}
	if writeStatus == 0 {
		logger.Infof("Stp120 Send Upgrade F1 writeStatus suc: %v", writeStatus)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:          sn,
			DeviceType:  int32(common.DEV_STP120),
			Status:      UpgradeStatusSendPkg,
			PkgPathName: fileName,
			ErrMsg:      "向Sfl发送升级包中",
		})
	}
	logger.Info("Stp120 Send Upgrade F1 End")
	return true
}

// stp120SendUpgradeF2 发送请求固件升级
func (e *DeviceCenter) stp120SendUpgradeF2(ctx context.Context, stp120 *STP120, cacheKey, sn string, pkgName string) bool {
	logger.Info("stp120 Send Upgrade F2 start")
	timer1 := time.NewTicker(1 * time.Second)
	for {
		select {
		case <-timer1.C:
			writeStatus, err := stp120.SendUpgradeF2()
			if err != nil {
				logger.Errorf("stp120 WriteUpdateData writeStatus %v", err.Error())
				go UpdateOtaStatus(cacheKey, &UpgradeStatus{
					Sn:         sn,
					DeviceType: int32(common.DEV_STP120),
					Status:     UpgradeStatusFailed,
					ErrMsg:     fmt.Sprintf("F2 get err: %v", err.Error()),
				})
				return false
			}
			logger.Infof("stp120 Send Upgrade F2 writeStatus %v", writeStatus)
			if writeStatus <= 95 && writeStatus != -1 {
				logger.Infof("sflSend get F2 writeStatus : %v", writeStatus)
				go UpdateOtaStatus(cacheKey, &UpgradeStatus{
					Sn:          sn,
					DeviceType:  int32(common.DEV_STP120),
					Status:      UpgradeStatusSendPkg,
					PkgPathName: pkgName,
					Permil:      int64(writeStatus * 10),
					ErrMsg:      "向stp120发送升级包中",
				})
			}
			if writeStatus == 100 {
				logger.Infof("stp120 Send get F2 writeStatus finish: %v", writeStatus)
				go UpdateOtaStatus(cacheKey, &UpgradeStatus{
					Sn:          sn,
					DeviceType:  int32(common.DEV_STP120),
					Status:      UpgradeStatusSendPkg,
					PkgPathName: pkgName,
					Permil:      int64((writeStatus - 5) * 10),
					ErrMsg:      "向stp120发送升级包中",
				})
				return true
			}
		case <-ctx.Done():
			return false
		}
	}

}

// stp120SendUpgradeF3 发送请求固件升级
func (e *DeviceCenter) stp120SendUpgradeF3(stp120 *STP120, cacheKey, sn string) bool {
	logger.Info("stp120 Send Upgrade F3 start")
	writeStatus, err := stp120.SendUpgradeF3()
	if err != nil {
		logger.Errorf("stp120 WriteUpdateData writeStatus %v", err.Error())
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_STP120),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("F3 download err: %v", err.Error()),
		})
		return false
	}
	logger.Infof("stp120 Send Upgrade F3 writeStatus %v", writeStatus)
	if writeStatus != 0 {
		logger.Infof("stp120 Send Upgrade F3 writeStatus err: %v", writeStatus)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_STP120),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("F3 download writeStatus: %v", writeStatus),
		})
		return false
	}
	if writeStatus == 0 {
		logger.Infof("stp120 Send Upgrade F3 writeStatus Finish %v", writeStatus)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_STP120),
			Status:     UpgradeStatusSuccess,
			Permil:     1000,
			ErrMsg:     "向sfl发送升级包完成",
		})
	}
	logger.Info("stp120 Send Upgrade F3 End")
	return true
}

// sflSendUpgradeF3 发送请求固件升级
func (e *DeviceCenter) sflSendUpgradeF3(sfl *Sfl, cacheKey, sn string) bool {
	logger.Info("sflSend Upgrade F3 start")
	writeStatus, err := sfl.SflSendUpgradeF3()
	if err != nil {
		logger.Errorf("sflWriteUpdateData writeStatus %v", err.Error())
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_SFL),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("F3 download err: %v", err.Error()),
		})
		return false
	}
	logger.Infof("sflSend Upgrade F3 writeStatus %v", writeStatus)
	if writeStatus != 0 {
		logger.Infof("sflSend Upgrade F3 writeStatus err: %v", writeStatus)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_SFL),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("F3 download writeStatus: %v", writeStatus),
		})
		return false
	}
	if writeStatus == 0 {
		logger.Infof("sflSend Upgrade F3 writeStatus Finish %v", writeStatus)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_SFL),
			Status:     UpgradeStatusSuccess,
			Permil:     1000,
			ErrMsg:     "向sfl发送升级包完成",
		})
	}
	logger.Info("sflSend Upgrade F3 End")
	return true
}

//-------Agx
// ------------Agx OTA升级

// agxWgetUpgrade Agx Wget升级
func (e *DeviceCenter) agxWgetUpgrade(req *client.ResetSystemRequest) (int32, error) {

	logger.Info("agxWgetUpgrade Start:", req)
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_AGX, req.Sn)
	dev := FindCacheDevice(req.Sn, common.DEV_AGX)
	if dev == nil {
		logger.Error("设备未在线")
		return 1, errors.New("设备未在线")
	}
	agx := &Agx{Device: dev}
	if req.Type == 0 {
		req.Type = 4
	}
	// 修改状态为升级中 同步状态给前端
	DevUpgradingMap.SetStatus(cacheKey, true)
	// 写入升级状态
	UpdateOtaStatus(cacheKey, &UpgradeStatus{
		Sn:         req.Sn,
		DeviceType: int32(common.DEV_AGX),
		Status:     UpgradeStatusSendPkg,
		ErrMsg:     "向系统发升级包中",
	})
	// 异步通过WebSocket向前端同步升级状态
	go OtaSyncUpgradeStatus(req.Sn, cacheKey, int32(common.DEV_AGX))
	go func() {
		ctx, cancel := context.WithCancel(context.Background())
		defer cancel()
		var c2Ip string
		localIPInfos, err := iphelper.GetLocalIPInfos()
		if err != nil {
			logger.Errorf("get IP err err %v", err)
			return
		}
		defaultIP := ""
		for _, ipInfo := range localIPInfos {
			logger.Infof("ip Info is %v,remote Ip is :%v", ipInfo.LocalIP, agx.RemoteIp)
			isSame := isSamePrefix(ipInfo.LocalIP, agx.RemoteIp)
			if isSame {
				c2Ip = ipInfo.LocalIP
			}
			if strings.Contains(ipInfo.LocalIP, "169.254") {
				defaultIP = ipInfo.LocalIP
			}
		}
		if c2Ip == "" {
			c2Ip = defaultIP
		}

		fileServer := http.FileServer(http.Dir(req.PkgPath))

		server := &http.Server{
			Addr:    c2Ip + ":8081",
			Handler: fileServer,
		}
		go func() {
			logger.Info("file server start:", server.Addr)
			if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
				logger.Error("file server start err:", err)
			}
		}()
		// 开启协程异步进行后续升级步骤
		//go e.tracerUpgrade(req.Sn, cacheKey, filepath.Join(req.PkgPath, req.FileName))
		stopChan := make(chan struct{})
		//执行其他操作
		defer close(stopChan)
		// 启动一个新的协程来等待关闭信号
		go func() {
			// 等待接收到关闭信号
			<-stopChan

			logger.Info("HTTP service stop")
			timeoutCtx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
			defer cancel()

			if err := server.Shutdown(timeoutCtx); err != nil {
				logger.Error("HTTP service stop  err：", err)
			}
			logger.Info("HTTP is close")
		}()
		if !e.agxSendUpgradeF1(agx, cacheKey, req.Sn, req.FileName, c2Ip) {
			logger.Error("download file err  F1")
			return
		}
		if !e.agxSendUpgradeF2(ctx, agx, cacheKey, req.Sn, req.FileName) {
			logger.Error("download file err  F2")
			return
		}

		if !e.agxSendUpgradeF3(agx, cacheKey, req.Sn) {
			logger.Error("download file err  F3")
		}

		logger.Info("agxWgetUpgrade End")
	}()

	return 0, nil
}

// agxSendUpgradeF1 发送请求固件升级
func (e *DeviceCenter) agxSendUpgradeF1(agx *Agx, cacheKey, sn string, fileName string, c2Ip string) bool {
	logger.Info("AgxSend Upgrade F1 start")
	time.Sleep(time.Second * 1)
	writeStatus, err := agx.AgxSendUpgradeF1(fileName, c2Ip)
	if err != nil {
		logger.Errorf("AgxWriteUpdateData writeStatus %v", err.Error())
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_AGX),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("A9写入固件错误 err: %v", err.Error()),
		})
		return false
	}
	logger.Infof("AgxSend Upgrade F1 writeStatus %v", writeStatus)
	if writeStatus != 0 {
		logger.Infof("AgxSendU pgrade F1 writeStatus err: %v", writeStatus)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_AGX),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("A9写入固件错误 writeStatus: %v", writeStatus),
		})
		return false
	}
	if writeStatus == 0 {
		logger.Infof("AgxSendU pgrade F1 writeStatus suc: %v", writeStatus)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:          sn,
			DeviceType:  int32(common.DEV_AGX),
			Status:      UpgradeStatusSendPkg,
			PkgPathName: fileName,
			ErrMsg:      "向Agx发送升级包中",
		})
	}
	logger.Info("AgxSend Upgrade F1 End")
	return true
}

// agxSendUpgradeF2 发送请求固件升级
func (e *DeviceCenter) agxSendUpgradeF2(ctx context.Context, agx *Agx, cacheKey, sn string, pkgName string) bool {
	logger.Info("agxSend Upgrade F2 start")
	timer1 := time.NewTicker(1 * time.Second)
	tryCount := 0
	for {
		select {
		case <-timer1.C:
			writeStatus, err := agx.AgxSendUpgradeF2()
			if err != nil {
				logger.Errorf("agxWriteUpdateData writeStatus %v", err.Error())
				tryCount++
				if tryCount >= 5 {
					go UpdateOtaStatus(cacheKey, &UpgradeStatus{
						Sn:         sn,
						DeviceType: int32(common.DEV_AGX),
						Status:     UpgradeStatusFailed,
						ErrMsg:     fmt.Sprintf("F2 get err: %v", err.Error()),
					})
					return false
				}

			}
			logger.Infof("agxSend Upgrade F2 writeStatus %v", writeStatus)
			if writeStatus <= 95 {
				logger.Infof("agxSend get F2 writeStatus : %v", writeStatus)
				go UpdateOtaStatus(cacheKey, &UpgradeStatus{
					Sn:          sn,
					DeviceType:  int32(common.DEV_AGX),
					Status:      UpgradeStatusSendPkg,
					PkgPathName: pkgName,
					Permil:      int64(writeStatus * 10),
					ErrMsg:      "向agx发送升级包中",
				})
			}
			if writeStatus == 100 {
				logger.Infof("agxSend get F2 writeStatus finish: %v", writeStatus)
				go UpdateOtaStatus(cacheKey, &UpgradeStatus{
					Sn:          sn,
					DeviceType:  int32(common.DEV_AGX),
					Status:      UpgradeStatusSendPkg,
					PkgPathName: pkgName,
					Permil:      int64((writeStatus - 5) * 10),
					ErrMsg:      "向agx发送升级包中",
				})
				return true
			}
		case <-ctx.Done():
			return false
		}
	}

}

// agxSendUpgradeF3 发送请求固件升级
func (e *DeviceCenter) agxSendUpgradeF3(agx *Agx, cacheKey, sn string) bool {
	logger.Info("sflSend Upgrade F3 start")
	writeStatus, err := agx.AgxSendUpgradeF3()
	if err != nil {
		logger.Errorf("agxWriteUpdateData writeStatus %v", err.Error())
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_AGX),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("F3 download err: %v", err.Error()),
		})
		return false
	}
	logger.Infof("agx Upgrade F3 writeStatus %v", writeStatus)
	if writeStatus != 0 {
		logger.Infof("agxSend Upgrade F3 writeStatus err: %v", writeStatus)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_AGX),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("F3 download writeStatus: %v", writeStatus),
		})
		return false
	}
	if writeStatus == 0 {
		logger.Infof("agxSend Upgrade F3 writeStatus Finish %v", writeStatus)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_AGX),
			Status:     UpgradeStatusSuccess,
			Permil:     1000,
			ErrMsg:     "向agx发送升级包完成",
		})
	}
	logger.Info("agxnd Upgrade F3 End")
	return true
}

// stp120WgetUpgrade stp120 wget 升级
func (e *DeviceCenter) stp120WgetUpgrade(req *client.ResetSystemRequest) (int32, error) {
	logger.Info("stp120WgetUpgrade Start:", req)

	stp120Dev, err := GetOnLineDev[*STP120](req.GetSn(), common.DEV_STP120)
	if err != nil {
		logger.Errorf("err: %v, dev: %v", err, req.GetSn())
		return 1, err
	}

	cacheKey := fmt.Sprintf("%d_%s", common.DEV_STP120, req.Sn)
	if req.Type == 0 {
		req.Type = 4
	}
	// 修改状态为升级中 同步状态给前端
	DevUpgradingMap.SetStatus(cacheKey, true)
	// 写入升级状态
	UpdateOtaStatus(cacheKey, &UpgradeStatus{
		Sn:         req.Sn,
		DeviceType: int32(common.DEV_STP120),
		Status:     UpgradeStatusSendPkg,
		ErrMsg:     "向系统发升级包中",
	})
	// 异步通过WebSocket向前端同步升级状态
	go OtaSyncUpgradeStatus(req.Sn, cacheKey, int32(common.DEV_STP120))
	go func() {
		ctx, cancel := context.WithCancel(context.Background())
		defer cancel()
		var c2Ip string
		localIPInfos, err := iphelper.GetLocalIPInfos()
		if err != nil {
			logger.Errorf("get IP err err %v", err)
			return
		}
		defaultIP := ""
		for _, ipInfo := range localIPInfos {
			logger.Infof("ip Info is %v,remote Ip is :%v", ipInfo.LocalIP, stp120Dev.RemoteIp)
			isSame := isSamePrefix(ipInfo.LocalIP, stp120Dev.RemoteIp)
			if isSame {
				c2Ip = ipInfo.LocalIP
			}
			if strings.Contains(ipInfo.LocalIP, "169.254") {
				defaultIP = ipInfo.LocalIP
			}
		}
		if c2Ip == "" {
			c2Ip = defaultIP
		}

		fileServer := http.FileServer(http.Dir(req.PkgPath))

		server := &http.Server{
			Addr:    c2Ip + ":8081",
			Handler: fileServer,
		}
		// 用于表示服务器状态的变量
		go func() {
			logger.Info("file server start:", server.Addr)
			if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
				logger.Error("file server start err:", err)
			}
		}()

		stopChan := make(chan struct{})
		//执行其他操作
		defer close(stopChan)
		// 启动一个新的协程来等待关闭信号
		go func() {
			// 等待接收到关闭信号
			<-stopChan

			logger.Info("HTTP service stop")
			timeoutCtx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
			defer cancel()

			if err := server.Shutdown(timeoutCtx); err != nil {
				logger.Error("HTTP service stop  err：", err)
			}
			logger.Info("HTTP is close")
		}()

		if !e.stp120SendUpgradeF1(stp120Dev, cacheKey, req.Sn, req.FileName, c2Ip) {
			logger.Error("download file err  F1")
			return
		}
		if !e.stp120SendUpgradeF2(ctx, stp120Dev, cacheKey, req.Sn, req.FileName) {
			logger.Error("download file err  F2")
			return
		}

		if !e.stp120SendUpgradeF3(stp120Dev, cacheKey, req.Sn) {
			logger.Error("download file err  F3")
		}

		logger.Info("stp120 WgetUpgrade End")
	}()

	return 0, nil
}

// ------------枪+云台OTA升级
// gunCloudWgetUpgrade gunCloud Wget升级
func (e *DeviceCenter) gunCloudWgetUpgrade(req *client.ResetSystemRequest) (int32, error) {

	logger.Info("gunCloudWgetUpgrade Start:", req)
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_HUNTER_PLATFORM, req.Sn)
	dev := FindCacheDevice(req.Sn, common.DEV_HUNTER_PLATFORM)
	if dev == nil {
		logger.Error("设备未在线")
		return 1, errors.New("设备未在线")
	}
	gunCloud := &GunsPlatform{Device: dev}
	if req.Type == 0 {
		req.Type = 4
	}
	// 修改状态为升级中 同步状态给前端
	DevUpgradingMap.SetStatus(cacheKey, true)
	// 写入升级状态
	UpdateOtaStatus(cacheKey, &UpgradeStatus{
		Sn:         req.Sn,
		DeviceType: int32(common.DEV_HUNTER_PLATFORM),
		Status:     UpgradeStatusSendPkg,
		ErrMsg:     "向系统发升级包中",
	})
	// 异步通过WebSocket向前端同步升级状态
	go OtaSyncUpgradeStatus(req.Sn, cacheKey, int32(common.DEV_HUNTER_PLATFORM))
	go func() {
		ctx, cancel := context.WithCancel(context.Background())
		defer cancel()
		var c2Ip string
		localIPInfos, err := iphelper.GetLocalIPInfos()
		if err != nil {
			logger.Errorf("get IP err err %v", err)
			return
		}
		defaultIP := ""
		for _, ipInfo := range localIPInfos {
			logger.Infof("ip Info is %v,remote Ip is :%v", ipInfo.LocalIP, gunCloud.RemoteIp)
			isSame := isSamePrefix(ipInfo.LocalIP, gunCloud.RemoteIp)
			if isSame {
				c2Ip = ipInfo.LocalIP
			}
			if strings.Contains(ipInfo.LocalIP, "169.254") {
				defaultIP = ipInfo.LocalIP
			}
		}
		if c2Ip == "" {
			c2Ip = defaultIP
		}

		fileServer := http.FileServer(http.Dir(req.PkgPath))

		server := &http.Server{
			Addr:    c2Ip + ":8081",
			Handler: fileServer,
		}
		go func() {
			logger.Info("file server start:", server.Addr)
			if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
				logger.Error("file server start err:", err)
			}
		}()
		// 开启协程异步进行后续升级步骤
		//go e.tracerUpgrade(req.Sn, cacheKey, filepath.Join(req.PkgPath, req.FileName))
		stopChan := make(chan struct{})
		//执行其他操作
		defer close(stopChan)
		// 启动一个新的协程来等待关闭信号
		go func() {
			// 等待接收到关闭信号
			<-stopChan

			logger.Info("HTTP service stop")
			timeoutCtx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
			defer cancel()

			if err := server.Shutdown(timeoutCtx); err != nil {
				logger.Error("HTTP service stop  err：", err)
			}
			logger.Info("HTTP is close")
		}()
		if !e.gunCloudSendUpgradeF1(gunCloud, cacheKey, req.Sn, req.FileName, c2Ip) {
			logger.Error("download file err  F1")
			return
		}
		if !e.gunCloudSendUpgradeF2(ctx, gunCloud, cacheKey, req.Sn, req.FileName) {
			logger.Error("download file err  F2")
			return
		}

		if !e.gunCloudSendUpgradeF3(gunCloud, cacheKey, req.Sn) {
			logger.Error("download file err  F3")
		}

		logger.Info("gunCloudWgetUpgrade End")
	}()

	return 0, nil
}

// gunCloudSendUpgradeF1 发送请求固件升级
func (e *DeviceCenter) gunCloudSendUpgradeF1(gunCloud *GunsPlatform, cacheKey, sn string, fileName string, c2Ip string) bool {
	logger.Info("gunCloudSend Upgrade F1 start")
	time.Sleep(time.Second * 1)
	writeStatus, err := gunCloud.GunCloudSendUpgradeF1(fileName, c2Ip)
	if err != nil {
		logger.Errorf("GunCloudWriteUpdateData writeStatus %v", err.Error())
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_HUNTER_PLATFORM),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("A9写入固件错误 err: %v", err.Error()),
		})
		return false
	}
	logger.Infof("GunCloud Send Upgrade F1 writeStatus %v", writeStatus)
	if writeStatus != 0 {
		logger.Infof("GunCloudSend Upgrade F1 writeStatus err: %v", writeStatus)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_HUNTER_PLATFORM),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("A9写入固件错误 writeStatus: %v", writeStatus),
		})
		return false
	}
	if writeStatus == 0 {
		logger.Infof("GunCloud Send Upgrade F1 writeStatus suc: %v", writeStatus)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:          sn,
			DeviceType:  int32(common.DEV_HUNTER_PLATFORM),
			Status:      UpgradeStatusSendPkg,
			PkgPathName: fileName,
			ErrMsg:      "向Agx发送升级包中",
		})
	}
	logger.Info("GunCloud Send Upgrade F1 End")
	return true
}

// gunCloudSendUpgradeF2 发送请求固件升级
func (e *DeviceCenter) gunCloudSendUpgradeF2(ctx context.Context, gunCloud *GunsPlatform, cacheKey, sn string, pkgName string) bool {
	logger.Info("agxSend Upgrade F2 start")
	timer1 := time.NewTicker(1 * time.Second)
	tryCount := 0
	for {
		select {
		case <-timer1.C:
			writeStatus, err := gunCloud.GunCloudSendUpgradeF2()
			if err != nil {
				logger.Errorf("gunCloudWriteUpdateData writeStatus %v", err.Error())
				tryCount++
				if tryCount >= 5 {
					go UpdateOtaStatus(cacheKey, &UpgradeStatus{
						Sn:         sn,
						DeviceType: int32(common.DEV_HUNTER_PLATFORM),
						Status:     UpgradeStatusFailed,
						ErrMsg:     fmt.Sprintf("F2 get err: %v", err.Error()),
					})
					return false
				}

			}
			logger.Infof("gunCloud Send Upgrade F2 writeStatus %v", writeStatus)
			if writeStatus <= 95 {
				logger.Infof("gunCloud get F2 writeStatus : %v", writeStatus)
				go UpdateOtaStatus(cacheKey, &UpgradeStatus{
					Sn:          sn,
					DeviceType:  int32(common.DEV_HUNTER_PLATFORM),
					Status:      UpgradeStatusSendPkg,
					PkgPathName: pkgName,
					Permil:      int64(writeStatus * 10),
					ErrMsg:      "向agx发送升级包中",
				})
			}
			if writeStatus == 100 {
				logger.Infof("gunCloud get F2 writeStatus finish: %v", writeStatus)
				go UpdateOtaStatus(cacheKey, &UpgradeStatus{
					Sn:          sn,
					DeviceType:  int32(common.DEV_HUNTER_PLATFORM),
					Status:      UpgradeStatusSendPkg,
					PkgPathName: pkgName,
					Permil:      int64((writeStatus - 5) * 10),
					ErrMsg:      "向agx发送升级包中",
				})
				return true
			}
		case <-ctx.Done():
			return false
		}
	}

}

// gunCloudSendUpgradeF3 发送请求固件升级
func (e *DeviceCenter) gunCloudSendUpgradeF3(gunCloud *GunsPlatform, cacheKey, sn string) bool {
	logger.Info("gunCloud Send Upgrade F3 start")
	writeStatus, err := gunCloud.GunCloudSendUpgradeF3()
	if err != nil {
		logger.Errorf("gunCloudWriteUpdateData writeStatus %v", err.Error())
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_HUNTER_PLATFORM),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("F3 download err: %v", err.Error()),
		})
		return false
	}
	logger.Infof("gunCloud Upgrade F3 writeStatus %v", writeStatus)
	if writeStatus != 0 {
		logger.Infof("gunCloudSend Upgrade F3 writeStatus err: %v", writeStatus)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_HUNTER_PLATFORM),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("F3 download writeStatus: %v", writeStatus),
		})
		return false
	}
	if writeStatus == 0 {
		logger.Infof("gunCloudSend Upgrade F3 writeStatus Finish %v", writeStatus)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_HUNTER_PLATFORM),
			Status:     UpgradeStatusSuccess,
			Permil:     1000,
			ErrMsg:     "向gunCloud发送升级包完成",
		})
	}
	logger.Info("gunCloud Upgrade F3 End")
	return true
}

// ------------SFL101 OTA升级

// sfl101WgetUpgrade SFL101 Wget升级
func (e *DeviceCenter) sfl101WgetUpgrade(req *client.ResetSystemRequest) (int32, error) {
	logger.Info("sfl101WgetUpgrade Start:", req)
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_SFL101, req.Sn)
	dev := FindCacheDevice(req.Sn, common.DEV_SFL101)
	if dev == nil {
		logger.Error("设备未在线")
		return 1, errors.New("设备未在线")
	}
	sfl101 := &Sfl101{Device: dev}
	if req.Type == 0 {
		req.Type = 4
	}
	// 修改状态为升级中 同步状态给前端
	DevUpgradingMap.SetStatus(cacheKey, true)
	// 写入升级状态
	UpdateOtaStatus(cacheKey, &UpgradeStatus{
		Sn:         req.Sn,
		DeviceType: int32(common.DEV_SFL101),
		Status:     UpgradeStatusSendPkg,
		ErrMsg:     "向系统发升级包中",
	})
	// 异步通过WebSocket向前端同步升级状态
	go OtaSyncUpgradeStatus(req.Sn, cacheKey, int32(common.DEV_SFL101))
	go func() {
		ctx, cancel := context.WithCancel(context.Background())
		defer cancel()
		var c2Ip string
		localIPInfos, err := iphelper.GetLocalIPInfos()
		if err != nil {
			logger.Errorf("get IP err err %v", err)
			return
		}
		defaultIP := ""
		for _, ipInfo := range localIPInfos {
			logger.Infof("ip Info is %v,remote Ip is :%v", ipInfo.LocalIP, sfl101.RemoteIp)
			isSame := isSamePrefix(ipInfo.LocalIP, sfl101.RemoteIp)
			if isSame {
				c2Ip = ipInfo.LocalIP
			}
			if strings.Contains(ipInfo.LocalIP, "169.254") {
				defaultIP = ipInfo.LocalIP
			}
		}
		if c2Ip == "" {
			c2Ip = defaultIP
		}

		fileServer := http.FileServer(http.Dir(req.PkgPath))

		server := &http.Server{
			Addr:    c2Ip + ":8081",
			Handler: fileServer,
		}
		// 用于表示服务器状态的变量
		go func() {
			logger.Info("file server start:", server.Addr)
			if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
				logger.Error("file server start err:", err)
			}
		}()

		// 开启协程异步进行后续升级步骤
		//go e.tracerUpgrade(req.Sn, cacheKey, filepath.Join(req.PkgPath, req.FileName))
		stopChan := make(chan struct{})
		//执行其他操作
		defer close(stopChan)
		// 启动一个新的协程来等待关闭信号
		go func() {
			// 等待接收到关闭信号
			<-stopChan

			logger.Info("HTTP service stop")
			timeoutCtx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
			defer cancel()

			if err := server.Shutdown(timeoutCtx); err != nil {
				logger.Error("HTTP service stop  err：", err)
			}
			logger.Info("HTTP is close")
		}()
		//给车载SFL发送文件地址
		if !e.sfl101SendUpgradeF1(sfl101, cacheKey, req.Sn, req.FileName, c2Ip) {
			logger.Error("download file err  F1")
			return
		}
		//定时查询文件下载进度
		if !e.sfl101SendUpgradeF2(ctx, sfl101, cacheKey, req.Sn, req.FileName) {
			logger.Error("download file err  F2")
			return
		}
		//升级结果上报
		if !e.sfl101SendUpgradeF3(sfl101, cacheKey, req.Sn) {
			logger.Error("download file err  F3")
		}

		logger.Info("sfl101WgetUpgrade End")
	}()

	return 0, nil
}

// sfl101SendUpgradeF1 发送请求固件升级
func (e *DeviceCenter) sfl101SendUpgradeF1(sfl101 *Sfl101, cacheKey, sn string, fileName string, c2Ip string) bool {
	logger.Info("Sfl101Send Upgrade F1 start")
	time.Sleep(time.Second * 3)
	writeStatus, err := sfl101.Sfl101SendUpgradeF1(fileName, c2Ip)
	if err != nil {
		logger.Errorf("Sfl101WriteUpdateData writeStatus %v", err.Error())
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_SFL101),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("F1  err: %v", err.Error()),
		})
		return false
	}
	logger.Infof("Sfl101Send Upgrade F1 writeStatus %v", writeStatus)
	if writeStatus != 0 {
		logger.Infof("Sfl101SendU pgrade F1 writeStatus err: %v", writeStatus)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_SFL101),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("F1 writeStatus: %v", writeStatus),
		})
		return false
	}
	if writeStatus == 0 {
		logger.Infof("Sfl101Send Upgrade F1 writeStatus suc: %v", writeStatus)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:          sn,
			DeviceType:  int32(common.DEV_SFL101),
			Status:      UpgradeStatusSendPkg,
			PkgPathName: fileName,
			ErrMsg:      "向Sfl101发送升级包中",
		})
	}
	logger.Info("Sfl101Send Upgrade F1 End")
	return true
}

// sfl101SendUpgradeF2 发送请求固件升级
func (e *DeviceCenter) sfl101SendUpgradeF2(ctx context.Context, sfl101 *Sfl101, cacheKey, sn string, pkgName string) bool {
	logger.Info("sfl101Send Upgrade F2 start")
	timer1 := time.NewTicker(1 * time.Second)
	for {
		select {
		case <-timer1.C:
			writeStatus, err := sfl101.Sfl101SendUpgradeF2()
			if err != nil {
				logger.Errorf("sfl101WriteUpdateData writeStatus %v", err.Error())
				go UpdateOtaStatus(cacheKey, &UpgradeStatus{
					Sn:         sn,
					DeviceType: int32(common.DEV_SFL101),
					Status:     UpgradeStatusFailed,
					ErrMsg:     fmt.Sprintf("F2 get err: %v", err.Error()),
				})
				return false
			}
			logger.Infof("sfl101Send Upgrade F2 writeStatus %v", writeStatus)
			if writeStatus <= 95 && writeStatus != -1 {
				logger.Infof("tracerSend get F2 writeStatus : %v", writeStatus)
				go UpdateOtaStatus(cacheKey, &UpgradeStatus{
					Sn:          sn,
					DeviceType:  int32(common.DEV_SFL101),
					Status:      UpgradeStatusSendPkg,
					PkgPathName: pkgName,
					Permil:      int64(writeStatus * 10),
					ErrMsg:      "向sfl101发送升级包中",
				})
			}
			if writeStatus == 100 {
				logger.Infof("sfl101Send get F2 writeStatus finish: %v", writeStatus)
				go UpdateOtaStatus(cacheKey, &UpgradeStatus{
					Sn:          sn,
					DeviceType:  int32(common.DEV_SFL101),
					Status:      UpgradeStatusSendPkg,
					PkgPathName: pkgName,
					Permil:      int64((writeStatus - 5) * 10),
					ErrMsg:      "向sfl101发送升级包中",
				})
				return true
			}
		case <-ctx.Done():
			return false
		}
	}

}

// sfl101SendUpgradeF3 发送请求固件升级
func (e *DeviceCenter) sfl101SendUpgradeF3(sfl101 *Sfl101, cacheKey, sn string) bool {
	logger.Info("sfl101Send Upgrade F3 start")
	writeStatus, err := sfl101.Sfl101SendUpgradeF3()
	if err != nil {
		logger.Errorf("sfl101WriteUpdateData writeStatus %v", err.Error())
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_SFL101),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("F3 download err: %v", err.Error()),
		})
		return false
	}
	logger.Infof("sfl101Send Upgrade F3 writeStatus %v", writeStatus)
	if writeStatus != 0 {
		logger.Infof("sfl101Send Upgrade F3 writeStatus err: %v", writeStatus)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_SFL101),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("F3 download writeStatus: %v", writeStatus),
		})
		return false
	}
	if writeStatus == 0 {
		logger.Infof("sfl101Send Upgrade F3 writeStatus Finish %v", writeStatus)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_SFL101),
			Status:     UpgradeStatusSuccess,
			Permil:     1000,
			ErrMsg:     "向sfl101发送升级包完成",
		})
	}
	logger.Info("sfl101Send Upgrade F3 End")
	return true
}

// ------------SVH OTA升级

// svhWgetUpgrade SVH Wget升级
func (e *DeviceCenter) svhWgetUpgrade(req *client.ResetSystemRequest) (int32, error) {
	logger.Info("svhWgetUpgrade Start:", req)
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_SVH, req.Sn)
	dev := FindCacheDevice(req.Sn, common.DEV_SVH)
	if dev == nil {
		logger.Error("设备未在线")
		return 1, errors.New("设备未在线")
	}
	svh := &Svh{Device: dev}
	if req.Type == 0 {
		req.Type = 4
	}
	// 修改状态为升级中 同步状态给前端
	DevUpgradingMap.SetStatus(cacheKey, true)
	// 写入升级状态
	UpdateOtaStatus(cacheKey, &UpgradeStatus{
		Sn:         req.Sn,
		DeviceType: int32(common.DEV_SVH),
		Status:     UpgradeStatusSendPkg,
		ErrMsg:     "向系统发升级包中",
	})
	// 异步通过WebSocket向前端同步升级状态
	go OtaSyncUpgradeStatus(req.Sn, cacheKey, int32(common.DEV_SVH))
	go func() {
		ctx, cancel := context.WithCancel(context.Background())
		defer cancel()
		var c2Ip string
		localIPInfos, err := iphelper.GetLocalIPInfos()
		if err != nil {
			logger.Errorf("get IP err err %v", err)
			return
		}
		defaultIP := ""
		for _, ipInfo := range localIPInfos {
			logger.Infof("ip Info is %v,remote Ip is :%v", ipInfo.LocalIP, svh.RemoteIp)
			isSame := isSamePrefix(ipInfo.LocalIP, svh.RemoteIp)
			if isSame {
				c2Ip = ipInfo.LocalIP
			}
			if strings.Contains(ipInfo.LocalIP, "169.254") {
				defaultIP = ipInfo.LocalIP
			}
		}
		if c2Ip == "" {
			c2Ip = defaultIP
		}

		fileServer := http.FileServer(http.Dir(req.PkgPath))

		server := &http.Server{
			Addr:    c2Ip + ":8081",
			Handler: fileServer,
		}
		// 用于表示服务器状态的变量
		go func() {
			logger.Info("file server start:", server.Addr)
			if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
				logger.Error("file server start err:", err)
			}
		}()

		// 开启协程异步进行后续升级步骤
		//go e.tracerUpgrade(req.Sn, cacheKey, filepath.Join(req.PkgPath, req.FileName))
		stopChan := make(chan struct{})
		//执行其他操作
		defer close(stopChan)
		// 启动一个新的协程来等待关闭信号
		go func() {
			// 等待接收到关闭信号
			<-stopChan

			logger.Info("HTTP service stop")
			timeoutCtx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
			defer cancel()

			if err := server.Shutdown(timeoutCtx); err != nil {
				logger.Error("HTTP service stop  err：", err)
			}
			logger.Info("HTTP is close")
		}()

		if !e.svhSendUpgradeF1(svh, cacheKey, req.Sn, req.FileName, c2Ip) {
			logger.Error("download file err  F1")
			return
		}
		if !e.svhSendUpgradeF2(ctx, svh, cacheKey, req.Sn, req.FileName) {
			logger.Error("download file err  F2")
			return
		}

		if !e.svhSendUpgradeF3(svh, cacheKey, req.Sn) {
			logger.Error("download file err  F3")
		}

		logger.Info("svhWgetUpgrade End")
	}()

	return 0, nil
}

// svhSendUpgradeF1 发送请求固件升级
func (e *DeviceCenter) svhSendUpgradeF1(svh *Svh, cacheKey, sn string, fileName string, c2Ip string) bool {
	logger.Info("SvhSend Upgrade F1 start")
	time.Sleep(time.Second * 3)
	writeStatus, err := svh.SvhSendUpgradeF1(fileName, c2Ip)
	if err != nil {
		logger.Errorf("SvhWriteUpdateData writeStatus %v", err.Error())
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_SVH),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("F1  err: %v", err.Error()),
		})
		return false
	}
	logger.Infof("SvhSend Upgrade F1 writeStatus %v", writeStatus)
	if writeStatus != 0 {
		logger.Infof("SvhSendU pgrade F1 writeStatus err: %v", writeStatus)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_SVH),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("F1 writeStatus: %v", writeStatus),
		})
		return false
	}
	if writeStatus == 0 {
		logger.Infof("SvhSend Upgrade F1 writeStatus suc: %v", writeStatus)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:          sn,
			DeviceType:  int32(common.DEV_SVH),
			Status:      UpgradeStatusSendPkg,
			PkgPathName: fileName,
			ErrMsg:      "向Svh发送升级包中",
		})
	}
	logger.Info("SvhSend Upgrade F1 End")
	return true
}

// svhSendUpgradeF2 发送请求固件升级
func (e *DeviceCenter) svhSendUpgradeF2(ctx context.Context, svh *Svh, cacheKey, sn string, pkgName string) bool {
	logger.Info("svhSend Upgrade F2 start")
	timer1 := time.NewTicker(1 * time.Second)
	for {
		select {
		case <-timer1.C:
			writeStatus, err := svh.SvhSendUpgradeF2()
			if err != nil {
				logger.Errorf("svhWriteUpdateData writeStatus %v", err.Error())
				go UpdateOtaStatus(cacheKey, &UpgradeStatus{
					Sn:         sn,
					DeviceType: int32(common.DEV_SVH),
					Status:     UpgradeStatusFailed,
					ErrMsg:     fmt.Sprintf("F2 get err: %v", err.Error()),
				})
				return false
			}
			logger.Infof("svhSend Upgrade F2 writeStatus %v", writeStatus)
			if writeStatus <= 95 && writeStatus != -1 {
				logger.Infof("tracerSend get F2 writeStatus : %v", writeStatus)
				go UpdateOtaStatus(cacheKey, &UpgradeStatus{
					Sn:          sn,
					DeviceType:  int32(common.DEV_SVH),
					Status:      UpgradeStatusSendPkg,
					PkgPathName: pkgName,
					Permil:      int64(writeStatus * 10),
					ErrMsg:      "向svh发送升级包中",
				})
			}
			if writeStatus == 100 {
				logger.Infof("svhSend get F2 writeStatus finish: %v", writeStatus)
				go UpdateOtaStatus(cacheKey, &UpgradeStatus{
					Sn:          sn,
					DeviceType:  int32(common.DEV_SVH),
					Status:      UpgradeStatusSendPkg,
					PkgPathName: pkgName,
					Permil:      int64((writeStatus - 5) * 10),
					ErrMsg:      "向svh发送升级包中",
				})
				return true
			}
		case <-ctx.Done():
			return false
		}
	}

}

// svhSendUpgradeF3 发送请求固件升级
func (e *DeviceCenter) svhSendUpgradeF3(svh *Svh, cacheKey, sn string) bool {
	logger.Info("svhSend Upgrade F3 start")
	writeStatus, err := svh.SvhSendUpgradeF3()
	if err != nil {
		logger.Errorf("svhWriteUpdateData writeStatus %v", err.Error())
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_SVH),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("F3 download err: %v", err.Error()),
		})
		return false
	}
	logger.Infof("svhSend Upgrade F3 writeStatus %v", writeStatus)
	if writeStatus != 0 {
		logger.Infof("svhSend Upgrade F3 writeStatus err: %v", writeStatus)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_SVH),
			Status:     UpgradeStatusFailed,
			ErrMsg:     fmt.Sprintf("F3 download writeStatus: %v", writeStatus),
		})
		return false
	}
	if writeStatus == 0 {
		logger.Infof("svhSend Upgrade F3 writeStatus Finish %v", writeStatus)
		go UpdateOtaStatus(cacheKey, &UpgradeStatus{
			Sn:         sn,
			DeviceType: int32(common.DEV_SVH),
			Status:     UpgradeStatusSuccess,
			Permil:     1000,
			ErrMsg:     "向svh发送升级包完成",
		})
	}
	logger.Info("svhSend Upgrade F3 End")
	return true
}

package handler

import (
	"bytes"
	"context"
	"encoding/binary"
	"errors"
	"fmt"
	"io"
	"net"
	"strings"
	"sync"
	"time"

	"adasgitlab.autel.com/tools/cuav_plugin/broker"
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"github.com/asaskevich/EventBus"
	jsoniter "github.com/json-iterator/go"
	"google.golang.org/protobuf/proto"

	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/config"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
	"adasgitlab.autel.com/tools/cuav_server/repo/utils"
)

const (
	UrdConfigPrefix              = "UrdConfig_"
	UrdHeaderLength              = 29
	UrdFooterLength              = 5
	UrdDeviceInfoType            = 1
	UrdDroneInfoType             = 3
	UrdFileDataType              = 8
	UrdCmdReqType                = 0
	UrdCmdRspType                = 6
	UrdSpectrumType              = 20
	UrdNegotiateType             = 18
	TracerRFEventMsgOnline       = 2001
	TracerRFEventMsgOffLine      = 2002
	TracerRFEventDetectAppear    = 2003
	TracerRFEventDetectDisappear = 2004
	TracerRFEventSpectrum        = 2005
)

var (
	ErrUrd360Offline = errors.New("device is offline")
)

var (
	UrdStartFlag     = [4]byte{0xEE, 0xEE, 0xEE, 0xEE}
	UrdEndFlag       = [4]byte{0xAA, 0xAA, 0xAA, 0xAA}
	cmdReplyEventBus = EventBus.New()
	urdConnections   sync.Map
)

// 获取设备连接
func getUrdConnection(sn string) (net.Conn, bool) {
	conn, ok := urdConnections.Load(sn)
	if !ok {
		return nil, false
	}
	return conn.(net.Conn), true
}

// 存储设备连接
func setUrdConnection(sn string, conn net.Conn) {
	urdConnections.Store(sn, conn)
}

// 删除设备连接
func deleteUrdConnection(sn string) {
	urdConnections.Delete(sn)
}

// UrdData 数据帧组成
type UrdData struct {
	StartFlag   [4]byte // 0xEE 0xEE 0xEE 0xEE
	Version     uint16  // 0x02 0x03
	Length      int32   // 整个数据帧的长度
	Year        int16
	Month       int8
	Day         int8
	Hour        int8
	Minute      int8
	Second      int8
	MilliSecond int16
	DataType    int16   // 数据类型
	Seq         int64   // 数据帧序号
	Data        []byte  // 数据内容
	CheckSum    uint8   // 校验和，未生效
	EndFlag     [4]byte // 0xAA 0xAA 0xAA 0xAA
}

func createUrdData(dataType int16, seq int64, content []byte) *UrdData {
	t := time.Now()
	data := &UrdData{
		StartFlag:   UrdStartFlag,
		Version:     config.GetGlobalConfig().Server.Urd360Version,
		Length:      int32(len(content) + UrdHeaderLength + UrdFooterLength),
		Year:        int16(t.Year()),
		Month:       int8(t.Month()),
		Day:         int8(t.Day()),
		Hour:        int8(t.Hour()),
		Minute:      int8(t.Minute()),
		Second:      int8(t.Second()),
		MilliSecond: int16(t.Nanosecond() / 1000000),
		DataType:    dataType,
		Seq:         seq,
		Data:        content,
		CheckSum:    0,
		EndFlag:     UrdEndFlag,
	}
	var buf bytes.Buffer
	_ = utils.WriteBinary(&buf, binary.LittleEndian, data, int(data.Length))
	// 计算校验和
	var sum uint8
	for _, b := range buf.Bytes() {
		sum += b
	}
	data.CheckSum = sum
	return data
}

func getUrdDataLength(data []byte) int32 {
	if len(data) != 4 {
		return 0
	}
	return int32(data[0]) | (int32(data[1]) << 8) | (int32(data[2]) << 16) | (int32(data[3]) << 24)
}

func checkUrdDataStartFlag(data []byte) bool {
	if len(data) != 4 {
		return false
	}
	return data[0] == UrdStartFlag[0] && data[1] == UrdStartFlag[1] && data[2] == UrdStartFlag[2] && data[3] == UrdStartFlag[3]
}

func checkUrdDataEndFlag(data []byte) bool {
	if len(data) != 4 {
		return false
	}
	return data[0] == 0xAA && data[1] == 0xAA && data[2] == 0xAA && data[3] == 0xAA
}

// UrdDeviceInfo 监测设备信息列表数据, DataType = 1
type UrdDeviceInfo struct {
	Id                int32
	Name              [20]byte
	Longitude         float32
	Latitude          float32
	Height            int32
	Status            int16 // 0:空闲 1:工作
	Azimuth           int32
	Type              int32    // 预留
	CompassStatus     int8     // 罗盘状态
	GpsStatus         int8     // GPS状态
	ReceiverStatus    int8     // 接收机状态
	AntennaStatus     int8     // 天线与上位机连接状态
	AntennaCoverRange int32    // 天线覆盖范围
	Reserved          [20]byte // 预留
}

// UrdDeviceInfoUpload 监测设备信息上传数据
type UrdDeviceInfoUpload struct {
	Id                int32   `json:"id"`
	Name              string  `json:"name"`
	Longitude         float32 `json:"longitude"`
	Latitude          float32 `json:"latitude"`
	Height            int32   `json:"height"`
	Status            int16   `json:"status"`
	Azimuth           int32   `json:"azimuth"`
	Type              int32   `json:"type"`
	CompassStatus     int8    `json:"compass_status"`
	GpsStatus         int8    `json:"gps_status"`
	ReceiverStatus    int8    `json:"receiver_status"`
	AntennaStatus     int8    `json:"antenna_status"`
	AntennaCoverRange int32   `json:"antenna_cover_range"`
}

// UrdDroneInfo 单站识别的无人机数据, DataType = 3
type UrdDroneInfo struct {
	Id               int32
	UniqueId         [32]byte // 无人机唯一Id，可能为空
	TargetInfoLength int32    // 目标信息长度
	TargetInfo       []byte   // 目标信息
	StationId        int32
	TargetAzimuth    int32
	TargetRange      int32
	Longitude        float32
	Latitude         float32
	Height           int32    // 预留
	Frequency        float64  // 目标频率 单位：kHz
	Bandwidth        float64  // 带宽 单位：kHz
	SignalStrength   float64  // 信号强度 单位：db
	Reserved         [18]byte // 预留
	Trust            int8     // 置信度
	Reserved2        [1]byte  // 保留字节
	Hour             int8
	Minute           int8
	Second           int8
	MilliSecond      int16
	DataType         int8 // 数据类型
	Modulation       int8 // 调制方式
}

func getTargetInfoLength(data []byte) int32 {
	if len(data) != 4 {
		return 0
	}
	return int32(data[0]) | (int32(data[1]) << 8) | (int32(data[2]) << 16) | (int32(data[3]) << 24)
}

// UrdDroneInfoUpload 单站识别的无人机数据上传
type UrdDroneInfoUpload struct {
	Id               int32   `json:"id"`
	UniqueId         string  `json:"unique_id"`
	TargetInfoLength int32   `json:"target_info_length"`
	TargetInfo       string  `json:"target_info"`
	StationId        int32   `json:"station_id"`
	TargetAzimuth    int32   `json:"target_azimuth"`
	TargetRange      int32   `json:"target_range"`
	Longitude        float32 `json:"longitude"`
	Latitude         float32 `json:"latitude"`
	Height           int32   `json:"height"`
	Frequency        float64 `json:"frequency"`       // 目标频率 单位：kHz
	Bandwidth        float64 `json:"bandwidth"`       // 带宽 单位：kHz
	SignalStrength   float64 `json:"signal_strength"` // 信号强度 单位：db
	Trust            int8    `json:"trust"`           // 置信度
	Time             string  `json:"time"`            // 发现时间
	DataType         int8    `json:"data_type"`       // 数据类型
	Modulation       int8    `json:"modulation"`      // 调制方式
	EventId          string  `json:"event_id"`        // 添加事件ID
	AlarmId          string  `json:"alarm_id"`        //告警ID
	AlarmEventId     string  `json:"alarm_event_id"`  //事件ID，同一个无人机威胁等级发生变化，事件ID不变
	ThreatLevel      int32   `json:"threat_level"`    //威胁等级，高（80-100分）、中（50-79分）、低（1-49分），0-无威胁
	ScenesId         int32   `json:"scenes_id"`       //场景 1-无围栏区， 2-预警区， 3-核心区， 4-核心区+预警区
}

func formatTime(hour int8, minute int8, second int8, milliSecond int16) string {
	return fmt.Sprintf("%02d:%02d:%02d.%03d", hour, minute, second, milliSecond)
}

// UrdFileData 文件数据帧, DataType = 8
// 文件数据内容模板：
//
//	[Testing Information]
//	freq_num=3
//	[freq1]
//	freq=2450
//	scan_num=5
//	gain=195
//	scan_time=5
//	[freq2]
//	freq=5787
//	scan_num=5
//	gain=195
//	scan_time=5
//	[freq3]
//	freq=900
//	scan_num=5
//	gain=195
//	scan_time=5
type UrdFileData struct {
	CmdId  uint8  // 命令Id
	Type   int8   // 文件类型 0:测量参数文件
	Length int32  // 文件数据内容长度
	Data   []byte // 文件数据内容
}

// UrdStartMonitorReq 启动监测请求参数, DataType = 0
type UrdStartMonitorReq struct {
	CmdId uint8  // 命令Id
	Start []byte // 固定内容： RMTP:CFGSTART:startmeasure
}

// UrdStopMonitorReq 停止监测请求参数, DataType = 0
type UrdStopMonitorReq struct {
	CmdId uint8  // 命令Id
	Stop  []byte // 固定内容： RMTP:CFGSTOP:stopmeasure
}

// UrdNegotiateProtocolReq 协议协商请求参数, DataType = 18
type UrdNegotiateProtocolReq struct {
	CmdId   uint8  // 命令Id
	Version uint16 // 协议版本号
}

// UrdCmdRsp 命令响应参数, DataType = 6
type UrdCmdRsp struct {
	CmdId    uint8  // 命令Id
	Response []byte // 格式如下： RESULT:result_id;Info:information_string result_id为SUCCESSED表示成功，其他表示失败 information_string为失败原因
}

// UrdResultInfo 命令响应结果信息
type UrdResultInfo struct {
	Result string
	Info   string
}

// parseResultInfo 解析命令响应结果信息
func parseResultInfo(input string) (*UrdResultInfo, error) {
	parts := strings.Split(input, ";")
	if len(parts) != 2 {
		return nil, fmt.Errorf("invalid input format")
	}

	resultInfo := &UrdResultInfo{}

	for _, part := range parts {
		kv := strings.Split(part, ":")
		if len(kv) != 2 {
			return nil, fmt.Errorf("invalid key-value pair")
		}

		key, value := kv[0], kv[1]
		switch key {
		case "RESULT":
			resultInfo.Result = value
		case "Info":
			resultInfo.Info = value
		default:
			return nil, fmt.Errorf("unknown key: %s", key)
		}
	}

	return resultInfo, nil
}

// StartUrdTCPConnection 开始TCP连接
func StartUrdTCPConnection(ip string, port int, sn string) {
	addr := fmt.Sprintf("%s:%d", ip, port)
	for {
		conn, err := net.Dial("tcp", addr)
		if err != nil {
			logger.Error("连接urd360失败, err:", err)
			time.Sleep(5 * time.Second) // 等待5秒钟再次尝试
			continue
		}
		logger.Debug("urd360 sn", sn)
		// 处理连接，如果handleUrdConnection返回，则连接可能已关闭或出现错误
		handleUrdConnection(conn, sn)
		time.Sleep(5 * time.Second) // 等待5秒钟再次尝试
	}
}

// checkDeviceEnable 检查设备是否禁用
func checkDeviceEnable(sn string) bool {
	status := &client.GetStatusRes{}
	err := NewEquipList().GetStatus(context.Background(), &client.GetStatusReq{
		Sn:    sn,
		EType: "tracerRF",
	}, status)
	if err != nil {
		logger.Error("get urd device status failed:", err)
		return false
	}
	if status.IsEnable == 2 {
		return false
	}
	return true
}

// getRemoteIP 获取远程IP
func getRemoteIP(conn net.Conn) string {
	if addr, ok := conn.RemoteAddr().(*net.TCPAddr); ok {
		return addr.IP.String()
	}
	return ""
}

// handleUrdConnection 从TCP连接读取并解码到UrdData结构
func handleUrdConnection(conn net.Conn, sn string) {
	defer conn.Close()

	// 存储连接
	setUrdConnection(sn, conn)
	defer deleteUrdConnection(sn)
	logger.Infof("urd conn receive start: %s", conn.RemoteAddr())

	// 初始化工作
	go func() {
		defer func() {
			if r := recover(); r != nil {
				logger.Error("handleUrdConnection.:", r)
			}
		}()
		// 发送协议协商请求
		for {
			err := negotiateProtocol(sn, 0, config.GetGlobalConfig().Server.Urd360Version)
			if err != nil {
				if errors.Is(err, ErrUrd360Offline) {
					return
				}
				logger.Errorf("urd360[%s]协议协商失败: %s", sn, err.Error())
				time.Sleep(100 * time.Millisecond)
				continue
			}
			logger.Infof("urd360[%s]协议协商成功", sn)
			break
		}
		// 发送启动监测请求
		for {
			_, err := UrdStartMonitor(sn, 0)
			if err != nil {
				if errors.Is(err, ErrUrd360Offline) {
					return
				}
				logger.Errorf("urd360[%s]启动监测失败: %s", sn, err.Error())
				continue
			}
			logger.Infof("urd360[%s]启动监测成功", sn)
			break
		}
	}()

	// 创建缓冲区接收数据
	packet := NewUrd360Packet()
	ch := make(chan Packet, 1)
	defer close(ch)
	go func() {
		defer func() {
			if r := recover(); r != nil {
				logger.Error("handleUrdConnection.:", r)
			}
		}()
		for {
			select {
			case c, ok := <-ch:
				if !ok {
					// 通道关闭，退出
					return
				}
				// 检查设备是否禁用
				if !checkDeviceEnable(sn) {
					logger.Warnf("urd device is disabled: %s", sn)
					continue
				}
				// 解析数据
				buf := c.Data
				length := c.Length
				var data UrdData
				data.Data = make([]byte, length-UrdHeaderLength-UrdFooterLength)
				err := utils.ReadBinary(bytes.NewReader(buf[:]), binary.LittleEndian, &data, length)
				if err != nil {
					logger.Error("binary.Read urd data failed:", err)
					continue
				}

				var (
					parentSn     string
					parentType   int
					isIntegrated int32
				)
				equipModel, err := GetEquipBySn(sn)
				name := getRemoteIP(conn)
				if equipModel != nil && equipModel.Name != "" {
					name = equipModel.Name
				}
				if err == nil {
					parentType = equipModel.ParentType
					parentSn = equipModel.ParentSn
					isIntegrated = equipModel.IsIntegrated
				}
				//logger.Debugf("urd data: %+v", data)
				switch data.DataType {
				case UrdDeviceInfoType:
					// 设备信息
					reader := bytes.NewReader(buf[UrdHeaderLength : data.Length-UrdFooterLength])
					var info UrdDeviceInfo
					err = binary.Read(reader, binary.LittleEndian, &info)
					if err != nil {
						logger.Error("binary.Read urd device info failed:", err)
						break
					}
					//修改代码，由于SN目前是写死的，根据协议文档标识，现在加上ID  @fzw
					// sn = fmt.Sprintf("%s%d", sn, info.Id)
					logger.Debug("sn = %s", sn)
					logger.Debug("info.Name[:] = %s", info.Name)
					logger.Debug("len info.Name[:] = ", len(info.Name[:]))

					// 上传设备信息
					msg := common.EquipmentMessageBoxEntity{
						Name:      name,
						Sn:        sn,
						MsgType:   UrdDeviceInfoType,
						EquipType: int(common.DEV_URD360),
						Info: UrdDeviceInfoUpload{
							Id:                info.Id,
							Name:              string(info.Name[:]),
							Longitude:         info.Longitude,
							Latitude:          info.Latitude,
							Height:            info.Height,
							Status:            info.Status,
							Azimuth:           info.Azimuth,
							Type:              info.Type,
							CompassStatus:     info.CompassStatus,
							GpsStatus:         info.GpsStatus,
							ReceiverStatus:    info.ReceiverStatus,
							AntennaStatus:     info.AntennaStatus,
							AntennaCoverRange: info.AntennaCoverRange,
						},
						ParentType:   parentType,
						ParentSn:     parentSn,
						IsIntegrated: isIntegrated,
					}
					logger.Infof("urd device info: %+v", msg)
					_ = mq.RFURDBroker.Publish(mq.RFURD360StatusTopic, broker.NewMessage(msg))
					//上报坤雷在线事件
					go tracerRFStatusEvent(sn, msg.Name, &info)
				case UrdDroneInfoType:
					// 无人机信息
					targetInfoLength := getTargetInfoLength(buf[UrdHeaderLength+36 : UrdHeaderLength+40])
					reader := bytes.NewReader(buf[UrdHeaderLength : data.Length-UrdFooterLength])
					var info UrdDroneInfo
					info.TargetInfo = make([]byte, targetInfoLength)
					if err := utils.ReadBinary(reader, binary.LittleEndian, &info, length-UrdHeaderLength-UrdFooterLength); err != nil {
						logger.Error("binary.Read urd drone info failed:", err)
						break
					}
					//修改代码，由于SN目前是写死的，根据协议文档标识，现在加上ID，未和设备通信验证过 @fzw
					// sn = fmt.Sprintf("%s%d", sn, info.Id)
					logger.Debug("info.TargetInfo[:] = ", info.TargetInfo)
					logger.Debug("string(info.TargetInfo[:]) = ", string(info.TargetInfo[:]))
					logger.Debug("info.UniqueId[:]) = ", info.UniqueId[:])
					logger.Debug("len (info.UniqueId[:]) = ) ", info.UniqueId[:])

					//var (
					//	alarmId, alarmEventId string
					//	threatLevel, scenesId int32
					//)
					////计算无人机威胁等级
					//fd, err := NewAlarmControl().GetDroneThreatLevel("", int64(info.Id+10000), float64(info.Longitude), float64(info.Latitude))
					//if err != nil {
					//	logger.Errorf("urd get drone threat level error: %v", err)
					//} else {
					//	alarmId = fd.AlarmId
					//	alarmEventId = fd.EventId
					//	threatLevel = fd.ThreatLevel
					//	scenesId = fd.ScenesId
					//}

					// 上传无人机信息
					msg := common.EquipmentMessageBoxEntity{
						Name:      name,
						Sn:        sn,
						MsgType:   UrdDroneInfoType,
						EquipType: int(common.DEV_URD360),
						Info: UrdDroneInfoUpload{
							Id:               info.Id + 10000,
							UniqueId:         string(info.UniqueId[:]),
							TargetInfoLength: info.TargetInfoLength,
							TargetInfo:       string(info.TargetInfo[:]),
							StationId:        info.StationId,
							TargetAzimuth:    info.TargetAzimuth,
							TargetRange:      info.TargetRange,
							Longitude:        info.Longitude,
							Latitude:         info.Latitude,
							Height:           info.Height,
							Frequency:        info.Frequency,
							Bandwidth:        info.Bandwidth,
							SignalStrength:   info.SignalStrength,
							Trust:            info.Trust,
							Time:             formatTime(info.Hour, info.Minute, info.Second, info.MilliSecond),
							DataType:         info.DataType,
							Modulation:       info.Modulation,
							//AlarmId:          alarmId,
							//AlarmEventId:     alarmEventId,
							//ThreatLevel:      threatLevel,
							//ScenesId:         scenesId,
						},
						ParentType:   parentType,
						ParentSn:     parentSn,
						IsIntegrated: isIntegrated,
					}
					logger.Infof("urd drone info: %+v", msg)

					_ = mq.RFURDBroker.Publish(mq.RFURD360DroneInfoTopic, broker.NewMessage(msg))
					//上报坤雷侦测事件
					go tracerRFDetectEvent(sn, msg.Name, &info)
				case UrdCmdRspType:
					// 命令响应
					reader := bytes.NewReader(buf[UrdHeaderLength : data.Length-UrdFooterLength])
					var rsp UrdCmdRsp
					rsp.Response = make([]byte, data.Length-UrdHeaderLength-UrdFooterLength-1)
					err = utils.ReadBinary(reader, binary.LittleEndian, &rsp, length-UrdHeaderLength-UrdFooterLength)
					if err != nil {
						logger.Error("binary.Read urd cmd rsp failed:", err)
						break
					}
					// 解析响应结果信息
					resultInfo, err := parseResultInfo(string(rsp.Response))
					if err != nil {
						logger.Error("parse result info failed:", err)
						break
					}
					logger.Infof("urd cmd rsp: %+v, %+v, %v", rsp.CmdId, string(rsp.Response), resultInfo.Info)
					// 发布命令响应事件
					cmdReplyEventBus.Publish(fmt.Sprintf("%s_%d", sn, rsp.CmdId), resultInfo)
				}
			}
		}
	}()

	// 创建缓冲区读取数据
	data := make([]byte, 2048)
	for {
		// 接收数据
		n, err := conn.Read(data)
		if err != nil {
			if err == io.EOF {
				logger.Warn("urd conn receive close:", conn.RemoteAddr())
			} else {
				logger.Error("urd conn receive err:", err)
			}
			return
		}
		if n <= 0 {
			continue
		}
		// 处理数据
		packet.PacketHandler(data[:n], ch)
	}
}

// tracerRFStatusEvent 坤雷在线事件上报
func tracerRFStatusEvent(sn, name string, heart *UrdDeviceInfo) {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_URD360, sn)
	if cache, ok := DevStatusMapOnEvent.Load(cacheKey); ok {
		dev := cache.(*Device)
		dev.Status = common.DevOnline
		dev.LastHeartTime = time.Now()
		dev.GetStatusInterval = time.Now()
		return
	}
	dev := &Device{
		Sn:                sn,
		Status:            common.DevOnline,
		DevType:           common.DEV_URD360,
		FirstHeartTime:    time.Now(),
		LastHeartTime:     time.Now(),
		IsEnable:          common.DeviceEnable,
		GetStatusInterval: time.Now(),
		SessionId:         GetGlobalSessionId(),
	}
	DevStatusMapOnEvent.Store(cacheKey, dev)

	equipModel, err := GetEquipBySn(sn)
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	heartInfo := &client.UrdDeviceInfoUpload{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        sn,
			EquipType: int32(common.DEV_URD360),
			MsgType:   TracerRFEventMsgOnline,
		},
		Data: &client.UrdDeviceInfo{
			Id:                heart.Id,
			Name:              string(heart.Name[:]),
			Longitude:         heart.Longitude,
			Latitude:          heart.Latitude,
			Height:            heart.Height,
			Status:            int32(heart.Status),
			Azimuth:           heart.Azimuth,
			Type:              heart.Type,
			CompassStatus:     int32(heart.CompassStatus),
			GpsStatus:         int32(heart.GpsStatus),
			ReceiverStatus:    int32(heart.ReceiverStatus),
			AntennaStatus:     int32(heart.AntennaStatus),
			AntennaCoverRange: heart.AntennaCoverRange,
			EventId:           utils.GetEventId(dev.SessionId),
		},
	}
	if err == nil {
		heartInfo.Header.ParentType = int32(equipModel.ParentType)
		heartInfo.Header.ParentSn = equipModel.ParentSn
		heartInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msg, err := proto.Marshal(heartInfo)
	if err != nil {
		logger.Errorf("proto.Marshal heartInfo err: %v", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgTracerRFStatusEventData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Errorf("marshal report err: %v", err)
		return
	}

	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Infof("tracerRF online event has reported, devSn: %v,report:%v", sn, heartInfo)
}

// TracerRFOffLineEventReport 坤雷离线事件上报
func TracerRFOffLineEventReport(sn string) {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_URD360, sn)
	eventId := ""

	if cache, ok := DevStatusMapOnEvent.Load(cacheKey); ok {
		dev := cache.(*Device)
		eventId = utils.GetEventId(dev.SessionId)
	} else {
		logger.Errorf("can't find tracerRF:%s in DevStatusMapOnEvent", sn)
		return
	}
	DevStatusMapOnEvent.Delete(cacheKey)

	equipModel, err := GetEquipBySn(sn)
	name := sn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	reportInfo := &client.UrdDeviceInfoUpload{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        sn,
			EquipType: int32(common.DEV_URD360),
			MsgType:   TracerRFEventMsgOffLine,
		},
		Data: &client.UrdDeviceInfo{
			EventId: eventId,
		},
	}
	if err == nil {
		reportInfo.Header.ParentType = int32(equipModel.ParentType)
		reportInfo.Header.ParentSn = equipModel.ParentSn
		reportInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}

	msg, err := jsoniter.Marshal(reportInfo)
	if err != nil {
		logger.Error("TracerRFOffLineEventReport marshal reportInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgTracerRFStatusEventData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Info("tracerRF Offline event report:", report)
}

// tracerRFDetectEvent 坤雷侦测事件上报
func tracerRFDetectEvent(sn, name string, info *UrdDroneInfo) {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_URD360, sn)
	if cache, ok := DevDetectMapOnEvent.Load(cacheKey); ok {
		detect := cache.(*DetectEvent)
		detect.LastReceiveTime = time.Now()
		return
	}
	detect := &DetectEvent{
		Sn:              sn,
		LastReceiveTime: time.Now(),
		DevType:         common.DEV_URD360,
		SessionId:       GetGlobalSessionId(),
	}
	DevDetectMapOnEvent.Store(cacheKey, detect)

	eventInfo := &common.EquipmentMessageBoxEntity{
		Name: name,
		Sn:   sn,
		Info: &UrdDroneInfoUpload{
			Id:               info.Id + 10000,
			UniqueId:         string(info.UniqueId[:]),
			TargetInfoLength: info.TargetInfoLength,
			TargetInfo:       string(info.TargetInfo[:]),
			StationId:        info.StationId,
			TargetAzimuth:    info.TargetAzimuth,
			TargetRange:      info.TargetRange,
			Longitude:        info.Longitude,
			Latitude:         info.Latitude,
			Height:           info.Height,
			Frequency:        info.Frequency,
			Bandwidth:        info.Bandwidth,
			SignalStrength:   info.SignalStrength,
			Trust:            info.Trust,
			Time:             formatTime(info.Hour, info.Minute, info.Second, info.MilliSecond),
			DataType:         info.DataType,
			Modulation:       info.Modulation,
			EventId:          utils.GetEventId(detect.SessionId),
		},
		EquipType: int(common.DEV_URD360),
		MsgType:   TracerRFEventDetectAppear,
	}
	msg, err := jsoniter.Marshal(eventInfo)
	if err != nil {
		logger.Errorf("proto.marshal eventInfo error: %v", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgTracerRFDetectEventData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Errorf("marshal report error: %v", err)
		return
	}
	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Infof("tracerRF detect uav event has reported, devSn: %v,report:%v", sn, eventInfo)
}

func TracerRFDetectDisappearEventReport(sn string) {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_URD360, sn)
	eventId := ""

	if cache, ok := DevDetectMapOnEvent.Load(cacheKey); ok {
		detect := cache.(*DetectEvent)
		eventId = utils.GetEventId(detect.SessionId)
	} else {
		logger.Infof("has not eventId for tracerRF detect disappear event report, sn: %v", sn)
		return
	}
	DevDetectMapOnEvent.Delete(cacheKey)

	eventInfo := &common.EquipmentMessageBoxEntity{
		Sn: sn,
		Info: &UrdDroneInfoUpload{
			EventId: eventId,
		},
		EquipType: int(common.DEV_URD360),
		MsgType:   TracerRFEventDetectDisappear,
	}
	msg, err := jsoniter.Marshal(eventInfo)
	if err != nil {
		logger.Error("marshal eventInfo err:", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgTracerRFDetectEventData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}
	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Info("tracerRF detect disappear event report:", report)
}

// UrdStartMonitor 启动监测
func UrdStartMonitor(sn string, cmdId uint8) (string, error) {
	// 获取连接
	conn, ok := getUrdConnection(sn)
	if !ok {
		return "该设备已离线", ErrUrd360Offline
	}

	// 接收启动监测响应
	ch := make(chan *UrdResultInfo, 1)
	cmdReplyEventBus.SubscribeOnce(fmt.Sprintf("%s_%d", sn, cmdId), func(data *UrdResultInfo) {
		ch <- data
	})

	// 发送启动监测请求
	req := &UrdStartMonitorReq{
		CmdId: cmdId,
		Start: []byte("RMTP:CFGSTART:startmeasure"),
	}
	var buf bytes.Buffer
	if err := utils.WriteBinary(&buf, binary.LittleEndian, req, 1+len(req.Start)); err != nil {
		return "", err
	}
	data := createUrdData(UrdCmdReqType, 0, buf.Bytes())
	buf.Reset()
	if err := utils.WriteBinary(&buf, binary.LittleEndian, data, int(data.Length)); err != nil {
		return "", err
	}
	_, err := conn.Write(buf.Bytes())
	if err != nil {
		return "向设备发送启动监测命令失败", err
	}
	logger.Infof("向设备发送启动监测命令成功: %+v", buf.Bytes())

	// 设置超时时间
	timer := time.NewTimer(5 * time.Second)
	defer timer.Stop()
	select {
	case <-timer.C:
		return "启动监测响应超时", fmt.Errorf("start monitor response timeout")
	case rsp := <-ch:
		if rsp.Result != "SUCCESSED" {
			return "启动监测失败", fmt.Errorf("start monitor response is not success")
		}
		return "启动监测成功", nil
	}
}

// UrdStopMonitor 停止监测
func UrdStopMonitor(sn string, cmdId uint8) (string, error) {
	// 获取连接
	conn, ok := getUrdConnection(sn)
	if !ok {
		return "该设备已离线", ErrUrd360Offline
	}

	// 接收停止监测响应
	ch := make(chan *UrdResultInfo, 1)
	cmdReplyEventBus.SubscribeOnce(fmt.Sprintf("%s_%d", sn, cmdId), func(data *UrdResultInfo) {
		ch <- data
	})

	// 发送停止监测请求
	req := &UrdStopMonitorReq{
		CmdId: cmdId,
		Stop:  []byte("RMTP:CFGSTOP:stopmeasure"),
	}
	var buf bytes.Buffer
	if err := utils.WriteBinary(&buf, binary.LittleEndian, req, 1+len(req.Stop)); err != nil {
		return "", err
	}
	data := createUrdData(UrdCmdReqType, 0, buf.Bytes())
	buf.Reset()
	if err := utils.WriteBinary(&buf, binary.LittleEndian, data, int(data.Length)); err != nil {
		return "", err
	}
	_, err := conn.Write(buf.Bytes())
	if err != nil {
		return "向设备发送停止监测命令失败", err
	}
	logger.Infof("向设备发送停止监测命令成功: %+v", buf.Bytes())

	// 设置超时时间
	timer := time.NewTimer(5 * time.Second)
	defer timer.Stop()
	select {
	case <-timer.C:
		return "停止监测响应超时", fmt.Errorf("stop monitor response timeout")
	case rsp := <-ch:
		if rsp.Result != "SUCCESSED" {
			return "停止监测失败", fmt.Errorf("stop monitor response is not success")
		}
		return "停止监测成功", nil
	}
}

// UrdUpdateConfig 更新配置
func UrdUpdateConfig(sn string, cmdId uint8, content []byte) (string, error) {
	// 获取连接
	conn, ok := getUrdConnection(sn)
	if !ok {
		return "该设备已离线", ErrUrd360Offline
	}

	// 接收更新配置响应
	ch := make(chan *UrdResultInfo, 1)
	cmdReplyEventBus.SubscribeOnce(fmt.Sprintf("%s_%d", sn, cmdId), func(data *UrdResultInfo) {
		ch <- data
	})

	// 发送更新配置请求
	req := &UrdFileData{
		CmdId:  cmdId,
		Type:   0,
		Length: int32(len(content)),
		Data:   content,
	}
	var buf bytes.Buffer
	if err := utils.WriteBinary(&buf, binary.LittleEndian, req, 6+len(req.Data)); err != nil {
		return "", err
	}
	data := createUrdData(UrdFileDataType, 0, buf.Bytes())
	buf.Reset()
	if err := utils.WriteBinary(&buf, binary.LittleEndian, data, int(data.Length)); err != nil {
		return "", err
	}
	_, err := conn.Write(buf.Bytes())
	if err != nil {
		return "向设备发送更新配置命令失败", err
	}
	logger.Infof("向设备发送更新配置命令成功: %+v", buf.Bytes())

	// 设置超时时间
	timer := time.NewTimer(5 * time.Second)
	defer timer.Stop()
	select {
	case <-timer.C:
		return "更新配置响应超时", fmt.Errorf("update config response timeout")
	case rsp := <-ch:
		if rsp.Result != "SUCCESSED" {
			return "更新配置失败", fmt.Errorf("update config response is not success")
		}
		// 更新成功后，重新启动监测
		_, err := UrdStartMonitor(sn, cmdId)
		if err != nil {
			return "更新配置成功，但启动监测失败", err
		}
		return "更新配置成功", nil
	}
}

// UrdEnable 启用禁用设备
func UrdEnable(sn string, enable int32) error {
	err := NewEquipList().SetEnableState(context.Background(), &client.SetEnableReq{Sn: sn, Status: enable, EType: "tracerRF"}, &client.SetEnableRes{})
	if err != nil {
		return err
	}
	return nil
}

// negotiateProtocol 协议协商
func negotiateProtocol(sn string, cmdId uint8, version uint16) error {
	// 获取连接
	conn, ok := getUrdConnection(sn)
	if !ok {
		return ErrUrd360Offline
	}

	// 接收协议协商响应
	ch := make(chan *UrdResultInfo, 1)
	cmdReplyEventBus.SubscribeOnce(fmt.Sprintf("%s_%d", sn, cmdId), func(data *UrdResultInfo) {
		ch <- data
	})

	// 发送协议协商请求
	req := &UrdNegotiateProtocolReq{
		CmdId:   cmdId,
		Version: version,
	}
	var buf bytes.Buffer
	if err := utils.WriteBinary(&buf, binary.LittleEndian, req, 3); err != nil {
		return err
	}
	data := createUrdData(UrdNegotiateType, 0, buf.Bytes())
	buf.Reset()
	if err := utils.WriteBinary(&buf, binary.LittleEndian, data, int(data.Length)); err != nil {
		return err
	}
	_, err := conn.Write(buf.Bytes())
	if err != nil {
		return err
	}
	logger.Infof("向设备发送协议协商命令成功: %+v", buf.Bytes())

	// 设置超时时间
	timer := time.NewTimer(5 * time.Second)
	defer timer.Stop()
	select {
	case <-timer.C:
		return fmt.Errorf("negotiate protocol response timeout")
	case rsp := <-ch:
		if rsp.Result != "SUCCESSED" {
			return fmt.Errorf("negotiate protocol response is not success")
		}
		return nil
	}
}

package handler

import (
	"bytes"
	"crypto/rand"
	"encoding/binary"
	"errors"
	"fmt"
	"math/big"
	randm "math/rand"
	"os"
	"strings"
	"sync"
	"time"

	"adasgitlab.autel.com/tools/cuav_plugin/broker"
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	jsoniter "github.com/json-iterator/go"

	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/server"
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/helper"
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/ip"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/proto/mavlink"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
)

var (
	GunTcpPort        int64 = 10000
	GunServerMaxCount int64 = 500
	GunTcpServerMap         = make(map[string]*server.TcpServer, 0)
	gunSendLock       sync.Mutex
	GunHeartSum       uint8
)

// const (
// 	AEAGMsgGetSn              = 0x81
// 	AEAGMsgGetChannel         = 0x10
// 	AEAGMsgHeartbeat          = 0x11
// 	AEAGMsgGetSoftVer         = 0xAB
// 	AEAGMsgGetAddress         = 0x21
// 	AEAGMsgSetWhiteList       = 0x22
// 	AEAGMsgHit                = 0x23
// 	AEAGGetAllWhiteList       = 0x24
// 	AEAGGetLogList            = 0x28
// 	AEAGGetLog                = 0x29
// 	AEAGDeleteLog             = 0x2A
// 	DeviceLogDownload         = 0x33
// 	LocalLogUpload            = 0x34
// 	CloudLogDownload          = 0x35
// 	GunIdResetSystem          = 0xA1 // 系统复位
// 	GunIdGetUpdateWriteStatus = 0xA6 // 获取固件写入状态
// 	GunIdRequestUpgrade       = 0xA7 // 请求固件升级
// 	GunIdSendUpdatePkg        = 0xA8 // 发送升级固件数据
// 	GunIdWriteUpdateData      = 0xA9 // 写入固件数据
// 	GunIdRunApp               = 0xAD // 运行固件App
// 	GunIdVerifyImage          = 0xAC // 校验固件镜像
// 	GunIdGetTimeoutRetryTime  = 0xAE // 获取运行超时重试时间
// 	GunIdBootToAppMod         = 0xAF // 程序处于boot时设置是否可跳转APP
// )

type CounterGun struct {
	*Device
	dt       common.DeviceType
	LogMsg   LogMsg
	LogCount uint32
}

var _ DeviceIfer = (*CounterGun)(nil)

// SetDevice 要使用GetOnLineDev 接口，必须要给该设备实现 DeviceIfer 接口
func (tg *CounterGun) SetDevice(d *Device) {
	tg.Device = d
}

func NewCounterGun(conn Connection, d []byte, dataLen int, remoteIp string, remotePort int, localIp string, serverPort int,
	mailBox map[int]*WaitTaskManager, dlimit *devLimit) DeviceInterface {
	return &CounterGun{
		Device: &Device{
			Conn:        conn,
			Msg:         d,
			MsgLen:      dataLen,
			SourceId:    d[mavlink.SenderLoc],
			RemoteIp:    remoteIp,
			RemotePort:  remotePort,
			LocalIp:     localIp,
			ServerPort:  serverPort,
			WaitTaskMap: mailBox,
		},
	}
}

func (d *CounterGun) Deal() {
	if d.MsgLen <= 0 {
		logger.Error("数据为null,不作处理: ", d.Device.RemoteIp)
		return
	}

	//xurong: 调用updateStatus更新连接
	d.updateStatus()
	msgId := d.Msg[mavlink.MsgIdLoc]
	switch msgId {
	case mavlink.AEAGMsgGetSoftVer:
		d.ReceiveAEAGSoftVer()
		break
	case mavlink.AEAGMsgGetSn:
		d.ReceiveAEAGSn()
		break
	case mavlink.AEAGGetLogList:
		d.ReceiveGetLogList()
		break
	case mavlink.AEAGGetLog:
		d.ReceiveGetLog()
		break
	case mavlink.AEAGDeleteLog:
		d.ReceiveDelLog()
		break
	case mavlink.GunIdResetSystem:
		d.ReceiveGunResetSystem()
		break
	case mavlink.GunIdGetUpdateWriteStatus:
		d.ReceiveGunGetUpdateWriteStatus()
		break
	case mavlink.GunIdRequestUpgrade:
		d.ReceiveGunRequestUpgrade()
		break
	case mavlink.GunIdSendUpdatePkg:
		d.ReceiveGunSendUpdatePkg()
		break
	case mavlink.GunIdWriteUpdateData:
		d.ReceiveGunWriteUpdateData()
		break
	case mavlink.GunIdRunApp:
		d.ReceiveGunRunApp()
		break
	case mavlink.GunIdVerifyImage:
		d.ReceiveGunVerifyImage()
		break
	case mavlink.GunIdGetTimeoutRetryTime:
		d.ReceiveGunGetUpdateTimeoutRetryTime()
		break
	case mavlink.GunIdBootToAppMod:
		d.ReceiveGunBootToAppMod()
		break
	default:
		logger.Error("未知反制枪消息id:", msgId)
		break
	}
}

// GetChannel @fzw nouse code?
func (d *CounterGun) GetChannel() (err error) {
	var tcpServer *server.TcpServer
	req := &mavlink.GunGetChannelRequest{}
	pack := d.GetPacket(req)
	devSn := req.SnToString()
	if pack == nil || devSn == "" {
		logger.Info("枪获取信道不能sn为空")
		return nil
	}
	d.CacheAndCheckSn(devSn, int32(d.SourceId))
	logger.Info("反制枪获取信道：", devSn, d.SourceId)
	if s, ok := GunTcpServerMap[devSn]; ok {
		s.Stop()
		deviceUsedPorts.Delete(s.Port)
		GunTcpServerMap[devSn] = nil
	}

	//注册tcp服务
	port, err := ip.GetFreeTcpPort()
	if err != nil {
		logger.Error("aeag tcp 获取可用端口失败：", err)
		port = d.getRandPort(GunTcpPort, GunTcpPort+GunServerMaxCount)
	}
	tcpServer = server.NewTcpServer(port, Handle)
	GunTcpServerMap[devSn] = tcpServer
	tcpServer.ServerType = uint8(common.DEV_AEAG)
	tcpServer.ServerName = devSn
	tcpServer.Port = port
	go tcpServer.Start()

	//判断是否开启成功
	//if tcpServer.Status != server.TcpServerNormal {
	//	return nil, errors.New("开启tcp失败")
	//}
	d.cacheConn(devSn)
	addr := d.LocalIp
	tcpServer.Ip = addr
	tcpServer.LastHeartTime = time.Now()
	res := &mavlink.GunGetChannelResponse{}
	resBuff := res.CreateGetChannelResponse(addr, uint16(port))
	n, err := d.Conn.Write(resBuff)
	logger.Info("反制枪响应获取信道：", addr, n, err)
	return nil
}

func (d *CounterGun) getRandPort(min, max int64) int {
	maxBigInt := big.NewInt(max)
	i, _ := rand.Int(rand.Reader, maxBigInt)
	_, ok := deviceUsedPorts.Load(i.Int64())
	port := i.Int64()
	//缓存不存在或者符合范围
	if !ok || (port > min && port < max) {
		deviceUsedPorts.Store(port, port)
		return int(port)
	}
	return d.getRandPort(min, max)
}

func (d *CounterGun) cacheConn(sn string) {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_AEAG, sn)
	cache, ok := DevStatusMap.Load(cacheKey)
	if !ok {
		dev := &Device{
			Name:           sn,
			Sn:             sn,
			Conn:           d.Conn,
			Status:         common.DevOffline,
			RemoteIp:       d.RemoteIp,
			RemotePort:     d.RemotePort,
			LocalIp:        d.LocalIp,
			ServerPort:     d.ServerPort,
			DevType:        common.DEV_AEAG,
			FirstHeartTime: time.Now(),
			LastHeartTime:  time.Now(),
			IsEnable:       common.DeviceEnable,
			WaitTaskMap:    d.WaitTaskMap,
		}
		DevStatusMap.Store(cacheKey, dev)
		logger.Debug("[cacheConn] DevStatus Stroe sn:", sn)
		return
	}
	dev := cache.(*Device)
	//是否直接信任
	dev.LastHeartTime = time.Now()
	dev.Status = common.DevOffline
	dev.Conn = d.Conn
	dev.WaitTaskMap = d.WaitTaskMap
}

// 缓存conn 获取信道、重连后的后必须更新
func (d *CounterGun) updateStatus() {
	sn := d.Sn
	if sn == "" {
		sn = d.getSn(d.Msg[mavlink.SenderLoc])
		if sn == "" {
			logger.Error("反制枪更新缓存信道连接错误:", d.RemoteIp)
			return
		}
	}
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_AEAG, sn)
	if cache, ok := DevStatusMap.Load(cacheKey); ok {
		dev := cache.(*Device)
		dev.LastHeartTime = time.Now()
		dev.Status = common.DevOnline
		dev.Conn = d.Conn
		dev.WaitTaskMap = d.WaitTaskMap
	}
	return
}

func (d *CounterGun) Heart() {
	heart := &mavlink.AeagHeartbeat{}
	d.GetPacket(heart)
	uavNum := heart.UUAVNum
	var uavs []*common.Uav
	heartLen := heart.Size()
	if uavNum > 0 {
		uavs = heart.DeserializeUav(d.Msg[heartLen+mavlink.HeaderLen : d.MsgLen-2])
		logger.Infof("接收到心跳,无人机个数：%v,%v", uavNum, uavs)
	}
	devSn := d.getSn(d.SourceId)
	d.report(devSn, uavs, heart)
}

func (d *CounterGun) report(devSn string, uavs []*common.Uav, heartBeat *mavlink.AeagHeartbeat) {
	reportUavs := make([]*common.UavReport, 0)
	for _, v := range uavs {
		nameBuff := make([]byte, 0)
		for _, v := range v.Name {
			if v == 0x00 {
				break
			}
			nameBuff = append(nameBuff, v)
		}
		reportUavs = append(reportUavs, &common.UavReport{
			Name:           string(nameBuff),
			UFreq:          v.UFreq,
			UDistance:      v.UDistance / mavlink.GunDistanceRed,
			UDangerLevels:  v.UDangerLevels,
			DroneAltitude:  v.DroneAltitude,
			DroneLatitude:  float64(v.DroneLatitude) / mavlink.GunGeoReduce,
			DroneLongitude: float64(v.DroneLongitude) / mavlink.GunGeoReduce,
		})
	}
	report := &common.AeagHeartbeatReport{
		Heartbeat: &common.GunStatusReport{
			Sn:             devSn,
			ScreenStatus:   heartBeat.ScreenStatus,
			Electricity:    heartBeat.Electricity,
			SignalStrength: heartBeat.SignalStrength,
			WorkStatus:     heartBeat.WorkStatus,
			AlarmLevel:     heartBeat.AlarmLevel,
			HitFreq:        heartBeat.HitFreq,
			DetectFreq:     heartBeat.DetectFreq,
			X:              heartBeat.X,
			Y:              heartBeat.Y,
			Z:              heartBeat.Z,
			GunLongitude:   float64(heartBeat.GunLongitude) / mavlink.GunGeoReduce,
			GunLatitude:    float64(heartBeat.GunLatitude) / mavlink.GunGeoReduce,
			GunAltitude:    heartBeat.GunAltitude,
			SatellitesNum:  heartBeat.SatellitesNum,
			GunDirection:   heartBeat.GunDirection,
			TimeStamp:      heartBeat.TimeStamp,
			UUAVNum:        heartBeat.UUAVNum,
			IsOnline:       common.DevOnline,
		},
		Uavs: reportUavs,
	}

	logger.Infof("反制枪接收到心跳：%v", report)
	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	msg := common.EquipmentMessageBoxEntity{
		Name:      name,
		Sn:        devSn,
		MsgType:   mavlink.AEAGMsgHeartbeat,
		EquipType: int(common.DEV_AEAG),
		Info:      report,
	}
	if err == nil {
		msg.ParentType = equipModel.ParentType
		msg.ParentSn = equipModel.ParentSn
		msg.IsIntegrated = equipModel.IsIntegrated
	}
	_ = mq.GunHeartBroker.Publish(mq.GunHeartTopic, broker.NewMessage(msg))
	logger.Info("反制枪上报心跳完成:", devSn)
}

// GetPacket 只适用与固定长度的消息,interface、[]byte、嵌套结构体不支持
func (d *CounterGun) GetPacket(message mavlink.Message) *mavlink.MavPacket {
	logger.Infof("GetPacket is [% x]", d.Msg)
	req := mavlink.NewNullPacket(message)
	buff := &bytes.Buffer{}
	if err := binary.Write(buff, binary.LittleEndian, d.Msg); err != nil {
		logger.Error("GetPacket write buff err:", err)
		return nil

	}
	if err := binary.Read(buff, binary.LittleEndian, &req.Header); err != nil {
		logger.Error("GetPacket read header err:", err)
		return nil
	}
	if err := binary.Read(buff, binary.LittleEndian, req.Msg); err != nil {
		logger.Error("GetPacket read msg err:", err)
		return nil
	}
	return req
}

func (d *CounterGun) SendGetAEAGSoftVer(sn string) (uint32, string, string, string, string, error) {
	logger.Info("SendGetAEAGSoftVer Start")
	logger.Infof("SendGetAEAGSoftVer WaitTaskMap %v\n", d.WaitTaskMap)
	d.MsgId = mavlink.AEAGMsgGetSoftVer
	req := &mavlink.GetAEAGVersionRequest{}
	reqBuff := req.CreateGetAEAGVersionRequest()

	// 先创建接受返回结果的任务
	if d.WaitTaskMap == nil {
		return 0, "", "", "", "", errors.New("data link not established")
	}
	manager, ok := d.WaitTaskMap[d.MsgId]
	if !ok {
		manager = NewWaitTaskManager(d.MsgId, true, 20*time.Second)
		d.WaitTaskMap[d.MsgId] = manager
	}
	task := manager.AddTask(nil, nil)

	if err := d.Send(sn, reqBuff); err != nil {
		logger.Errorf("SendGetAEAGSoftVer d.Send err %v \n", err)
		return 0, "", "", "", "", err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 0, "", "", "", "", err
		}
		return 0, "", "", "", "", err
	}
	res := result.(*mavlink.GetAEAGVersionResponse)
	logger.Info("SendGetAEAGSoftVer end")
	return res.RunVersion,
		d.TrimStringSpace(res.AppVersion[:]),
		d.TrimStringSpace(res.BootVersion[:]),
		d.TrimStringSpace(res.HwVersion[:]),
		d.TrimStringSpace(res.ProtocolVersion[:]),
		nil
}

func (d *CounterGun) ReceiveAEAGSoftVer() error {
	ver := &mavlink.GetAEAGVersionResponse{}
	d.GetPacket(ver)

	logger.Info("接收到软件版本：", ver)
	manager, ok := d.WaitTaskMap[mavlink.AEAGMsgGetSoftVer]
	if ok {
		manager.CompletedTask(ver, nil)
	}
	return nil
}

func (d *CounterGun) TrimStringSpace(strArr []byte) string {
	tmp := make([]byte, 0)
	for _, v := range strArr {
		if v == 0x00 {
			break
		}
		tmp = append(tmp, v)
	}
	return string(tmp)
}

func (d *CounterGun) SendGetAEAGAddress(sn string) error {
	req := mavlink.GetAEAGAddressRequest{}
	reqBuff := req.CreateGetAEAGAddressRequest()
	if err := d.Send(sn, reqBuff); err != nil {
		return err
	}
	//这里是不是要等待获取到
	return nil
}

func (d *CounterGun) ReceiveAEAGAddress() string {
	addr := &mavlink.GetAEAGAddressResponse{}
	d.GetPacket(addr)
	return addr.ToAddress()
}

func (d *CounterGun) SendSetWhiteList(sn, uavName string) (*mavlink.SetGunWhiteListResponse, error) {
	d.MsgId = mavlink.AEAGMsgSetWhiteList
	req := &mavlink.SetGunWhiteListRequest{}
	reqBuff := req.CreateSetGunWhiteListRequest(uavName)
	if err := d.Send(sn, reqBuff); err != nil {
		return nil, err
	}
	manager, ok := d.WaitTaskMap[d.MsgId]
	if !ok {
		manager = NewWaitTaskManager(d.MsgId, true, 0)
		d.WaitTaskMap[d.MsgId] = manager
	}
	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return nil, checkNetConnErr
		}
	}
	return result.(*mavlink.SetGunWhiteListResponse), nil
}

func (d *CounterGun) ReceiveSetWhiteListResponse() {
	res := &mavlink.SetGunWhiteListResponse{}
	d.GetPacket(res)
	logger.Info("get white list response :", res.Status)
	manager, ok := d.WaitTaskMap[mavlink.AEAGMsgSetWhiteList]
	if ok {
		manager.CompletedTask(res, nil)
	}
}

func (d *CounterGun) SendHit(sn string, mode uint8, hitFreq uint8, longitude, latitude, altitude uint16, hitTime uint16) (*mavlink.SetGunHitResponse, error) {
	d.MsgId = mavlink.AEAGMsgHit
	if hitTime <= 0 {
		hitTime = 10
	}
	req := &mavlink.SetGunHitRequest{
		Mode:           mode,
		HitFreq:        hitFreq,
		DroneLongitude: longitude,
		DroneLatitude:  latitude,
		DroneAltitude:  altitude,
		HitTime:        hitTime,
	}
	reqBuff := req.CreateHitRequest()
	if err := d.Send(sn, reqBuff); err != nil {
		return nil, err
	}
	manager, ok := d.WaitTaskMap[d.MsgId]
	if !ok {
		manager = NewWaitTaskManager(d.MsgId, true, 0)
		d.WaitTaskMap[d.MsgId] = manager
	}
	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return nil, checkNetConnErr
		}
	}
	return result.(*mavlink.SetGunHitResponse), nil
}

func (d *CounterGun) ReceiveHitResponse() {
	hitRes := &mavlink.SetGunHitResponse{}
	d.GetPacket(hitRes)
	logger.Info("set hit response :", hitRes.Status)
	manager, ok := d.WaitTaskMap[mavlink.AEAGMsgHit]
	if ok {
		manager.CompletedTask(hitRes, nil)
	}
}

func (d *CounterGun) SendGetWhiteList(sn string) ([]string, error) {
	d.MsgId = mavlink.AEAGGetAllWhiteList
	req := mavlink.GetAEAGWhiteListRequest{}
	reqBuff := req.CreateGetAEAGWhiteListRequest()
	if err := d.Send(sn, reqBuff); err != nil {
		return nil, err
	}
	manager, ok := d.WaitTaskMap[d.MsgId]
	if !ok {
		manager = NewWaitTaskManager(d.MsgId, true, 0)
		d.WaitTaskMap[d.MsgId] = manager
	}
	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return nil, checkNetConnErr
		}
		return nil, err
	}
	return result.([]string), nil
}

func (d *CounterGun) ReceiveGetWhiteList() {
	dataBuff := d.Msg[mavlink.HeaderLen : len(d.Msg)-mavlink.CrcLen]
	cnt := len(dataBuff) / 20
	whiteList := make([]string, 0)
	for i := 0; i < cnt; i++ {
		tmp := dataBuff[i*20+1 : (i+1)*20+1]
		nameBuff := make([]byte, 0)
		for _, v := range tmp {
			if v == 0x00 {
				break
			}
			nameBuff = append(nameBuff, v)
		}
		whiteList = append(whiteList, string(nameBuff))
	}
	logger.Info("get white list response:", whiteList)
	manager, ok := d.WaitTaskMap[mavlink.AEAGGetAllWhiteList]
	if ok {
		manager.CompletedTask(whiteList, nil)
	}
}

func (d *CounterGun) SendExtHeartbeat() error {
	GunHeartSum++
	if GunHeartSum > 255 {
		GunHeartSum = 0
	}
	req := &mavlink.GunHeartbeatExtRequest{
		GunHeartSum,
	}
	reqBuff := req.CreateGunHeartbeatExt()
	if d != nil && d.Conn != nil {
		n, err := d.Conn.Write(reqBuff)
		logger.Info("c2发送反制枪心跳结果：", GunHeartSum, n, err)
		return err
	}
	return nil
}

func (d *CounterGun) Send(sn string, reqBuff []byte) error {
	if sn == "" {
		return errors.New("设备未连接")
	}
	//是否要加锁
	gunSendLock.Lock()
	defer gunSendLock.Unlock()
	if d.Device == nil {
		cacheKey := fmt.Sprintf("%d_%s", common.DEV_AEAG, sn)
		cache, ok := DevStatusMap.Load(cacheKey)
		if !ok {
			return errors.New("设备未连接")
		}
		dev := cache.(*Device)
		d.Device = dev
	}

	if _, err := d.Conn.Write(reqBuff); err != nil {
		return err
	}
	return nil
}

func (d *CounterGun) getSn(sourceId uint8) string {
	if sn, ok := DevSnMap.Load(int32(sourceId)); ok {
		return sn.(string)
	}
	return ""
}

func (d *CounterGun) CacheAndCheckSn(sn string, sourceId int32) (uint8, error) {
	//获取信道的时候，都会更新一遍sn
	if sn != "" {
		DevSnMap.Store(sourceId, sn)
	}
	return uint8(sourceId), nil
}

func (d *CounterGun) LogOperator(req, resp interface{}, err error) {
	reqJson, _ := jsoniter.Marshal(req)
	res := ""
	remark := ""
	if err != nil {
		remark = err.Error()
	}
	if resp != nil {
		resJson, _ := jsoniter.Marshal(resp)
		res = string(resJson)
	}
	msg := common.DeviceEventEntity{
		DeviceType: int(common.DEV_RADAR),
		Sn:         d.Sn,
		MsgId:      uint8(d.MsgId),
		Request:    string(reqJson),
		Response:   res,
		Remark:     remark,
	}
	_ = mq.DeviceCommEventBroker.Publish(mq.DeviceCommEventTopic, broker.NewMessage(common.EquipmentMessageBoxEntity{
		Info: msg,
	}))
}

func (d *CounterGun) ReceiveAEAGSn() error {
	d.MsgId = mavlink.AEAGMsgGetSn
	if d.MsgLen != mavlink.HeaderLen+14+mavlink.CrcLen {
		logger.Errorf("接收到反制枪sn长度错误")
		return nil
	}
	snBuff := d.Msg[mavlink.HeaderLen : d.MsgLen-mavlink.CrcLen]
	snLen := len(snBuff)
	for i, v := range snBuff {
		if v == 0x00 {
			snLen = i
			break
		}
	}
	sn := string(snBuff[:snLen])
	logger.Info("接收到反制枪sn：", sn)
	manager, ok := d.WaitTaskMap[d.MsgId]
	if ok {
		manager.CompletedTask(sn, nil)
	}
	return nil
}

func SendGunHeart() {
	ticker := time.NewTicker(time.Second * 1)
	defer ticker.Stop()
	for range ticker.C {
		DevStatusMap.Range(func(key, value interface{}) bool {
			dev := value.(*Device)
			if dev.DevType == common.DEV_AEAG && dev.Status == common.DevOnline {
				reqMode := &CounterGun{
					Device: dev,
					dt:     common.DEV_AEAG,
				}
				reqMode.SendExtHeartbeat()
			}
			return true
		})
	}
}

// SendGetLogList -----------------------------日志列表-----------------------------------------------
// 发送请求枪日志列表指令
func (d *CounterGun) SendGetLogList(sn string) (*mavlink.GunGetLogListResponseAll, error) {
	logger.Info("-->Into Send Get LogList To Gun sn:", sn)
	defer func() {
		if r := recover(); r != nil {
			logger.Error("Gun Get LogList occurred:", r)
			return
		}
	}()
	req := mavlink.GunGetLogListRequest{}
	reqBuff := req.CreateGunGetLogList()
	if err := d.Send(sn, reqBuff); err != nil {
		logger.Error("-->Send Get LogList To Gun fail !,err is : ", err)
		return nil, err
	}
	manager, ok := d.WaitTaskMap[mavlink.AEAGGetLogList]
	if !ok {
		manager = NewWaitTaskManager(mavlink.AEAGGetLogList, true, time.Second*10)
		d.WaitTaskMap[mavlink.AEAGGetLogList] = manager
	}
	result, err := manager.Wait()
	if err != nil {
		logger.Error("-->Wait err : ", err)
		return nil, err
	}
	logger.Info("-->Send Get LogList To Gun End")
	return result.(*mavlink.GunGetLogListResponseAll), nil
}

// ReceiveGetLogList 接收枪日志列表返回，组包
func (d *CounterGun) ReceiveGetLogList() {
	logger.Info("-->into Revceive Get LogList")

	var PkgTotalNum uint32
	var PkgCurNum uint32
	var LogNameLen uint32
	var LogDataLen uint32
	var LogName []byte

	io := bytes.NewReader(d.Msg[9:])
	err := mavlink.Read(io, binary.LittleEndian, &PkgTotalNum, 4)
	logger.Info("PkgTotalNum : ", PkgTotalNum)

	err = mavlink.Read(bytes.NewReader(d.Msg[mavlink.HeaderLen+4:mavlink.HeaderLen+8]), binary.LittleEndian, &PkgCurNum, 4)
	logger.Info("PkgTotalNum : ", PkgCurNum)

	if err != nil {
		logger.Error("msg Decode err : ", err)
		return
	}
	msg := &mavlink.GunGetLogListResponse{}

	index := mavlink.HeaderLen + 8
	for {
		//退出条件
		if len(d.Msg)-index < mavlink.CrcLen+1 {
			break
		}
		//解析LogNameLen
		err = mavlink.Read(bytes.NewReader(d.Msg[index:]), binary.LittleEndian, &LogNameLen, 4)
		if err != nil {
			logger.Error("msg Decode LogNameLen err : ", err)
			return
		}
		//解析LogDataLen
		index = index + 4
		err = mavlink.Read(bytes.NewReader(d.Msg[index:]), binary.LittleEndian, &LogDataLen, 4)
		if err != nil {
			logger.Error("msg Decode LogDataLen err : ", err)
			return
		}
		//解析LogName
		index = index + 4
		LogName = make([]byte, LogNameLen)
		err = mavlink.Read(bytes.NewReader(d.Msg[index:]), binary.LittleEndian, &LogName, int(LogNameLen))
		if err != nil {
			logger.Error("msg Decode LogName err : ", err)
			return
		}
		msg.LogInfo = append(msg.LogInfo, mavlink.LogInfo{
			LogNameLen: LogNameLen,
			LogDataLen: LogDataLen,
			LogName:    LogName,
		})

		logger.Debug("LogName : ", string(LogName))
		index = index + int(LogNameLen)
	}

	var i interface{} = msg
	if PkgCurNum+1 != PkgTotalNum {
		logger.Info("-->Revceive ing")
		mavlink.GunResAll.SetData(i.(*mavlink.GunGetLogListResponse))

	} else {
		mavlink.GunResAll.SetData(i.(*mavlink.GunGetLogListResponse))
		logger.Info("Loglist res is : ", msg)
		manager, ok := d.WaitTaskMap[mavlink.AEAGGetLogList]
		if ok {
			manager.CompletedTask(&mavlink.GunResAll, nil)
		}
		logger.Info("-->Revceive Get LogList end")
	}

}

// SendGetLog -----------------------------请求日志-----------------------------------------------
// 发送请求枪日志指令
func (d *CounterGun) SendGetLog(sn, filePath string, logInfo []DeviceLogList) (*mavlink.GunGetLogMsgResponse, error) {
	logger.Info("-->Into Send Get Log To Gun")
	logger.Info("LogInfo:", logInfo)
	defer func() {
		if r := recover(); r != nil {
			logger.Error("Gun Get Log occurred:", r)
			return
		}
	}()
	//var num uint32
	//binary.Read(rand.Reader, binary.LittleEndian, &num)
	// 设置种子以确保随机性
	randm.Seed(time.Now().UnixNano())
	// 生成一个随机数
	randomNum := randm.Uint32()
	logger.Info("rand is ", randomNum)
	req := mavlink.GunGetLogRequestAll{}
	logreq := make([]*mavlink.GunGetLogRequest, 0)

	logfile := &mavlink.GunLogFileInfo{
		LogId:      randomNum,
		LogNameLen: uint32(len(logInfo[0].LogName)),
		LogName:    []byte(logInfo[0].LogName),
	}
	logreq = append(logreq, &mavlink.GunGetLogRequest{
		LogNum:      1,
		LogFileInfo: [1]mavlink.GunLogFileInfo{*logfile},
	})

	reqBuff := req.CreateGunGetLog(randomNum, logreq)

	FileNameMap.Set(randomNum, logInfo[0].LogName, filePath+"/guns/"+sn+"/"+logInfo[0].LogName)

	//创建文件夹
	err := helper.CreateDirIfNotExist(filePath + "/guns/" + sn)
	if err != nil {
		logger.Error("Create directory error : ", err)
	} else {
		logger.Info("Directory created successfully.")
	}

	logger.Info("-->File Path is : ", filePath+"/guns/"+sn+"/"+logInfo[0].LogName)
	if err = d.Send(sn, reqBuff); err != nil {
		logger.Error("-->Send Get Log To Gun Fail,err : ", err)
		return nil, err
	}
	logger.Info("-->Into Send Get file")

	manager, ok := d.WaitTaskMap[mavlink.AEAGGetLog]
	if !ok {
		manager = NewWaitTaskManager(mavlink.AEAGGetLog, true, time.Second*600)
		d.WaitTaskMap[mavlink.AEAGGetLog] = manager
	}
	// TODO 处理包序
	result, err := manager.Wait()
	if err != nil {
		logger.Error("-->Wait Fail,err : ", err)
		return nil, err
	}
	logger.Info("-->Send Get Log End To Gun")
	return result.(*mavlink.GunGetLogMsgResponse), nil
}

// ReceiveGetLog 接收枪日志文件返回
func (d *CounterGun) ReceiveGetLog() {
	logger.Info("-->into Receive Get Log")

	var PkgTotalNum uint32
	var PkgCurNum uint32

	var LogId uint32

	err := mavlink.Read(bytes.NewReader(d.Msg[mavlink.HeaderLen:mavlink.HeaderLen+4]), binary.LittleEndian, &LogId, 4)
	logger.Debug("LogId : ", LogId)

	err = mavlink.Read(bytes.NewReader(d.Msg[mavlink.HeaderLen+4:mavlink.HeaderLen+8]), binary.LittleEndian, &PkgTotalNum, 4)
	logger.Debug("PkgTotalNum : ", PkgTotalNum)

	err = mavlink.Read(bytes.NewReader(d.Msg[mavlink.HeaderLen+8:mavlink.HeaderLen+12]), binary.LittleEndian, &PkgCurNum, 4)
	logger.Debug("PkgCurNum ", PkgCurNum)

	if err != nil {
		logger.Error("msg Decode err : ", err)
		return
	}
	var msg string

	msg = string(d.Msg[mavlink.HeaderLen+16 : len(d.Msg)-mavlink.CrcLen])
	fileInfo, isExit := FileNameMap.Get(LogId)
	if isExit != true {
		logger.Error("File Name Map Get err")
	}

	if PkgCurNum == 0 {
		//go DownLoadling(DeviceLogDownload, d.LogMsg.FileName, d.Sn)
		file, err := os.Create(fileInfo.FilePath)
		if err != nil {
			logger.Error(err)
		}
		defer file.Close()
		logger.Debug("文件已创建")
	}
	mavlink.GunLogMsgAll.SetData(msg)
	if PkgCurNum+1 != PkgTotalNum {
		logger.Debug("-->Revceive log ing")
		if PkgCurNum%GunPackNUm == 0 { //1000个包写入一次  一个包1k
			if PkgCurNum == GunPackNUm {
				//新建文件写入
				err = os.WriteFile(fileInfo.FilePath, []byte(strings.Join(mavlink.GunLogMsgAll.GetData(), "")), 0644)
				if err != nil {
					logger.Error("Log Store Fail,err:", err)
				}
			} else {
				//追加写入
				file, err := os.OpenFile(fileInfo.FilePath, os.O_APPEND|os.O_WRONLY, 0644)
				if err != nil {
					logger.Error(err)
				}
				file.WriteString(strings.Join(mavlink.GunLogMsgAll.GetData(), ""))
				defer file.Close()
			}
			mavlink.GunLogMsgAll.DeleteData()
		}
	} else {
		logger.Info("-->Revceive Get Log All end")
		if PkgTotalNum == 1 {
			//新建文件写入
			err = os.WriteFile(fileInfo.FilePath, []byte(strings.Join(mavlink.GunLogMsgAll.GetData(), "")), 0644)
			if err != nil {
				logger.Error("Log Store Fail,err:", err)
			}
			manager, ok := d.WaitTaskMap[mavlink.AEAGGetLog]
			if ok {
				manager.CompletedTask(&mavlink.GunLogMsgAll, nil)
			}
		} else {
			//追加写入
			file, err := os.OpenFile(fileInfo.FilePath, os.O_APPEND|os.O_WRONLY, 0644)
			if err != nil {
				logger.Error(err)
			}
			file.WriteString(strings.Join(mavlink.GunLogMsgAll.GetData(), ""))
			defer file.Close()
			manager, ok := d.WaitTaskMap[mavlink.AEAGGetLog]
			if ok {
				manager.CompletedTask(&mavlink.GunLogMsgAll, nil)
			}
		}
		mavlink.GunLogMsgAll.DeleteData()
		FileNameMap.Del(LogId)
	}
	logger.Info("-->Receive GetLog  end")
}

// SendDelLog -----------------------------删除日志-----------------------------------------------
// 发送删除枪日志指令
func (d *CounterGun) SendDelLog(sn string) (*mavlink.GunDelLogResponse, error) {
	logger.Info("-->Into Send Del Log")
	req := mavlink.GunDelLogRequest{}
	reqBuff := req.CreateGunDelLog()
	if err := d.Send(sn, reqBuff); err != nil {
		logger.Error("-->Send Del Log To Gun Fail,err : ", err)
		return nil, err
	}
	manager, ok := d.WaitTaskMap[mavlink.AEAGDeleteLog]
	if !ok {
		manager = NewWaitTaskManager(mavlink.AEAGDeleteLog, true, 0)
		d.WaitTaskMap[mavlink.AEAGDeleteLog] = manager
	}
	// TODO 处理包序
	result, err := manager.Wait()
	if err != nil {
		logger.Error("-->Send Del Log Wait err : ", err)
		return nil, err
	}
	logger.Info("-->Send Del Log End")
	return result.(*mavlink.GunDelLogResponse), nil
}

// ReceiveDelLog 接收枪日志文件返回
func (d *CounterGun) ReceiveDelLog() {
	logger.Info("-->into Receive Del Log")
	res := &mavlink.GunDelLogResponse{}
	d.GetPacket(res)
	logger.Info("get Del Log response : ", res.Status)
	manager, ok := d.WaitTaskMap[mavlink.AEAGDeleteLog]
	if ok {
		manager.CompletedTask(res, nil)
	}
	logger.Info("-->Receive Del Log end")
}

// GunResetSystem 系统复位
func (d *CounterGun) GunResetSystem(rq *client.ResetSystemRequest) (int32, error) {
	logger.Info("GunResetSystem Start")
	req := &mavlink.GunResetSystemRequest{
		ResetCode: mavlink.GunOtaReSetCode,
		Type:      uint16(4),
	}
	buff := req.Create()
	logger.Info(buff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("GunResetSystem 发送反制抢系统复位信息失败: ", err)
		return 1, err
	}
	logger.Infof("GunResetSystem End")
	return 0, nil
}

// ReceiveGunResetSystem 获取系统复位响应
func (d *CounterGun) ReceiveGunResetSystem() {
	res := &mavlink.GunResetSystemResponse{}
	d.GetPacket(res)
	logger.Debugf("系统复位回复信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.GunIdResetSystem]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// GunGetUpdateWriteStatus 获取固件写入状态
func (d *CounterGun) GunGetUpdateWriteStatus() (*mavlink.GunGetUpdateWriteStatusResponse, error) {
	logger.Info("GunGetUpdateWriteStatus Start")
	req := &mavlink.GunGetUpdateWriteStatusRequest{}
	buff := req.Create()
	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.GunIdGetUpdateWriteStatus]
	if !ok {
		manager = NewWaitTaskManager(mavlink.GunIdGetUpdateWriteStatus, true, 0)
		d.WaitTaskMap[mavlink.GunIdGetUpdateWriteStatus] = manager
	}
	task := manager.AddTask(nil, nil)

	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("GunGetUpdateWriteStatus 发送获取固件写入状态信息失败: ", err)
		return nil, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("GunGetUpdateWriteStatus WaitTask Err: %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return nil, checkNetConnErr
		}
		return nil, err
	}
	res := result.(*mavlink.GunGetUpdateWriteStatusResponse)
	logger.Debugf("GunGetUpdateWriteStatus 获取固件写入状态信息结果：%#v", res)
	logger.Info("GunGetUpdateWriteStatus End")
	return res, nil
}

// ReceiveGunGetUpdateWriteStatus 获取固件写入状态回复结果
func (d *CounterGun) ReceiveGunGetUpdateWriteStatus() {
	res := &mavlink.GunGetUpdateWriteStatusResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveGunGetUpdateWriteStatus 获取固件写入状态回复信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.GunIdGetUpdateWriteStatus]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// GunGetUpdateTimeoutRetryTime 获取固件升级超时重试时间
func (d *CounterGun) GunGetUpdateTimeoutRetryTime() (*mavlink.GunGetUpdateTimeoutRetryTimeResponse, error) {
	logger.Info("GunGetUpdateTimeoutRetryTime Start")
	req := &mavlink.GunGetUpdateTimeoutRetryTimeRequest{}
	buff := req.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.GunIdGetTimeoutRetryTime]
	if !ok {
		manager = NewWaitTaskManager(mavlink.GunIdGetTimeoutRetryTime, true, 0)
		d.WaitTaskMap[mavlink.GunIdGetTimeoutRetryTime] = manager
	}
	task := manager.AddTask(nil, nil)

	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("GunGetUpdateTimeoutRetryTime 发送获取固件升级超时重试时间信息失败: ", err)
		return nil, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("GunGetUpdateTimeoutRetryTime WaitTask Err: %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return nil, checkNetConnErr
		}
		return nil, err
	}
	res := result.(*mavlink.GunGetUpdateTimeoutRetryTimeResponse)
	logger.Debugf("GunGetUpdateTimeoutRetryTime 获取固件升级超时重试时间信息结果：%#v", res)
	logger.Info("GunGetUpdateTimeoutRetryTime End")
	return res, nil
}

// ReceiveGunGetUpdateTimeoutRetryTime 获取固件升级超时重试时间响应
func (d *CounterGun) ReceiveGunGetUpdateTimeoutRetryTime() {
	res := &mavlink.GunGetUpdateTimeoutRetryTimeResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveGunGetUpdateTimeoutRetryTime 获取固件升级超时重试时间回复信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.GunIdGetTimeoutRetryTime]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// GunRequestUpgrade 请求固件升级
func (d *CounterGun) GunRequestUpgrade(data [256]byte, tryCount int) (int32, error) {
	logger.Info("GunRequestUpgrade Start")
	var req = &mavlink.GunRequestUpgradeRequest{
		Data: data,
	}
	buff := req.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.GunIdRequestUpgrade]
	if !ok {
		manager = NewWaitTaskManager(mavlink.GunIdRequestUpgrade, true, 0)
		d.WaitTaskMap[mavlink.GunIdRequestUpgrade] = manager
	}
	task := manager.AddTask(nil, nil)

	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("GunRequestUpgrade 请求固件升级: ", err)
		return 1, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("GunRequestUpgrade WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 1, checkNetConnErr
		}
		return 1, err
	}
	res := result.(*mavlink.GunRequestUpgradeResponse)
	logger.Debugf("GunRequestUpgrade 请求固件升级：%#v", res)
	logger.Info("GunRequestUpgrade End")
	// 嵌入是boot有个bug第一次请求A7有一定概率会返回1;睡眠2两秒再重试
	if res.Status != 0 {
		if tryCount > 0 {
			tryCount--
			time.Sleep(2 * time.Second)
			return d.GunRequestUpgrade(data, tryCount)
		}
	}
	return int32(res.Status), nil
}

// ReceiveGunRequestUpgrade 获取请求固件升级响应
func (d *CounterGun) ReceiveGunRequestUpgrade() {
	res := &mavlink.GunRequestUpgradeResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveGunRequestUpgrade 获取请求固件升级响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.GunIdRequestUpgrade]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// GunVerifyImage 校验固件镜像
func (d *CounterGun) GunVerifyImage() (int32, error) {
	logger.Info("GunVerifyImage Start")
	req := &mavlink.GunVerifyImageRequest{}
	buff := req.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.GunIdVerifyImage]
	if !ok {
		manager = NewWaitTaskManager(mavlink.GunIdVerifyImage, true, 0)
		d.WaitTaskMap[mavlink.GunIdVerifyImage] = manager
	}
	task := manager.AddTask(nil, nil)

	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("GunVerifyImage 发送校验固件镜像信息失败: ", err)
		return 1, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("GunVerifyImage WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 1, checkNetConnErr
		}
		return 1, err
	}
	res := result.(*mavlink.GunVerifyImageResponse)
	logger.Debugf("GunVerifyImage 获取校验固件镜像信息结果：%#v", res)
	logger.Info("GunVerifyImage End")
	return int32(res.Status), nil
}

// ReceiveGunVerifyImage 获取校验固件镜像响应
func (d *CounterGun) ReceiveGunVerifyImage() {
	res := &mavlink.GunVerifyImageResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveGunVerifyImage 获取校验固件镜像响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.GunIdVerifyImage]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// GunRunApp 运行固件App
func (d *CounterGun) GunRunApp() (int32, error) {
	logger.Info("GunRunApp Start")
	req := &mavlink.GunRunAppRequest{}
	buff := req.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.GunIdRunApp]
	if !ok {
		manager = NewWaitTaskManager(mavlink.GunIdRunApp, true, 0)
		d.WaitTaskMap[mavlink.GunIdRunApp] = manager
	}
	task := manager.AddTask(nil, nil)

	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("GunRunApp 发送运行固件App信息失败: ", err)
		return 1, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("GunRunApp WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 1, checkNetConnErr
		}
		return 1, err
	}
	res := result.(*mavlink.GunRunAppResponse)
	logger.Debugf("GunRunApp 获取运行固件App信息结果：%#v \n", res)
	logger.Info("GunRunApp End")
	return int32(res.Status), nil
}

// ReceiveGunRunApp 获取运行固件App响应
func (d *CounterGun) ReceiveGunRunApp() {
	res := &mavlink.GunRunAppResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveGunRunApp 获取运行固件App响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.GunIdRunApp]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// GunWriteUpdateData 写入固件数据
func (d *CounterGun) GunWriteUpdateData() (int32, error) {
	logger.Info("GunWriteUpdateData Start")
	req := &mavlink.GunWriteUpdateDataRequest{}
	buff := req.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.GunIdWriteUpdateData]
	if !ok {
		manager = NewWaitTaskManager(mavlink.GunIdWriteUpdateData, true, 0)
		d.WaitTaskMap[mavlink.GunIdWriteUpdateData] = manager
	}
	task := manager.AddTask(nil, nil)

	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("GunWriteUpdateData 发送写入固件数据信息失败: ", err)
		return 1, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("GunWriteUpdateData WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 1, checkNetConnErr
		}
		return 1, err
	}
	res := result.(*mavlink.GunWriteUpdateDataResponse)
	logger.Debugf("GunWriteUpdateData 获取写入固件数据信息结果：%#v", res)
	logger.Info("GunWriteUpdateData End")
	return int32(res.Status), nil
}

// ReceiveGunWriteUpdateData 获取写入固件数据响应
func (d *CounterGun) ReceiveGunWriteUpdateData() {
	res := &mavlink.GunWriteUpdateDataResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveGunWriteUpdateData 获取写入固件数据响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.GunIdWriteUpdateData]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// GunSendUpdatePkg 发送升级固件数据
func (d *CounterGun) GunSendUpdatePkg(offset uint32, imageData []uint8) (*mavlink.GunSendUpdatePkgResponse, error) {
	logger.Info("GunSendUpdatePkg Start")
	req := &mavlink.GunSendUpdatePkgRequest{
		ImageOffset: offset,
		ImageLength: uint32(len(imageData)),
		ImageData:   imageData,
	}
	buff, err := req.Create()
	if err != nil {
		return nil, err
	}

	// 超时重发
	result, err := d.TimeOutRepeatSendBuff(buff, 3, 5*time.Second, mavlink.GunIdSendUpdatePkg)
	if err != nil {
		logger.Errorf("RadarSendUpdatePkg 获取发送升级固件数据信息结果报错：%#v", err)
		logger.Errorf("RadarSendUpdatePkg Err buff: %v", buff)
		logger.Errorf("RadarWriteUpdateData WaitTask Err %s", err.Error())
		return nil, err
	}

	res := result.(*mavlink.GunSendUpdatePkgResponse)
	logger.Debugf("GunSendUpdatePkg 获取发送升级固件数据信息结果：%#v", res)
	logger.Info("GunSendUpdatePkg End")
	return res, nil
}

// ReceiveGunSendUpdatePkg 获取发送升级固件数据响应
func (d *CounterGun) ReceiveGunSendUpdatePkg() {
	res := &mavlink.GunSendUpdatePkgResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveGunSendUpdatePkg 获取发送升级固件数据响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.GunIdSendUpdatePkg]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// GunBootToAppMod 设置是否可跳转APP
func (d *CounterGun) GunBootToAppMod() (int32, error) {
	logger.Info("GunBootToAppMod Start")
	fmt.Println("GunBootToAppMod Start")
	req := &mavlink.GunBootToAppModRequest{
		Able: 1,
	}
	buff := req.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.GunIdBootToAppMod]
	if !ok {
		manager = NewWaitTaskManager(mavlink.GunIdBootToAppMod, true, 0)
		d.WaitTaskMap[mavlink.GunIdBootToAppMod] = manager
	}
	task := manager.AddTask(nil, nil)

	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("GunBootToAppMod 发送写入固件数据信息失败: ", err)
		return 1, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("GunBootToAppMod WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 1, checkNetConnErr
		}
		return 1, err
	}
	res := result.(*mavlink.GunBootToAppModResponse)
	logger.Debugf("GunBootToAppMod 获取写入固件数据信息结果：%#v", res)
	fmt.Println("GunBootToAppMod End")
	logger.Info("GunBootToAppMod End")
	return int32(res.Status), nil
}

// ReceiveGunBootToAppMod 设置是否可跳转APP
func (d *CounterGun) ReceiveGunBootToAppMod() {
	res := &mavlink.GunBootToAppModResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveGunBootToAppMod 获取发送升级固件数据响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.GunIdBootToAppMod]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// TimeOutRepeatSendBuff 超时重发字节数据
func (d *CounterGun) TimeOutRepeatSendBuff(buff []byte, tryCount int, timeOut time.Duration, messageId int) (interface{}, error) {
	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[messageId]
	if !ok {
		manager = NewWaitTaskManager(messageId, true, timeOut)
		d.WaitTaskMap[messageId] = manager
	}
	task := manager.AddTask(nil, nil)
	if d.Conn == nil {
		manager.DeleteTask(task.TaskId)
		fmt.Println("TimeOutRepeatSendBuff device conn is nil")
		return nil, errors.New("device conn is nil")
	}
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("TimeOutRepeatSendBuff 发送信息失败: ", err)
		manager.DeleteTask(task.TaskId)
		return nil, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		// 超时重试
		if tryCount > 0 {
			tryCount--
			fmt.Println("TimeOutRepeatSendBuff tryCount: ", tryCount)
			return d.TimeOutRepeatSendBuff(buff, tryCount, timeOut, messageId)
		}
	}
	return result, err
}

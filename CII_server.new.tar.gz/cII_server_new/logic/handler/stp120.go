package handler

import (
	"adasgitlab.autel.com/tools/cuav_plugin/broker"
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/server"
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/ip"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/proto/mavlink"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
	"adasgitlab.autel.com/tools/cuav_server/repo/utils"
	"adasgitlab.autel.com/tools/slink_proto/slinkv1"
	"bytes"
	"context"
	"crypto/rand"
	"encoding/binary"
	"errors"
	"fmt"
	"golang.org/x/time/rate"
	"google.golang.org/protobuf/proto"
	"math/big"
	"sync"
	"time"
)

var (
	STP120TcpServerLock sync.Mutex
	STP120TcpServerMap  sync.Map

	Stp120HeartSum uint8 = 0
)

const (
	STP120TcpPort        = 31000
	STP120ServerMaxCount = 50
)

type STP120 struct {
	*Device
	dt common.DeviceType
	*STP120Limit
}

func NewSTP120(conn Connection, d []byte, dataLen int, remoteIp string, remotePort int, localIp string, serverPort int,
	mailBox map[int]*WaitTaskManager, dlimit *devLimit) DeviceInterface {
	stp120 := &STP120{
		Device: &Device{
			Conn:        conn,
			Msg:         d,
			MsgLen:      dataLen,
			SourceId:    d[mavlink.SenderLoc],
			RemoteIp:    remoteIp,
			RemotePort:  remotePort,
			LocalIp:     localIp,
			ServerPort:  serverPort,
			WaitTaskMap: mailBox,
		},
		STP120Limit: &STP120Limit{
			detectLimit: dlimit.stp120.detectLimit,
			hitLimit:    dlimit.stp120.hitLimit,
			heartLimit:  dlimit.stp120.heartLimit,
		},
	}
	return stp120
}

var _ DeviceIfer = (*STP120)(nil)

// SetDevice 要使用GetOnLineDev 接口，必须要给该设备实现 DeviceIfer 接口
func (di *STP120) SetDevice(d *Device) {
	di.Device = d
}

// HandleBroadCast 处理广播消息
func (d *STP120) HandleBroadCast(ctx context.Context, req *slinkv1.UdpBroadcastConfirmRequest) (*slinkv1.UdpBroadcastConfirmResponse, error) {

	if req.GetSn() == "" {
		logger.Info("device sn empty")
		return nil, errors.New("device sn empty")
	}
	d.GetStatus(req.GetSn(), int(req.DeviceType))
	logger.Debug("req.DeviceType = ", req.DeviceType)

	localIP := make([]string, 0)
	localIps, broadIps, err := ip.GetBroadcastAddress()
	if err != nil {
		logger.Error("Get IP error :%v", err)
	}
	for i, localIp := range localIps {
		if i >= len(broadIps) {
			continue
		}
		localIP = append(localIP, localIp)
	}
	logger.Debugf("[STP120] localIP:%v,", localIP)

	tcpServer := d.TcpServerCheck(req.GetSn(), localIP, uint8(req.DeviceType))
	DevSnMap.Store(tcpServer.Port, req.GetSn())
	d.ServerPort = tcpServer.Port
	var tempSn [32]byte
	for i, v := range []byte(req.GetSn()) {
		tempSn[i] = v
	}
	//响应
	rsp := &slinkv1.UdpBroadcastConfirmResponse{
		Sn:       tempSn,
		Addr:     ip.IPV4(tcpServer.Ip),
		Port:     uint16(tcpServer.Port),
		ConnType: 1,
	}
	return rsp, nil
}

func (d *STP120) TcpServerCheck(devSn string, localIP []string, devType uint8) *server.TcpServer {
	var tcpServer *server.TcpServer
	if s, ok := STP120TcpServerMap.Load(devSn); ok {
		tcpServer = s.(*server.TcpServer)
		isAlike := false
		for _, ip := range localIP {
			if ip == tcpServer.Ip {
				isAlike = true
			}
		}
		if isAlike == false { //查找的本地IP没有与之前相同的
			if tcpServer != nil {
				tcpServer.Stop()
			}
			deviceUsedPorts.Delete(tcpServer.Port)
			STP120TcpServerMap.Delete(devSn)
			DevSnMap.Delete(tcpServer.Port)
			tcpServer = nil
		}
	}

	//注册tcp服务
	if tcpServer == nil {
		port, err := ip.GetFreeTcpPort()
		if err != nil {
			logger.Error("STP120 tcp 获取可用端口失败：", err)
			port = d.getRandPort(STP120TcpPort, STP120TcpPort+STP120ServerMaxCount)
		}
		tcpServer = server.NewTcpServer(port, Handle)
		STP120TcpServerMap.Store(devSn, tcpServer)
		tcpServer.ServerType = uint8(common.DEV_STP120)
		tcpServer.ServerType = devType
		tcpServer.ServerName = devSn
		localAddr, _ := ip.GetLocalIp(d.UdpIp)
		tcpServer.Ip = localAddr
		go tcpServer.Start()
	}
	return tcpServer
}

func (d *STP120) getRandPort(min, max int64) int {
	maxBigInt := big.NewInt(max)
	i, _ := rand.Int(rand.Reader, maxBigInt)
	_, ok := deviceUsedPorts.Load(i.Int64())
	port := i.Int64()
	//缓存不存在或者符合范围
	if !ok && (port > min && port < max) {
		deviceUsedPorts.Store(port, port)
		return int(port)
	}
	return d.getRandPort(min, max)
}
func (d *STP120) GetStatus(sn string, subDevType int) int32 {
	statusRes := &client.GetStatusRes{}
	err := NewEquipList().GetStatus(context.Background(), &client.GetStatusReq{Sn: sn, EType: common.STP120, SubDevType: int64(subDevType)}, statusRes)
	if err != nil {
		logger.Errorf("GetStatus err: %v", err.Error())
		return 0
	}

	return statusRes.IsEnable
}

const (
	stp120burst      = 1  //perf me with better value @fzw
	stp120DetectRate = 10 //10Hz
	stp120HitRate    = 2  //2Hz
	stp120HeartRate  = 10 //10Hz
)

type STP120Limit struct {
	detectLimit *rate.Limiter
	hitLimit    *rate.Limiter
	heartLimit  *rate.Limiter
}

func (d *STP120) Deal() {
	defer func() {
		if err := recover(); err != nil {
			logger.Error("STP120 deal 接收到panic:", err)
		}
	}()

	if d.MsgLen <= 0 {
		logger.Error("STP120 数据为null,不作处理:", d.Device.RemoteIp)
		return
	}

	d.MsgId = int(d.Msg[mavlink.MsgIdLoc])
	switch d.MsgId {
	case mavlink.STP120HeartMsg:
		if d.heartLimit.Allow() {
			d.Heart()
		} else {
			logger.Error("speed of stp120 heartbeat is quite fast,msgid:", d.MsgId)
			heart := &mavlink.STP120Heart{}
			if err := d.UnmarshalPayload(heart); err != nil {
				logger.Errorf(err.Error())
			}
			logger.Debug("heart = ", heart)
		}
	case mavlink.STP120DetectMsg:
		if d.detectLimit.Allow() {
			d.ReceiveDetectMsg()
		} else {
			logger.Error("speed of stp120 detect is quite fast,msgid:", d.MsgId)
			result := &mavlink.Stp120Detect{}
			if err := d.UnmarshalPayloadStp120Detect(result); err != nil {
				logger.Errorf(err.Error())
			}
			logger.Debug("result = ", result)
		}
	case mavlink.Stp120SetOnOff:
		d.ReceiveSetOnOff()
	case mavlink.Stp120Reboot:
		d.ReceiveReboot()
	case mavlink.STP120GetFreqList:
		d.ReceiveGetFreqList()
	case mavlink.Stp120RealTmFreqReport:
		d.ReceiveRealTmFreqReport()
	case mavlink.Stp120SetFreqCmd:
		d.ReceiveSetFreqCmd()
	case mavlink.STP120DevStateMsg:
		d.ReceiveDevStateReport()
	case mavlink.STP120GNSSGetCmd:
		d.ReceiveGetGNSS()
	case mavlink.STP120GetVersion:
		d.ReceiveGetVersion()
	case mavlink.Stp120PerformanceEvaluate:
		d.ReceivePerformanceEvaluate()
	case mavlink.Stp120PerformanceEvaluateReport:
		d.ReportPerformanceEvaluateResult()
	case mavlink.Stp120IdUpgradeF1:
		d.ReceiveIdUpgradeF1()
	case mavlink.Stp120IdUpgradeF2:
		d.ReceiveIdUpgradeF2()
	case mavlink.Stp120IdUpgradeF3:
		d.ReceiveIdUpgradeF3()
	case mavlink.Stp120RefPerformanceEvaluate:
		d.ReceiveRefPerformanceEvaluate()
	case mavlink.Stp120RefPerformanceEvaluateReport:
		d.ReceiveRefPerformanceEvaluateReport()
	case mavlink.STP120GNSSSetCmd:
		d.ReceiveSetGNSS()
	default:
		logger.Error(" 未知消息id:", d.MsgId)
		break
	}
}
func (d *STP120) ReceiveSetGNSS() {
	logger.Info("-->into Receive stp120 reference ReceiveSetGNSS")
	res := &mavlink.Stp120GNSSSetResponse{}
	d.GetPacket(res)
	logger.Debugf("Stp120 reference STP120GNSSSetCmd：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.STP120GNSSSetCmd]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}
func (d *STP120) ReceiveIdUpgradeF3() {
	res := &mavlink.Stp120UpdateF3Response{}
	d.GetPacket(res)
	logger.Debugf("ReceiveStp120UpdateF3 获取请求固件升级响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.Stp120IdUpgradeF3]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}
func (d *STP120) ReceiveIdUpgradeF2() {
	res := &mavlink.Stp120UpdateF2Response{}
	d.GetPacket(res)
	logger.Debugf("ReceiveStp120UpdateF2 获取请求固件升级响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.Stp120IdUpgradeF2]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}
func (d *STP120) ReceiveIdUpgradeF1() {
	res := &mavlink.Stp120UpdateF1Response{}
	d.GetPacket(res)
	logger.Debugf("ReceiveStp120UpdateF1 获取请求固件升级响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.Stp120IdUpgradeF1]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *STP120) ReceiveRealTmFreqReport() {
	timeFreq := &mavlink.STp120TimeFreqData{}
	err := timeFreq.Deserialize(d.Msg)
	if err != nil {
		logger.Error("timeFreq deserialize got err: %v", err)
		return
	}
	sn := ""
	idx := bytes.IndexByte(timeFreq.SnName[:], 0)
	if idx == -1 {
		idx = len(timeFreq.SnName)
	}
	sn = string(timeFreq.SnName[:idx])
	if timeFreq.FrameIdx == 0 {
		timeFreqMap.Reset(sn)
	}
	timeFreqMap.Write(sn, timeFreq.Data)
	logger.Infof("receive STp120TimeFreqData, sn: %v, frameIdx: %v, frameNum: %v", sn, timeFreq.FrameIdx, timeFreq.FrameNum)
	if timeFreq.FrameIdx == timeFreq.FrameNum-1 {
		content := timeFreqMap.ReadAll(sn)
		logger.Infof("STp120TimeFreqData content length: %v, sn: %v", len(content), sn)
		if len(content) != 768512 {
			logger.Errorf("STp120TimeFreqData content length is not 768512, sn: %v", sn)
			return
		}
		arr := make([]int32, 0)
		for i, _ := range content {
			if i%2 == 0 {
				tmp := binary.LittleEndian.Uint16(content[i : i+2])
				arr = append(arr, int32(int16(tmp)))
			}
		}
		data := &client.Stp120TimeFreqData{
			Sn:   sn,
			Data: arr,
		}
		payload, _ := proto.Marshal(data)
		report := &client.ClientReport{
			MsgType: common.ClientMsgIdSTP120FreqData,
			Data:    payload,
		}
		out, err := proto.Marshal(report)
		if err != nil {
			logger.Error("STp120TimeFreqData marshal client report got error: %v", err)
			return
		}
		_ = mq.STP120Broker.Publish(mq.STP120Topic, broker.NewMessage(out))
		logger.Infof("send Stp120TimeFreqData to client, sn: %v", sn)
	}
}
func (d *STP120) ReceiveDetectMsg() {
	result := &mavlink.Stp120Detect{}
	if err := d.UnmarshalPayloadStp120Detect(result); err != nil {
		logger.Errorf(err.Error())
		return
	}

	devSn := ByteToString(result.Info.SN[:])
	if devSn != "" {
		d.updateStatusDetect(devSn)
		d.Stp120DetectReport(devSn, result)
	}
	logger.Info("--->End Receive Stp120 Detect")
}

func (d *STP120) GetVersion(ctx context.Context, sn string) (string, error) {
	logger.Info("-->into Send Get Version msg")
	req := &mavlink.Stp120GetVersionRequest{}
	buff := req.Create()
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request stp120 version info err: %v", err)
		return "", fmt.Errorf("request stp120 version info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.STP120GetVersion]
	if !ok {
		manager = NewWaitTaskManager(mavlink.STP120GetVersion, true, 0)
		d.WaitTaskMap[mavlink.STP120GetVersion] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request stp120 version info err: %v", checkNetConnErr)
			return "", checkNetConnErr
		}
	}
	logger.Debug("SendGetVersionInfo result = ", result)
	res, ok := result.(*mavlink.Stp120GetVersionResponse)
	if !ok {
		return "", errors.New("response err type")
	}
	logger.Debug("response stp120 version result: %+v", *res)
	if string(res.AppVersion) != "" {
		err = NewEquipList().Update(context.Background(), &client.EquipCrudReq{
			Sn:         sn,
			DevVersion: string(res.AppVersion),
		}, &client.EquipCrudRes{})
		if err != nil {
			logger.Error("Update EquipList err: ", err)
		}
	}
	return string(res.AppVersion), nil
}
func (d *STP120) SetGNSS(ctx context.Context, in *client.Stp120SetGNSSRequest) error {
	logger.Info("-->into stp120 SetGNSS msg")
	req := &mavlink.Stp120GNSSSetRequest{}
	buff := req.Create(in)
	logger.Debug("buff = ", buff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request stp120 set gnss: %v", err)
		return fmt.Errorf("request stp120 set gnss: err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.STP120GNSSSetCmd]
	if !ok {
		manager = NewWaitTaskManager(mavlink.STP120GNSSSetCmd, true, 0)
		d.WaitTaskMap[mavlink.STP120GNSSSetCmd] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Stp120 GNSS Set Req info err: %v", checkNetConnErr)
			return checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.Stp120GNSSSetResponse)
	if !ok {
		return errors.New("response err type")
	}
	logger.Debug("response stp120 GNSSSet result: %+v", *res)
	if res.Status == 0 {
		logger.Errorf("set stp120 gnss fail, status: %v", res.Status)
		return fmt.Errorf("set stp120 gnss fail")
	}
	return nil
}

func (d *STP120) GetGNSS(ctx context.Context) (*mavlink.Stp120GNSSGetResponse, error) {
	logger.Info("-->into Send STP120 STP120GNSSGetCmd hit msg")
	req := &mavlink.Stp120GNSSGetRequest{}
	buff := req.Create()
	logger.Debug("buff = ", buff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("STP120 GetGNSS info err: %v", err)
		return nil, fmt.Errorf("STP120 GetGNSS info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.STP120GNSSGetCmd]
	if !ok {
		manager = NewWaitTaskManager(mavlink.STP120GNSSGetCmd, true, 0)
		d.WaitTaskMap[mavlink.STP120GNSSGetCmd] = manager
	}

	result, err := manager.Wait()
	logger.Debug("result = ", result)
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Stp120 GetGNSS err: %v", checkNetConnErr)
			return nil, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.Stp120GNSSGetResponse)
	if !ok {
		return nil, errors.New("response err type")
	}
	logger.Debug("response Stp120 GetGNSS result:%+v", *res)
	return res, nil
}
func (d *STP120) ReceiveGetVersion() {
	logger.Info("-->into Receive stp120 Get Version")

	res := &mavlink.STP120GetVersionResponse{}

	res.AppVersion = d.Msg[mavlink.HeaderLen : len(d.Msg)-2]
	manager, ok := d.WaitTaskMap[mavlink.Stp120GetVersion]
	if ok {
		manager.CompletedTask(res, nil)
	}
	logger.Info("-->End Receive stp120 Version:", string(res.AppVersion))
	return
}
func (d *STP120) ReceiveGetGNSS() {
	logger.Info("-->into Receive STP120 Get GNNS")

	res := &mavlink.Stp120GNSSGetResponse{}
	ret := d.UnmarshalPayloadStp120GetGNSS(res)
	if ret != nil {
		logger.Debug("Receive stp120 Get GNNS ret = ", ret)
	}
	manager, ok := d.WaitTaskMap[mavlink.STP120GNSSGetCmd]
	if ok {
		manager.CompletedTask(res, nil)
	}
	logger.Info("-->End Receives GetGNNS stp120 :", res)
	return
}
func (d *STP120) UnmarshalPayloadStp120GetGNSS(data *mavlink.Stp120GNSSGetResponse) error {
	buff := &bytes.Buffer{}
	start := mavlink.HeaderLen
	end := start + int(data.Size())
	logger.Debug("start: , end: ", start, end)
	logger.Debug("d.Msg[start:end] = ", d.Msg[start:end])
	if err := binary.Write(buff, binary.LittleEndian, d.Msg[start:end]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, data); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}
	logger.Debugf("Receive UnmarshalPayload stp120 GetGNSS 接收到 STP120 信息：%#v", data)
	return nil
}

func DetectCheckInputNumOnStp120(drone *mavlink.Stp120DetectDescription) *mavlink.Stp120DetectDescription {
	if drone.DroneLongitude == InvalidValueInt32 {
		drone.DroneLongitude = 0
	}
	if drone.DroneLatitude == InvalidValueInt32 {
		drone.DroneLatitude = 0
	}
	if drone.DroneHeight == InvalidValueInt16 {
		drone.DroneHeight = 0
	}
	if drone.DroneYawAngle == InvalidValueInt16 {
		drone.DroneYawAngle = 0
	}
	if drone.DroneSpeed == InvalidValueInt16 {
		drone.DroneSpeed = 0
	}
	if drone.DroneVerticalSpeed == InvalidValueInt16 {
		drone.DroneVerticalSpeed = 0
	}
	if drone.DroneSailLongitude == InvalidValueInt32 {
		drone.DroneSailLongitude = 0
	}
	if drone.DroneSailLatitude == InvalidValueInt32 {
		drone.DroneSailLatitude = 0
	}
	if drone.PilotLongitude == InvalidValueInt32 {
		drone.PilotLongitude = 0
	}
	if drone.PilotLatitude == InvalidValueInt32 {
		drone.PilotLatitude = 0
	}
	if drone.DroneHorizon == InvalidValueInt32 {
		drone.DroneHorizon = -1
	}
	if drone.DronePitch == InvalidValueInt32 {
		drone.DronePitch = -1
	}
	if drone.UDistance == InvalidValueInt16 {
		drone.UDistance = 0
	}
	if drone.UDangerLevels == InvalidValueInt16 {
		drone.UDangerLevels = 0
	}
	if drone.UFreq == InvalidValueInt32 {
		drone.UFreq = 0
	}
	return drone
}

func (d *STP120) Stp120DetectReport(devSn string, detectInfo *mavlink.Stp120Detect) {
	dataInfo := &client.Stp120DetectSocketInfo{}
	dataInfo.List = make([]*client.Stp120DetectDroneInfo, 0, len(detectInfo.Description))
	dataInfo.Sn = devSn
	dataInfo.DetectionNum = int32(detectInfo.Info.DetectionNum)
	//查白名单中的无人机，在Tracer侦测结果中添加无人机角色
	whiteList := &client.ListResAll{}
	err := NewWhiteList().ListAll(context.Background(), &client.ListReqAll{}, whiteList)
	if err != nil {
		logger.Error("Get whiteList err: ", err)
		return
	}

	var dstDetectItems []*client.Stp120DetectDroneInfo
	//检查无效值
	for _, drone := range detectInfo.Description {
		if drone.Source == 0 {
			drone = DetectCheckInputNumOnStp120(drone)
			//1-敌军 2-友军 3-未知 4-中立     批量导入为2友军
			var role int32
			for _, info := range whiteList.WhiteList {
				if info.Sn == ByteToString(drone.SerialNum[:]) && info.Sn != "" {
					role = info.Role
				}
			}
			if role == ERRTYPE {
				role = ENEMY
			}

			var wifiMac [6]uint8
			wifiMac = drone.WifiMac
			wifiMacBytes := make([]byte, len(wifiMac))
			for i, v := range wifiMac {
				wifiMacBytes[i] = v
			}

			r := &client.Stp120DetectDroneInfo{
				ProductType:        int32(drone.ProductType),
				DroneName:          ByteToString(drone.DroneName[:]),
				SerialNum:          ByteToString(drone.SerialNum[:]),
				DroneLongitude:     float64(drone.DroneLongitude) / DroneTion,
				DroneLatitude:      float64(drone.DroneLatitude) / DroneTion,
				DroneHeight:        float64(drone.DroneHeight) / DroneHeightTion,
				DroneYawAngle:      float64(drone.DroneYawAngle) / DroneYawTion,
				DroneSpeed:         float64(drone.DroneSpeed) / DroneSpeedTion,
				DroneVerticalSpeed: float64(drone.DroneVerticalSpeed) / DroneVerticalSpeedTion,
				SpeedDirection:     int32(drone.SpeedDerection) / DroneSpeedTion,
				DroneSailLongitude: float64(drone.DroneSailLongitude) / DroneSailLongitudeTion,
				DroneSailLatitude:  float64(drone.DroneSailLatitude) / DroneSailLatitudeTion,
				PilotLongitude:     float64(drone.PilotLongitude) / DroneTion,
				PilotLatitude:      float64(drone.PilotLatitude) / DroneTion,
				DroneHorizon:       float64(drone.DroneHorizon) / DroneHorizonTion,
				DronePitch:         float64(drone.DronePitch) / DronePitch,
				UFreq:              float64(drone.UFreq) / DetectFreqTion,
				UDistance:          int32(drone.UDistance),
				UDangerLevels:      int32(drone.UDangerLevels),
				Role:               role,
				UZC:                int32(drone.Uzc),
				UDirStatus:         int32(drone.UDirStatus),
				UNumber:            uint32(drone.UNumber),
				GpsClocks:          drone.GpsClocks,
				TimeStampRid:       drone.TimestampRid,
				IdType:             uint32(drone.IdType),
				WifiMac:            wifiMacBytes,
				FlagTime:           drone.FlagTime,
			}

			r.DroneName = common.ConstructDroneName(r.DroneName, r.SerialNum, r.UNumber)
			logger.Debugf("GimbalCounterDetectDroneInfo : r = %+v", r)
			//过滤频谱数据
			if r.SerialNum != "" && role != FRIEND {
				//计算无人机威胁等级
				fd, err := NewAlarmControl().GetDroneThreatLevel(&GetThreatLevelReq{
					DroneSn:        r.SerialNum,
					DroneObjId:     0,
					DroneLongitude: r.DroneLongitude,
					DroneLatitude:  r.DroneLatitude,
					DevSn:          devSn,
				})
				if err != nil {
					logger.Errorf("STP120 DetectReport GetDroneThreatLevel err: %v", err)
				} else {
					r.AlarmId = fd.AlarmId
					r.EventId = fd.EventId
					r.ThreatLevel = fd.ThreatLevel
					r.ScenesId = fd.ScenesId
				}
			}

			logger.Infof("STP120 Detect data: %v", r)
			dataInfo.List = append(dataInfo.List, r)
			dstDetectItems = append(dstDetectItems, r)
		}
	}

	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	msg := &client.Stp120DetectInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        devSn,
			EquipType: int32(common.DEV_STP120),
			MsgType:   mavlink.STP12DetectMsgReport,
		},
		Data: dataInfo,
	}
	if err == nil {
		msg.Header.ParentType = int32(equipModel.ParentType)
		msg.Header.ParentSn = equipModel.ParentSn
		msg.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msgOut, err := proto.Marshal(msg)
	if err != nil {
		logger.Error("marshal msg err:", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIDSTP120Detect,
		Data:    msgOut,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	_ = mq.STP120Broker.Publish(mq.STP120Topic, broker.NewMessage(out))
	logger.Infof("Stp120 Detect has reported, devSn: %v, Drone size: %v", devSn, msg.Data)
}
func (d *STP120) UnmarshalPayloadStp120Detect(data *mavlink.Stp120Detect) error {
	deviceInfoLen := binary.Size(mavlink.Stp120DetectInfo{})
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}

	start := mavlink.HeaderLen + deviceInfoLen
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializeDrone(d.Msg[start:end]); err != nil {
		return err
	}

	return nil
}

func (d *STP120) updateStatusDetect(sn string) int32 {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_STP120, sn)
	if cache, ok := DevStatusMap.Load(cacheKey); ok {
		dev := cache.(*Device)
		dev.Status = common.DevOnline
		dev.Conn = d.Conn
		dev.WaitTaskMap = d.WaitTaskMap
		dev.RemoteIp = d.RemoteIp
		dev.LastHeartTime = time.Now()
		dev.GetStatusInterval = time.Now()
		return common.DeviceEnable
	} else {
		dev := &Device{
			Sn:                sn,
			Conn:              d.Conn,
			Status:            common.DevOnline,
			RemoteIp:          d.RemoteIp,
			RemotePort:        d.RemotePort,
			LocalIp:           d.LocalIp,
			ServerPort:        d.ServerPort,
			DevType:           common.DEV_STP120,
			FirstHeartTime:    time.Now(),
			LastHeartTime:     time.Now(),
			SourceId:          d.SourceId,
			IsEnable:          common.DeviceEnable,
			GetStatusInterval: time.Now(),
			WaitTaskMap:       d.WaitTaskMap,
		}
		DevStatusMap.Store(cacheKey, dev)
		go func() {
			time.Sleep(time.Second * 2)
			e := NewEquipList().Update(context.Background(), &client.EquipCrudReq{
				Sn: sn,
				Ip: d.RemoteIp,
			}, &client.EquipCrudRes{})
			logger.Infof("update dev ip: %v, e: %v", d.RemoteIp, e)

			if d.Conn == nil {
				return
			}
			appVer, err := d.SendGetVersionInfo(sn)
			logger.Infof("stp120 get  Ver: %v", appVer)
			if err != nil {
				logger.Infof("stp120 get  Ver runVer: %v err: %v \n", appVer, err)
				return
			}
			if appVer != "" {
				err = NewEquipList().Update(context.Background(), &client.EquipCrudReq{
					Sn:         sn,
					DevVersion: appVer,
				}, &client.EquipCrudRes{})
				if err != nil {
					logger.Error("Update EquipList err: ", err)
				}
			}
		}()
		return dev.IsEnable
	}
}

// Heart 处理Stp120心跳消息
func (d *STP120) Heart() {
	heart := &mavlink.STP120Heart{}
	if err := d.UnmarshalPayload(heart); err != nil {
		logger.Errorf(err.Error())
		return
	}

	devSn := ByteToString(heart.Info.Sn[:])
	if devSn != "" {
		// update device status
		d.updateOnLineStatus(devSn, heart)
		d.updateStatus(devSn, int(heart.Info.DevSubId))
		d.HeartReport(devSn, heart)
	}
}

func (d *STP120) HeartReport(devSn string, heartInfo *mavlink.STP120Heart) {
	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	dataInfo := &client.Stp120HeartInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        devSn,
			EquipType: int32(common.DEV_STP120),
			MsgType:   mavlink.STP120HeartMsgReport,
		},
		Data: &client.Stp120HeartInfoData{
			Sn:              devSn,
			TimeStamp:       int32(heartInfo.Info.TimeStamp),
			WorkStatus:      int32(heartInfo.Info.WorkStatus),
			IsOnline:        common.DevOnline,
			HitFreq:         int32(heartInfo.Info.HitFreq),
			DetectFreq:      float64(heartInfo.Info.DetectFreq) / DetectFreqTion,
			Elevation:       float64(heartInfo.Info.Elevation) / ElevationTion,
			GunDirection:    float64(heartInfo.Info.GunDirection) / GunDirectTion,
			GunLongitude:    float64(heartInfo.Info.GunLongitude) / GunLongitudeTion,
			GunLatitude:     float64(heartInfo.Info.GunLatitude) / GunLatitudeTion,
			GunAltitude:     float64(heartInfo.Info.GunAltitude),
			SatellitesNum:   int32(heartInfo.Info.SatellitesNum),
			FaultLevel:      int32(heartInfo.Info.FaultLevel),
			CtrlFault:       int32(heartInfo.Info.CtrlFault),
			AeagFault:       int32(heartInfo.Info.AeagFault),
			TracerFault:     int32(heartInfo.Info.TracerFault),
			WorkStatusParam: int32(heartInfo.Info.WorkStatusParam),
			DevSubId:        int32(heartInfo.Info.DevSubId),
		},
	}
	if err == nil {
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgIDSTP120HeartBeat,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.STP120Broker.Publish(mq.STP120Topic, broker.NewMessage(out))

	logger.Infof("Stp120 heartbeat has reported, devSn:%v,report:%v", devSn, dataInfo.Data)
}

func (d *STP120) updateStatus(sn string, subDevType int) int32 {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_STP120, sn)
	if cache, ok := DevStatusMap.Load(cacheKey); ok {
		dev := cache.(*Device)
		dev.Status = common.DevOnline
		dev.Conn = d.Conn
		dev.WaitTaskMap = d.WaitTaskMap
		dev.RemoteIp = d.RemoteIp
		dev.LastHeartTime = time.Now()
		dev.GetStatusInterval = time.Now()
		d.GetStatus(sn, subDevType)
		return common.DeviceEnable
	} else {
		dev := &Device{
			Sn:                sn,
			Conn:              d.Conn,
			Status:            common.DevOnline,
			RemoteIp:          d.RemoteIp,
			RemotePort:        d.RemotePort,
			LocalIp:           d.LocalIp,
			ServerPort:        d.ServerPort,
			DevType:           common.DEV_STP120,
			FirstHeartTime:    time.Now(),
			LastHeartTime:     time.Now(),
			SourceId:          d.SourceId,
			IsEnable:          d.GetStatus(sn, subDevType),
			GetStatusInterval: time.Now(),
			WaitTaskMap:       d.WaitTaskMap,
		}
		DevStatusMap.Store(cacheKey, dev)
		go func() {
			time.Sleep(time.Second * 2)
			e := NewEquipList().Update(context.Background(), &client.EquipCrudReq{
				Sn: sn,
				Ip: d.RemoteIp,
			}, &client.EquipCrudRes{})
			logger.Infof("update dev ip: %v, e: %v", d.RemoteIp, e)

			appVer, err := d.SendGetVersionInfo(sn)
			logger.Infof("STP120 get  Ver: %v", appVer)
			if err != nil {
				logger.Infof("STP120 get  Ver runVer: %v err: %v \n", appVer, err)
				return
			}
			if appVer != "" {
				err = NewEquipList().Update(context.Background(), &client.EquipCrudReq{
					Sn:         sn,
					DevVersion: appVer,
					IsOnline:   true,
				}, &client.EquipCrudRes{})
				if err != nil {
					logger.Error("Update EquipList err: ", err)
				}
			}
		}()
		return dev.IsEnable
	}
}

func (d *STP120) SendGetVersionInfo(sn string) (string, error) {
	logger.Info("-->into Send Get Version msg")
	req := &mavlink.STP120GetVersionRequest{}
	buff := req.Create()
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request stp120 version info err: %v", err)
		return "", fmt.Errorf("request stp120 version info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.STP120GetVersion]
	if !ok {
		manager = NewWaitTaskManager(mavlink.STP120GetVersion, true, 0)
		d.WaitTaskMap[mavlink.STP120GetVersion] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request stp120 version info err: %v", checkNetConnErr)
			return "", checkNetConnErr
		}
	}
	logger.Debug("SendGetVersionInfo result = ", result)
	res, ok := result.(*mavlink.STP120GetVersionResponse)
	if !ok {
		return "", errors.New("response err type")
	}
	logger.Debug("response stp120 version result:%+v", *res)
	if string(res.AppVersion) != "" {
		err = NewEquipList().Update(context.Background(), &client.EquipCrudReq{
			Sn:         sn,
			DevVersion: string(res.AppVersion),
		}, &client.EquipCrudRes{})
		if err != nil {
			logger.Error("Update EquipList err: ", err)
		}
	}
	return string(res.AppVersion), nil
}
func (d *STP120) updateOnLineStatus(sn string, heartInfo *mavlink.STP120Heart) int32 {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_STP120, sn)
	if cache, ok := DevStatusMapOnEvent.Load(cacheKey); ok {
		dev := cache.(*Device)
		dev.Status = common.DevOnline
		dev.LastHeartTime = time.Now()
		dev.GetStatusInterval = time.Now()
		return common.DeviceEnable
	}

	dev := &Device{
		Sn:                sn,
		Status:            common.DevOnline,
		RemoteIp:          d.RemoteIp,
		RemotePort:        d.RemotePort,
		LocalIp:           d.LocalIp,
		ServerPort:        d.ServerPort,
		DevType:           common.DEV_STP120,
		FirstHeartTime:    time.Now(),
		LastHeartTime:     time.Now(),
		SourceId:          d.SourceId,
		IsEnable:          common.DeviceEnable,
		GetStatusInterval: time.Now(),
		SessionId:         GetGlobalSessionId(),
	}
	DevStatusMapOnEvent.Store(cacheKey, dev)

	go func() {
		equipModel, err := GetEquipBySn(sn)
		name := sn
		if equipModel != nil && equipModel.Name != "" {
			name = equipModel.Name
		}
		dataInfo := &client.Stp120HeartInfo{
			Header: &client.EquipmentMessageBoxEntity{
				Name:      name,
				Sn:        sn,
				EquipType: int32(common.DEV_STP120),
				MsgType:   mavlink.STP120EventMsgOnline,
			},
			Data: &client.Stp120HeartInfoData{
				Sn:           sn,
				EventId:      utils.GetEventId(dev.SessionId),
				GunLatitude:  float64(heartInfo.Info.GunLatitude) / GunLatitudeTion,
				GunLongitude: float64(heartInfo.Info.GunLongitude) / GunLongitudeTion,
			},
		}
		if err == nil {
			dataInfo.Header.ParentType = int32(equipModel.ParentType)
			dataInfo.Header.ParentSn = equipModel.ParentSn
			dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
		}
		msg, err := proto.Marshal(dataInfo)
		if err != nil {
			logger.Error("marshal dataInfo err:", err)
			return
		}

		report := &client.ClientReport{
			MsgType: common.ClientMsgSTP120StatusEventData,
			Data:    msg,
		}
		out, err := proto.Marshal(report)
		if err != nil {
			logger.Error("marshal report err:", err)
			return
		}

		_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
		logger.Infof("STP120 heartbeat event has reported, devSn: %v,report:%v", sn, dataInfo.Data)
	}()
	return common.DeviceEnable

}
func (d *STP120) UnmarshalPayload(data *mavlink.STP120Heart) error {
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("STP120 UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("STP120 UnmarshalPayload read data err: %v", err)
	}

	return nil
}

// STP120OfflineReport STP120 离线处理; TODO:
func STP120OfflineReport(sn string) {
	var tcpServer *server.TcpServer
	if s, ok := STP120TcpServerMap.Load(sn); ok {
		tcpServer = s.(*server.TcpServer)

		if tcpServer != nil {
			tcpServer.Stop()
		}
		deviceUsedPorts.Delete(tcpServer.Port)
		STP120TcpServerMap.Delete(sn)
		DevSnMap.Delete(tcpServer.Port)
		cachekeyDroneid := fmt.Sprintf("%d_%s", common.DEV_STP120, sn)
		DevStatusMap.Delete(cachekeyDroneid)
		tcpServer = nil
	}

	equipModel, err := GetEquipBySn(sn)
	name := sn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	dataInfo := &client.SvhHeartInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        sn,
			EquipType: int32(common.DEV_STP120),
			MsgType:   mavlink.SVHHeartMsg,
		},
		Data: &client.SvhHeartInfoData{
			Sn:       sn,
			IsOnline: common.DevOffline,
		},
	}
	if err == nil {
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: mavlink.STP120HeartMsgReport,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}
	_ = mq.STP120Broker.Publish(mq.STP120Topic, broker.NewMessage(out))
	logger.Info("svh Offline report:", report)

}

func (d *STP120) SendExtHeartbeat() error {
	Stp120HeartSum++
	if Stp120HeartSum > 255 {
		Stp120HeartSum = 0
	}
	req := &mavlink.Stp120HeartbeatExtRequest{
		Stp120HeartSum,
	}
	reqBuff := req.CreateStp120HeartbeatExt()
	if d != nil && d.Conn != nil {
		_, err := d.Conn.Write(reqBuff)
		logger.Infof("Stp120 c2发送心跳结果：%X", reqBuff)
		if err != nil {
			equipModel, err := GetEquipBySn(d.Sn)
			name := d.Sn
			if equipModel != nil && equipModel.Name != "" {
				name = equipModel.Name
			}
			dataInfo := &client.Stp120HeartInfo{
				Header: &client.EquipmentMessageBoxEntity{
					Name:      name,
					Sn:        d.Sn,
					EquipType: int32(common.DEV_STP120),
					MsgType:   mavlink.STP120HeartMsgReport,
				},
				Data: &client.Stp120HeartInfoData{
					Sn:       d.Sn,
					IsOnline: common.DevOffline,
				},
			}
			if err == nil {
				dataInfo.Header.ParentType = int32(equipModel.ParentType)
				dataInfo.Header.ParentSn = equipModel.ParentSn
				dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
			}
			msg, err := proto.Marshal(dataInfo)
			if err != nil {
				logger.Error("marshal dataInfo err:", err)
				return err
			}
			report := &client.ClientReport{
				MsgType: common.ClientMsgIDSTP120HeartBeat,
				Data:    msg,
			}
			out, err := proto.Marshal(report)
			if err != nil {
				logger.Error("marshal report err:", err)
				return err
			}
			_ = mq.STP120Broker.Publish(mq.STP120Topic, broker.NewMessage(out))
			logger.Info("stp120 Offline report:", report)
		}
		return err
	}
	return nil
}
func (d *STP120) SwitchOn(ctx context.Context, on int32) error {
	devOn := uint8(0x0A)

	if on == 1 {
		devOn = 0x0A
	} else if on == 2 {
		devOn = 0xF5
	} else {
		logger.Errorf("on: %v is not support")
		return fmt.Errorf("on: %v is not support", on)
	}

	req := &mavlink.Stp120SetOnOffRequest{}
	buff := req.Create(devOn)

	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request stp120 On Off info err: %v", err)
		return fmt.Errorf("request stp120 On Off info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.Stp120SetOnOff]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Stp120SetOnOff, true, 0)
		d.WaitTaskMap[mavlink.Stp120SetOnOff] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Stp120 On Off info err: %v", checkNetConnErr)
			return checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.Stp120SetOnOffResponse)
	if !ok {
		return errors.New("response err type")
	}
	logger.Debug("response stp120 On Off result:%+v", *res)
	if res.Status == 1 {
		return nil
	} else {
		return fmt.Errorf("response status fail, %v", res.Status)
	}
}
func (d *STP120) Reboot(ctx context.Context, reboot int32) error {
	req := &mavlink.Stp120RebootRequest{}
	buff := req.Create(uint8(reboot))

	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request stp120 reboot info err: %v", err)
		return fmt.Errorf("request stp120 reboot info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.Stp120Reboot]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Stp120Reboot, true, 0)
		d.WaitTaskMap[mavlink.Stp120Reboot] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Stp120 On Off info err: %v", checkNetConnErr)
			return checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.Stp120RebootResponse)
	if !ok {
		return errors.New("response err type")
	}
	logger.Debug("response stp120 reboot result:%+v", *res)
	if res.Status == 1 {
		return nil
	} else {
		return fmt.Errorf("response status fail, %v", res.Status)
	}
}
func (d *STP120) ReceiveReboot() {
	logger.Info("-->into Receive Stp120 reboot")
	res := &mavlink.Stp120SetOnOffResponse{}
	d.GetPacket(res)
	logger.Debugf("Stp120 reboot 接收到Stp120信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.Stp120Reboot]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}
func (d *STP120) ReceiveGetFreqList() {
	res := &mavlink.Stp120FreqDetectNodeListResponse{}
	if err := d.UnmarshalFreqDetectNodeList(res); err != nil {
		logger.Errorf("parse freq detect node list response fail, e: %v", err)
		return
	}
	logger.Debugf("receive Send FreqDetectNodeList：%+v", *res)
	manager, ok := d.WaitTaskMap[mavlink.STP120GetFreqList]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *STP120) UnmarshalFreqDetectNodeList(data *mavlink.Stp120FreqDetectNodeListResponse) error {
	buf := new(bytes.Buffer)
	if e := binary.Write(buf, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); e != nil {
		return fmt.Errorf("parse Stp120FreqDetectNodeListResponse fail, e: %v", e)
	}

	if e := binary.Read(buf, binary.LittleEndian, &data.FreqNums); e != nil {
		return fmt.Errorf("parse Stp120FreqDetectNodeListResponse.freqNums fail, e: %v", e)
	}

	if data.FreqNums <= 0 {
		return nil
	}

	start := mavlink.HeaderLen + binary.Size(data.FreqNums)
	end := d.MsgLen - mavlink.CrcLen
	buffer2 := new(bytes.Buffer)
	if e := binary.Write(buffer2, binary.LittleEndian, d.Msg[start:end]); e != nil {
		return fmt.Errorf("parse Stp120FreqDetectNodeListResponse fail, e: %v", e)
	}
	for i := 0; i < int(data.FreqNums); i++ {
		var freqValue uint32 = 0
		if err := binary.Read(buffer2, binary.LittleEndian, &freqValue); err != nil {
			return fmt.Errorf("parse freq node list value fail, e: %v", err)
		}
		data.FreqList = append(data.FreqList, freqValue)
	}
	return nil
}

func (d *STP120) ReceiveSetOnOff() {
	logger.Info("-->into Receive Stp120 SetOnOff")
	res := &mavlink.Stp120SetOnOffResponse{}
	d.GetPacket(res)
	logger.Debugf("Stp120 Set OnOff  接收到stp120信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.Stp120SetOnOff]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *STP120) GetFreqNodeList(status uint8) ([]uint32, error) {
	logger.Info("---> Send stp120 GetDetectFreqList")

	req := &mavlink.Stp120FreqDetectNodeListRequest{}
	buff := req.Create(0)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.STP120GetFreqList]
	if !ok {
		manager = NewWaitTaskManager(mavlink.STP120GetFreqList, true, 0)
		d.WaitTaskMap[mavlink.STP120GetFreqList] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Send Send stp120 GetFreqNodeList is :[% x]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send Send stp120 GetFreqNodeList err:[%v].Buff is [% x]", err, buff)
		return nil, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send Send sto120 GetFreqNodeList err %s", err.Error())
		return nil, err
	}
	res := result.(*mavlink.Stp120FreqDetectNodeListResponse)
	logger.Info("-->End GetFreqNodeList")
	return res.FreqList, nil
}

func (d *STP120) SetFreqCmd(in *client.DeviceSetFreqCmdRequest) error {
	logger.Info("-->into SetFreqCmd on stp120")
	req := &mavlink.Stp120SetFreqCmdRequest{}
	buff := req.Create(uint32(in.GetMode()), uint32(in.GetFreq()))

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.Stp120SetFreqCmd]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Stp120SetFreqCmd, true, 0)
		d.WaitTaskMap[mavlink.Stp120SetFreqCmd] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Send SetFreqCmd is :[% x]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send SetFreqCmd err:[%v].Buff is [% x]", err, buff)
		return err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send SetFreqCmd err %s", err.Error())
		return err
	}
	res := result.(*mavlink.Stp120SetFreqCmdResponse)
	logger.Info("-->End SetFreqCmd: ", *res)

	if res.Status == 0 {
		return fmt.Errorf("res status fail: %v", res.Status)
	}
	return nil
}
func (d *STP120) ReceiveSetFreqCmd() {
	logger.Info("-->into Receive stp120 freq cmd")
	res := &mavlink.Stp120SetFreqCmdResponse{}
	d.GetPacket(res)
	logger.Debugf("Stp120 freq cmd ：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.Stp120SetFreqCmd]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}
func (d *STP120) ReceiveDevStateReport() {
	devState := &mavlink.Stp120DevState{}
	if err := d.UnmarshalPayloadDevStateMsg(devState); err != nil {
		logger.Errorf(err.Error())
		return
	}

	devSn := ByteToString(devState.Info.Sn[:])
	if devSn != "" {
		// update device status
		d.updateStatus(devSn, 0)
		d.DevStateReport(devSn, devState)
	}
}

func (d *STP120) ReferencePerformanceEvaluate(ctx context.Context, in *client.PerformanceEvaluateReferenceRequest) error {
	logger.Info("-->into reference PerformanceEvaluate on stp120")
	req := &mavlink.Stp120ReferencePerformanceEvaluateRequest{}
	buff := req.Create(in)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.Stp120RefPerformanceEvaluate]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Stp120RefPerformanceEvaluate, true, 0)
		d.WaitTaskMap[mavlink.Stp120RefPerformanceEvaluate] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Send reference PerformanceEvaluate is :[% x]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send reference PerformanceEvaluate err:[%v].Buff is [% x]", err, buff)
		return err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send reference PerformanceEvaluate err %s", err.Error())
		return err
	}
	res := result.(*mavlink.Stp120ReferencePerformanceEvaluateResponse)
	logger.Info("-->End reference PerformanceEvaluate: ", *res)

	if res.Status == 0 {
		return fmt.Errorf("res status fail: %v", res.Status)
	}
	return nil

}
func (d *STP120) ReceiveRefPerformanceEvaluate() {
	logger.Info("-->into Receive stp120 reference PerformanceEvaluate")
	res := &mavlink.Stp120ReferencePerformanceEvaluateResponse{}
	d.GetPacket(res)
	logger.Debugf("Stp120 reference PerformanceEvaluate：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.Stp120RefPerformanceEvaluate]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}
func (d *STP120) PerformanceEvaluate(ctx context.Context, in *client.EnvBaseNoiseRequest) error {
	logger.Info("-->into PerformanceEvaluate on stp120")
	req := &mavlink.Stp120PerformanceEvaluateRequest{}
	buff := req.Create(in)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.Stp120PerformanceEvaluate]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Stp120PerformanceEvaluate, true, 0)
		d.WaitTaskMap[mavlink.Stp120PerformanceEvaluate] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Send PerformanceEvaluate is :[% x]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send PerformanceEvaluate err:[%v].Buff is [% x]", err, buff)
		return err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send PerformanceEvaluate err %s", err.Error())
		return err
	}
	res := result.(*mavlink.Stp120PerformanceEvaluateResponse)
	logger.Info("-->End PerformanceEvaluate: ", *res)

	if res.Status == 0 {
		return fmt.Errorf("res status fail: %v", res.Status)
	}
	return nil
}
func (d *STP120) ReceivePerformanceEvaluate() {
	logger.Info("-->into Receive stp120 PerformanceEvaluate")
	res := &mavlink.Stp120PerformanceEvaluateResponse{}
	d.GetPacket(res)
	logger.Debugf("Stp120 PerformanceEvaluate：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.Stp120PerformanceEvaluate]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *STP120) ReportPerformanceEvaluateResult() {
	logger.Debugf("stp120 report performance evaluate result")
	evaluateResult := new(mavlink.Stp120PerformanceEvaluateReportData)
	if err := d.UnmarshalPayloadEnv(evaluateResult); err != nil {
		logger.Errorf("unmarshal env noise fail, err: %v", err)
		return
	}

	devSn := ByteToString(evaluateResult.Info.Sn[:])
	if len(devSn) > 0 {
		d.updateStatus(devSn, 0)
		d.NoiseEnvEvaluateReport(devSn, evaluateResult)
	}
}
func (d *STP120) ReceiveRefPerformanceEvaluateReport() {
	logger.Debugf("stp120 report reference performance evaluate result")
	evaluateResult := new(mavlink.Stp120RefPerformanceEvaluateReportData)
	if err := d.UnmarshalPayloadRef(evaluateResult); err != nil {
		logger.Errorf("unmarshal reference performance evaluate fail, err: %v", err)
		return
	}

	devSn := ByteToString(evaluateResult.Info.Sn[:])
	if len(devSn) > 0 {
		d.updateStatus(devSn, 0)
		d.RefPerformanceElvReport(devSn, evaluateResult)
	}
}

func (d *STP120) RefPerformanceElvReport(devSn string, data *mavlink.Stp120RefPerformanceEvaluateReportData) {
	if data == nil {
		return
	}

	retRefItems := new(client.ReferencePerformanceReport)
	retRefItems.Sn = devSn

	for i := 0; i < int(data.Info.ItemNums); i++ {
		refItem := data.RefPerformanceItems[i]
		if refItem == nil {
			continue
		}

		reportRefItem := &client.ReferencePerformanceReportItem{
			DetectType: int32(refItem.DetectionType),
			ReferenceValue: &client.ReferencePerformanceEvaItem{
				MinDistance:          refItem.MinDistance,
				MaxDistance:          refItem.MaxDistance,
				ReferenceMinDistance: refItem.RefMinDistance,
				ReferenceMaxDistance: refItem.RefMaxDistance,
			},
		}
		retRefItems.ItemList = append(retRefItems.ItemList, reportRefItem)
	}

	msg, err := proto.Marshal(retRefItems)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgIdSTP120PerformanceEvtRefReport,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.STP120Broker.Publish(mq.STP120Topic, broker.NewMessage(out))
	logger.Infof("stp120  reference performance evaluate has reported, devSn: %v, report: %+v", devSn, retRefItems.ItemList)
}

func (d *STP120) NoiseEnvEvaluateReport(devSn string, data *mavlink.Stp120PerformanceEvaluateReportData) {
	if data == nil {
		return
	}

	detectTypDetail := make(map[int32][]*client.EnvBaseNoiseItem)
	for i := 0; i < int(data.Info.NoiseDetailNums); i++ {
		noiseDetailItem := data.NoiseDetailItems[i]
		if noiseDetailItem == nil {
			continue
		}

		listNoiseItems := detectTypDetail[int32(noiseDetailItem.DetectionType)]
		listNoiseItems = append(listNoiseItems, &client.EnvBaseNoiseItem{
			Freq:        float32(noiseDetailItem.Freq),
			MinDistance: noiseDetailItem.MinDistance,
			MaxDistance: noiseDetailItem.MaxDistance,
		})
		detectTypDetail[int32(noiseDetailItem.DetectionType)] = listNoiseItems
	}

	var dataInfo *client.EnvBaseNoiseDetail = new(client.EnvBaseNoiseDetail)
	dataInfo.Sn = devSn
	for detectType, item := range detectTypDetail {
		var noiseDetectType *client.EnvBaseNoiseOnDetectType = new(client.EnvBaseNoiseOnDetectType)
		noiseDetectType.DetectType = detectType
		noiseDetectType.NoiseList = item

		dataInfo.DetailList = append(dataInfo.DetailList, noiseDetectType)
	}

	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgIdSTP120PerformanceEvtReport,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.STP120Broker.Publish(mq.STP120Topic, broker.NewMessage(out))

	logger.Infof("stp120  noise env evaluate has reported, devSn: %v, report: %+v", devSn, dataInfo.DetailList)
}

func (d *STP120) UnmarshalPayloadEnv(data *mavlink.Stp120PerformanceEvaluateReportData) error {
	evaInfoLen := binary.Size(mavlink.Stp120PerformanceEvaluateInfo{})
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}
	if data.Info.NoiseDetailNums <= 0 {
		logger.Debugf("noise detail nums is 0")
		return nil
	}

	// 解析： NoiseDetailItems, 类型： []*EnvBaseNoiseOnDetectType
	start := mavlink.HeaderLen + evaInfoLen
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializeNoiseDetailItems(d.Msg[start:end]); err != nil {
		return err
	}
	return nil
}
func (d *STP120) UnmarshalPayloadRef(data *mavlink.Stp120RefPerformanceEvaluateReportData) error {
	evaInfoLen := binary.Size(mavlink.Stp120RefPerformanceEvaluateInfo{})
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}
	if data.Info.ItemNums <= 0 {
		logger.Debugf("referance detail nums is 0")
		return nil
	}

	start := mavlink.HeaderLen + evaInfoLen
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializeRefPerformanceEvlDetailItems(d.Msg[start:end]); err != nil {
		return err
	}
	return nil
}

func (d *STP120) DevStateReport(devSn string, devStateInfo *mavlink.Stp120DevState) {
	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	dataInfo := &client.Stp120DevStateInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        devSn,
			EquipType: int32(common.DEV_STP120),
			MsgType:   mavlink.STP120DevStateMsg,
		},
		Data: &client.Stp120DevStateInfoData{
			Sn:              devSn,
			TimeStamp:       int64(devStateInfo.Info.TimeStamp),
			SportState:      int32(devStateInfo.Info.SportState),
			GpsState:        int32(devStateInfo.Info.GPSState),
			GpsSateliteNum:  int32(devStateInfo.Info.GPSSateliteNum),
			DGpsState:       int32(devStateInfo.Info.DGPSState),
			DGpsSateliteNum: int32(devStateInfo.Info.DGPSSateliteNum),
			DGpsRaw:         devStateInfo.Info.DGPSRaw,
			CpuTemperature:  devStateInfo.Info.CPUTemperature,
			CoreTemperature: devStateInfo.Info.CoreTemperature,
			Amp1Temperature: devStateInfo.Info.Amp1Temperature,
			Amp2Temperature: devStateInfo.Info.Amp2Temperature,
		},
	}
	if err == nil && equipModel != nil {
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgIdSTP120DevStateE0,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.STP120Broker.Publish(mq.STP120Topic, broker.NewMessage(out))
	logger.Infof("stp120 devState Info has reported, devSn:%v,report:%v", devSn, dataInfo.Data)
}

func (d *STP120) UnmarshalPayloadDevStateMsg(data *mavlink.Stp120DevState) error {
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("Stp120 UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("Stp120 UnmarshalPayload read data err: %v", err)
	}

	return nil
}

func (d *STP120) GetPacket(message mavlink.Message) *mavlink.MavPacket {
	logger.Infof("Stp120 GetPacket is [% x]", d.Msg)
	req := mavlink.NewNullPacket(message)
	buff := &bytes.Buffer{}
	if err := binary.Write(buff, binary.LittleEndian, d.Msg); err != nil {
		logger.Error("Stp120 GetPacket write buff err:", err)
		return nil

	}
	if err := binary.Read(buff, binary.LittleEndian, &req.Header); err != nil {
		logger.Error("stp120 GetPacket read header err:", err)
		return nil
	}
	if err := binary.Read(buff, binary.LittleEndian, req.Msg); err != nil {
		logger.Error("stp120 GetPacket read msg err:", err)
		return nil
	}
	return req
}
func SendSTP120Heart() {
	ticker := time.NewTicker(time.Second * 1)
	defer ticker.Stop()
	for range ticker.C {
		DevStatusMap.Range(func(key, value interface{}) bool {
			dev := value.(*Device)
			if dev.DevType == common.DEV_STP120 && dev.Status == common.DevOnline {
				reqMode := &STP120{
					Device: dev,
					dt:     common.DEV_STP120,
				}
				reqMode.SendExtHeartbeat()
			}
			return true
		})
	}
}

// Stp120OfflineReport stp120 offline process.
func Stp120OfflineReport(sn string) {
	var tcpServer *server.TcpServer
	if s, ok := STP120TcpServerMap.Load(sn); ok {
		tcpServer = s.(*server.TcpServer)

		if tcpServer != nil {
			tcpServer.Stop()
		}
		deviceUsedPorts.Delete(tcpServer.Port)
		STP120TcpServerMap.Delete(sn)
		DevSnMap.Delete(tcpServer.Port)
		cachekeyDroneid := fmt.Sprintf("%d_%s", common.DEV_STP120, sn)
		DevStatusMap.Delete(cachekeyDroneid)
		tcpServer = nil
	}

	equipModel, err := GetEquipBySn(sn)
	name := sn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	dataInfo := &client.Stp120HeartInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        sn,
			EquipType: int32(common.DEV_STP120),
			MsgType:   mavlink.STP120HeartMsgReport,
		},
		Data: &client.Stp120HeartInfoData{
			Sn:       sn,
			IsOnline: common.DevOffline,
		},
	}
	if err == nil && equipModel != nil {
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgIDSTP120HeartBeat,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}
	_ = mq.STP120Broker.Publish(mq.STP120Topic, broker.NewMessage(out))
	logger.Info("stp120 Offline report:", report)
}

// SendUpgradeF2
func (d *STP120) SendUpgradeF2() (int32, error) {
	logger.Info("Stp120 SendUpgradeF2 Start")
	req := &mavlink.Stp120UpdateF2Request{}
	buff := req.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.Stp120IdUpgradeF2]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Stp120IdUpgradeF2, true, time.Second*15)
		d.WaitTaskMap[mavlink.Stp120IdUpgradeF2] = manager
	}
	task := manager.AddTask(nil, nil)
	logger.Debugf("Stp120 SendUpgradeF2 buff: %02X \n", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("Stp120 SendUpgradeF2 发送写入固件数据信息失败: ", err)
		return -1, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Stp120 SendUpgradeF2 WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return -1, checkNetConnErr
		}
		return -1, err
	}
	res := result.(*mavlink.Stp120UpdateF2Response)
	logger.Debugf("Stp120 UpdateF2Response 获取写入固件数据信息结果：%#v", res)
	logger.Info("Stp120 UpdateF2Response End")
	return int32(res.Progress), nil
}

// SendUpgradeF3
func (d *STP120) SendUpgradeF3() (int32, error) {
	logger.Info("Stp120 SendUpgradeF3 Start")

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.Stp120IdUpgradeF3]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Stp120IdUpgradeF3, true, time.Second*60)
		d.WaitTaskMap[mavlink.Stp120IdUpgradeF3] = manager
	}
	task := manager.AddTask(nil, nil)

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Stp120SendUpgradeF3 WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 1, checkNetConnErr
		}
		return 1, err
	}
	res := result.(*mavlink.Stp120UpdateF3Response)
	logger.Debugf("Stp120 UpdateF3Response 获取写入固件数据信息结果：%#v", res)
	logger.Info("Stp120 UpdateF3Response End")
	return int32(res.UpgradeResult), nil
}

// ReceiveStp120UpdateF3 获取请求固件升级响应
func (d *STP120) ReceiveStp120UpdateF3() {
	res := &mavlink.Stp120UpdateF3Response{}
	d.GetPacket(res)
	logger.Debugf("ReceiveStp120UpdateF3 获取请求固件升级响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.Stp120IdUpgradeF3]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// SendUpgradeF1
func (d *STP120) SendUpgradeF1(fileName string, c2Ip string) (int32, error) {
	logger.Info("Stp20 SendUpgradeF1 Start")

	req := &mavlink.Stp120UpdateF1Request{}
	buff := req.Create(fileName, c2Ip)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.Stp120IdUpgradeF1]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Stp120IdUpgradeF1, true, 0)
		d.WaitTaskMap[mavlink.Stp120IdUpgradeF1] = manager
	}
	task := manager.AddTask(nil, nil)
	logger.Debugf("Stp120 SendUpgradeF1 buff: %02X \n", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("Stp120 SendUpgradeF1 发送写入固件数据信息失败: ", err)
		return 1, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Stp120 SendUpgradeF1 WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 1, checkNetConnErr
		}
		return 1, err
	}
	res := result.(*mavlink.Stp120UpdateF1Response)
	logger.Debugf("Stp120 UpdateF1Response 获取写入固件数据信息结果：%#v", res)
	logger.Info("Stp120 UpdateF1Response End")
	return int32(res.Status), nil
}

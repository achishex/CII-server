package handler

import (
	"context"
	"testing"

	"adasgitlab.autel.com/tools/cuav_server/proto/client"
)

func TestDeviceCenter_GetReplayDataSchedule(t *testing.T) {
	type args struct {
		ctx context.Context
		req *client.GetReplayDataScheduleRequest
		rsp *client.GetReplayDataScheduleResponse
	}
	tests := []struct {
		name    string
		e       *DeviceCenter
		args    args
		wantErr bool
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			e := &DeviceCenter{}
			if err := e.GetReplayDataSchedule(tt.args.ctx, tt.args.req, tt.args.rsp); (err != nil) != tt.wantErr {
				t.Errorf("DeviceCenter.GetReplayDataSchedule() error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

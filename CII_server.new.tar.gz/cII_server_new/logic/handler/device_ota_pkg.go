package handler

import (
	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/repo/utils/threading"
	"context"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"

	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/awsS3"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/ota"
	utils "adasgitlab.autel.com/tools/cuav_server/entity/utils/panic"
)

// DownloadOtaPkg 异步下载ota固件升级包
func (e *DeviceCenter) DownloadOtaPkg(ctx context.Context, req *client.DownloadOtaPkgRequest, rsp *client.DownloadOtaPkgResponse) error {
	logger.Info("DownloadOtaPkg req: ", req)

	defer utils.HandlePanic()
	filePath := ota.LocalOtaPkgPathMap[req.DeviceType]
	if filePath == "" {
		return errors.New("未知设备类型")
	}
	if req.PkgPath == "" {
		//req.PkgPath = ota.DefaultOtaPkgPath
		logger.Error("DownloadOtaPkg path is nil")
		return errors.New("pkgPath is nil")
	}
	filePath = filepath.Join(req.PkgPath, filePath)
	logger.Info("DownloadOtaPkg filePath: ", filePath)
	_, fileName := filepath.Split(req.FileKey)
	if err := os.MkdirAll(filePath, 0666); err != nil {
		logger.Error("DownloadOtaPkg failed to os.Create, %v \n", err)
	}
	fn, ok := OtaDownloadCancelMap[fileName]
	if ok {
		fn()
		delete(OtaDownloadCancelMap, fileName)
		return nil
	}
	downloadCtx, cancelFunc := context.WithCancel(context.Background())
	logger.Info("DownloadOtaPkg fileName: ", fileName)
	OtaDownloadCancelMap[fileName] = cancelFunc
	go e.downloadOtaPkg(downloadCtx, req, filepath.Join(filePath, fileName))
	rsp.Status = 0

	return nil
}

// downloadOtaPkg 下载ota固件升级包
func (e *DeviceCenter) downloadOtaPkg(ctx context.Context, req *client.DownloadOtaPkgRequest, filePathName string) {
	defer utils.HandlePanic()
	logger.Info("downloadOtaPkg Start")
	f, err := os.Create(filePathName)
	if err != nil {
		logger.Errorf("failed to create download file %v", err)
		return
	}
	defer f.Close()

	// 开启协websocket同步下载状态
	_, cacheKey := filepath.Split(filePathName)
	UpdateDownLoadPkgStatus(cacheKey, &OtaFileDownloadStatus{
		Status:               Downloading,
		DownloadedPercentage: 0,
		FileName:             cacheKey,
		ErrMsg:               "",
		Speed:                0,
		FileSize:             0,
	})
	//go OtaSyncProgress(WsOtaPkgDownloadStatus, "", cacheKey, cacheKey)
	go OtaSyncDownLoadPkgStatus(cacheKey)

	// 下载并写入文件
	e.downloadAndWriteFile(req.Area, req.TestSet, f, req.FileKey, cacheKey, filePathName, "", 0, -1, ctx)
}

// PauseDownloadOtaPkg 暂停下载ota固件升级包
func (e *DeviceCenter) PauseDownloadOtaPkg(ctx context.Context, req *client.PauseDownloadOtaRequest, rsp *client.PauseDownloadOtaResponse) error {
	_, fileName := filepath.Split(req.FileKey)
	// 获取通知停止下载的cancel方法进行调用
	cancelFun, ok := OtaDownloadCancelMap[fileName]
	if !ok {
		rsp.Status = 1
		return nil
	}
	cancelFun()
	rsp.Status = 0
	return nil
}

// ContinueDownloadOtaPkg 继续下载ota固件升级包
func (e *DeviceCenter) ContinueDownloadOtaPkg(ctx context.Context, req *client.ContinueDownloadOtaRequest, rsp *client.ContinueDownloadOtaResponse) error {
	defer utils.HandlePanic()
	filePath := ota.LocalOtaPkgPathMap[req.DeviceType]
	if filePath == "" {
		return errors.New("未知设备类型")
	}
	if req.PkgPath == "" {
		//req.PkgPath = ota.DefaultOtaPkgPath
		logger.Error("DownloadOtaPkg path is nil")
		return errors.New("pkgPath is nil")
	}
	filePath = filepath.Join(req.PkgPath, filePath)
	_, fileName := filepath.Split(req.FileKey)
	fallPath := filepath.Join(filePath, fileName)
	fn, ok := OtaDownloadCancelMap[fileName]
	if ok {
		fn()
		delete(OtaDownloadCancelMap, fileName)
		return nil
	}
	downloadCtx, cancelFunc := context.WithCancel(context.Background())
	OtaDownloadCancelMap[fileName] = cancelFunc // 保存用于通知取消的cancel方法
	// 定位继续下载的文件位置
	exist, _ := ota.PathOrFileExists(fallPath)
	if !exist {
		fallPath = strings.TrimSuffix(fallPath, filepath.Ext(fallPath)) + DownloadFiledSuffix
		FieldExist, _ := ota.PathOrFileExists(fallPath)
		if !FieldExist {
			// 都不存在则重新下载
			go e.downloadOtaPkg(downloadCtx, &client.DownloadOtaPkgRequest{
				FileKey:    req.FileKey,
				DeviceType: req.DeviceType,
				PkgPath:    req.PkgPath,
			}, filepath.Join(filePath, fileName))
			return nil
		}
	}
	go e.continueDownloadOtaPkg(downloadCtx, fallPath, req.FileKey, req.TestSet, req.Area)
	rsp.Status = 0
	return nil
}

// continueDownloadOtaPkg 异步继续下载ota固件升级包
func (e *DeviceCenter) continueDownloadOtaPkg(ctx context.Context, fallPath, fileKey string, testEnv int32, area int32) {
	defer utils.HandlePanic()
	logger.Info("continueDownloadOtaPkg Start")
	_, fileName := filepath.Split(fileKey)
	cloudPkg, ok := ota.GetCloudOtaFilePackage(fileName)
	if !ok {
		logger.Error("not found")
		return
	}
	// 计算已下载文件的大小占云端文件的百分比
	fileInfo, _ := os.Stat(fallPath)
	offset := fileInfo.Size()
	totalSize := cloudPkg.FileSize
	if offset == int64(totalSize) {
		// 文件已下载完成
		return
	}
	permil := 1000 * int(offset) / totalSize
	UpdateDownLoadPkgStatus(fileName, &OtaFileDownloadStatus{
		Status:               Downloading,
		DownloadedPercentage: permil,
		FileName:             fileName,
		ErrMsg:               "",
	})
	// 开启协程与前端同步进度
	go OtaSyncDownLoadPkgStatus(fileName)
	// 下载的字节范围
	rangeHeader := fmt.Sprintf("bytes=%d-%d", offset, cloudPkg.FileSize-1)
	// 打开文件
	writer, _ := os.OpenFile(fallPath, os.O_APPEND|os.O_WRONLY, 0644)
	defer writer.Close()
	// 下载并写入文件
	e.downloadAndWriteFile(area, testEnv, writer, fileKey, fileName, fallPath, rangeHeader, offset, totalSize, ctx)
}

func float32ToTwoDecimal(num float32) float32 {
	str := fmt.Sprintf("%.2f", num)
	if newNum, err := strconv.ParseFloat(str, 32); err == nil {
		return float32(newNum)
	}
	return num // return original number in case of an error
}

// downloadAndWriteFile 下载并写入文件
func (e *DeviceCenter) downloadAndWriteFile(area int32, testEnv int32, f *os.File,
	fileKey, fileName, fallPath, rangeHeader string,
	offset int64, totalSize int,
	ctx context.Context,
) {
	defer utils.HandlePanic()
	// 获取零时下载地址
	url := ""
	if area == 1 {
		url = ota.AbroadCloudOtaDownloadPreSignUrl
	} else {
		url = ota.CloudOtaDownloadPreSignUrl
		if testEnv == 1 {
			url = ota.TestCloudOtaDownloadPreSignUrl
		}
	}
	preSignRsp, err := ota.GetOtaPreSignDownloadUrl(url, fileKey, rangeHeader)
	if err != nil {
		logger.Errorf("continueDownloadOtaPkg ota.GetOtaPreSignDownloadUrl:%v \n", err)
		UpdateDownLoadPkgStatus(fileName, &OtaFileDownloadStatus{
			Status:               DownloadField,
			DownloadedPercentage: 0,
			FileName:             fileName,
			ErrMsg:               err.Error(),
			FallPath:             fallPath,
		})
		return
	}

	logger.Infof("continueDownloadOtaPkg preSignRsp.Url:%s \n", preSignRsp.URL)
	// 下载升级包
	httpReq, _ := http.NewRequest(preSignRsp.Method, preSignRsp.URL, nil)
	for k, vs := range preSignRsp.Header {
		for _, v := range vs {
			httpReq.Header.Add(k, v)
		}
	}
	client := &http.Client{}
	otaRsp, err := client.Do(httpReq)
	if err != nil {
		logger.Errorf("downloadAndWriteFile got err:%v \n", err)
		return
	}

	if totalSize == -1 {
		totalSize = int(otaRsp.ContentLength)
	}
	defer otaRsp.Body.Close()
	buf := make([]byte, 10240)
	if err != nil {
		logger.Errorf("continueDownloadOtaPkg failed client.Get, %d:%s", otaRsp.StatusCode, otaRsp.Status)
		UpdateDownLoadPkgStatus(fileName, &OtaFileDownloadStatus{
			Status:               DownloadField,
			DownloadedPercentage: 0,
			FileName:             fileName,
			ErrMsg:               err.Error(),
			FallPath:             fallPath,
			FileSize:             int64(totalSize),
		})
		return
	}
	lastTime := time.Now()
	lastRecvLenByte := 0
	downByteRate := float32(0.0)
	for {
		select {
		case <-ctx.Done():
			logger.Info("continueDownloadOtaPkg 下载被暂停")
			percent := 1000 * int(offset) / totalSize
			UpdateDownLoadPkgStatus(fileName, &OtaFileDownloadStatus{
				Status:               DownloadPause,
				DownloadedPercentage: percent,
				FileName:             fileName,
				ErrMsg:               "暂停",
				FallPath:             fallPath,
				FileSize:             int64(totalSize),
			})
			return
		default:
			cancel := time.AfterFunc(time.Second*4, func() {
				// 超过4秒没有读取到字节则关闭Body退出
				logger.Info("downloadAndWriteFile time out AfterFunc")
				_ = otaRsp.Body.Close()
			})
			n, err := otaRsp.Body.Read(buf)
			lastRecvLenByte += n

			currentTime := time.Now()
			if currentTime.Sub(lastTime) >= 500*time.Millisecond {
				elapsed := currentTime.Sub(lastTime).Milliseconds()
				downByteRate = float32(lastRecvLenByte) / float32(elapsed) * 1000

				lastTime = currentTime
				lastRecvLenByte = 0
			}
			cancel.Stop()
			if n == 0 {
				if err != nil && err != io.EOF {
					percent := 1000 * int(offset) / totalSize
					UpdateDownLoadPkgStatus(fileName, &OtaFileDownloadStatus{
						Status:               DownloadNetworkErr,
						DownloadedPercentage: percent,
						FileName:             fileName,
						ErrMsg:               err.Error(),
						FallPath:             fallPath,
						FileSize:             int64(totalSize),
					})
					logger.Info("downloadAndWriteFile Body.Read err: ", err)
					return
				}
				UpdateDownLoadPkgStatus(fileName, &OtaFileDownloadStatus{
					Status:               DownloadDone,
					DownloadedPercentage: 1000,
					FileName:             fileName,
					ErrMsg:               "",
					FallPath:             fallPath,
					FileSize:             int64(totalSize),
				})
				return
			}
			if err != nil && err != io.EOF {
				// 读取报错更新状态
				UpdateDownLoadPkgStatus(fileName, &OtaFileDownloadStatus{
					Status:               DownloadField,
					DownloadedPercentage: 0,
					FileName:             fileName,
					ErrMsg:               "读取下载文件数据报错",
					FallPath:             fallPath,
					FileSize:             int64(totalSize),
				})
				return
			}
			buf2 := buf[:n]
			// 写入文件
			_, err = f.Write(buf2)
			if err != nil {
				// 写入报错更新状态
				UpdateDownLoadPkgStatus(fileName, &OtaFileDownloadStatus{
					Status:               DownloadField,
					DownloadedPercentage: 0,
					FileName:             fileName,
					ErrMsg:               "写入本地文件报错",
					FallPath:             fallPath,
					FileSize:             int64(totalSize),
				})
				return
			}
			offset += int64(n)
			// 更新状态
			percent := 1000 * int(offset) / totalSize
			// 更新状态
			if percent%10 == 0 { //进度条整数上报
				UpdateDownLoadPkgStatus(fileName, &OtaFileDownloadStatus{
					Status:               Downloading,
					DownloadedPercentage: percent,
					FileName:             fileName,
					ErrMsg:               "",
					Speed:                downByteRate,
					FileSize:             int64(totalSize),
				})
			}
		}
	}
}

// transDevTypeToOtaDevType 返回m1, key: sn, value is ota dev type; 返回m2, key: ota dev type(eg: ota.DeviceTypeRadar), value: sn list.
func transDevTypeToOtaDevType(devInfoList []*bean.EquipList) (map[string]int, map[int][]string, error) {
	if len(devInfoList) <= 0 {
		return nil, nil, fmt.Errorf("dev info list is empty")
	}

	snOtaDevType := make(map[string]int)
	otaDevTypeSn := make(map[int][]string) //key:ota.DeviceTypeSfl110, value: []string{sn}
	for _, devInfo := range devInfoList {
		if devInfo == nil {
			continue
		}

		var otaDevType = -1
		if devInfo.Etype == common.STP120 {
			otaDevType = ota.DeviceSTP120

		} else if devInfo.Etype == common.Radar {
			otaDevType = ota.DeviceTypeRadar

		} else if devInfo.Etype == common.Sfl {
			otaDevType = ota.DeviceTypeSFL

		} else if devInfo.Etype == common.FPV {
			otaDevType = ota.DeviceTypeFPV

		} else if devInfo.Etype == common.Drone {
			if devInfo.SubDevType == 0 { //从数据库中获取值为0， 默认是tracerP
				otaDevType = ota.DeviceTypeTracerP

			} else if devInfo.SubDevType == int(TracerMap[TracerType(STP100)]) {
				otaDevType = ota.DeviceTypeTracerP

			} else if devInfo.SubDevType == int(TracerMap[TracerType(STS100)]) ||
				devInfo.SubDevType == int(TracerMap[TracerType(STC100)]) ||
				devInfo.SubDevType == int(TracerMap[TracerType(STS120)]) {
				otaDevType = ota.DeviceTypeTracerS

			} else {
				logger.Errorf("not unknown sub dev type: %v", devInfo.SubDevType)
			}

		} else if devInfo.Etype == common.Agx {
			otaDevType = ota.DeviceTypeAgx

		} else if devInfo.Etype == common.SFL101 {
			otaDevType = ota.DeviceTypeSfl110

		} else if devInfo.Etype == common.GunsCloud {
			otaDevType = ota.DeviceTypeGunCloud

		} else if devInfo.Etype == common.SVH100 {
			otaDevType = ota.DeviceTypeSVH
		} else {
			logger.Debugf("not implement dev ota type for sn: %v, devType: %v", devInfo.Sn, devInfo.Etype)
			continue
		}
		snOtaDevType[devInfo.Sn] = otaDevType
		//
		snList := otaDevTypeSn[otaDevType]
		snList = append(snList, devInfo.Sn)
		otaDevTypeSn[otaDevType] = snList
	}
	logger.Info("sn and ota Dev type: %v", snOtaDevType)
	return snOtaDevType, otaDevTypeSn, nil
}

// GetLatestPkgFromOta 并发获取设备类型的ota 最新包, otaDevType, key is ota type(eg: ota.DeviceTypeRadar)
func GetLatestPkgFromOta(latestVerInfo *sync.Map, area int32, otaDevTypeSnList map[int][]string) error {
	latestPkgWg := threading.NewRoutineGroupWrap()
	for otaDevType, _ := range otaDevTypeSnList {

		latestPkgWg.Run(func() {
			pkg, err := ota.GetLatestPkg(int32(otaDevType), area)
			if err != nil {
				logger.Errorf("get latest pkg for dev type: %v, err: %v", otaDevType, err)
				return
			}
			if pkg == nil {
				logger.Errorf("get latest pkg ret is empty, type: %v, err: %v", otaDevType, err)
				return
			}
			latestVerInfo.Store(otaDevType, &client.CheckPkgIsLatestResponse{
				LatestVersion: pkg.Version,
			})
		})
	}
	latestPkgWg.Wait()
	return nil
}
func transDroneWithSubDevType(dst *client.OtaDevicePkgInfo, src *bean.EquipList) error {
	if dst == nil || src == nil {
		return nil
	}

	if src.SubDevType == int(TracerMap[STP100]) {
		dst.DeviceType = common.DroneTracerP
	} else if src.SubDevType == int(TracerMap[STS100]) {
		dst.DeviceType = common.DroneTracerS
	} else if src.SubDevType == int(TracerMap[STC100]) {
		dst.DeviceType = common.DroneTracerS
	} else { //strings.HasPrefix(src.DevVersion, "STC100-") ||
		if strings.HasPrefix(src.DevVersion, "STC100-") || strings.HasPrefix(src.DevVersion, "STS100-") {
			logger.Errorf("device sub type is 0, and dev version is: %v", src.DevVersion)
			dst.DeviceType = common.DroneTracerS
		} else if strings.HasPrefix(src.DevVersion, "STP100-") {
			logger.Errorf("device sub type is 0, and dev version is: %v", src.DevVersion)
			dst.DeviceType = common.DroneTracerP
		} else {
			return fmt.Errorf("default drone is tracerP: %v", src.SubDevType)
		}
	}
	return nil
}

// GetVersionParallel 调用接口获取设备当前版本
func GetVersionParallel(verInfos *sync.Map, devList []*bean.EquipList) error {
	wgGetVersion := threading.NewRoutineGroupWrap()

	for i, _ := range devList {
		devInfo := devList[i]
		if devInfo == nil {
			continue
		}

		wgGetVersion.Run(func() {
			versionData := &client.OtaDevicePkgInfo{
				DeviceName: devInfo.Name,
				Sn:         devInfo.Sn,
				DeviceType: devInfo.Etype,
			}

			if devInfo.Etype == common.STP120 {
				deviceReq := &client.Stp120GetVersionRequest{
					Sn: devInfo.Sn,
				}

				deviceRsp := &client.Stp120GetVersionResponse{}
				err := NewDeviceCenter().Stp120GetVersion(context.Background(), deviceReq, deviceRsp)
				if err != nil {
					return
				}
				versionData.DeviceVersion = deviceRsp.GetVersion()
				verInfos.Store(devInfo.Sn, versionData)
				logger.Infof("stp120 version: %v", versionData.String())

			} else if devInfo.Etype == common.Drone {
				deviceReq := &client.TracerGetVersionInfoRequest{Sn: devInfo.Sn}
				deviceRsp := &client.TracerGetVersionInfoResponse{}
				err := NewDeviceCenter().TracerGetVersionInfo(context.Background(), deviceReq, deviceRsp)
				if err != nil {
					logger.Errorf("get tracer version fail, sn: %v, err: %v", devInfo.Sn, err)
					return
				}

				_ = transDroneWithSubDevType(versionData, devInfo)
				versionData.DeviceVersion = deviceRsp.AppVersion
				verInfos.Store(devInfo.Sn, versionData)
				logger.Infof("drone version: %v", versionData.String())

			} else if devInfo.Etype == common.FPV {
				deviceReq := &client.FpvSendGetVersionRequest{
					Sn: devInfo.Sn,
				}

				deviceRsp := &client.FpvSendGetVersionResponse{}
				err := NewDeviceCenter().FpvSendGetVersion(context.Background(), deviceReq, deviceRsp)
				if err != nil {
					return
				}
				versionData.DeviceVersion = deviceRsp.PlVersion
				verInfos.Store(devInfo.Sn, versionData)
				logger.Infof("fpv version: %v", versionData.String())

			} else if devInfo.Etype == common.Radar {
				deviceReq := &client.RadarGetConfigRequest{
					Sn: devInfo.Sn,
				}
				deviceRsp := &client.RadarGetConfigResponse{}

				err := NewDeviceCenter().RadarGetConfig(context.Background(), deviceReq, deviceRsp)
				if err != nil {
					logger.Errorf("radar RadarGetConfig error: %v, sn: %v", err, devInfo.Sn)
					return
				}

				versionData.DeviceVersion = deviceRsp.GetVersion()
				verInfos.Store(devInfo.Sn, versionData)
				logger.Infof("radar version: %v", versionData.String())

			} else if devInfo.Etype == common.Agx {
				deviceReq := &client.AgxGetVersionRequest{
					Sn:        devInfo.Sn,
					EquipType: int32(common.DEV_AGX),
				}
				deviceRsp := &client.AgxGetVersionResponse{}

				err := NewDeviceCenter().AgxGetVersion(context.Background(), deviceReq, deviceRsp)
				if err != nil {
					logger.Errorf("agx get version error: %v, sn: %v", err, devInfo.Sn)
					return
				}
				versionData.DeviceVersion = deviceRsp.GetAppVersion()
				verInfos.Store(devInfo.Sn, versionData)
				logger.Infof("agx version: %v", versionData.String())

			} else if devInfo.Etype == common.SRP150 {
				deviceReq := &client.AgxGetVersionRequest{
					Sn:        devInfo.Sn,
					EquipType: int32(common.DEV_SRP150),
				}
				deviceRsp := &client.AgxGetVersionResponse{}

				err := NewDeviceCenter().AgxGetVersion(context.Background(), deviceReq, deviceRsp)
				if err != nil {
					logger.Errorf("agx get version error: %v, sn: %v", err, devInfo.Sn)
					return
				}
				versionData.DeviceVersion = deviceRsp.GetAppVersion()
				verInfos.Store(devInfo.Sn, versionData)
				logger.Infof("agx version: %v", versionData.String())

			} else if devInfo.Etype == common.SRP200 {
				deviceReq := &client.AgxGetVersionRequest{
					Sn:        devInfo.Sn,
					EquipType: int32(common.DEV_SRP200),
				}
				deviceRsp := &client.AgxGetVersionResponse{}

				err := NewDeviceCenter().AgxGetVersion(context.Background(), deviceReq, deviceRsp)
				if err != nil {
					logger.Errorf("agx get version error: %v, sn: %v", err, devInfo.Sn)
					return
				}
				versionData.DeviceVersion = deviceRsp.GetAppVersion()
				verInfos.Store(devInfo.Sn, versionData)
				logger.Infof("agx version: %v", versionData.String())
			} else if devInfo.Etype == common.SBP100 {
				deviceReq := &client.AgxGetVersionRequest{
					Sn:        devInfo.Sn,
					EquipType: int32(common.DEV_SBP100),
				}
				deviceRsp := &client.AgxGetVersionResponse{}

				err := NewDeviceCenter().AgxGetVersion(context.Background(), deviceReq, deviceRsp)
				if err != nil {
					logger.Errorf("agx get version error: %v, sn: %v", err, devInfo.Sn)
					return
				}
				versionData.DeviceVersion = deviceRsp.GetAppVersion()
				verInfos.Store(devInfo.Sn, versionData)
				logger.Infof("agx version: %v", versionData.String())

			} else if devInfo.Etype == common.Sfl {
				deviceReq := &client.SflGetVersionRequest{Sn: devInfo.Sn}
				deviceRsp := &client.SflGetVersionResponse{}

				err := NewDeviceCenter().SflGetVersionInfo(context.Background(), deviceReq, deviceRsp)
				if err != nil {
					logger.Errorf("get sfl version fail, err: %v, sn: %v", err, devInfo.Sn)
					return
				}
				versionData.DeviceVersion = deviceRsp.Version
				verInfos.Store(devInfo.Sn, versionData)
				logger.Infof("sfl version: %v", versionData.String())

			} else if devInfo.Etype == common.NSF400 {
				return

			} else if devInfo.Etype == common.TracerRFurd360 {
				return

			} else if devInfo.Etype == common.Sfl200 {
				deviceReq := &client.Sfl200GetVersionRequest{}
				deviceRsp := &client.Sfl200GetVersionResponse{}
				err := NewDeviceCenter().Sfl200GetVersionInfo(context.Background(), deviceReq, deviceRsp)
				if err != nil {
					logger.Errorf("get sfl200 version fail, err: %v, sn: %v", err, devInfo.Sn)
					return
				}
				versionData.DeviceVersion = deviceRsp.Sfl200Version
				verInfos.Store(devInfo.Sn, versionData)
				logger.Infof("sfl200 version: %v", versionData.String())

			} else if devInfo.Etype == common.RF {
				return

			} else if devInfo.Etype == common.DPH110 {
				return

			} else if devInfo.Etype == common.GunsCloud {
				deviceReq := &client.GunsPlatformGetVersionRequest{
					Sn: devInfo.Sn,
				}
				deviceRsp := &client.GunsPlatformGetVersionResponse{}
				err := NewDeviceCenter().GunsPlatformGetVersionInfo(context.Background(), deviceReq, deviceRsp)
				if err != nil {
					logger.Errorf("get gun platform version fail, sn: %v, err: %v", devInfo.Sn, err)
					return
				}
				versionData.DeviceVersion = deviceRsp.Version
				verInfos.Store(devInfo.Sn, versionData)
				logger.Infof("gun cloud version: %v", versionData.String())

			} else if devInfo.Etype == common.SRP150 {
				return
			} else if devInfo.Etype == common.SRP200 {
				return
			} else if devInfo.Etype == common.TracerGun {
				return
			} else if devInfo.Etype == common.SBP100 {
				return
			} else if devInfo.Etype == common.SVH100 {
				deviceReq := &client.SvhGetVersionRequest{
					Sn: devInfo.Sn,
				}
				deviceRsp := &client.SvhGetVersionResponse{}
				err := NewDeviceCenter().SvhGetVersionInfo(context.Background(), deviceReq, deviceRsp)
				if err != nil {
					logger.Errorf("get svh version fail, err: %v, sn: %v", err, devInfo.Sn)
					return
				}
				versionData.DeviceVersion = deviceRsp.PlVersion
				verInfos.Store(devInfo.Sn, versionData)

				logger.Infof("SVH100 version: %v", versionData.String())

			} else if devInfo.Etype == common.SFL101 {
				deviceReq := &client.Sfl101GetVersionRequest{
					Sn: devInfo.Sn,
				}
				deviceRsp := &client.Sfl101GetVersionResponse{}

				err := NewDeviceCenter().Sfl101GetVersionInfo(context.Background(), deviceReq, deviceRsp)
				if err != nil {
					logger.Errorf("get sfl101 version fail, err: %v, sn: %v", err, devInfo.Sn)
					return
				}
				versionData.DeviceVersion = deviceRsp.Version
				verInfos.Store(devInfo.Sn, versionData)

				logger.Infof("SFL101 version: %v", versionData.String())
			}
		})
	}
	wgGetVersion.Wait()
	//
	return nil
}
func (e *DeviceCenter) ProcessOnlineDeviceOta(ctx context.Context, snList []string, area int32, o *client.OtaDevicePkgPullResponse) error {
	devList, err := NewEquipList().QueryDevDetailsBySn(ctx, snList)
	if err != nil {
		logger.Errorf("query dev detail by sn list: %v, err: %v", snList, err)
		return err
	}
	if len(devList) <= 0 {
		return nil
	}
	//根据数据库中设备类型获取ota设备类型
	snOtaDevType, otaDevTypeSn, err := transDevTypeToOtaDevType(devList)
	if err != nil {
		return err
	}
	if len(snOtaDevType) <= 0 || len(otaDevTypeSn) <= 0 {
		logger.Errorf("get sn to ota dev type map ret empty")
		return fmt.Errorf("get sn to ota dev type map ret empty")
	}

	var versionResponse sync.Map     // key: sn, value:  *OtaDevicePkgInfo.
	var otaDevTypeLatestPkg sync.Map //key: ota devType, value:  *CheckPkgIsLatestResponse

	var versionResponsePtr = &versionResponse         // key: sn, value:  *OtaDevicePkgInfo.
	var otaDevTypeLatestPkgPtr = &otaDevTypeLatestPkg //key: ota devType, value:  *CheckPkgIsLatestResponse

	otaPkgOnlineWg := threading.NewRoutineGroupWrap()
	otaPkgOnlineWg.Run(func() {
		_ = GetVersionParallel(versionResponsePtr, devList)
	})
	otaPkgOnlineWg.Run(func() {
		_ = GetLatestPkgFromOta(otaDevTypeLatestPkgPtr, area, otaDevTypeSn)
	})
	otaPkgOnlineWg.Wait()

	versionResponsePtr.Range(func(key any, value any) bool {
		logger.Debugf("version: %v, %v", key, value)
		return true
	})

	otaDevTypeLatestPkgPtr.Range(func(key any, value any) bool {
		logger.Debugf("ota pkg latest: %v, %v", key, value)
		return true
	})

	var retProcess []*client.OtaDevicePkgInfo = nil
	versionResponsePtr.Range(func(key, value any) bool {
		otaDevPkgInfo, ok := value.(*client.OtaDevicePkgInfo)
		if !ok {
			logger.Errorf("sn: %v, value no OtaDevicePkgInfo", key)
			return true
		}
		if otaDevPkgInfo == nil {
			logger.Errorf("sn: %v, value OtaDevicePkgInfo is nil", key)
			return true
		}
		sn := key.(string)
		otaDevType, ok := snOtaDevType[sn]
		if !ok {
			logger.Errorf("sn: %v, not exist valid ot devType", sn)
			return true
		}
		otaDevLatestPkg, ok := otaDevTypeLatestPkgPtr.Load(otaDevType)
		if !ok {
			logger.Errorf("sn: %v, ota devType: %v, not have ota latest pkg version", sn, otaDevType)
			otaDevPkgInfo.PkgStatus = 2
			retProcess = append(retProcess, otaDevPkgInfo)
			return true
		}
		if otaDevLatestPkg == nil {
			logger.Errorf("sn: %v, ota devType: %v, ota latest pkg version is nil", sn, otaDevType)
			otaDevPkgInfo.PkgStatus = 2
			retProcess = append(retProcess, otaDevPkgInfo)
			return true
		}
		pkgLatestItem, ok := otaDevLatestPkg.(*client.CheckPkgIsLatestResponse)
		if !ok || pkgLatestItem == nil {
			logger.Errorf("sn: %v, ota devType: %v, ota latest pkg version is nil", sn, otaDevType)
			return true
		}
		if pkgLatestItem.GetLatestVersion() == otaDevPkgInfo.GetDeviceVersion() {
			otaDevPkgInfo.PkgStatus = 1
		} else {
			logger.Debugf("ota latest pkg version: %v, device current version: %v",
				pkgLatestItem.GetLatestVersion(),
				otaDevPkgInfo.GetDeviceVersion())
			otaDevPkgInfo.PkgStatus = 2
		}
		retProcess = append(retProcess, otaDevPkgInfo)
		return true
	})
	o.DeviceList = retProcess
	return nil
}

// cmpOtaDevTypeWithDeviceType 检查设备类型和ota设备类型是否相等
func cmpOtaDevTypeWithDeviceType(otaDevType int32, devType common.DeviceType, subDevType uint16) bool {
	var ret = false

	switch devType {
	case common.DEV_AEAG:
	//屏幕
	case common.DEV_SCREEN:
	//雷达
	case common.DEV_RADAR:
		if otaDevType == ota.DeviceTypeRadar {
			ret = true
		}
	//C2 droneID
	case common.DEV_V2DRONEID:
		if (otaDevType == ota.DeviceTypeTracerP && subDevType == converTracerType(STP100)) ||
			(otaDevType == ota.DeviceTypeTracerS && subDevType == converTracerType(STS100)) ||
			(otaDevType == ota.DeviceTypeTracerPro && subDevType == converTracerType(STC100)) ||
			(otaDevType == ota.DeviceTypeTracerS && subDevType == converTracerType(STS120)) {
			ret = true
		}
	// DEV_URD360 Urd360
	case common.DEV_URD360:
	//NSF4000 cheater
	case common.DEV_NSF4000:

	//C2_Sfl 云台
	case common.DEV_SFL:
		if otaDevType == ota.DeviceTypeSFL ||
			otaDevType == ota.DeviceTypeSfl110 {
			ret = true
		}
	//C2_AGX_雷达融合平台
	case common.DEV_AGX:
		if otaDevType == ota.DeviceTypeAgx {
			ret = true
		}
	//Sfl200
	case common.DEV_SFL200:
	//枪+云台
	case common.DEV_HUNTER_PLATFORM:
		if otaDevType == ota.DeviceTypeGunCloud {
			ret = true
		}

	//DPH110 中程雷达
	case common.DEV_DPH110:

	//中程雷视
	case common.DEV_SRP200:

	//激光雷达(agx)
	case common.DEV_SBP100:

	//激光雷达(单独)
	case common.DEV_LASER:

	//tracer+枪
	case common.DEV_TracerGun:

	//新车载FPV  DEV_SVH
	case common.DEV_SVH:
		if otaDevType == ota.DeviceTypeSVH {
			ret = true
		}

	//C2_Fpv 车载
	case common.DEV_FPV:
		if otaDevType == ota.DeviceTypeFPV {
			ret = true
		}

	//spoofer 电量监测设备
	case common.DEV_SPOOFER_MONITOR:

	//SFL移动式
	case common.DEV_SFL101:
		if otaDevType == ota.DeviceTypeSFL101 {
			ret = true
		}

	//SRP150 雷视便携
	case common.DEV_SRP150:

	}
	return ret
}

// GetLocalOtaPkgList 获取本地ota固件升级包列表
func (e *DeviceCenter) GetLocalOtaPkgList(ctx context.Context, req *client.GetOtaPkgListRequest, rsp *client.GetOtaPkgListResponse) error {
	logger.Debug("--->into GetLocalOta List req:", req)
	defer utils.HandlePanic()
	rsp.Status = 0
	rsp.OtaPkgList = make([]*client.OtaPkgInfo, 0)
	if req.PkgPath == "" {
		logger.Error("Get Local OtaPkg List err:pkgPath is nil")
		return errors.New("pkgPath is nil")
	}
	//查询所有在线设备
	snList := make([]string, 0)
	DevStatusMap.Range(func(key, value interface{}) bool {
		dev := value.(*Device)
		snList = append(snList, dev.Sn)
		return true
	})
	// 先查看一下是否有缓存列表
	var otaList *ota.GetOtaCloudFileListResult
	otaList, _ = ota.GetOtaCloudFileList(req.PkgPath, 0, req.TestSet, req.Area, snList)

	if req.DeviceType == 0 {
		// 获取所有的ota升级包
		for deviceType, pkgPath := range ota.LocalOtaPkgPathMap {
			if deviceType == ota.DeviceTypeTracerPro {
				continue
			}
			pkgList := ota.GetLocalOtaPkgInfo(otaList, filepath.Join(req.PkgPath, pkgPath), deviceType, req.PkgPath)
			if pkgList != nil {
				rsp.OtaPkgList = append(rsp.OtaPkgList, pkgList...)
			} else {

			}
		}

		logger.Debug("--->End GetLocalOta List Type 0 req:", rsp.OtaPkgList)
		return nil
	} else {
		// 查询具体类型的升级包
		filePath := ota.LocalOtaPkgPathMap[req.DeviceType]
		if filePath != "" {
			rsp.OtaPkgList = ota.GetLocalOtaPkgInfo(otaList, filepath.Join(req.PkgPath, filePath), req.DeviceType, req.PkgPath)
		}
		logger.Debug("--->End GetLocalOta List req:", rsp.OtaPkgList)
		return nil
	}

}

// GetCloudOtaPkgList 获取云端ota固件升级包列表
func (e *DeviceCenter) GetCloudOtaPkgList(ctx context.Context, req *client.GetOtaPkgListRequest, rsp *client.GetOtaPkgListResponse) error {
	defer utils.HandlePanic()
	logger.Info("get cloud pkg list:", req)
	// 获取S3ota升级包列表
	snList := make([]string, 0)
	DevStatusMap.Range(func(key, value interface{}) bool {
		dev := value.(*Device)
		snList = append(snList, dev.Sn)
		return true
	})
	//snList = append(snList, "test1234")
	result, err := ota.GetOtaCloudFileList(req.PkgPath, req.DeviceType, req.TestSet, req.Area, snList)
	if err != nil {
		return err
	}

	var upgradeList *awsS3.TracerUpgradeInfo
	upgradeList, err = awsS3.GetTracerUpgradeJson(req.DeviceType, req.PkgPath, req.TestSet)

	rsp.Status = 0
	// 返回文件列表
	rsp.OtaPkgList = make([]*client.OtaPkgInfo, 0)
	for _, otaPackage := range result.List {
		upgradeInfo, upgradeInfoChinese, upgradeInfoEnglish, upgradeInfoRussian := "", "", "", ""
		if upgradeList != nil {
			for _, list := range upgradeList.List {
				if otaPackage.FileName == list.Version {
					upgradeInfo = list.UpgradeDesc
					upgradeInfoChinese = list.UpgradeDescChinese
					upgradeInfoEnglish = list.UpgradeDescEnglish
					upgradeInfoRussian = list.UpgradeDescRussian
				}
			}
		}
		rsp.OtaPkgList = append(rsp.OtaPkgList, &client.OtaPkgInfo{
			FileName:           otaPackage.FileName,
			DeviceType:         int32(otaPackage.DeviceType),
			Version:            otaPackage.Version,
			ModTime:            otaPackage.UpdatedAt.String(),
			FileKey:            otaPackage.FileKey,
			IsLatest:           otaPackage.IsLatest == 1,
			UpgradeInfo:        upgradeInfo,
			UpgradeInfoChinese: upgradeInfoChinese,
			UpgradeInfoEnglish: upgradeInfoEnglish,
			UpgradeInfoRussian: upgradeInfoRussian,
			C2Version:          otaPackage.C2Version,
		})

	}
	for devType, pkgPath := range ota.LocalOtaPkgPathMap {
		ota.DelLocalOtaPkgInfo(filepath.Join(req.PkgPath, pkgPath), rsp.OtaPkgList, devType)
	}
	logger.Info(" --->End get cloud pkg list:", rsp.OtaPkgList)
	return nil
}

// GetUpgradeStatus 获取固件升级状态
func (e *DeviceCenter) GetUpgradeStatus(ctx context.Context, req *client.GetUpgradeStatusRequest, rsp *client.GetUpgradeStatusResponse) error {
	cacheKey := ""
	if req.DeviceType == ota.DeviceTypeRadar {
		cacheKey = fmt.Sprintf("%d_%s", common.DEV_RADAR, req.Sn)
	} else if req.DeviceType == ota.DeviceTypeGun {
		cacheKey = fmt.Sprintf("%d_%s", common.DEV_SCREEN, req.Sn)
	}
	logger.Info(cacheKey)
	return nil
}

// CheckPkgIsLatest 检查升级包版本是否为最新
func (e *DeviceCenter) CheckPkgIsLatest(ctx context.Context, req *client.CheckPkgIsLatestRequest, rsp *client.CheckPkgIsLatestResponse) error {
	// 根据设备类型查询出最新的版本号
	pkg, err := ota.GetLatestPkg(req.DeviceType, req.Area)
	if err != nil {
		return err
	}
	rsp.LatestVersion = pkg.Version
	rsp.IsLatest = req.Version == pkg.Version
	return nil
}

// CheckLatestPkgExist 检查本地是否有最新版本升级包
func (e *DeviceCenter) CheckLatestPkgExist(ctx context.Context, req *client.CheckLatestPkgExistRequest, rsp *client.CheckLatestPkgExistResponse) error {
	filePath := ota.LocalOtaPkgPathMap[req.DeviceType]
	if filePath == "" {
		return errors.New("设备类型有误")
	}
	// 根据设备类型查询出最新的版本号
	pkg, err := ota.GetLatestPkg(req.DeviceType, req.Area)
	if err != nil {
		return err
	}

	rsp.LatestVersion = pkg.Version
	rsp.Exist = ota.CheckVersionExist(filepath.Join(req.PkgPath, filePath), pkg.Version)

	return nil
}

// GetLatestVersion 根据设备类型获取最新的ota升级包版本
func (e *DeviceCenter) GetLatestVersion(ctx context.Context, req *client.GetLatestVersionRequest, rsp *client.GetLatestVersionResponse) error {
	// 查询最新版本信息
	pkg, err := ota.GetLatestPkg(req.DeviceType, req.Area)
	if err != nil || pkg == nil {
		rsp.LatestVersion = ""
		return nil
	}

	rsp.LatestVersion = pkg.Version
	return nil
}

// GetLatestFileName 根据设备类型获取最新的ota升级包文件名
func (e *DeviceCenter) GetLatestFileName(ctx context.Context, req *client.GetLatestFileNameRequest, rsp *client.GetLatestFileNameResponse) error {
	// 查询最新版本信息
	pkg, err := ota.GetLatestPkg(req.DeviceType, req.Area)
	if err != nil || pkg == nil {
		rsp.LatestFileName = ""
		return nil
	}

	rsp.LatestFileName = pkg.FileName
	return nil
}

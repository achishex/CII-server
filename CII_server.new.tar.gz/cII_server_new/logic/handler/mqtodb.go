package handler

import (
	"adasgitlab.autel.com/tools/cuav_server/proto/mavlink"
	"fmt"
	"sync"
	"time"

	"gorm.io/gorm"

	"adasgitlab.autel.com/tools/cuav_server/proto/client"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	jsoniter "github.com/json-iterator/go"
	broker2 "go-micro.dev/v4/broker"

	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
	"adasgitlab.autel.com/tools/cuav_server/repo/utils"
)

var batchSize = 100
var storeLoadPosture = 0
var MaxLoad = 5
var RadarReplaySize = 20

func Consume() {
	consumeDeviceCommEvent()
	consumeRadarTcpHeartInfo()
	consumeRadarTcpTrackInfo()
	consumeRadarTcpPostureInfo()
	consumeDroneHeartInfo()
	consumeTracerHeartInfo()
	consumeTracerDetectInfo()
	//radar replay
	consumeReplayRadarHeartInfo()
	consumeReplayRadarPostureInfo()
	consumeReplayRadarDetectInfo()
	//tracerP/S replay
	consumeReplayTracerDetectInfo()
	consumeReplayTracerHeartInfo()
	//fpv replay
	consumeReplayFpvHeartInfo()
	consumeReplayFpvDetectInfo()
	//
	consumerReplayC2Config() //获取fpv. tracerS 时c2的经纬度
	//gun replay
	consumeReplayRFHeartInfo() //反制枪心跳包
	// sfl replay
	consumeReplaySFLInfo()
	// sfl101 replay
	consumeReplaySFL101Info()
	// gunCloud replay
	consumeReplayGunCloudInfo()
	//NSF400 replay
	consumeReplaySpooferHeartInfo()
	consumeReplaySpooferHeartInfoLLH()
	//urd360 replay
	consumeReplayUrd360()

	//
	consumeTransmit()
	// 调用写库日志
	NewNavySpooferUnionActionLog(1).WriteLog()
}

func createRadarHeartTable(sn string) {
	if sn == "" {
		return
	}

	tableName := common.BuildHeartTableName(sn) // 使用SN+当前日期作为新表名
	utils.CheckAndCreateTab[bean.RadarReplayHeart](db.GetDB(), tableName, &bean.RadarReplayHeart{}, 0)
	// 检查新表是否已存在，如果不存在则创建
}
func createRadarPostureTable(sn string) {
	if sn == "" {
		return
	}
	tableName := common.BuildPostureTableName(sn) // 使用SN+当前日期作为新表名

	utils.CheckAndCreateTab[bean.RadarReplayPosture](db.GetDB(), tableName, &bean.RadarReplayPosture{}, 0)
	//// 检查新表是否已存在，如果不存在则创建
}
func createRadarDetectTable(sn string) {
	if sn == "" {
		return
	}
	tableName := common.BuildDetectTableName(sn)

	existField := utils.WithColFieldCond2[bean.RadarReplayDetect](tableName, "Classification")(db.GetDB())
	if !existField {
		e := db.GetDB().Table(tableName).AutoMigrate(&bean.RadarReplayDetect{})
		if e != nil {
			logger.Errorf("add column fail, column name: Classification")
		}
	}

	// 检查新表是否已存在，如果不存在则创建
	if !db.GetDB().Migrator().HasTable(tableName) {
		err := db.GetDB().Table(tableName).AutoMigrate(&bean.RadarReplayDetect{})
		if err != nil {
			logger.Errorf("RadarReplayDetect create New Table:%v", err)
		}
		record := bean.RecordList{
			DevType:         int32(common.DEV_RADAR),
			DetectTableName: tableName,
		}
		if err = db.GetDB().Table(bean.RecordList{}.TableName()).Create(&record).Error; err != nil {
			logger.Errorf("Write To Db RecordList data, radar write to db fail, e: %v", err)
		}
	}
}
func createTracerDetectTable(sn string) {
	if sn == "" {
		return
	}
	tableName := common.BuildDetectTableName(sn) // 使用SN+当前日期作为新表名
	utils.CheckAndCreateTab[bean.TracerReplayDetect](db.GetDB(), tableName, &bean.TracerReplayDetect{}, 0)
}

type LoadYesterdayTracerReplay struct {
	lk              sync.Mutex
	snLoadYesterday map[string]bool
}

func (l *LoadYesterdayTracerReplay) IsLoad(sn string) bool {
	if l == nil || len(sn) <= 0 {
		return false
	}
	l.lk.Lock()
	defer l.lk.Unlock()

	if _, ok := l.snLoadYesterday[sn]; !ok {
		return false
	}
	if l.snLoadYesterday[sn] == true {
		return true
	}
	return false
}

func (l *LoadYesterdayTracerReplay) LoadYesterdayDetect(sn string, db *gorm.DB) bool {
	if len(sn) <= 0 || db == nil {
		return false
	}
	{
		l.lk.Lock()
		defer l.lk.Unlock()
		l.snLoadYesterday[sn] = true
	}
	return true
}

var loadYesterdayTracerReplayDetectTab *LoadYesterdayTracerReplay = &LoadYesterdayTracerReplay{
	snLoadYesterday: make(map[string]bool),
}

func needTransferTabScheme(sn string, db *gorm.DB) bool {
	checkLoad := loadYesterdayTracerReplayDetectTab.IsLoad(sn)
	if checkLoad {
		return true
	}

	loadYesterdayTracerReplayDetectTab.LoadYesterdayDetect(sn, db)
	yesterdayTime := time.Now().AddDate(0, 0, -1)
	yesterdayTab := common.BuildDetectTableName(sn, yesterdayTime)
	existField := utils.WithColFieldCond2[bean.TracerReplayDetect](yesterdayTab, "once_seq")(db)
	if existField == true {
		return true //不需要变换数据库
	}
	return false
}

func createTracerDetectTableV2(db *gorm.DB, sn string) {
	if len(sn) <= 0 {
		return
	}
	tableName := common.BuildDetectTableName(sn) // 使用SN+当前日期作为新表名
	utils.CheckTabCondCreateTab[bean.TracerReplayDetect](db, tableName, &bean.TracerReplayDetect{},
		utils.WithTableCond[bean.TracerReplayDetect](nil, tableName),
		func(db *gorm.DB) bool { return needTransferTabScheme(sn, db) })

}
func createSysConfigTable[T any](db *gorm.DB, sn string) {
	if sn == "" {
		return
	}
	tabName := common.BuildSysCfgTabName(sn)
	utils.CheckAndCreateTab[T](db, tabName, new(T), 0)
}
func createBusiHeartTable[T any](db *gorm.DB, sn string, devType int32) {
	if sn == "" {
		return
	}
	tableName := common.BuildHeartTableName(sn) // 使用SN+当前日期作为新表名
	utils.CheckAndCreateTab[T](db, tableName, new(T), devType)
	// 检查新表是否已存在，如果不存在则创建
}

func createBusiSflHitTable[T any](db *gorm.DB, sn string) {
	if sn == "" {
		return
	}
	tableName := common.BuildHitStatusTableName(sn) // 使用SN+当前日期作为新表名
	utils.CheckAndCreateTab[T](db, tableName, new(T), 0)
	// 检查新表是否已存在，如果不存在则创建
}
func createBusiSfl101HitTable[T any](db *gorm.DB, sn string) {
	if sn == "" {
		return
	}
	tableName := common.BuildHitStatusTableName(sn) // 使用SN+当前日期作为新表名
	utils.CheckAndCreateTab[T](db, tableName, new(T), 0)
	// 检查新表是否已存在，如果不存在则创建
}

func createBusiDetectTable[T any](db *gorm.DB, sn string, devType int32) {
	if sn == "" {
		return
	}
	tableName := common.BuildDetectTableName(sn) // 使用SN+当前日期作为新表名
	utils.CheckAndCreateTab[T](db, tableName, new(T), devType)
	// 检查新表是否已存在，如果不存在则创建
}

func delBusiHeartTable[T any](db *gorm.DB, sn string) {
	if sn == "" {
		return
	}
	tableName := common.BuildHeartTableName(sn) // 使用SN+当前日期作为新表名
	utils.CheckAndDeleteTab[T](db, tableName, new(T))
	// 检查新表是否已存在，如果不存在则创建
}
func createTracerHeartTable(db *gorm.DB, sn string) {
	if sn == "" {
		return
	}
	tableName := common.BuildHeartTableName(sn) // 使用SN+当前日期作为新表名
	utils.CheckAndCreateTab[bean.TracerReplayHeart](db, tableName, &bean.TracerReplayHeart{}, 0)
	// 检查新表是否已存在，如果不存在则创建
}
func consumeReplayRadarDetectInfo() {
	detectEntities := make([]bean.RadarReplayDetect, 0)
	mu := sync.Mutex{}
	_, _ = mq.RadarTrackBroker.Subscribe(mq.RadarTrackTopic, func(event broker2.Event) error {
		entity := common.EquipmentMessageBoxEntity{}
		err := jsoniter.Unmarshal(event.Message().Body, &entity)
		if err != nil {
			return fmt.Errorf("consumeReplayRadarDetectInfo Unmarshal error: %v", err)
		}
		infoJson, _ := jsoniter.Marshal(entity.Info)
		trackTarget := make([]bean.RadarTcpTrackTarget, 0)
		err = jsoniter.Unmarshal(infoJson, &trackTarget)
		if err != nil {
			return fmt.Errorf("consumeReplayRadarDetectInfo Unmarshal info error: %v", err)
		}

		mu.Lock()
		defer mu.Unlock()

		for i := 0; i < len(trackTarget); i++ {
			trackTarget[i].Sn = entity.Sn
			detectEntities = append(detectEntities, bean.RadarReplayDetect{
				Sn:             trackTarget[i].Sn,
				ObjId:          int(trackTarget[i].Obj_id),
				X:              trackTarget[i].X,
				Y:              trackTarget[i].Y,
				Z:              trackTarget[i].Z,
				Velocity:       trackTarget[i].Velocity,
				Azimuth:        trackTarget[i].Azimuth,
				Alive:          int(trackTarget[i].Alive),
				ExistingProb:   float64(trackTarget[i].ExistingProb),
				StateType:      int(trackTarget[i].State_type),
				CreateTime:     time.Now().UnixMilli(),
				Classification: int32(trackTarget[i].Classification),
				//t1 := time.Now().UnixMilli()
				//t := time.Unix(0, t1*int64(time.Millisecond))
				//
				//格式化时间对象为字符串
				//resTime := t.Format("2006-01-02 15:04:05.000")
			})
		}
		//批量保存 20条存一次
		//targetLen := len(detectEntities)

		//if targetLen > RadarReplaySize {
		createRadarDetectTable(entity.Sn)
		if err = db.GetDB().Table(bean.RadarReplayDetect{}.GetTableName(entity.Sn)).Create(&detectEntities).Error; err != nil {
			logger.Errorf("RadarReplayDetect create error:%v", err)
		}
		//这里不判断错误了，存不进就忽略
		detectEntities = detectEntities[0:0]
		//}

		return nil
	})
}

func consumeReplayRadarPostureInfo() {
	//姿态信息100ms一次
	postureEntities := make([]bean.RadarReplayPosture, 0, batchSize)
	mu := sync.Mutex{}
	_, _ = mq.RadarPostureBroker.Subscribe(mq.RadarPostureTopic, func(event broker2.Event) error {
		storeLoadPosture++
		if storeLoadPosture == MaxLoad {
			storeLoadPosture = 0
			entity := common.EquipmentMessageBoxEntity{}
			err := jsoniter.Unmarshal(event.Message().Body, &entity)
			if err != nil {
				return fmt.Errorf("consumeReplayRadarPostureInfo Unmarshal error: %v", err)
			}
			infoJson, _ := jsoniter.Marshal(entity.Info)
			posture := bean.RadarTcpPostureInfo{}
			err = jsoniter.Unmarshal(infoJson, &posture)
			if err != nil {
				return fmt.Errorf("consumeReplayRadarPostureInfo Unmarshal info error: %v", err)
			}
			posture.Sn = entity.Sn
			mu.Lock()
			defer mu.Unlock()
			postureEntities = append(postureEntities, bean.RadarReplayPosture{
				Sn:         posture.Sn,
				Heading:    posture.Heading,
				Pitching:   posture.Pitching,
				Rolling:    posture.Rolling,
				Longitude:  posture.Longitude,
				Latitude:   posture.Latitude,
				CreateTime: time.Now().UnixMilli(),
			})

			createRadarPostureTable(entity.Sn)
			err = db.GetDB().Table(bean.RadarReplayPosture{}.GetTableName(entity.Sn)).Create(&postureEntities).Error

			if err != nil {
				logger.Errorf("consumeReplayRadarPostureInfo create error: %v", err)
			}
			postureEntities = postureEntities[0:0]

		}
		return nil
	})
}

func consumeReplayRadarHeartInfo() {
	//雷达心跳1s一次
	heartEntities := make([]bean.RadarReplayHeart, 0, batchSize)
	mu := sync.Mutex{}
	_, _ = mq.EquipmentStatusBroker.Subscribe(mq.EquipmentStatusTopic, func(event broker2.Event) error {
		entity := common.EquipmentMessageBoxEntity{}
		err := jsoniter.Unmarshal(event.Message().Body, &entity)
		if err != nil {
			return fmt.Errorf("consumeRadarTcpHeartInfo Unmarshal error: %v", err)
		}
		if entity.MsgType == 0 {
			return nil
		}
		infoJson, _ := jsoniter.Marshal(entity.Info)
		heart := bean.RadarTcpHeart{}
		err = jsoniter.Unmarshal(infoJson, &heart)
		if err != nil {
			return fmt.Errorf("consumeRadarTcpHeartInfo Unmarshal info error: %v", err)
		}
		heart.Sn = entity.Sn
		mu.Lock()
		defer mu.Unlock()

		heartEntities = append(heartEntities, bean.RadarReplayHeart{
			Sn:          heart.Sn,
			IsOnline:    1, //1在线、2离线
			Electricity: int(heart.Electricity),
			CreateTime:  time.Now().UnixMilli(),
		})

		createRadarHeartTable(entity.Sn)
		if err = db.GetDB().Table(bean.RadarReplayHeart{}.GetTableName(entity.Sn)).Create(&heartEntities).Error; err != nil {

			logger.Errorf("consumeRadarTcpHeartInfo create error: %v", err)
		}
		heartEntities = heartEntities[0:0]

		return nil
	})
}

const (
	TracerIdGetDetectRes                = 0xE0
	TracerIdGetRemoteIdDetectRes        = 0xE1
	TracerIdGetFreqDetectRes            = 0xE2
	TracerIdGetDroneIdRemoteIdDetectRes = 0xEA
)

type TracerDetectReport struct {
	Sn          string                           `json:"sn"`
	Description []*TracerDetectDescriptionReport `json:"info"`
}
type TracerDetectDescriptionReport struct {
	ProductType        uint8   `json:"product_type"`         //无人机类型
	DroneName          string  `json:"drone_name"`           //无人机品牌+机型
	SerialNum          string  `json:"serial_num"`           //无人机Sn码
	DroneLongitude     float64 `json:"drone_longitude"`      //经度
	DroneLatitude      float64 `json:"drone_latitude"`       //纬度
	DroneHeight        float64 `json:"drone_height"`         //高度
	DroneYawAngle      float64 `json:"drone_yaw_angle"`      //偏航角
	DroneSpeed         float64 `json:"drone_speed"`          //速度
	DroneVerticalSpeed float64 `json:"drone_vertical_speed"` //垂直速度
	OperatorLongitude  float64 `json:"operator_longitude"`   //飞手经度
	OperatorLatitude   float64 `json:"operator_latitude"`    //飞手纬度
	Freq               float64 `json:"freq"`                 //频率
	Distance           uint16  `json:"distance"`             //距离
	DangerLevels       uint16  `json:"danger_levels"`        //危险等级
	Role               int32   `json:"role"`                 //无人机角色
}
type TracerRemoteDetectReport struct {
	Sn          string                                 `json:"sn"`
	Description []*TracerRemoteDetectDescriptionReport `json:"info"`
}
type TracerRemoteDetectDescriptionReport struct {
	ProductType         uint8   `json:"product_type"`         //无人机类型
	DroneName           string  `json:"drone_name"`           //无人机品牌+机型
	SerialNum           string  `json:"serial_num"`           //无人机Sn码
	DroneLongitude      float64 `json:"drone_longitude"`      //经度
	DroneLatitude       float64 `json:"drone_latitude"`       //纬度
	DroneHeight         float64 `json:"drone_height"`         //高度
	DroneDirection      float64 `json:"drone_direction"`      //无人机角度
	DroneYawAngle       float64 `json:"drone_yaw_angle"`      //偏航角
	DroneSpeed          float64 `json:"drone_speed"`          //速度
	DroneSpeedderection uint8   `json:"drone_speedderection"` //0:无人机向前 1:向后  2:向左  3:向右 4:垂直
	DroneVerticalSpeed  float64 `json:"drone_vertical_speed"` //垂直速度
	OperatorLongitude   float64 `json:"operator_longitude"`   //飞手经度
	OperatorLatitude    float64 `json:"operator_latitude"`    //飞手纬度
	Freq                float64 `json:"freq"`                 //频率
	Distance            uint16  `json:"distance"`             //距离
	DangerLevels        uint16  `json:"danger_levels"`        //危险等级
	Role                int32   `json:"role"`                 //无人机角色
}
type TracerFreqDetectReport struct {
	Sn          string                               `json:"sn"`
	QxPower     float64                              `json:"qx_power"`   //全向功率
	DxPower     float64                              `json:"dx_power"`   //定向功率
	DxHorizon   float64                              `json:"dx_horizon"` //定向天线水平角(0.01°)
	Description []*TracerFreqDetectDescriptionReport `json:"info"`
}
type TracerFreqDetectDescriptionReport struct {
	UavNumber     uint8   `json:"uav_number"`      //无人机编号
	DroneName     string  `json:"drone_name"`      //无人机品牌+机型
	DroneHorizon  float64 `json:"drone_horizon"`   //lsb 目标水平角（0.01°），无效值0x7fffffff
	UFreq         float64 `json:"u_freq"`          //频率
	UDangerLevels uint16  `json:"u_danger_levels"` //危险等级
	Recerve       int32   `json:"recerve"`         //保留
}
type TracerDronIdRemoteIdDetectReport struct {
	Sn          string                                         `json:"sn"`
	Description []*TracerDronIdRemoteIdDetectDescriptionReport `json:"info"`
}
type TracerDronIdRemoteIdDetectDescriptionReport struct {
	Name      string `json:"name"`      // 无人机名字
	SerialNum string `json:"serialNum"` // 无人机SN码
	// Uuid           string  `json:"uuid"`           // 无人机实名登记号
	Direction      float64 `json:"direction"`      // 无人机航向角度 (deg)
	Speed          float64 `json:"speed"`          // 无人机对地速度 (m/s)
	VerticalSpeed  float64 `json:"verticalSpeed"`  // 无人机垂直速度 (m/s)
	Height         float64 `json:"height"`         // 无人机距地高度 (m)
	Longitude      float64 `json:"longitude"`      // 无人机经度 (deg)
	Latitude       float64 `json:"latitude"`       // 无人机纬度 (deg)
	PilotLongitude float64 `json:"pilotLongitude"` // 无人机飞手经度 (deg)
	PilotLatitude  float64 `json:"pilotLatitude"`  // 无人机飞手纬度 (deg)
	HomeLongitude  float64 `json:"homeLongitude"`  // 无人机返航点经度 (deg)
	HomeLatitude   float64 `json:"homeLatitude"`   // 无人机返航点纬度 (deg)
	// RecordTime                uint32    `json:"recordTime"`                // 无人机已录取时间 (ms)
	AliveTime            uint32  `json:"aliveTime"`            //无人机生命周期 (ms) 1
	TargetMask           uint16  `json:"targetMask"`           // 后续目标信息字段来源掩码
	TypeCodeRid          uint16  `json:"typeCodeRid"`          // 无人机RemoteID类型码
	SeqNumRid            uint16  `json:"seqNumRid"`            // 无人机RemoteID信号序号
	ClassificationType   uint8   `json:"classificationType"`   // 无人机等级分类归属区域及取值
	OperationStatus      uint8   `json:"operationStatus"`      // 无人机运行状态
	OperatorLocationType uint8   `json:"operatorLocationType"` // 无人机操作员的位置类型及取值
	HeightType           uint8   `json:"heightType"`           //无人机高度类型： 0：基于起飞地的高度 1：基于AGL高度
	SignalFreqRid        uint32  `json:"signalFreqRid"`        // 无人机RemoteID信号频率(MHz)
	SignalPowerRid       int16   `json:"signalPowerRid"`       // 无人机RemoteID天线信号强度 (dBm)
	NoisePowerRid        int16   `json:"noisePowerRid"`        // 无人机RemoteID天线噪声强度 (dBm)
	TimestampRid         uint32  `json:"timestampRid"`         // 无人机RemoteID时间戳
	ReserveRid           uint32  `json:"reserveRid"`           // 预留字段
	TypeCodeDid          uint16  `json:"typeCodeDid"`          // 无人机DroneID类型码
	SeqNumDid            uint16  `json:"seqNumDid"`            // 无人机DroneID信号序号
	Altitude             float64 `json:"altitude"`             // 无人机海拔高度 (m)
	SpeedX               float64 `json:"speedX"`               // 无人机X方向速度 (m/s)
	SpeedY               float64 `json:"speedY"`               // 无人机Y方向速度 (m/s)
	SignalFreqDid        uint32  `json:"signalFreqDid"`        // 无人机DroneID信号频率(MHz)
	SignalPowerDidCh1    int16   `json:"signalPowerDidCh1"`    // 无人机DroneID信号强度(dBm),通道1
	SignalPowerDidCh2    int16   `json:"signalPowerDidCh2"`    // 无人机DroneID信号强度(dBm)，通道2
	GpsClock             uint64  `json:"gpsClock"`             // 无人机GPS时间戳
	ReserveDid           uint32  `json:"reserveDid"`           // 预留字段
	Role                 int32   `json:"role"`                 //无人机角色
}

const (
	//RemoteIDReplaySQL 数据回放前端区分remoteID 和 dronID
	RemoteIDReplaySQL         = 1
	droneIDReplaySQL          = 2
	DroneAndRemoteIDReplaySQL = 3
)

func consumeReplayTracerDetectInfo() {
	detectEntities := make([]bean.TracerReplayDetect, 0, batchSize)
	mu := sync.Mutex{}
	_, _ = mq.V2DroneIdBroker.Subscribe(mq.TracerDetectTopic, func(event broker2.Event) error {

		entity := common.EquipmentMessageBoxEntity{}
		err := jsoniter.Unmarshal(event.Message().Body, &entity)
		if err != nil {
			return fmt.Errorf("consumeReplayTracerDetectInfo Unmarshal error: %v", err)
		}
		infoJson, _ := jsoniter.Marshal(entity.Info)
		var sn string

		if entity.MsgType == TracerIdGetDetectRes { //drone ID
			drone := &TracerDetectReport{}
			err = jsoniter.Unmarshal(infoJson, &drone)
			if err != nil {
				return fmt.Errorf("consumeReplayTracerDetectInfo Unmarshal info error: %v", err)
			}

			mu.Lock()
			defer mu.Unlock()
			sn = drone.Sn
			for i := 0; i < len(drone.Description); i++ {

				distance := float64(drone.Description[i].Distance)
				distanceCache, e := GetDroneDistanceProcHandler().CalcDistance(drone.Description[i].DroneLongitude, drone.Description[i].DroneLatitude)
				if e == nil {
					distance = distanceCache
				}

				detectEntities = append(detectEntities, bean.TracerReplayDetect{
					Sn:                drone.Sn,
					OperatorLongitude: drone.Description[i].OperatorLongitude,
					OperatorLatitude:  drone.Description[i].OperatorLatitude,
					Freq:              drone.Description[i].Freq,
					Distance:          distance,
					DangerLevels:      int(drone.Description[i].DangerLevels),
					Role:              int(drone.Description[i].Role), //1-敌军 2-友军 3-未知 4-中立     批量导入为2友军
					DroneName:         drone.Description[i].DroneName,
					SerialNum:         drone.Description[i].SerialNum,
					DroneLongitude:    drone.Description[i].DroneLongitude,
					DroneLatitude:     drone.Description[i].DroneLatitude,
					DroneHeight:       drone.Description[i].DroneHeight,
					DroneSpeed:        drone.Description[i].DroneSpeed,
					DroneYawAngle:     drone.Description[i].DroneYawAngle,
					DetectSrcType:     droneIDReplaySQL,
					CreateTime:        time.Now().UnixMilli(),
				})
			}
		} else if entity.MsgType == TracerIdGetRemoteIdDetectRes {
			drone := &TracerRemoteDetectReport{}
			err = jsoniter.Unmarshal(infoJson, &drone)
			if err != nil {
				return fmt.Errorf("consumeReplayTracerRemoteDetectReport Unmarshal info error: %v", err)
			}

			mu.Lock()
			defer mu.Unlock()

			sn = drone.Sn

			for i := 0; i < len(drone.Description); i++ {
				distance := float64(drone.Description[i].Distance)
				distanceCache, e := GetDroneDistanceProcHandler().CalcDistance(drone.Description[i].DroneLongitude, drone.Description[i].DroneLatitude)
				if e == nil {
					distance = distanceCache
				}

				detectEntities = append(detectEntities, bean.TracerReplayDetect{
					Sn:                drone.Sn,
					OperatorLongitude: drone.Description[i].OperatorLongitude,
					OperatorLatitude:  drone.Description[i].OperatorLatitude,
					Freq:              drone.Description[i].Freq,
					Distance:          distance,
					DangerLevels:      int(drone.Description[i].DangerLevels),
					Role:              int(drone.Description[i].Role), //1-敌军 2-友军 3-未知 4-中立     批量导入为2友军
					DroneName:         drone.Description[i].DroneName,
					SerialNum:         drone.Description[i].SerialNum,
					DroneLongitude:    drone.Description[i].DroneLongitude,
					DroneLatitude:     drone.Description[i].DroneLatitude,
					DroneHeight:       drone.Description[i].DroneHeight,
					DroneSpeed:        drone.Description[i].DroneSpeed,
					DroneYawAngle:     drone.Description[i].DroneYawAngle,
					DetectSrcType:     RemoteIDReplaySQL,
					CreateTime:        time.Now().UnixMilli(),
				})
			}
		} else if entity.MsgType == TracerIdGetFreqDetectRes {
			drone := &TracerFreqDetectReport{}
			err = jsoniter.Unmarshal(infoJson, &drone)
			if err != nil {
				return fmt.Errorf("consumeReplayTracerRemoteDetectReport Unmarshal info error: %v", err)
			}

			mu.Lock()
			defer mu.Unlock()
			sn = drone.Sn

			tmpSeq := time.Now().UnixMilli()

			for i := 0; i < len(drone.Description); i++ {
				detectEntities = append(detectEntities, bean.TracerReplayDetect{
					Sn:           drone.Sn,
					Freq:         drone.Description[i].UFreq,
					DangerLevels: int(drone.Description[i].UDangerLevels),
					DroneName:    drone.Description[i].DroneName,
					DroneHorizon: drone.Description[i].DroneHorizon,

					QxPower:   drone.DxPower,
					DxPower:   drone.DxPower,
					DxHorizon: drone.DxHorizon,

					HasUav:  bean.FreqDetectUavHas,
					OnceSeq: tmpSeq, //用于识别一次

					CreateTime: time.Now().UnixMilli(),
				})
			}
		} else if entity.MsgType == TracerIdGetDroneIdRemoteIdDetectRes {
			drone := &TracerDronIdRemoteIdDetectReport{}
			err = jsoniter.Unmarshal(infoJson, &drone)
			if err != nil {
				return fmt.Errorf("consumeReplayTracerDronIdRemoteIdDetectReport Unmarshal info error: %v", err)
			}

			mu.Lock()
			defer mu.Unlock()

			sn = drone.Sn

			for i := 0; i < len(drone.Description); i++ {

				distance := float64(0.0)
				distanceCache, e := GetDroneDistanceProcHandler().CalcDistance(drone.Description[i].Longitude, drone.Description[i].Latitude)
				if e == nil {
					distance = distanceCache
				}

				detectEntities = append(detectEntities, bean.TracerReplayDetect{
					Sn:                drone.Sn,
					OperatorLongitude: drone.Description[i].PilotLongitude,
					OperatorLatitude:  drone.Description[i].PilotLatitude,
					Freq:              float64(drone.Description[i].SignalFreqRid),
					Distance:          distance,
					//DangerLevels:   int(drone.Description[i].DangerLevels),
					Role:                 int(drone.Description[i].Role), //1-敌军 2-友军 3-未知 4-中立     批量导入为2友军
					DroneName:            drone.Description[i].Name,
					SerialNum:            drone.Description[i].SerialNum,
					DroneLongitude:       drone.Description[i].Longitude,
					DroneLatitude:        drone.Description[i].Latitude,
					DroneHeight:          drone.Description[i].Height,
					DroneSpeed:           drone.Description[i].Speed,
					DroneYawAngle:        drone.Description[i].Direction,
					DetectSrcType:        DroneAndRemoteIDReplaySQL,
					HomeLongitude:        drone.Description[i].HomeLongitude,
					HomeLatitude:         drone.Description[i].HomeLatitude,
					AliveTime:            drone.Description[i].AliveTime,
					TargetMask:           drone.Description[i].TargetMask,
					TypeCodeRid:          drone.Description[i].TypeCodeDid,
					SeqNumRid:            drone.Description[i].SeqNumDid,
					ClassificationType:   drone.Description[i].ClassificationType,
					OperationStatus:      drone.Description[i].OperationStatus,
					OperatorLocationType: drone.Description[i].OperatorLocationType,
					HeightType:           drone.Description[i].HeightType,
					SignalFreqRid:        drone.Description[i].SignalFreqDid,
					SignalPowerRid:       drone.Description[i].SignalPowerRid,
					NoisePowerRid:        drone.Description[i].NoisePowerRid,
					TimestampRid:         drone.Description[i].TimestampRid,
					TypeCodeDid:          drone.Description[i].TypeCodeRid,
					SeqNumDid:            drone.Description[i].SeqNumRid,
					Altitude:             drone.Description[i].Altitude,
					SpeedX:               drone.Description[i].SpeedX,
					SpeedY:               drone.Description[i].SpeedY,
					SignalFreqDid:        drone.Description[i].SignalFreqRid,
					SignalPowerDidCh1:    drone.Description[i].SignalPowerDidCh1,
					SignalPowerDidCh2:    drone.Description[i].SignalPowerDidCh2,
					GpsClock:             drone.Description[i].GpsClock,
					CreateTime:           time.Now().UnixMilli(),
				})
			}
		} else {
			logger.Errorf("not support msg type: %v, not write db", entity.MsgType)
			return nil
		}
		if len(detectEntities) <= 0 {
			return nil
		}

		createTracerDetectTableV2(db.GetDB(), sn)
		if err = db.GetDB().Table(bean.TracerReplayDetect{}.GetTableName(sn)).Create(&detectEntities).Error; err != nil { //如何区分开设备类型。只能依赖app传递时携带etype.

			logger.Errorf("consumeReplayTracerDronIdRemoteIdDetectReport create heart error: %v", err)
		}
		detectEntities = detectEntities[0:0]

		return nil
	})
}

type DroneIDReport struct {
	TimeStamp     uint32 `json:"timeStamp"`
	Electricity   uint8  `json:"electricity"`
	Sn            string `json:"sn"`
	IsOnline      int    `json:"is_online"`
	BatteryStatus uint8  `json:"batteryStatus"` //0：电池 1：电池 + 适配器（充电） 2：适配器
	WorkMode      uint8  `json:"workMode"`      //工作模式 1:Droneid模式  2:全向侦测模式  3:定向侦测模式
	WorkStatus    uint8  `json:"workStatus"`    //TRACER工作状态 bit0~bit3: 0：待机 1: 侦测 5：水平扫描中 6：水平瞄准中 7：俯仰扫描中 8：俯仰瞄准中 9：瞄准完成 bit4: 0: 没有故障 1：有故障
	AlarmLevel    uint8  `json:"alarmLevel"`    //bit0~bit3: 0x00: 未检测到无人机，无报警 0x01: 一级报警 0x02: 二级报警 0x03: 三级报警 bit4: 0: 蜂鸣器不响 1：蜂鸣器响 bit5: 0：马达振动关闭 1：马达振动打开
}

func consumeReplayTracerHeartInfo() {
	//Tracer心跳
	heartEntities := make([]bean.TracerReplayHeart, 0, batchSize)
	mu := sync.Mutex{}
	_, _ = mq.V2DroneIdBroker.Subscribe(mq.V2DroneIdTopic, func(event broker2.Event) error {
		entity := common.EquipmentMessageBoxEntity{}
		err := jsoniter.Unmarshal(event.Message().Body, &entity)
		if err != nil {
			return fmt.Errorf("consumeRadarTcpHeartInfo Unmarshal error: %v", err)
		}
		if entity.MsgType == 0 {
			return nil
		}
		infoJson, _ := jsoniter.Marshal(entity.Info)
		heart := &DroneIDReport{}
		err = jsoniter.Unmarshal(infoJson, &heart)
		if err != nil {
			return fmt.Errorf("consumeRadarTcpHeartInfo Unmarshal info error: %v", err)
		}
		heart.Sn = entity.Sn
		mu.Lock()
		defer mu.Unlock()

		heartEntities = append(heartEntities, bean.TracerReplayHeart{
			Sn:          heart.Sn,
			IsOnline:    heart.IsOnline, //1在线、2离线
			Electricity: int(heart.Electricity),
			WorkMode:    int(heart.WorkMode),
			WorkStatus:  int(heart.WorkStatus),
			AlarmLevel:  int(heart.AlarmLevel),
			CreateTime:  time.Now().UnixMilli(),
		})
		createTracerHeartTable(db.GetDB(), entity.Sn)
		if err = db.GetDB().Table(bean.TracerReplayHeart{}.GetTableName(entity.Sn)).Create(&heartEntities).Error; err != nil {
			logger.Errorf("consumeTracerReplayHeartInfo create error: %v", err)
		}
		heartEntities = heartEntities[0:0]
		return nil
	})
}

func consumeRadarTcpHeartInfo() {
	heartEntities := make([]bean.RadarTcpHeart, 0, batchSize)
	mu := sync.Mutex{}
	_, _ = mq.EquipmentStatusBroker.Subscribe(mq.EquipmentStatusTopic, func(event broker2.Event) error {
		if StopCacheDB > 0 {
			return nil
		}
		entity := common.EquipmentMessageBoxEntity{}
		err := jsoniter.Unmarshal(event.Message().Body, &entity)
		if err != nil {
			return fmt.Errorf("consumeRadarTcpHeartInfo Unmarshal error: %v", err)
		}
		if entity.MsgType == 0 {
			return nil
		}
		infoJson, _ := jsoniter.Marshal(entity.Info)
		heart := bean.RadarTcpHeart{}
		err = jsoniter.Unmarshal(infoJson, &heart)
		if err != nil {
			return fmt.Errorf("consumeRadarTcpHeartInfo Unmarshal info error: %v", err)
		}
		heart.Sn = entity.Sn
		mu.Lock()
		defer mu.Unlock()
		heartEntities = append(heartEntities, heart)
		if len(heartEntities) >= batchSize {
			if err = db.GetDB().Table(bean.RadarTcpHeart{}.TableName()).Create(&heartEntities).Error; err != nil {
				logger.Errorf("consumeRadarTcpHeartInfo create error: %v", err)
			}
			heartEntities = heartEntities[0:0]
		}
		return nil
	})
}

func consumeRadarTcpTrackInfo() {
	trackEntities := make([]bean.RadarTcpTrackInfo, 0, batchSize)
	targetEntities := make([]bean.RadarTcpTrackTarget, 0)
	mu := sync.Mutex{}
	_, _ = mq.RadarTrackBroker.Subscribe(mq.RadarTrackTopic, func(event broker2.Event) error {
		if StopCacheDB > 0 {
			return nil
		}
		entity := common.EquipmentMessageBoxEntity{}
		err := jsoniter.Unmarshal(event.Message().Body, &entity)
		if err != nil {
			return fmt.Errorf("consumeRadarTcpTrackInfo Unmarshal error: %v", err)
		}
		infoJson, _ := jsoniter.Marshal(entity.Info)
		trackTarget := make([]bean.RadarTcpTrackTarget, 0)
		err = jsoniter.Unmarshal(infoJson, &trackTarget)
		if err != nil {
			return fmt.Errorf("consumeRadarTcpTrackInfo Unmarshal info error: %v", err)
		}
		uid := utils.SnowFlakeNode.Generate().Int64()
		trackInfo := bean.RadarTcpTrackInfo{
			Uid:          uid,
			Sn:           entity.Sn,
			ReceivedTime: time.Now().UnixMilli(),
		}
		mu.Lock()
		defer mu.Unlock()
		trackEntities = append(trackEntities, trackInfo)
		for i := 0; i < len(trackTarget); i++ {
			trackTarget[i].HeaderUid = uid
			trackTarget[i].Sn = entity.Sn
			trackTarget[i].Create_time = string(rune(time.Now().UnixMilli()))
			targetEntities = append(targetEntities, trackTarget[i])
		}
		//批量保存
		targetLen := len(targetEntities)
		trackLen := len(trackEntities)
		if trackLen >= batchSize || targetLen > batchSize*5 {
			if err = db.GetDB().Table(bean.RadarTcpTrackInfo{}.TableName()).Create(&trackEntities).Error; err != nil {
				logger.Errorf("RadarTcpTrackInfo create error:%v", err)
			}
			if err = db.GetDB().Table(bean.RadarTcpTrackTarget{}.TableName()).Create(&targetEntities).Error; err != nil {
				logger.Errorf("RadarTcpTrackTarget create error:%v", err)
			}
			//这里不判断错误了，存不进就忽略
			trackEntities = trackEntities[0:0]
			targetEntities = targetEntities[0:0]
		}
		return nil
	})
}

func consumeRadarTcpPostureInfo() {
	postureEntities := make([]bean.RadarTcpPostureInfo, 0, batchSize)
	mu := sync.Mutex{}
	_, _ = mq.RadarPostureBroker.Subscribe(mq.RadarPostureTopic, func(event broker2.Event) error {
		if StopCacheDB > 0 {
			return nil
		}
		entity := common.EquipmentMessageBoxEntity{}
		err := jsoniter.Unmarshal(event.Message().Body, &entity)
		if err != nil {
			return fmt.Errorf("consumeRadarTcpPostureInfo Unmarshal error: %v", err)
		}
		infoJson, _ := jsoniter.Marshal(entity.Info)
		posture := bean.RadarTcpPostureInfo{}
		err = jsoniter.Unmarshal(infoJson, &posture)
		if err != nil {
			return fmt.Errorf("consumeRadarTcpPostureInfo Unmarshal info error: %v", err)
		}
		posture.Sn = entity.Sn
		posture.Heading = posture.Heading - float64(TempHeading)
		mu.Lock()
		defer mu.Unlock()
		postureEntities = append(postureEntities, posture)
		if len(postureEntities) >= batchSize {
			err = db.GetDB().Table(bean.RadarTcpPostureInfo{}.TableName()).Create(&postureEntities).Error
			if err != nil {
				logger.Errorf("consumeRadarTcpPostureInfo create error: %v", err)
			}
			postureEntities = postureEntities[0:0]
		}
		return nil
	})
}

func consumeDroneHeartInfo() {
	heartEntities := make([]bean.GunTcpHeart, 0, batchSize)
	droneEntities := make([]bean.GunTcpHeartUav, 0)
	mu := sync.Mutex{}
	_, _ = mq.GunDroneIdBroker.Subscribe(mq.GunDroneIdTopic, func(event broker2.Event) error {
		if StopCacheDB > 0 {
			return nil
		}
		entity := common.EquipmentMessageBoxEntity{}
		err := jsoniter.Unmarshal(event.Message().Body, &entity)
		if err != nil {
			return fmt.Errorf("consumeDroneHeartInfo Unmarshal error: %v", err)
		}
		infoJson, _ := jsoniter.Marshal(entity.Info)
		drone := &DroneIdHeartBeat{}
		err = jsoniter.Unmarshal(infoJson, &drone)
		if err != nil {
			return fmt.Errorf("consumeDroneHeartInfo Unmarshal info error: %v", err)
		}
		uid := utils.SnowFlakeNode.Generate().Int64()
		heart := bean.GunTcpHeart{
			HeaderId:       uid,
			TimeStamp:      drone.TimeStamp,
			ScreenStatus:   drone.ScreenStatus,
			Electricity:    drone.Electricity,
			SignalStrength: drone.SignalStrength,
			WorkStatus:     drone.WorkStatus,
			AlarmLevel:     drone.AlarmLevel,
			HitFreq:        drone.HitFreq,
			DetectFreq:     drone.DetectFreq,
			X:              drone.X,
			Y:              drone.Y,
			Z:              drone.Z,
			GunLongitude:   drone.GunLongitude,
			GunLatitude:    drone.GunLatitude,
			GunAltitude:    drone.GunAltitude,
			SatellitesNum:  drone.SatellitesNum,
			GunDirection:   drone.GunDirection,
			Elevation:      drone.Elevation,
			UDroneNum:      drone.UDroneNum,
			ReceivedTime:   time.Now().UnixMilli(),
		}
		mu.Lock()
		defer mu.Unlock()
		heartEntities = append(heartEntities, heart)
		for i := 0; i < len(drone.Info); i++ {
			drone.Info[i].HeaderId = uid
			droneEntities = append(droneEntities, drone.Info[i])
		}
		heartLen := len(heartEntities)
		droneLen := len(droneEntities)
		if heartLen >= batchSize || droneLen > batchSize*5 {
			if err = db.GetDB().Table(bean.GunTcpHeart{}.TableName()).Create(&heartEntities).Error; err != nil {
				logger.Errorf("consumeDroneHeartInfo create heart error: %v", err)
			}
			if droneLen > 0 {
				if err = db.GetDB().Table(bean.GunTcpHeartUav{}.TableName()).Create(&droneEntities).Error; err != nil {
					logger.Errorf("consumeDroneHeartInfo create uav error: %v", err)
				}
			}
			heartEntities = heartEntities[0:0]
			droneEntities = droneEntities[0:0]
		}
		return nil
	})
}

type DroneIdHeartBeat struct {
	TimeStamp      uint32                `json:"timeStamp"`
	ScreenStatus   uint8                 `json:"screenStatus"`
	Electricity    uint8                 `json:"electricity"`
	SignalStrength uint8                 `json:"signalStrength"`
	WorkStatus     uint8                 `json:"workStatus"`
	AlarmLevel     uint8                 `json:"alarmLevel"`
	HitFreq        uint8                 `json:"hitFreq"`
	DetectFreq     uint32                `json:"detectFreq"`
	X              uint16                `json:"x"`
	Y              uint16                `json:"y"`
	Z              uint16                `json:"z"`
	GunLongitude   float64               `json:"gunLongitude"`
	GunLatitude    float64               `json:"gunLatitude"`
	GunAltitude    int32                 `json:"gunAltitude"`
	SatellitesNum  uint16                `json:"satellitesNum"`
	GunDirection   float64               `json:"gunDirection"`
	UDroneNum      uint8                 `json:"uDroneNum"`
	Elevation      float64               `json:"elevation"`
	Info           []bean.GunTcpHeartUav `json:"info"`
}

func consumeDeviceCommEvent() {
	_, _ = mq.DeviceCommEventBroker.Subscribe(mq.DeviceCommEventTopic, func(event broker2.Event) error {
		if StopCacheDB > 0 {
			return nil
		}
		entity := common.EquipmentMessageBoxEntity{}
		err := jsoniter.Unmarshal(event.Message().Body, &entity)
		if err != nil {
			return fmt.Errorf("consumeDeviceCommEvent Unmarshal error: %v", err)
		}
		infoJson, _ := jsoniter.Marshal(entity.Info)
		commLog := &bean.DeviceCommLog{}
		err = jsoniter.Unmarshal(infoJson, commLog)
		if err != nil {
			return fmt.Errorf("consumeDeviceCommEvent Unmarshal info error: %v", err)
		}
		if commLog != nil {
			err = db.GetDB().Table(bean.DeviceCommLog{}.TableName()).Create(commLog).Error
			if err != nil {
				logger.Errorf("consumeDeviceCommEvent create error:%v", err)
			}
		}
		return nil
	})
}

func consumeTracerHeartInfo() {
	heartEntities := make([]bean.TracerTcpHeart, 0, batchSize)
	droneEntities := make([]bean.TracerTcpHeartUav, 0)
	mu := sync.Mutex{}
	_, _ = mq.V2DroneIdBroker.Subscribe(mq.V2DroneIdTopic, func(event broker2.Event) error {
		if StopCacheDB > 0 {
			return nil
		}
		entity := common.EquipmentMessageBoxEntity{}
		err := jsoniter.Unmarshal(event.Message().Body, &entity)
		if err != nil {
			return fmt.Errorf("consumeTracerHeartInfo Unmarshal error: %v", err)
		}
		infoJson, _ := jsoniter.Marshal(entity.Info)
		drone := &TracerHeartBeat{}
		err = jsoniter.Unmarshal(infoJson, &drone)
		if err != nil {
			return fmt.Errorf("consumeTracerHeartInfo Unmarshal info error: %v", err)
		}
		uid := utils.SnowFlakeNode.Generate().Int64()
		heart := bean.TracerTcpHeart{
			HeaderId:       uid,
			TimeStamp:      drone.TimeStamp,
			ScreenStatus:   drone.ScreenStatus,
			Electricity:    drone.Electricity,
			SignalStrength: drone.SignalStrength,
			WorkStatus:     drone.WorkStatus,
			AlarmLevel:     drone.AlarmLevel,
			HitFreq:        drone.HitFreq,
			DetectFreq:     drone.DetectFreq,
			Elevation:      drone.Elevation,
			GunLongitude:   drone.GunLongitude,
			GunLatitude:    drone.GunLatitude,
			GunAltitude:    drone.GunAltitude,
			SatellitesNum:  drone.SatellitesNum,
			GunDirection:   drone.GunDirection,
			Sn:             drone.Sn,
			UDroneNum:      drone.UDroneNum,
			ReceivedTime:   time.Now().UnixMilli(),
		}
		mu.Lock()
		defer mu.Unlock()
		heartEntities = append(heartEntities, heart)
		for i := 0; i < len(drone.Info); i++ {
			drone.Info[i].HeaderId = uid
			droneEntities = append(droneEntities, drone.Info[i])
		}
		heartLen := len(heartEntities)
		droneLen := len(droneEntities)
		if heartLen >= batchSize || droneLen > batchSize*5 {
			if err = db.GetDB().Table(bean.TracerTcpHeart{}.TableName()).Create(&heartEntities).Error; err != nil {
				logger.Errorf("consumeTracerHeartInfo create heart error: %v", err)
			}
			if droneLen > 0 {
				if err = db.GetDB().Table(bean.TracerTcpHeartUav{}.TableName()).Create(&droneEntities).Error; err != nil {
					logger.Errorf("consumeTracerHeartInfo create uav error: %v", err)
				}
			}
			heartEntities = heartEntities[0:0]
			droneEntities = droneEntities[0:0]
		}
		return nil
	})
}

type TracerHeartBeat struct {
	TimeStamp      uint32                   `json:"timeStamp"`
	ScreenStatus   uint8                    `json:"screen_status"`
	Electricity    uint8                    `json:"electricity"`
	SignalStrength uint8                    `json:"signal_strength"`
	WorkStatus     uint8                    `json:"work_status"`
	AlarmLevel     uint8                    `json:"alarm_level"`
	HitFreq        uint8                    `json:"hit_freq"`
	DetectFreq     uint32                   `json:"detect_freq"`
	Elevation      float64                  `json:"elevation"`
	GunLongitude   float64                  `json:"gun_longitude"`
	GunLatitude    float64                  `json:"gun_latitude"`
	GunAltitude    int32                    `json:"gun_altitude"`
	SatellitesNum  uint16                   `json:"satellites_num"`
	GunDirection   float64                  `json:"gun_direction"`
	Sn             string                   `json:"sn"`
	UDroneNum      uint8                    `json:"u_drone_num"`
	Info           []bean.TracerTcpHeartUav `json:"info"`
}
type TracerDetect struct {
	Sn          string                  `json:"sn"`
	Description []bean.TracerDetectInfo `json:"info"`
}

func consumeTracerDetectInfo() {
	droneEntities := make([]bean.TracerDetectInfo, 0)
	mu := sync.Mutex{}
	_, _ = mq.TracerDetectBroker.Subscribe(mq.TracerDetectTopic, func(event broker2.Event) error {
		if StopCacheDB > 0 {
			return nil
		}
		entity := common.EquipmentMessageBoxEntity{}
		err := jsoniter.Unmarshal(event.Message().Body, &entity)
		if err != nil {
			logger.Errorf("consumeTracerDetectInfo Unmarshal error: %v", err)
			return fmt.Errorf("consumeTracerDetectInfo Unmarshal error: %v", err)
		}
		infoJson, _ := jsoniter.Marshal(entity.Info)
		drone := &TracerDetect{}
		err = jsoniter.Unmarshal(infoJson, &drone)
		if err != nil {
			logger.Errorf("consumeTracerDetectInfo Unmarshal error: %v", err)
			return fmt.Errorf("consumeTracerDetectInfo Unmarshal info error: %v", err)
		}
		uid := utils.SnowFlakeNode.Generate().Int64()

		mu.Lock()
		defer mu.Unlock()

		for i := 0; i < len(drone.Description); i++ {
			drone.Description[i].DetectId = uid
			drone.Description[i].ReceivedTime = time.Now().UnixMilli()
			droneEntities = append(droneEntities, drone.Description[i])
		}

		droneLen := len(droneEntities)
		if droneLen > batchSize*5 {
			if droneLen > 0 {
				if err = db.GetDB().Table(bean.TracerDetectInfo{}.TableName()).Create(&droneEntities).Error; err != nil {
					logger.Errorf("consumeTracerDetectInfo create uav error: %v", err)
				}
			}
			droneEntities = droneEntities[0:0]
		}
		return nil
	})
}

func consumerReplayC2CfgTracerS(mu *sync.Mutex, dstItem *client.CrudReq) {
	if mu == nil || dstItem == nil {
		return
	}

	sysCfgEntities := make([]bean.TracerSReplaySysConfigData, 0, batchSize) //暂时放弃批量写的能力

	tracerSList, proList, tracerPList := GetOnlineTracerSSn()
	if len(tracerSList) <= 0 && len(proList) <= 0 && len(tracerPList) <= 0 {
		return
	}

	logger.Infof("get tracerS sn: %v, proList: %v, ptracer: %v", tracerSList, proList, tracerPList)

	mu.Lock()
	defer mu.Unlock()

	for _, sn := range tracerSList {
		sysCfgEntities = append(sysCfgEntities, bean.TracerSReplaySysConfigData{
			Sn:          sn,
			C2Longitude: dstItem.GetC2Longitude(),
			C2Latitude:  dstItem.GetC2Latitude(),
			CreateTime:  time.Now().UnixMilli(),
		})

		createSysConfigTable[bean.TracerSReplaySysConfigData](db.GetDB(), sn)
		if err := db.GetDB().Table(bean.TracerSReplaySysConfigData{}.TableName(sn)).Create(&sysCfgEntities).Error; err != nil {
			logger.Errorf("consume tracerS sys cfg data, write to db fail, e: %v", err)
		}
	}

	for _, sn := range proList {
		sysCfgEntities = append(sysCfgEntities, bean.TracerSReplaySysConfigData{
			Sn:          sn,
			C2Longitude: dstItem.GetC2Longitude(),
			C2Latitude:  dstItem.GetC2Latitude(),
			CreateTime:  time.Now().UnixMilli(),
		})

		createSysConfigTable[bean.TracerSReplaySysConfigData](db.GetDB(), sn)
		if err := db.GetDB().Table(bean.TracerSReplaySysConfigData{}.TableName(sn)).Create(&sysCfgEntities).Error; err != nil {
			logger.Errorf("consume tracerPro sys cfg data, write to db fail, e: %v", err)
		}
	}

	for _, sn := range tracerPList { //tracerP 使用tracerS的存储
		sysCfgEntities = append(sysCfgEntities, bean.TracerSReplaySysConfigData{
			Sn:          sn,
			C2Longitude: dstItem.GetC2Longitude(),
			C2Latitude:  dstItem.GetC2Latitude(),
			CreateTime:  time.Now().UnixMilli(),
		})

		createSysConfigTable[bean.TracerSReplaySysConfigData](db.GetDB(), sn)
		if err := db.GetDB().Table(bean.TracerSReplaySysConfigData{}.TableName(sn)).Create(&sysCfgEntities).Error; err != nil {
			logger.Errorf("consume tracerP sys cfg data, write to db fail, e: %v", err)
		}
	}
	return
}

func consumeTransmit() {
	_, _ = mq.V2DroneIdBroker.Subscribe(mq.TracerDetectTopic, func(event broker2.Event) error {
		entity := common.EquipmentMessageBoxEntity{}
		err := jsoniter.Unmarshal(event.Message().Body, &entity)
		if err != nil {
			return fmt.Errorf("consumeTransmit Unmarshal error: %v", err)
		}
		infoJson, _ := jsoniter.Marshal(entity.Info)

		if entity.MsgType == mavlink.TracerIdGetUasSystemInfoRes {
			logger.Info("consumeTransmit TracerIdGetUasSystemInfoRes")
			drone := &mavlink.TracerDetectUavSystemDataReport{}
			err = jsoniter.Unmarshal(infoJson, &drone)
			if err != nil {
				logger.Errorf("consumeTransmit Unmarshal info error: %v", err)
				return fmt.Errorf("consumeTransmit Unmarshal info error: %v", err)
			}
			r := &mavlink.TracerPSendToAGX{}
			r.Upload = drone.Description
			go NewDeviceCenter().TracerPToAgx(r)

		}

		return nil
	})
}

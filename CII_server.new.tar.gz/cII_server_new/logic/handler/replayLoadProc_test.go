package handler

import (
	"context"
	"github.com/stretchr/testify/assert"
	"testing"
	"time"
)

func TestBigCache(t *testing.T) {

	toExpiredTime := 5 * time.Second
	toDelExpiredTime := 10 * time.Second
	//
	ctx := context.Background()
	localM := InitLocalMem(ctx, WithLocalMemCfgShare(8), WithLocalMemCfgLifWin(toExpiredTime), WithLocalMemCfgCleanWin(toDelExpiredTime), WithHardMaxCacheSize(10))
	assert.NotNil(t, localM)

	dataSets := []struct {
		tKey   string
		tValue string
	}{
		{tKey: "a1", tValue: "v1"},
		{tKey: "a2", tValue: "v2"},
		{tKey: "a3", tValue: "v3"},
		{tKey: "a4", tValue: "v4"},
		{tKey: "a5", tValue: "v5"},
		{tKey: "a6", tValue: "v6"},
	}

	for _, item := range dataSets {
		localM.Set(item.tKey, []byte(item.tValue))
	}
	//数据没有过期
	time.Sleep(1 * 100 * time.Millisecond)
	t.Logf("1) cache nums: %v, cap: %v", localM.cache.Len(), localM.cache.Capacity())
	for _, item := range dataSets {
		v, _ := localM.Get(item.tKey)
		assert.Equal(t, string(v), item.tValue)
	}
	//数据过期但没有到删除过期记录时间,数据有可能获取不到。
	time.Sleep(toExpiredTime + 1*time.Second)
	for _, item := range dataSets {
		v, _ := localM.Get(item.tKey)
		if string(v) == item.tValue || len(v) <= 0 {
			t.Logf("v: %v", string(v))
			assert.NotNil(t, true)
		}
	}
	t.Logf("2) cache nums: %v, cap: %v", localM.cache.Len(), localM.cache.Capacity())

	//过期且超过删除的时间，数据将被删除。数据一定再获取不到了。
	time.Sleep(toExpiredTime + toDelExpiredTime + 10*time.Second)
	for _, item := range dataSets {
		v, _ := localM.Get(item.tKey)
		//因为超过 toExpiredTime + toDelExpiredTime， 所以数据将会被删除，从里面获取的数据为空。
		assert.Equal(t, string(v), "")
	}
	t.Logf("3) cache nums: %v, cap: %v", localM.cache.Len(), localM.cache.Capacity())
}

func TestBigCacheDel(t *testing.T) {
	toExpiredTime := 5 * time.Second
	toDelExpiredTime := 10 * time.Second
	//
	ctx := context.Background()
	localM := InitLocalMem(ctx, WithLocalMemCfgShare(8), WithLocalMemCfgLifWin(toExpiredTime), WithLocalMemCfgCleanWin(toDelExpiredTime), WithHardMaxCacheSize(10))
	assert.NotNil(t, localM)

	dataSets := []struct {
		tKey   string
		tValue string
	}{
		{tKey: "a1", tValue: "v1"},
		{tKey: "a2", tValue: "v2"},
		{tKey: "a3", tValue: "v3"},
		{tKey: "a4", tValue: "v4"},
		{tKey: "a5", tValue: "v5"},
		{tKey: "a6", tValue: "v6"},
	}

	for _, item := range dataSets {
		localM.Set(item.tKey, []byte(item.tValue))
	}
	//数据没有过期
	time.Sleep(100 * time.Millisecond)
	t.Logf("1) cache nums: %v, cap: %v", localM.cache.Len(), localM.cache.Capacity())
	for _, item := range dataSets {
		v, _ := localM.Get(item.tKey)
		assert.Equal(t, string(v), item.tValue)
	}

	for _, item := range dataSets {
		t.Logf("before del, cache nums: %v", localM.cache.Len())
		//边删除， 边检查数据:
		e := localM.Delete(item.tKey)
		assert.Nil(t, e)

		//检查数据是否存在:
		originV, e := localM.Get(item.tKey)
		assert.Equal(t, len(originV), 0)
		t.Logf("after del, cache nums: %v", localM.cache.Len())
	}
}

func TestGetShardsNums(t *testing.T) {
	testDataShards := []struct {
		originShardNums int
		dstShardNums    int
	}{
		{originShardNums: 1, dstShardNums: 2},
		{originShardNums: 2, dstShardNums: 2},
		{originShardNums: 3, dstShardNums: 2},
		{originShardNums: 4, dstShardNums: 4},
		{originShardNums: 5, dstShardNums: 4},
		{originShardNums: 6, dstShardNums: 4},
		{originShardNums: 7, dstShardNums: 4},
		{originShardNums: 8, dstShardNums: 8},
		{originShardNums: 9, dstShardNums: 8},
		{originShardNums: 10, dstShardNums: 8},
		{originShardNums: 11, dstShardNums: 8},
		{originShardNums: 12, dstShardNums: 8},
		{originShardNums: 13, dstShardNums: 8},
		{originShardNums: 14, dstShardNums: 8},
		{originShardNums: 15, dstShardNums: 8},
		{originShardNums: 16, dstShardNums: 16},
		{originShardNums: 129, dstShardNums: 128},
	}

	for _, v := range testDataShards {
		t.Run("test..", func(tt *testing.T) {
			assert.Equal(tt, GetShardsNums(v.originShardNums), v.dstShardNums)
		})
	}
}

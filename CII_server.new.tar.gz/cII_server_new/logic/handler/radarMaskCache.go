package handler

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"gorm.io/gorm"

	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
)

type RadarMaskModel struct{}

func NewRadarMaskModel() *RadarMaskModel {
	return &RadarMaskModel{}
}

func (m *RadarMaskModel) Insert(sn, masks string, allDelete bool, allDelVal int32) error {
	_, err := m.First(sn)
	if err != nil {
		if err == gorm.ErrRecordNotFound {
			maskModel := bean.RadarMask{
				Sn:             sn,
				AllDelete:      allDelete,
				Masks:          masks,
				AllDeleteValue: allDelVal,
			}
			//插入
			if err := db.GetDB().Model(&bean.RadarMask{}).Create(&maskModel).Error; err != nil {
				logger.Errorf("Insert Create err: %v", err)
				return err
			}
			return nil
		}
		logger.Errorf("Insert First err: %v", err)
		return err
	}
	//更新
	//gorm updates零值不更新
	field := map[string]interface{}{
		"sn":               sn,
		"all_delete":       allDelete,
		"masks":            masks,
		"all_delete_value": allDelVal,
	}
	return db.GetDB().Model(&bean.RadarMask{}).Where("sn = ?", sn).Updates(&field).Error
}

func (m *RadarMaskModel) First(sn string) (*bean.RadarMask, error) {
	var radarMask bean.RadarMask
	err := db.GetDB().Model(&bean.RadarMask{}).Where("sn = ?", sn).First(&radarMask).Error
	return &radarMask, err
}

func (m *RadarMaskModel) Delete(sn string) error {
	return db.GetDB().Model(&bean.RadarMask{}).Where("sn = ?", sn).Delete(&bean.RadarMask{}).Error
}

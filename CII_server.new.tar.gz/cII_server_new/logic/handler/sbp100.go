package handler

import (
	"errors"
	"fmt"
	"strconv"
	"strings"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"github.com/samber/lo"

	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/proto/mavlink"
)

var (
	// sbp100 sn —> uav objId -> laser sn 存储下发指定目标给激光设备
	status = map[string]map[int32]string{}
	// sbp100 sn -> laser sn
	modeChangeFlag = map[string]string{}
)

// notice：激光不入库，通过sbp100转发消息
type Sbp100 struct {
	*Agx
	dt common.DeviceType
}

func (s *Sbp100) Sbp100TurnOnOff(req *client.Sbp100TurnOnOffRequest, rsp *client.Sbp100TurnOnOffResponse) error {
	//1：ATP 上电
	//2：ATP 断电
	//3：激光器上电
	//4：激光器断电
	var (
		statesNotExist bool
		atpPowerSet    bool //ATPPowerFlag 是否为true
		laserPowerSet  bool //LaserPowerFlag 是否为true
	)

	request := &mavlink.CommandControl{}
	switchStatus := int(req.SwitchStatus) //1:开启 2:关闭
	if switchStatus != 1 && switchStatus != 2 {
		logger.Errorf("Sbp100TurnOnOff param err: %v", req)
		return fmt.Errorf("param SwitchStatus err, only support [1,2], but got %d", switchStatus)
	}
	stateResp, err := s.GetLaserStates(req.Sn, false)
	if err != nil {
		logger.Error("Sbp100TurnOnOff GetLaserStates err1: ", err)
		return err
	}
	if stateResp == nil {
		statesNotExist = true
	}
	if stateResp != nil {
		aTPPowerFlag := stateResp.ATPPowerFlag
		laserPowerFlag := stateResp.LaserPowerFlag
		if aTPPowerFlag == nil || *aTPPowerFlag == false {
			atpPowerSet = true
		}
		if laserPowerFlag == nil || *laserPowerFlag == false {
			laserPowerSet = true
		}

	}
	//开关开启，需保证 1：ATP 上电 3：激光器上电
	if switchStatus == 1 {
		if statesNotExist || (atpPowerSet == true && laserPowerSet == true) {
			request.Control = &mavlink.Control{}
			request.Control.Power = &switchStatus //1:ATP 上电
			if err := s.sendControl(req.Sn, request); err != nil {
				logger.Error("Sbp100TurnOnOff sendControl ATP 上电 err1: ", err)
				return err
			}
			request.Control.Power = lo.ToPtr(3) //3:激光器上电
			if err := s.sendControl(req.Sn, request); err != nil {
				logger.Error("Sbp100TurnOnOff sendControl 激光器上电 err1: ", err)
				return err
			}
		} else if atpPowerSet == false && laserPowerSet == true {
			request.Control.Power = lo.ToPtr(3) //3:激光器上电
			if err := s.sendControl(req.Sn, request); err != nil {
				logger.Error("Sbp100TurnOnOff sendControl 激光器上电 err2: ", err)
				return err
			}
		} else if atpPowerSet == true && laserPowerSet == false {
			request.Control = &mavlink.Control{}
			request.Control.Power = &switchStatus //1:ATP 上电
			if err := s.sendControl(req.Sn, request); err != nil {
				logger.Error("Sbp100TurnOnOff sendControl ATP 上电 err2: ", err)
				return err
			}
		}

		// 如果因为冷启动，这个时候需要等冷却系统初始化后
		// a. 发起重置指令
		// b. 发起prepare指令
		for i := 0; i < 3; i++ {
			stateResp, err = s.GetLaserStates(req.Sn, true)
			if err != nil {
				logger.Error("Sbp100TurnOnOff GetLaserStates err2: ", err)
				return err
			}
			if stateResp == nil {
				continue
			}
			LaserState := stateResp.LaserState
			if LaserState == nil {
				continue
			}

			//LaserState 激光器状态：
			//b0:主激光器出光
			//b1:主激光器故障
			//b2:主激光器刹车
			//b3:预留
			//b4:照明激光器出光
			//b5:照明激光器故障

			//b1:主激光器故障
			laserFailFlag := checkBit(uint32(*LaserState), 1)
			//b5:照明激光器故障
			lightFailFlag := checkBit(uint32(*LaserState), 5)
			if !laserFailFlag && !lightFailFlag {
				logger.Debug("laser device power on success")
				break
			}

			//Control Laser激光器控制：
			//1：主光出光
			//2：主光停光
			//3：照明出光
			//4：照明停光
			//5：主光复位
			//6：照明复位
			//7：红光出光
			//8：红光停光
			if laserFailFlag {
				resetReq := &mavlink.CommandControl{
					Control: &mavlink.Control{
						Laser: lo.ToPtr(5), //5：主光复位
					},
				}
				logger.Debug("laser device power on fail, resetReq: %v", resetReq)
				if err := s.sendControl(req.Sn, request); err != nil {
					logger.Error("Sbp100TurnOnOff sendControl 主光复位 err: ", err)
					return err
				}
			}
			if lightFailFlag {
				resetReq := &mavlink.CommandControl{
					Control: &mavlink.Control{
						Laser: lo.ToPtr(6), //6：照明复位
					},
				}
				logger.Debug("light device power on fail, resetReq: %v", resetReq)
				if err := s.sendControl(req.Sn, request); err != nil {
					logger.Error("Sbp100TurnOnOff sendControl 照明复位 err: ", err)
					return err
				}
			}
		}

		err = s.sbp100FirePrepare(req.Sn)
		if err != nil {
			logger.Error("Sbp100TurnOnOff sbp100FirePrepare err: ", err)
			return err
		}
	} else {
		if statesNotExist || (atpPowerSet == false && laserPowerSet == false) {
			request.Control = &mavlink.Control{}
			request.Control.Power = &switchStatus //2：ATP 断电
			if err := s.sendControl(req.Sn, request); err != nil {
				logger.Error("Sbp100TurnOnOff sendControl ATP 断电 err1: ", err)
				return err
			}
			request.Control.Power = lo.ToPtr(4) //4：激光器断电
			if err := s.sendControl(req.Sn, request); err != nil {
				logger.Error("Sbp100TurnOnOff sendControl 激光器断电 err1: ", err)
				return err
			}
		} else if atpPowerSet == false && laserPowerSet == true {
			request.Control = &mavlink.Control{}
			request.Control.Power = &switchStatus //2：ATP 断电
			if err := s.sendControl(req.Sn, request); err != nil {
				logger.Error("Sbp100TurnOnOff sendControl ATP 断电 err2: ", err)
				return err
			}
		} else if atpPowerSet == true && laserPowerSet == false {
			request.Control.Power = lo.ToPtr(4) //4：激光器断电
			if err := s.sendControl(req.Sn, request); err != nil {
				logger.Error("Sbp100TurnOnOff sendControl 激光器断电 err2: ", err)
				return err
			}
		}
	}

	//等待激光设备响应
	statesResp, err := s.GetLaserStates(req.Sn, true)
	if err != nil {
		logger.Error("Sbp100TurnOnOff GetLaserStates err3: ", err)
		return err
	}

	rsp.Status = 2
	if statesResp != nil && statesResp.LaserPowerFlag != nil && statesResp.ATPPowerFlag != nil {
		if *statesResp.ATPPowerFlag == true && *statesResp.LaserPowerFlag == true {
			rsp.Status = 1
		}
	}
	logger.Debugf("Sbp100TurnOnOff rsp: %v", rsp)
	return nil
}

func (s *Sbp100) sbp100FirePrepare(sn string) error {
	statesResp, err := s.GetLaserStates(sn, false)
	if err != nil {
		logger.Error("sbp100FirePrepare GetLaserStates err1: ", err)
		return err
	}
	var (
		needPrepare    bool
		statesNotExist bool
	)
	if statesResp == nil {
		statesNotExist = true
	}
	if statesResp != nil {
		laserPower := statesResp.LaserPower
		lightPower := statesResp.LightPower
		if laserPower == nil || lightPower == nil || *laserPower == 0 || *lightPower == 0 {
			needPrepare = true
		}
	}
	if statesNotExist || needPrepare {
		req := &mavlink.CommandControl{}
		req.Control = &mavlink.Control{
			Prepare: lo.ToPtr(true),
		}
		if err := s.sendControl(sn, req); err != nil {
			logger.Error("sbp100FirePrepare sendControl Prepare err: ", err)
			return err
		}

		statesInfo, err := s.GetLaserStates(sn, true)
		if err != nil {
			logger.Error("sbp100FirePrepare GetLaserStates err: ", err)
			return err
		}
		logger.Info("sbp100FirePrepare GetLaserStates: ", *statesInfo)
		if statesInfo != nil {
			laserPower := statesInfo.LaserPower
			lightPower := statesInfo.LightPower
			if laserPower != nil && lightPower != nil {
				if *laserPower > 0 && *lightPower > 0 {
					return nil
				}
			}
		}
	}
	return nil
}

func (s *Sbp100) Sbp100FireZero(req *client.Sbp100FireZeroRequest, rsp *client.Sbp100FireZeroResponse) error {
	request := &mavlink.CommandControl{}
	x := int(req.X)
	y := int(req.Y)
	request.Control = &mavlink.Control{
		CatchZero: &mavlink.CatchZero{
			X: &x,
			Y: &y,
		},
	}
	if err := s.sendControl(req.Sn, request); err != nil {
		logger.Error("Sbp100FireZero sendControl CatchZero err: ", err)
		return err
	}
	rsp.Status = 1
	return nil
}

func (s *Sbp100) Sbp100FireRange(req *client.Sbp100FireRangeRequest, rsp *client.Sbp100FireRangeResponse) error {
	request := &mavlink.CommandControl{}
	rangeEnable := int(req.SwitchStatus) //1:开启 2:关闭
	if rangeEnable != 1 && rangeEnable != 2 {
		logger.Error("Sbp100FireRange param err: ", rangeEnable)
		return fmt.Errorf("param SwitchStatus err, only support [1,2], but got %d", rangeEnable)
	}
	temp := false
	if rangeEnable == 1 {
		temp = true
	}
	request.Control = &mavlink.Control{
		Range: &temp,
	}
	if err := s.sendControl(req.Sn, request); err != nil {
		logger.Error("Sbp100FireRange sendControl Range err: ", err)
		return err
	}

	rsp.Status = 1
	return nil
}

func (s *Sbp100) Sbp100OnOffLight(req *client.Sbp100OnOffLightRequest, rsp *client.Sbp100OnOffLightResponse) error {
	err := s.sbp100FirePrepare(req.Sn)
	if err != nil {
		logger.Error("Sbp100OnOffLight sbp100FirePrepare err: ", err)
		return err
	}
	request := &mavlink.CommandControl{}
	temp := 4 //照明停光
	if req.SwitchStatus == 1 {
		//照明出光
		temp = 3

	}
	request.Control = &mavlink.Control{
		Laser: &temp,
	}

	if err := s.sendControl(req.Sn, request); err != nil {
		logger.Error("Sbp100OnOffLight sendControl Laser err: ", err)
		return err
	}
	rsp.Status = 1
	return nil
}

func (s *Sbp100) Sbp100FireMainLaser(req *client.Sbp100FireMainLaserRequest, rsp *client.Sbp100FireMainLaserResponse) error {
	request := &mavlink.CommandControl{}
	var laserEnable int // 9:开启 10:关闭
	if req.SwitchStatus == 1 {
		laserEnable = 9
	}
	if req.SwitchStatus == 2 {
		laserEnable = 10
	}
	if laserEnable != 9 && laserEnable != 10 {
		logger.Errorf("Sbp100FireMainLaser param err: %v", req)
		return fmt.Errorf("param SwitchStatus err, only support [1,2], but got %d", req.SwitchStatus)
	}
	var laserTemp int
	if laserEnable == 9 {
		// 开启
		err := s.sbp100FirePrepare(req.Sn)
		if err != nil {
			logger.Error("Sbp100FireMainLaser sbp100FirePrepare err: ", err)
			return err
		}
		laserTemp = 9
	} else {
		//关闭
		laserTemp = 10
	}

	request.Control = &mavlink.Control{}
	request.Control.Laser = &laserTemp
	if err := s.sendControl(req.Sn, request); err != nil {
		logger.Error("Sbp100FireMainLaser sendControl Laser err: ", err)
		return err
	}
	rsp.Status = 1
	return nil
}

func (s *Sbp100) SelectUavToLaserDevice(req *client.SelectUavToLaserDeviceReq, rsp *client.SelectUavToLaserDeviceRsp) error {
	logger.Debugf("SelectUavToLaserDevice req: %v", req)
	if status == nil {
		status = make(map[string]map[int32]string)
	}
	if status[req.AgxSn] == nil {
		status[req.AgxSn] = make(map[int32]string)
	}
	status[req.AgxSn][req.UavId] = req.LaserSn

	rsp.Status = 1
	//退出执勤模式
	go s.quitAutoLock(req, 2)
	return nil
}

// quitAutoLock 退出执勤模式
func (s *Sbp100) quitAutoLock(req *client.SelectUavToLaserDeviceReq, mode int) {
	//1：开始执勤
	//2：结束执勤
	//3：待机
	quitAutoLockReq := mavlink.CommandControl{}
	quitAutoLockReq.Control = &mavlink.Control{
		Mode: lo.ToPtr(mode),
	}
	err := s.sendControl(req.LaserSn, &quitAutoLockReq)
	if err != nil {
		logger.Error("quitAutoLock sendControl error: ", err)
	}
	modeChangeFlag[req.AgxSn] = req.LaserSn
}

// sendControl C2下发操控激光指令
func (s *Sbp100) sendControl(laserSn string, req *mavlink.CommandControl) error {
	logger.Debugf("sendControl laserSn: %s, req: %v", laserSn, req)
	ips := strings.Split(laserSn, "_")
	ip := [4]byte{}
	for idx, ipStr := range ips {
		tmp, err := strconv.ParseInt(ipStr, 10, 64)
		if err != nil {
			logger.Error("sendControl ParseInt err: ", err)
			return err
		}
		if idx < 4 {
			ip[idx] = byte(tmp)
		}
	}
	laserData, err := req.Encode()
	if err != nil {
		logger.Error("sendControl Encode CommandControl err: ", err)
		return err
	}
	var request mavlink.ProxySbp100
	reqBuff, err := request.Create(ip, laserData)
	if err != nil {
		logger.Error("sendControl Create ProxySbp100 err: ", err)
		return err
	}
	logger.Debugf("sendControl reqBuff: [ %X ]", reqBuff)
	_, err = s.Conn.Write(reqBuff)
	if err != nil {
		logger.Error("sendControl Write err: ", err)
		return err
	}
	return nil
}

func (s *Sbp100) GetLaserStates(sn string, needSleep bool) (*mavlink.States, error) {
	if needSleep {
		time.Sleep(5 * time.Second)
	}
	val, ok := States[sn]
	if !ok {
		return nil, errors.New("GetLaserStates States not found")
	}
	return val, nil
}

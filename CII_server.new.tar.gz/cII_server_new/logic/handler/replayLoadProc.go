package handler

import (
	"context"
	"encoding/json"
	"strconv"
	"time"

	utils "adasgitlab.autel.com/tools/cuav_server/entity/utils/panic"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"

	"github.com/google/uuid"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/helper"
	"github.com/jinzhu/copier"
	"google.golang.org/protobuf/proto"
)

var (
	LoadMsgFromDb map[int32]ILoadDbAbstract = map[int32]ILoadDbAbstract{
		ReplayTypeHEART:       new(LoadDbForHeart),
		ReplayTypeDetect:      new(LoadDbForDetect),
		ReplayTypePosture:     new(LoadDbForPosture),
		ReplayTypeHit:         new(LoadDbForHit),
		ReplayTypeSpectrum:    new(LoadDbForSpectrum),
		ReplayTypeC2SysConfig: new(LoadDbForSysConfig),
	}
)

// QueueToDbMsg 从queue线程发给load db线程的消息。
type QueueToDbMsg struct {
	Sn        string
	DevType   int32
	TaskType  int32
	BatchNums int32
	StartTime int64
	EndTime   int64
	Seq       int64
}

type SignalDelSnTask struct {
	Sn string
}

func (qtm *QueueToDbMsg) String() string {
	ret := "Sn: " + qtm.Sn + ", devType: " + strconv.Itoa(int(qtm.DevType)) +
		", taskType: " + GetReplayDataTypeDesc(qtm.TaskType) +
		", batchNums: " + strconv.Itoa(int(qtm.BatchNums)) +
		", startTime: " + strconv.Itoa(int(qtm.StartTime)) +
		", endTime: " + strconv.Itoa(int(qtm.EndTime)) +
		", seq: " + strconv.FormatInt(qtm.Seq, 10)

	return ret
}

func QueryBusiItemsFromDb[T any](cTm int64, ceTm int64, sn string, limit int32, devType int32, busiType int32) []*T {
	if limit <= 0 {
		limit = 1
	}
	var (
		RetItem      []*T
		timestampTos = time.UnixMilli(cTm) //start time 	//end time
		tabName      = ""
	)

	switch busiType {
	case ReplayTypeHEART:
		tabName = common.BuildHeartTableName(sn, timestampTos)

	case ReplayTypeDetect:
		tabName = common.BuildDetectTableName(sn, timestampTos)

	case ReplayTypePosture:
		tabName = common.BuildPostureTableName(sn, timestampTos)

	case ReplayTypeHit:
		tabName = common.BuildHitStatusTableName(sn, timestampTos)

	case ReplayTypeSpectrum:
		tabName = common.BuildSpectrumTabName(sn, timestampTos)

	case ReplayTypeC2SysConfig:
		tabName = common.BuildSysCfgTabName(sn, timestampTos)

	default:
		logger.Errorf("not support business type: %v", busiType)
		return nil
	}

	querySql := "select * from `" + tabName + "` where create_time > ? and create_time < ? order by create_time ASC limit ?; "
	//err := Db.Debug().Raw("select * from `"+tabName+"` where create_time > ? and create_time < ? order by create_time ASC limit ?;",
	//	cTm, ceTm, limit).Scan(&RetItem).Error
	err := db.GetDB().Debug().Raw(querySql, cTm, ceTm, limit).Scan(&RetItem).Error
	if err != nil {
		logger.Errorf("load devType: %v fail, err: %v, table: %v, busiType: %v", devType, err, tabName, busiType)
		return nil
	}

	logger.Infof("query ret item nums: %v, devType: %v, taskType: %v, beginTm: %v, endTime: %v, sn: %v, tabName: %v",
		len(RetItem), devType, GetReplayDataTypeDesc(busiType), cTm, ceTm, sn, tabName)
	return RetItem
}
func QueryHeartItemsFromDb[T any](cTm int64, ceTm int64, sn string, limit int32, devType int32) []*T {
	return QueryBusiItemsFromDb[T](cTm, ceTm, sn, limit, devType, ReplayTypeHEART)
}
func QueryDetectItemsFromDb[T any](cTm int64, ceTm int64, sn string, limit int32, devType int32) []*T {
	return QueryBusiItemsFromDb[T](cTm, ceTm, sn, limit, devType, ReplayTypeDetect)
}
func QueryPostureItemFromDb[T any](cTm int64, ceTm int64, sn string, limit int32, devType int32) []*T {
	return QueryBusiItemsFromDb[T](cTm, ceTm, sn, limit, devType, ReplayTypePosture)
}

func QueryHitItemFromDb[T any](cTm int64, ceTm int64, sn string, limit int32, devType int32) []*T {
	return QueryBusiItemsFromDb[T](cTm, ceTm, sn, limit, devType, ReplayTypeHit)
}
func QueryC2SysConfigItemsFromDb[T any](cTm int64, ceTm int64, sn string, limit int32, devType int32) []*T {
	return QueryBusiItemsFromDb[T](cTm, ceTm, sn, limit, devType, ReplayTypeC2SysConfig)
}
func QueryTracerSSysCfgItemFromDb[T any](cTm int64, ceTm int64, sn string, limit int32, devType int32) []*T {
	return QueryBusiItemsFromDb[T](cTm, ceTm, sn, limit, devType, ReplayTypeC2SysConfig)
}
func QueryTracerPSysCfgItemFromDb[T any](cTm int64, ceTm int64, sn string, limit int32, devType int32) []*T {
	return QueryBusiItemsFromDb[T](cTm, ceTm, sn, limit, devType, ReplayTypeC2SysConfig)
}

func QuerySpectrumItemFromDb[T any](cTm int64, ceTm int64, sn string, limit int32, devType int32) []*T {
	return QueryBusiItemsFromDb[T](cTm, ceTm, sn, limit, devType, ReplayTypeSpectrum)
}

func MarshalCall[P proto.Message](pb P, retBuf []*MemItemIndexValue, item *MemItemIndexValue) []*MemItemIndexValue {
	if item == nil {
		return retBuf
	}

	r, e := proto.Marshal(pb)
	if e != nil {
		logger.Errorf("marshal fail, e: %v", e)
		return retBuf
	}
	if len(r) <= 0 {
		logger.Errorf("marshal ret is nil")
		return retBuf
	}
	item.PbData = r

	retBuf = append(retBuf, item)
	return retBuf
}

type MsgToQueue struct {
	helper.SkyFendPQItem[ValueType]
	Sn       string
	BusiType int32
}
type MemItemIndexValue struct {
	MsgToQueue
	PbData []byte
}

type FilterAfterLoad func(mng *LoadMsgManager) bool

func WithHeartLoadMsgFilter(sn string, taskType int32, devType int32, updateStartTime int64) FilterAfterLoad {
	omitThisItemCond := int64(100) //ms

	return func(mng *LoadMsgManager) bool {
		preUpdateStartTime := mng.LoadTask[sn][taskType].StartTime

		if updateStartTime > 0 && preUpdateStartTime <= updateStartTime {
			logger.Infof("update start query db time from %v =>  %v", preUpdateStartTime, updateStartTime)
			mng.LoadTask[sn][taskType].StartTime = updateStartTime

			if updateStartTime-preUpdateStartTime >= omitThisItemCond {
				logger.Infof("send this item to client, middle item omit")
				return true
			}
		}

		return false
	}
}

// ILoadDbAbstract 加载业务数据表的抽象类
type ILoadDbAbstract interface {
	Load(c *QueueToDbMsg, mng *LoadMsgManager) []*MemItemIndexValue
	Store(items []*MemItemIndexValue, c *QueueToDbMsg, memHandle *LocalMem)
}

// //////////////////////////////////////////////////////////
type StoreBigCache struct {
}

func (s *StoreBigCache) Store(items []*MemItemIndexValue, c *QueueToDbMsg, memHandle *LocalMem) {
	if len(items) <= 0 || c == nil {
		logger.Infof("store data is nil")
		return
	}
	if memHandle == nil {
		logger.Infof("big cache mem handle is empty")
		return
	}

	for _, v := range items {
		if v == nil {
			logger.Infof("to store mem is nil, check it.")
			continue
		}

		e := memHandle.Set(v.Value, v.PbData)
		if e != nil {
			logger.Errorf("store data to mem cache fail, e: %v, sn: %v, sn type: %v, task type: %v", e, c.Sn, c.DevType, c.TaskType)
			continue
		}
	}
}

// // heart data transfer...
func TransRadarHeartFromStructToPb(src *bean.RadarReplayHeart) *client.ReplayRadarHeart {
	if src == nil {
		return nil
	}
	var ret *client.ReplayRadarHeart = new(client.ReplayRadarHeart)
	ret.CreateTime = src.CreateTime
	ret.Sn = src.Sn
	ret.IsOnline = int32(src.IsOnline)
	ret.Electricity = int32(src.Electricity)

	return ret
}
func TransTracerPHeartFromStructToPb(src *bean.TracerReplayHeart) *client.ReplayTracerPHeart {
	if src == nil {
		return nil
	}
	var ret *client.ReplayTracerPHeart = new(client.ReplayTracerPHeart)
	ret.AlarmLevel = int32(src.AlarmLevel)
	ret.CreateTime = src.CreateTime
	ret.Electricity = int32(src.Electricity)
	ret.IsOnline = int32(src.IsOnline)
	ret.Sn = src.Sn
	ret.WorkMode = int32(src.WorkMode)
	ret.WorkStatus = int32(src.WorkStatus)
	return ret
}
func TransTracerSHeartFromStructToPb(src *bean.TracerReplayHeart) *client.ReplayTracerSHeart {
	if src == nil {
		return nil
	}
	var r *client.ReplayTracerSHeart = new(client.ReplayTracerSHeart)
	r.CreateTime = src.CreateTime
	r.AlarmLevel = int32(src.AlarmLevel)
	r.IsOnline = int32(src.IsOnline)
	r.Sn = src.Sn
	r.WorkMode = int32(src.WorkMode)
	r.WorkStatus = int32(src.WorkStatus)
	return r
}
func TransTracerProHeartFromStructToPB(src *bean.TracerReplayHeart) *client.ReplayTracerSHeart {
	if src == nil {
		return nil
	}
	var r *client.ReplayTracerSHeart = new(client.ReplayTracerSHeart)
	r.CreateTime = src.CreateTime
	r.AlarmLevel = int32(src.AlarmLevel)
	r.IsOnline = int32(src.IsOnline)
	r.Sn = src.Sn
	r.WorkMode = int32(src.WorkMode)
	r.WorkStatus = int32(src.WorkStatus)
	return r
}
func TransFpvHeartFromStructToPb(src *bean.FpvReplayHeartData) *client.ReplayFpvHeart {
	if src == nil {
		return nil
	}
	var r *client.ReplayFpvHeart = new(client.ReplayFpvHeart)
	r.AlarmLevel = int32(src.AlarmLevel)
	r.BatteryStatus = int32(src.BatteryStatus)
	r.CreateTime = src.CreateTime
	r.Electricity = int32(src.Electricity)
	r.IsOnline = int32(src.IsOnline)
	r.WorkMode = int32(src.WorkMode)
	r.WorkStatus = int32(src.WorkStatus)
	return r
}
func TransGunHeartFromStructToPb(src *bean.GunReplayHeartData) *client.ReplayGunHeart {
	if src == nil {
		return nil
	}
	var r *client.ReplayGunHeart = new(client.ReplayGunHeart)
	r.AlarmLevel = src.AlarmLevel
	r.CreateTime = src.CreateTime
	r.DetectFreq = src.DetectFreq
	r.Elevation = src.Elevation
	r.GunAltitude = src.GunAltitude
	r.Electricity = src.Electricity
	r.GunDirection = src.GunDirection
	r.GunLatitude = src.GunLatitude
	r.GunLongitude = src.GunLongitude
	r.HitFreq = src.HitFreq
	r.HitTime = src.HitTime
	r.IsOnline = src.IsOnline
	r.RehitTime = src.ReHitTime
	r.SatellitesNum = src.SatellitesNum
	r.ScreenStatus = src.ScreenStatus
	r.SignalStrength = src.SignalStrength
	r.Sn = src.Sn
	r.UDroneNum = src.UDroneNum
	r.WorkStatus = src.WorkStatus
	r.X = src.X
	r.Y = src.Y
	r.Z = src.Z
	return r
}
func TransSflHeartFromStructToPb(src *bean.SFLReplayHeartData) *client.ReplaySFLHeart {
	if src == nil {
		return nil
	}
	var r *client.ReplaySFLHeart = new(client.ReplaySFLHeart)
	r.AeagFault = src.AeagFault
	r.CreateTime = src.CreateTime
	r.CtrlFault = src.CtrlFault
	r.DetectFreq = src.DetectFreq
	r.Elevation = src.Elevation
	r.FaultLevel = src.FaultLevel
	r.GunAltitude = src.GunAltitude
	r.GunDirection = src.GunDirection
	r.GunLatitude = src.GunLatitude
	r.GunLongitude = src.GunLongitude
	r.HitFreq = src.HitFreq
	r.IsOnline = src.IsOnline
	r.SatellitesNum = src.SatellitesNum
	r.Sn = src.Sn
	r.TimeStamp = src.TimeStamp
	r.TracerFault = src.TracerFault
	r.WorkStatus = src.WorkStatus
	return r
}
func TransSfl101HeartFromStructToPb(src *bean.SFL101ReplayHeartData) *client.ReplaySFL101Heart {
	if src == nil {
		return nil
	}
	var r *client.ReplaySFL101Heart = new(client.ReplaySFL101Heart)
	r.AeagFault = src.AeagFault
	r.CreateTime = src.CreateTime
	r.CtrlFault = src.CtrlFault
	r.DetectFreq = src.DetectFreq
	r.Elevation = src.Elevation
	r.FaultLevel = src.FaultLevel
	r.GunAltitude = src.GunAltitude
	r.GunDirection = src.GunDirection
	r.GunLatitude = src.GunLatitude
	r.GunLongitude = src.GunLongitude
	r.HitFreq = src.HitFreq
	r.IsOnline = src.IsOnline
	r.SatellitesNum = src.SatellitesNum
	r.Sn = src.Sn
	r.TimeStamp = src.TimeStamp
	r.TracerFault = src.TracerFault
	r.WorkStatus = src.WorkStatus
	return r
}
func TransGunCloudHeartFromStructToPb(src *bean.GunCloudReplayHeartData) *client.ReplayGunCloudHeart {
	if src == nil {
		return nil
	}
	var r *client.ReplayGunCloudHeart = new(client.ReplayGunCloudHeart)
	r.AeagFault = src.AeagFault
	r.CreateTime = src.CreateTime
	r.CtrlFault = src.CtrlFault
	r.DetectFreq = src.DetectFreq
	r.Elevation = src.Elevation
	r.FaultLevel = src.FaultLevel
	r.GunAltitude = src.GunAltitude
	r.GunDirection = src.GunDirection
	r.GunLatitude = src.GunLatitude
	r.GunLongitude = src.GunLongitude
	r.HitFreq = src.HitFreq
	r.IsOnline = src.IsOnline
	r.SatellitesNum = src.SatellitesNum
	r.Sn = src.Sn
	r.TimeStamp = src.TimeStamp
	r.TracerFault = src.TracerFault
	r.WorkStatus = src.WorkStatus
	return r
}
func TransSpooferHeartFromStructToPb(src *bean.SpooferReplayHeartData) *client.ReplaySpooferHeart {
	if src == nil {
		return nil
	}
	var r *client.ReplaySpooferHeart = new(client.ReplaySpooferHeart)
	r.CreateTime = src.CreateTime
	r.Ephemeris = int32(src.Ephemeris)
	r.GpsStatus = int32(src.GpsStatus)
	r.Height = src.Height
	r.IsOnline = int32(src.IsOnline)
	r.Latitude = src.Latitude
	r.Longititude = src.Longititude
	r.Sn = src.Sn
	r.TimeSync = int32(src.TimeSync)
	return r
}
func TransUrdfHeartFromStructToPb(src *UrdStatusRepaly) *client.ReplayUrdHeart {
	var ret *client.ReplayUrdHeart = &client.ReplayUrdHeart{
		Sn:                src.SN,
		Name:              src.Name,
		Longitude:         src.Longitude,
		Latitude:          src.Latitude,
		Height:            src.Height,
		Status:            int32(src.Status),
		Azimuth:           src.Azimuth,
		Type:              src.Type,
		CompassStatus:     int32(src.CompassStatus),
		GpsStatus:         int32(src.GpsStatus),
		ReceiverStatus:    int32(src.ReceiverStatus),
		AntennaStatus:     int32(src.AntennaStatus),
		AntennaCoverRange: int32(src.AntennaCoverRange),
	}
	return ret
}

func TransUrdfSpectrumFromStructToPb(src *UrdSpectrumSDB) *client.ReplayUrdSpectrum {
	if src == nil {
		return nil
	}
	infoo := UrdSpectrumRepaly{}
	err := json.Unmarshal(src.Data, &infoo)
	if err != nil {
		logger.Error("json Unmarshal spectrum err = ", err)
	}
	logger.Debug("X = ", infoo.X)
	logger.Debug("Y = ", infoo.Y)

	var ret *client.ReplayUrdSpectrum = &client.ReplayUrdSpectrum{
		Sn:         src.SN,
		X:          infoo.X,
		Y:          infoo.Y,
		CreateTime: src.CreateTime,
	}
	return ret
}

// detect data transfer;
func TransRadarDetectFromStructToPb(src *bean.RadarReplayDetect) *client.ReplayRadarDetect {
	if src == nil {
		return nil
	}
	var ret *client.ReplayRadarDetect = new(client.ReplayRadarDetect)
	ret.CreateTime = src.CreateTime
	ret.Sn = src.Sn
	ret.ObjId = int32(src.ObjId)
	ret.X = src.X
	ret.Y = src.Y
	ret.Z = src.Z
	ret.Velocity = src.Velocity
	ret.Azimuth = src.Azimuth
	ret.Alive = int32(src.Alive)
	ret.ExistingProb = src.ExistingProb
	ret.StateType = int32(src.StateType)
	ret.Classification = int32(src.Classification)

	return ret
}

func TransRadarPostureFromStructToPb(src *bean.RadarReplayPosture) *client.ReplayRadarPosture {
	if src == nil {
		return nil
	}
	var ret *client.ReplayRadarPosture = new(client.ReplayRadarPosture)
	ret.CreateTime = src.CreateTime
	ret.Sn = src.Sn
	ret.Latitude = src.Latitude
	ret.Longitude = src.Longitude
	ret.Pitching = src.Pitching
	ret.Rolling = src.Rolling
	ret.Heading = src.Heading
	return ret
}

func TransTracerPDetectFromStructToPb(src *bean.TracerReplayDetect) *client.ReplayTracerPDetect {
	if src == nil {
		return nil
	}
	var ret *client.ReplayTracerPDetect = new(client.ReplayTracerPDetect)
	ret.CreateTime = src.CreateTime
	ret.DangerLevels = int32(src.DangerLevels)
	ret.Distance = src.Distance
	ret.DroneHeight = src.DroneHeight
	ret.DroneLatitude = src.DroneLatitude
	ret.DroneLongitude = src.DroneLongitude
	ret.DroneName = src.DroneName
	ret.DroneSpeed = src.DroneSpeed
	ret.DroneYawAngle = src.DroneYawAngle
	ret.Freq = src.Freq
	ret.OperatorLatitude = src.OperatorLatitude
	ret.OperatorLongitude = src.OperatorLongitude
	ret.Role = int32(src.Role)
	ret.SerialNum = src.SerialNum
	ret.Sn = src.Sn
	ret.DetectDevSrc = src.DetectSrcType
	ret.HomeLongitude = src.HomeLongitude
	ret.HomeLatitude = src.HomeLatitude
	ret.AliveTime = src.AliveTime
	ret.TargetMask = uint32(src.TargetMask)
	ret.TypeCodeRid = uint32(src.TypeCodeRid)
	ret.SeqNumRid = uint32(src.SeqNumRid)
	ret.ClassificationType = uint32(src.ClassificationType)
	ret.OperationStatus = uint32(src.OperationStatus)
	ret.OperatorLocationType = uint32(src.OperatorLocationType)
	ret.HeightType = uint32(src.HeightType)
	ret.SignalFreqRid = src.SignalFreqRid
	ret.SignalPowerRid = uint32(src.SignalPowerRid)
	ret.NoisePowerRid = uint32(src.NoisePowerRid)
	ret.TimestampRid = src.TimestampRid
	ret.TypeCodeDid = uint32(src.TypeCodeDid)
	ret.SeqNumDid = uint32(src.SeqNumDid)
	ret.Altitude = src.Altitude
	ret.SpeedX = src.SpeedX
	ret.SpeedY = src.SpeedY
	ret.SignalFreqDid = src.SignalFreqDid
	ret.SignalPowerDidCh1 = uint32(src.SignalPowerDidCh1)
	ret.SignalPowerDidCh2 = uint32(src.SignalPowerDidCh2)
	ret.GpsClock = src.GpsClock

	return ret
}

func TransTracerSDetectFromStructToPb2(src *bean.TracerReplayDetect) *client.TracerFreqDetectDescription {
	if src == nil {
		return nil
	}

	ret := new(client.TracerFreqDetectDescription)

	ret.DroneName = src.DroneName
	ret.DroneHorizon = src.DroneHorizon
	ret.UFreq = src.Freq
	ret.UDangerLevels = int32(src.DangerLevels)
	ret.Recerve = 0

	return ret
}
func TransTracerSDetectFromStructToPb(src *bean.TracerReplayDetect) *client.ReplayTracerSDetect {
	if src == nil {
		return nil
	}
	var r *client.ReplayTracerSDetect = new(client.ReplayTracerSDetect)
	r.CreateTime = src.CreateTime
	r.DangerLevels = int32(src.DangerLevels)
	r.Distance = src.Distance
	r.DroneHeight = src.DroneHeight
	r.DroneLatitude = src.DroneLatitude
	r.DroneLongitude = src.DroneLongitude
	r.DroneName = src.DroneName
	r.DroneSpeed = src.DroneSpeed
	r.DroneYawAngle = src.DroneYawAngle
	r.Freq = src.Freq
	r.OperatorLatitude = src.OperatorLatitude
	r.OperatorLongitude = src.OperatorLongitude
	r.Role = int32(src.Role)
	r.SerialNum = src.SerialNum
	r.Sn = src.Sn
	r.QxPower = src.QxPower
	r.DxPower = src.DxPower
	r.DxHorizon = src.DxHorizon

	return r
}
func TransFpvDetectFromStructToPb(src *bean.FpvReplayDetectData) *client.ReplayFpvDetect {
	if src == nil {
		return nil
	}
	r := &client.ReplayFpvDetect{
		Sn:           src.Sn,
		QxPower:      float32(src.QxPower),
		DxPower:      float32(src.DxPower),
		DxHorizon:    float32(src.DxHorizon),
		UavNumber:    int32(src.UavNumber),
		DroneName:    src.DroneName,
		DroneHorizon: float32(src.DroneHorizon),
		Freq:         float32(src.UFreq),
		DangerLevels: src.UDangerLevels,
		CreateTime:   src.CreateTime}
	return r
}

// TransSflDetectFromStructToPb
func TransSflDetectFromStructToPbV2(src *bean.SFLReplayDetectData) *client.GimbalCounterDetectDroneInfo {
	if src == nil {
		return nil
	}
	ret := &client.GimbalCounterDetectDroneInfo{
		ProductType:        src.ProductType,
		DroneName:          src.DroneName,
		SerialNum:          src.SerialNum,
		DroneLongitude:     src.DroneLongitude,
		DroneLatitude:      src.DroneLatitude,
		DroneHeight:        src.DroneHeight,
		DroneYawAngle:      src.DroneYawAngle,
		DroneSpeed:         src.DroneSpeed,
		DroneVerticalSpeed: src.DroneVerticalSpeed,
		SpeedDirection:     src.SpeedDirection,
		DroneSailLongitude: src.DroneSailLongitude,
		DroneSailLatitude:  src.DroneSailLatitude,
		PilotLongitude:     src.PilotLongitude,
		PilotLatitude:      src.PilotLatitude,
		DroneHorizon:       src.DroneHorizon,
		DronePitch:         src.DronePitch,
		UFreq:              src.UFreq,
		UDistance:          src.UDistance,
		UDangerLevels:      src.UDangerLevels,
		Role:               src.Role,
		IdType:             uint32(src.IdType),
	}

	return ret
}

// TransSfl101DetectFromStructToPb
func TransSfl101DetectFromStructToPbV2(src *bean.SFL101ReplayDetectData) *client.Sfl101DetectDroneInfo {
	if src == nil {
		return nil
	}
	ret := &client.Sfl101DetectDroneInfo{
		ProductType:        src.ProductType,
		DroneName:          src.DroneName,
		SerialNum:          src.SerialNum,
		DroneLongitude:     src.DroneLongitude,
		DroneLatitude:      src.DroneLatitude,
		DroneHeight:        src.DroneHeight,
		DroneYawAngle:      src.DroneYawAngle,
		DroneSpeed:         src.DroneSpeed,
		DroneVerticalSpeed: src.DroneVerticalSpeed,
		SpeedDirection:     src.SpeedDirection,
		DroneSailLongitude: src.DroneSailLongitude,
		DroneSailLatitude:  src.DroneSailLatitude,
		PilotLongitude:     src.PilotLongitude,
		PilotLatitude:      src.PilotLatitude,
		DroneHorizon:       src.DroneHorizon,
		DronePitch:         src.DronePitch,
		UFreq:              src.UFreq,
		UDistance:          src.UDistance,
		UDangerLevels:      src.UDangerLevels,
		Role:               src.Role,
		IdType:             uint32(src.IdType),
	}

	return ret
}

// TransGunCloudDetectFromStructToPb
func TransGunCloudDetectFromStructToPbV2(src *bean.GunCloudReplayDetectData) *client.GunsPlatformDetectDroneInfo {
	if src == nil {
		return nil
	}
	ret := &client.GunsPlatformDetectDroneInfo{
		ProductType:        src.ProductType,
		DroneName:          src.DroneName,
		SerialNum:          src.SerialNum,
		DroneLongitude:     src.DroneLongitude,
		DroneLatitude:      src.DroneLatitude,
		DroneHeight:        src.DroneHeight,
		DroneYawAngle:      src.DroneYawAngle,
		DroneSpeed:         src.DroneSpeed,
		DroneVerticalSpeed: src.DroneVerticalSpeed,
		SpeedDirection:     src.SpeedDirection,
		DroneSailLongitude: src.DroneSailLongitude,
		DroneSailLatitude:  src.DroneSailLatitude,
		PilotLongitude:     src.PilotLongitude,
		PilotLatitude:      src.PilotLatitude,
		DroneHorizon:       src.DroneHorizon,
		DronePitch:         src.DronePitch,
		UFreq:              src.UFreq,
		UDistance:          src.UDistance,
		UDangerLevels:      src.UDangerLevels,
		Role:               src.Role,
	}

	return ret
}
func TransSflDetectFromStructToPb(src *bean.SFLReplayDetectData) *client.ReplaySFLDetect {

	if src == nil {
		return nil
	}
	r := &client.ReplaySFLDetect{
		Sn:                 src.Sn,
		ProductType:        src.ProductType,
		DroneName:          src.DroneName,
		SerialNum:          src.SerialNum,
		DroneLongitude:     src.DroneLongitude,
		DroneLatitude:      src.DroneLatitude,
		DroneHeight:        src.DroneHeight,
		DroneYawAngle:      src.DroneYawAngle,
		DroneSpeed:         src.DroneSpeed,
		DroneVerticalSpeed: src.DroneVerticalSpeed,
		SpeedDirection:     src.SpeedDirection,
		DroneSailLongitude: src.DroneSailLongitude,
		DroneSailLatitude:  src.DroneSailLatitude,
		PilotLongitude:     src.PilotLongitude,
		PilotLatitude:      src.PilotLatitude,
		DroneHorizon:       src.DroneHorizon,
		DronePitch:         src.DronePitch,
		UFreq:              float32(src.UFreq),
		UDistance:          src.UDistance,
		UDangerLevels:      src.UDangerLevels,
		Role:               src.Role,
		CreateTime:         src.CreateTime,
	}
	return r
}
func TransSfl101DetectFromStructToPb(src *bean.SFL101ReplayDetectData) *client.ReplaySFL101Detect {

	if src == nil {
		return nil
	}
	r := &client.ReplaySFL101Detect{
		Sn:                 src.Sn,
		ProductType:        src.ProductType,
		DroneName:          src.DroneName,
		SerialNum:          src.SerialNum,
		DroneLongitude:     src.DroneLongitude,
		DroneLatitude:      src.DroneLatitude,
		DroneHeight:        src.DroneHeight,
		DroneYawAngle:      src.DroneYawAngle,
		DroneSpeed:         src.DroneSpeed,
		DroneVerticalSpeed: src.DroneVerticalSpeed,
		SpeedDirection:     src.SpeedDirection,
		DroneSailLongitude: src.DroneSailLongitude,
		DroneSailLatitude:  src.DroneSailLatitude,
		PilotLongitude:     src.PilotLongitude,
		PilotLatitude:      src.PilotLatitude,
		DroneHorizon:       src.DroneHorizon,
		DronePitch:         src.DronePitch,
		UFreq:              float32(src.UFreq),
		UDistance:          src.UDistance,
		UDangerLevels:      src.UDangerLevels,
		Role:               src.Role,
		CreateTime:         src.CreateTime,
	}
	return r
}
func TransSflHitFromStructToPb(src *bean.SFLReplayHitStatusData) *client.ReplaySFLHit {
	if src == nil {
		return nil
	}
	return &client.ReplaySFLHit{
		Id:                 int32(src.ID),
		Sn:                 src.SN,
		HitState:           src.HitState,
		ProductType:        src.ProductType,
		DroneName:          src.DroneName,
		SerialNum:          src.SerialNum,
		DroneLongitude:     src.DroneLongitude,
		DroneLatitude:      src.DroneLatitude,
		DroneHeight:        src.DroneHeight,
		DroneYawAngle:      src.DroneYawAngle,
		DroneSpeed:         src.DroneSpeed,
		DroneVerticalSpeed: src.DroneVerticalSpeed,
		SpeedDirection:     src.SpeedDirection,
		DroneSailLongitude: src.DroneSailLongitude,
		DroneSailLatitude:  src.DroneSailLatitude,
		PilotLongitude:     src.PilotLongitude,
		PilotLatitude:      src.PilotLatitude,
		DroneHorizon:       src.DroneHorizon,
		DronePitch:         src.DronePitch,
		UFreq:              src.UFreq,
		UDistance:          src.UDistance,
		UDangerLevels:      src.UDangerLevels,
		Role:               src.Role,
		CreateTime:         src.CreateTime}
}

func TransSfl101HitFromStructToPb(src *bean.SFL101ReplayHitStatusData) *client.ReplaySFL101Hit {
	if src == nil {
		return nil
	}
	return &client.ReplaySFL101Hit{
		Id:                 int32(src.ID),
		Sn:                 src.SN,
		HitState:           src.HitState,
		ProductType:        src.ProductType,
		DroneName:          src.DroneName,
		SerialNum:          src.SerialNum,
		DroneLongitude:     src.DroneLongitude,
		DroneLatitude:      src.DroneLatitude,
		DroneHeight:        src.DroneHeight,
		DroneYawAngle:      src.DroneYawAngle,
		DroneSpeed:         src.DroneSpeed,
		DroneVerticalSpeed: src.DroneVerticalSpeed,
		SpeedDirection:     src.SpeedDirection,
		DroneSailLongitude: src.DroneSailLongitude,
		DroneSailLatitude:  src.DroneSailLatitude,
		PilotLongitude:     src.PilotLongitude,
		PilotLatitude:      src.PilotLatitude,
		DroneHorizon:       src.DroneHorizon,
		DronePitch:         src.DronePitch,
		UFreq:              src.UFreq,
		UDistance:          src.UDistance,
		UDangerLevels:      src.UDangerLevels,
		Role:               src.Role,
		CreateTime:         src.CreateTime}
}

func TransGunCloudHitFromStructToPb(src *bean.GunCloudReplayHitStatusData) *client.ReplayGunCloudHit {
	if src == nil {
		return nil
	}
	return &client.ReplayGunCloudHit{
		Id:                 int32(src.ID),
		Sn:                 src.SN,
		HitState:           src.HitState,
		ProductType:        src.ProductType,
		DroneName:          src.DroneName,
		SerialNum:          src.SerialNum,
		DroneLongitude:     src.DroneLongitude,
		DroneLatitude:      src.DroneLatitude,
		DroneHeight:        src.DroneHeight,
		DroneYawAngle:      src.DroneYawAngle,
		DroneSpeed:         src.DroneSpeed,
		DroneVerticalSpeed: src.DroneVerticalSpeed,
		SpeedDirection:     src.SpeedDirection,
		DroneSailLongitude: src.DroneSailLongitude,
		DroneSailLatitude:  src.DroneSailLatitude,
		PilotLongitude:     src.PilotLongitude,
		PilotLatitude:      src.PilotLatitude,
		DroneHorizon:       src.DroneHorizon,
		DronePitch:         src.DronePitch,
		UFreq:              src.UFreq,
		UDistance:          src.UDistance,
		UDangerLevels:      src.UDangerLevels,
		Role:               src.Role,
		CreateTime:         src.CreateTime}
}
func TransSysCfgFromStructToPb(src *bean.FpvReplaySysConfigData) *client.ReplayC2SysConfig {
	if src == nil {
		return nil
	}
	ret := &client.ReplayC2SysConfig{
		Longitude:     src.Longitude,
		Latitude:      src.Latitude,
		Heading:       src.Heading,
		Arch:          src.Arch,
		TerminalId:    src.TerminalId,
		Etype:         src.EType,
		WarningRadius: src.WarningRadius,
		CounterRadius: src.CounterRadius,
		FenceRadius:   src.FenceRadius,
		ScannerRadius: src.ScannerRadius,
		Height:        src.Height,
		C2Longitude:   src.C2Longitude,
		C2Latitude:    src.C2Latitude,
		CreateTime:    src.CreateTime,
	}
	return ret
}
func TransSysCfgFromStructToPbOnTracerS(src *bean.TracerSReplaySysConfigData) *client.ReplayC2SysConfig {
	if src == nil {
		return nil
	}
	ret := &client.ReplayC2SysConfig{
		C2Longitude: src.C2Longitude,
		C2Latitude:  src.C2Latitude,
		Longitude:   src.C2Longitude,
		Latitude:    src.C2Latitude,
		CreateTime:  src.CreateTime,
	}
	return ret
}

// TransUrdfDetectFromStructToPb urd detect trans
func TransUrdfDetectFromStructToPb(src *UrdDroneInfoReplay) *client.ReplayUrdDetect {
	if src == nil {
		return nil
	}
	return &client.ReplayUrdDetect{
		Sn:               src.SN,
		Id:               src.ID,
		UniqueId:         src.UniqueID,
		TargetInfoLength: src.TargetInfoLength,
		TargetInfo:       src.TargetInfo,
		StationId:        src.StationID,
		TargetAzimuth:    src.TargetAzimuth,
		TargetRange:      src.TargetRange,
		Longitude:        src.Longitude,
		Latitude:         src.Latitude,
		Height:           src.Height,
		Frequency:        src.Frequency,
		Bandwidth:        src.Bandwidth,
		SignalStrength:   src.SignalStrength,
		Trust:            int32(src.Trust),
		Time:             src.Time,
		DataType:         int32(src.DataType),
		Modulation:       int32(src.Modulation),
		CreateTime:       src.CreateTime,
	}
}

func GetMemItem(tm int64, sn string, busiType int32) *MemItemIndexValue {
	item := &MemItemIndexValue{
		MsgToQueue: MsgToQueue{
			SkyFendPQItem: helper.SkyFendPQItem[ValueType]{
				Priority: tm,
				Value:    uuid.New().String(),
			},
			Sn:       sn,
			BusiType: busiType,
		},
	}
	return item
}

type LoadDbForSysConfig struct {
	StoreBigCache
}

func (l *LoadDbForSysConfig) Load(c *QueueToDbMsg, mng *LoadMsgManager) []*MemItemIndexValue {
	if c == nil || mng == nil {
		return nil
	}

	var (
		updateStartTime int64
		retBuf          []*MemItemIndexValue
	)

	switch c.DevType {
	case int32(client.EnumDevTypeList_FpvDevTypeEnum):
		arrT := QueryC2SysConfigItemsFromDb[bean.FpvReplaySysConfigData](c.StartTime, c.EndTime, c.Sn, c.BatchNums, c.DevType)
		if arrT == nil {
			return nil
		}
		for _, v := range arrT {
			if v == nil {
				continue
			}

			r := TransSysCfgFromStructToPb(v)
			updateStartTime = r.GetCreateTime()
			item := GetMemItem(r.GetCreateTime(), c.Sn, c.TaskType)
			retBuf = MarshalCall[*client.ReplayC2SysConfig](r, retBuf, item)
		}

	case int32(client.EnumDevTypeList_TracerSDevTypeEnum):
		arrT := QueryTracerSSysCfgItemFromDb[bean.TracerSReplaySysConfigData](c.StartTime, c.EndTime, c.Sn, c.BatchNums, c.DevType)
		if arrT == nil {
			return nil
		}
		for _, v := range arrT {
			if v == nil {
				continue
			}
			r := TransSysCfgFromStructToPbOnTracerS(v)
			updateStartTime = r.GetCreateTime()
			item := GetMemItem(r.GetCreateTime(), c.Sn, c.TaskType)
			retBuf = MarshalCall[*client.ReplayC2SysConfig](r, retBuf, item)
		}
	case int32(client.EnumDevTypeList_TracerPro):
		arrT := QueryTracerSSysCfgItemFromDb[bean.TracerSReplaySysConfigData](c.StartTime, c.EndTime, c.Sn, c.BatchNums, c.DevType)
		if arrT == nil {
			return nil
		}
		for _, v := range arrT {
			if v == nil {
				continue
			}
			r := TransSysCfgFromStructToPbOnTracerS(v)
			updateStartTime = r.GetCreateTime()
			item := GetMemItem(r.GetCreateTime(), c.Sn, c.TaskType)
			retBuf = MarshalCall[*client.ReplayC2SysConfig](r, retBuf, item)
		}
	case int32(client.EnumDevTypeList_TracerPDevTypeEnum):
		arrT := QueryTracerPSysCfgItemFromDb[bean.TracerSReplaySysConfigData](c.StartTime, c.EndTime, c.Sn, c.BatchNums, c.DevType)
		if arrT == nil {
			return nil
		}
		for _, v := range arrT {
			if v == nil {
				continue
			}
			r := TransSysCfgFromStructToPbOnTracerS(v)
			updateStartTime = r.GetCreateTime()
			item := GetMemItem(r.GetCreateTime(), c.Sn, c.TaskType)
			retBuf = MarshalCall[*client.ReplayC2SysConfig](r, retBuf, item)
		}

	case int32(client.EnumDevTypeList_RadarDevTypeEnum),
		int32(client.EnumDevTypeList_GunDevTypeEnum),
		int32(client.EnumDevTypeList_SFLDevTypeEnum),
		int32(client.EnumDevTypeList_SpooferDevTypeEnum),
		int32(client.EnumDevTypeList_UrdDevTypeEnum):

		logger.Infof("not support dev op")
		return nil

	default:
		logger.Errorf("not support dev type: %v", c.DevType)
	}
	if updateStartTime > 0 && mng.LoadTask[c.Sn][c.TaskType].StartTime <= updateStartTime {
		logger.Infof("update start query db time from %v  to %v", mng.LoadTask[c.Sn][c.TaskType].StartTime, updateStartTime)
		mng.LoadTask[c.Sn][c.TaskType].StartTime = updateStartTime
	}

	return retBuf
}

// /////////
type LoadDbForHeart struct {
	StoreBigCache
}

func FilterHeartItem(originStartTime, updateStartTime int64) bool {
	if updateStartTime-originStartTime >= 90 {
		return true
	}
	//less than 100ms  heart need not replay.
	return false
}
func (h *LoadDbForHeart) Load(c *QueueToDbMsg, mng *LoadMsgManager) []*MemItemIndexValue {
	if c == nil {
		return nil
	}
	updateStartTime, originStartTime := int64(0), int64(0)

	var retBuf []*MemItemIndexValue

	switch c.DevType {
	case int32(client.EnumDevTypeList_RadarDevTypeEnum): //radar 雷达，
		arrT := QueryHeartItemsFromDb[bean.RadarReplayHeart](c.StartTime, c.EndTime, c.Sn, c.BatchNums, c.DevType)
		if arrT == nil {
			logger.Infof("not get heart data.")
			return nil
		}
		logger.Infof("heart data nums: %v", len(arrT))

		for _, v := range arrT {
			if v == nil {
				continue
			}

			r := TransRadarHeartFromStructToPb(v)
			if r == nil {
				continue
			}
			updateStartTime = r.GetCreateTime()
			if FilterHeartItem(originStartTime, updateStartTime) == false {
				continue
			}
			originStartTime = updateStartTime

			item := GetMemItem(r.GetCreateTime(), c.Sn, c.TaskType)
			retBuf = MarshalCall[*client.ReplayRadarHeart](r, retBuf, item)
		}

	case int32(client.EnumDevTypeList_TracerPDevTypeEnum): //tracerP
		arrT := QueryHeartItemsFromDb[bean.TracerReplayHeart](c.StartTime, c.EndTime, c.Sn, c.BatchNums, c.DevType)
		if arrT == nil {
			return nil
		}

		for _, v := range arrT {
			if v == nil {
				continue
			}

			r := TransTracerPHeartFromStructToPb(v)
			if r == nil {
				continue
			}

			updateStartTime = r.GetCreateTime()
			item := GetMemItem(r.GetCreateTime(), c.Sn, c.TaskType)
			retBuf = MarshalCall[*client.ReplayTracerPHeart](r, retBuf, item)
		}

	case int32(client.EnumDevTypeList_TracerSDevTypeEnum): //tracerS
		arrT := QueryHeartItemsFromDb[bean.TracerReplayHeart](c.StartTime, c.EndTime, c.Sn, c.BatchNums, c.DevType)
		if arrT == nil {
			return nil
		}

		for _, v := range arrT {
			if v == nil {
				continue
			}

			r := TransTracerSHeartFromStructToPb(v)
			if r == nil {
				continue
			}

			updateStartTime = r.GetCreateTime()
			item := GetMemItem(r.GetCreateTime(), c.Sn, c.TaskType)
			retBuf = MarshalCall[*client.ReplayTracerSHeart](r, retBuf, item)
		}

	case int32(client.EnumDevTypeList_TracerPro): // tracerPro
		arrT := QueryHeartItemsFromDb[bean.TracerReplayHeart](c.StartTime, c.EndTime, c.Sn, c.BatchNums, c.DevType)
		if arrT == nil {
			return nil
		}

		for _, v := range arrT {
			if v == nil {
				continue
			}

			r := TransTracerProHeartFromStructToPB(v)
			if r == nil {
				continue
			}

			updateStartTime = r.GetCreateTime()
			item := GetMemItem(r.GetCreateTime(), c.Sn, c.TaskType)
			retBuf = MarshalCall[*client.ReplayTracerSHeart](r, retBuf, item)
		}

	case int32(client.EnumDevTypeList_FpvDevTypeEnum): //fpv 车载FPV
		arrT := QueryHeartItemsFromDb[bean.FpvReplayHeartData](c.StartTime, c.EndTime, c.Sn, c.BatchNums, c.DevType)
		if arrT == nil {
			return nil
		}

		for _, v := range arrT {
			if v == nil {
				continue
			}

			r := TransFpvHeartFromStructToPb(v)
			if r == nil {
				continue
			}

			updateStartTime = r.GetCreateTime()
			item := GetMemItem(r.GetCreateTime(), c.Sn, c.TaskType)
			retBuf = MarshalCall[*client.ReplayFpvHeart](r, retBuf, item)
		}

	case int32(client.EnumDevTypeList_GunDevTypeEnum): //gun/screen 大枪（非云台）
		arrT := QueryHeartItemsFromDb[bean.GunReplayHeartData](c.StartTime, c.EndTime, c.Sn, c.BatchNums, c.DevType)
		if arrT == nil {
			return nil
		}

		for _, v := range arrT {
			if v == nil {
				continue
			}

			r := TransGunHeartFromStructToPb(v)
			if r == nil {
				continue
			}
			updateStartTime = r.GetCreateTime()
			item := GetMemItem(r.GetCreateTime(), c.Sn, c.TaskType)
			retBuf = MarshalCall[*client.ReplayGunHeart](r, retBuf, item)
		}

	case int32(client.EnumDevTypeList_SFLDevTypeEnum): //sfl 哨兵塔
		arrT := QueryHeartItemsFromDb[bean.SFLReplayHeartData](c.StartTime, c.EndTime, c.Sn, c.BatchNums, c.DevType)
		if arrT == nil {
			return nil
		}

		for _, v := range arrT {
			if v == nil {
				continue
			}

			r := TransSflHeartFromStructToPb(v)
			if r == nil {
				continue
			}

			updateStartTime = r.GetCreateTime()
			if FilterHeartItem(originStartTime, updateStartTime) == false {
				continue
			}
			originStartTime = updateStartTime

			item := GetMemItem(r.GetCreateTime(), c.Sn, c.TaskType)
			retBuf = MarshalCall[*client.ReplaySFLHeart](r, retBuf, item)
		}
	case int32(client.EnumDevTypeList_Sfl101): //sfl101 哨兵塔
		arrT := QueryHeartItemsFromDb[bean.SFL101ReplayHeartData](c.StartTime, c.EndTime, c.Sn, c.BatchNums, c.DevType)
		if arrT == nil {
			return nil
		}

		for _, v := range arrT {
			if v == nil {
				continue
			}

			r := TransSfl101HeartFromStructToPb(v)
			if r == nil {
				continue
			}

			updateStartTime = r.GetCreateTime()
			if FilterHeartItem(originStartTime, updateStartTime) == false {
				continue
			}
			originStartTime = updateStartTime

			item := GetMemItem(r.GetCreateTime(), c.Sn, c.TaskType)
			retBuf = MarshalCall[*client.ReplaySFL101Heart](r, retBuf, item)
		}
	case int32(client.EnumDevTypeList_GunCloud): //枪+云台
		arrT := QueryHeartItemsFromDb[bean.GunCloudReplayHeartData](c.StartTime, c.EndTime, c.Sn, c.BatchNums, c.DevType)
		if arrT == nil {
			return nil
		}

		for _, v := range arrT {
			if v == nil {
				continue
			}

			r := TransGunCloudHeartFromStructToPb(v)
			if r == nil {
				continue
			}

			updateStartTime = r.GetCreateTime()
			if FilterHeartItem(originStartTime, updateStartTime) == false {
				continue
			}
			originStartTime = updateStartTime

			item := GetMemItem(r.GetCreateTime(), c.Sn, c.TaskType)
			retBuf = MarshalCall[*client.ReplayGunCloudHeart](r, retBuf, item)
		}
	case int32(client.EnumDevTypeList_SpooferDevTypeEnum): // dev_nsf4000  导航诱导
		arrT := QueryHeartItemsFromDb[bean.SpooferReplayHeartData](c.StartTime, c.EndTime, c.Sn, c.BatchNums, c.DevType)
		if arrT == nil {
			return nil
		}

		for _, v := range arrT {
			if v == nil {
				continue
			}

			r := TransSpooferHeartFromStructToPb(v)
			if r == nil {
				continue
			}

			updateStartTime = r.GetCreateTime()
			if FilterHeartItem(originStartTime, updateStartTime) == false {
				continue
			}
			originStartTime = updateStartTime

			item := GetMemItem(r.GetCreateTime(), c.Sn, c.TaskType)
			retBuf = MarshalCall[*client.ReplaySpooferHeart](r, retBuf, item)
		}

	case int32(client.EnumDevTypeList_UrdDevTypeEnum): //dev_urd360 坤雷RF
		arrT := QueryHeartItemsFromDb[UrdStatusRepaly](c.StartTime, c.EndTime, c.Sn, c.BatchNums, c.DevType)
		if arrT == nil {
			return nil
		}

		for _, v := range arrT {
			if v == nil {
				continue
			}

			r := TransUrdfHeartFromStructToPb(v)

			if r == nil {
				continue
			}
			updateStartTime = r.GetCreateTime()
			if FilterHeartItem(originStartTime, updateStartTime) == false {
				continue
			}
			originStartTime = updateStartTime

			item := GetMemItem(r.GetCreateTime(), c.Sn, c.TaskType)
			retBuf = MarshalCall[*client.ReplayUrdHeart](r, retBuf, item)
		}
	default:
		logger.Errorf("not support dev type: %v", c.DevType)
		return nil
	}

	if updateStartTime > 0 && mng.LoadTask[c.Sn][c.TaskType].StartTime <= updateStartTime {
		logger.Infof("update start query db time from %v =>  %v", mng.LoadTask[c.Sn][c.TaskType].StartTime, updateStartTime)
		mng.LoadTask[c.Sn][c.TaskType].StartTime = updateStartTime
	}

	return retBuf
}

// ///////////////////////
type LoadDbForDetect struct {
	StoreBigCache
}

type FreqDetectAgentData struct {
	detectItem *client.TracerFreqDetectReport
	createTime int64
}

type SflDetectAgentData struct {
	detectItem *client.GimbalCounterDetectSocketInfo
	createTime int64
}
type GunCloudDetectAgentData struct {
	detectItem *client.GunsPlatformDetectSocketInfo
	createTime int64
}
type Sfl101DetectAgentData struct {
	detectItem *client.Sfl101DetectSocketInfo
	createTime int64
}

// Load 从数据库加载无人机检测信息
func (d *LoadDbForDetect) Load(c *QueueToDbMsg, mng *LoadMsgManager) []*MemItemIndexValue {
	if c == nil {
		return nil
	}
	var updateStartTime int64

	var retBuf []*MemItemIndexValue

	switch c.DevType {
	case int32(client.EnumDevTypeList_RadarDevTypeEnum): //radar 雷达，
		arrT := QueryDetectItemsFromDb[bean.RadarReplayDetect](c.StartTime, c.EndTime, c.Sn, c.BatchNums, c.DevType)
		if arrT == nil {
			return nil
		}

		for _, v := range arrT {
			if v == nil {
				continue
			}

			r := TransRadarDetectFromStructToPb(v)
			if r == nil {
				continue
			}
			updateStartTime = r.GetCreateTime()

			item := GetMemItem(r.GetCreateTime(), c.Sn, c.TaskType)
			retBuf = MarshalCall[*client.ReplayRadarDetect](r, retBuf, item)
		}

	case int32(client.EnumDevTypeList_TracerPDevTypeEnum): //tracerP
		arrT := QueryDetectItemsFromDb[bean.TracerReplayDetect](c.StartTime, c.EndTime, c.Sn, c.BatchNums, c.DevType)
		if arrT == nil {
			return nil
		}

		for _, v := range arrT {
			if v == nil {
				continue
			}

			r := TransTracerPDetectFromStructToPb(v)
			if r == nil {
				continue
			}

			updateStartTime = r.GetCreateTime()
			item := GetMemItem(r.GetCreateTime(), c.Sn, c.TaskType)
			retBuf = MarshalCall[*client.ReplayTracerPDetect](r, retBuf, item)
		}

	case int32(client.EnumDevTypeList_TracerSDevTypeEnum): //tracerS
		arrT := QueryDetectItemsFromDb[bean.TracerReplayDetect](c.StartTime, c.EndTime, c.Sn, c.BatchNums, c.DevType)
		if arrT == nil || len(arrT) <= 0 {
			return nil
		}

		detectOnceMap := make(map[int64]*FreqDetectAgentData)
		for _, v := range arrT {
			if v == nil {
				continue
			}

			session, ok := detectOnceMap[v.OnceSeq]
			if !ok || session == nil || session.detectItem == nil {
				a := &FreqDetectAgentData{
					detectItem: &client.TracerFreqDetectReport{
						Sn:        c.Sn,
						QxPower:   v.QxPower,
						DxPower:   v.DxPower,
						DxHorizon: v.DxHorizon,
					},
					createTime: v.CreateTime,
				}

				if v.HasUav == bean.FreqDetectUavHas {
					trs := TransTracerSDetectFromStructToPb2(v)
					if trs == nil {
						continue
					}
					a.detectItem.Info = append(a.detectItem.Info, trs)
				}
				detectOnceMap[v.OnceSeq] = a
			} else {
				if v.HasUav == bean.FreqDetectUavHas {
					trs := TransTracerSDetectFromStructToPb2(v)
					if trs == nil {
						continue
					}
					detectOnceMap[v.OnceSeq].detectItem.Info = append(detectOnceMap[v.OnceSeq].detectItem.Info, trs)
				}
			}
		}

		for _, v := range detectOnceMap {
			if v == nil || v.detectItem == nil {
				continue
			}
			updateStartTime = v.createTime
			item := GetMemItem(v.createTime, c.Sn, c.TaskType)
			retBuf = MarshalCall[*client.TracerFreqDetectReport](v.detectItem, retBuf, item)
		}

	case int32(client.EnumDevTypeList_TracerPro):
		arrT := QueryDetectItemsFromDb[bean.TracerReplayDetect](c.StartTime, c.EndTime, c.Sn, c.BatchNums, c.DevType)
		if arrT == nil {
			return nil
		}
		detectOnceMap := make(map[int64]*FreqDetectAgentData)

		for _, v := range arrT {
			if v == nil {
				continue
			}

			if v.DetectSrcType == RemoteIDReplaySQL || v.DetectSrcType == DroneAndRemoteIDReplaySQL || v.DetectSrcType == droneIDReplaySQL {
				r := TransTracerPDetectFromStructToPb(v)
				if r == nil {
					continue
				}
				updateStartTime = r.GetCreateTime()
				item := GetMemItem(r.GetCreateTime(), c.Sn, c.TaskType)
				detectItem := &client.ReplayTracerProDetect{
					DetectUavType: uint32(client.TracerDetectType_RemoteIDDetect),
					PDetectItem:   r,
				}
				retBuf = MarshalCall[*client.ReplayTracerProDetect](detectItem, retBuf, item)
				continue
			}

			session, ok := detectOnceMap[v.OnceSeq]
			if !ok || session == nil || session.detectItem == nil {
				a := &FreqDetectAgentData{
					detectItem: &client.TracerFreqDetectReport{
						Sn:        c.Sn,
						QxPower:   v.QxPower,
						DxPower:   v.DxPower,
						DxHorizon: v.DxHorizon,
					},
					createTime: v.CreateTime,
				}

				if v.HasUav == bean.FreqDetectUavHas {
					trs := TransTracerSDetectFromStructToPb2(v)
					if trs == nil {
						continue
					}
					a.detectItem.Info = append(a.detectItem.Info, trs)
				}
				detectOnceMap[v.OnceSeq] = a
			} else {
				if v.HasUav == bean.FreqDetectUavHas {
					trs := TransTracerSDetectFromStructToPb2(v)
					if trs == nil {
						continue
					}
					detectOnceMap[v.OnceSeq].detectItem.Info = append(detectOnceMap[v.OnceSeq].detectItem.Info, trs)
				}
			}
		}

		for _, v := range detectOnceMap {
			if v == nil || v.detectItem == nil {
				continue
			}

			detectItem := &client.ReplayTracerProDetect{
				DetectUavType: uint32(client.TracerDetectType_FreqDetect),
				SDetectItem:   v.detectItem,
			}

			updateStartTime = v.createTime
			item := GetMemItem(v.createTime, c.Sn, c.TaskType)
			retBuf = MarshalCall[*client.ReplayTracerProDetect](detectItem, retBuf, item)
		}

	case int32(client.EnumDevTypeList_FpvDevTypeEnum): //fpv 车载FPV
		arrT := QueryDetectItemsFromDb[bean.FpvReplayDetectData](c.StartTime, c.EndTime, c.Sn, c.BatchNums, c.DevType)
		if arrT == nil {
			return nil
		}

		for _, v := range arrT {
			if v == nil {
				continue
			}

			r := TransFpvDetectFromStructToPb(v)
			if r == nil {
				continue
			}

			updateStartTime = r.GetCreateTime()
			item := GetMemItem(r.GetCreateTime(), c.Sn, c.TaskType)
			retBuf = MarshalCall[*client.ReplayFpvDetect](r, retBuf, item)
		}

	case int32(client.EnumDevTypeList_GunDevTypeEnum): //gun/screen 大枪（非云台）
		logger.Infof("has not detect for gun ")

	case int32(client.EnumDevTypeList_SFLDevTypeEnum): //sfl 哨兵塔
		arrT := QueryDetectItemsFromDb[bean.SFLReplayDetectData](c.StartTime, c.EndTime, c.Sn, c.BatchNums, c.DevType)
		if arrT == nil {
			return nil
		}

		detectOnceMap := make(map[int64]*SflDetectAgentData)

		for _, v := range arrT {
			if v == nil {
				continue
			}

			session, ok := detectOnceMap[v.OnceSeq]
			if !ok || session == nil || session.detectItem == nil {
				a := &SflDetectAgentData{
					detectItem: &client.GimbalCounterDetectSocketInfo{
						Sn: c.Sn,
					},
					createTime: v.CreateTime,
				}
				detectOnceMap[v.OnceSeq] = a
			}

			trs := TransSflDetectFromStructToPbV2(v)
			if trs == nil {
				continue
			}
			detectOnceMap[v.OnceSeq].detectItem.List = append(detectOnceMap[v.OnceSeq].detectItem.List, trs)
		}

		for _, v := range detectOnceMap {
			if v == nil || v.detectItem == nil {
				continue
			}
			updateStartTime = v.createTime
			item := GetMemItem(v.createTime, c.Sn, c.TaskType)
			retBuf = MarshalCall[*client.GimbalCounterDetectSocketInfo](v.detectItem, retBuf, item)
		}
	case int32(client.EnumDevTypeList_Sfl101): //sfl101 哨兵塔
		arrT := QueryDetectItemsFromDb[bean.SFL101ReplayDetectData](c.StartTime, c.EndTime, c.Sn, c.BatchNums, c.DevType)
		if arrT == nil {
			return nil
		}

		detectOnceMap := make(map[int64]*Sfl101DetectAgentData)

		for _, v := range arrT {
			if v == nil {
				continue
			}

			session, ok := detectOnceMap[v.OnceSeq]
			if !ok || session == nil || session.detectItem == nil {
				a := &Sfl101DetectAgentData{
					detectItem: &client.Sfl101DetectSocketInfo{
						Sn: c.Sn,
					},
					createTime: v.CreateTime,
				}
				detectOnceMap[v.OnceSeq] = a
			}

			trs := TransSfl101DetectFromStructToPbV2(v)
			if trs == nil {
				continue
			}
			detectOnceMap[v.OnceSeq].detectItem.List = append(detectOnceMap[v.OnceSeq].detectItem.List, trs)
		}

		for _, v := range detectOnceMap {
			if v == nil || v.detectItem == nil {
				continue
			}
			updateStartTime = v.createTime
			item := GetMemItem(v.createTime, c.Sn, c.TaskType)
			retBuf = MarshalCall[*client.Sfl101DetectSocketInfo](v.detectItem, retBuf, item)
		}
	case int32(client.EnumDevTypeList_GunCloud): //GunCloud 枪+云台
		arrT := QueryDetectItemsFromDb[bean.GunCloudReplayDetectData](c.StartTime, c.EndTime, c.Sn, c.BatchNums, c.DevType)
		if arrT == nil {
			return nil
		}

		detectOnceMap := make(map[int64]*GunCloudDetectAgentData)

		for _, v := range arrT {
			if v == nil {
				continue
			}

			session, ok := detectOnceMap[v.OnceSeq]
			if !ok || session == nil || session.detectItem == nil {
				a := &GunCloudDetectAgentData{
					detectItem: &client.GunsPlatformDetectSocketInfo{
						Sn: c.Sn,
					},
					createTime: v.CreateTime,
				}
				detectOnceMap[v.OnceSeq] = a
			}

			trs := TransGunCloudDetectFromStructToPbV2(v)
			if trs == nil {
				continue
			}
			detectOnceMap[v.OnceSeq].detectItem.List = append(detectOnceMap[v.OnceSeq].detectItem.List, trs)
		}

		for _, v := range detectOnceMap {
			if v == nil || v.detectItem == nil {
				continue
			}
			updateStartTime = v.createTime
			item := GetMemItem(v.createTime, c.Sn, c.TaskType)
			retBuf = MarshalCall[*client.GunsPlatformDetectSocketInfo](v.detectItem, retBuf, item)
		}
	case int32(client.EnumDevTypeList_SpooferDevTypeEnum): // dev_nsf4000  导航诱导
		logger.Infof("spoofer has not detect info.")

	case int32(client.EnumDevTypeList_UrdDevTypeEnum): //dev_urd360 坤雷RF
		arrT := QueryDetectItemsFromDb[UrdDroneInfoReplay](c.StartTime, c.EndTime, c.Sn, c.BatchNums, c.DevType)
		if arrT == nil {
			return nil
		}

		for _, v := range arrT {
			if v == nil {
				continue
			}

			r := TransUrdfDetectFromStructToPb(v)
			if r == nil {
				continue
			}
			updateStartTime = r.GetCreateTime()
			item := GetMemItem(r.GetCreateTime(), c.Sn, c.TaskType)
			retBuf = MarshalCall[*client.ReplayUrdDetect](r, retBuf, item)
		}
	default:
		logger.Errorf("not support dev type: %v", c.DevType)
		return nil
	}

	if updateStartTime > 0 && mng.LoadTask[c.Sn][c.TaskType].StartTime <= updateStartTime {
		logger.Infof("update start query db time from %v  to %v", mng.LoadTask[c.Sn][c.TaskType].StartTime, updateStartTime)
		mng.LoadTask[c.Sn][c.TaskType].StartTime = updateStartTime
	}

	return retBuf
}

type LoadDbForPosture struct {
	StoreBigCache
}

func (p *LoadDbForPosture) Load(c *QueueToDbMsg, mng *LoadMsgManager) []*MemItemIndexValue {
	if c == nil {
		return nil
	}
	var updateStartTime int64

	var retBuf []*MemItemIndexValue

	switch c.DevType {
	case int32(client.EnumDevTypeList_RadarDevTypeEnum): //radar 雷达，
		arrT := QueryPostureItemFromDb[bean.RadarReplayPosture](c.StartTime, c.EndTime, c.Sn, c.BatchNums, c.DevType)
		if arrT == nil {
			return nil
		}

		for _, v := range arrT {
			if v == nil {
				continue
			}

			r := TransRadarPostureFromStructToPb(v)
			if r == nil {
				continue
			}
			updateStartTime = r.GetCreateTime()

			item := GetMemItem(r.GetCreateTime(), c.Sn, c.TaskType)
			retBuf = MarshalCall[*client.ReplayRadarPosture](r, retBuf, item)
		}

	case int32(client.EnumDevTypeList_TracerPDevTypeEnum): //tracerP
		logger.Infof("posture of tracerP contain in heart package ") //Pitching Rolling
	case int32(client.EnumDevTypeList_TracerSDevTypeEnum): //tracerS
		logger.Infof("posture of tracerP contain in heart package ")
	case int32(client.EnumDevTypeList_FpvDevTypeEnum): //fpv 车载FPV
		logger.Infof("posture of fpv has not posture info ")

	case int32(client.EnumDevTypeList_GunDevTypeEnum): //gun/screen 大枪（非云台）
		logger.Infof("posture of gun/screen contain in heart package") //GunDirection 这个字段

	case int32(client.EnumDevTypeList_SFLDevTypeEnum): //sfl 哨兵塔
		logger.Infof("posture of sfl contain in heart package") //GunDirection 这个字段
	case int32(client.EnumDevTypeList_Sfl101): //sfl101 哨兵塔
		logger.Infof("posture of sfl contain in heart package") //

	case int32(client.EnumDevTypeList_GunCloud): //GunCloud 枪+云台
		logger.Infof("posture of GunCloud contain in heart package")

	case int32(client.EnumDevTypeList_SpooferDevTypeEnum): // dev_nsf4000  导航诱导
		logger.Infof("nsf4000 has not posture info.")

	case int32(client.EnumDevTypeList_UrdDevTypeEnum): //dev_urd360 坤雷RF
		logger.Infof("urd360 has not posture info.")
	default:
		logger.Errorf("not support dev type: %v", c.DevType)
		return nil
	}

	if updateStartTime > 0 && mng.LoadTask[c.Sn][c.TaskType].StartTime <= updateStartTime {
		logger.Infof("update start query db time from %v  to %v", mng.LoadTask[c.Sn][c.TaskType].StartTime, updateStartTime)
		mng.LoadTask[c.Sn][c.TaskType].StartTime = updateStartTime
	}
	return retBuf
}

type LoadDbForHit struct {
	StoreBigCache
}

func (p *LoadDbForHit) Load(c *QueueToDbMsg, mng *LoadMsgManager) []*MemItemIndexValue {
	if c == nil {
		return nil
	}
	var updateStartTime int64

	var retBuf []*MemItemIndexValue

	switch c.DevType {
	case int32(client.EnumDevTypeList_RadarDevTypeEnum): //radar 雷达，
		logger.Infof("radar has not hit info ")

	case int32(client.EnumDevTypeList_TracerPDevTypeEnum): //tracerP
		logger.Infof("tracerP has not hit info   ") //Pitching Rolling
	case int32(client.EnumDevTypeList_TracerSDevTypeEnum): //tracerS
		logger.Infof("tracerS has not hit info ")
	case int32(client.EnumDevTypeList_FpvDevTypeEnum): //fpv 车载FPV
		logger.Infof("fpv has not hit info ")

	case int32(client.EnumDevTypeList_GunDevTypeEnum): //gun/screen 大枪（非云台）
		logger.Infof("gun/screen has not hit info")

	case int32(client.EnumDevTypeList_SFLDevTypeEnum): //sfl 哨兵塔
		arrT := QueryHitItemFromDb[bean.SFLReplayHitStatusData](c.StartTime, c.EndTime, c.Sn, c.BatchNums, c.DevType)
		if arrT == nil {
			return nil
		}

		for _, v := range arrT {
			if v == nil {
				continue
			}

			r := TransSflHitFromStructToPb(v)
			if r == nil {
				continue
			}
			updateStartTime = r.GetCreateTime()

			item := GetMemItem(r.GetCreateTime(), c.Sn, c.TaskType)
			retBuf = MarshalCall[*client.ReplaySFLHit](r, retBuf, item)
		}
	case int32(client.EnumDevTypeList_Sfl101): //sfl101 哨兵塔
		arrT := QueryHitItemFromDb[bean.SFL101ReplayHitStatusData](c.StartTime, c.EndTime, c.Sn, c.BatchNums, c.DevType)
		if arrT == nil {
			return nil
		}

		for _, v := range arrT {
			if v == nil {
				continue
			}

			r := TransSfl101HitFromStructToPb(v)
			if r == nil {
				continue
			}
			updateStartTime = r.GetCreateTime()

			item := GetMemItem(r.GetCreateTime(), c.Sn, c.TaskType)
			retBuf = MarshalCall[*client.ReplaySFL101Hit](r, retBuf, item)
		}
	case int32(client.EnumDevTypeList_GunCloud): //GunCloud  枪+云台
		arrT := QueryHitItemFromDb[bean.GunCloudReplayHitStatusData](c.StartTime, c.EndTime, c.Sn, c.BatchNums, c.DevType)
		if arrT == nil {
			return nil
		}

		for _, v := range arrT {
			if v == nil {
				continue
			}

			r := TransGunCloudHitFromStructToPb(v)
			if r == nil {
				continue
			}
			updateStartTime = r.GetCreateTime()

			item := GetMemItem(r.GetCreateTime(), c.Sn, c.TaskType)
			retBuf = MarshalCall[*client.ReplayGunCloudHit](r, retBuf, item)
		}
	case int32(client.EnumDevTypeList_SpooferDevTypeEnum): // dev_nsf4000  导航诱导
		logger.Infof("nsf4000 has not hit info.")

	case int32(client.EnumDevTypeList_UrdDevTypeEnum): //dev_urd360 坤雷RF
		logger.Infof("urd360 has not hit info.")
	default:
		logger.Errorf("not support dev type: %v", c.DevType)
		return nil
	}

	if updateStartTime > 0 && mng.LoadTask[c.Sn][c.TaskType].StartTime <= updateStartTime {
		logger.Infof("update start query db time from %v  to %v", mng.LoadTask[c.Sn][c.TaskType].StartTime, updateStartTime)
		mng.LoadTask[c.Sn][c.TaskType].StartTime = updateStartTime
	}
	return retBuf
}

type LoadDbForSpectrum struct {
	StoreBigCache
}

func (p *LoadDbForSpectrum) Load(c *QueueToDbMsg, mng *LoadMsgManager) []*MemItemIndexValue {
	if c == nil {
		return nil
	}
	var updateStartTime int64

	var retBuf []*MemItemIndexValue

	switch c.DevType {
	case int32(client.EnumDevTypeList_RadarDevTypeEnum): //radar 雷达，
		logger.Infof("radar has not Spectrum info.")
	case int32(client.EnumDevTypeList_TracerPDevTypeEnum): //tracerP
		logger.Infof("tracerP has not Spectrum info.")

	case int32(client.EnumDevTypeList_TracerSDevTypeEnum): //tracerS
		logger.Infof("tracerS has not Spectrum info.")

	case int32(client.EnumDevTypeList_FpvDevTypeEnum): //fpv 车载FPV
		logger.Infof("fpv has not Spectrum info.")

	case int32(client.EnumDevTypeList_GunDevTypeEnum): //gun/screen 大枪（非云台）
		logger.Infof("gun/screen has not Spectrum info ")

	case int32(client.EnumDevTypeList_SFLDevTypeEnum): //sfl 哨兵塔
		logger.Infof("sfl has not Spectrum info ")
	case int32(client.EnumDevTypeList_Sfl101): //sfl101 哨兵塔
		logger.Infof("sfl101 has not Spectrum info ")
	case int32(client.EnumDevTypeList_GunCloud): //GunCloud 枪+云台
		logger.Infof("GunCloud has not Spectrum info ")

	case int32(client.EnumDevTypeList_SpooferDevTypeEnum): // dev_nsf4000  导航诱导
		logger.Infof("nsf4000 has not Spectrum info ")

	case int32(client.EnumDevTypeList_UrdDevTypeEnum): //dev_urd360 坤雷RF
		arrT := QuerySpectrumItemFromDb[UrdSpectrumSDB](c.StartTime, c.EndTime, c.Sn, c.BatchNums, c.DevType)
		if arrT == nil {
			return nil
		}

		for _, v := range arrT {
			if v == nil {
				continue
			}

			r := TransUrdfSpectrumFromStructToPb(v)
			if r == nil {
				continue
			}
			updateStartTime = r.GetCreateTime()
			item := GetMemItem(r.GetCreateTime(), c.Sn, c.TaskType)
			retBuf = MarshalCall[*client.ReplayUrdSpectrum](r, retBuf, item)
		}
	default:
		logger.Errorf("not support dev type: %v", c.DevType)
		return nil
	}

	if updateStartTime > 0 && mng.LoadTask[c.Sn][c.TaskType].StartTime <= updateStartTime {
		logger.Infof("update start query db time from %v  to %v", mng.LoadTask[c.Sn][c.TaskType].StartTime, updateStartTime)
		mng.LoadTask[c.Sn][c.TaskType].StartTime = updateStartTime
	}

	return retBuf
}

type LoadMsgManager struct {
	ChLoaderClose chan *SignalDelSnTask
	ChLoadMsgToDb chan *QueueToDbMsg //所有发给db的通知消息
	ChMsgToQueue  chan []*MsgToQueue //所有发给queue的加载数据索引。大块在本线程中存在 LocalMem.

	//first key is sn, second key is task type. 保存加载数据任务，对 不同的 sn和业务 进行加载。 只接受第一请求时更新，期间请求不更新
	LoadTask map[string]map[int32]*QueueToDbMsg

	//加载后保存的大块数据地址，也是对不同的 sn和业务 分开存储，小的数据通过管道传给 发送队列线程。
	MemCache map[string]map[int32]*LocalMem

	StopCtx  context.Context
	Replayer *DataReplayer //
}

func NewLoadMsgManager(ctx context.Context, taskMng *DataReplayer) *LoadMsgManager {
	return &LoadMsgManager{
		ChLoadMsgToDb: make(chan *QueueToDbMsg, 1024),
		ChLoaderClose: make(chan *SignalDelSnTask, 30), //同时可以接受30个设备关闭的请求。
		ChMsgToQueue:  make(chan []*MsgToQueue),        //加载数据线程调用。

		LoadTask: make(map[string]map[int32]*QueueToDbMsg), //first key is sn, second key is task type

		StopCtx:  ctx,
		MemCache: taskMng.ReplayMem,

		Replayer: taskMng,
	}
}

func (lm *LoadMsgManager) isFirstNotifyLoadNotify(msg *QueueToDbMsg) bool {
	taskTypeItem, ok := lm.LoadTask[msg.Sn]
	if !ok || taskTypeItem == nil {
		return true
	}
	notifyItem, ok := taskTypeItem[msg.TaskType]
	if !ok || notifyItem == nil {
		return true
	}
	logger.Infof("has received loading msg notify more times; notify: %+v", msg)
	return false
}

// LoadDbMsgSendToQueue  加载某个sn 下的某种业务数据。
func (lm *LoadMsgManager) LoadDbMsgSendToQueue(cond *QueueToDbMsg) {
	if cond == nil {
		return
	}

	loadTask, ok := LoadMsgFromDb[cond.TaskType]
	if !ok || loadTask == nil {
		logger.Errorf("not support business type for load msg from db, %v", cond)
		return
	}

	// step 1: load data.
	data := loadTask.Load(cond, lm)

	// step 2: store big cache.
	for {
		if data == nil || len(data) <= 0 {
			logger.Infof("load data is empty")
			break
		}

		snMem, ok := lm.MemCache[cond.Sn]
		if !ok {
			logger.Errorf("not exit sn local mem, %v", cond)
			break
		}
		if snMem == nil {
			logger.Errorf("sn local mem is nil, %v", cond)
			break
		}

		busiMem, ok := snMem[cond.TaskType]
		if !ok {
			logger.Errorf("not exist busi mem, %v", cond)
			break
		}
		if busiMem == nil {
			logger.Errorf("busi mem is nil, %v", cond)
			break
		}

		/// must been called at end and need to break.
		loadTask.Store(data, cond, busiMem)
		break
	}

	// step 3: send notify to task goroutine.
	vItems := make([]*MsgToQueue, 0)
	for _, v := range data {
		item := &v.MsgToQueue
		vItems = append(vItems, item)
	}
	if len(vItems) <= 0 {
		logger.Infof("has not get items, is empty, %v", cond)
		return
	}
	lm.ChMsgToQueue <- vItems

	logger.Infof("send load msg to send task: %v, send queue data len: %v", cond, len(vItems))
}

func (lm *LoadMsgManager) DelLoadTask(sn string) {
	if len(sn) <= 0 {
		return
	}
	delete(lm.LoadTask, sn)
	logger.Infof("delete load task for sn: %v", sn)
}

func (lm *LoadMsgManager) processLoadMsgNotify(msg *QueueToDbMsg) bool {
	if msg == nil {
		return false
	}

	//仅仅是在第一个且没有记录时才更新，其他收到通知时使用本地条件。
	if lm.isFirstNotifyLoadNotify(msg) {
		if lm.LoadTask == nil {
			lm.LoadTask = make(map[string]map[int32]*QueueToDbMsg)
		}

		if _, ok := lm.LoadTask[msg.Sn]; !ok {
			lm.LoadTask[msg.Sn] = make(map[int32]*QueueToDbMsg)
		}

		if item, ok := lm.LoadTask[msg.Sn][msg.TaskType]; !ok || item == nil {

			newItem := &QueueToDbMsg{}
			copier.Copy(newItem, msg)
			lm.LoadTask[msg.Sn][msg.TaskType] = newItem

			logger.Infof("update load cnf: %v", lm.LoadTask[msg.Sn][msg.TaskType])
		}
	}

	loadMsgCond := lm.LoadTask[msg.Sn][msg.TaskType]
	lm.LoadDbMsgSendToQueue(loadMsgCond)

	return true
}

func (lm *LoadMsgManager) WaitNotifyToLoad() {
	go func() {
		defer func() {
			utils.HandlePanic()
		}()

		for {
			select {
			case qToDbMsg, isLoadMsg := <-lm.ChLoadMsgToDb:
				if isLoadMsg && qToDbMsg != nil {
					logger.Infof("receive load msg notify: %v", qToDbMsg)
					lm.processLoadMsgNotify(qToDbMsg)
					continue
				}

			case closeSignal, isToDelSn := <-lm.ChLoaderClose:
				if isToDelSn && closeSignal != nil {
					logger.Infof("receive del load task on sn: %v", closeSignal.Sn)
					lm.DelLoadTask(closeSignal.Sn)
				}

			case <-lm.StopCtx.Done():
				logger.Errorf("receive stop load data process.")
				return
			}
		}
	}()
}

func (lm *LoadMsgManager) SendNotifyToDb(signal *QueueToDbMsg) {
	if lm == nil || signal == nil {
		return
	}
	select {
	case lm.ChLoadMsgToDb <- signal:
		logger.Infof("ok: send load msg signal to loader ok, signal: %v", signal)
	default:
		//logger.Infof("not complete: send load msg signal to load process, signal: %v", signal)
	}
}
func (lm *LoadMsgManager) SendDelLoadOnSn(signal *SignalDelSnTask) {
	if lm == nil || signal == nil {
		return
	}

	logger.Infof("begin to send close loader for sn: %v", signal.Sn)

	lm.ChLoaderClose <- signal

	logger.Infof("send del load task on sn: %v", signal.Sn)
}

func (lm *LoadMsgManager) ReceiveMsgFromDb() []*MsgToQueue {
	var (
		ok   bool
		data []*MsgToQueue
	)

	select {
	case data, ok = <-lm.ChMsgToQueue:
		if !ok {
			logger.Errorf("receive close to queue data chan.")
			return nil
		}
		logger.Infof("to queue data item len: %v", len(data))

	default:
		_ = ok
	}
	return data
}

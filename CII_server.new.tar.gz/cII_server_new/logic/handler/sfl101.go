package handler

import (
	"adasgitlab.autel.com/tools/cuav_plugin/broker"
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/server"
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/ip"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/proto/mavlink"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
	"adasgitlab.autel.com/tools/cuav_server/repo/utils"
	"adasgitlab.autel.com/tools/slink_proto/slinkv1"
	"bytes"
	"context"
	"crypto/rand"
	"encoding/binary"
	"encoding/csv"
	"errors"
	"fmt"
	"github.com/360EntSecGroup-Skylar/excelize"
	"google.golang.org/protobuf/proto"
	"math/big"
	"os"
	"strconv"
	"strings"
	"sync"
	"time"
)

const (
	Sfl101TcpPort        = 25000
	Sfl101ServerMaxCount = 500
)

type Sfl101 struct {
	*Device
	dt common.DeviceType
}

var (
	Sfl101TcpServerLock sync.Mutex
	Sfl101TcpServerMap  sync.Map
	Sfl101HeartSum      uint8
	Sfl101DetectInfoMap = common.NewSfl101DetectInfoMap()
)

// HandleBroadCast 处理广播消息
func (d *Sfl101) HandleBroadCast(ctx context.Context, req *slinkv1.UdpBroadcastConfirmRequest) (*slinkv1.UdpBroadcastConfirmResponse, error) {
	if req.GetSn() == "" {
		logger.Info("device sn empty")
		return nil, errors.New("device sn empty")
	}
	//d.GetStatus(req.GetSn())
	//if status := d.GetStatus(req.GetSn()); status == common.DeviceDisenable {
	//	logger.Infof("device %v disable", req.GetSn())
	//	return nil, nil
	//}

	localIP := make([]string, 0)
	localIps, broadIps, err := ip.GetBroadcastAddress()
	if err != nil {
		logger.Error("Get IP error :%v", err)
	}
	for i, ip := range localIps {
		if i >= len(broadIps) {
			continue
		}
		localIP = append(localIP, ip)
	}
	logger.Debugf("[Sfl101] localIP:%v,", localIP)

	tcpServer := d.TcpServerCheck(req.GetSn(), localIP)
	DevSnMap.Store(tcpServer.Port, req.GetSn())
	d.ServerPort = tcpServer.Port

	//响应
	rsp := &slinkv1.UdpBroadcastConfirmResponse{
		Sn:       req.Sn,
		Addr:     ip.IPV4(tcpServer.Ip),
		Port:     uint16(tcpServer.Port),
		ConnType: 1,
	}
	return rsp, nil
}

func (d *Sfl101) TcpServerCheck(devSn string, localIP []string) *server.TcpServer {
	var tcpServer *server.TcpServer
	if s, ok := Sfl101TcpServerMap.Load(devSn); ok {
		tcpServer = s.(*server.TcpServer)
		isAlike := false
		for _, ip := range localIP {
			if ip == tcpServer.Ip {
				isAlike = true
			}
		}
		if isAlike == false { //查找的本地IP没有与之前相同的
			if tcpServer != nil {
				tcpServer.Stop()
			}
			deviceUsedPorts.Delete(tcpServer.Port)
			Sfl101TcpServerMap.Delete(devSn)
			DevSnMap.Delete(tcpServer.Port)
			tcpServer = nil
		}
	}

	//注册tcp服务
	if tcpServer == nil {
		port, err := ip.GetFreeTcpPort()
		if err != nil {
			logger.Error("Sfl101 tcp 获取可用端口失败：", err)
			port = d.getRandPort(Sfl101TcpPort, Sfl101TcpPort+Sfl101ServerMaxCount)
		}
		tcpServer = server.NewTcpServer(port, Handle)
		Sfl101TcpServerMap.Store(devSn, tcpServer)
		tcpServer.ServerType = uint8(common.DEV_SFL101)
		tcpServer.ServerName = devSn
		localAddr, _ := ip.GetLocalIp(d.UdpIp)
		tcpServer.Ip = localAddr
		go tcpServer.Start()
	}
	return tcpServer
}

func (d *Sfl101) getRandPort(min, max int64) int {
	maxBigInt := big.NewInt(max)
	i, _ := rand.Int(rand.Reader, maxBigInt)
	_, ok := deviceUsedPorts.Load(i.Int64())
	port := i.Int64()
	//缓存不存在或者符合范围
	if !ok && (port > min && port < max) {
		deviceUsedPorts.Store(port, port)
		return int(port)
	}
	return d.getRandPort(min, max)
}
func (d *Sfl101) GetStatus(sn string, subDevType int) int32 {
	statusRes := &client.GetStatusRes{}
	err := NewEquipList().GetStatus(context.Background(), &client.GetStatusReq{Sn: sn, EType: "Sfl101", SubDevType: int64(subDevType)}, statusRes)
	if err != nil {
		logger.Errorf("GetStatus err: %v", err.Error())
		return 0
	}

	return statusRes.IsEnable
}

func SendSfl101Heart() {
	ticker := time.NewTicker(time.Second * 1)
	defer ticker.Stop()
	for range ticker.C {
		DevStatusMap.Range(func(key, value interface{}) bool {
			dev := value.(*Device)
			if dev.DevType == common.DEV_SFL101 && dev.Status == common.DevOnline {
				reqMode := &Sfl101{
					Device: dev,
					dt:     common.DEV_SFL101,
				}
				reqMode.SendExtHeartbeat()
			}
			return true
		})
	}
}
func (d *Sfl101) SendExtHeartbeat() error {
	Sfl101HeartSum++
	if Sfl101HeartSum > 255 {
		Sfl101HeartSum = 0
	}
	req := &mavlink.Sfl101HeartbeatExtRequest{
		Sfl101HeartSum,
	}
	reqBuff := req.CreateSfl101HeartbeatExt()
	if d != nil && d.Conn != nil {
		_, err := d.Conn.Write(reqBuff)
		logger.Infof("Sfl101 c2发送心跳结果：%X", reqBuff)
		if err != nil {
			equipModel, err := GetEquipBySn(d.Sn)
			name := d.Sn
			if equipModel != nil && equipModel.Name != "" {
				name = equipModel.Name
			}
			dataInfo := &client.Sfl101HeartInfo{
				Header: &client.EquipmentMessageBoxEntity{
					Name:      name,
					Sn:        d.Sn,
					EquipType: int32(common.DEV_SFL101),
					MsgType:   mavlink.Sfl101HeartMsgReport,
				},
				Data: &client.Sfl101HeartInfoData{
					Sn:       d.Sn,
					IsOnline: common.DevOffline,
				},
			}
			if err == nil {
				dataInfo.Header.ParentType = int32(equipModel.ParentType)
				dataInfo.Header.ParentSn = equipModel.ParentSn
				dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
			}
			msg, err := proto.Marshal(dataInfo)
			if err != nil {
				logger.Error("marshal dataInfo err:", err)
				return err
			}
			report := &client.ClientReport{
				MsgType: common.ClientMsgIDSfl101HeartBeat,
				Data:    msg,
			}
			out, err := proto.Marshal(report)
			if err != nil {
				logger.Error("marshal report err:", err)
				return err
			}
			_ = mq.Sfl101MsgBroker.Publish(mq.Sfl101Topic, broker.NewMessage(out))
			logger.Info("sfl101 Offline report:", report)
		}
		return err
	}
	return nil
}

func NewSfl101(conn Connection, d []byte, dataLen int, remoteIp string, remotePort int, localIp string, serverPort int,
	mailBox map[int]*WaitTaskManager, dlimit *devLimit) DeviceInterface {
	sfl101 := &Sfl101{
		Device: &Device{
			Conn:        conn,
			Msg:         d,
			MsgLen:      dataLen,
			SourceId:    d[mavlink.SenderLoc],
			RemoteIp:    remoteIp,
			RemotePort:  remotePort,
			LocalIp:     localIp,
			ServerPort:  serverPort,
			WaitTaskMap: mailBox,
		},
	}

	return sfl101
}
func (d *Sfl101) Deal() {
	defer func() {
		if err := recover(); err != nil {
			logger.Error("Sfl101 deal 接收到panic:", err)
		}
	}()

	if d.MsgLen <= 0 {
		logger.Error("Sfl101 数据为null,不作处理:", d.Device.RemoteIp)
		return
	}
	d.MsgId = int(d.Msg[mavlink.MsgIdLoc])
	switch d.MsgId {
	case mavlink.Sfl101HeartMsg:
		d.Heart()
	case mavlink.Sfl101DevStateMsg:
		d.ReceiveSfl101DevStateMsg()

	case mavlink.Sfl101DetectMsg:
		d.ReceiveSfl101DetectMsg()

	case mavlink.Sfl101HitStatusMsg:
		d.ReceiveSfl101HitStatusMsg()

	case mavlink.Sfl101RadarChartMsg:
		d.ReceiveSfl101RadarChartMsg()
	case mavlink.Sfl101SendFreqData:
		d.ReceiveSfl101CollectData()
	case mavlink.Sfl101GetFreqCmd:
		d.ReceiveSfl101SetFreqCmd()
	case mavlink.Sfl101SendTimeFreq:
		d.ReceiveSfl101SendTimeFreq()
	case mavlink.Sfl101SendNoiseDataD6:
		d.ReceiveSfl101SendTimeFreqD6()
	case mavlink.Sfl101GetVersion:
		d.ReceiveSfl101GetVersion()
	case mavlink.Sfl101GetTime:
		d.ReceiveGetTime()
	case mavlink.Sfl101GetGNSS:
		d.ReceiveSfl101GetGNNS()
	case mavlink.Sfl101SetGNSS:
		d.ReceiveSfl101SetGNNS()
	case mavlink.Sfl101GetHitPith:
		d.ReceiveSfl101GetHitPith()
	case mavlink.Sfl101GetHitAngle:
		d.ReceiveSfl101GetHitAngle()
	case mavlink.Sfl101GetHitMode:
		d.ReceiveSfl101GetHitMode()
	case mavlink.Sfl101Reset:
		d.ReceiveSfl101Reset()
	case mavlink.Sfl101SendHitUav:
		d.ReceiveSfl101GetHitUav()

	case mavlink.Sfl101SetOnOff:
		d.ReceiveSfl101SetOnOff()

	case mavlink.Sfl101GetOnOff:
		d.ReceiveSfl101GetOnOff()
	case mavlink.Sfl101SetPith:
		d.ReceiveSfl101SetPith()
	case mavlink.Sfl101SetAngle:
		d.ReceiveSfl101SetAngle()
	case mavlink.Sfl101StopHit:
		d.ReceiveSfl101StopHit()
	case mavlink.Sfl101SetHitMode:
		d.ReceiveSfl101SetHitMode()
	case mavlink.Sfl101SetAutoHitMode:
		d.ReceiveSfl101SetAutoHitMode()
	case mavlink.Sfl101GetAutoHitMode:
		d.ReceiveSfl101GetAutoHitMode()
	case mavlink.Sfl101IdUpgradeF1:
		d.ReceiveSfl101UpdateF1()
	case mavlink.Sfl101IdUpgradeF2:
		d.ReceiveSfl101UpdateF2()
	case mavlink.Sfl101IdUpgradeF3:
		d.ReceiveSfl101UpdateF3()
	case mavlink.Sfl101HitTurn:
		d.ReceiveSfl101TurnHit()
	case mavlink.Sfl101HorizontalTurn:
		d.ReceiveSfl101HorizontalTurn()
	case mavlink.Sfl101VerticalTurn:
		d.ReceiveSfl101VerticalTurn()
	case mavlink.Sfl101CrashStop:
		d.ReceiveSfl101CrashStop()
	case mavlink.Sfl101SetNoise:
		d.ReceiveSfl101SetNoise()
	case mavlink.Sfl101SendNoiseData:
		d.ReceiveSfl101SendNoiseData()
	case mavlink.Sfl101GetFreqList:
		d.ReceiveSfl101GetFreqList()
	case mavlink.Sfl101SetPreciseHit:
		d.ReceiveSetPreciseHit()
	case mavlink.Sfl101GetPreciseHit:
		d.ReceiveGetPreciseHit()
	case mavlink.Sfl101SetInvalidFreqList:
		d.ReceiveSetInvalid()
	case mavlink.Sfl101GetInvalidFreqList:
		d.ReceiveGetInvalidList()
	case mavlink.Sfl101SetAutoRadius:
		d.ReceiveSfl101SetAutoRadius()
	case mavlink.Sfl101GetAutoRadius:
		d.ReceiveSfl101GetAutoRadius()
	case mavlink.Sfl101SetSwitchParam:
		d.ReceiveSfl101SetSwitchParameter()
	case mavlink.Sfl101GetSwitchParam:
		d.ReceiveSfl101GetSwitchParameter()
	case mavlink.Sfl101SetDevPosture:
		d.ReceiveSfl101SetPosture()
	case mavlink.Sfl101GetDevPosture:
		d.ReceiveSfl101GetPosture()

	default:
		logger.Error("Sfl101 未知Sfl101消息id:", d.MsgId)
		break
	}
}

// Sfl101OfflineReport SFL101离线处理
func Sfl101OfflineReport(sn string) {
	var tcpServer *server.TcpServer
	if s, ok := Sfl101TcpServerMap.Load(sn); ok {
		tcpServer = s.(*server.TcpServer)

		if tcpServer != nil {
			tcpServer.Stop()
		}
		deviceUsedPorts.Delete(tcpServer.Port)
		Sfl101TcpServerMap.Delete(sn)
		DevSnMap.Delete(tcpServer.Port)
		cachekeyDroneid := fmt.Sprintf("%d_%s", common.DEV_SFL101, sn)
		DevStatusMap.Delete(cachekeyDroneid)
		Sfl101DetectInfoMap.Clear()
		tcpServer = nil
	}

	equipModel, err := GetEquipBySn(sn)
	name := sn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	dataInfo := &client.Sfl101HeartInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        sn,
			EquipType: int32(common.DEV_SFL101),
			MsgType:   mavlink.Sfl101HeartMsgReport,
		},
		Data: &client.Sfl101HeartInfoData{
			Sn:       sn,
			IsOnline: common.DevOffline,
		},
	}
	if err == nil {
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgIDSfl101HeartBeat,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}
	dev := FindCacheDevice(sn, common.DEV_SFL101)
	if dev != nil {
		d := &Sfl101{Device: dev}
		d.collectTaskOffline(sn)
	}
	_ = mq.Sfl101MsgBroker.Publish(mq.Sfl101Topic, broker.NewMessage(out))
	logger.Info("sfl101 Offline report:", report)
	Sfl101OffLineEventReport(sn)
}

func Sfl101DetectDisappearEventReport(sn string) {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_SFL101, sn)
	eventId := ""

	if cache, ok := DevDetectMapOnEvent.Load(cacheKey); ok {
		detect := cache.(*DetectEvent)
		eventId = utils.GetEventId(detect.SessionId)
		logger.Infof("eventId: %v, sessionId: %v", eventId, detect.SessionId)
	} else {
		logger.Infof("has not eventId for sfl101 detect disappear event report, sn: %v", sn)
	}
	DevDetectMapOnEvent.Delete(cacheKey)

	equipModel, err := GetEquipBySn(sn)
	name := sn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	dataInfo := &client.Sfl101DetectInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        sn,
			EquipType: int32(common.DEV_SFL101),
			MsgType:   mavlink.Sfl101EventDetectDisappear,
		},
		Data: &client.Sfl101DetectSocketInfo{
			Sn:      sn,
			EventId: eventId,
		},
	}
	if err == nil {
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgSfl101DetectEventData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Info("sfl101 detect disappear event report:", report)
}
func Sfl101HitOverEventReport(hitNode *common.Sfl101HitEventInfo) {
	var (
		eventID                            = ""
		hitSucc                            = false
		hitOver *common.Sfl101HitEventInfo = nil
	)

	cacheKey := GetSfl101HitCacheKey(hitNode.UavSn, hitNode.DroneName, hitNode.ProductType)
	if cache, ok := Sfl101HitOverMapOnEvent.Load(cacheKey); ok {
		hitOver, ok = cache.(*common.Sfl101HitEventInfo)
		if !ok {
			return
		}

		eventID = utils.GetEventId(hitOver.SessionId)
		if time.Since(hitOver.DetectReportTime) > 3*time.Second {
			hitSucc = true //disappear at begin, or recently disappear
		}
	} else {
		return
	}
	Sfl101HitOverMapOnEvent.Delete(cacheKey)

	equipModel, err := GetEquipBySn(hitNode.Sn)
	name := hitNode.Sn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	dataInfo := &client.Sfl101HitStateInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        hitNode.Sn, // sfl101 sn
			EquipType: int32(common.DEV_SFL101),
		},
		Data: &client.Sfl101HitSocketInfo{
			SerialNum:      hitNode.UavSn,
			DroneName:      hitOver.DroneName,
			DroneLongitude: hitOver.DroneLongitude,
			DroneLatitude:  hitOver.DroneLatitude,
			DroneHeight:    hitOver.DroneHeight,
			DroneYawAngle:  hitOver.DroneYawAngle,
			EventId:        eventID,
		},
	}
	if err == nil {
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	if hitSucc == false {
		dataInfo.Header.MsgType = mavlink.Sfl101EventHitFail
	} else {
		dataInfo.Header.MsgType = mavlink.Sfl101EventHitSucc
	}

	logger.Infof("sfl101 hit over report: %v", dataInfo)
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgSfl101HitEventData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Infof("sfl101 hit status: %v, event report: %v", hitSucc, report)
}

func Sfl101OffLineEventReport(sn string) {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_SFL101, sn)
	eventId := ""

	if cache, ok := DevStatusMapOnEvent.Load(cacheKey); ok {
		dev := cache.(*Device)
		eventId = utils.GetEventId(dev.SessionId)
	}
	DevStatusMapOnEvent.Delete(cacheKey)

	equipModel, err := GetEquipBySn(sn)
	name := sn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	dataInfo := &client.Sfl101HeartInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        sn,
			EquipType: int32(common.DEV_SFL101),
			MsgType:   mavlink.Sfl101EventMsgOffLine,
		},
		Data: &client.Sfl101HeartInfoData{
			Sn:       sn,
			IsOnline: common.DevOffline,
			EventId:  eventId,
		},
	}
	if err == nil {
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgSfl101StatusEventData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Info("sfl101 Offline event report:", report)
}

// Heart 处理SFL101心跳消息
func (d *Sfl101) Heart() {
	heart := &mavlink.Sfl101Heart{}
	if err := d.UnmarshalPayload(heart); err != nil {
		logger.Errorf(err.Error())
		return
	}

	devSn := ByteToString(heart.Info.Sn[:])
	if devSn != "" {
		// update device status
		d.updateOnLineStatus(devSn, heart)
		d.updateStatus(devSn, int(heart.Info.DevSubId))
		//if isEnable := d.updateStatus(devSn); isEnable == common.DeviceDisenable {
		//	logger.Infof("Sfl101 device %v disable", devSn)
		//	return
		//}
		// report heartbeat
		d.HeartReport(devSn, heart)
	}
}
func (d *Sfl101) HeartReport(devSn string, heartInfo *mavlink.Sfl101Heart) {

	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	dataInfo := &client.Sfl101HeartInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        devSn,
			EquipType: int32(common.DEV_SFL101),
			MsgType:   mavlink.Sfl101HeartMsgReport,
		},
		Data: &client.Sfl101HeartInfoData{
			Sn:              devSn,
			TimeStamp:       int32(heartInfo.Info.TimeStamp),
			WorkStatus:      int32(heartInfo.Info.WorkStatus),
			IsOnline:        common.DevOnline,
			HitFreq:         int32(heartInfo.Info.HitFreq),
			DetectFreq:      float64(heartInfo.Info.DetectFreq) / DetectFreqTion,
			Elevation:       float64(heartInfo.Info.Elevation) / ElevationTion,
			GunDirection:    float64(heartInfo.Info.GunDirection) / GunDirectTion,
			GunLongitude:    float64(heartInfo.Info.GunLongitude) / GunLongitudeTion,
			GunLatitude:     float64(heartInfo.Info.GunLatitude) / GunLatitudeTion,
			GunAltitude:     float64(heartInfo.Info.GunAltitude),
			SatellitesNum:   int32(heartInfo.Info.SatellitesNum),
			FaultLevel:      int32(heartInfo.Info.FaultLevel),
			CtrlFault:       int32(heartInfo.Info.CtrlFault),
			AeagFault:       int32(heartInfo.Info.AeagFault),
			TracerFault:     int32(heartInfo.Info.TracerFault),
			WorkStatusParam: int32(heartInfo.Info.WorkStatusParam),
			DevSubId:        int32(heartInfo.Info.DevSubId),
		},
	}
	if err == nil {
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgIDSfl101HeartBeat,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.Sfl101MsgBroker.Publish(mq.Sfl101Topic, broker.NewMessage(out))

	logger.Infof("Sfl101 heartbeat has reported, devSn:%v,report:%v", devSn, dataInfo.Data)
}

func (d *Sfl101) updateOnLineStatus(sn string, heartInfo *mavlink.Sfl101Heart) int32 {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_SFL101, sn)
	if cache, ok := DevStatusMapOnEvent.Load(cacheKey); ok {
		dev := cache.(*Device)
		//if dev.IsEnable == common.DeviceDisenable {
		//	return common.DeviceDisenable
		//}
		dev.Status = common.DevOnline
		dev.LastHeartTime = time.Now()
		dev.GetStatusInterval = time.Now()
		return common.DeviceEnable
	}

	dev := &Device{
		Sn:                sn,
		Status:            common.DevOnline,
		RemoteIp:          d.RemoteIp,
		RemotePort:        d.RemotePort,
		LocalIp:           d.LocalIp,
		ServerPort:        d.ServerPort,
		DevType:           common.DEV_SFL101,
		FirstHeartTime:    time.Now(),
		LastHeartTime:     time.Now(),
		SourceId:          d.SourceId,
		IsEnable:          common.DeviceEnable,
		GetStatusInterval: time.Now(),
		SessionId:         GetGlobalSessionId(),
	}
	DevStatusMapOnEvent.Store(cacheKey, dev)
	//SendNotify

	go func() {
		equipModel, err := GetEquipBySn(sn)
		name := sn
		if equipModel != nil && equipModel.Name != "" {
			name = equipModel.Name
		}
		dataInfo := &client.Sfl101HeartInfo{
			Header: &client.EquipmentMessageBoxEntity{
				Name:      name,
				Sn:        sn,
				EquipType: int32(common.DEV_SFL101),
				MsgType:   mavlink.Sfl101EventMsgOnline,
			},
			Data: &client.Sfl101HeartInfoData{
				Sn:           sn,
				EventId:      utils.GetEventId(dev.SessionId),
				GunLatitude:  float64(heartInfo.Info.GunLatitude) / GunLatitudeTion,
				GunLongitude: float64(heartInfo.Info.GunLongitude) / GunLongitudeTion,
			},
		}
		if err == nil {
			dataInfo.Header.ParentType = int32(equipModel.ParentType)
			dataInfo.Header.ParentSn = equipModel.ParentSn
			dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
		}
		msg, err := proto.Marshal(dataInfo)
		if err != nil {
			logger.Error("marshal dataInfo err:", err)
			return
		}

		report := &client.ClientReport{
			MsgType: common.ClientMsgSFlStatusEventData,
			Data:    msg,
		}
		out, err := proto.Marshal(report)
		if err != nil {
			logger.Error("marshal report err:", err)
			return
		}

		_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
		logger.Infof("Sfl101 heartbeat event has reported, devSn: %v,report:%v", sn, dataInfo.Data)
	}()
	return common.DeviceEnable

}
func (d *Sfl101) updateStatus(sn string, subDevType int) int32 {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_SFL101, sn)
	if cache, ok := DevStatusMap.Load(cacheKey); ok {
		dev := cache.(*Device)
		//if dev.IsEnable == common.DeviceDisenable {
		//	return common.DeviceDisenable
		//}
		dev.Status = common.DevOnline
		dev.Conn = d.Conn
		dev.WaitTaskMap = d.WaitTaskMap
		dev.RemoteIp = d.RemoteIp
		dev.LastHeartTime = time.Now()
		dev.GetStatusInterval = time.Now()
		//if dev.IsEnable != common.DeviceDisenable && dev.IsEnable != common.DeviceEnable {
		//dev.IsEnable = d.GetStatus(sn)
		//}
		d.GetStatus(sn, subDevType)
		return common.DeviceEnable
	} else {
		dev := &Device{
			Sn:                sn,
			Conn:              d.Conn,
			Status:            common.DevOnline,
			RemoteIp:          d.RemoteIp,
			RemotePort:        d.RemotePort,
			LocalIp:           d.LocalIp,
			ServerPort:        d.ServerPort,
			DevType:           common.DEV_SFL101,
			FirstHeartTime:    time.Now(),
			LastHeartTime:     time.Now(),
			SourceId:          d.SourceId,
			IsEnable:          d.GetStatus(sn, subDevType),
			GetStatusInterval: time.Now(),
			WaitTaskMap:       d.WaitTaskMap,
		}
		DevStatusMap.Store(cacheKey, dev)
		go func() {
			time.Sleep(time.Second * 2)
			e := NewEquipList().Update(context.Background(), &client.EquipCrudReq{
				Sn: sn,
				Ip: d.RemoteIp,
			}, &client.EquipCrudRes{})
			logger.Infof("update dev ip: %v, e: %v", d.RemoteIp, e)

			//发送白名单给Sfl101设备
			go SendDevWhiteListToSfl101()
			if d.Conn == nil {
				return
			}
			appVer, err := d.SendGetVersionInfo(sn)
			logger.Infof("sfl101 get  Ver: %v", appVer)
			if err != nil {
				logger.Infof("sfl101 get  Ver runVer: %v err: %v \n", appVer, err)
				return
			}
			if appVer != "" {
				err = NewEquipList().Update(context.Background(), &client.EquipCrudReq{
					Sn:         sn,
					DevVersion: appVer,
				}, &client.EquipCrudRes{})
				if err != nil {
					logger.Error("Update EquipList err: ", err)
				}
			}
		}()
		return dev.IsEnable
	}
}
func (d *Sfl101) updateStatusDetect(sn string) int32 {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_SFL101, sn)
	if cache, ok := DevStatusMap.Load(cacheKey); ok {
		dev := cache.(*Device)
		//if dev.IsEnable == common.DeviceDisenable {
		//	return common.DeviceDisenable
		//}
		dev.Status = common.DevOnline
		dev.Conn = d.Conn
		dev.WaitTaskMap = d.WaitTaskMap
		dev.RemoteIp = d.RemoteIp
		dev.LastHeartTime = time.Now()
		dev.GetStatusInterval = time.Now()
		//if dev.IsEnable != common.DeviceDisenable && dev.IsEnable != common.DeviceEnable {
		//dev.IsEnable = d.GetStatus(sn)
		//}
		return common.DeviceEnable
	} else {
		dev := &Device{
			Sn:                sn,
			Conn:              d.Conn,
			Status:            common.DevOnline,
			RemoteIp:          d.RemoteIp,
			RemotePort:        d.RemotePort,
			LocalIp:           d.LocalIp,
			ServerPort:        d.ServerPort,
			DevType:           common.DEV_SFL101,
			FirstHeartTime:    time.Now(),
			LastHeartTime:     time.Now(),
			SourceId:          d.SourceId,
			IsEnable:          common.DeviceEnable,
			GetStatusInterval: time.Now(),
			WaitTaskMap:       d.WaitTaskMap,
		}
		DevStatusMap.Store(cacheKey, dev)
		go func() {
			time.Sleep(time.Second * 2)
			e := NewEquipList().Update(context.Background(), &client.EquipCrudReq{
				Sn: sn,
				Ip: d.RemoteIp,
			}, &client.EquipCrudRes{})
			logger.Infof("update dev ip: %v, e: %v", d.RemoteIp, e)

			//发送白名单给Sfl101设备
			go SendDevWhiteListToSfl101()
			if d.Conn == nil {
				return
			}
			appVer, err := d.SendGetVersionInfo(sn)
			logger.Infof("sfl101 get  Ver: %v", appVer)
			if err != nil {
				logger.Infof("sfl101 get  Ver runVer: %v err: %v \n", appVer, err)
				return
			}
			if appVer != "" {
				err = NewEquipList().Update(context.Background(), &client.EquipCrudReq{
					Sn:         sn,
					DevVersion: appVer,
				}, &client.EquipCrudRes{})
				if err != nil {
					logger.Error("Update EquipList err: ", err)
				}
			}
		}()
		return dev.IsEnable
	}
}
func (d *Sfl101) UnmarshalPayload(data *mavlink.Sfl101Heart) error {
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("Sfl101 UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("Sfl101 UnmarshalPayload read data err: %v", err)
	}

	return nil
}

func (d *Sfl101) ReceiveGetChannelReq() {
	Sfl101TcpServerLock.Lock()
	defer Sfl101TcpServerLock.Unlock()

	devSn := d.UnMarshalGetChannelReq()
	if devSn == "" {
		logger.Info("Sfl101 device sn empty")
		return
	}

	//if isContinue := d.deviceDiscover(devSn); !isContinue {
	//	logger.Error("droneID等待设备确认：", devSn)
	//	return
	//}
	//d.GetStatus(devSn)
	//if status := d.GetStatus(devSn); status == common.DeviceDisenable {
	//	logger.Infof("Sfl101 device %v disable", devSn)
	//	return
	//}

	localIP := make([]string, 0)

	localIps, broadIps, err := ip.GetBroadcastAddress()
	if err != nil {
		logger.Error("Sfl101 Get IP error :%v", err)
	}
	for i, ip := range localIps {
		if i >= len(broadIps) {
			continue
		}
		localIP = append(localIP, ip)
	}
	logger.Debugf("[Sfl101] localIP:%v,", localIP)

	tcpServer := d.TcpServerCheck(devSn, localIP)
	DevSnMap.Store(tcpServer.Port, devSn)
	d.ServerPort = tcpServer.Port

	//响应
	switch d.MsgId {
	case mavlink.Sfl101UdpBroadcastResponse:
		logger.Info("[Sfl101] receive Broadcast BB Msg")
		UdpBroadcastSendChannel(devSn, d.UdpIp, d.SourceId, tcpServer)
		break
	default:
		break
	}

	return
}

func (d *Sfl101) UnMarshalGetChannelReq() string {
	devSn := ""
	switch d.MsgId {
	case mavlink.Sfl101UdpBroadcastResponse:
		req := &mavlink.UdpBroadcastConfirmRequest{}
		d.GetPacket(req)
		devSn = strings.TrimRight(string(req.Sn[:]), string(rune(0)))
		break
	default:
		break
	}
	return devSn
}

func (d *Sfl101) GetPacket(message mavlink.Message) *mavlink.MavPacket {
	logger.Infof("Sfl101 GetPacket is [% x]", d.Msg)
	req := mavlink.NewNullPacket(message)
	buff := &bytes.Buffer{}
	if err := binary.Write(buff, binary.LittleEndian, d.Msg); err != nil {
		logger.Error("Sfl101 GetPacket write buff err:", err)
		return nil

	}
	if err := binary.Read(buff, binary.LittleEndian, &req.Header); err != nil {
		logger.Error("Sfl101 GetPacket read header err:", err)
		return nil
	}
	if err := binary.Read(buff, binary.LittleEndian, req.Msg); err != nil {
		logger.Error("Sfl101 GetPacket read msg err:", err)
		return nil
	}
	return req
}

func (d *Sfl101) ReceiveSfl101DetectMsg() {
	result := &mavlink.Sfl101Detect{}
	if err := d.UnmarshalPayloadSfl101Detect(result); err != nil {
		logger.Errorf(err.Error())
		return
	}

	devSn := ByteToString(result.Info.SN[:])
	if devSn != "" {
		d.updateStatusDetect(devSn)
		//if isEnable := d.updateStatus(devSn); isEnable == common.DeviceDisenable {
		//	logger.Infof("Sfl101 device %v disable", devSn)
		//	return
		//}
		d.Sfl101DetectReport(devSn, result)
	}
	logger.Info("--->End Receive Sfl101 Detect")
}
func (d *Sfl101) Sfl101DetectAppearEvent(sn string, detectInfo *client.Sfl101DetectSocketInfo) {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_SFL101, sn)
	if cache, ok := DevDetectMapOnEvent.Load(cacheKey); ok {
		detect := cache.(*DetectEvent)
		detect.LastReceiveTime = time.Now()
		return
	}

	if len(detectInfo.GetList()) <= 0 {
		logger.Infof("has not detect any uav")
		return
	}

	detect := &DetectEvent{
		Sn:              sn,
		LastReceiveTime: time.Now(),
		DevType:         common.DEV_SFL101,
		SessionId:       GetGlobalSessionId(),
	}
	DevDetectMapOnEvent.Store(cacheKey, detect)
	detectInfo.EventId = utils.GetEventId(detect.SessionId)

	go func() {
		equipModel, err := GetEquipBySn(sn)
		name := sn
		if equipModel != nil && equipModel.Name != "" {
			name = equipModel.Name
		}
		msg := &client.Sfl101DetectInfo{
			Header: &client.EquipmentMessageBoxEntity{
				Name:      name,
				Sn:        sn,
				EquipType: int32(common.DEV_SFL101),
				MsgType:   mavlink.Sfl101EventDetectAppear,
			},
			Data: detectInfo,
		}
		if err == nil {
			msg.Header.ParentType = int32(equipModel.ParentType)
			msg.Header.ParentSn = equipModel.ParentSn
			msg.Header.IsIntegrated = equipModel.IsIntegrated
		}
		msgOut, err := proto.Marshal(msg)
		if err != nil {
			logger.Error("marshal msg err:", err)
			return
		}
		report := &client.ClientReport{
			MsgType: common.ClientMsgSFlDetectEventData,
			Data:    msgOut,
		}
		out, err := proto.Marshal(report)
		if err != nil {
			logger.Error("marshal dataInfo err:", err)
			return
		}

		_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
		logger.Infof("Sfl101 detect uav event has reported, devSn: %v,report:%v", sn, detectInfo.GetList())
	}()
	//go SendAlarmEmail(detectInfo)

}

// Sfl101HitOverCheckEventReport 打击无人机时，无人机位置变动满足打击成功，上报打击成功事件。
func (d *Sfl101) Sfl101HitOverCheckEventReport(uav *mavlink.Sfl101DetectDescription, devSn string) {
	if uav == nil {
		return
	}

	uavSn := ByteToString(uav.SerialNum[:])
	cacheKey := GetSfl101HitCacheKey(uavSn, ByteToString(uav.DroneName[:]), int32(uav.ProductType))
	cache, ok := Sfl101HitOverMapOnEvent.Load(cacheKey)
	if !ok || cache == nil {
		return
	}
	hitOverNode, ok := cache.(*common.Sfl101HitEventInfo)
	if !ok {
		return
	}

	hitSucc := CalcHitOverStatus(uav.DroneHeight, uav.UDistance)
	if !hitSucc {
		//如果不满足打击成功，则继续记录无人机上报信息。
		hitOverNode.DetectReportTime = time.Now()
		//
		hitOverNode.DroneName = ByteToString(uav.DroneName[:])
		hitOverNode.DroneLongitude = float64(uav.DroneLongitude) / DroneTion
		hitOverNode.DroneLatitude = float64(uav.DroneLatitude) / DroneTion
		hitOverNode.DroneHeight = float64(uav.DroneHeight) / DroneHeightTion
		hitOverNode.DroneYawAngle = float64(uav.DroneYawAngle) / DroneYawTion
		//
		Sfl101HitOverMapOnEvent.Store(cacheKey, hitOverNode)
		logger.Infof("hit fail, uav: %v", cacheKey)
		return
	}

	// 打击满足成功，则上报打击成功事件
	eventId := utils.GetEventId(hitOverNode.SessionId)
	logger.Infof("hit succ, uav: %v, sn: %v", cacheKey, devSn)
	Sfl101HitOverMapOnEvent.Delete(cacheKey)

	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	dataInfo := &client.Sfl101HitStateInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        devSn,
			EquipType: int32(common.DEV_SFL101),
			MsgType:   mavlink.Sfl101EventHitSucc,
		},
		Data: &client.Sfl101HitSocketInfo{
			SerialNum:      uavSn,
			DroneName:      ByteToString(uav.DroneName[:]),
			DroneLongitude: float64(uav.DroneLongitude) / DroneTion,
			DroneLatitude:  float64(uav.DroneLatitude) / DroneTion,
			DroneHeight:    float64(uav.DroneHeight) / DroneHeightTion,
			DroneYawAngle:  float64(uav.DroneYawAngle) / DroneYawTion,
			EventId:        eventId,
		},
	}
	if err == nil {
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	logger.Infof("sfl101 hit succ report event: %v", dataInfo)

	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgSfl101HitEventData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Info("sfl101 hit succ event report:", report)
}
func Sfl101CheckInputNum(info *mavlink.Sfl101Hit) *mavlink.Sfl101Hit {
	if info.Info.DroneLongitude == InvalidValueInt32 {
		info.Info.DroneLongitude = 0
	}
	if info.Info.DroneLatitude == InvalidValueInt32 {
		info.Info.DroneLatitude = 0
	}
	if info.Info.DroneHeight == InvalidValueInt16 {
		info.Info.DroneHeight = 0
	}
	if info.Info.DroneYawAngle == InvalidValueInt16 {
		info.Info.DroneYawAngle = 0
	}
	if info.Info.DroneSpeed == InvalidValueInt16 {
		info.Info.DroneSpeed = 0
	}
	if info.Info.DroneVerticalSpeed == InvalidValueInt16 {
		info.Info.DroneVerticalSpeed = 0
	}
	if info.Info.DroneSailLongitude == InvalidValueInt32 {
		info.Info.DroneSailLongitude = 0
	}
	if info.Info.DroneSailLatitude == InvalidValueInt32 {
		info.Info.DroneSailLatitude = 0
	}
	if info.Info.PilotLongitude == InvalidValueInt32 {
		info.Info.PilotLongitude = 0
	}
	if info.Info.PilotLatitude == InvalidValueInt32 {
		info.Info.PilotLatitude = 0
	}
	if info.Info.DroneHorizon == InvalidValueInt32 {
		info.Info.DroneHorizon = -1
	}
	if info.Info.DronePitch == InvalidValueInt32 {
		info.Info.DronePitch = -1
	}

	if info.Info.UDistance == InvalidValueUInt16 {
		info.Info.UDistance = 0
	}
	if info.Info.UDangerLevels == InvalidValueInt16 {
		info.Info.UDangerLevels = 0
	}
	if info.Info.UFreq == InvalidValueInt32 {
		info.Info.UFreq = 0
	}

	return info
}
func Sfl101DetectCheckInputNum(drone *mavlink.Sfl101DetectDescription) *mavlink.Sfl101DetectDescription {
	if drone.DroneLongitude == InvalidValueInt32 {
		drone.DroneLongitude = 0
	}
	if drone.DroneLatitude == InvalidValueInt32 {
		drone.DroneLatitude = 0
	}
	if drone.DroneHeight == InvalidValueInt16 {
		drone.DroneHeight = 0
	}
	if drone.DroneYawAngle == InvalidValueInt16 {
		drone.DroneYawAngle = 0
	}
	if drone.DroneSpeed == InvalidValueInt16 {
		drone.DroneSpeed = 0
	}
	if drone.DroneVerticalSpeed == InvalidValueInt16 {
		drone.DroneVerticalSpeed = 0
	}
	if drone.DroneSailLongitude == InvalidValueInt32 {
		drone.DroneSailLongitude = 0
	}
	if drone.DroneSailLatitude == InvalidValueInt32 {
		drone.DroneSailLatitude = 0
	}
	if drone.PilotLongitude == InvalidValueInt32 {
		drone.PilotLongitude = 0
	}
	if drone.PilotLatitude == InvalidValueInt32 {
		drone.PilotLatitude = 0
	}
	if drone.DroneHorizon == InvalidValueInt32 {
		drone.DroneHorizon = -1
	}
	if drone.DronePitch == InvalidValueInt32 {
		drone.DronePitch = -1
	}
	if drone.UDistance == InvalidValueInt16 {
		drone.UDistance = 0
	}
	if drone.UDangerLevels == InvalidValueInt16 {
		drone.UDangerLevels = 0
	}
	if drone.UFreq == InvalidValueInt32 {
		drone.UFreq = 0
	}
	return drone
}
func (d *Sfl101) Sfl101DetectReport(devSn string, detectInfo *mavlink.Sfl101Detect) {
	dataInfo := &client.Sfl101DetectSocketInfo{}
	dataInfo.List = make([]*client.Sfl101DetectDroneInfo, 0, len(detectInfo.Description))
	dataInfo.Sn = devSn
	dataInfo.DetectionNum = int32(detectInfo.Info.DetectionNum)
	//查白名单中的无人机，在Tracer侦测结果中添加无人机角色
	whiteList := &client.ListResAll{}
	err := NewWhiteList().ListAll(context.Background(), &client.ListReqAll{}, whiteList)
	if err != nil {
		logger.Error("Get whiteList err: ", err)
		return
	}

	var dstDetectItems []*client.Sfl101DetectDroneInfo
	//检查无效值
	for _, drone := range detectInfo.Description {
		if drone.Source == 0 {
			drone = Sfl101DetectCheckInputNum(drone)
			//1-敌军 2-友军 3-未知 4-中立     批量导入为2友军
			var role int32
			for _, info := range whiteList.WhiteList {
				if info.Sn == ByteToString(drone.SerialNum[:]) && info.Sn != "" {
					role = info.Role
				}
			}
			if role == ERRTYPE {
				role = ENEMY
			}

			var wifiMac [6]uint8
			wifiMac = drone.WifiMac
			wifiMacBytes := make([]byte, len(wifiMac))
			for i, v := range wifiMac {
				wifiMacBytes[i] = v
			}

			r := &client.Sfl101DetectDroneInfo{
				ProductType:        int32(drone.ProductType),
				DroneName:          ByteToString(drone.DroneName[:]),
				SerialNum:          ByteToString(drone.SerialNum[:]),
				DroneLongitude:     float64(drone.DroneLongitude) / DroneTion,
				DroneLatitude:      float64(drone.DroneLatitude) / DroneTion,
				DroneHeight:        float64(drone.DroneHeight) / DroneHeightTion,
				DroneYawAngle:      float64(drone.DroneYawAngle) / DroneYawTion,
				DroneSpeed:         float64(drone.DroneSpeed) / DroneSpeedTion,
				DroneVerticalSpeed: float64(drone.DroneVerticalSpeed) / DroneVerticalSpeedTion,
				SpeedDirection:     int32(drone.SpeedDerection) / DroneSpeedTion,
				DroneSailLongitude: float64(drone.DroneSailLongitude) / DroneSailLongitudeTion,
				DroneSailLatitude:  float64(drone.DroneSailLatitude) / DroneSailLatitudeTion,
				PilotLongitude:     float64(drone.PilotLongitude) / DroneTion,
				PilotLatitude:      float64(drone.PilotLatitude) / DroneTion,
				DroneHorizon:       float64(drone.DroneHorizon) / DroneHorizonTion,
				DronePitch:         float64(drone.DronePitch) / DronePitch,
				UFreq:              float64(drone.UFreq) / DetectFreqTion,
				UDistance:          int32(drone.UDistance),
				UDangerLevels:      int32(drone.UDangerLevels),
				Role:               role,
				UZC:                int32(drone.Uzc),
				UDirStatus:         int32(drone.UDirStatus),
				UNumber:            uint32(drone.UNumber),
				GpsClocks:          drone.GpsClocks,
				TimeStampRid:       drone.TimestampRid,
				IdType:             uint32(drone.IdType),
				WifiMac:            wifiMacBytes,
				FlagTime:           drone.FlagTime,
			}

			r.DroneName = common.ConstructDroneName(r.DroneName, r.SerialNum, r.UNumber)
			logger.Debugf("GimbalCounterDetectDroneInfo : r = %+v", r)
			//过滤频谱数据
			if r.SerialNum != "" && role != FRIEND {
				//计算无人机威胁等级
				fd, err := NewAlarmControl().GetDroneThreatLevel(&GetThreatLevelReq{
					DroneSn:        r.SerialNum,
					DroneObjId:     0,
					DroneLongitude: r.DroneLongitude,
					DroneLatitude:  r.DroneLatitude,
					DevSn:          devSn,
				})
				if err != nil {
					logger.Errorf("Sfl101DetectReport GetDroneThreatLevel err: %v", err)
				} else {
					r.AlarmId = fd.AlarmId
					r.EventId = fd.EventId
					r.ThreatLevel = fd.ThreatLevel
					r.ScenesId = fd.ScenesId
				}
			}

			logger.Infof("Sfl101 Detect data: %v", r)
			dataInfo.List = append(dataInfo.List, r)
			//记录探测信息
			RecordSfl101Info(r)

			d.Sfl101HitOverCheckEventReport(drone, devSn)
			dstDetectItems = append(dstDetectItems, r)
		}
	}
	// 处理打击后无人机消失时上报打击成功事件
	d.Sfl101HitOverUavDisappearProc(dstDetectItems, devSn)

	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	msg := &client.Sfl101DetectInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        devSn,
			EquipType: int32(common.DEV_SFL101),
			MsgType:   mavlink.Sfl101DetectMsgReport,
		},
		Data: dataInfo,
	}
	if err == nil {
		msg.Header.ParentType = int32(equipModel.ParentType)
		msg.Header.ParentSn = equipModel.ParentSn
		msg.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msgOut, err := proto.Marshal(msg)
	if err != nil {
		logger.Error("marshal msg err:", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIDSfl101Detect,
		Data:    msgOut,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	_ = mq.Sfl101MsgBroker.Publish(mq.Sfl101Topic, broker.NewMessage(out))
	d.Sfl101DetectAppearEvent(devSn, dataInfo)
	logger.Infof("Sfl101 Detect has reported, devSn: %v, Drone size: %v", devSn, msg.Data)
}

// Sfl101HitOverUavDisappearProc 打击无人机后，无人机消失时 上报打击成功事件。
func (d *Sfl101) Sfl101HitOverUavDisappearProc(uavs []*client.Sfl101DetectDroneInfo, devSn string) {
	var disappearHitNode []*common.Sfl101HitEventInfo

	Sfl101HitOverMapOnEvent.Range(func(key, value interface{}) bool {
		hitNode := value.(*common.Sfl101HitEventInfo)
		existNode := false

		for _, uav := range uavs {
			if uav == nil {
				continue
			}
			//
			if uav.ProductType == hitNode.ProductType &&
				uav.DroneName == hitNode.DroneName &&
				uav.SerialNum == hitNode.UavSn {
				existNode = true
			}
		}

		if !existNode {
			disappearHitNode = append(disappearHitNode, hitNode)
			logger.Infof("history hit node disappear, ProductType: %v, uavSn: %v, uavName: %v",
				hitNode.ProductType, hitNode.UavSn, hitNode.DroneName)
		}
		return true
	})

	for _, hitNode := range disappearHitNode {
		if hitNode == nil {
			continue
		}
		//
		eventId := utils.GetEventId(hitNode.SessionId)
		cacheKey := GetSfl101HitCacheKey(hitNode.UavSn, hitNode.DroneName, hitNode.ProductType)
		Sfl101HitOverMapOnEvent.Delete(cacheKey)
		//
		equipModel, err := GetEquipBySn(devSn)
		name := devSn
		if equipModel != nil && equipModel.Name != "" {
			name = equipModel.Name
		}

		dataInfo := &client.Sfl101HitStateInfo{
			Header: &client.EquipmentMessageBoxEntity{
				Name:      name,
				Sn:        devSn,
				EquipType: int32(common.DEV_SFL101),
				MsgType:   mavlink.Sfl101EventHitSucc,
			},
			Data: &client.Sfl101HitSocketInfo{
				SerialNum:      hitNode.UavSn,
				DroneName:      hitNode.DroneName,
				DroneLongitude: hitNode.DroneLongitude,
				DroneLatitude:  hitNode.DroneLatitude,
				DroneHeight:    hitNode.DroneHeight,
				DroneYawAngle:  hitNode.DroneYawAngle,
				EventId:        eventId,
			},
		}
		if err == nil {
			dataInfo.Header.ParentType = int32(equipModel.ParentType)
			dataInfo.Header.ParentSn = equipModel.ParentSn
			dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
		}
		logger.Infof("sfl101 hit succ report event: %v", dataInfo)

		msg, err := proto.Marshal(dataInfo)
		if err != nil {
			logger.Error("marshal dataInfo err:", err)
			return
		}

		report := &client.ClientReport{
			MsgType: common.ClientMsgSfl101HitEventData,
			Data:    msg,
		}
		out, err := proto.Marshal(report)
		if err != nil {
			logger.Error("marshal report err:", err)
			return
		}

		_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
		logger.Info("sfl101 hit succ event report:", report)
	}
}
func RecordSfl101Info(r *client.Sfl101DetectDroneInfo) {
	_, isExist := Sfl101DetectInfoMap.Get(r.SerialNum)
	tempTime := time.Now().UnixMilli()
	if !isExist { //不存在添加
		logger.Info("Sfl101 add drone event,", r.SerialNum)
		piltlong := strconv.FormatFloat(r.PilotLongitude, 'f', 4, 64)
		piltlat := strconv.FormatFloat(r.PilotLatitude, 'f', 4, 64)
		Sfl101DetectInfoMap.Set(r.SerialNum, r.DroneName, tempTime, 0, 0, r.UFreq,
			int64(r.DroneYawAngle), piltlong+","+piltlat, tempTime, r.UDirStatus)
		//写数据库
		err := NewSfl101DetectInfo().Insert(context.Background(), &client.Sfl101DetectInfoInsertReq{
			Sn:           r.SerialNum,
			Vendor:       r.DroneName,
			DetectTime:   tempTime,
			HitTime:      0,
			CounterTime:  0,
			Freq:         float32(r.UFreq),
			Direction:    int64(r.DroneHorizon),
			PilotLongLat: piltlong + " , " + piltlat,
			DroneHeight:  r.DroneHeight,
			UDirStatus:   r.UDirStatus,
			DevType:      int32(DevType(common.DEV_SFL101)),
		}, &client.Sfl101DetectInfoInsertRes{})
		if err != nil {
			logger.Error("Sfl101 Detect Info Insert err:", err)
		}
	}
}

func (d *Sfl101) UnmarshalPayloadSfl101Detect(data *mavlink.Sfl101Detect) error {
	deviceInfoLen := binary.Size(mavlink.Sfl101DetectInfo{})
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}

	start := mavlink.HeaderLen + deviceInfoLen
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializeDrone(d.Msg[start:end]); err != nil {
		return err
	}

	return nil
}
func (d *Sfl101) ReceiveSfl101RadarChartMsg() {
	hit := &mavlink.Sfl101RadarChart{}
	if err := d.UnmarshalPayloadSfl101RadarChart(hit); err != nil {
		logger.Errorf(err.Error())
		return
	}

	devSn := ByteToString(hit.Info.Sn[:])
	if devSn != "" {
		d.Sfl101RadarChartReport(devSn, hit)
	}
	logger.Info("--->End Receive Sfl101Radar Chart")
}
func (d *Sfl101) UnmarshalPayloadSfl101RadarChart(data *mavlink.Sfl101RadarChart) error {
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("sfl101 UnmarshalPayloadSfl101RadarChart write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("sfl101 UnmarshalPayloadSfl101RadarChart read data err: %v", err)
	}

	return nil
}
func (d *Sfl101) Sfl101RadarChartReport(devSn string, chartInfo *mavlink.Sfl101RadarChart) {

	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	dataInfo := &client.Sfl101RadarChartInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        devSn,
			EquipType: int32(common.DEV_SFL101),
			MsgType:   mavlink.Sfl101RadarChartMsg,
		},
		Data: &client.Sfl101RadarChartInfoData{
			Sn:           devSn,
			TimeStamp:    int64(chartInfo.Info.TimeStamp),
			StartAngle:   float64(chartInfo.Info.StartAngle) / SflChartTion,
			EndAngle:     float64(chartInfo.Info.EndAngle) / SflChartTion,
			AmpMean:      float64(chartInfo.Info.DxPower),
			GunDirection: float64(chartInfo.Info.DirectionAngle) / SflChartTion,
			Status:       uint32(chartInfo.Info.Status),
			TargetAngle:  float64(chartInfo.Info.TargetAngle) / SflChartTion,
		},
	}
	if err == nil {
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIdSfl101RadarChart,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}
	_ = mq.Sfl101MsgBroker.Publish(mq.Sfl101Topic, broker.NewMessage(out))
	logger.Infof("Sfl101 RadarChart has reported, devSn: %v report:%v", devSn, report)
}

func (d *Sfl101) ReceiveSfl101HitStatusMsg() {
	hit := &mavlink.Sfl101Hit{}
	if err := d.UnmarshalPayloadHitInfo(hit); err != nil {
		logger.Errorf(err.Error())
		return
	}

	devSn := ByteToString(hit.Info.SN[:])
	if devSn != "" {
		// report Hit
		d.updateStatusDetect(devSn)
		//if isEnable := d.updateStatus(devSn); isEnable == common.DeviceDisenable {
		//	logger.Infof("Sfl101 device %v disable", devSn)
		//	return
		//}
		d.HitInfoReport(devSn, hit)
	}
	logger.Info("--->End Receive Sfl101 HitStat")
}

func (d *Sfl101) UnmarshalPayloadHitInfo(data *mavlink.Sfl101Hit) error {
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("Sfl101 UnmarshalPayloadHitInfo write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("Sfl101 UnmarshalPayloadHitInfo read data err: %v", err)
	}

	return nil
}

func (d *Sfl101) HitInfoReport(devSn string, hitInfo *mavlink.Sfl101Hit) {
	//查白名单中的无人机，在Tracer侦测结果中添加无人机角色
	whiteList := &client.ListResAll{}
	err := NewWhiteList().ListAll(context.Background(), &client.ListReqAll{}, whiteList)
	if err != nil {
		logger.Error("Get whiteList err: ", err)
		return
	}
	//1-敌军 2-友军 3-未知 4-中立     批量导入为2友军
	var role int32
	for _, info := range whiteList.WhiteList {
		if info.Sn == ByteToString(hitInfo.Info.SerialNum[:]) {
			role = info.Role
		}
	}
	if role == ERRTYPE {
		role = ENEMY
	}

	//检查无效值
	hitInfo = Sfl101CheckInputNum(hitInfo)

	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	dataInfo := &client.Sfl101HitStateInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        devSn,
			EquipType: int32(common.DEV_SFL101),
			MsgType:   mavlink.Sfl101HitStatusMsgReport,
		},
		Data: &client.Sfl101HitSocketInfo{
			Sn:                 devSn,
			HitState:           int32(hitInfo.Info.HitState),
			ProductType:        int32(hitInfo.Info.ProductType),
			DroneName:          ByteToString(hitInfo.Info.DroneName[:]),
			SerialNum:          ByteToString(hitInfo.Info.SerialNum[:]),
			DroneLongitude:     float64(hitInfo.Info.DroneLongitude) / DroneTion,
			DroneLatitude:      float64(hitInfo.Info.DroneLatitude) / DroneTion,
			DroneHeight:        float64(hitInfo.Info.DroneHeight) / DroneHeightTion,
			DroneYawAngle:      float64(hitInfo.Info.DroneYawAngle) / DroneYawTion,
			DroneSpeed:         float64(hitInfo.Info.DroneSpeed) / DroneSpeedTion,
			DroneVerticalSpeed: float64(hitInfo.Info.DroneVerticalSpeed) / DroneVerticalSpeedTion,
			SpeedDirection:     int32(hitInfo.Info.SpeedDerection) / DroneSpeedTion,
			DroneSailLongitude: float64(hitInfo.Info.DroneSailLongitude) / DroneSailLongitudeTion,
			DroneSailLatitude:  float64(hitInfo.Info.DroneSailLatitude) / DroneSailLatitudeTion,
			PilotLongitude:     float64(hitInfo.Info.PilotLongitude) / DroneTion,
			PilotLatitude:      float64(hitInfo.Info.PilotLatitude) / DroneTion,
			DroneHorizon:       float64(hitInfo.Info.DroneHorizon) / DroneHorizonTion,
			DronePitch:         float64(hitInfo.Info.DronePitch) / DronePitch,
			UFreq:              float64(hitInfo.Info.UFreq) / DetectFreqTion,
			UDistance:          int32(hitInfo.Info.UDistance),
			UDangerLevels:      int32(hitInfo.Info.UDangerLevels),
			Role:               role,
		},
	}
	if err == nil {
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIDSfl101HitStatus,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}
	_ = mq.Sfl101MsgBroker.Publish(mq.Sfl101Topic, broker.NewMessage(out))
	logger.Infof("Sfl101 HitInfo has reported, devSn: %v report:%v", devSn, report)

	//统计打击时间、打击时长
	uavNode := RecordSlf101HitStatus(dataInfo.Data)
	if uavNode != nil {
		hitCacheKey := GetSfl101HitCacheKey(uavNode.UavSn, uavNode.DroneName, uavNode.ProductType)
		Sfl101HitOverMapOnEvent.Store(hitCacheKey, uavNode)
	}
}

func GetSfl101HitCacheKey(serialNum string, droneName string, productType int32) string {
	hitCacheKey := fmt.Sprintf("%d_%d_%s_%s", common.DEV_SFL101, productType, serialNum, droneName)
	logger.Infof("sfl101 hit cache key: %v", hitCacheKey)

	return hitCacheKey
}

func RecordSlf101HitStatus(report *client.Sfl101HitSocketInfo) *common.Sfl101HitEventInfo {
	var observeHitOverUav *common.Sfl101HitEventInfo = nil

	droneInfo, isExist := Sfl101DetectInfoMap.Get(report.SerialNum)
	tempTime := time.Now().UnixMilli()
	if isExist && (report.HitState == HITING || report.HitState == HITOVER) {
		if report.HitState == HITING && droneInfo.HitTime == 0 { //更新打击时间
			Sfl101DetectInfoMap.UpdateHitTime(report.SerialNum, tempTime)
			//更新数据库
			err := NewSfl101DetectInfo().UpdateHitTime(context.Background(), &client.Sfl101DetectInfoUpdateReq{Sn: report.SerialNum, HitTime: tempTime}, &client.Sfl101DetectInfoUpdateRes{})
			if err != nil {
				logger.Error("Update Sfl101 Detect Info err:", err)
			}
		}
		if report.HitState == HITOVER {
			//更新数据库
			counterDur := (tempTime - droneInfo.HitTime) / 1000
			err := NewSfl101DetectInfo().UpdateCountTime(context.Background(), &client.Sfl101DetectInfoUpdateReq{Sn: report.SerialNum, CounterTime: counterDur}, &client.Sfl101DetectInfoUpdateRes{})
			if err != nil {
				logger.Error("Update Sfl101 Detect Info hit over err:", err)
			}

			// 判断10s内无人机的状态信息
			nowTime := time.Now()
			droneInfo.CounterTime = counterDur
			observeHitOverUav = &common.Sfl101HitEventInfo{
				UavSn:            report.SerialNum,
				Sn:               report.Sn,
				HitOverTime:      nowTime,
				DetectReportTime: nowTime,
				ProductType:      report.ProductType,
				SessionId:        GetGlobalSessionId(),
				DroneName:        report.DroneName,
				DroneLongitude:   report.DroneLongitude,
				DroneLatitude:    report.DroneLatitude,
				DroneHeight:      report.DroneHeight,
				DroneYawAngle:    report.DroneYawAngle,
			}
			logger.Infof("sfl101 hit over, sfl101 sn: %v, uav serialNum: %v, productType: %v, droneName: %v",
				report.Sn, report.SerialNum, report.ProductType, report.DroneName)

			//清空map
			Sfl101DetectInfoMap.Clear()
		}
	}

	return observeHitOverUav
}

func (d *Sfl101) ReceiveSfl101GetVersion() {
	logger.Info("-->into Receive Sfl101 Get Version")

	res := &mavlink.Sfl101GetVersionResponse{}

	res.AppVersion = d.Msg[mavlink.HeaderLen : len(d.Msg)-2]
	manager, ok := d.WaitTaskMap[mavlink.Sfl101GetVersion]
	if ok {
		manager.CompletedTask(res, nil)
	}
	logger.Info("-->End Receive Sfl101 Version:", string(res.AppVersion))
	return
}

func (d *Sfl101) SendGetVersionInfo(sn string) (string, error) {
	logger.Info("-->into Send Get Version msg")
	req := &mavlink.Sfl101GetVersionRequest{}
	buff := req.Create()
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Sfl101 version info err: %v", err)
		return "", fmt.Errorf("request Sfl101 version info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.Sfl101GetVersion]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Sfl101GetVersion, true, 0)
		d.WaitTaskMap[mavlink.Sfl101GetVersion] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl101 version info err: %v", checkNetConnErr)
			return "", checkNetConnErr
		}
	}
	logger.Debug("SendGetVersionInfo result = ", result)
	res, ok := result.(*mavlink.Sfl101GetVersionResponse)
	if !ok {
		return "", errors.New("response err type")
	}
	logger.Debug("response Sfl101 version result:%+v", *res)
	if string(res.AppVersion) != "" {
		err = NewEquipList().Update(context.Background(), &client.EquipCrudReq{
			Sn:         sn,
			DevVersion: string(res.AppVersion),
		}, &client.EquipCrudRes{})
		if err != nil {
			logger.Error("Update EquipList err: ", err)
		}
	}
	return string(res.AppVersion), nil
}

// ReceiveGetTime 接收Sfl101获取时间消息
func (d *Sfl101) ReceiveGetTime() {
	logger.Info("-->into Send Time To Sfl101")
	res := &mavlink.Sfl101GetTimeResponse{}
	time1 := time.Now().UTC()
	resTime := time1.Format("20060102150405.000")
	logger.Info("resTime:", resTime)
	var byteArr [20]byte

	for k := range resTime {
		byteArr[k] = resTime[k]
	}

	rspBuf := res.CreateGetTimeMessage(byteArr)
	logger.Debugf("Send Time To Sfl101 Data:%v", rspBuf)

	n, err := d.Conn.Write(rspBuf)
	logger.Debugf("Send Time To Sfl101：%v,%#v", n, res)
	if err != nil {
		logger.Error("Send Time To Sfl101 err:", err)
		return
	}
	logger.Info("--->End Send Time To Sfl101")
	return
}
func (d *Sfl101) ReceiveSfl101GetGNNS() {
	logger.Info("-->into Receive Sfl101 Get GNNS")

	res := &mavlink.Sfl101GNSSGetResponse{}
	ret := d.UnmarshalPayloadSfl101GetGNSS(res)
	if ret != nil {
		logger.Debug("Receive Sfl101 Get GNNS ret = ", ret)
	}
	// res.AppVersion = d.Msg[mavlink.HeaderLen : len(d.Msg)-2]
	// res.Type = d.Msg[mavlink.HeaderLen : len(d.Msg)-2]
	manager, ok := d.WaitTaskMap[mavlink.Sfl101GetGNSS]
	if ok {
		manager.CompletedTask(res, nil)
	}
	logger.Info("-->End ReceiveSfl101GetGNNS Sfl101 :", res)
	return
}

func (d *Sfl101) ReceiveSfl101SetGNNS() {
	logger.Info("-->into ReceiveSfl101SetGNNS Sfl101 Set GNNS")

	res := &mavlink.Sfl101GNSSSetResponse{}
	ret := d.UnmarshalPayloadSfl101SetGNSS(res)
	if ret != nil {
		logger.Debug("Receive ReceiveSfl101SetGNNSret = ", ret)
	}
	manager, ok := d.WaitTaskMap[mavlink.Sfl101SetGNSS]
	if ok {
		manager.CompletedTask(res, nil)
	}
	logger.Info("-->End ReceiveSfl101SetGNNS Sfl101 :", res)
	return
}

func (d *Sfl101) ReceiveSfl101SetPith() {
	logger.Info("-->into Receive Sfl101 Set Pith")
	res := &mavlink.Sfl101SetHitInfoResponse{}
	d.GetPacket(res)
	logger.Debugf("Set Pith 接收到Sfl101 信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.Sfl101SetPith]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl101) ReceiveSfl101SetAngle() {
	logger.Info("-->into Receive Sfl101 Set Angle")
	res := &mavlink.Sfl101SetHitAngleResponse{}
	d.GetPacket(res)
	logger.Debugf("Set Angle 接收到Sfl101 信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.Sfl101SetAngle]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl101) SendSfl101HitAngleSet(request *client.Sfl101HitAngleRequest) (int, error) {
	logger.Info("-->into Send Hit Angle msg,req is %v", request)
	//1、设置打击俯仰角度
	req := &mavlink.Sfl101SetHitInfoRequest{}
	buff := req.Create(request)
	logger.Debug("-->Set Hit Info is :", buff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Sfl101 Hit Angle  err: %v", err)
		return Fail, fmt.Errorf("request Sfl101 Hit Info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.Sfl101SetPith]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Sfl101SetPith, true, 0)
		d.WaitTaskMap[mavlink.Sfl101SetPith] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl101 Hit Info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.Sfl101SetHitInfoResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl101 Hit Info result:%+v", *res)

	//2、设置有效角度范围
	reqAngle := &mavlink.Sfl101SetHitAngleRequest{}
	buffAngle := reqAngle.Create(request)
	logger.Debug("-->Set Hit Angle is :", buffAngle)
	if _, err := d.Conn.Write(buffAngle); err != nil {
		logger.Errorf("request Sfl101 Hit Angle err: %v", err)
		return Fail, fmt.Errorf("request Sfl101 Hit Angle err: %v", err)
	}
	managerAngle, ok := d.WaitTaskMap[mavlink.Sfl101SetAngle]
	if !ok {
		managerAngle = NewWaitTaskManager(mavlink.Sfl101SetAngle, true, 0)
		d.WaitTaskMap[mavlink.Sfl101SetAngle] = managerAngle
	}

	resultAngle, err := managerAngle.Wait()
	if err != nil {
		if checkNetConnErr := managerAngle.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl101  Hit Angle err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	resAngle, ok := resultAngle.(*mavlink.Sfl101SetHitAngleResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl101 Hit Angle result:%+v", *resAngle)

	//3.设置打击模式   反制模式：1、Normal 2、GNSS。打击模式拆分成单独的接口
	return int(resAngle.Status), nil
}

func (d *Sfl101) ReceiveSfl101StopHit() {
	logger.Info("-->into Receive Sfl101 Stop Hit")
	res := &mavlink.Sfl101StopHitResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveSfl101StopHit 接收到信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.Sfl101StopHit]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl101) SendSfl101StopHitReq() (int, error) {
	logger.Info("-->into Send Sfl101 stop hit msg")
	req := &mavlink.Sfl101StopHitRequest{}
	buff := req.Create()
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Sfl101 Stop Hit info err: %v", err)
		return Fail, fmt.Errorf("request Sfl101 Stop Hit info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.Sfl101StopHit]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Sfl101StopHit, true, 0)
		d.WaitTaskMap[mavlink.Sfl101StopHit] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl101 Stop Hit info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.Sfl101StopHitResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl101 Stop Hit result:%+v", *res)
	//清空map
	Sfl101DetectInfoMap.Clear()
	return int(res.Status), nil
}

// Sfl101GNSSSetReq
func (d *Sfl101) Sfl101GNSSSetReq(request *client.Sfl101SetGNSSRequest) (int, error) {
	logger.Info("-->into Sfl101GNSSSetReq stop hit msg")
	req := &mavlink.Sfl101GNSSSetRequest{}
	buff := req.Create(request)
	logger.Debug("buff = ", buff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Sfl101 SSfl101GNSSSetReqerr: %v", err)
		return Fail, fmt.Errorf("request Sfl101GNSSSetReq  info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.Sfl101SetGNSS]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Sfl101SetGNSS, true, 0)
		d.WaitTaskMap[mavlink.Sfl101SetGNSS] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl101GNSSSetReq info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.Sfl101GNSSSetResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl101 Sfl101GNSSSetReqresult:%+v", *res)
	//清空map
	Sfl101DetectInfoMap.Clear()
	return int(res.Status), nil
}

// Sfl101GNSSSetReq
func (d *Sfl101) Sfl101GNSSGetReq() (*mavlink.Sfl101GNSSGetResponse, error) {
	logger.Info("-->into Send Sfl101 Sfl101GNSSGetReq hit msg")
	req := &mavlink.Sfl101GNSSGetRequest{}
	buff := req.Create()
	logger.Debug("buff = ", buff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Sfl101GNSSGetReqHit info err: %v", err)
		return nil, fmt.Errorf("Sfl101GNSSGetReq info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.Sfl101GetGNSS]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Sfl101GetGNSS, true, 0)
		d.WaitTaskMap[mavlink.Sfl101GetGNSS] = manager
	}

	result, err := manager.Wait()
	logger.Debug("result = ", result)
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl101Sfl101GNSSGetReq err: %v", checkNetConnErr)
			return nil, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.Sfl101GNSSGetResponse)
	if !ok {
		return nil, errors.New("response err type")
	}
	logger.Debug("response Sfl101GNSSGetReq result:%+v", *res)
	//清空map
	Sfl101DetectInfoMap.Clear()
	return res, nil
}

func FindSfl101DetectInfo(request *client.Sfl101DetectInfoRequest) (*client.Sfl101DetectInfoResponse, error) {
	logger.Info("-->into Find Sfl101Detect Info,req is :", request)
	layout := "2006-01-02 15:04:05" // 输入时间的格式

	start, err := time.Parse(layout, request.StartTime)
	if err != nil {
		logger.Error("Parse  StartTime err:", err)
		return nil, err
	}
	end, err := time.Parse(layout, request.EndTime)
	if err != nil {
		logger.Error("Parse  EndTime err:", err)
		return nil, err
	}
	startTimeInt := start.UnixNano() / int64(time.Millisecond)
	endTimeInt := end.UnixNano() / int64(time.Millisecond)
	rspInfo := make([]*client.Event, 0)
	rsp := &client.Sfl101DetectInfoResponse{}
	detectList := &client.Sfl101DetectInfoListRes{}

	err = NewSfl101DetectInfo().List(context.Background(), &client.Sfl101DetectInfoListReq{
		StartTime: startTimeInt,
		StopTime:  endTimeInt,
	}, detectList)
	if err != nil {
		logger.Error("List Sfl101 err:", err)
		return nil, err
	}
	detectNum := 0
	hitNum := 0
	for _, list := range detectList.Sfl101List {
		hittime := ""
		if list.HitTime != 0 {
			hittime = time.Unix(0, list.HitTime*int64(time.Millisecond)).Format("2006-01-02 15:04:05")
		}
		devType := list.DevType
		if devType == 0 {
			devType = int32(DevType(common.DEV_SFL101))
		}
		rspInfo = append(rspInfo, &client.Event{
			Id:            list.Id,
			BeginTime:     time.Unix(0, list.DetectTime*int64(time.Millisecond)).Format("2006-01-02 15:04:05"),
			Freq:          float64(list.Freq),
			DroneName:     list.Vendor,
			Protocol:      "TCP",
			SerialNum:     list.Sn,
			DevType:       devType,
			DroneYawAngle: float64(list.Direction),
			HitTime:       hittime,
			HitDev:        devType,
			PilotLongLat:  list.PilotLongLat,
			DroneHeight:   list.DroneHeight,
			UDirStatus:    list.UDirStatus,
		})
		detectNum++
		if list.HitTime != 0 {
			hitNum++
		}
	}
	rsp.List = rspInfo
	rsp.DetectNum = int32(detectNum)
	rsp.HitNum = int32(hitNum)
	logger.Info("Sfl101 rsp is :", rsp)
	return rsp, nil
}

// FindSfl101DetectExportInfo 导出侦测信息
func FindSfl101DetectExportInfo(ctx context.Context, request *client.Sfl101DetectInfoExportRequest) (int, error) {
	logger.Info("-->into Find Sfl101Detect Export Info,req is :", request)

	file := excelize.NewFile()

	sheetName := file.GetSheetName(1) // 获取第一个表格的名称
	if sheetName != "sfl101_detect_list" {
		file.SetSheetName(sheetName, "sfl101_detect_list") // 将表格名称修改为 sfl101_detect_list
	}

	tranStrToInt64 := func(data string) int64 {
		ret, e := strconv.ParseInt(data, 10, 64)
		if e != nil {
			return 0
		}
		return ret
	}
	file.SetCellValue("sfl101_detect_list", "A1", "Sn")
	file.SetCellValue("sfl101_detect_list", "B1", "Vendor")
	file.SetCellValue("sfl101_detect_list", "C1", "DetectTime")
	file.SetCellValue("sfl101_detect_list", "D1", "HitTime")
	file.SetCellValue("sfl101_detect_list", "E1", "CounterTime")
	file.SetCellValue("sfl101_detect_list", "F1", "Freq")
	file.SetCellValue("sfl101_detect_list", "G1", "Direction")
	file.SetCellValue("sfl101_detect_list", "H1", "PilotLongLat")
	file.SetCellValue("sfl101_detect_list", "Ii", "DroneHeight")
	file.SetCellValue("sfl101_detect_list", "J1", "UDirStatus")
	listinfo := &client.Sfl101DetectInfoListRes{}
	sfl101DetectInfo := NewSfl101DetectInfo()
	err := sfl101DetectInfo.List(ctx, &client.Sfl101DetectInfoListReq{
		StartTime: tranStrToInt64(request.StartTime),
		StopTime:  tranStrToInt64(request.EndTime),
	}, listinfo)
	if err != nil {
		logger.Error("-->get sfl101_detect_list err:", err)
		return Fail, err
	}
	start := 0
	for i, list := range listinfo.Sfl101List {
		rowNum := i + 2
		file.SetCellValue("sfl101_detect_list", fmt.Sprintf("A%d", rowNum), list.Sn)
		file.SetCellValue("sfl101_detect_list", fmt.Sprintf("B%d", rowNum), list.Vendor)
		file.SetCellValue("sfl101_detect_list", fmt.Sprintf("C%d", rowNum), list.DetectTime)
		file.SetCellValue("sfl101_detect_list", fmt.Sprintf("D%d", rowNum), list.HitTime)
		file.SetCellValue("sfl101_detect_list", fmt.Sprintf("E%d", rowNum), list.CounterTime)
		file.SetCellValue("sfl101_detect_list", fmt.Sprintf("F%d", rowNum), list.Freq)
		file.SetCellValue("sfl101_detect_list", fmt.Sprintf("G%d", rowNum), list.Direction)
		file.SetCellValue("sfl101_detect_list", fmt.Sprintf("H%d", rowNum), list.PilotLongLat)
		file.SetCellValue("sfl101_detect_list", fmt.Sprintf("I%d", rowNum), list.DroneHeight)
		file.SetCellValue("sfl101_detect_list", fmt.Sprintf("J%d", rowNum), list.UDirStatus)
		start = i
	}
	if err = file.SaveAs(request.FilePath); err != nil {
		logger.Error("-->SaveAs sfl101_detect_list err:", err)
		return Fail, err
	}

	//其他类型设备数据导出
	var flightEvents []bean.FlightList
	err = db.GetDB().Model(&bean.FlightList{}).
		Order("begin_time desc").
		Find(&flightEvents).Error
	if err != nil {
		logger.Errorf("outPut query event list error:%v", err)
		return Fail, err
	}
	for i, list := range flightEvents {
		rowNum := i + 2 + start
		file.SetCellValue("sfl101_detect_list", fmt.Sprintf("A%d", rowNum), list.SerialNum)
		file.SetCellValue("sfl101_detect_list", fmt.Sprintf("B%d", rowNum), list.Vendor)
		file.SetCellValue("sfl101_detect_list", fmt.Sprintf("C%d", rowNum), list.BeginTime)
		file.SetCellValue("sfl101_detect_list", fmt.Sprintf("D%d", rowNum), 0)
		file.SetCellValue("sfl101_detect_list", fmt.Sprintf("E%d", rowNum), list.DurationTime)
		file.SetCellValue("sfl101_detect_list", fmt.Sprintf("F%d", rowNum), list.Freq)
		file.SetCellValue("sfl101_detect_list", fmt.Sprintf("G%d", rowNum), list.DroneYawAngle)
		file.SetCellValue("sfl101_detect_list", fmt.Sprintf("H%d", rowNum), "")
		file.SetCellValue("sfl101_detect_list", fmt.Sprintf("I%d", rowNum), "")
	}
	if err = file.SaveAs(request.FilePath); err != nil {
		logger.Error("-->SaveAs Other sfl101_detect_list err:", err)
		return Fail, err
	}

	logger.Info("-->End Export sfl101_detect_list List")
	return Success, nil
}

func FindSfl101DetectExportInfoV2(ctx context.Context, request *client.Sfl101DetectInfoExportRequest) (int, error) {
	logger.Info("-->into Find Sfl101Detect Export Info,req is :", request)

	// 创建CSV文件
	file, err := os.Create(request.FilePath)
	if err != nil {
		logger.Error("FindSfl101DetectExportInfoV2 os.Create err:", err)
		return Fail, err
	}
	defer file.Close()

	// 创建CSV writer
	writer := csv.NewWriter(file)

	//写入UTF-8 BOM头，避免使用excel软件打开.csv文件出现中文乱码
	//writer.Write([]string{"\xEF\xBB\xBF"})
	// 写入CSV文件的头部
	title := []string{"Sn", "Vendor", "DetectTime", "HitTime", "CounterTime", "Freq", "Direction", "PilotLongLat", "DroneHeight"}
	if err := writer.Write(title); err != nil {
		logger.Error("FindSfl101DetectExportInfoV2 writer.Write title err:", err)
		return Fail, err
	}
	// 写入CSV文件的数据行
	tranStrToInt64 := func(data string) int64 {
		ret, e := strconv.ParseInt(data, 10, 64)
		if e != nil {
			return 0
		}
		return ret
	}
	listinfo := &client.Sfl101DetectInfoListRes{}
	sfl101DetectInfo := NewSfl101DetectInfo()
	err = sfl101DetectInfo.List(ctx, &client.Sfl101DetectInfoListReq{
		StartTime: tranStrToInt64(request.StartTime),
		StopTime:  tranStrToInt64(request.EndTime),
	}, listinfo)
	if err != nil {
		logger.Error("-->get sfl101_detect_list err:", err)
		return Fail, err
	}

	records := make([][]string, 0)
	for _, list := range listinfo.Sfl101List {
		record := []string{
			list.Sn,
			list.Vendor,
			strconv.FormatInt(list.DetectTime, 10),
			strconv.FormatInt(list.HitTime, 10),
			strconv.FormatInt(list.CounterTime, 10),
			strconv.FormatFloat(float64(list.Freq), 'f', -1, 32),
			strconv.FormatInt(list.Direction, 10),
			list.PilotLongLat,
			strconv.FormatFloat(list.DroneHeight, 'f', -1, 32),
		}
		records = append(records, record)
	}

	if err := writer.WriteAll(records); err != nil {
		logger.Error("FindSfl101DetectExportInfoV2 writer.WriteAll err:", err)
		return Fail, err
	}
	logger.Info("-->End Export sfl101_detect_list List")
	return Success, nil
}

// FindSfl101DetectInfoByKey 侦测信息查询
func FindSfl101DetectInfoByKey(request *client.Sfl101DetectInfoRequest) (*client.Sfl101DetectInfoResponse, error) {
	logger.Info("-->into Detect Find Info,req is :", request)
	layout := "2006-01-02 15:04:05" // 输入时间的格式

	start, err := time.Parse(layout, request.StartTime)
	if err != nil {
		logger.Error("Parse  StartTime err:", err)
		return nil, err
	}
	end, err := time.Parse(layout, request.EndTime)
	if err != nil {
		logger.Error("Parse  EndTime err:", err)
		return nil, err
	}
	startTimeInt := start.UnixNano() / int64(time.Millisecond)
	endTimeInt := end.UnixNano() / int64(time.Millisecond)
	rspInfo := make([]*client.Event, 0)
	rsp := &client.Sfl101DetectInfoResponse{}
	detectList := &client.Sfl101DetectInfoListLikeRes{}
	err = NewSfl101DetectInfo().ListLike(context.Background(), &client.Sfl101DetectInfoListLikeReq{
		StartTime: startTimeInt,
		StopTime:  endTimeInt,
		FindKey:   request.FindKey,
	}, detectList)
	if err != nil {
		logger.Error("List Sfl101 err:", err)
		return nil, err
	}
	detectNum := 0
	hitNum := 0
	for _, list := range detectList.Sfl101List {
		hittime := ""
		if list.HitTime != 0 {
			hittime = time.Unix(0, list.HitTime*int64(time.Millisecond)).Format("2006-01-02 15:04:05")
		}
		devType := list.DevType
		if devType == 0 {
			devType = int32(DevType(common.DEV_SFL101))
		}
		rspInfo = append(rspInfo, &client.Event{
			Id:            list.Id,
			BeginTime:     time.Unix(0, list.DetectTime*int64(time.Millisecond)).Format("2006-01-02 15:04:05"),
			Freq:          float64(list.Freq),
			DroneName:     list.Vendor,
			Protocol:      "TCP",
			SerialNum:     list.Sn,
			DevType:       int32(devType),
			DroneYawAngle: float64(list.Direction),
			HitTime:       hittime,
			HitDev:        int32(devType),
			DroneHeight:   list.DroneHeight,
			PilotLongLat:  list.PilotLongLat,
			UDirStatus:    list.UDirStatus,
		})
		detectNum++
		if list.HitTime != 0 {
			hitNum++
		}
	}
	rsp.List = rspInfo
	rsp.DetectNum = int32(detectNum)
	rsp.HitNum = int32(hitNum)
	logger.Info("Sfl101 rsp is :", rsp)
	return rsp, nil
}

func (d *Sfl101) ReceiveSfl101SetHitMode() {
	logger.Info("-->into Receive Set Hit Mode")
	res := &mavlink.Sfl101SetHitModeResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveSfl101Set Hit Mode 接收到Sfl101信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.Sfl101SetHitMode]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl101) SendSfl101OnOffSet(request *client.Sfl101OnOffRequest) (int, error) {
	logger.Info("-->into Send On Off  msg")
	req := &mavlink.Sfl101SetOnOffRequest{}
	buff := req.Create(request)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Sfl101 On Off info err: %v", err)
		return Fail, fmt.Errorf("request Sfl101 On Off info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.Sfl101SetOnOff]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Sfl101SetOnOff, true, 0)
		d.WaitTaskMap[mavlink.Sfl101SetOnOff] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl101 On Off info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.Sfl101SetOnOffResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl101 On Off result:%+v", *res)
	return int(res.Status), nil
}
func (d *Sfl101) ReceiveSfl101SetOnOff() {
	logger.Info("-->into Receive Sfl101SetOnOff")
	res := &mavlink.Sfl101SetOnOffResponse{}
	d.GetPacket(res)
	logger.Debugf("Sfl101 Set OnOff  接收到Sfl101信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.Sfl101SetOnOff]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl101) SendSfl101Reset() (int, error) {
	logger.Info("-->into Send Reset  msg")
	req := &mavlink.Sfl101ResetRequest{}
	buff := req.Create()
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Sfl101 Reset info err: %v", err)
		return Fail, fmt.Errorf("request Sfl101 Reset info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.Sfl101Reset]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Sfl101Reset, true, 0)
		d.WaitTaskMap[mavlink.Sfl101Reset] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl101 Reset info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.Sfl101ResetResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl101 Reset result:%+v", *res)
	return int(res.Status), nil
}
func (d *Sfl101) ReceiveSfl101Reset() {
	logger.Info("-->into Receive Reset")
	res := &mavlink.Sfl101ResetResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveSfl101Get Reset 接收到Sfl101信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.Sfl101Reset]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}
func (d *Sfl101) SendSfl101HitUav(request *client.Sfl101SendHitUavRequest) (int, error) {
	logger.Info("-->into Send Hit Uav msg,req is:", request)
	req := &mavlink.Sfl101SendHitUavRequest{}

	hitCmdDroneName := common.DeConstructDroneName(request.GetDroneName(), request.GetDroneSn())
	logger.Infof("drone Name: %v before hit cmd, drone name: %v after hit cmd", request.GetDroneName(), hitCmdDroneName)
	request.DroneName = hitCmdDroneName

	buff := req.Create(request)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Sfl101 Send Hit Uav info err: %v", err)
		return Fail, fmt.Errorf("request Sfl101 Send Hit Uav info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.Sfl101SendHitUav]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Sfl101SendHitUav, true, 0)
		d.WaitTaskMap[mavlink.Sfl101SendHitUav] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl101 Send Hit Uav info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.Sfl101SendHitUavResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl101 Send Hit Uav result:%+v", *res)
	return int(res.Status), nil
}

func (d *Sfl101) ReceiveSfl101GetHitUav() {
	logger.Info("-->into Receive Get Hit Uav")
	res := &mavlink.Sfl101SendHitUavResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveSfl101GetHitUav  接收到Sfl101信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.Sfl101SendHitUav]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}
func (d *Sfl101) SendSfl101GetStatus() (*client.Sfl101GetStatusResponse, error) {
	logger.Info("-->into Send Reset  msg")
	rsp := &client.Sfl101GetStatusResponse{}

	//1.获取角度、打击时长信息
	req := &mavlink.Sfl101GetPitchRequest{}
	buff := req.Create()
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Sfl101 GetPitch info err: %v", err)
		return rsp, fmt.Errorf("request Sfl101 GetPitch info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.Sfl101GetHitPith]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Sfl101GetHitPith, true, 0)
		d.WaitTaskMap[mavlink.Sfl101GetHitPith] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl101 GetPitch info err: %v", checkNetConnErr)
			return rsp, checkNetConnErr
		}
	}
	resPitch, ok := result.(*mavlink.Sfl101GetPitchResponse)
	if !ok {
		return rsp, errors.New("response err type")
	}
	logger.Debug("response Sfl101 GetPitch result:%+v", *resPitch)

	for i := 0; i < int(resPitch.HitCnt); i++ {
		rsp.HitTime = int32(resPitch.HitDescription[0].HitTime)
		rsp.HitPitch1 = int32(resPitch.HitDescription[0].HitPitch)
		rsp.HitPitch2 = int32(resPitch.HitDescription[i].HitPitch)
	}

	//2.获取打击范围信息
	reqAngle := &mavlink.Sfl101GetAngleRequest{}
	buffAngle := reqAngle.Create()
	if _, err := d.Conn.Write(buffAngle); err != nil {
		logger.Errorf("request Sfl101 GetAngle info err: %v", err)
		return rsp, fmt.Errorf("request Sfl101 GetAngle info err: %v", err)
	}
	managerAngle, ok := d.WaitTaskMap[mavlink.Sfl101GetHitAngle]
	if !ok {
		managerAngle = NewWaitTaskManager(mavlink.Sfl101GetHitAngle, true, 0)
		d.WaitTaskMap[mavlink.Sfl101GetHitAngle] = managerAngle
	}

	resultAngle, err := managerAngle.Wait()
	if err != nil {
		if checkNetConnErr := managerAngle.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl101 GetAngle info err: %v", checkNetConnErr)
			return rsp, checkNetConnErr
		}
	}
	resAngle, ok := resultAngle.(*mavlink.Sfl101GetAngleResponse)
	if !ok {
		return rsp, errors.New("response err type")
	}
	logger.Debug("response Sfl101 GetAngle result:%+v", *resAngle)
	rsp.HitAngleBegin = int32(resAngle.HitAngleBegin)
	rsp.HitAngleEnd = int32(resAngle.HitAngleEnd)

	//3.获取工作模式
	reqMode := &mavlink.Sfl101GetHitModeRequest{}
	buffMode := reqMode.Create()
	if _, err := d.Conn.Write(buffMode); err != nil {
		logger.Errorf("request Sfl101 GetMode info err: %v", err)
		return rsp, fmt.Errorf("request Sfl101 GetMode info err: %v", err)
	}
	managerreqMode, ok := d.WaitTaskMap[mavlink.Sfl101GetHitMode]
	if !ok {
		managerreqMode = NewWaitTaskManager(mavlink.Sfl101GetHitMode, true, 0)
		d.WaitTaskMap[mavlink.Sfl101GetHitMode] = managerreqMode
	}

	resultMode, err := managerreqMode.Wait()
	if err != nil {
		if checkNetConnErr := managerreqMode.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl101 GetMode info err: %v", checkNetConnErr)
			return rsp, checkNetConnErr
		}
	}
	resMode, ok := resultMode.(*mavlink.Sfl101GetHitModeResponse)
	if !ok {
		return rsp, errors.New("response err type")
	}
	logger.Debug("response Sfl101 GetMode result:%+v", *resMode)
	rsp.HitMode = int32(resMode.ModeStatus)

	return rsp, nil
}

func (d *Sfl101) SendSfl101SetHitMode(hitMode int32) (int, error) {
	//设置打击模式  0 不自动打击    1 自动打击
	req := &mavlink.Sfl101SetAutoModeRequest{}
	buff := req.Create(hitMode)
	logger.Debug("-->Set Hit Auto is :", buff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Sfl101 Hit Auto err: %v", err)
		return Fail, fmt.Errorf("request Sfl101 Hit Auto err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.Sfl101SetAutoHitMode]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Sfl101SetAutoHitMode, true, 0)
		d.WaitTaskMap[mavlink.Sfl101SetAutoHitMode] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl101  Hit Mode err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.Sfl101SetAutoModeResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl101 Hit Auto result:%+v", *res)

	return int(res.Status), nil
}
func (d *Sfl101) ReceiveSfl101SetAutoHitMode() {
	logger.Info("-->into ReceiveSfl101 Set Auto Hit Mode")
	res := &mavlink.Sfl101SetAutoModeResponse{}
	d.GetPacket(res)
	logger.Debugf("Set Auto Hit Mode  接收到Sfl101信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.Sfl101SetAutoHitMode]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}
func (d *Sfl101) SendSfl101GetHitMode() (int, error) {
	//获取打击模式  0 不自动打击    1 自动打击
	req := &mavlink.Sfl101GetAutoModeRequest{}
	buff := req.Create()
	logger.Debug("-->Get Hit Auto is :", buff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Get Sfl101 Hit Auto err: %v", err)
		return Fail, fmt.Errorf("request Get Sfl101 Hit Auto err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.Sfl101GetAutoHitMode]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Sfl101GetAutoHitMode, true, 0)
		d.WaitTaskMap[mavlink.Sfl101GetAutoHitMode] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl101 Get Hit Mode err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.Sfl101GetAutoModeResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl101 Get Hit Auto result:%+v", *res)

	return int(res.AutoStatus), nil
}
func (d *Sfl101) ReceiveSfl101GetAutoHitMode() {
	logger.Info("-->into ReceiveSfl101 Get Auto Hit Mode")
	res := &mavlink.Sfl101GetAutoModeResponse{}
	d.GetPacket(res)
	logger.Debugf("Get Auto Hit Mode  接收到Sfl101信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.Sfl101GetAutoHitMode]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl101) SendSfl101GetPower() (int, int, error) {
	logger.Info("-->into Send Get Power  msg")
	//获取开关机状态
	req := &mavlink.Sfl101GetPowerRequest{}
	buff := req.Create()
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Sfl101 Get Power info err: %v", err)
		return Fail, Fail, fmt.Errorf("request Sfl101 Get Power info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.Sfl101GetOnOff]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Sfl101GetOnOff, true, 0)
		d.WaitTaskMap[mavlink.Sfl101GetOnOff] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl101 Get Power info err: %v", checkNetConnErr)
			return Fail, Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.Sfl101GetPowerResponse)
	if !ok {
		return Fail, Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl101 Get Power result:%+v", *res)

	return int(res.PowerStatus), int(res.Status), nil
}
func (d *Sfl101) ReceiveSfl101GetOnOff() {
	logger.Info("-->into Receive Sfl101GetOnOff")
	res := &mavlink.Sfl101GetPowerResponse{}
	d.GetPacket(res)
	logger.Debugf("Sfl101GetOnOff Get 接收到Sfl101信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.Sfl101GetOnOff]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl101) SendSfl101TurnHit(startStop int32) (int, error) {
	logger.Info("-->into Send Turn Hit  msg")
	//获取开关机状态
	req := &mavlink.Sfl101TurnHitRequest{}
	buff := req.Create(uint8(startStop))
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Sfl101 Send Turn Hit info err: %v", err)
		return Fail, fmt.Errorf("request Sfl101 Send Turn Hit info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.Sfl101HitTurn]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Sfl101HitTurn, true, 0)
		d.WaitTaskMap[mavlink.Sfl101HitTurn] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl101 Turn Hit info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.Sfl101TurnHitResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl101 Turn Hit result:%+v", *res)

	return int(res.Status), nil
}
func (d *Sfl101) ReceiveSfl101TurnHit() {
	logger.Info("-->into Receive Sfl101TurnHit")
	res := &mavlink.Sfl101TurnHitResponse{}
	d.GetPacket(res)
	logger.Debugf("Sfl101TurnHit Get 接收到Sfl101信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.Sfl101HitTurn]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl101) SendSfl101HorizontalTurn(request *client.Sfl101HorizontalTurnRequest) (int, error) {
	logger.Info("-->into Send Horizontal Turn  msg")
	//获取开关机状态
	req := &mavlink.Sfl101HorizontalTurnRequest{}
	buff := req.Create(request)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Sfl101 Send Horizontal Turn info err: %v", err)
		return Fail, fmt.Errorf("request Sfl101 Send Horizontal Turn info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.Sfl101HorizontalTurn]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Sfl101HorizontalTurn, true, 0)
		d.WaitTaskMap[mavlink.Sfl101HorizontalTurn] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl101 Horizontal Turn info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.Sfl101HorizontalTurnResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl101 Horizontal Turn result:%+v", *res)

	return int(res.Status), nil
}
func (d *Sfl101) ReceiveSfl101HorizontalTurn() {
	logger.Info("-->into Receive Sfl101 Horizontal Turn")
	res := &mavlink.Sfl101HorizontalTurnResponse{}
	d.GetPacket(res)
	logger.Debugf("Sfl101 Horizontal Turn Get 接收到Sfl101信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.Sfl101HorizontalTurn]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl101) SendSfl101VerticalTurn(request *client.Sfl101VerticalTurnRequest) (int, error) {
	logger.Info("-->into Send Vertical Turn  msg")
	//获取开关机状态
	req := &mavlink.Sfl101VerticalTurnRequest{}
	buff := req.Create(request)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Sfl101 Send Vertical Turn info err: %v", err)
		return Fail, fmt.Errorf("request Sfl101 Send Vertical Turn info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.Sfl101VerticalTurn]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Sfl101VerticalTurn, true, 0)
		d.WaitTaskMap[mavlink.Sfl101VerticalTurn] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl101 Vertical Turn info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.Sfl101VerticalTurnResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl101 Vertical Turn result:%+v", *res)

	return int(res.Status), nil
}
func (d *Sfl101) ReceiveSfl101VerticalTurn() {
	logger.Info("-->into Receive Sfl101 Vertical Turn")
	res := &mavlink.Sfl101VerticalTurnResponse{}
	d.GetPacket(res)
	logger.Debugf("Sfl101 Vertical Turn Get 接收到Sfl101信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.Sfl101VerticalTurn]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl101) SendSfl101CrashStop() (int, error) {
	logger.Info("-->into Send Sfl101 Crash Stop  msg")
	//获取开关机状态
	req := &mavlink.Sfl101CrashStopRequest{}
	buff := req.Create()
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Send Sfl101 Crash Stop info err: %v", err)
		return Fail, fmt.Errorf("request Send Sfl101 Crash Stop info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.Sfl101CrashStop]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Sfl101CrashStop, true, 0)
		d.WaitTaskMap[mavlink.Sfl101CrashStop] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl101 Crash Stop info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.Sfl101CrashStopResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl101 Crash Stop result:%+v", *res)

	return int(res.Status), nil
}
func (d *Sfl101) ReceiveSfl101CrashStop() {
	logger.Info("-->into Receive Sfl101Crash Stop")
	res := &mavlink.Sfl101CrashStopResponse{}
	d.GetPacket(res)
	logger.Debugf("Sfl101 Crash Stop Get 接收到Sfl101信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.Sfl101CrashStop]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl101) Sfl101SetPreciseHit(request *client.Sfl101SetPreciseHitRequest) (int, error) {
	logger.Info("-->into Send Sfl101 SetPreciseHit  msg")
	//获取开关机状态
	req := &mavlink.Sfl101SetPreciseHitRequest{}
	buff := req.Create(request)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Send Sfl101 Set PreciseHit info err: %v", err)
		return Fail, fmt.Errorf("request Send Sfl101 Set PreciseHit info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.Sfl101SetPreciseHit]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Sfl101SetPreciseHit, true, 0)
		d.WaitTaskMap[mavlink.Sfl101SetPreciseHit] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl101 SetPreciseHit info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.Sfl101SetPreciseHitResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl101 SetPreciseHit result:%+v", *res)

	return int(res.Status), nil
}
func (d *Sfl101) ReceiveSetPreciseHit() {
	logger.Info("-->into Receive Set PreciseHit")
	res := &mavlink.Sfl101SetPreciseHitResponse{}
	d.GetPacket(res)
	logger.Debugf("Sfl101 SetPreciseHit Get 接收到Sfl101信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.Sfl101SetPreciseHit]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}
func (d *Sfl101) Sfl101GetPreciseHit() (int, error) {
	logger.Info("-->into Send Sfl101 GetPreciseHit  msg")
	//获取开关机状态
	req := &mavlink.Sfl101GetPreciseHitRequest{}
	buff := req.Create()
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Send Sfl101 Get PreciseHit info err: %v", err)
		return Fail, fmt.Errorf("request Send Sfl101 Get PreciseHit info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.Sfl101GetPreciseHit]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Sfl101GetPreciseHit, true, 0)
		d.WaitTaskMap[mavlink.Sfl101GetPreciseHit] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl101 GetPreciseHit info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.Sfl101GetPreciseHitResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl101 GetPreciseHit result:%+v", *res)

	return int(res.Enable), nil
}
func (d *Sfl101) ReceiveGetPreciseHit() {
	logger.Info("-->into Receive Get PreciseHit")
	res := &mavlink.Sfl101GetPreciseHitResponse{}
	d.GetPacket(res)
	logger.Debugf("Sfl101 GetPreciseHit Get 接收到Sfl101信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.Sfl101GetPreciseHit]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl101) Sfl101SetInvalidFreq(request *client.Sfl101SetInvalidFreqRequest) (int, error) {
	logger.Info("---> Send Sfl101 Set Invalid")
	defer func() {
		if r := recover(); r != nil {
			logger.Error("Sfl101 Set Invalid occurred:", r)
			return
		}
	}()
	req := mavlink.Sfl101SetInvalidRequestAll{}
	invalidlist := make([]mavlink.Sfl101SetInvalidInfo, 0)
	for _, s := range request.FreqList {
		invalidlist = append(invalidlist, mavlink.Sfl101SetInvalidInfo{
			StartFreq: uint16(s.StartFreq),
			EndFreq:   uint16(s.EndFreq),
		})
	}
	reqInfo := &mavlink.Sfl101SetInvalidRequest{
		SetInvalidNum:  uint8(len(invalidlist)),
		SetInvalidList: invalidlist,
	}

	buff := req.Create(reqInfo)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.Sfl101SetInvalidFreqList]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Sfl101SetInvalidFreqList, true, time.Millisecond*300)
		d.WaitTaskMap[mavlink.Sfl101SetInvalidFreqList] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Send Sfl101 Set Invalid is :[%v]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send Sfl101 Set Invalid  err:[%v].Buff is [%v]", err, buff)
		return Fail, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send Sfl101 Set Invalid  err %s", err.Error())
		return Fail, err
	}
	res := result.(*mavlink.Sfl101SetInvalidResponse)

	logger.Info("-->End Set Sfl101 Set Invalid")
	return int(res.Status), nil
}
func (d *Sfl101) ReceiveSetInvalid() {
	logger.Info("-->into Receive Set Invalid")
	res := &mavlink.Sfl101SetInvalidResponse{}
	d.GetPacket(res)
	logger.Debugf("Sfl101 Set Invalid 接收到Sfl101信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.Sfl101SetInvalidFreqList]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}
func (d *Sfl101) Sfl101GetInvalidFreq() ([]*client.FreqList, error) {
	logger.Info("---> Send Sfl101GetInvalidFreq")
	var rsp []*client.FreqList
	req := &mavlink.Sfl101GetInvalidListRequest{}
	buff := req.Create(0)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.Sfl101GetInvalidFreqList]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Sfl101GetInvalidFreqList, true, 0)
		d.WaitTaskMap[mavlink.Sfl101GetInvalidFreqList] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Send Sfl101GetInvalidFreqList is :[% x]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send Sfl101GetInvalidFreqList err:[%v].Buff is [% x]", err, buff)
		return rsp, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send Sfl101GetInvalidFreqList err %s", err.Error())
		return rsp, err
	}
	res := result.(*mavlink.Sfl101GetInvalidListResponse)
	for _, des := range res.Description {
		rsp = append(rsp, &client.FreqList{
			StartFreq: int32(des.StartFreqList),
			EndFreq:   int32(des.EndFreqList),
		})
	}
	logger.Info("-->End Sfl101GetInvalidFreqList")
	return rsp, nil
}

// ReceiveGetInvalidList 接收 freq无效列表
func (d *Sfl101) ReceiveGetInvalidList() {
	res := &mavlink.Sfl101GetInvalidListResponse{}
	if err := d.UnmarshalFreqInvalidList(res); err != nil {
		logger.Errorf("parse freq Get Invalid  list response fail, e: %v", err)
		return
	}
	logger.Debugf("receive Send Sfl101GetInvalidListResponse：%+v", *res)
	manager, ok := d.WaitTaskMap[mavlink.Sfl101GetInvalidFreqList]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}
func (d *Sfl101) UnmarshalFreqInvalidList(data *mavlink.Sfl101GetInvalidListResponse) error {
	deviceInfoLen := binary.Size(mavlink.Sfl101FreqInfo{})
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}

	start := mavlink.HeaderLen + deviceInfoLen
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializeDrone(d.Msg[start:end]); err != nil {
		return err
	}
	return nil
}
func (d *Sfl101) SendSfl101SetNoise(request *client.Sfl101SetNoiseRequest) (int, error) {
	logger.Info("-->into Send Send Sfl101 Set Noise  msg")
	//获取开关机状态
	req := &mavlink.Sfl101SetNoiseRequest{}
	buff := req.Create(uint32(request.Mode), uint32(request.Freq))
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Send Sfl101 Set Noise info err: %v", err)
		return Fail, fmt.Errorf("request Send Sfl101 Set Noise info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.Sfl101SetNoise]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Sfl101SetNoise, true, 0)
		d.WaitTaskMap[mavlink.Sfl101SetNoise] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("requestSend Sfl101 Set Noise info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.Sfl101SetNoiseResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Send Sfl101 Set Noise result:%+v", *res)

	return int(res.Status), nil
}
func (d *Sfl101) ReceiveSfl101SetNoise() {
	logger.Info("-->into Receive Sfl101 SetNoise")
	res := &mavlink.Sfl101SetNoiseResponse{}
	d.GetPacket(res)
	logger.Debugf("Sfl101 Set Noise Get ：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.Sfl101SetNoise]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}
func (d *Sfl101) SendSfl101SetHitRadius(request *client.Sfl101SetAutoHitRadiusRequest) (int, error) {
	logger.Info("-->into Send Sfl101 SetAutoHitRadius  msg,req:", request)
	//获取开关机状态
	req := &mavlink.Sfl101SetAutoHitRadiusRequest{}
	buff := req.Create(uint32(request.Radius))
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Send Sfl101 SetAutoHitRadius info err: %v", err)
		return Fail, fmt.Errorf("request Send Sfl101 SetAutoHitRadius info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.Sfl101SetAutoRadius]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Sfl101SetAutoRadius, true, 0)
		d.WaitTaskMap[mavlink.Sfl101SetAutoRadius] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("requestSend Sfl101 SetAutoHitRadius info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.Sfl101SetAutoHitRadiusResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Send Sfl101 SetAutoHitRadius result:%+v", *res)

	return int(res.Status), nil
}
func (d *Sfl101) ReceiveSfl101SetAutoRadius() {
	logger.Info("-->into Receive Sfl101 SetAutoRadius")
	res := &mavlink.Sfl101SetAutoHitRadiusResponse{}
	d.GetPacket(res)
	logger.Debugf("Sfl101 SetAutoRadius Get ：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.Sfl101SetAutoRadius]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl101) SendSfl101GetHitRadius(request *client.Sfl101GetAutoHitRadiusRequest) (int, error) {
	logger.Info("-->into Send Sfl101 GetAutoHitRadius  msg,req:", request)
	//获取开关机状态
	req := &mavlink.Sfl101GetAutoHitRadiusRequest{}
	buff := req.Create()
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Send Sfl101 GetAutoHitRadius info err: %v", err)
		return Fail, fmt.Errorf("request Send Sfl101 GetAutoHitRadius info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.Sfl101GetAutoRadius]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Sfl101GetAutoRadius, true, 0)
		d.WaitTaskMap[mavlink.Sfl101GetAutoRadius] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("requestSend Sfl101 GetAutoHitRadius info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.Sfl101GetAutoHitRadiusResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Send Sfl101 GetAutoHitRadius result:%+v", *res)

	return int(res.Radius), nil
}
func (d *Sfl101) ReceiveSfl101GetAutoRadius() {
	logger.Info("-->into Receive Sfl101 GetAutoRadius")
	res := &mavlink.Sfl101GetAutoHitRadiusResponse{}
	d.GetPacket(res)
	logger.Debugf("Sfl101 GetAutoRadius Get ：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.Sfl101GetAutoRadius]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl101) Sfl101SetSwitchParameter(request *client.Sfl101SetSwitchParameterRequest) (int, error) {
	logger.Info("-->into Send Sfl101SetSwitchParameter  msg,req:", request)
	//获取开关机状态
	req := &mavlink.Sfl101SetSwitchParameterRequest{}
	buff := req.Create(request)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Send Sfl101SetSwitchParameter info err: %v", err)
		return Fail, fmt.Errorf("request Send Sfl101SetSwitchParameter info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.Sfl101SetSwitchParam]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Sfl101SetSwitchParam, true, 0)
		d.WaitTaskMap[mavlink.Sfl101SetSwitchParam] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("requestSend Sfl101SetSwitchParameter info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.Sfl101SetSwitchParameterResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Send Sfl101SetSwitchParameter result:%+v", *res)

	return int(res.Status), nil
}
func (d *Sfl101) ReceiveSfl101SetSwitchParameter() {
	logger.Info("-->into Receive Sfl101 SetSwitchParameter")
	res := &mavlink.Sfl101SetSwitchParameterResponse{}
	d.GetPacket(res)
	logger.Debugf("Sfl101 SetSwitchParameter Get ：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.Sfl101SetSwitchParam]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl101) Sfl101GetSwitchParameter(request *client.Sfl101GetSwitchParameterRequest) ([]*client.Sfl101SwitchParameter, error) {
	logger.Info("-->into Send Sfl101SetSwitchParameter  msg,req:", request)
	//获取开关机状态
	req := &mavlink.Sfl101GetSwitchParameterRequest{}
	buff := req.Create(request)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Send Sfl101GetSwitchParameter info err: %v", err)
		return nil, fmt.Errorf("request Send Sfl101GetSwitchParameter info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.Sfl101GetSwitchParam]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Sfl101GetSwitchParam, true, 0)
		d.WaitTaskMap[mavlink.Sfl101GetSwitchParam] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("requestSend Sfl101GetSwitchParameter info err: %v", checkNetConnErr)
			return nil, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.Sfl101GetSwitchParameterResponse)
	if !ok {
		return nil, errors.New("response err type")
	}
	logger.Debug("response Send Sfl101GetSwitchParameter result:%+v", *res)
	response := make([]*client.Sfl101SwitchParameter, 0)
	response = append(response, &client.Sfl101SwitchParameter{Type: int32(res.Type1), Enable: int32(res.Enable1)})
	response = append(response, &client.Sfl101SwitchParameter{Type: int32(res.Type2), Enable: int32(res.Enable2)})
	response = append(response, &client.Sfl101SwitchParameter{Type: int32(res.Type3), Enable: int32(res.Enable3)})
	response = append(response, &client.Sfl101SwitchParameter{Type: int32(res.Type4), Enable: int32(res.Enable4)})
	return response, nil
}
func (d *Sfl101) ReceiveSfl101GetSwitchParameter() {
	logger.Info("-->into Receive Sfl101 GetSwitchParameter")
	res := &mavlink.Sfl101GetSwitchParameterResponse{}
	d.GetPacket(res)
	logger.Debugf("Sfl101 GetSwitchParameter Get ：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.Sfl101GetSwitchParam]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}
func (d *Sfl101) SendSfl101SetFreqCmd(sn string, op int32, fileName string) (int32, error) {
	logger.Info("-->into Send Sfl101 Set Freq Cmd  msg,req:", sn, op, fileName)
	var (
		status int32 = 0
		err    error
	)

	if op == CollectDataTracerOpen {
		if len(fileName) == 0 {
			return 0, errors.New("file name is empty on open")
		}
		status, err = d.openCollect(sn, fileName)

	} else if op == CollectDataTracerEnd {
		status, err = d.closeCollect(sn)

	} else {
		return 0, errors.New("not support op")
	}
	return status, err
}

// openCollect 发送打开数据收集
func (d *Sfl101) openCollect(sn string, fileName string) (int32, error) {
	sessionCollMng.UnRegister(sn)

	s := &ClientCollectSession{}
	sessionCollMng.Register(sn, fileName, d.collectTaskTimeoutCB, s.InitSession, CollectDataToDevEnd)

	logger.Info("---> Send openCollect: ", CollectDataToDevBegin)
	req := &mavlink.Sfl101SetFreqCmdRequest{}
	buff := req.Create(CollectDataToDevBegin)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.Sfl101GetFreqCmd]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Sfl101GetFreqCmd, true, 0)
		d.WaitTaskMap[mavlink.Sfl101GetFreqCmd] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Send Sfl101 setOpenCollect is :[% x]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send Sfl101 setOpenCollect err:[%v].Buff is [%v]", err, buff)
		sessionCollMng.UnRegister(sn)
		return 0, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send Sfl101 setOpenCollect err %s", err.Error())
		sessionCollMng.UnRegister(sn)
		return 0, err
	}

	// 只有等设备有响应才进行后续的动作。
	sessionCollMng.StartSession(sn)

	res := result.(*mavlink.Sfl101SetFreqCmdResponse)

	logger.Info("-->End openCollect")
	return int32(res.Status), nil
}

// collectTaskTimeoutCB 检测定时器检测到已经开始的数据收集任务超时
func (d *Sfl101) collectTaskTimeoutCB(sn string) {
	fileSz, receivedSz, fileName := sessionCollMng.GetFileParameters(sn)
	logger.Infof("filesz: %v, receivesz: %v, sn: %v", fileSz, receivedSz, sn)
	logger.Infof("collect task time out callback proc, sn: %v, send stop to dev", sn)
	d.closeCollect(sn)
	sessionCollMng.UnRegister(sn)
	d.reportCollectStatus(sn, ReportCollectStatusFail, fileName, receivedSz, fileSz, 11)
}

// collectTaskOffline 数据收集开始后，设备离线的处理
func (d *Sfl101) collectTaskOffline(sn string) {
	fileSz, receivedSz, fileName := sessionCollMng.GetFileParameters(sn)
	logger.Infof("filesz: %v, receivesz: %v, sn: %v", fileSz, receivedSz, sn)
	logger.Infof("collect task on dev offline, sn: %v, send stop to dev", sn)
	d.closeCollect(sn)
	sessionCollMng.UnRegister(sn)
	d.reportCollectStatus(sn, ReportCollectStatusFail, fileName, receivedSz, fileSz, 11)
}
func (d *Sfl101) ReceiveSfl101SetFreqCmd() {
	logger.Info("-->into Receive Sfl101 SetFreqCmd")
	res := &mavlink.Sfl101SetFreqCmdResponse{}
	d.GetPacket(res)
	logger.Debugf("Sfl101 Set FreqCmd Get ：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.Sfl101GetFreqCmd]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl101) SendSfl101HitModeSet(request *client.Sfl101HitModeRequest) (int, error) {
	logger.Info("-->into Send Hit Mode msg,req is %v", request)
	//3.设置打击模式   反制模式：1、Normal 2、GNSS
	reqMode := &mavlink.Sfl101SetHitModeRequest{}
	buffMode := reqMode.Create(request)
	logger.Debug("-->Set Hit Mode is :", buffMode)
	if _, err := d.Conn.Write(buffMode); err != nil {
		logger.Errorf("request Sfl101 Hit Mode err: %v", err)
		return Fail, fmt.Errorf("request Sfl101 Hit Mode err: %v", err)
	}
	managerMode, ok := d.WaitTaskMap[mavlink.Sfl101SetHitMode]
	if !ok {
		managerMode = NewWaitTaskManager(mavlink.Sfl101SetHitMode, true, 0)
		d.WaitTaskMap[mavlink.Sfl101SetHitMode] = managerMode
	}

	resultMode, err := managerMode.Wait()
	if err != nil {
		if checkNetConnErr := managerMode.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl101  Hit Mode err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	resMode, ok := resultMode.(*mavlink.Sfl101SetHitModeResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl101 Hit Mode result:%+v", *resMode)

	return int(resMode.Status), nil
}

func (d *Sfl101) SendSfl101GetFreqNodeList() ([]uint32, error) {
	logger.Info("---> Send GetDetectFreqList")
	req := &mavlink.Sfl101FreqDetectNodeListRequest{}
	buff := req.Create(0)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.Sfl101GetFreqList]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Sfl101GetFreqList, true, 0)
		d.WaitTaskMap[mavlink.Sfl101GetFreqList] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Send SendSfl101GetFreqNodeList is :[% x]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send SendSfl101GetFreqNodeList err:[%v].Buff is [% x]", err, buff)
		return nil, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send SendSfl101GetFreqNodeList err %s", err.Error())
		return nil, err
	}
	res := result.(*mavlink.Sfl101FreqDetectNodeListResponse)

	logger.Info("-->End SendSfl101GetFreqNodeList")
	return res.FreqList, nil
}

func (d *Sfl101) ReceiveSfl101GetHitPith() {
	logger.Info("-->into Receive Get Hit Pith")
	res := &mavlink.Sfl101GetPitchResponse{}
	if err := d.UnmarshalPayloadSfl101HitPith(res); err != nil {
		logger.Errorf(err.Error())
		return
	}
	logger.Debugf("ReceiveSfl101Get Hit Pith 接收到Sfl101信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.Sfl101GetHitPith]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl101) UnmarshalPayloadSfl101HitPith(data *mavlink.Sfl101GetPitchResponse) error {
	deviceInfoLen := binary.Size(data.HitCnt)
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.HitCnt); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}

	start := mavlink.HeaderLen + deviceInfoLen
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializeDrone(d.Msg[start:end]); err != nil {
		return err
	}

	return nil
}

func (d *Sfl101) UnmarshalPayloadSfl101GetGNSS(data *mavlink.Sfl101GNSSGetResponse) error {
	buff := &bytes.Buffer{}
	start := mavlink.HeaderLen
	end := start + int(data.Size())
	logger.Debug("start: , end: ", start, end)
	logger.Debug("d.Msg[start:end] = ", d.Msg[start:end])
	if err := binary.Write(buff, binary.LittleEndian, d.Msg[start:end]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, data); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}
	logger.Debugf("ReceiveSfl101 UnmarshalPayloadSfl101GetGNSS 接收到Sfl101信息：%#v", data)
	// if err := data.DeserializeDrone(d.Msg[start:end]); err != nil {
	// 	return err
	// }

	return nil
}

func (d *Sfl101) UnmarshalPayloadSfl101SetGNSS(data *mavlink.Sfl101GNSSSetResponse) error {
	buff := &bytes.Buffer{}
	start := mavlink.HeaderLen
	end := start + int(data.Size())
	logger.Debug("start: , end: ", start, end)
	logger.Debug("d.Msg[start:end] = ", d.Msg[start:end])
	if err := binary.Write(buff, binary.LittleEndian, d.Msg[start:end]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, data); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}
	logger.Debugf("ReceiveSfl101 UnmarshalPayloadSfl101SetGNSS 接收到Sfl101信息：%#v", data)
	// if err := data.DeserializeDrone(d.Msg[start:end]); err != nil {
	// 	return err
	// }

	return nil
}

func (d *Sfl101) ReceiveSfl101GetHitAngle() {
	logger.Info("-->into Receive Get Hit Angle")
	res := &mavlink.Sfl101GetAngleResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveSfl101 Get Hit Angle 接收到Sfl101信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.Sfl101GetHitAngle]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl101) ReceiveSfl101GetHitMode() {
	logger.Info("-->into Receive Get Hit Mode")
	res := &mavlink.Sfl101GetHitModeResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveSfl101Get Hit Mode 接收到Sfl101信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.Sfl101GetHitMode]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// SendSfl101SetWhite 发送设置Sfl101白名单
func (d *Sfl101) SendSfl101SetWhite(snList []mavlink.Sfl101WhiteInfo) (int, error) {
	logger.Info("---> Send Sfl101 Set White")
	defer func() {
		if r := recover(); r != nil {
			logger.Error("Sfl101 Set White occurred:", r)
			return
		}
	}()
	req := mavlink.Sfl101SetWhiteRequestAll{}
	whitelist := make([]mavlink.Sfl101WhiteInfo, 0)
	for _, s := range snList {
		whitelist = append(whitelist, mavlink.Sfl101WhiteInfo{Serial: s.Serial})
	}
	reqInfo := &mavlink.Sfl101SetWhiteRequest{
		WhiteNum:  uint16(len(whitelist)),
		WhiteList: whitelist,
	}

	buff := req.Create(reqInfo)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.Sfl101SetWhiteList]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Sfl101SetWhiteList, true, time.Millisecond*300)
		d.WaitTaskMap[mavlink.Sfl101SetWhiteList] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Send Sfl101 Set White is :[%v]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send Sfl101 Set White  err:[%v].Buff is [%v]", err, buff)
		return Fail, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send Sfl101 Set White  err %s", err.Error())
		return Fail, err
	}
	res := result.(*mavlink.Sfl101SetWhiteResponse)

	logger.Info("-->End Set Sfl101 Set Alarm")
	return int(res.Status), nil
}

func SendDevWhiteListToSfl101() {
	deviceInfo := &client.EquipListRes{}
	err := NewEquipList().List(context.Background(), &client.EquipListReq{}, deviceInfo)
	if err != nil {
		logger.Error("Get EquipList err: ", err)
	}
	//查白名单中的无人机，在Tracer侦测结果中添加无人机角色
	whiteList := &client.ListResAll{}
	err = NewWhiteList().ListAll(context.Background(), &client.ListReqAll{}, whiteList)
	if err != nil {
		logger.Error("Get whiteList err: ", err)
		return
	}
	logger.Info("Get EquipList is : ", whiteList.WhiteList)
	snList := make([]mavlink.Sfl101WhiteInfo, 0)

	for _, all := range whiteList.WhiteList {
		if all.Role == FRIEND {
			var tempSn [32]byte
			copy(tempSn[:], all.Sn)
			snList = append(snList, mavlink.Sfl101WhiteInfo{Serial: tempSn})
		}
	}
	for _, equip := range deviceInfo.Equips {
		if equip.Etype == "Sfl101" {
			sfl101Info := FindCacheDevice(equip.Sn, common.DEV_SFL101)
			if sfl101Info == nil {
				continue
			} else {
				dev := &Sfl101{Device: sfl101Info}
				dev.SendSfl101SetWhite(snList)
			}

		}
	}

}

// Sfl101SendUpgradeF1
func (d *Sfl101) Sfl101SendUpgradeF1(fileName string, c2Ip string) (int32, error) {
	logger.Info("Sfl101SendUpgradeF1 Start")

	req := &mavlink.Sfl101UpdateF1Request{}
	buff := req.Create(fileName, c2Ip)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.Sfl101IdUpgradeF1]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Sfl101IdUpgradeF1, true, 0)
		d.WaitTaskMap[mavlink.Sfl101IdUpgradeF1] = manager
	}
	task := manager.AddTask(nil, nil)
	logger.Debugf("Sfl101SendUpgradeF1 buff: %02X \n", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("Sfl101SendUpgradeF1 发送写入固件数据信息失败: ", err)
		return 1, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Sfl101SendUpgradeF1 WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 1, checkNetConnErr
		}
		return 1, err
	}
	res := result.(*mavlink.Sfl101UpdateF1Response)
	logger.Debugf("Sfl101UpdateF1Response 获取写入固件数据信息结果：%#v", res)
	logger.Info("Sfl101UpdateF1Response End")
	return int32(res.Status), nil
}

// ReceiveSfl101UpdateF1 获取请求固件升级响应
func (d *Sfl101) ReceiveSfl101UpdateF1() {
	res := &mavlink.Sfl101UpdateF1Response{}
	d.GetPacket(res)
	logger.Debugf("ReceiveSfl101UpdateF1 获取请求固件升级响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.Sfl101IdUpgradeF1]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// Sfl101SendUpgradeF2
func (d *Sfl101) Sfl101SendUpgradeF2() (int32, error) {
	logger.Info("Sfl101SendUpgradeF2 Start")
	req := &mavlink.Sfl101UpdateF2Request{}
	buff := req.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.Sfl101IdUpgradeF2]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Sfl101IdUpgradeF2, true, time.Second*15)
		d.WaitTaskMap[mavlink.Sfl101IdUpgradeF2] = manager
	}
	task := manager.AddTask(nil, nil)
	logger.Debugf("Sfl101SendUpgradeF2 buff: %02X \n", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("Sfl101SendUpgradeF2 发送写入固件数据信息失败: ", err)
		return -1, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Sfl101SendUpgradeF2 WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return -1, checkNetConnErr
		}
		return -1, err
	}
	res := result.(*mavlink.Sfl101UpdateF2Response)
	logger.Debugf("Sfl101UpdateF2Response 获取写入固件数据信息结果：%#v", res)
	logger.Info("Sfl101UpdateF2Response End")
	return int32(res.Progress), nil
}

// ReceiveSfl101UpdateF2 获取请求固件升级响应
func (d *Sfl101) ReceiveSfl101UpdateF2() {
	res := &mavlink.Sfl101UpdateF2Response{}
	d.GetPacket(res)
	logger.Debugf("ReceiveSfl101UpdateF2 获取请求固件升级响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.Sfl101IdUpgradeF2]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// Sfl101SendUpgradeF3
func (d *Sfl101) Sfl101SendUpgradeF3() (int32, error) {
	logger.Info("Sfl101SendUpgradeF3 Start")

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.Sfl101IdUpgradeF3]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Sfl101IdUpgradeF3, true, time.Second*60)
		d.WaitTaskMap[mavlink.Sfl101IdUpgradeF3] = manager
	}
	task := manager.AddTask(nil, nil)

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Sfl101SendUpgradeF3 WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 1, checkNetConnErr
		}
		return 1, err
	}
	res := result.(*mavlink.Sfl101UpdateF3Response)
	logger.Debugf("Sfl101UpdateF3Response 获取写入固件数据信息结果：%#v", res)
	logger.Info("Sfl101UpdateF3Response End")
	return int32(res.UpgradeResult), nil
}

// ReceiveSfl101UpdateF3 获取请求固件升级响应
func (d *Sfl101) ReceiveSfl101UpdateF3() {
	res := &mavlink.Sfl101UpdateF3Response{}
	d.GetPacket(res)
	logger.Debugf("ReceiveSfl101UpdateF3 获取请求固件升级响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.Sfl101IdUpgradeF3]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl101) ReceiveSfl101SendNoiseData() {
	timeFreq := &mavlink.Sfl101TimeFreqData{}
	err := timeFreq.Deserialize(d.Msg)
	if err != nil {
		logger.Error("timeFreq deserialize got err: %v", err)
		return
	}
	sn := ""
	idx := bytes.IndexByte(timeFreq.SnName[:], 0)
	if idx == -1 {
		idx = len(timeFreq.SnName)
	}
	sn = string(timeFreq.SnName[:idx])
	if timeFreq.FrameIdx == 0 {
		timeFreqMap.Reset(sn)
	}
	timeFreqMap.Write(sn, timeFreq.Data)
	logger.Infof("receive Sfl101TimeFreqData, sn: %v, frameIdx: %v, frameNum: %v", sn, timeFreq.FrameIdx, timeFreq.FrameNum)
	if timeFreq.FrameIdx == timeFreq.FrameNum-1 {
		content := timeFreqMap.ReadAll(sn)
		logger.Infof("Sfl101TimeFreqData content length: %v, sn: %v", len(content), sn)
		if len(content) != 768512 {
			logger.Errorf("Sfl101TimeFreqData content length is not 768512, sn: %v", sn)
			return
		}
		arr := make([]int32, 0)
		for i, _ := range content {
			if i%2 == 0 {
				tmp := binary.LittleEndian.Uint16(content[i : i+2])
				arr = append(arr, int32(int16(tmp)))
			}
		}
		data := &client.Sfl101TimeFreqData{
			Sn:   sn,
			Data: arr,
		}
		payload, _ := proto.Marshal(data)
		report := &client.ClientReport{
			MsgType: common.ClientMsgIdSfl101FreqData,
			Data:    payload,
		}
		out, err := proto.Marshal(report)
		if err != nil {
			logger.Error("Sfl101TimeFreqData marshal client report got error: %v", err)
			return
		}
		_ = mq.Sfl101MsgBroker.Publish(mq.Sfl101Topic, broker.NewMessage(out))
		logger.Infof("send Sfl101TimeFreqData to client, sn: %v", sn)
	}
}

// ReceiveSfl101GetFreqList 接收 freq detect 节点列表
func (d *Sfl101) ReceiveSfl101GetFreqList() {
	res := &mavlink.Sfl101FreqDetectNodeListResponse{}
	if err := d.UnmarshalFreqDetectNodeList(res); err != nil {
		logger.Errorf("parse freq detect node list response fail, e: %v", err)
		return
	}
	logger.Debugf("receive Send FreqDetectNodeList：%+v", *res)
	manager, ok := d.WaitTaskMap[mavlink.Sfl101GetFreqList]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl101) UnmarshalFreqDetectNodeList(data *mavlink.Sfl101FreqDetectNodeListResponse) error {
	buf := new(bytes.Buffer)
	if e := binary.Write(buf, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); e != nil {
		return fmt.Errorf("parse Sfl101FreqDetectNodeListResponse fail, e: %v", e)
	}

	if e := binary.Read(buf, binary.LittleEndian, &data.FreqNums); e != nil {
		return fmt.Errorf("parse Sfl101FreqDetectNodeListResponse.freqNums fail, e: %v", e)
	}

	if data.FreqNums <= 0 {
		return nil
	}

	start := mavlink.HeaderLen + binary.Size(data.FreqNums)
	end := d.MsgLen - mavlink.CrcLen
	buffer2 := new(bytes.Buffer)
	if e := binary.Write(buffer2, binary.LittleEndian, d.Msg[start:end]); e != nil {
		return fmt.Errorf("parse Sfl101FreqDetectNodeListResponse fail, e: %v", e)
	}
	for i := 0; i < int(data.FreqNums); i++ {
		var freqValue uint32 = 0
		if err := binary.Read(buffer2, binary.LittleEndian, &freqValue); err != nil {
			return fmt.Errorf("parse freq node list value fail, e: %v", err)
		}
		data.FreqList = append(data.FreqList, freqValue)
	}
	return nil
}

// procCollectErrStatus 注销设备sn collection session, 上报错误
func (d *Sfl101) procCollectErrStatus(sn string, errCode uint32) {
	if sn == "" {
		return
	}
	fileSz, receivedSz, fileName := sessionCollMng.GetFileParameters(sn)
	logger.Infof("filesz: %v, receivesz: %v, sn: %v", fileSz, receivedSz, sn)
	sessionCollMng.UnRegister(sn)
	d.reportCollectStatus(sn, ReportCollectStatusFail, fileName, receivedSz, fileSz, errCode)
}

// reportCollectStatus 上报数据收集状态
func (d *Sfl101) reportCollectStatus(devSn string, status uint32, fName string, receiveFileSz uint32, totalFileSz uint32, errCode uint32) {
	if status != ReportCollectStatusFail {
		errCode = 0
	}
	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	msgProto := &client.Sfl101CollectDataReport{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        devSn,
			MsgType:   mavlink.Sfl101SendFreqData,
			EquipType: int32(common.DEV_SFL101),
		},

		Data: &client.Sfl101CollectInfo{
			Status:          status,
			FileName:        fName,
			ReceiveFileSize: receiveFileSz,
			FileTotalSize:   totalFileSz,
			ErrCode:         errCode,
		},
	}
	if err == nil {
		msgProto.Header.ParentType = int32(equipModel.ParentType)
		msgProto.Header.ParentSn = equipModel.ParentSn
		msgProto.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msgProtoBin, e := proto.Marshal(msgProto)
	if e != nil {
		logger.Errorf("marshal collection status  fail, e: %v", e)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgIDSfl101CollectData,
		Data:    msgProtoBin,
	}
	out, e := proto.Marshal(report)
	if e != nil {
		logger.Errorf("marshal report data fail, e: %v", e)
		return
	}
	e = mq.Sfl101MsgBroker.Publish(mq.Sfl101Topic, broker.NewMessage(out))
	if e != nil {
		logger.Errorf("push msg on topic: %v fail", mq.Sfl101Topic)
		return
	}
	logger.Infof("send report, value: +%v", msgProto)
}

// ReceiveSfl101CollectData 转发数据收集
func (d *Sfl101) ReceiveSfl101CollectData() {
	logger.Infof("receive sfl101 collect data")
	collectStatus := &mavlink.Sfl101TimeFreqCollectReport{}

	// dev sn; 25 bytes
	readBegin := mavlink.HeaderLen
	offset := mavlink.DevSNLen
	readEnd := readBegin + offset
	err := mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, &collectStatus.SN, offset)
	devSn := ByteToString(collectStatus.SN[:])
	if devSn == "" {
		logger.Errorf("collect report dev sn is empty")
		return
	}
	d.updateStatus(devSn, 0)
	// status; 26 bytes
	readBegin = readEnd
	offset = 1
	readEnd = readBegin + offset
	err = mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, &collectStatus.Status, offset)
	logger.Debugf("sn: %v, status: %v", devSn, collectStatus.Status)

	if !sessionCollMng.IsBegin(devSn) {
		logger.Errorf("sn: %v not been triggered by client cmd; send stop cmd to history collect data.", devSn)
		d.closeCollect(devSn)
		return
	}

	sessionCollMng.UpdateTime(devSn)

	if collectStatus.Status == DEV_COLLECT_STATUS_ERR {

		var paramOne uint32 = 0
		readBegin = readEnd
		offset = 4
		readEnd = readBegin + offset
		err = mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, &paramOne, offset)

		logger.Infof("receive fail status, sn: %v, err code: %v", devSn, paramOne)

		d.procCollectErrStatus(devSn, paramOne)
		return
	}

	if !sessionCollMng.CheckCurrentReceiveStatus(devSn, int32(collectStatus.Status)) {
		logger.Errorf("sn: %v, receive status: %v not fit for cur status.", devSn, collectStatus.Status)
		return
	}

	if collectStatus.Status <= DEV_COLLECT_STATUS_GZIPING {
		procStatus := ReportCollectStatusIng
		if collectStatus.Status == DEV_COLLECT_STATUS_GZIPING {
			procStatus = ReportCollectGzip
		}
		fileSz, receivedSz, fileName := sessionCollMng.GetFileParameters(devSn)
		logger.Infof("filesz: %v, receivesz: %v, sn: %v", fileSz, receivedSz, devSn)
		d.reportCollectStatus(devSn, procStatus, fileName, receivedSz, fileSz, 0)
		return
	}

	// 开始上传，上传中，上传完成， 30 bytes
	var paramOne uint32 = 0
	readBegin = readEnd
	offset = 4
	readEnd = readBegin + offset
	err = mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, &paramOne, offset)

	//文件大小
	if collectStatus.Status == DEV_COLLECT_STATUS_UPLOAD_BEGIN {
		collectStatus.ParamOne = paramOne
		logger.Debugf("sn: %v, file size: %v", devSn, paramOne)
		sessionCollMng.UpdateFileSize(devSn, paramOne) // 记录文件大小

		fileSz, receivedSz, fileName := sessionCollMng.GetFileParameters(devSn)
		logger.Infof("filesz: %v, receivesz: %v, sn: %v", fileSz, receivedSz, devSn)
		d.reportCollectStatus(devSn, ReportCollectTraning, fileName, receivedSz, fileSz, 0)
		return
	}

	if collectStatus.Status == DEV_COLLECT_STATUS_UPLOAD_ING {
		// 最大分包数
		collectStatus.ParamOne = paramOne
		logger.Debugf("sn: %v, max package nums: %v", devSn, paramOne)

		// 分包序列号
		readBegin = readEnd
		offset = 4
		readEnd = readBegin + offset
		err = mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, &collectStatus.PkgIndex, offset)
		logger.Debugf("sn: %v, pkg index: %v", devSn, collectStatus.PkgIndex)

		// 发送数据长度
		readBegin = readEnd
		offset = 4
		readEnd = readBegin + offset
		err = mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, &collectStatus.DataLen, offset)
		logger.Debugf("sn: %v, pkg data len: %v", devSn, collectStatus.DataLen)
		sessionCollMng.UpdateReceiveFileSz(devSn, collectStatus.DataLen)

		// 数据内容
		readBegin = readEnd
		offset = int(collectStatus.DataLen)
		readEnd = readBegin + offset
		collectStatus.Data = make([]byte, offset)

		err = mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, collectStatus.Data, offset)
		if err != nil {
			logger.Errorf("msg decode data pkg fail,sn: %v,e: %v", devSn, err)
			return
		}

		fileSz, receivedSz, fileName := sessionCollMng.GetFileParameters(devSn)
		logger.Infof("filesz: %v, receivesz: %v, sn: %v", fileSz, receivedSz, devSn)
		d.reportCollectStatus(devSn, ReportCollectTraning, fileName, receivedSz, fileSz, 0)
		err := sessionCollMng.WriteBuffToFile(devSn, collectStatus.Data)
		if err != nil {
			logger.Errorf("write data to buf fail, sn: %v, pkgIndex: %v, maxPkgNums: %v",
				devSn, collectStatus.PkgIndex, collectStatus.ParamOne)
			return
		}

		if collectStatus.PkgIndex < collectStatus.ParamOne-1 {
			logger.Debugf("is not full pkg, sn: %v, maxPkgNums: %v, curPkgIndex: %v, cur pkg len: %v",
				devSn, collectStatus.ParamOne, collectStatus.PkgIndex, collectStatus.DataLen)
			return
		}
		logger.Infof("receive complete package, sn: %v, cur pkgIndex: %v, maxPkgNums: %v",
			devSn, collectStatus.PkgIndex, collectStatus.ParamOne)
		return
	}

	if collectStatus.Status == DEV_COLLECT_STATUS_UPLOAD_END {
		logger.Infof("receive collect done : %v, sn: %v", DEV_COLLECT_STATUS_UPLOAD_END, devSn)
		d.receiveDonePkgProc(devSn)
	}
}

// receiveDonePkgProc 完整包后逻辑处理： 写文件，删除状态机
func (d *Sfl101) receiveDonePkgProc(devSn string) {
	fileSz, receivedSz, fileName := sessionCollMng.GetFileParameters(devSn)
	logger.Infof("filesz: %v, receivesz: %v, sn: %v", fileSz, receivedSz, devSn)
	sessionCollMng.UnRegister(devSn)
	d.reportCollectStatus(devSn, ReportCollectStatusDone, fileName, receivedSz, fileSz, 0)
	logger.Info("--->End Receive tracer collection data")
}

// closeCollect 发送关闭收集收集
func (d *Sfl101) closeCollect(sn string) (int32, error) {
	logger.Info("---> Send closeCollect: ", CollectDataToDevEnd)

	req := &mavlink.Sfl101SetFreqCmdRequest{}
	buff := req.Create(CollectDataToDevEnd)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.Sfl101GetFreqCmd]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Sfl101GetFreqCmd, true, 0)
		d.WaitTaskMap[mavlink.Sfl101GetFreqCmd] = manager
	}
	task := manager.AddTask(nil, nil)
	logger.Debugf("Send Sfl101 closeCollect is :[% x]", buff)

	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send Sfl101 closeCollect err:[%v].Buff is [%v]", err, buff)
		manager.DeleteTask(task.TaskId)
		return 0, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send Sfl101 closeCollect err %s", err.Error())
		return 0, err
	}
	defer func() {
		sessionCollMng.UnRegister(sn)
	}()

	res := result.(*mavlink.TracerCollectResponse)

	logger.Info("-->End closeCollect")
	return int32(res.Status), nil
}

func (d *Sfl101) ReceiveSfl101SendTimeFreq() {
	timeFreq := &mavlink.Sfl101TimeFreqData{}
	err := timeFreq.Deserialize(d.Msg)
	if err != nil {
		logger.Error("timeFreq deserialize got err: %v", err)
		return
	}
	sn := ""
	idx := bytes.IndexByte(timeFreq.SnName[:], 0)
	if idx == -1 {
		idx = len(timeFreq.SnName)
	}
	sn = string(timeFreq.SnName[:idx])
	if timeFreq.FrameIdx == 0 {
		timeFreqMap.Reset(sn)
	}
	timeFreqMap.Write(sn, timeFreq.Data)
	logger.Infof("receive Sfl101TimeFreqData, sn: %v, frameIdx: %v, frameNum: %v", sn, timeFreq.FrameIdx, timeFreq.FrameNum)
	if timeFreq.FrameIdx == timeFreq.FrameNum-1 {
		content := timeFreqMap.ReadAll(sn)
		logger.Infof("Sfl101TimeFreqData content length: %v, sn: %v", len(content), sn)
		if len(content) != 76800 {
			logger.Errorf("Sfl101TimeFreqData content length is not 768512, sn: %v", sn)
			return
		}
		arr := make([]int32, 0)
		for i, _ := range content {
			if i%2 == 0 {
				tmp := binary.LittleEndian.Uint16(content[i : i+2])
				arr = append(arr, int32(int16(tmp)))
			}
		}
		data := &client.Sfl101TimeFreqData{
			Sn:   sn,
			Data: arr,
		}
		payload, _ := proto.Marshal(data)
		report := &client.ClientReport{
			MsgType: common.ClientMsgIDSfl101TimeFreqData,
			Data:    payload,
		}
		out, err := proto.Marshal(report)
		if err != nil {
			logger.Error("Sfl101TimeFreqData marshal client report got error: %v", err)
			return
		}
		_ = mq.Sfl101MsgBroker.Publish(mq.Sfl101Topic, broker.NewMessage(out))
		logger.Infof("send Sfl101TimeFreqData to client, sn: %v", sn)
	}
}

func (d *Sfl101) ReceiveSfl101SendTimeFreqD6() {
	timeFreq := &mavlink.Sfl101TimeFreqDataD6{}
	err := timeFreq.Deserialize(d.Msg)
	if err != nil {
		logger.Error("timeFreq deserialize D6 got err: %v", err)
		return
	}
	sn := ""
	idx := bytes.IndexByte(timeFreq.SnName[:], 0)
	if idx == -1 {
		idx = len(timeFreq.SnName)
	}
	sn = string(timeFreq.SnName[:idx])
	if timeFreq.FrameIdx == 0 {
		timeFreqMap.Reset(sn)
	}
	timeFreqMap.Write(sn, timeFreq.Data)
	logger.Infof("receive Sfl101TimeFreqDataD6, sn: %v, frameIdx: %v, frameNum: %v", sn, timeFreq.FrameIdx, timeFreq.FrameNum)
	if timeFreq.FrameIdx == timeFreq.FrameNum-1 {
		content := timeFreqMap.ReadAll(sn)
		logger.Infof("Sfl101TimeFreqDataD6 content length: %v, sn: %v", len(content), sn)
		if len(content) != 76800 {
			logger.Errorf("Sfl101TimeFreqDataD6 content length is not 77312, sn: %v", sn)
			return
		}
		arr := make([]int32, 0)
		for i, _ := range content {
			if i%2 == 0 {
				tmp := binary.LittleEndian.Uint16(content[i : i+2])
				arr = append(arr, int32(int16(tmp)))
			}
		}
		data := &client.Sfl101TimeFreqDataD6{
			Sn:       sn,
			Freq:     timeFreq.Freq,
			TrackBws: timeFreq.TrackBws,
			TrackBwe: timeFreq.TrackBwe,
			Data:     arr,
		}
		payload, _ := proto.Marshal(data)
		report := &client.ClientReport{
			MsgType: common.ClientMsgIDSfl101TimeFreqDataD6,
			Data:    payload,
		}
		out, err := proto.Marshal(report)
		if err != nil {
			logger.Error("Sfl101TimeFreqDataD6 marshal client report got error: %v", err)
			return
		}
		_ = mq.Sfl101MsgBroker.Publish(mq.Sfl101Topic, broker.NewMessage(out))
		logger.Infof("send Sfl101TimeFreqDataD6 to client, sn: %v", sn)
	}
}

// Heart 处理SFL101设备信息
func (d *Sfl101) ReceiveSfl101DevStateMsg() {
	devState := &mavlink.Sfl101DevState{}
	if err := d.UnmarshalPayloadDevStateMsg(devState); err != nil {
		logger.Errorf(err.Error())
		return
	}

	devSn := ByteToString(devState.Info.Sn[:])
	if devSn != "" {
		// update device status
		d.updateStatus(devSn, 0)
		//if isEnable := d.updateStatus(devSn); isEnable == common.DeviceDisenable {
		//	logger.Infof("Sfl101 device %v disable", devSn)
		//	return
		//}
		// report heartbeat
		d.DevStateReport(devSn, devState)
	}
}
func (d *Sfl101) UnmarshalPayloadDevStateMsg(data *mavlink.Sfl101DevState) error {
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("Sfl101 UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("Sfl101 UnmarshalPayload read data err: %v", err)
	}

	return nil
}
func (d *Sfl101) DevStateReport(devSn string, devStateInfo *mavlink.Sfl101DevState) {

	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	dataInfo := &client.Sfl101DevStateInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        devSn,
			EquipType: int32(common.DEV_SFL101),
			MsgType:   mavlink.Sfl101DevStateMsg,
		},
		Data: &client.Sfl101DevStateInfoData{
			Sn:              devSn,
			TimeStamp:       int64(devStateInfo.Info.TimeStamp),
			SportState:      int32(devStateInfo.Info.SportState),
			GpsState:        int32(devStateInfo.Info.GPSState),
			GpsSateliteNum:  int32(devStateInfo.Info.GPSSateliteNum),
			DGpsState:       int32(devStateInfo.Info.DGPSState),
			DGpsSateliteNum: int32(devStateInfo.Info.DGPSSateliteNum),
			DGpsRaw:         devStateInfo.Info.DGPSRaw,
			CpuTemperature:  devStateInfo.Info.CPUTemperature,
			CoreTemperature: devStateInfo.Info.CoreTemperature,
			Amp1Temperature: devStateInfo.Info.Amp1Temperature,
			Amp2Temperature: devStateInfo.Info.Amp2Temperature,
		},
	}
	if err == nil {
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgIdSFL101DevStateE0,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.Sfl101MsgBroker.Publish(mq.Sfl101Topic, broker.NewMessage(out))

	logger.Infof("Sfl101 devState Info has reported, devSn:%v,report:%v", devSn, dataInfo.Data)
}

func (d *Sfl101) SendSfl101SetPosture(request *client.Sfl101SetPostureRequest) (int, error) {
	logger.Info("-->into Send Sfl101 SetDevPosture  msg,req:", request)
	//获取开关机状态
	req := &mavlink.Sfl101SetPostureRequest{}
	buff := req.Create(request)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Send Sfl101 SetDevPosture info err: %v", err)
		return Fail, fmt.Errorf("request Send Sfl101 SetDevPosture info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.Sfl101SetDevPosture]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Sfl101SetDevPosture, true, 0)
		d.WaitTaskMap[mavlink.Sfl101SetDevPosture] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("requestSend Sfl101 SetDevPosture info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.Sfl101SetPostureResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Send Sfl101 SetDevPosture result:%+v", *res)

	return int(res.Status), nil
}
func (d *Sfl101) ReceiveSfl101SetPosture() {
	logger.Info("-->into Receive Sfl101 SetDevPosture")
	res := &mavlink.Sfl101SetPostureResponse{}
	d.GetPacket(res)
	logger.Debugf("Sfl101 SetDevPosture Get ：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.Sfl101SetDevPosture]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl101) SendSfl101GetPosture(request *client.Sfl101GetPostureRequest) (*client.Sfl101GetPostureResponse, error) {
	logger.Info("-->into Send Sfl101 GetPosture  msg,req:", request)
	//获取开关机状态
	req := &mavlink.Sfl101GetPostureRequest{}
	buff := req.Create()
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Send Sfl101 GetPosture info err: %v", err)
		return nil, fmt.Errorf("request Send Sfl101 GetPosture info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.Sfl101GetDevPosture]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Sfl101GetDevPosture, true, 0)
		d.WaitTaskMap[mavlink.Sfl101GetDevPosture] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("requestSend Sfl101 GetPosture info err: %v", checkNetConnErr)
			return nil, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.Sfl101GetPostureResponse)
	if !ok {
		return nil, errors.New("response err type")
	}
	logger.Debug("response Send Sfl101 GetPosture result:%+v", *res)
	rsp := &client.Sfl101GetPostureResponse{}
	rsp.Set = int32(res.Set)
	rsp.Pitch = res.Pitch
	rsp.Raw = res.Raw
	return rsp, nil
}
func (d *Sfl101) ReceiveSfl101GetPosture() {
	logger.Info("-->into Receive Sfl101 GetPosture")
	res := &mavlink.Sfl101GetPostureResponse{}
	d.GetPacket(res)
	logger.Debugf("Sfl101 GetPosture Get ：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.Sfl101GetDevPosture]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

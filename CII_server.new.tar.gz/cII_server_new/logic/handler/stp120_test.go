package handler

import (
	"adasgitlab.autel.com/tools/cuav_server/proto/mavlink"
	"bytes"
	"encoding/binary"
	"testing"
)

func TestStp120D9Decode(t *testing.T) {
	src := []byte{0x01, 0x00, 0x80, 0x52, 0x44, 0x00, 0x00, 0x00, 0x00}
	buff := &bytes.Buffer{}
	if err := binary.Write(buff, binary.LittleEndian, src); err != nil {
		t.Errorf("write data fail, err: %v", err)
		return
	}
	dst := &mavlink.Stp120ReferencePerformanceEvaluateRequest{}
	err := binary.Read(buff, binary.LittleEndian, dst)
	if err != nil {
		t.Errorf("parse fail, err: %v", err)
		return
	}
	t.Logf("%+v", *dst)
}

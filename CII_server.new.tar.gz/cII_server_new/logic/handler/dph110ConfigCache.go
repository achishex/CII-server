package handler

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"gorm.io/gorm"

	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
)

type DPH110Config struct{}

func NewDPH110Config() *DPH110Config {
	return &DPH110Config{}
}

func (d *DPH110Config) Upsert(req *client.RadarSetConfigRequest) error {
	dph110Config, err := d.First(req.GetSn())
	if err != nil {
		if err == gorm.ErrRecordNotFound {
			dphModel := d.generateInsert(req)
			err := d.Insert(dphModel)
			if err != nil {
				logger.Errorf("[DPH110Config] Create err: %v", err)
				return err
			}
			return nil
		}
		logger.Errorf("[DPH110Config] First err: %v", err)
		return err
	}
	//更新
	field := d.generateUpdate(req)
	if err = db.GetDB().Model(&bean.DPH110Config{}).Where("id=?", dph110Config.Id).Updates(field).Error; err != nil {
		logger.Errorf("[DPH110Config] Update err: %v", err)
		return err
	}
	return nil
}

func (d *DPH110Config) Insert(dphModel *bean.DPH110Config) error {
	return db.GetDB().Model(&bean.DPH110Config{}).Create(&dphModel).Error
}

func (d *DPH110Config) First(sn string) (*bean.DPH110Config, error) {
	var dphModel bean.DPH110Config
	err := db.GetDB().Model(&bean.DPH110Config{}).Where("sn=?", sn).First(&dphModel).Error
	if err != nil {
		return nil, err
	}
	return &dphModel, nil
}

func (d *DPH110Config) generateInsert(req *client.RadarSetConfigRequest) *bean.DPH110Config {
	dphModel := &bean.DPH110Config{
		Sn:              req.Sn,
		Longitude:       req.GetLongitude(),
		Latitude:        req.GetLatitude(),
		Altitude:        req.GetAltitude(),
		Heading:         req.GetHeading(),
		Pitching:        req.GetPitching(),
		Rolling:         req.GetRolling(),
		EleScanCenter:   req.GetEleScanCenter(),
		EleScanScope:    req.GetEleScanScope(),
		AziScanCenter:   req.GetAziScanCenter(),
		AziScanScope:    req.GetAziScanScope(),
		RadarScanRadius: int32(req.GetRadarScanRadius()),
		FilterLevel:     int32(req.GetFilterLevel()),
		FChannel:        int32(req.GetFChannel()),
		TChannel:        int32(req.GetTChannel()),
	}
	if req.GetEleScanCenter() == 0 {
		dphModel.EleScanCenter = 15.00
	}
	if req.GetEleScanScope() == 0 {
		dphModel.EleScanScope = 30.00
	}
	if req.GetAziScanCenter() == 0 {
		dphModel.AziScanCenter = 180.00
	}
	if req.GetAziScanScope() == 0 {
		dphModel.AziScanScope = 360.00
	}
	if req.GetRadarScanRadius() == 0 {
		dphModel.RadarScanRadius = 6000
	}
	if req.GetFilterLevel() == 0 {
		dphModel.FilterLevel = 1
	}
	if req.GetFChannel() == 0 {
		dphModel.FChannel = 1
	}
	if req.GetTChannel() == 0 {
		dphModel.TChannel = 1
	}
	return dphModel
}

func (d *DPH110Config) generateUpdate(req *client.RadarSetConfigRequest) map[string]interface{} {
	field := make(map[string]interface{})
	if req.Longitude != nil {
		field["longitude"] = req.GetLongitude()
	}
	if req.Latitude != nil {
		field["latitude"] = req.GetLatitude()
	}
	if req.Altitude != nil {
		field["altitude"] = req.GetAltitude()
	}
	if req.Heading != nil {
		field["heading"] = req.GetHeading()
	}
	if req.Pitching != nil {
		field["pitching"] = req.GetPitching()
	}
	if req.Rolling != nil {
		field["rolling"] = req.GetRolling()
	}
	if req.EleScanCenter != nil {
		field["ele_scan_center"] = req.GetEleScanCenter()
	}
	if req.EleScanScope != nil {
		field["ele_scan_scope"] = req.GetEleScanScope()
	}
	if req.AziScanCenter != nil {
		field["azi_scan_center"] = req.GetAziScanCenter()
	}
	if req.AziScanScope != nil {
		field["azi_scan_scope"] = req.GetAziScanScope()
	}
	if req.RadarScanRadius != nil {
		field["radar_scan_radius"] = req.GetRadarScanRadius()
	}
	if req.FilterLevel != nil {
		field["filter_level"] = req.GetFilterLevel()
	}
	if req.FChannel != nil {
		field["f_channel"] = req.GetFChannel()
	}
	if req.TChannel != nil {
		field["t_channel"] = req.GetTChannel()
	}

	return field
}

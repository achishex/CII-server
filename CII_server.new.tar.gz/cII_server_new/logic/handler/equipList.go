package handler

import (
	"context"
	"errors"
	"fmt"
	"math/rand"
	"strconv"
	"strings"
	"sync"
	"time"

	"adasgitlab.autel.com/tools/cuav_plugin/broker"
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"google.golang.org/protobuf/proto"
	"gorm.io/gorm"

	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/proto/mavlink"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
	"adasgitlab.autel.com/tools/cuav_server/repo/utils"
)

type EquipList struct {
}

func NewEquipList() *EquipList {
	return &EquipList{}
}

// QueryDevDetailsBySn 根据sn 查询 设备详情
func (c *EquipList) QueryDevDetailsBySn(ctx context.Context, snList []string) ([]*bean.EquipList, error) {
	if len(snList) <= 0 {
		return nil, nil
	}

	var list []*bean.EquipList
	err := db.GetDB().Model(&bean.EquipList{}).Where("sn IN (?)", snList).Find(&list).Error
	if err != nil {
		logger.Errorf("query list error:", err)
	}
	return list, err
}
func (c *EquipList) UpdateSomeFields(ctx context.Context, in *client.UpdateCondReq, out *client.UpdateCondRsp) error {
	if in == nil {
		return errors.New("input param is nil")
	}
	if err := db.GetDB().Model(&bean.EquipList{}).Where("sn=?", in.Sn).Update("etype", in.Etype).Error; err != nil {
		logger.Errorf("update table equip_list etype to: %v fail, sn: %v, err: %v", in.Sn, in.Etype, err)
		return err
	}
	return nil
}

func (c *EquipList) Insert(ctx context.Context, req *client.EquipCrudReq, res *client.EquipCrudRes) error {
	var model bean.EquipList
	err := db.GetDB().Model(&bean.EquipList{}).Where("sn = ?", req.Sn).First(&model).Error
	if err == nil {
		logger.Error("record already exists:", req.Sn)
		return nil
	}
	if err == gorm.ErrRecordNotFound {
		c.generate(&model, req)
		err := db.GetDB().Model(&bean.EquipList{}).Create(&model).Error
		if err != nil {
			logger.Errorf("create equip list  error:%v", err)
			return err
		}
		return nil
	}
	return err
}

func (c *EquipList) Update(ctx context.Context, req *client.EquipCrudReq, res *client.EquipCrudRes) error {
	var model bean.EquipList
	err := db.GetDB().Model(&bean.EquipList{}).Where("sn = ?", req.Sn).Error
	if err != nil {
		if err == gorm.ErrRecordNotFound {
			return errors.New("record does not exist")
		}
		return err
	}
	c.generate(&model, req)
	err = db.GetDB().Model(&bean.EquipList{}).Where("sn = ?", req.Sn).Updates(&model).Error
	if err != nil {
		logger.Errorf("update failed,error:%v", err)
		return err
	}
	//修改name,立即上报云端
	if req.Name != "" {
		go reportCloud(req)
	}
	return nil
}

func reportCloud(req *client.EquipCrudReq) {
	report := &client.Equip{
		Id:             req.Id,
		Etype:          req.Etype,
		Ip:             req.Ip,
		Name:           req.Name,
		Sn:             req.Sn,
		RadarRelevance: req.RadarRelevance,
		ParentSn:       req.ParentSn,
	}
	if req.IsEnable {
		report.Enable = common.DeviceEnable
	}
	msg, err := proto.Marshal(report)
	if err != nil {
		logger.Error("reportCloud marshal error:", err)
		return
	}

	_ = mq.EquipmentBroker.Publish(mq.EquipmentUpdateTopic, broker.NewMessage(msg))

	logger.Infof("equipment update has reported, devSn: %v,report:%v", req.Sn, report)
}
func (c *EquipList) FindByIds(_ context.Context, req *client.EquipDeleteReq, res *[]*bean.EquipList) error {
	var list []*bean.EquipList
	err := db.GetDB().Model(&bean.EquipList{}).Find(&list, req.Ids).Error
	if err != nil {
		logger.Errorf("find equipment list fail, e: %v", err)
		return err
	}
	*res = list
	return nil
}

func (c *EquipList) InsetBackUp(ctx context.Context, req *bean.EquipList, res *client.CrudRes) error {
	var model bean.EquipListBackUp

	model.Id = int(req.Id)
	model.Reverse = req.Reverse
	model.TerminalId = req.TerminalId
	model.Etype = req.Etype
	model.TcpPort = int(req.TcpPort)
	model.UdpPort = int(req.UdpPort)
	model.Ip = req.Ip
	if req.CrtTime == "" {
		model.CrtTime = utils.ParseTimeToString(time.Now())
	} else {
		model.CrtTime = req.CrtTime
	}
	model.Status = req.Status
	if req.UpdateTime == "" {
		model.UpdateTime = utils.ParseTimeToString(time.Now())
	} else {
		model.UpdateTime = req.UpdateTime
	}
	model.Name = req.Name
	model.Content = req.Content
	model.SubType = req.SubType
	model.LocalIp = req.LocalIp
	model.LocalUdpPort = int(req.LocalUdpPort)
	model.Sn = req.Sn

	model.IsEnable = req.IsEnable

	err := db.GetDB().Model(&bean.EquipListBackUp{}).Create(&model).Error
	if err != nil {
		logger.Errorf("create equip list backup  error:%v", err)
		return err
	}
	return err
}
func (c *EquipList) InsertOrUpdateBackupTab(ctx context.Context, req []*bean.EquipList) error {
	utils.CheckAndCreateTab[bean.EquipListBackUp](db.GetDB(), bean.EquipListBackUp{}.TableName(), &bean.EquipListBackUp{}, 0)

	for _, item := range req {
		if item == nil {
			continue
		}
		var dst bean.EquipListBackUp
		err := db.GetDB().Model(&bean.EquipListBackUp{}).Where("sn = ?", item.Sn).First(&dst).Error
		if err != nil && errors.Is(err, gorm.ErrRecordNotFound) {
			c.InsetBackUp(ctx, item, nil)

		} else if err == nil {
			logger.Infof("sn: %v has exist in tab: %v, need to update", item.Sn, dst.TableName())

		} else {
			logger.Errorf("find item fail, e: %v, sn: %v", err, item.Sn)
		}
	}
	return nil
}

func (c *EquipList) Delete(ctx context.Context, req *client.EquipDeleteReq, res *client.EquipCrudRes) error {
	err := db.GetDB().Delete(&bean.EquipList{}, &req.Ids).Error
	if err != nil {
		logger.Errorf("delete equip list error:", err)
		return err
	}
	return nil
}
func (c *EquipList) DeleteWithSn(ctx context.Context, req *client.DeleteWithSnReq, res *client.EquipCrudRes) error {
	err := db.GetDB().Delete(&bean.EquipList{}).Where("sn = ?", &req.Sn).Error
	if err != nil {
		logger.Errorf("delete equip with sn list error:", err)
		return err
	}
	return nil
}

func (c *EquipList) List(ctx context.Context, req *client.EquipListReq, res *client.EquipListRes) error {
	var list []*bean.EquipList
	err := db.GetDB().Model(&bean.EquipList{}).Find(&list).Error
	if err != nil {
		return errors.New("query list failed")
	}
	for _, v := range list {
		var model client.List
		c.generateRes(&model, *v)
		if v.Sn == "" {
			continue
		}
		res.Equips = append(res.Equips, &model)
	}
	return nil
}

func (c *EquipList) SetEnableState(ctx context.Context, req *client.SetEnableReq, res *client.SetEnableRes) error {
	var model bean.EquipList
	if req.Sn == "" {
		return nil
	}
	err := db.GetDB().Where("sn = ?", req.Sn).First(&model).Error
	if err != nil {
		if err != gorm.ErrRecordNotFound {
			return err
		}
	}
	if err == gorm.ErrRecordNotFound {
		err := db.GetDB().Create(&bean.EquipList{
			Sn:       req.Sn,
			IsEnable: int(req.Status),
			Etype:    req.EType,
		}).Error
		if err != nil {
			logger.Errorf("SetEnableState create equip list  error:%v", err)
			return err
		}
	} else {
		model.IsEnable = int(req.Status)
		err = db.GetDB().Model(&bean.EquipList{}).Where("sn = ?", req.Sn).Updates(&model).Error
		if err != nil {
			logger.Errorf("SetEnableState failed,error:%v", err)
			return err
		}
	}
	res.Status = 1
	return nil
}

func (c *EquipList) GetSourceId(ctx context.Context, req *client.GetSourceIdReq, res *client.GetSourceIdRes) error {
	var model bean.EquipSourceId
	if req.Sn == "" {
		return errors.New("sn is nil")
	}
	var err error
	if err = db.GetDB().Where("sn = ?", req.Sn).Last(&model).Error; err != nil && err != gorm.ErrRecordNotFound {
		return err
	}
	//不存在要判断当前最大的sourceId，然后加1
	if err == gorm.ErrRecordNotFound && req.Sn != "" {
		for i := 1; i < 16; i++ {
			var checkModel bean.EquipSourceId
			sourceId := int32(i<<4) + req.DevType
			if err = db.GetDB().Where("source_id = ?", sourceId).Last(&checkModel).Error; err != nil && err == gorm.ErrRecordNotFound {
				es := &bean.EquipSourceId{
					Sn:       req.Sn,
					SourceId: sourceId,
				}
				if err = db.GetDB().Create(es).Error; err != nil {
					logger.Errorf("GetSourceId create sourceId error:%v", err)
					return err
				}
				res.SourceId = sourceId
				res.Sn = req.Sn
				return nil
			}
		}
		return errors.New("sourceId 不足")
	}
	res.Sn = model.Sn
	res.SourceId = model.SourceId
	return nil
}

func (c *EquipList) GetSnBySourceId(ctx context.Context, req *client.GetSnBySourceIdReq, res *client.GetSnBySourceIdRes) error {
	var model bean.EquipSourceId
	err := db.GetDB().Where("source_id = ?", req.SourceId).Last(&model).Error
	if err != nil {
		return err
	}
	res.Sn = model.Sn
	res.SourceId = model.SourceId
	return nil
}

func (c *EquipList) GetStatus(ctx context.Context, req *client.GetStatusReq, res *client.GetStatusRes, radarVersion ...int32) error {
	if req.Sn == "" {
		return nil
	}
	var model bean.EquipList
	err := db.GetDB().Where("sn = ?", req.Sn).Last(&model).Error

	if err != nil {
		if err == gorm.ErrRecordNotFound {
			res.IsEnable = common.DeviceEnable
			res.IsOnline = 2
			res.IsAllow = 1
			//前端组网成功前，不需要添加设备，只有获取信道的时候，不存在设备时添加
			if req.EType != "" {
				equipModel := &bean.EquipList{
					Sn:         req.Sn,
					IsEnable:   common.DeviceEnable,
					IsOnline:   2,
					Etype:      req.EType,
					Name:       common.GetDevNameFromEtype(req.EType, req.SubDevType) + "#" + c.GenerateUniqueNumber(ctx, req.EType, req.SubDevType),
					SubDevType: int(req.SubDevType),
				}
				if req.EType == common.Radar {
					equipModel.VersionType = radarVersion[0]
				}
				if err := db.GetDB().Create(equipModel).Error; err != nil {
					logger.Errorf("GetStatus create equip list  error:%v", err)
					return nil
				} else {
					go func() {
						time.Sleep(1 * time.Second)
						bean.GupdateEquipListNotify <- true
						logger.Debug("send notify to update equip_list")
					}()
				}
			}
			return nil
		}
		return err
	}
	res.Sn = model.Sn
	res.Name = model.Name
	res.IsEnable = common.DeviceEnable
	res.IsOnline = int32(model.IsOnline)
	//if model.IsEnable == common.DeviceDisenable || model.IsOnline == 1 {
	//	res.IsAllow = 2
	//} else {
	res.IsAllow = 1
	//}
	return nil
}
func (c *EquipList) GetStatusNotCreat(ctx context.Context, req *client.GetStatusReq, res *client.GetStatusRes) error {
	var model bean.EquipList
	err := db.GetDB().Where("sn = ?", req.Sn).Last(&model).Error
	if err != nil {
		logger.Errorf("sn not exit:%v", req.Sn)
		return err
	}
	res.Sn = model.Sn
	res.Name = model.Name
	res.IsEnable = int32(model.IsEnable)
	res.IsOnline = int32(model.IsOnline)
	if model.IsEnable == common.DeviceDisenable || model.IsOnline == 1 {
		res.IsAllow = 2
	} else {
		res.IsAllow = 1
	}
	return nil
}

func (c *EquipList) generate(model *bean.EquipList, req *client.EquipCrudReq) {
	model.Id = int(req.Id)
	model.Reverse = req.Reverse
	model.TerminalId = req.TerminalId
	model.Etype = req.Etype
	model.TcpPort = int(req.TcpPort)
	model.UdpPort = int(req.UdpPort)
	model.Ip = req.Ip
	if req.CrtTime == "" {
		model.CrtTime = utils.ParseTimeToString(time.Now())
	} else {
		model.CrtTime = req.CrtTime
	}
	model.Status = strconv.Itoa(int(req.Status))
	if req.UpdateTime == "" {
		model.UpdateTime = utils.ParseTimeToString(time.Now())
	} else {
		model.UpdateTime = req.UpdateTime
	}
	model.Name = req.Name
	model.Content = req.Content
	model.SubType = req.SubType
	model.LocalIp = req.LocalIp
	model.LocalUdpPort = int(req.LocalUdpPort)
	model.Sn = req.Sn
	if req.IsEnable {
		model.IsEnable = common.DeviceEnable
	}
	model.DevVersion = req.DevVersion
	model.ParentSn = req.ParentSn
	model.SubDevType = int(req.SubDevType)
	//1-在线 2-离线
	model.IsOnline = 2
	if req.IsOnline {
		model.IsOnline = 1
	}
}

func (c *EquipList) generateRes(model *client.List, list bean.EquipList) {
	model.Id = int64(list.Id)
	model.Reverse = list.Reverse
	model.TerminalId = list.TerminalId
	model.Etype = list.Etype
	model.TcpPort = int64(list.TcpPort)
	model.UdpPort = int64(list.UdpPort)
	model.Ip = list.Ip
	status, _ := strconv.Atoi(list.Status)
	model.Status = int32(status)
	model.UpdateTime = list.UpdateTime
	model.Name = list.Name
	model.Content = list.Content
	model.SubType = list.SubType
	model.LocalIp = list.LocalIp
	model.LocalUdpPort = int32(list.LocalUdpPort)
	model.Sn = list.Sn
	model.IsEnable = int32(list.IsEnable)
	model.RadarRelevance = int32(list.RadarRelevance)
	model.DevVersion = list.DevVersion
	model.ParentSn = list.ParentSn
	model.SubDevType = int64(list.SubDevType)
	model.IsIntegrated = list.IsIntegrated
	model.VersionType = list.VersionType
}

func (c *EquipList) DelSpooferDevice(ctx context.Context, req *client.DelSpooferDeviceReq, res *client.DelSpooferDeviceRes) error {
	err := db.GetDB().Delete(&bean.EquipList{}, "etype = ?", req.Etype).Error
	if err != nil {
		logger.Errorf("delete equip list error:", err)
		return err
	}
	return nil
}

func (c *EquipList) UpdateRadarStatus(ctx context.Context, req *client.UpdateRadarStatusReq, res *client.UpdateRadarStatusRes) error {
	logger.Info("Update Radar Status:", req)
	err := db.GetDB().Model(&bean.EquipList{}).Where(true).Update("radar_relevance", 0).Error
	if err != nil {
		logger.Errorf("update All failed, error: %v", err)
		return err
	}
	for _, devInfo := range req.List {
		err = db.GetDB().Model(&bean.EquipList{}).Where("sn = ?", devInfo.Sn).Update("radar_relevance", 1).Error
		if err != nil {
			logger.Errorf("update radar failed,error:%v", err)
			return err
		}
		err = db.GetDB().Model(&bean.EquipList{}).Where("sn = ?", devInfo.Sn).Update("parent_sn", devInfo.AgxSn).Error
		if err != nil {
			logger.Errorf("update Sfl200 radar failed,error:%v", err)
			return err
		}
	}
	return nil
}
func (c *EquipList) UpdateSfl200Status(ctx context.Context, req *client.UpdateSfl200StatusReq, res *client.UpdateSfl200StatusRes) error {
	logger.Info("Update Sfl200 Status:", req)
	//err := db.GetDB().Model(&bean.EquipList{}).Where(true).Update("parent_sn", "").Error
	//if err != nil {
	//	logger.Errorf("update All failed, error: %v", err)
	//	return err
	//}
	var err error
	for _, devInfo := range req.List {
		if devInfo.Sn != devInfo.Sfl200Sn {
			err = db.GetDB().Model(&bean.EquipList{}).Where("sn = ?", devInfo.Sn).Updates(map[string]interface{}{
				"parent_sn":   devInfo.Sfl200Sn,
				"parent_type": int(devInfo.Sfl200Type),
			}).Error
			if err != nil {
				logger.Errorf("update Sfl200 failed,error:%v", err)
				return err
			}
		}
	}
	return nil
}

func (c *EquipList) UpdateParentSn(ctx context.Context, parentSn string, parentType int, devList []*client.AgxDeviceSn) error {
	logger.Debugf("parentSn: %v, parentType: %v, devList: %v", parentSn, parentType, devList)
	field := map[string]interface{}{
		"parent_sn":   parentSn,
		"parent_type": parentType,
	}
	for _, devInfo := range devList {
		if devInfo.DevSn != parentSn {
			var equipModel bean.EquipList
			err := db.GetDB().Model(&bean.EquipList{}).Where("sn=?", devInfo.DevSn).First(&equipModel).Error
			if err != nil {
				logger.Errorf("UpdateParentSn sn : %s First err: %v", devInfo.DevSn, err)
				continue
			}
			if equipModel.ParentSn != parentSn || equipModel.ParentType != parentType {
				err = db.GetDB().Model(&bean.EquipList{}).Where("sn = ?", devInfo.DevSn).Updates(field).Error
				if err != nil {
					logger.Error("UpdateParentSn failed,error:", "err", err)
					return err
				}
			}
		}
	}
	return nil
}

func (c *EquipList) InsertSubDevices(ctx context.Context, parentSn string, parentType int, info *mavlink.AgxHeartbeatWithDeviceList) error {
	logger.Info("parentSn:", parentSn, " parentType: ", parentType, " info:", info)
	for i := 0; i < int(info.SubDeviceNum); i++ {
		sn := ByteToString(info.List[i].SN[:])
		if strings.Contains(sn, "ptz") {
			continue
		}
		var model bean.EquipList
		err := db.GetDB().Model(&bean.EquipList{}).Where("sn = ?", sn).First(&model).Error
		if err != nil {
			if err == gorm.ErrRecordNotFound {
				ip := fmt.Sprintf("%d.%d.%d.%d", info.List[i].IP[0], info.List[i].IP[1], info.List[i].IP[2], info.List[i].IP[3])
				//中程雷达 IP：133.2.168.192
				if info.List[i].DeviceType == 8 {
					ip = fmt.Sprintf("%d.%d.%d.%d", info.List[i].IP[3], info.List[i].IP[2], info.List[i].IP[1], info.List[i].IP[0])
				}
				equipModel := bean.EquipList{
					Etype:        common.SubDevTYpeToEtypeMap[info.List[i].DeviceType],
					Ip:           ip,
					CrtTime:      utils.ParseTimeToString(time.Now()),
					UpdateTime:   utils.ParseTimeToString(time.Now()),
					Sn:           sn,
					IsEnable:     common.DeviceEnable,
					IsOnline:     common.DevOnline,
					ParentSn:     parentSn,
					ParentType:   parentType,
					IsIntegrated: 0,
				}
				equipModel.Name = common.GetDevNameFromEtype(equipModel.Etype, 0) + "#" + c.GenerateUniqueNumber(ctx, equipModel.Etype, 0)
				err := db.GetDB().Model(&bean.EquipList{}).Create(&equipModel).Error
				if err != nil {
					logger.Errorf("InsertSubDevices Create err", err)
					return err
				}
			}
			logger.Errorf("InsertSubDevices First err", err)
			return err
		}
		if model.ParentSn != parentSn || model.ParentType != parentType {
			field := map[string]interface{}{
				"parent_sn":   parentSn,
				"parent_type": parentType,
			}
			err = db.GetDB().Model(&bean.EquipList{}).Where("sn = ?", sn).Updates(field).Error
			if err != nil {
				logger.Error("InsertSubDevices Updates error:", "err", err)
				return err
			}
		}
	}
	return nil
}

func (c *EquipList) DeleteSubDevices(ctx context.Context, parentSn string) error {
	field := map[string]interface{}{
		"parent_sn":   "",
		"parent_type": 0,
	}
	err := db.GetDB().Model(&bean.EquipList{}).Where("parent_sn = ?", parentSn).Updates(field).Error
	if err != nil {
		logger.Errorf("DeleteSubDevices Updates err", err)
	}
	return err
}

func (c *EquipList) UpdateSfl200ParentSn(ctx context.Context, req *client.UpdateSfl200ParentSnReq, res *client.UpdateSfl200ParentSnRes) error {
	logger.Info("Update Sfl200 Status:", req)
	field := map[string]interface{}{
		"parent_sn":   "",
		"parent_type": 0,
	}
	err := db.GetDB().Model(&bean.EquipList{}).Where("parent_sn = ?", req.Sfl200Sn).Updates(field).Error
	if err != nil {
		logger.Errorf("update All failed, error: %v", err)
		return err
	}
	return nil
}

func (c *EquipList) InitUpdateSfl200ParentSn(ctx context.Context, req *client.UpdateSfl200ParentSnReq, res *client.UpdateSfl200ParentSnRes) error {
	logger.Info("Update Sfl200 Status:", req)
	err := db.GetDB().Model(&bean.EquipList{}).Where("1 = 1").Updates(map[string]interface{}{"parent_sn": "", "parent_type": 0}).Error
	if err != nil {
		logger.Errorf("update All failed, error: %v", err)
		return err
	}
	return nil
}

func (c *EquipList) UpsertBySnAndEType(ctx context.Context, req *client.UpsertBySnAndETypeReq, res *client.UpsertBySnAndETypeRes) error {
	var model bean.EquipList
	err := db.GetDB().Where("sn = ? and etype = ?", req.Sn, req.EType).First(&model).Error
	if err != nil {
		if err == gorm.ErrRecordNotFound {
			err := db.GetDB().Create(&bean.EquipList{
				Sn:         req.Sn,
				ScanRadius: int(req.ScanRadius),
				Etype:      req.EType,
			}).Error
			if err != nil {
				logger.Errorf("UpsertBySnAndEType create equip list error:%v", err)
				return err
			}
			return nil
		}
		return err
	}

	model.ScanRadius = int(req.ScanRadius)
	err = db.GetDB().Model(&bean.EquipList{}).Where("sn = ? and etype = ?", req.Sn, req.EType).Updates(&model).Error
	if err != nil {
		logger.Errorf("UpsertBySnAndEType update failed,error:%v", err)
		return err
	}
	return nil
}

func (c *EquipList) QueryBySnAndEType(ctx context.Context, req *client.QueryBySnAndETypeReq, res *client.QueryBySnAndETypeRes) error {
	var model bean.EquipList
	err := db.GetDB().Where("sn = ? and etype = ?", req.Sn, req.EType).First(&model).Error
	if err != nil {
		logger.Errorf("QueryBySnAndEType err: %v", err)
		return err
	}
	res.ScanRadius = int32(model.ScanRadius)
	return nil
}

func (c *EquipList) ListByEType(ctx context.Context, req *client.EquipListByETypeReq, res *client.EquipListRes) error {
	var list []*bean.EquipList
	err := db.GetDB().Model(&bean.EquipList{}).Where("etype = ?", req.EType).Find(&list).Error
	if err != nil {
		return errors.New("query list failed")
	}
	for _, v := range list {
		var model client.List
		c.generateRes(&model, *v)
		if v.Sn == "" {
			continue
		}
		res.Equips = append(res.Equips, &model)
	}
	return nil
}

var (
	numbers []int
	numMap  sync.Map //保存eType和随机数关系
	mutex   sync.Mutex
)

func init() {
	numbers = make([]int, 0)
	for i := 0; i < 900; i++ {
		numbers = append(numbers, i+100)
	}
}

func (c *EquipList) GenerateUniqueNumber(ctx context.Context, eType string, subDevType int64) string {
	res := &client.EquipListRes{}
	numStr := fmt.Sprintf("%03d", rand.Intn(900)+100)
	if err := c.ListByEType(ctx, &client.EquipListByETypeReq{EType: eType, SubDevType: subDevType}, res); err != nil {
		logger.Errorf("GenerateUniqueNumber error: %v", err)
		return numStr
	}
	if len(res.Equips) > 0 {
		for i := range res.Equips {
			nameArr := strings.Split(res.Equips[i].Name, "#")
			if len(nameArr) != 2 {
				logger.Errorf("GenerateUniqueNumber error: %v", res.Equips[i].Name)
			} else {
				if _, ok := numMap.Load(nameArr[1]); !ok {
					numMap.Store(nameArr[1], true)
				}
			}
		}
	}

	rand.Seed(time.Now().UnixNano())

	rand.Shuffle(len(numbers), func(i, j int) {
		numbers[i], numbers[j] = numbers[j], numbers[i]
	})

	mutex.Lock()
	defer mutex.Unlock()
	for _, num := range numbers {
		sNum := fmt.Sprintf("%03d", num)
		_, ok := numMap.Load(sNum)
		if !ok {
			numMap.Store(sNum, true)
			numStr = sNum
			break
		}
	}
	return numStr
}

func (c *EquipList) First(sn string) (*bean.EquipList, error) {
	var equip bean.EquipList
	err := db.GetDB().Model(&bean.EquipList{}).Where("sn = ?", sn).First(&equip).Error
	if err != nil {
		return nil, err
	}
	return &equip, nil
}

func (c *EquipList) UpdateBySn(sn string, field map[string]interface{}) error {
	_, err := c.First(sn)
	if err != nil {
		logger.Errorf("UpdateBySn First failed,error:%v", err)
		return err
	}
	err = db.GetDB().Model(&bean.EquipList{}).Where("sn = ?", sn).Updates(field).Error
	if err != nil {
		logger.Errorf("update failed,error:%v", err)
		return err
	}
	return nil
}

func (c *EquipList) FindByParentSn(parentSn string) ([]*bean.EquipList, error) {
	equipList := make([]*bean.EquipList, 0)
	err := db.GetDB().Model(&bean.EquipList{}).Where("parent_sn = ?", parentSn).Find(&equipList).Error
	if err != nil {
		return nil, errors.New("find equipList failed")
	}
	return equipList, nil
}

package handler

import (
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"context"
	"fmt"
	"testing"

	"go.uber.org/atomic"

	"adasgitlab.autel.com/tools/cuav_server/proto/client"
)

func TestBuildDeviceObj(t *testing.T) {
	{
		// 设备不在线
		sn := "abc123123——not-exist"
		y1, err := GetOnLineDev[*TracerGun](sn, common.DEV_TracerGun)
		if err != nil {
			t.Logf(" err: %v", err)
		} else {
			t.Logf("dev: %v, err: %v", y1.Sn, err)
		}
	}

	{
		//设备在线：
		sn := "abc123123"
		cacheKey := fmt.Sprintf("%d_%s", common.DEV_TracerGun, sn)
		DevStatusMap.Store(cacheKey, &Device{
			Sn: sn,
		})
		y1, err := GetOnLineDev[*TracerGun](sn, common.DEV_TracerGun)
		if err != nil {
			t.Logf(" err: %v", err)
		} else {
			t.Logf("sn online dev: %v", y1.Sn)
		}
	}

}
func TestRadarSetMask(t *testing.T) {
	req := &client.RadarSetMaskRequest{
		Sn: "SDH100B00Q155028\n",
	}
	order := atomic.NewUint32(1).Load()
	var num uint32 = 0
	name := "筛选层#0"
	var rangeStart float32 = 200
	var rangeEnd float32 = 400
	var aziStart float32 = 10
	var aziEnd float32 = 20
	var eleStart float32 = 10
	var eleEnd float32 = 20
	var higStart float32 = 200
	var higEnd float32 = 400
	var vStart float32 = 10
	var vEnd float32 = 90
	var rcsStart float32 = 20
	var rcsEnd float32 = 60

	var num2 uint32 = 1
	name2 := "筛选层#1"
	var rangeStart2 float32 = 300
	var rangeEnd2 float32 = 500
	var aziStart2 float32 = 10
	var aziEnd2 float32 = 20
	var eleStart2 float32 = 10
	var eleEnd2 float32 = 20
	var higStart2 float32 = 500
	var higEnd2 float32 = 1000
	var vStart2 float32 = 10
	var vEnd2 float32 = 90
	var rcsStart2 float32 = 20
	var rcsEnd2 float32 = 60

	req.ItemMasks = []*client.RadarMaskInfo{
		{
			Order:          &order,
			Number:         &num,
			RangeStart:     &rangeStart,
			RangeEnd:       &rangeEnd,
			AzimuthStart:   &aziStart,
			AzimuthEnd:     &aziEnd,
			ElevationStart: &eleStart,
			ElevationEnd:   &eleEnd,
			VelocityStart:  &vStart,
			VelocityEnd:    &vEnd,
			RcsStart:       &rcsStart,
			RcsEnd:         &rcsEnd,
			Name:           &name,
			Classification: []int32{6, 4, 2, 1},
			HeightStart:    &higStart,
			HeightEnd:      &higEnd,
		},
		{
			Order:          &order,
			Number:         &num2,
			RangeStart:     &rangeStart2,
			RangeEnd:       &rangeEnd2,
			AzimuthStart:   &aziStart2,
			AzimuthEnd:     &aziEnd2,
			ElevationStart: &eleStart2,
			ElevationEnd:   &eleEnd2,
			VelocityStart:  &vStart2,
			VelocityEnd:    &vEnd2,
			RcsStart:       &rcsStart2,
			RcsEnd:         &rcsEnd2,
			Name:           &name2,
			Classification: []int32{6, 1, 2},
			HeightStart:    &higStart2,
			HeightEnd:      &higEnd2,
		},
	}

	rsp := &client.RadarSetMaskResponse{}
	err := NewDeviceCenter().RadarSetMask(context.Background(), req, rsp)
	if err != nil {
		t.Logf("RadarSetMask err: %v", err)
	}
	t.Logf("RadarSetMask rsp: %+v", rsp)
}

func TestRadarGetMask(t *testing.T) {
	req := &client.RadarGetMaskRequest{
		Sn: "SDH100B00Q155028\\n",
	}
	rsp := &client.RadarGetMaskResponse{}
	err := NewDeviceCenter().RadarGetMask(context.Background(), req, rsp)
	if err != nil {
		t.Logf("RadarGetMask err: %v", err)
	}
	t.Logf("RadarGetMask rsp: %+v", rsp)
}

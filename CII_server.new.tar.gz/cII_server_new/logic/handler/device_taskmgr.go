package handler

import (
	"errors"
	"fmt"
	"sync"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"

	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	uuid "github.com/satori/go.uuid"
)

var (
	ErrNetWorkDisConn = "network disconnected"
)

type WaitTaskManager struct {
	TaskType   int           //任务类型
	NeedRepeat bool          // 是否需要重复
	TimeOut    time.Duration // 超时时间
	Tasks      []*WaitTask   //
	Mx         sync.Mutex
}

type WaitTaskRetryEvent func() error
type WaitTaskEndEvent func(param interface{})
type WaitTask struct {
	TaskId    string      //超时删除任务id的时候用
	Completed bool        // 状态
	Result    interface{} // 结果
	Err       error
	Ch        chan int
	RetryFunc WaitTaskRetryEvent
	EndFunc   WaitTaskEndEvent
}

func NewWaitTaskManager(taskType int, needRepeat bool, timeout time.Duration) *WaitTaskManager {
	if timeout <= 0 {
		timeout = time.Millisecond * 15000
	}
	return &WaitTaskManager{
		TaskType:   taskType,
		NeedRepeat: needRepeat,
		TimeOut:    timeout,
		Tasks:      make([]*WaitTask, 0),
	}
}

func (tm *WaitTaskManager) addTask(retryFunc WaitTaskRetryEvent, endFunc WaitTaskEndEvent) (*WaitTask, error) {
	tm.Mx.Lock()
	defer tm.Mx.Unlock()
	//同一个类型允许并发操作
	//if len(tm.Tasks) > 0 {
	//	return nil, errors.New("有正在等待的任务")
	//}
	t := &WaitTask{
		TaskId:    uuid.NewV4().String(),
		Ch:        make(chan int),
		RetryFunc: retryFunc,
		EndFunc:   endFunc,
	}
	tm.Tasks = append(tm.Tasks, t)
	return t, nil
}

func (tm *WaitTaskManager) AddTask(retryFunc WaitTaskRetryEvent, endFunc WaitTaskEndEvent) *WaitTask {
	tm.Mx.Lock()
	defer tm.Mx.Unlock()
	t := &WaitTask{
		TaskId:    uuid.NewV4().String(),
		Ch:        make(chan int),
		RetryFunc: retryFunc,
		EndFunc:   endFunc,
	}
	logger.Infof("add task id: %v", t.TaskId)
	tm.Tasks = append(tm.Tasks, t)
	return t
}

func (tm *WaitTaskManager) CompletedTask(result interface{}, err error) {
	tm.Mx.Lock()
	defer tm.Mx.Unlock()
	waitLen := len(tm.Tasks)
	if waitLen <= 0 {
		logger.Infof("not has wait len")
		return
	}
	//完成时取最先加入的一个等待任务作响应，同时清除该等待任务
	wt := tm.Tasks[0]
	if wt != nil {
		wt.Result = result
		wt.Err = err
		//xurong: 删除wt.Ch <- 1。如果没有人读取channel，会有阻塞风险
		//wt.Ch <- 1
		close(wt.Ch)
		logger.Infof("notify task completed, task id: %v", wt.TaskId)
		tm.Tasks = tm.Tasks[1:len(tm.Tasks)]
	} else {
		logger.Infof("task is nil")
	}
}

func (tm *WaitTaskManager) deleteTask(taskId string) {
	defer tm.Mx.Unlock()
	tm.Mx.Lock()
	waitLen := len(tm.Tasks)
	if waitLen <= 0 {
		return
	}
	//并发任务时的清除方式，如果能确保顺序（加锁或其他），也可以这么做
	//tm.Tasks = tm.Tasks[1:len(tm.Tasks)]
	tmp := make([]*WaitTask, 0)
	for index, _ := range tm.Tasks {
		if tm.Tasks[index].TaskId != taskId {
			tmp = append(tmp, tm.Tasks[index])
		} else {
			logger.Infof("to omit task id: %v", taskId)
		}
	}
	tm.Tasks = tmp
}

// DeleteTask 删除task
func (tm *WaitTaskManager) DeleteTask(taskId string) {
	tm.deleteTask(taskId)
}

func (tm *WaitTaskManager) Wait() (interface{}, error) {
	t, err := tm.addTask(nil, nil)
	if err != nil {
		return nil, err
	}
	ticker := time.NewTicker(tm.TimeOut)
	defer ticker.Stop()
	for {
		select {
		case <-ticker.C:
			tm.deleteTask(t.TaskId)
			logger.Infof("time is out")
			return nil, errors.New("wait time out")
		case <-t.Ch:
			logger.Infof("recv notify for task")
			return t.Result, t.Err
		}
	}
}

func (tm *WaitTaskManager) WaitTask(t *WaitTask) (interface{}, error) {
	ticker := time.NewTicker(tm.TimeOut)
	defer ticker.Stop()
	for {
		select {
		case <-ticker.C:
			tm.deleteTask(t.TaskId)
			return nil, fmt.Errorf("wait time out, taskId: %v", t.TaskId)
		case <-t.Ch:
			logger.Infof("receive task notify: %v, TaskType: %v, taskId: %v", t.Result, tm.TaskType, t.TaskId)
			return t.Result, t.Err
		}
	}
}

func (tm *WaitTaskManager) CheckError(err error, dev *Device, checkTime time.Duration) error {
	if dev.Status == common.DevOffline {
		return errors.New(ErrNetWorkDisConn)
	}
	dr := time.Millisecond * 500
	for checkTime-dr >= 0 {
		checkTime = checkTime - dr
		time.Sleep(dr)
		if dev.Status == common.DevOffline {
			return errors.New(ErrNetWorkDisConn)
		}
	}
	return err
}

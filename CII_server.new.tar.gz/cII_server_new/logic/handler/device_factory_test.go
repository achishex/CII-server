package handler

import (
	"reflect"
	"testing"

	"adasgitlab.autel.com/tools/cuav_server/entity/common"
)

func TestMaxVersion(t *testing.T) {
	type args struct {
		versions []string
	}
	tests := []struct {
		name string
		args args
		want string
	}{
		{
			name: "Test case 1",
			args: args{
				versions: []string{"1.0.0.3", "1.0.0.4"},
			},
			want: "1.0.0.4",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := MaxVersion(tt.args.versions); got != tt.want {
				t.Errorf("MaxVersion() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestCompareVersionsNum(t *testing.T) {
	type args struct {
		version1 []int
		version2 []int
	}
	tests := []struct {
		name string
		args args
		want int
	}{
		{
			name: "Equal versions",
			args: args{
				version1: []int{1, 2, 3},
				version2: []int{1, 2, 3},
			},
			want: 0,
		},
		{
			name: "Version1 is smaller",
			args: args{
				version1: []int{1, 2, 3},
				version2: []int{1, 2, 4},
			},
			want: -1,
		},
		{
			name: "Version1 is greater",
			args: args{
				version1: []int{1, 2, 4},
				version2: []int{1, 2, 3},
			},
			want: 1,
		},
		{
			name: "Version1 is longer",
			args: args{
				version1: []int{1, 2, 3, 4},
				version2: []int{1, 2, 3},
			},
			want: 1,
		},
		{
			name: "Version2 is longer",
			args: args{
				version1: []int{1, 2, 3},
				version2: []int{1, 2, 3, 4},
			},
			want: -1,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := CompareVersionsNum(tt.args.version1, tt.args.version2); got != tt.want {
				t.Errorf("CompareVersionsNum() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestParseVersionNum(t *testing.T) {
	type args struct {
		versionStr string
	}
	tests := []struct {
		name string
		args args
		want []int
	}{
		{
			name: "Single digit version",
			args: args{
				versionStr: "1",
			},
			want: []int{1},
		},
		{
			name: "Multi-digit version",
			args: args{
				versionStr: "1.2.3",
			},
			want: []int{1, 2, 3},
		},
		{
			name: "Leading/trailing zeros",
			args: args{
				versionStr: "01.002.0003",
			},
			want: []int{1, 2, 3},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := ParseVersionNum(tt.args.versionStr); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("ParseVersionNum() = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_compareVersion(t *testing.T) {
	type args struct {
		version1 string
		version2 string
	}
	tests := []struct {
		name string
		args args
		want int
	}{
		{
			name: "Equal versions",
			args: args{
				version1: "1.2.3",
				version2: "1.2.3",
			},
			want: 0,
		},
		{
			name: "Version1 is greater",
			args: args{
				version1: "2.0",
				version2: "1.9",
			},
			want: 1,
		},
		{
			name: "Version2 is greater",
			args: args{
				version1: "1.8",
				version2: "1.10",
			},
			want: -2,
		},
		{
			name: "Different number of version parts",
			args: args{
				version1: "1.2.3",
				version2: "1.2",
			},
			want: 1,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := compareVersion(tt.args.version1, tt.args.version2); got != tt.want {
				t.Errorf("compareVersion() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestFindCacheDeviceAndType(t *testing.T) {
	DevStatusMap.Store("3_radar123", &Device{})
	type args struct {
		sn string
	}
	tests := []struct {
		name  string
		args  args
		want  *Device
		want1 common.DeviceType
	}{
		{
			name: "Case1",
			args: args{
				sn: "radar123",
			},
			want:  &Device{},
			want1: common.DEV_RADAR,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, got1 := FindCacheDeviceAndType(tt.args.sn)
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("FindCacheDeviceAndType() got = %v, want %v", got, tt.want)
			}
			if !reflect.DeepEqual(got1, tt.want1) {
				t.Errorf("FindCacheDeviceAndType() got1 = %v, want %v", got1, tt.want1)
			}
		})
	}
}

// type MockClient struct {
// }

// func (m *MockClient) DeleteWithSn(ctx context.Context, in *equiplist.DeleteWithSnReq, opts ...client.CallOption) (*equiplist.CrudRes, error) {
// 	return nil, nil
// }

// func TestAddSimulateDevice(t *testing.T) {
// 	test.LoggerMock()
// 	mq.InitMemoryBroker()
// 	DevStatusMap.Store("3_radar0000000000", &Device{})

// 	// mockClient := &MockClient{}
// 	// patches := gomonkey.NewPatches()
// 	// EquipClient = mockClient
// 	// defer patches.Reset()

// 	type args struct {
// 		status  int32
// 		msgtype int32
// 	}
// 	tests := []struct {
// 		name string
// 		args args
// 	}{
// 		{
// 			name: "Case1",
// 			args: args{
// 				status:  2,
// 				msgtype: 2,
// 			},
// 		},
// 	}
// 	for _, tt := range tests {
// 		t.Run(tt.name, func(t *testing.T) {
// 			AddSimulateDevice(tt.args.status, tt.args.msgtype)
// 		})
// 	}
// }

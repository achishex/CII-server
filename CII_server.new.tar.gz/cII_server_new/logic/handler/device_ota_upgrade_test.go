package handler

//func TestDeviceCenter_OtaRequestUpgrade(t *testing.T) {
//	test.LoggerMock()
//	mq.InitMemoryBroker()
//	r := &device.Radar{}
//	d := &device.DroneID{}
//	patches := gomonkey.NewPatches()
//	patches.ApplyFunc(ota.PathOrFileExists, func(string) (bool, error) {
//		return true, nil
//	})
//	patches.ApplyFunc(device.FindCacheDevice, func(sn string, deviceType common.DeviceType) *device.Device {
//		return &device.Device{}
//	})
//	patches.ApplyFunc(device.OtaSyncUpgradeStatus, func(sn string, cacheKey string) {
//		return
//	})
//	patches.ApplyMethod(reflect.TypeOf(r), "RadarResetSystem", func(_ *device.Radar, rq *pb.ResetSystemRequest) (int32, error) {
//		return 0, nil
//	})
//	patches.ApplyMethod(reflect.TypeOf(d), "TracerResetSystem", func(_ *device.DroneID, rq *pb.ResetSystemRequest) (int32, error) {
//		return 0, nil
//	})
//	defer patches.Reset()
//
//	type args struct {
//		ctx context.Context
//		req *pb.RequestUpgradeRequest
//		rsp *pb.RequestUpgradeResponse
//	}
//	tests := []struct {
//		name    string
//		e       *DeviceCenter
//		args    args
//		wantErr bool
//	}{
//		{
//			name: "Case1",
//			e:    &DeviceCenter{},
//			args: args{
//				ctx: context.Background(),
//				req: &pb.RequestUpgradeRequest{
//					DeviceType: 1,
//				},
//				rsp: &pb.RequestUpgradeResponse{},
//			},
//			wantErr: false,
//		},
//		{
//			name: "Case2",
//			e:    &DeviceCenter{},
//			args: args{
//				ctx: context.Background(),
//				req: &pb.RequestUpgradeRequest{
//					DeviceType: 2,
//				},
//				rsp: &pb.RequestUpgradeResponse{},
//			},
//			wantErr: false,
//		},
//		{
//			name: "Case3",
//			e:    &DeviceCenter{},
//			args: args{
//				ctx: context.Background(),
//				req: &pb.RequestUpgradeRequest{
//					DeviceType: 3,
//				},
//				rsp: &pb.RequestUpgradeResponse{},
//			},
//			wantErr: false,
//		},
//	}
//	for _, tt := range tests {
//		t.Run(tt.name, func(t *testing.T) {
//			e := &DeviceCenter{}
//			if err := e.OtaRequestUpgrade(tt.args.ctx, tt.args.req, tt.args.rsp); (err != nil) != tt.wantErr {
//				t.Errorf("DeviceCenter.OtaRequestUpgrade() error = %v, wantErr %v", err, tt.wantErr)
//			}
//		})
//	}
//}

// func TestDeviceCenter_radarUpgrade(t *testing.T) {
// 	test.LoggerMock()

// 	d := &DeviceCenter{}
// 	patches := gomonkey.NewPatches()
// 	patches.ApplyMethod(reflect.TypeOf(d), "radarLoopCheckIsInBootUpdateMod", func(_ *DeviceCenter, sn string, cacheKey string, deviceType common.DeviceType) (*device.Radar, bool) {
// 		return &device.Radar{}, true
// 	})
// 	patches.ApplyMethod(reflect.TypeOf(d), "radarSendPkgFile", func(_ *DeviceCenter, radar *device.Radar, pkgPathName string, cacheKey string, sn string) bool {
// 		return true
// 	})
// 	patches.ApplyMethod(reflect.TypeOf(d), "radarVerifyImage", func(_ *DeviceCenter, radar *device.Radar, cacheKey string, sn string) bool {
// 		return true
// 	})
// 	patches.ApplyMethod(reflect.TypeOf(d), "radarWriteUpdateData", func(_ *DeviceCenter, radar *device.Radar, cacheKey string, sn string) bool {
// 		return true
// 	})
// 	patches.ApplyMethod(reflect.TypeOf(d), "radarGetUpdateWriteStatus", func(_ *DeviceCenter, radar *device.Radar, cacheKey string, sn string) bool {
// 		return true
// 	})
// 	patches.ApplyMethod(reflect.TypeOf(d), "radarRunApp", func(_ *DeviceCenter, radar *device.Radar, cacheKey string, sn string) {
// 		return
// 	})
// 	defer patches.Reset()

// 	type args struct {
// 		sn          string
// 		cacheKey    string
// 		pkgPathName string
// 	}
// 	tests := []struct {
// 		name string
// 		e    *DeviceCenter
// 		args args
// 	}{
// 		{
// 			name: "Case1",
// 			e:    &DeviceCenter{},
// 			args: args{
// 				sn:          "radar1234",
// 				cacheKey:    "213435",
// 				pkgPathName: "",
// 			},
// 		},
// 	}
// 	for _, tt := range tests {
// 		t.Run(tt.name, func(t *testing.T) {
// 			e := &DeviceCenter{}
// 			e.radarUpgrade(tt.args.sn, tt.args.cacheKey, tt.args.pkgPathName)
// 		})
// 	}
// }

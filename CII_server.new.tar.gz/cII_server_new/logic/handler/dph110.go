package handler

import (
	"bytes"
	"context"
	"encoding/binary"
	"errors"
	"fmt"
	"io"
	"math"
	"net"
	"sync"
	"time"

	"adasgitlab.autel.com/tools/cuav_plugin/broker"
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"google.golang.org/protobuf/proto"
	"gorm.io/gorm"

	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/helper"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/proto/mavlink"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
)

const (
	magic           = 0x55AA //帧头
	magicLen        = 2      //帧头字节数
	magicLocEnd     = 2      //帧头结束位置
	msgIdLocEnd     = 4      //标识符结束位置
	seqLocEnd       = 6      //帧计数结束字节位置
	sourceIdLoc     = 6      //发送者id位置
	destIdLoc       = 7      //接收者id位置
	dataLenLocStart = 8      //帧内容长度起始字节位置
	dataLenLocEnd   = 12     //帧内容长度结束字节位置
	dataLen         = 4      //帧内容长度
	crcLen          = 1      //CRC 校验位长度
)

var (
	DPH110Conn sync.Map // 存储sn到conn的映射
)

type ControllerDPH110 struct {
	*Device
	DPHIp      string //一体机显示IP
	Sn         string //设备序列号
	DevVersion string //设备版本号
}

// DPHData 数据帧内容
type DPHData struct {
	Magic           uint16   //帧头
	MsgId           uint16   //标识符
	Seq             uint16   //帧计数
	SourceId        [1]uint8 //发送者id
	DestId          [1]uint8 //接收者id
	Length          uint32   //数据长度
	payload         []byte   //数据
	ProtocolId      [1]uint8 //协议标识
	ProtocolVersion [1]uint8 //协议版本号
	Reserved        [1]uint8 //备用
	CheckSum        [1]uint8 //校验和，除帧头外前面所有数据求和取最低字节
}

// DPHStateInfo 一体机状态数据帧内容
type DPHStateInfo struct {
	SysStatus             [1]uint8  //工作模式 0x00：待机 0x11：自检 0x22：搜索 0x33：调试 0x44: 跟踪 其他：待机
	WorkStatus            [1]uint8  //工作状态 一体机杂波建模状态： 0x11:杂波建模(未上报目标之前) 0x22:正常工作(开始上报目标)
	CommandExecStatus     [1]uint8  //命令执行情况 0x00：空闲（未收到新命令） 0x11：正在执行 0x22：执行成功 0x33：执行失败 其他，无效状态
	FaultType             [1]uint8  //故障类型 0x00：无故障 0x01：命令解析失败 0x02：命令无法执行 0x03：命令同步失败 其他，自定义故障
	ReceiveCheckResult    uint16    //接收机检查结果，低6位表示正确计数，每次收到命令清零
	OfficeCheckResult     uint16    //信处检查结果，低6位表示正确计数，每次收到命令清零
	FiberLinkStatus       [1]uint8  //光纤链路状态 0：表示未建立链路 1：表示已经建立链路
	GPUCheckResult        [1]uint8  //GPU检查结果 0：表示异常 1：表示正常
	PCIeCheckResult       [1]uint8  //PCIe检查结果 0：表示异常 1：表示正常
	CuringParamReadStatus [1]uint8  //固化参数读取状态 0：表示异常 1：表示正常
	Sn                    [32]uint8 //GPU_SN_CODE
	RadarType             [32]uint8 //雷达类型
	StandbyCounter        uint32    //待机计数器 一体机开始待机后，该计数器即开始从0开始递增，直到退出待机命令；初始化为0； (利用该标志判断一体机进入待机时间，待机超过1个小时，搜索命令里不再发送加载杂波标志)
	ClutterSLStatus       [1]uint8  //杂波图数据SL状态 0x00:空闲 0x11:存储完毕 0x22:加载完毕
	CPUCoreCnt            [1]uint8
	CPUTemperature        [12]uint8  //CPU温度
	GPUTemperature        [1]uint8   //GPU温度
	Version               [64]uint8  //一体机版本号
	GPUDisplayInfo        [256]uint8 //GPU显示信息
}

// DPHTargetData 一体机目标数据帧内容
type DPHTargetData struct {
	CurrentServoAngle   uint32       //当前伺服角度
	ServoScanCycleCount uint32       //伺服扫描周期计数
	FrameID             uint32       //脉组计数
	TrackObjNum         uint32       //目标个数
	ItemList            []TargetItem //目标信息
}

// TargetItem 单个目标信息
type TargetItem struct {
	TargetTrackDeleteFlag       uint16     //目标航迹删除标识 0x00：航迹不删除 0x01：航迹删除
	Id                          uint16     //数据编号（航迹编号）
	ForCastFrameNum             uint16     //目标丢失计数
	TargetLossReason            uint16     //目标丢失原因
	TargetUpdateTime            uint32     //目标更新时间（脉组计数）
	TargetMeasuredDoppler       uint16     //目标的实测多普勒单元数
	TargetMeasuredDistance      uint16     //目标的实测距离单元数
	Mag                         float32    //目标能量
	Snr                         float32    //目标信杂比
	Velocity                    float32    //目标的实测速度
	Range                       float32    //目标的实测距离
	Azimuth                     float32    //目标的实测方位
	Elevation                   float32    //目标的实测俯仰
	Height                      float32    //目标的实测高度
	AzimuthDeviation            float32    //方位角误差
	ElevationDeviation          float32    //俯仰角误差
	PredictedSpeed              float32    //目标的预测速度
	PredictedDistance           float32    //目标的预测距离
	PredictedAzimuth            float32    //目标的预测方位
	PredictedElevation          float32    //目标的预测俯仰
	PredictedHeight             float32    //目标的预测高度
	FilterSpeed                 float32    //目标的滤波速度
	FilteredDistance            float32    //目标的滤波距离
	FilteredAzimuth             float32    //目标的滤波方位
	FilteredElevation           float32    //目标的滤波俯仰
	FilteredHeight              float32    //目标的滤波高度
	FilteredAverageSpeed        float32    //目标的滤波平均速度
	FilteredAverageAcceleration float32    //目标的滤波平均加速度
	EnvelopePoints              uint16     //该目标的包络点数
	TrackPriority               uint16     //该目标航迹优先级
	AssociationNum              uint32     //该目标航迹中的点数
	Classification              [1]uint8   //该目标航迹类型 0x00:未知 0x01:飞行物 0x02:船只 0x03:地面目标 0x04:人 0x05:车
	PitchBeamNumber             uint16     //该目标俯仰波束号
	NormalizedEnergy            float32    //归一化能量
	Reserved1                   [8]float32 //备用
	Reserved2                   [25]uint8  //备用
}

// DPHTracerData 一体机跟踪目标数据帧内容
type DPHTracerData struct {
	ServoAngle                  uint32     //伺服角度，数字范围：0~3600 精度：0.1度
	FrameID                     uint32     //脉组计数
	TrackDeletionFlag           uint16     //跟踪航迹删除标识 0x00：航迹不删除 0x01：航迹删除
	Id                          uint16     //目标编号
	ForcastFrameNum             uint16     //目标丢失计数
	TargetLossReason            uint16     //目标丢失原因
	TargetUpdateTime            uint32     //目标更新时间（脉组计数）
	TargetMeasuredDoppler       uint16     //目标的实测多普勒单元数
	TargetMeasuredDistance      uint16     //目标的实测距离单元数
	Mag                         float32    //目标能量
	Snr                         float32    //目标信杂比
	Velocity                    float32    //目标的实测速度
	Range                       float32    //目标的实测距离
	Azimuth                     float32    //目标的实测方位
	Elevation                   float32    //目标的实测俯仰
	Height                      float32    //目标的实测高度
	AzimuthDeviation            float32    //方位角误差
	ElevationDeviation          float32    //俯仰角误差
	PredictedSpeed              float32    //目标的预测速度
	PredictedDistance           float32    //目标的预测距离
	PredictedAzimuth            float32    //目标的预测方位
	PredictedElevation          float32    //目标的预测俯仰
	PredictedHeight             float32    //目标的预测高度
	FilterSpeed                 float32    //目标的滤波速度
	FilteredDistance            float32    //目标的滤波距离
	FilteredAzimuth             float32    //目标的滤波方位
	FilteredElevation           float32    //目标的滤波俯仰
	FilteredHeight              float32    //目标的滤波高度
	FilteredAverageSpeed        float32    //目标的滤波平均速度
	FilteredAverageAcceleration float32    //目标的滤波平均加速度
	AssociationNum              uint32     //该目标航迹中的点数
	Classification              [1]uint8   //该目标航迹类型 0x00:未知 0x01:飞行物 0x02:船只 0x03:地面目标 0x04:人 0x05:车
	PitchBeamNumber             uint16     //该目标俯仰波束号
	NormalizedEnergy            float32    //归一化能量
	Reserved1                   [8]float32 //备用
	Reserved2                   [90]uint8  //备用
}

// RadarFrontendStateInfo 雷达前端状态数据帧内容
type RadarFrontendStateInfo struct {
	WorkMode                 [1]uint8  //工作模式 0x00：待机 0x11：搜索 0x22：接收机自检 0x33：信处自检 0x44:跟踪 其他：待机
	WorkStatus               [1]uint8  //工作状态
	CommandExecStatus        [1]uint8  //命令执行情况 0x00：空闲（未收到新命令） 0x11：正在执行 0x22：执行成功 0x33：执行失败 其他，无效状态
	FaultType                [1]uint8  //故障类型 0x00：无故障 0x01：命令解析失败 0x02：命令无法执行 其他，自定义故障 其他，有故障
	SilentZoneEnableStatus   uint16    //雷达静默区使能状态 0x00：不使能 0x11：使能 其他，不使能
	SilentZoneStartAngle     uint16    //雷达静默区起始角 0~360°，精度0.1°，其他，无效状态
	SilentZoneEndAngle       uint16    //雷达静默区结束始角 0~360°，精度0.1°，其他，无效状态
	Azimuth                  uint16    //伺服角度 0~360°，精度0.1°，其他，无效状态
	TrackTwsTasFlag          [1]uint8  //伺服模式 0xFF：空闲 0x11：指向 0x22：扇扫 0x33：环扫 0x44：跟踪
	ServoStatus              [1]uint8  //伺服状态 Bit0:编码器通信状态，1表示正常，0表示异常；Bit1:驱动器通信状态，1表示正常，0表示异常； Bit2:运转是否超时，1表示超时，0表示未超时；Bit3:收到的指令是否有效，1表示有效，0表示无效；其他保持为0
	ServoCommunicationStatus [1]uint8  //伺服通信状态 FPGA与伺服通信状态 0：异常 1：正常
	PitchPointingMark        [1]uint8  //俯仰指向标志 0:  多个波束 1：单个波束
	PitchAngleNum            [1]uint8  //俯仰角个数
	Prf                      [1]uint8  //0.1kHz
	Reserved                 [2]uint8  //备用
	NarrowTransFreq          uint16    //窄脉冲发射频率 0~16对应15.80~16.2GHz，其他，无效状态
	BroadTransFreq           uint16    //宽脉冲发射频率
	FreqControlVal           [1]uint8  //频综衰减控制值 0x1F：不衰减
	AGCCode                  [1]uint8  //AGC码值 低6位有效，由DSP写入的下变频中AGC起控码值
	AGCControlFlag           [1]uint8  //AGC控制标志 最低位有效， 0：由FPGA自主起控AGC 1：由DSP写入AGC起控码值
	STCEnableControlFlag     [1]uint8  //STC使能控制标志 0：不使能 1：使能
	FanStatus                [1]uint8  //风扇状态
	FreqStatus               [1]uint8  //频综状态
	TRStatus                 uint32    //TR状态
	TRTemperature            [8]uint8  //TR温度
	SRIOLinkStatus           [1]uint8  //SRIO链路状态
	FiberLinkStatus          [1]uint8  //光纤链路状态
	QDRCheckResult           [1]uint8  //QDR检查结果状态、信处与波控同步串口通信检查结果
	CuringParamReadStatus    [1]uint8  //固化参数读取状态
	Voltage28V               uint16    //28V电源电压
	Current28V               uint16    //28V电源电流
	Voltage5V                uint16    //5V电源电压
	Current5V                uint16    //5V电源电流
	Voltage55V               uint16    //5.5V电源电压
	Current55V               uint16    //5.5V电源电流
	Voltage12V               uint16    //12V电源电压
	Current12V               uint16    //12V电源电流
	ServoCyclesNum           uint32    //当前伺服周期数
	FPGACodeVersion          [32]uint8 //FPGA代码版本号
	TRCurrent                [8]uint8  //TR电流
	CustomInfo               [88]uint8 //自定义信息
}

type dronePoint struct {
	X float64
	Y float64
	Z float64
}

// isMavLink 判断包头首字节是否mavlink包
func isMavLink(first []byte) bool {
	return binary.LittleEndian.Uint16(first[:]) == magic
}

// isCheckSumEqual 校验校验和
func isCheckSumEqual(buff []byte, checkSum [1]uint8) bool {
	check := uint8(0)
	for i := magicLen; i < len(buff)-crcLen; i++ {
		check += buff[i]
	}
	logger.Debugf("checkSum:%d, check:%d", checkSum[0], check)
	return checkSum == [1]uint8{check & 0xFF}
}

// Decode 解码
func Decode(buff []byte) (*DPHData, error) {
	if buff == nil || len(buff) < magicLen {
		return nil, errors.New("buff empty")
	}
	if !isMavLink(buff[:magicLocEnd]) {
		return nil, errors.New("not mavlink")
	}
	packet := &DPHData{}
	packet.Magic = binary.LittleEndian.Uint16(buff[:magicLocEnd])
	packet.MsgId = binary.LittleEndian.Uint16(buff[magicLocEnd:msgIdLocEnd])
	packet.Seq = binary.LittleEndian.Uint16(buff[msgIdLocEnd:seqLocEnd])
	packet.SourceId = [1]uint8{buff[sourceIdLoc]}
	packet.DestId = [1]uint8{buff[destIdLoc]}
	packet.Length = binary.LittleEndian.Uint32(buff[dataLenLocStart:dataLenLocEnd])
	packet.payload = make([]byte, packet.Length)
	copy(packet.payload, buff[dataLenLocEnd:len(buff)-4])
	packet.ProtocolId = [1]uint8{buff[len(buff)-4]}
	packet.ProtocolVersion = [1]uint8{buff[len(buff)-3]}
	packet.Reserved = [1]uint8{buff[len(buff)-2]}
	packet.CheckSum = [1]uint8{buff[len(buff)-1]}

	//if !isCheckSumEqual(buff, packet.CheckSum) {
	//	return nil, errors.New("check sum not equal")
	//}
	return packet, nil
}

func NewControllerDPH110() *ControllerDPH110 {
	return &ControllerDPH110{
		Device: &Device{},
	}
}

func (d *ControllerDPH110) Handle(ctx context.Context, devIP string, pConn *net.UDPConn) {
	//defer dConn.Close()
	defer pConn.Close()
	d.DPHIp = devIP

	defer func() {
		if r := recover(); r != nil {
			logger.Errorf("Recovered in %v", r)
		}
	}()
	if /*dConn == nil ||*/ pConn == nil {
		logger.Errorf("dConn or pConn is nil")
		return
	}

	for {
		buff := make([]byte, 1048576)
		n, addr, err := pConn.ReadFromUDP(buff)
		if err != nil {
			if err == io.EOF {
				logger.Errorf("ReadFromUDP receive close: %v", addr)
			} else {
				logger.Errorf("ReadFromUDP error: %v", err)
			}
			//dConn.Close()
			pConn.Close()
			return
		}
		logger.Debugf("receive %d bytes from %s", n, addr.String())
		if n <= 0 {
			continue
		}
		data, err := Decode(buff[:n])
		if err != nil {
			logger.Errorf("decode error: %v", err)
			continue
		}
		logger.Debugf("receive data: %+v", data)
		buffer := &bytes.Buffer{}
		if err = binary.Write(buffer, binary.LittleEndian, data.payload); err != nil {
			logger.Errorf("binary.Write error: %v", err)
			continue
		}

		switch data.MsgId {
		case mavlink.StatusMsgType:
			stateInfo := DPHStateInfo{}

			if err = binary.Read(buffer, binary.LittleEndian, &stateInfo); err != nil {
				logger.Errorf("DPHStateInfo binary.Read error: %v", err)
				continue
			}
			logger.Debugf("DPHStateInfo: %+v", stateInfo)
			d.Sn = ByteToString(stateInfo.Sn[:])
			d.DevVersion = ByteToString(stateInfo.Version[:])
			updateStatus(d.Sn, d.DevVersion)
			setDPH110Conn(d.Sn, pConn)
			//状态上报
			isOnline := helper.TranBaseType[int32, int](common.DevOnline)
			equipModel, err := GetEquipBySn(d.Sn)
			name := d.Sn
			if equipModel != nil && equipModel.Name != "" {
				name = equipModel.Name
			}
			heartInfo := &client.RadarStatusInfo{
				Header: &client.EquipmentMessageBoxEntity{
					Name:      name,
					Sn:        d.Sn,
					EquipType: int32(common.DEV_DPH110),
					MsgType:   mavlink.StatusMsgType,
				},
				Data: &client.RadarStatusEntity{
					IsOnline:   &isOnline,
					Ip:         d.DPHIp,
					SerialNum:  d.Sn,
					SysStatus:  int32(stateInfo.SysStatus[0]),
					DphVersion: ByteToString(stateInfo.Version[:]),
				},
			}
			if err == nil {
				heartInfo.Header.IsIntegrated = equipModel.IsIntegrated
				heartInfo.Header.ParentSn = equipModel.ParentSn
				heartInfo.Header.ParentType = int32(equipModel.ParentType)
			}
			buData, err := proto.Marshal(heartInfo)
			if err != nil {
				logger.Error("DPHStateInfo Marshal err %v", err)
				continue
			}
			report := &client.ClientReport{
				MsgType: common.ClientMsgIDDPH110HeartBeat,
				Data:    buData,
			}
			out, err := proto.Marshal(report)
			if err != nil {
				logger.Errorf("DPHStateInfo ClientReport Marshal err %v", err)
				continue
			}
			_ = mq.DPH110Broker.Publish(mq.DPH110Topic, broker.NewMessage(out))
			logger.Debugf("DPH110 status report: %+v", heartInfo)
			//雷达姿态信息上报
			go d.reportDPHPosture()

		case mavlink.TargetMsgType:
			targetInfo, err := d.deserializeTrack(data.payload)
			if err != nil {
				logger.Errorf("DPHTargetData deserializeTrack error: %v")
				continue
			}

			logger.Debugf("DPHTargetData target info: %+v", targetInfo)
			updateStatus(d.Sn, d.DevVersion)
			if len(targetInfo.ItemList) <= 0 {
				logger.Debug("no target info")
			}

			equipModel, err := GetEquipBySn(d.Sn)
			name := d.Sn
			if equipModel != nil && equipModel.Name != "" {
				name = equipModel.Name
			}
			dphTargetData := &client.DPHTTargetInfo{
				Header: &client.EquipmentMessageBoxEntity{
					Name:      name,
					Sn:        d.Sn,
					EquipType: int32(common.DEV_DPH110),
					MsgType:   mavlink.TargetMsgType,
				},
				Data: &client.DPHTargetData{
					CurrentServoAngle:   float32(float64(targetInfo.CurrentServoAngle) * 0.01),
					ServoScanCycleCount: targetInfo.ServoScanCycleCount,
					FrameID:             targetInfo.FrameID,
					TrackObjNum:         targetInfo.TrackObjNum,
					Items:               make([]*client.DPHTargetItem, 0),
				},
			}
			if err == nil {
				dphTargetData.Header.ParentSn = equipModel.ParentSn
				dphTargetData.Header.ParentType = int32(equipModel.ParentType)
				dphTargetData.Header.IsIntegrated = equipModel.IsIntegrated
			}

			dphConfigModel, err := dphGetConfig(d.Sn)
			if err != nil || dphConfigModel == nil {
				logger.Errorf("DPHTargetData dphGetConfig error: %v", err)
			} else {
				var aziScanScope float32 = 360
				aziScanCenter := dphTargetData.Data.CurrentServoAngle - 90 + float32(dphConfigModel.Heading)
				dphTargetData.Data.BeamConfig = &client.RadarUploadBeamConfigEntity{
					AziScanCenter:   &aziScanCenter,
					AziScanScope:    &aziScanScope,
					EleScanCenter:   &(dphConfigModel.EleScanScope),
					EleScanScope:    &(dphConfigModel.EleScanCenter),
					RadarScanRadius: &(dphConfigModel.RadarScanRadius),
				}
			}
			var (
				heading, pitching, rolling float64 //雷达姿态
				longitude, latitude        float64 //雷达经纬度
			)
			if dphConfigModel != nil {
				heading = dphConfigModel.Heading
				pitching = dphConfigModel.Pitching
				rolling = dphConfigModel.Rolling
				longitude = dphConfigModel.Longitude
				latitude = dphConfigModel.Latitude
			}

			if longitude == 0 && latitude == 0 {
				// 如果设备的经纬度同时为0时，使用C2的经纬度计算无人机的经纬度
				configRes := &client.ConfigRes{}
				if err := NewSystemConfig().GetSystemConfig(context.Background(), &client.ConfigReq{}, configRes); err != nil {
					logger.Errorf("DPHTargetData failed to get system config: %v", err)
				} else {
					longitude = configRes.C2Longitude
					latitude = configRes.C2Latitude
				}
			}

			if len(targetInfo.ItemList) > 0 {
				for _, track := range targetInfo.ItemList {
					var droneLongitude, droneLatitude float64 //无人机经纬度

					//坐标转换
					dronePoint, err := d.calculateCoordinates(float64(track.FilteredDistance), float64(track.FilteredElevation)-pitching, float64(track.FilteredAzimuth), heading, pitching, rolling)
					if err != nil {
						logger.Errorf("DPHTargetData calculateCoordinates error: %v", err)
					}
					if dronePoint != nil {
						//无人机x,y 转换成经纬度
						//point := common.Coord3D{
						//	X: dronePoint.X,
						//	Y: dronePoint.Y,
						//	Z: dronePoint.Z,
						//}

						latLng, err := common.GetLatLngByXY(common.LatLng{
							Latitude:  latitude,
							Longitude: longitude,
						}, dronePoint.Y, dronePoint.X)
						if err != nil {
							logger.Error("DPHTargetData GetLatLngByXY error: %v", err)
						} else {
							droneLongitude = latLng.Longitude
							droneLatitude = latLng.Latitude
						}
					}

					// 适配目标类别
					classification := convertClassification(int32(track.Classification[0]))

					// azi 改成 heading+azi
					item := &client.DPHTargetItem{
						TargetTrackDeleteFlag:       uint32(track.TargetTrackDeleteFlag),
						Id:                          uint32(track.Id),
						ForCastFrameNum:             uint32(track.ForCastFrameNum),
						TargetLossReason:            uint32(track.TargetLossReason),
						TargetUpdateTime:            track.TargetUpdateTime,
						TargetMeasuredDoppler:       uint32(track.TargetMeasuredDoppler),
						TargetMeasuredDistance:      uint32(track.TargetMeasuredDistance),
						Mag:                         float32(common.RoundFloat(float64(track.Mag))),
						Snr:                         float32(common.RoundFloat(float64(track.Snr))),
						Velocity:                    -float32(common.RoundFloat(float64(track.Velocity))),
						Range:                       float32(common.RoundFloat(float64(track.Range))),
						Azimuth:                     float32(common.RoundFloat(float64(track.Azimuth))) + float32(heading),
						Elevation:                   float32(common.RoundFloat(float64(track.Elevation))),
						Height:                      float32(common.RoundFloat(float64(track.Height))),
						AzimuthDeviation:            float32(common.RoundFloat(float64(track.AzimuthDeviation))),
						ElevationDeviation:          float32(common.RoundFloat(float64(track.ElevationDeviation))),
						PredictedSpeed:              -float32(common.RoundFloat(float64(track.PredictedSpeed))),
						PredictedDistance:           float32(common.RoundFloat(float64(track.PredictedDistance))),
						PredictedAzimuth:            float32(common.RoundFloat(float64(track.PredictedAzimuth))) + float32(heading),
						PredictedElevation:          float32(common.RoundFloat(float64(track.PredictedElevation))),
						PredictedHeight:             float32(common.RoundFloat(float64(track.PredictedHeight))),
						FilterSpeed:                 -float32(common.RoundFloat(float64(track.FilterSpeed))),
						FilteredDistance:            float32(common.RoundFloat(float64(track.FilteredDistance))),
						FilteredAzimuth:             float32(common.RoundFloat(float64(track.FilteredAzimuth))) + float32(heading),
						FilteredElevation:           float32(common.RoundFloat(float64(track.FilteredElevation))),
						FilteredHeight:              float32(common.RoundFloat(float64(track.FilteredHeight))),
						FilteredAverageSpeed:        float32(common.RoundFloat(float64(track.FilteredAverageSpeed))),
						FilteredAverageAcceleration: float32(common.RoundFloat(float64(track.FilteredAverageAcceleration))),
						EnvelopePoints:              uint32(track.EnvelopePoints),
						TrackPriority:               uint32(track.TrackPriority),
						Alive:                       track.AssociationNum,
						Classification:              classification,
						PitchBeamNumber:             uint32(track.PitchBeamNumber),
						NormalizedEnergy:            float32(common.RoundFloat(float64(track.NormalizedEnergy))),
						Longitude:                   common.RoundFloat(droneLongitude),
						Latitude:                    common.RoundFloat(droneLatitude),
						DroneName:                   fmt.Sprintf("%s%d", GenerateNamePrefix(int(classification)), track.Id),
					}
					if dronePoint != nil {
						item.X = common.RoundFloat(dronePoint.X)
						item.Y = common.RoundFloat(dronePoint.Y)
						item.Z = common.RoundFloat(dronePoint.Z)
					}
					if item.Classification == 0x01 {
						//计算无人机威胁等级
						fd, err := NewAlarmControl().GetDroneThreatLevel(&GetThreatLevelReq{
							DroneSn:        "",
							DroneObjId:     int64(item.Id),
							DroneLongitude: droneLongitude,
							DroneLatitude:  droneLatitude,
							DevSn:          d.Sn,
						})
						if err != nil {
							logger.Errorf("DPHTargetData get drone threat level error, droneId: %d, err: %v", item.Id, err)
						} else {
							item.AlarmId = fd.AlarmId
							item.EventId = fd.EventId
							item.ThreatLevel = fd.ThreatLevel
							item.ScenesId = fd.ScenesId
						}
					}
					dphTargetData.Data.Items = append(dphTargetData.Data.Items, item)
				}
			}
			buBuff, err := proto.Marshal(dphTargetData)
			if err != nil {
				logger.Errorf("DPHTargetData proto.Marshal error: %v", err)
				continue
			}
			report := &client.ClientReport{
				MsgType: common.ClientMsgIDDPH110Target,
				Data:    buBuff,
			}

			out, err := proto.Marshal(report)
			if err != nil {
				logger.Errorf("DPHTargetData ClientReport proto.Marshal error: %v", err)
				continue
			}
			_ = mq.DPH110Broker.Publish(mq.DPH110Topic, broker.NewMessage(out))
			logger.Debugf("DPH110 target has reported %+v", dphTargetData)
			//雷达波束信息上报
			//if err = d.reportDPHBeamSteer(dphTargetData.Data.CurrentServoAngle); err != nil {
			//	logger.Errorf("DPH110 reportDPHBeamSteer error: %v", err)
			//}
		case mavlink.TraceMsgType:
			track := DPHTracerData{}
			if err = binary.Read(buffer, binary.LittleEndian, &track); err != nil {
				logger.Errorf("DPHTraceData binary.Read error: %v", err)
				continue
			}

			logger.Debugf("trace info: %+v", track)
			updateStatus(d.Sn, d.DevVersion)

			var (
				droneLongitude, droneLatitude float64 //无人机经纬度
				heading, pitching, rolling    float64 //雷达姿态
				longitude, latitude           float64 //雷达经纬度
			)
			dphConfigModel, err := dphGetConfig(d.Sn)
			if err != nil || dphConfigModel == nil {
				logger.Errorf("DPHTraceData dphGetConfig error: %v", err)
			} else {
				heading = dphConfigModel.Heading
				pitching = dphConfigModel.Pitching
				rolling = dphConfigModel.Rolling
				longitude = dphConfigModel.Longitude
				latitude = dphConfigModel.Latitude
			}

			//坐标转换
			dronePoint, err := d.calculateCoordinates(float64(track.FilteredDistance), float64(track.FilteredElevation)-pitching, float64(track.FilteredAzimuth), heading, pitching, rolling)
			if err != nil {
				logger.Errorf("DPHTraceData calculateCoordinates error: %v", err)
			}
			if dronePoint != nil {
				//无人机x,y 转换成经纬度
				//point := common.Coord3D{
				//	X: dronePoint.X,
				//	Y: dronePoint.Y,
				//	Z: dronePoint.Z,
				//}
				//droneLongitude, droneLatitude = common.ConvertToLatLon(longitude, latitude, point)

				latLng, err := common.GetLatLngByXY(common.LatLng{
					Latitude:  latitude,
					Longitude: longitude,
				}, dronePoint.Y, dronePoint.X)
				if err != nil {
					logger.Error("DPHTraceData GetLatLngByXY error: %v", err)
				} else {
					droneLongitude = latLng.Longitude
					droneLatitude = latLng.Latitude
				}
			}

			// 适配目标类别
			classification := convertClassification(int32(track.Classification[0]))
			//azi 改成 heading+azi
			traceData := &client.DPHTraceData{
				ServoAngle:                  float32(track.ServoAngle) * 0.1,
				FrameID:                     track.FrameID,
				TargetTrackDeleteFlag:       uint32(track.TrackDeletionFlag),
				Id:                          uint32(track.Id),
				ForCastFrameNum:             uint32(track.ForcastFrameNum),
				TargetLossReason:            uint32(track.TargetLossReason),
				TargetUpdateTime:            track.TargetUpdateTime,
				TargetMeasuredDoppler:       uint32(track.TargetMeasuredDoppler),
				TargetMeasuredDistance:      uint32(track.TargetMeasuredDistance),
				Mag:                         float32(common.RoundFloat(float64(track.Mag))),
				Snr:                         float32(common.RoundFloat(float64(track.Snr))),
				Velocity:                    -float32(common.RoundFloat(float64(track.Velocity))),
				Range:                       float32(common.RoundFloat(float64(track.Range))),
				Azimuth:                     float32(common.RoundFloat(float64(track.Azimuth))) + float32(heading),
				Elevation:                   float32(common.RoundFloat(float64(track.Elevation))),
				Height:                      float32(common.RoundFloat(float64(track.Height))),
				AzimuthDeviation:            float32(common.RoundFloat(float64(track.AzimuthDeviation))),
				ElevationDeviation:          float32(common.RoundFloat(float64(track.ElevationDeviation))),
				PredictedSpeed:              -float32(common.RoundFloat(float64(track.PredictedSpeed))),
				PredictedDistance:           float32(common.RoundFloat(float64(track.PredictedDistance))),
				PredictedAzimuth:            float32(common.RoundFloat(float64(track.PredictedAzimuth))) + float32(heading),
				PredictedElevation:          float32(common.RoundFloat(float64(track.PredictedElevation))),
				PredictedHeight:             float32(common.RoundFloat(float64(track.PredictedHeight))),
				FilterSpeed:                 -float32(common.RoundFloat(float64(track.FilterSpeed))),
				FilteredDistance:            float32(common.RoundFloat(float64(track.FilteredDistance))),
				FilteredAzimuth:             float32(common.RoundFloat(float64(track.FilteredAzimuth))) + float32(heading),
				FilteredElevation:           float32(common.RoundFloat(float64(track.FilteredElevation))),
				FilteredHeight:              float32(common.RoundFloat(float64(track.FilteredHeight))),
				FilteredAverageSpeed:        float32(common.RoundFloat(float64(track.FilteredAverageSpeed))),
				FilteredAverageAcceleration: float32(common.RoundFloat(float64(track.FilteredAverageAcceleration))),
				Alive:                       track.AssociationNum,
				Classification:              classification,
				PitchBeamNumber:             uint32(track.PitchBeamNumber),
				NormalizedEnergy:            float32(common.RoundFloat(float64(track.NormalizedEnergy))),
				Longitude:                   common.RoundFloat(droneLongitude),
				Latitude:                    common.RoundFloat(droneLatitude),
				DroneName:                   fmt.Sprintf("%s%d", GenerateNamePrefix(int(classification)), track.Id),
			}
			if dronePoint != nil {
				traceData.X = common.RoundFloat(dronePoint.X)
				traceData.Y = common.RoundFloat(dronePoint.Y)
				traceData.Z = common.RoundFloat(dronePoint.Z)
			}
			if traceData.Classification == 0x01 {
				//计算无人机威胁等级
				fd, err := NewAlarmControl().GetDroneThreatLevel(&GetThreatLevelReq{
					DroneSn:        "",
					DroneObjId:     int64(traceData.Id),
					DroneLongitude: droneLongitude,
					DroneLatitude:  droneLatitude,
					DevSn:          d.Sn,
				})
				if err != nil {
					logger.Errorf("DPHTraceData get drone threat level error, droneId: %d, err: %v", traceData.Id, err)
				} else {
					traceData.AlarmId = fd.AlarmId
					traceData.EventId = fd.EventId
					traceData.ThreatLevel = fd.ThreatLevel
					traceData.ScenesId = fd.ScenesId
				}
			}

			equipModel, err := GetEquipBySn(d.Sn)
			name := d.Sn
			if equipModel != nil && equipModel.Name != "" {
				name = equipModel.Name
			}
			buData := &client.DPHTTraceInfo{
				Header: &client.EquipmentMessageBoxEntity{
					Name:      name,
					Sn:        d.Sn,
					EquipType: int32(common.DEV_DPH110),
					MsgType:   mavlink.TraceMsgType,
				},
				Data: traceData,
			}
			if err != nil {
				buData.Header.ParentSn = equipModel.ParentSn
				buData.Header.ParentType = int32(equipModel.ParentType)
				buData.Header.IsIntegrated = equipModel.IsIntegrated
			}
			buBuff, err := proto.Marshal(buData)
			if err != nil {
				logger.Errorf("DPHTraceData proto.Marshal err %v", err)
				continue
			}
			report := &client.ClientReport{
				MsgType: common.ClientMsgIDDPH110Track,
				Data:    buBuff,
			}
			out, err := proto.Marshal(report)
			if err != nil {
				logger.Errorf("DPHTraceData ClientReport Marshal err %v", err)
				continue
			}
			_ = mq.DPH110Broker.Publish(mq.DPH110Topic, broker.NewMessage(out))
			logger.Debugf("DPH110 trace has reported %+v", buData)
		}
		buff = buff[:0]
	}
}

// reportDPHBeamSteer DPH110波束信息上报
func (d *ControllerDPH110) reportDPHBeamSteer(servoAngle float32) error {
	dphConfigModel, err := dphGetConfig(d.Sn)
	if err != nil || dphConfigModel == nil {
		logger.Errorf("reportDPHBeamSteer dphGetConfig error: %v", err)
		return err
	}

	var aziScanScope float32 = 360
	aziScanCenter := servoAngle + float32(dphConfigModel.Heading)
	equipModel, err := GetEquipBySn(d.Sn)
	name := d.Sn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	beamSteerCfg := &client.RadarBeamSteerConfig{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        d.Sn,
			EquipType: int32(common.DEV_DPH110),
			MsgType:   common.ClientMsgIDDPH110BeamSteer,
		},
		Data: &client.RadarUploadBeamConfigEntity{
			AziScanCenter:   &aziScanCenter,
			AziScanScope:    &aziScanScope,
			EleScanCenter:   &(dphConfigModel.EleScanScope),
			EleScanScope:    &(dphConfigModel.EleScanCenter),
			RadarScanRadius: &(dphConfigModel.RadarScanRadius),
		},
	}
	if err != nil {
		beamSteerCfg.Header.ParentSn = equipModel.ParentSn
		beamSteerCfg.Header.ParentType = int32(equipModel.ParentType)
		beamSteerCfg.Header.IsIntegrated = equipModel.IsIntegrated
	}

	buData, err := proto.Marshal(beamSteerCfg)
	if err != nil {
		logger.Error("reportDPHBeamSteer RadarBeamSteerConfig Marshal err %v", err)
		return err
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIDDPH110BeamSteer,
		Data:    buData,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Errorf("reportDPHBeamSteer ClientReport Marshal err %v", err)
		return err
	}
	_ = mq.DPH110Broker.Publish(mq.DPH110Topic, broker.NewMessage(out))
	logger.Infof("DPH110 Beam has reported, devSn: %+v, report:%+v", d.Sn, beamSteerCfg)
	return nil
}

// reportDPHPosture DPH110姿态信息上报
func (d *ControllerDPH110) reportDPHPosture() error {
	dphConfigModel, err := dphGetConfig(d.Sn)
	if err != nil || dphConfigModel == nil {
		logger.Errorf("reportDPHPosture dphGetConfig error: %v", err)
		return err
	}

	equipModel, err := GetEquipBySn(d.Sn)
	name := d.Sn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	postureInfo := &client.RadarPosture{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        d.Sn,
			EquipType: int32(common.DEV_DPH110),
			MsgType:   common.ClientMsgIDDPH110Posture,
		},
		Data: &client.RadarUploadPostureEntity{
			Heading:   &(dphConfigModel.Heading),
			Pitching:  &(dphConfigModel.Pitching),
			Rolling:   &(dphConfigModel.Rolling),
			Longitude: &(dphConfigModel.Longitude),
			Latitude:  &(dphConfigModel.Latitude),
			Altitude:  &(dphConfigModel.Altitude),
		},
	}
	if err != nil {
		postureInfo.Header.ParentSn = equipModel.ParentSn
		postureInfo.Header.ParentType = int32(equipModel.ParentType)
		postureInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}

	buData, err := proto.Marshal(postureInfo)
	if err != nil {
		logger.Error("reportDPHPosture postureInfo Marshal err %v", err)
		return err
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIDDPH110Posture,
		Data:    buData,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Errorf("reportDPHPosture ClientReport Marshal err %v", err)
		return err
	}
	_ = mq.DPH110Broker.Publish(mq.DPH110Topic, broker.NewMessage(out))
	logger.Infof("DPH110 Posture has reported, devSn: %+v,report:%+v", d.Sn, postureInfo)
	return nil
}

func Dph110OfflineReport(sn string) {
	conn, ok := getDPH110Conn(sn)
	if ok {
		conn.Close()
		cacheKey := fmt.Sprintf("%d_%s", common.DEV_DPH110, sn)
		DevStatusMap.Delete(cacheKey)
		deleteDPH110Conn(sn)
	}
	offline := int32(common.DevOffline)
	equipModel, err := GetEquipBySn(sn)
	name := sn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	heartInfo := &client.RadarStatusInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        sn,
			EquipType: int32(common.DEV_DPH110),
			MsgType:   mavlink.StatusMsgType,
		},
		Data: &client.RadarStatusEntity{
			IsOnline:  &offline,
			SerialNum: sn,
		},
	}
	if err == nil {
		heartInfo.Header.ParentSn = equipModel.ParentSn
		heartInfo.Header.ParentType = int32(equipModel.ParentType)
		heartInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	buData, err := proto.Marshal(heartInfo)
	if err != nil {
		logger.Error("Dph110OfflineReport Marshal err %v", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIDDPH110HeartBeat,
		Data:    buData,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Errorf("Dph110OfflineReport ClientReport Marshal err %v", err)
		return
	}
	_ = mq.DPH110Broker.Publish(mq.DPH110Topic, broker.NewMessage(out))
	logger.Debugf("DPH110 offline has reported: %+v", heartInfo)
}

func (d *ControllerDPH110) deserializeTrack(msg []byte) (*DPHTargetData, error) {
	var (
		currentServoAngle   uint32
		servoScanCycleCount uint32
		frameID             uint32
		trackObjNum         uint32
	)
	if err := mavlink.Read(bytes.NewReader(msg[:4]), binary.LittleEndian, &currentServoAngle, 4); err != nil {
		logger.Errorf("deserializeTrack currentServoAngle binary.Read error: %v", err)
		return nil, err
	}
	if err := mavlink.Read(bytes.NewReader(msg[4:8]), binary.LittleEndian, &servoScanCycleCount, 4); err != nil {
		logger.Errorf("deserializeTrack servoScanCycleCount binary.Read error: %v", err)
		return nil, err
	}
	if err := mavlink.Read(bytes.NewReader(msg[8:12]), binary.LittleEndian, &frameID, 4); err != nil {
		logger.Errorf("deserializeTrack frameID binary.Read error: %v", err)
		return nil, err
	}
	if err := mavlink.Read(bytes.NewReader(msg[12:16]), binary.LittleEndian, &trackObjNum, 4); err != nil {
		logger.Errorf("deserializeTrack trackObjNum binary.Read error: %v", err)
		return nil, err
	}

	targetInfo := &DPHTargetData{
		CurrentServoAngle:   currentServoAngle,
		ServoScanCycleCount: servoScanCycleCount,
		FrameID:             frameID,
		TrackObjNum:         trackObjNum,
	}

	items := msg[16:]
	tracks := make([]TargetItem, 0)
	tLen := 172
	for i := 0; i < int(trackObjNum); i++ {
		var tmp TargetItem
		buff := &bytes.Buffer{}
		err := binary.Write(buff, binary.LittleEndian, items[i*tLen:(i+1)*tLen])
		if err != nil {
			logger.Error("deserialize TargetItem err:", err)
			continue
		}
		err = binary.Read(buff, binary.LittleEndian, &tmp)
		if err != nil {
			continue
		}
		tracks = append(tracks, tmp)
	}
	targetInfo.ItemList = tracks
	return targetInfo, nil
}

// calculateCoordinates 转换成北西天坐标系
func (d *ControllerDPH110) calculateCoordinates(rangeValue, elevationAngle, azimuthAngle, heading, pitching, rolling float64) (*dronePoint, error) {
	xRadar, yRadar, zRadar := transformPolarToRadar(rangeValue, elevationAngle, azimuthAngle)
	h := calculateRotationMatrixElements(heading, pitching, rolling)
	x, y, z := calculateTransformedCoordinates(h, xRadar, yRadar, zRadar)
	dp := &dronePoint{
		X: x,
		Y: y,
		Z: z,
	}
	return dp, nil
}

// transformPolarToRadar 极坐标系（R，A，E）转雷达坐标系（X_radar，Y_radar，Z_radar）
func transformPolarToRadar(rangeValue, elevationAngle, azimuthAngle float64) (float64, float64, float64) {
	//公式使用角度:elevation=elevation/180*π;azimuth=azimuth/180*π;
	//(1) X_radar = range * cos(elevation) * cos(azimuth);
	//(2) Y_radar = range * cos(elevation) * sin(azimuth);
	//(3) Z_radar = range * sin(elevation);

	// 转换角度为弧度
	elevationRad := elevationAngle * math.Pi / 180.0
	azimuthRad := azimuthAngle * math.Pi / 180.0
	// 计算坐标
	xRadar := rangeValue * math.Cos(elevationRad) * math.Cos(azimuthRad)
	yRadar := rangeValue * math.Cos(elevationRad) * math.Sin(azimuthRad)
	zRadar := rangeValue * math.Sin(elevationRad)
	return xRadar, yRadar, zRadar
}

// 计算旋转矩阵的元素
func calculateRotationMatrixElements(heading, pitching, rolling float64) [9]float64 {
	// 雷达坐标系（X_radar，Y_radar，Z_radar）转北西天坐标系（X，Y，Z，即最终需要显示到C2的X，Y，Z信息）
	// （1）转换矩阵：
	//C2输入角度：Yaw，Pitch，Roll
	//公式使用角度：Yaw = -Yaw/180*π；Pitch = Pitch/180*π；Roll = Roll/180*π；
	//
	//H[0] = cos(Pitch) * cos(Yaw);
	//H[1] = -sin(Yaw)* cos(Roll) + cos(Yaw) * sin(Pitch) * sin(Roll);
	//H[2] = sin(Yaw) * sin(Roll) + cos(Yaw) * sin(Pitch) * cos(Roll);
	//H[3] = sin(Yaw) * cos(Pitch);
	//H[4] = cos(Yaw) * cos(Roll)+ sin(Yaw) * sin(Pitch) * sin(Roll);
	//H[5] = -cos(Yaw) * sin(Roll)+ sin(Yaw) * sin(Pitch) * cos(Roll):
	//H[6] = -sin(Pitch);
	//H[7] = cos(Pitch) * sin(Roll);
	//H[8] = cos(Pitch) * cos(Roll);

	yawRadians := heading * math.Pi / 180.0
	pitchRadians := -pitching * math.Pi / 180.0
	rollRadians := -rolling * math.Pi / 180.0

	// 根据给定的公式计算变换矩阵的每个元素
	H := [9]float64{
		math.Cos(pitchRadians) * math.Cos(yawRadians),                                                                   // H[0]
		-math.Sin(yawRadians)*math.Cos(rollRadians) + math.Cos(yawRadians)*math.Sin(pitchRadians)*math.Sin(rollRadians), // H[1]
		math.Sin(yawRadians)*math.Sin(rollRadians) + math.Cos(yawRadians)*math.Sin(pitchRadians)*math.Cos(rollRadians),  // H[2]
		math.Sin(yawRadians) * math.Cos(pitchRadians),                                                                   // H[3]
		math.Cos(yawRadians)*math.Cos(rollRadians) + math.Sin(yawRadians)*math.Sin(pitchRadians)*math.Sin(rollRadians),  // H[4]
		-math.Cos(yawRadians)*math.Sin(rollRadians) + math.Sin(yawRadians)*math.Sin(pitchRadians)*math.Cos(rollRadians), // H[5]
		-math.Sin(pitchRadians),                        // H[6]
		math.Cos(pitchRadians) * math.Sin(rollRadians), // H[7]
		math.Cos(pitchRadians) * math.Cos(rollRadians), // H[8]
	}
	return H
}

// 计算旋转矩阵变换后的坐标
func calculateTransformedCoordinates(H [9]float64, X_radar, Y_radar, Z_radar float64) (X, Y, Z float64) {
	// （2）转换公式：
	//X = H[0]* X_radar + H[1]* Y_radar + H[2]* Z_radar；
	//Y = H[3]* X_radar + H[4]* Y_radar + H[5]* Z_radar；
	//Z = H[6]* X_radar + H[7]* Y_radar + H[8]* Z_radar；

	// 计算变换后的坐标
	X = H[0]*X_radar + H[1]*Y_radar + H[2]*Z_radar
	Y = H[3]*X_radar + H[4]*Y_radar + H[5]*Z_radar
	Z = H[6]*X_radar + H[7]*Y_radar + H[8]*Z_radar

	return
}

func updateStatus(sn, devVersion string) {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_DPH110, sn)
	if cache, ok := DevStatusMap.Load(cacheKey); ok {
		dev := cache.(*Device)
		dev.LastHeartTime = time.Now()
		dev.Status = common.DevOnline
	} else {
		dev := &Device{
			Sn:                sn,
			Status:            common.DevOnline,
			DevType:           common.DEV_DPH110,
			FirstHeartTime:    time.Now(),
			LastHeartTime:     time.Now(),
			IsEnable:          GetDevStatus(int32(common.DEV_DPH110), sn),
			GetStatusInterval: time.Now(),
		}
		DevStatusMap.Store(cacheKey, dev)
		//更新设备版本号
		updateDevVersion(sn, devVersion)
	}
}

func updateDevVersion(sn, devVersion string) {
	err := NewEquipList().Update(context.Background(), &client.EquipCrudReq{
		Sn:         sn,
		DevVersion: devVersion,
		//IsOnline:   true,
	}, &client.EquipCrudRes{})
	if err != nil {
		logger.Error("update DPH110 dev version error: ", err)
	}
}

// convertClassification 适配目标类别
func convertClassification(classification int32) int32 {
	switch classification {
	case 0:
		return 0
	case 1:
		return 1
	case 2:
		return 0
	case 3:
		return 0
	case 4:
		return 2
	case 5:
		return 3
	}
	return 0
}

func dphGetConfig(sn string) (*bean.DPH110Config, error) {
	dph110Config, err := NewDPH110Config().First(sn)
	if err != nil {
		if err == gorm.ErrRecordNotFound {
			dph110ConfigModel := NewDPH110Config().generateInsert(&client.RadarSetConfigRequest{
				Sn: sn,
			})
			if err = NewDPH110Config().Insert(dph110ConfigModel); err != nil {
				logger.Errorf("insert dph110 config error: %v", err)
				return nil, err
			}
			return NewDPH110Config().First(sn)
		}
		return nil, err
	}
	return dph110Config, nil
}

func setDPH110Conn(sn string, conn *net.UDPConn) {
	DPH110Conn.Store(sn, conn)
}

func getDPH110Conn(sn string) (*net.UDPConn, bool) {
	conn, ok := DPH110Conn.Load(sn)
	if !ok {
		return nil, false
	}
	return conn.(*net.UDPConn), true
}

func deleteDPH110Conn(sn string) {
	DPH110Conn.Delete(sn)
}

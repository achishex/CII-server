package handler

import (
	"context"
	"time"

	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
	"adasgitlab.autel.com/tools/cuav_server/repo/utils"
)

type Sms struct {
}

func NewSms() *Sms {
	return &Sms{}
}

var sdk = NewSDK()

func (s *Sms) Send(ctx context.Context, req *client.SmsSendReq, resp *client.SmsSendRes) error {
	// 先根据手机号查询用户
	var user bean.User
	err := db.GetDB().Model(&bean.User{}).Where("mobile = ?", req.Phone).First(&user).Error
	if err != nil {
		return err
	}
	times, ok := user.GetTodaySendSmsTimes()
	if !ok {
		// 被限制
		resp.Times = times
		resp.Limited = true
		resp.Code = ""
		return nil
	} else {
		// 发送短信
		code, err := sdk.SendSms(req.Phone, req.NumberType)
		if err != nil {
			return err
		}
		// 更新数据用户的发送次数和最后发送短信时间
		lastUpdateTime := utils.ParseTimeToString(time.Now())
		times++
		db.GetDB().Model(&bean.User{}).Where("id = ?", user.ID).Updates(bean.User{LastSmsTime: lastUpdateTime, DailySendTimes: times})
		resp.Times = times
		resp.Limited = false
		resp.Code = code
		return nil
	}
}

func (s *Sms) CheckVerificationCode(ctx context.Context, req *client.CheckReq, resp *client.CheckRes) error {
	err := sdk.CheckVerificationCode(req.Phone, req.Code)
	if err != nil {
		return err
	}
	return nil
}

func (s *Sms) Notify(ctx context.Context, req *client.SmsNotifyReq, resp *client.SmsSendRes) error {
	if err := sdk.NotifySms(req); err != nil {
		return err
	}

	return nil
}

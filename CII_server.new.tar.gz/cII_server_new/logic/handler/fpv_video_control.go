package handler

import (
	"context"
	"errors"
	"sync"
	"sync/atomic"
	"time"

	"adasgitlab.autel.com/tools/cuav_plugin/broker"
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/helper"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
	"google.golang.org/protobuf/proto"
)

var (
	fpvVideoSessNode *FpvVideoSession
	fpvVideoSessOnce sync.Once
)

// Instance 单例
func FpvVideoInstance() *FpvVideoSession {
	fpvVideoSessOnce.Do(func() {
		fpvVideoSessNode = &FpvVideoSession{
			TmrDur:                  "500ms", // timer worker timer.
			WaitToRecvVideoMaxTime:  10 * time.Second,
			WaitToClientStopMaxTime: 2 * time.Second,
		}
		fpvVideoSessNode.Status.Store(uint32(FpvVideoSessionInit))
	})
	return fpvVideoSessNode
}

const (
	FpvVideoSessionInit     uint8 = 1 //未开启视频
	FpvVideoSessionStarting uint8 = 2 //正在开流中,但是未接到视频流
	FpvVideoSessionStopped  uint8 = 3
	FpvVideoSessionStarted  uint8 = 4 //已开启, 且已经有视频流
	//
	BeginToSendStopCmdToClient uint8 = 5
	WaitToClientStopCmdTimeOut uint8 = 6
)

type FpvVideoSession struct {
	Status        atomic.Uint32 //会话状态
	LastVideoTime atomic.Int64  // unit is second; 上次收流的时间点
	//
	WaitToRecvVideoMaxTime  time.Duration //配置项; 等待收流的最长时间
	notifyClientStopTime    time.Time     //标记watch 不到流时, 向client 发送通知的时间点。
	WaitToClientStopMaxTime time.Duration //配置项； 等待client 发送stop的最大时间。

	Sn        string //设备sn
	UavSeqNo  int32  // 无人机编号。 底层存储是 uint8
	DroneName string //无人机名称
	UFreq     uint32 //lsb无人机信号频率(mHz)

	WatchTmr   *helper.GeneralTaskTimer
	Ctx        context.Context
	CancelFunc context.CancelFunc

	TmrDur  string //
	devNode any    //Fpv   //DroneID
	devType int32  //
}

func (fvSession *FpvVideoSession) SetEndToStatus() {
	fvSession.Status.Store(uint32(FpvVideoSessionStopped))
}
func (fvSession *FpvVideoSession) SetStartingToStatus() {
	fvSession.Status.Store(uint32(FpvVideoSessionStarting))
}
func (fvSession *FpvVideoSession) IsInitStatus() bool {
	return uint8(fvSession.Status.Load()&0xFF) == FpvVideoSessionInit || uint8(fvSession.Status.Load()&0xFF) == FpvVideoSessionStopped
}
func (fvSession *FpvVideoSession) IsStartedAndVideoing() bool {
	return uint8(fvSession.Status.Load()&0xFF) == FpvVideoSessionStarted
}

func (fvSession *FpvVideoSession) SetDroneId(id *DroneID) {
	fvSession.devNode = id
}
func (fvSession *FpvVideoSession) SetFpvId(id *Fpv) {
	fvSession.devNode = id
}
func (fvSession *FpvVideoSession) SetUavSeqNo(seqNo int32) {
	fvSession.UavSeqNo = seqNo
}
func (fvSession *FpvVideoSession) SetDroneName(name string) {
	fvSession.DroneName = name
}
func (fvSession *FpvVideoSession) SetUFreq(freq uint32) {
	fvSession.UFreq = freq
}

func (fvSession *FpvVideoSession) SendCmdToDevice(req *client.FpvVideoControlReq, resp *client.FpvVideoControlResp) error {
	devSn := req.GetSn()

	var devType common.DeviceType
	switch req.GetDevType() {
	case int32(client.EnumDevTypeList_TracerSDevTypeEnum):
		devType = common.DEV_V2DRONEID

	case int32(client.EnumDevTypeList_FpvDevTypeEnum):
		devType = common.DEV_FPV

	default:
		devType = common.DEV_FPV
	}

	dev := FindCacheDevice(devSn, devType)
	if dev == nil {
		logger.Errorf("dev not online, sn: %v, req: %v", devSn, req)
		resp.Status = VideoFail
		return errors.New("设备未在线")
	}

	if req.GetOps() == int32(client.FpvVideoCtrlOPS_FpvVideoCtrlEntry) {
		fvSession.SetUavSeqNo(req.GetUavSeqNo())
		fvSession.SetUFreq(req.GetUFreq())
		fvSession.SetDroneName(req.GetDroneName())
		fvSession.Sn = devSn
	} else {
		if len(req.GetDroneName()) != 25 {
			logger.Infof("req stop cmd, droneName is not 25 byte, val: %v", req.GetDroneName())
			req.DroneName = "1234567890qwertyuiopasdfg" //填充一个无效值
			logger.Infof("now req msg: %v", req)
		}
	}

	if devType == common.DEV_V2DRONEID {
		var devNode *DroneID = &DroneID{Device: dev}
		fvSession.SetDroneId(devNode)
		fvSession.devType = int32(common.DEV_V2DRONEID)
		ret, e := devNode.ControlVideoCmd(uint8(req.GetOps()), uint8(req.GetUavSeqNo()), []uint8(req.GetDroneName()), req.GetUFreq())
		if e != nil {
			logger.Infof("send tracer video ctrl fail, e: %v, req: %v", e, req)
			resp.Status = VideoFail
			return e
		}
		resp.Status = ret
		return nil
	}

	var devNode *Fpv = &Fpv{Device: dev}
	fvSession.SetFpvId(devNode)
	fvSession.devType = int32(common.DEV_FPV)

	ret, e := devNode.ControlVideoCmd(uint8(req.GetOps()), uint8(req.GetUavSeqNo()), []uint8(req.GetDroneName()), req.GetUFreq())
	if e != nil {
		logger.Infof("send tracer video ctrl fail, e: %v, req: %v", e, req)
		resp.Status = VideoFail
		return e
	}
	resp.Status = ret

	return nil
}
func (fvSession *FpvVideoSession) StartTimer() {
	fvSession.Ctx, fvSession.CancelFunc = context.WithCancel(context.Background())
	fvSession.LastVideoTime.Store(time.Now().Unix())
	fvSession.notifyClientStopTime = time.Now()
	//
	fvSession.WatchTmr = helper.NewGeneralTaskTimer(fvSession.TmrDur, helper.RegisterTaskProcess(fvSession))
	fvSession.WatchTmr.DoTask(fvSession.Ctx)
	logger.Infof("begin to watch fpv video push logic.")
}
func (fvSession *FpvVideoSession) StopTimer() {
	logger.Infof("stop watch video, now")
	if fvSession.CancelFunc != nil {
		fvSession.CancelFunc()
	}
	fvSession.CancelFunc = nil
}

func (fvSession *FpvVideoSession) SendStopCmdToClient() {
	logger.Info("--->send video stop cmd to client")
	report := &client.FpvVideoControlNotify{
		UFreq:     fvSession.UFreq,
		UavSeqNo:  fvSession.UavSeqNo,
		DroneName: fvSession.DroneName,
		Notify:    int32(client.FpvVideoCtrlOPS_FpvVideoCtrlExit),
	}

	buBuff, err := proto.Marshal(report)
	if err != nil {
		logger.Errorf("Marshal TracerVideStopCmd err %v", err)
		return
	}

	out := &client.ClientReport{
		MsgType: common.ClientFpvVideoNotifyCmd,
		Data:    buBuff,
	}

	data, err := proto.Marshal(out)
	if err != nil {
		logger.Errorf("ClientReport Marshal err %v", err)
		return
	}

	_ = mq.FpvVideoStopCmdBroker.Publish(mq.FpvStopCmdTopic, broker.NewMessage(data))
	logger.Infof("tracer stop cmd data, devSn: %v", fvSession.Sn)
}

func (fvSession *FpvVideoSession) SelfSendEndCmdToDevice() {
	var (
		req  *client.FpvVideoControlReq  = new(client.FpvVideoControlReq)
		resp *client.FpvVideoControlResp = new(client.FpvVideoControlResp)
	)

	req.Sn = fvSession.Sn
	req.Ops = int32(client.FpvVideoCtrlOPS_FpvVideoCtrlExit)
	req.UavSeqNo = fvSession.UavSeqNo
	req.DroneName = fvSession.DroneName
	req.UFreq = fvSession.UFreq

	if fvSession.devType == int32(common.DEV_V2DRONEID) {
		req.DevType = int32(client.EnumDevTypeList_TracerSDevTypeEnum)

	} else {
		req.DevType = int32(client.EnumDevTypeList_FpvDevTypeEnum)
	}

	fvSession.SendCmdToDevice(req, resp)
	logger.Infof("send stop video cmd to device")
}
func (fvSession *FpvVideoSession) UpdateStatusOnPushingVideo() {
	status := uint8(fvSession.Status.Load() & 0xFF)
	if status >= FpvVideoSessionStarting && status != FpvVideoSessionStopped {
		fvSession.LastVideoTime.Store(time.Now().Unix())
	}
	//如果已经是stopped状态，此时接收到视频流，状态保持不变。除非用户指令开流来修改状态。
	if status <= FpvVideoSessionStarting {
		fvSession.Status.Store(uint32(FpvVideoSessionStarted))
		logger.Infof("update fpv video session status to: %v", FpvVideoSessionStarted)
	}
}

// Process 开流后，检查设备是否持续向c2推流; 如果长时间没有流则向client 发送stop；同时等待client close动作，如果client 未发送stop.则session自动销毁。
func (fvSession *FpvVideoSession) Process() error {
	var (
		lastTime = fvSession.LastVideoTime.Load()
	)

	if uint8(fvSession.Status.Load()&0xFF) <= FpvVideoSessionStarted {
		if time.Since(time.Unix(lastTime, 0)) > fvSession.WaitToRecvVideoMaxTime {
			logger.Errorf("not recv video for long time, last recv video time: %v", lastTime)

			fvSession.Status.Store(uint32(BeginToSendStopCmdToClient))
			logger.Infof("session status change to BeginToSendStopCmdToClient")
		}
		return nil
	}

	if uint8(fvSession.Status.Load()&0xFF) == BeginToSendStopCmdToClient {
		fvSession.SendStopCmdToClient()
		fvSession.notifyClientStopTime = time.Now()
		fvSession.Status.Store(uint32(WaitToClientStopCmdTimeOut))
		logger.Infof("session status change to WaitToClientStopCmdTimeOut")

		return nil
	}

	if uint8(fvSession.Status.Load()&0xFF) == WaitToClientStopCmdTimeOut {
		if time.Since(fvSession.notifyClientStopTime) > fvSession.WaitToClientStopMaxTime {
			logger.Infof("wait client to stop cmd arrive max times, self close session")

			go func() {
				fvSession.SelfSendEndCmdToDevice()
			}()

			fvSession.SetEndToStatus()
			logger.Infof("session status change to  FpvVideoSessionInit")

			if fvSession.CancelFunc != nil {
				logger.Infof("self close session")

				go func() {
					fvSession.CancelFunc()
					fvSession.CancelFunc = nil
				}()
			}
		}
	}
	return nil
}

// IFpvVideoCtrl 控制接口
type IFpvVideoCtrl interface {
	Control(req *client.FpvVideoControlReq, resp *client.FpvVideoControlResp)
}
type FpvVideoCtrlStart struct {
}

// Control 开启视频流
func (fv *FpvVideoCtrlStart) Control(req *client.FpvVideoControlReq, resp *client.FpvVideoControlResp) {
	resp.Status = SUCC

	if !FpvVideoInstance().IsInitStatus() {
		logger.Infof("not free idle status, current status: %v", FpvVideoInstance().Status.Load())
		if FpvVideoInstance().IsStartedAndVideoing() {
			FpvVideoInstance().StartTimer()
			resp.Status = 2
			resp.Ops = req.GetOps()
			logger.Infof("is streaming, return front is ok.")
			return
		}

		resp.Status = 0
		resp.Ops = resp.GetOps()
		return
	}

	FpvVideoInstance().SendCmdToDevice(req, resp)
	if resp.GetStatus() != VideoFail {
		FpvVideoInstance().StartTimer()
		FpvVideoInstance().SetStartingToStatus()
	} else {
		resp.Status = VideoFail
		resp.Ops = req.GetOps()
	}
	return
}

type FpvVideoCtrlEnd struct {
}

// Control 结束视频流
func (fv *FpvVideoCtrlEnd) Control(req *client.FpvVideoControlReq, resp *client.FpvVideoControlResp) {
	resp.Status = SUCC
	FpvVideoInstance().SendCmdToDevice(req, resp)
	FpvVideoInstance().StopTimer()
	FpvVideoInstance().SetEndToStatus()
	return
}

func NewFpvVideoCtrlHandler(op int32) IFpvVideoCtrl {
	switch op {
	case int32(client.FpvVideoCtrlOPS_FpvVideoCtrlExit):
		return new(FpvVideoCtrlEnd)

	case int32(client.FpvVideoCtrlOPS_FpvVideoCtrlEntry):
		return new(FpvVideoCtrlStart)

	default:
		return nil
	}
}
func GetOpsDesc(op int32) string {
	switch op {
	case int32(client.FpvVideoCtrlOPS_FpvVideoCtrlExit):
		return "fpv_video_exit"

	case int32(client.FpvVideoCtrlOPS_FpvVideoCtrlEntry):
		return "fpv_video_entry"

	default:
		return ""
	}
}

func (d *DeviceCenter) FpvVideoControl(ctx context.Context, req *client.FpvVideoControlReq, resp *client.FpvVideoControlResp) error {
	if req == nil || resp == nil {
		return errors.New("parameter is nil")
	}

	logger.Infof("FpvVideoControl req: %v, ops: %v", req, GetOpsDesc(req.GetOps()))
	defer logger.Infof("FpvVideoControl response: %v", resp)

	resp.Status = 2
	resp.Ops = req.GetOps()

	//只有在开启视频流才校验请求参数.
	if req.GetOps() == int32(client.FpvVideoCtrlOPS_FpvVideoCtrlEntry) && (req.GetUavSeqNo() < 0 || len(req.GetDroneName()) <= 0 || req.GetUFreq() <= 0) {
		logger.Infof("req parameter is invalid, req: %v, ops: %v", req, GetOpsDesc(req.GetOps()))
		resp.Status = Fail
		return nil
	}

	handler := NewFpvVideoCtrlHandler(req.GetOps())
	if handler == nil {
		logger.Infof("not support op: %v, desc: %v", req.GetOps(), GetOpsDesc(req.GetOps()))
		resp.Status = Fail
		return nil
	}

	handler.Control(req, resp)
	return nil
}

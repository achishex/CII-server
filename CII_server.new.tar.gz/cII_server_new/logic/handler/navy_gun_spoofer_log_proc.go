package handler

import (
	"adasgitlab.autel.com/tools/cuav_plugin/broker"
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
	"encoding/json"
	"fmt"
	broker2 "go-micro.dev/v4/broker"
)

// INavySpooferUnionActionLog 日志操作接口
type INavySpooferUnionActionLog interface {
	// PubLog 日志产生方调用
	PubLog(data *bean.NavyGunSpooferLog)

	// WriteLog 日志消费方接口调用
	WriteLog()
}

// NewNavySpooferUnionActionLog 创建日志操作句柄
func NewNavySpooferUnionActionLog(logMode int32) INavySpooferUnionActionLog {
	switch logMode {
	case 1:
		return &NavySpooferUnionActionLogDB{}

	case 2:
		return &NavySpooferUnionActionLogDB{}

	default:
		return &NavySpooferUnionActionLogDB{}
	}
}

// NavySpooferUnionActionLogDB 海军日志写库实例
type NavySpooferUnionActionLogDB struct {
}

// PubLog 发布日志数据
func (n *NavySpooferUnionActionLogDB) PubLog(data *bean.NavyGunSpooferLog) {
	if data == nil {
		return
	}
	buf, err := json.Marshal(data)
	if err != nil {
		logger.Errorf("marsh json fail, e: %v", err)
		return
	}
	_ = mq.MiniGunSpooferTracerLogBroker.Publish(mq.MiniGunSpooferTracerLogTopic, broker.NewMessage(buf))
	logger.Infof("pub topic: %v, succ", mq.MiniGunSpooferTracerLogTopic)

}

// WriteLog 写库接口
func (n *NavySpooferUnionActionLogDB) WriteLog() {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()

	_, _ = mq.MiniGunSpooferTracerLogBroker.Subscribe(mq.MiniGunSpooferTracerLogTopic, func(event broker2.Event) error {
		entity := bean.NavyGunSpooferLog{}
		if err := json.Unmarshal(event.Message().Body, &entity); err != nil {
			logger.Errorf("unmarshal log fail, e: %v", err)
			return err
		}
		//
		if err := db.GetDB().Table(bean.NavyGunSpooferLog{}.GetTableName()).Create(&entity).Error; err != nil {
			logger.Errorf("write navy spoof_gun_tracer fail, e: %v", err)
			return err
		}
		//
		logger.Infof("write log to db succ, data: %+v", entity)
		return nil
	})
}

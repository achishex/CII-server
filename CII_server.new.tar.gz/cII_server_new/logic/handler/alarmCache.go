package handler

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"

	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
)

type AlarmModel struct{}

func NewAlarmModel() *AlarmModel {
	return &AlarmModel{}
}

func (a *AlarmModel) Insert(alarm bean.Alarm) (int64, error) {
	db.GetDB().Model(&bean.Alarm{}).Where("drone_sn = ? and drone_obj_id = ? and threat_level = ?", alarm.DroneSn, alarm.DroneObjId, alarm.ThreatLevel).Delete(&bean.Alarm{})
	if err := db.GetDB().Model(&bean.Alarm{}).Create(&alarm).Error; err != nil {
		logger.Errorf("insert alarm failed, err: %v", err)
		return 0, err
	}
	return alarm.ID, nil
}

func (a *AlarmModel) Find(droneSn string, droneObjId int64) (int64, string, error) {
	alarmList := make([]bean.Alarm, 0)
	err := db.GetDB().Model(&bean.Alarm{}).Where("drone_sn = ? and drone_obj_id = ?", droneSn, droneObjId).Order("id desc").Find(&alarmList).Error
	if err != nil {
		logger.Errorf("find alarm failed, err: %v", err)
		return 0, "", err
	}
	if len(alarmList) == 0 {
		logger.Debugf("no alarm found droneSn: %s, droneObjId: %d", droneSn, droneObjId)
		return 0, "", nil
	}
	return alarmList[0].EventId, alarmList[0].CreateTime, nil
}

func (a *AlarmModel) Last(droneSn string, threatLevel int32, eventId, droneObjId int64) (*bean.Alarm, error) {
	var alarm bean.Alarm
	err := db.GetDB().Model(&bean.Alarm{}).Where("drone_sn = ? and drone_obj_id = ? and threat_level = ? and event_id = ?", droneSn, droneObjId, threatLevel, eventId).Last(&alarm).Error
	return &alarm, err
}

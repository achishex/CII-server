package handler

import (
	"context"
	"errors"
	"fmt"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
	"gorm.io/gorm"
)

type LogStatus struct {
}

func NewLogStatus() *LogStatus {
	return &LogStatus{}
}
func (w *LogStatus) Insert(ctx context.Context, req *client.LogStatusInsertReq, res *client.LogStatusInsertRsp) error {
	var model bean.LogStatus
	model.Id = req.Id
	model.Sn = req.Sn
	model.Status = req.Status
	model.Path = req.Path

	// check sn
	logger.Info("Into Insert Log Status")
	var logstat bean.LogStatus
	if err := db.GetDB().Model(&bean.LogStatus{}).Where("sn = ?", req.Sn).First(&logstat).Error; err != nil {
		if err == gorm.ErrRecordNotFound {
			if err := db.GetDB().Model(&bean.LogStatus{}).Create(&model).Error; err != nil {
				logger.Errorf("create Log Status error: %v", err)
				return err
			}
			return nil
		}
		logger.Errorf("query Log Status error:", err)
		return err
	}
	return nil
}
func (w *LogStatus) Update(ctx context.Context, req *client.LogStatusUpdateReq, rsp *client.LogStatusUpdateRsp) error {
	var model bean.LogStatus
	model.Sn = req.Sn
	model.Status = req.Status

	r := db.GetDB().Model(&bean.LogStatus{}).Where("sn=?", req.Sn).Updates(&model).RowsAffected
	if r == 0 {
		return fmt.Errorf("update Log Status error: sn=%v no-exist", req.Sn)
	}

	return nil
}

func (w *LogStatus) Deletes(ctx context.Context, req *client.LogStatusDeletesReq, rsp *client.LogStatusDeletesRsp) error {
	var model bean.LogStatus

	err := db.GetDB().Model(&bean.LogStatus{}).Where("sn = ?", req.Sn).Delete(&model).Error
	if err != nil {
		logger.Errorf("delete Log Status error: %v", err)
	}

	return nil
}

func (w *LogStatus) List(ctx context.Context, req *client.LogStatusListReq, rsp *client.LogStatusListRsp) error {
	var list []*bean.LogStatus
	err := db.GetDB().Model(&bean.LogStatus{}).Find(&list).Error
	if err != nil {
		return errors.New("query list failed")
	}
	for _, v := range list {
		var model client.LogInfo
		w.generateRes(&model, *v)
		rsp.StatusList = append(rsp.StatusList, &model)
	}
	return nil
}
func (w *LogStatus) generateRes(model *client.LogInfo, list bean.LogStatus) {
	model.Id = list.Id
	model.Sn = list.Sn
	model.Status = list.Status
	model.Path = list.Path
	model.Proid = list.Proid
}

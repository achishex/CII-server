package handler

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
	"context"
	"database/sql"
	"fmt"
	jsoniter "github.com/json-iterator/go"
	"reflect"
	"strconv"
	"strings"
	"sync"
	"time"
)

type Statist struct {
	once sync.Once
}
type CommonAnalysis struct {
	Sn            string //飞机唯一标识,雷达为ObjId  频谱侦测为飞机名称
	DroneName     string
	Freq          float64
	Height        float64 //高度
	CreateTime    int64   //创建时间
	LastTime      int64   //上一条记录时间
	AvgHeight     float64 //平均高度
	Count         int64   //分析的条数
	DroneYawAngle float64 //无人机角度 平均值
}

const (
	OneDayMillisecond  = 24 * 60 * 60 * 1000
	OneHourMillisecond = 60 * 60 * 1000
	TimeInterval       = 5000 //5秒
)

func NewStatistics() *Statist {
	return &Statist{}
}

func (p *Statist) EventCollect(ctx context.Context, req *client.CollectReq, res *client.CollectRes) error {
	p.once.Do(func() {
		// 开始事件收集，req: 间隔时间(分钟)
		go func() {
			time.Sleep(3 * time.Second)
			logger.Debug("Start Event Collect")
			defer logger.Debug("End Event Collect")

			period := time.Duration(req.Period) * time.Minute
			ticker := time.NewTicker(period)
			defer ticker.Stop()
			before := time.Now().UnixMilli()
			StartAnalysis() //启动服务执行一次分析
			for {
				select {
				case now := <-ticker.C:
					t := now.UnixMilli()
					t0 := before
					before = t
					logger.Debug("定时事件统计: ", t0, "->", t)
					//开始分析
					StartAnalysis()
					logger.Debug("Analysis end")
				}
			}
		}()
	})
	res.Status = 1
	return nil
}

func StartAnalysis() {
	//获取当前时间
	logger.Info("start analysis.")
	nowTime := time.Now().UnixMilli()

	// 读取static表记录
	var statistic bean.StatisticList
	err := db.GetDB().Raw("select * from statistic_list where id = 1").Scan(&statistic).Error
	if err != nil {
		logger.Error("get static table err:", err)
	}
	if nowTime-statistic.LastTime < OneHourMillisecond { //目前时间比表里最后一条记录时间小于1小时  不执行
		logger.Debugf("nowTime is less lastTime,nowTime:%v,lastTime", nowTime, statistic.LastTime)
		return
	}
	//获取所有探测表名
	var record []bean.RecordList
	err = db.GetDB().Raw("SELECT * from record_list").Scan(&record).Error
	if err != nil {
		logger.Error("get record table err:", err)
	}
	//过滤出需要分析的表从statistic_list中获取到last_time 去做比较
	for _, recordList := range record {
		//通过表名截取出日期
		subDate := recordList.DetectTableName[len(recordList.DetectTableName)-8:]
		t, err := time.Parse("20060102", subDate)
		if err != nil {
			logger.Error("date format is err:", err)
			return
		}
		t = time.Date(t.Year(), t.Month(), t.Day(), 0, 0, 0, 0, t.Location())
		tableTime := t.UnixMilli() + OneDayMillisecond
		// 判断当前时间戳是否在指定日期范围内或之前
		if statistic.LastTime <= tableTime {
			logger.Infof("The Last time is within the date:%v,type is:", recordList.DetectTableName, recordList.DevType)
			if recordList.DevType == int32(common.DEV_RADAR) { //分析雷达探测表
				go AnalysisRadarDetect(statistic.LastTime, nowTime, recordList.DetectTableName, recordList.DevType)
			} else if recordList.DevType == int32(common.DEV_V2DRONEID) { //分析Tracer探测表
				go AnalysisTracerDetect(statistic.LastTime, nowTime, recordList.DetectTableName, recordList.DevType)
			} else if recordList.DevType == int32(common.DEV_FPV) { //分析FPV探测表
				go AnalysisFpvDetect(statistic.LastTime, nowTime, recordList.DetectTableName, recordList.DevType)
			} else if recordList.DevType == int32(common.DEV_SFL) { //分析SFL哨兵塔探测表
				go AnalysisSflDetect(statistic.LastTime, nowTime, recordList.DetectTableName, recordList.DevType)
			} else if recordList.DevType == int32(common.DEV_URD360) { //分析URD360坤雷探测表
				//go AnalysisUrd360Detect(statistic.LastTime, nowTime, recordList.DetectTableName, recordList.DevType)
			} else if recordList.DevType == int32(common.DEV_SCREEN) { //分析枪探测表
				go AnalysisGunDetect(statistic.LastTime, nowTime, recordList.DetectTableName, recordList.DevType)
			} else if recordList.DevType == int32(common.DEV_HUNTER_PLATFORM) { //分析枪+云台探测表
				go AnalysisGunCloudDetect(statistic.LastTime, nowTime, recordList.DetectTableName, recordList.DevType)
			}
		}
	}
	// 操作完后 更新 statistic_list 表格中的 last_time 字段
	err = db.GetDB().Table("statistic_list").Where("id = ?", 1).
		Update("last_time", nowTime).Error
	if err != nil {
		logger.Error("Update Statistic_list err:", err)
	}
	logger.Debug("Timed event statistics completed")
	logger.Info("end analysis.")
}

func AnalysisGunCloudDetect(lastTime int64, nowTime int64, tableName string, devType int32) {
	//获取需要分析的数据
	logger.Debugf("Analysis gunCloud Detect Data,lastTime:%v , nowTime:%v , tableName:%v", lastTime, nowTime, tableName)
	var gunCloudList []bean.GunCloudReplayDetectData
	query := fmt.Sprintf("SELECT * FROM `%s` WHERE create_time >= ? AND create_time <= ?", tableName)
	err := db.GetDB().Raw(query, lastTime, nowTime).Scan(&gunCloudList).Error
	if err != nil {
		logger.Error("get gunCloud ReplayDetect table err:", err)
	}

	var gunCloudToDbMap sync.Map
	for _, gunCloudInfo := range gunCloudList {
		if gunCloudInfo.SerialNum == "" {
			gunCloudInfo.SerialNum = gunCloudInfo.DroneName
		}
		if cache, ok := gunCloudToDbMap.Load(gunCloudInfo.SerialNum); !ok { //查询map中是否有该ObjId   没有的话存储，有的话判断本条数据与已经存储的数据的时间间隔

			sflAnalysis := &CommonAnalysis{
				Sn:            gunCloudInfo.SerialNum,
				DroneName:     gunCloudInfo.DroneName,
				Freq:          gunCloudInfo.UFreq,
				Height:        gunCloudInfo.DroneHeight,
				CreateTime:    gunCloudInfo.CreateTime,
				AvgHeight:     gunCloudInfo.DroneHeight,
				LastTime:      gunCloudInfo.CreateTime,
				DroneYawAngle: gunCloudInfo.DroneYawAngle,
				Count:         1,
			}
			gunCloudToDbMap.Store(gunCloudInfo.SerialNum, sflAnalysis)
		} else { //map中存在  比较该条数据与map中数据的时间间隔
			gunCloudMap := cache.(*CommonAnalysis)
			gunCloudMap.AvgHeight = ((gunCloudMap.AvgHeight * float64(gunCloudMap.Count)) + gunCloudInfo.DroneHeight) / float64(gunCloudMap.Count+1)           //更新平均高度
			gunCloudMap.DroneYawAngle = ((gunCloudMap.DroneYawAngle * float64(gunCloudMap.Count)) + gunCloudInfo.DroneYawAngle) / float64(gunCloudMap.Count+1) //
			gunCloudMap.Count = gunCloudMap.Count + 1                                                                                                          //更新条数
			if gunCloudMap.LastTime-gunCloudInfo.CreateTime > TimeInterval {                                                                                   //大于5秒为第二次飞行,存储到数据库，并移除map中该条记录
				start := time.Unix(gunCloudMap.CreateTime/1000, (gunCloudMap.CreateTime%1000)*int64(time.Millisecond))
				end := time.Unix(gunCloudInfo.CreateTime/1000, (gunCloudInfo.CreateTime%1000)*int64(time.Millisecond))
				duration := end.Sub(start)

				flight := bean.FlightList{
					DroneName:     gunCloudInfo.DroneName,
					Freq:          gunCloudInfo.UFreq,
					Vendor:        strings.Split(gunCloudInfo.DroneName, " ")[0],
					DevType:       devType,
					SerialNum:     gunCloudInfo.SerialNum,
					BeginTime:     time.Unix(0, gunCloudMap.CreateTime*int64(time.Millisecond)).Format("2006-01-02 15:04:05"),
					EndTime:       time.Unix(0, gunCloudInfo.CreateTime*int64(time.Millisecond)).Format("2006-01-02 15:04:05"),
					DurationTime:  duration.Minutes(),
					Height:        gunCloudMap.AvgHeight,
					DroneYawAngle: gunCloudMap.DroneYawAngle,
					Protocol:      "Tcp",
				}
				WriteToDbFlight(flight)
				gunCloudToDbMap.Delete(gunCloudInfo.SerialNum)
			} else {
				gunCloudMap.LastTime = gunCloudInfo.CreateTime
				gunCloudToDbMap.Store(gunCloudInfo.SerialNum, gunCloudMap)
			}
		}
	}
	gunCloudToDbMap.Range(func(key, value interface{}) bool {
		gunCloudMap := value.(*CommonAnalysis)
		start := time.Unix(gunCloudMap.CreateTime/1000, (gunCloudMap.CreateTime%1000)*int64(time.Millisecond))
		end := time.Unix(gunCloudMap.LastTime/1000, (gunCloudMap.LastTime%1000)*int64(time.Millisecond))
		duration := end.Sub(start)
		flight := bean.FlightList{
			DroneName:     gunCloudMap.DroneName,
			Freq:          gunCloudMap.Freq,
			Vendor:        strings.Split(gunCloudMap.DroneName, " ")[0],
			DevType:       devType,
			SerialNum:     gunCloudMap.Sn,
			BeginTime:     time.Unix(0, gunCloudMap.CreateTime*int64(time.Millisecond)).Format("2006-01-02 15:04:05"),
			EndTime:       time.Unix(0, gunCloudMap.LastTime*int64(time.Millisecond)).Format("2006-01-02 15:04:05"),
			DurationTime:  duration.Minutes(),
			Height:        gunCloudMap.AvgHeight,
			DroneYawAngle: gunCloudMap.DroneYawAngle,
			Protocol:      "Tcp",
		}
		WriteToDbFlight(flight)
		gunCloudToDbMap.Delete(gunCloudMap.Sn)
		return true // 返回 true 继续遍历，返回 false 停止遍历
	})
}
func WriteToDbFlight(flight bean.FlightList) {
	var lock sync.Mutex
	lock.Lock()
	defer lock.Unlock()
	if err := db.GetDB().Table(bean.FlightList{}.TableName()).Create(&flight).Error; err != nil {
		logger.Errorf("Write To Db Flight data, write to db fail, e: %v", err)
	}
}
func AnalysisRadarDetect(lastTime int64, nowTime int64, tableName string, devType int32) {
	//获取需要分析的数据
	logger.Debugf("Analysis Radar Detect Data,lastTime:%v , nowTime:%v , tableName:%v", lastTime, nowTime, tableName)
	var radarList []bean.RadarReplayDetect
	query := fmt.Sprintf("SELECT * FROM `%s` WHERE create_time >= ? AND create_time <= ?", tableName)
	err := db.GetDB().Raw(query, lastTime, nowTime).Scan(&radarList).Error
	if err != nil {
		logger.Error("get RadarReplayDetect table err:", err)
	}

	var radarToDbMap sync.Map
	for _, radarInfo := range radarList {
		if cache, ok := radarToDbMap.Load(radarInfo.ObjId); !ok { //查询map中是否有该ObjId   没有的话存储，有的话判断本条数据与已经存储的数据的时间间隔

			radarAnalysis := &CommonAnalysis{
				Sn:         strconv.Itoa(radarInfo.ObjId),
				Height:     radarInfo.Z,
				CreateTime: radarInfo.CreateTime,
				AvgHeight:  radarInfo.Z,
				LastTime:   radarInfo.CreateTime,
				Count:      1,
			}
			radarToDbMap.Store(radarInfo.ObjId, radarAnalysis)
		} else { //map中存在  比较该条数据与map中数据的时间间隔
			radarMap := cache.(*CommonAnalysis)
			radarMap.AvgHeight = ((radarMap.AvgHeight * float64(radarMap.Count)) + radarInfo.Z) / float64(radarMap.Count+1) //更新条数
			radarMap.Count = radarMap.Count + 1                                                                             //更新平均高度
			if radarMap.LastTime-radarInfo.CreateTime > TimeInterval {                                                      //大于5秒为第二次飞行,存储到数据库，并移除map中该条记录
				start := time.Unix(radarMap.CreateTime/1000, (radarMap.CreateTime%1000)*int64(time.Millisecond))
				end := time.Unix(radarInfo.CreateTime/1000, (radarInfo.CreateTime%1000)*int64(time.Millisecond))
				duration := end.Sub(start)

				flight := bean.FlightList{
					DroneName:    strconv.Itoa(radarInfo.ObjId),
					DevType:      devType,
					SerialNum:    strconv.Itoa(radarInfo.ObjId),
					BeginTime:    time.Unix(0, radarMap.CreateTime*int64(time.Millisecond)).Format("2006-01-02 15:04:05"),
					EndTime:      time.Unix(0, radarInfo.CreateTime*int64(time.Millisecond)).Format("2006-01-02 15:04:05"),
					DurationTime: duration.Minutes(),
					Height:       radarMap.AvgHeight,
					Protocol:     "Tcp",
				}
				WriteToDbFlight(flight)
				radarToDbMap.Delete(radarInfo.ObjId)
			} else {
				radarMap.LastTime = radarInfo.CreateTime
				radarToDbMap.Store(radarInfo.ObjId, radarMap)
			}
		}
	}
	radarToDbMap.Range(func(key, value interface{}) bool {
		radarMap := value.(*CommonAnalysis)
		start := time.Unix(radarMap.CreateTime/1000, (radarMap.CreateTime%1000)*int64(time.Millisecond))
		end := time.Unix(radarMap.LastTime/1000, (radarMap.LastTime%1000)*int64(time.Millisecond))
		duration := end.Sub(start)
		flight := bean.FlightList{
			DroneName:    radarMap.Sn,
			Freq:         radarMap.Freq,
			Vendor:       strings.Split(radarMap.DroneName, " ")[0],
			DevType:      devType,
			SerialNum:    radarMap.Sn,
			BeginTime:    time.Unix(0, radarMap.CreateTime*int64(time.Millisecond)).Format("2006-01-02 15:04:05"),
			EndTime:      time.Unix(0, radarMap.LastTime*int64(time.Millisecond)).Format("2006-01-02 15:04:05"),
			DurationTime: duration.Minutes(),
			Height:       radarMap.AvgHeight,
			Protocol:     "Tcp",
		}
		WriteToDbFlight(flight)
		radarToDbMap.Delete(radarMap.Sn)
		return true // 返回 true 继续遍历，返回 false 停止遍历
	})
}

func AnalysisTracerDetect(lastTime int64, nowTime int64, tableName string, devType int32) {
	//获取需要分析的数据
	logger.Debugf("Analysis Tracer Detect Data,lastTime:%v , nowTime:%v , tableName:%v", lastTime, nowTime, tableName)
	var tracerList []bean.TracerReplayDetect
	query := fmt.Sprintf("SELECT * FROM `%s` WHERE create_time >= ? AND create_time <= ?", tableName)
	err := db.GetDB().Raw(query, lastTime, nowTime).Scan(&tracerList).Error
	if err != nil {
		logger.Error("get TracerReplayDetect table err:", err)
	}

	var tracerToDbMap sync.Map
	for _, tracerInfo := range tracerList {
		if cache, ok := tracerToDbMap.Load(tracerInfo.SerialNum); !ok { //查询map中是否有该ObjId   没有的话存储，有的话判断本条数据与已经存储的数据的时间间隔

			tracerAnalysis := &CommonAnalysis{
				Sn:            tracerInfo.SerialNum,
				DroneName:     tracerInfo.DroneName,
				Freq:          tracerInfo.Freq,
				Height:        tracerInfo.DroneHeight,
				CreateTime:    tracerInfo.CreateTime,
				AvgHeight:     tracerInfo.DroneHeight,
				LastTime:      tracerInfo.CreateTime,
				Count:         1,
				DroneYawAngle: tracerInfo.DroneYawAngle,
			}
			tracerToDbMap.Store(tracerInfo.SerialNum, tracerAnalysis)
		} else { //map中存在  比较该条数据与map中数据的时间间隔
			tracerMap := cache.(*CommonAnalysis)
			tracerMap.AvgHeight = ((tracerMap.AvgHeight * float64(tracerMap.Count)) + tracerInfo.DroneHeight) / float64(tracerMap.Count+1)           //更新条数
			tracerMap.DroneYawAngle = ((tracerMap.DroneYawAngle * float64(tracerMap.Count)) + tracerInfo.DroneYawAngle) / float64(tracerMap.Count+1) //更新条数
			tracerMap.Count = tracerMap.Count + 1                                                                                                    //更新平均高度
			if tracerMap.LastTime-tracerInfo.CreateTime > TimeInterval {                                                                             //大于5秒为第二次飞行,存储到数据库，并移除map中该条记录
				start := time.Unix(tracerMap.CreateTime/1000, (tracerMap.CreateTime%1000)*int64(time.Millisecond))
				end := time.Unix(tracerInfo.CreateTime/1000, (tracerInfo.CreateTime%1000)*int64(time.Millisecond))
				duration := end.Sub(start)

				flight := bean.FlightList{
					DroneName:     tracerInfo.DroneName,
					Freq:          tracerInfo.Freq,
					Vendor:        strings.Split(tracerInfo.DroneName, " ")[0],
					DevType:       devType,
					SerialNum:     tracerInfo.SerialNum,
					BeginTime:     time.Unix(0, tracerMap.CreateTime*int64(time.Millisecond)).Format("2006-01-02 15:04:05"),
					EndTime:       time.Unix(0, tracerInfo.CreateTime*int64(time.Millisecond)).Format("2006-01-02 15:04:05"),
					DurationTime:  duration.Minutes(),
					Height:        tracerMap.AvgHeight,
					DroneYawAngle: tracerMap.DroneYawAngle,
					Protocol:      "Tcp",
				}
				WriteToDbFlight(flight)
				tracerToDbMap.Delete(tracerInfo.SerialNum)
			} else {
				tracerMap.LastTime = tracerInfo.CreateTime
				tracerToDbMap.Store(tracerInfo.SerialNum, tracerMap)
			}
		}
	}
	tracerToDbMap.Range(func(key, value interface{}) bool {
		tracerMap := value.(*CommonAnalysis)
		start := time.Unix(tracerMap.CreateTime/1000, (tracerMap.CreateTime%1000)*int64(time.Millisecond))
		end := time.Unix(tracerMap.LastTime/1000, (tracerMap.LastTime%1000)*int64(time.Millisecond))
		duration := end.Sub(start)
		flight := bean.FlightList{
			DroneName:     tracerMap.DroneName,
			Freq:          tracerMap.Freq,
			Vendor:        strings.Split(tracerMap.DroneName, " ")[0],
			DevType:       devType,
			SerialNum:     tracerMap.Sn,
			BeginTime:     time.Unix(0, tracerMap.CreateTime*int64(time.Millisecond)).Format("2006-01-02 15:04:05"),
			EndTime:       time.Unix(0, tracerMap.LastTime*int64(time.Millisecond)).Format("2006-01-02 15:04:05"),
			DurationTime:  duration.Minutes(),
			Height:        tracerMap.AvgHeight,
			DroneYawAngle: tracerMap.DroneYawAngle,
			Protocol:      "Tcp",
		}
		WriteToDbFlight(flight)
		tracerToDbMap.Delete(tracerMap.Sn)
		return true // 返回 true 继续遍历，返回 false 停止遍历
	})
}
func AnalysisFpvDetect(lastTime int64, nowTime int64, tableName string, devType int32) {
	//获取需要分析的数据
	logger.Debugf("Analysis Fpv Detect Data,lastTime:%v , nowTime:%v , tableName:%v", lastTime, nowTime, tableName)
	var fpvList []bean.FpvReplayDetectData
	query := fmt.Sprintf("SELECT * FROM `%s` WHERE create_time >= ? AND create_time <= ?", tableName)
	err := db.GetDB().Raw(query, lastTime, nowTime).Scan(&fpvList).Error
	if err != nil {
		logger.Error("get FpvReplayDetect table err:", err)
	}

	var fpvToDbMap sync.Map
	for _, fpvInfo := range fpvList {
		if cache, ok := fpvToDbMap.Load(fpvInfo.DroneName); !ok { //查询map中是否有该ObjId   没有的话存储，有的话判断本条数据与已经存储的数据的时间间隔

			fpvAnalysis := &CommonAnalysis{
				Sn:            fpvInfo.DroneName,
				DroneName:     fpvInfo.DroneName,
				Freq:          fpvInfo.UFreq,
				CreateTime:    fpvInfo.CreateTime,
				LastTime:      fpvInfo.CreateTime,
				DroneYawAngle: fpvInfo.DroneHorizon,
				Count:         1,
			}
			fpvToDbMap.Store(fpvInfo.DroneName, fpvAnalysis)
		} else { //map中存在  比较该条数据与map中数据的时间间隔
			fpvMap := cache.(*CommonAnalysis)
			fpvMap.DroneYawAngle = ((fpvMap.DroneYawAngle * float64(fpvMap.Count)) + fpvInfo.DroneHorizon) / float64(fpvMap.Count+1) //更新条数
			fpvMap.Count = fpvMap.Count + 1                                                                                          //
			if fpvMap.LastTime-fpvInfo.CreateTime > TimeInterval {                                                                   //大于5秒为第二次飞行,存储到数据库，并移除map中该条记录
				start := time.Unix(fpvMap.CreateTime/1000, (fpvMap.CreateTime%1000)*int64(time.Millisecond))
				end := time.Unix(fpvInfo.CreateTime/1000, (fpvInfo.CreateTime%1000)*int64(time.Millisecond))
				duration := end.Sub(start)

				flight := bean.FlightList{
					DroneName:     fpvInfo.DroneName,
					Freq:          fpvInfo.UFreq,
					Vendor:        strings.Split(fpvInfo.DroneName, " ")[0],
					DevType:       devType,
					SerialNum:     fpvInfo.DroneName,
					BeginTime:     time.Unix(0, fpvMap.CreateTime*int64(time.Millisecond)).Format("2006-01-02 15:04:05"),
					EndTime:       time.Unix(0, fpvInfo.CreateTime*int64(time.Millisecond)).Format("2006-01-02 15:04:05"),
					DurationTime:  duration.Minutes(),
					DroneYawAngle: fpvMap.DroneYawAngle,
					Protocol:      "Tcp",
				}
				WriteToDbFlight(flight)
				fpvToDbMap.Delete(fpvInfo.DroneName)
			} else {
				fpvMap.LastTime = fpvInfo.CreateTime
				fpvToDbMap.Store(fpvInfo.DroneName, fpvMap)
			}
		}
	}
	fpvToDbMap.Range(func(key, value interface{}) bool {
		fpvMap := value.(*CommonAnalysis)
		start := time.Unix(fpvMap.CreateTime/1000, (fpvMap.CreateTime%1000)*int64(time.Millisecond))
		end := time.Unix(fpvMap.LastTime/1000, (fpvMap.LastTime%1000)*int64(time.Millisecond))
		duration := end.Sub(start)
		flight := bean.FlightList{
			DroneName:     fpvMap.DroneName,
			Freq:          fpvMap.Freq,
			Vendor:        strings.Split(fpvMap.DroneName, " ")[0],
			DevType:       devType,
			SerialNum:     fpvMap.DroneName,
			BeginTime:     time.Unix(0, fpvMap.CreateTime*int64(time.Millisecond)).Format("2006-01-02 15:04:05"),
			EndTime:       time.Unix(0, fpvMap.LastTime*int64(time.Millisecond)).Format("2006-01-02 15:04:05"),
			DurationTime:  duration.Minutes(),
			DroneYawAngle: fpvMap.DroneYawAngle,
			Protocol:      "Tcp",
		}
		WriteToDbFlight(flight)
		fpvToDbMap.Delete(fpvMap.Sn)
		return true // 返回 true 继续遍历，返回 false 停止遍历
	})
}

// AnalysisGunDetect 反制枪数据回放没有做、暂时不分析
func AnalysisGunDetect(lastTime int64, nowTime int64, tableName string, devType int32) {
	//	//获取需要分析的数据
	//	logger.Debugf("Analysis Gun Detect Data,lastTime:%v , nowTime:%v , tableName:%v", lastTime, nowTime, tableName)
	//	var gunList []bean.GunReplayHeartData
	//	query := fmt.Sprintf("SELECT * FROM `%s` WHERE create_time >= ? AND create_time <= ?", tableName)
	//	err := db.GetDB().Raw(query, lastTime, nowTime).Scan(&gunList).Error
	//	if err != nil {
	//		logger.Error("get GunReplayHeartData table err:", err)
	//	}
	//
	//	var gunToDbMap sync.Map
	//	for _, gunInfo := range gunList {
	//		if cache, ok := gunToDbMap.Load(gunInfo.SerialNum); !ok { //查询map中是否有该ObjId   没有的话存储，有的话判断本条数据与已经存储的数据的时间间隔
	//
	//			tracerAnalysis := &CommonAnalysis{
	//				Sn:         gunInfo.SatellitesNum,
	//				DroneName:  gunInfo.DroneName,
	//				Freq:       gunInfo.Freq,
	//				height:     gunInfo.DroneHeight,
	//				CreateTime: gunInfo.CreateTime,
	//				AvgHeight:  gunInfo.DroneHeight,
	//				LastTime:   gunInfo.CreateTime,
	//				Count:      1,
	//			}
	//			gunToDbMap.Store(gunInfo.SerialNum, tracerAnalysis)
	//		} else { //map中存在  比较该条数据与map中数据的时间间隔
	//			tracerMap := cache.(*CommonAnalysis)
	//			tracerMap.AvgHeight = ((tracerMap.AvgHeight * float64(tracerMap.Count)) + gunInfo.DroneHeight) / float64(tracerMap.Count+1) //更新条数
	//			tracerMap.Count = tracerMap.Count + 1                                                                                          //更新平均高度
	//			if tracerMap.LastTime-gunInfo.CreateTime > TimeInterval {                                                                           //大于5秒为第二次飞行,存储到数据库，并移除map中该条记录
	//				start := time.Unix(tracerMap.CreateTime/1000, (tracerMap.CreateTime%1000)*int64(time.Millisecond))
	//				end := time.Unix(gunInfo.CreateTime/1000, (gunInfo.CreateTime%1000)*int64(time.Millisecond))
	//				duration := end.Sub(start)
	//
	//				flight := bean.FlightList{
	//					DroneName:    gunInfo.DroneName,
	//					Freq:         gunInfo.Freq,
	//					Vendor:       strings.Split(gunInfo.DroneName, " ")[0],
	//					DevType:      devType,
	//					SerialNum:    gunInfo.SerialNum,
	//					BeginTime:    time.Unix(0, tracerMap.CreateTime*int64(time.Millisecond)).Format("2006-01-02 15:04:05"),
	//					EndTime:      time.Unix(0, gunInfo.CreateTime*int64(time.Millisecond)).Format("2006-01-02 15:04:05"),
	//					DurationTime: duration.Minutes(),
	//					Height:       tracerMap.AvgHeight,
	//					Protocol:     "Tcp",
	//				}
	//				WriteToDbFlight(flight)
	//				gunToDbMap.Delete(gunInfo.SerialNum)
	//			} else {
	//				tracerMap.LastTime = gunInfo.CreateTime
	//				gunToDbMap.Store(gunInfo.SerialNum, tracerMap)
	//			}
	//		}
	//	}
	//	gunToDbMap.Range(func(key, value interface{}) bool {
	//		tracerMap := value.(*CommonAnalysis)
	//		start := time.Unix(tracerMap.CreateTime/1000, (tracerMap.CreateTime%1000)*int64(time.Millisecond))
	//		end := time.Unix(tracerMap.LastTime/1000, (tracerMap.LastTime%1000)*int64(time.Millisecond))
	//		duration := end.Sub(start)
	//		flight := bean.FlightList{
	//			DroneName:    tracerMap.DroneName,
	//			Freq:         tracerMap.Freq,
	//			Vendor:       strings.Split(tracerMap.DroneName, " ")[0],
	//			DevType:      devType,
	//			SerialNum:    tracerMap.Sn,
	//			BeginTime:    time.Unix(0, tracerMap.CreateTime*int64(time.Millisecond)).Format("2006-01-02 15:04:05"),
	//			EndTime:      time.Unix(0, tracerMap.LastTime*int64(time.Millisecond)).Format("2006-01-02 15:04:05"),
	//			DurationTime: duration.Minutes(),
	//			Height:       tracerMap.AvgHeight,
	//			Protocol:     "Tcp",
	//		}
	//		WriteToDbFlight(flight)
	//		gunToDbMap.Delete(tracerMap.Sn)
	//		return true // 返回 true 继续遍历，返回 false 停止遍历
	//	})
}
func AnalysisSflDetect(lastTime int64, nowTime int64, tableName string, devType int32) {
	//获取需要分析的数据
	logger.Debugf("Analysis Sfl Detect Data,lastTime:%v , nowTime:%v , tableName:%v", lastTime, nowTime, tableName)
	var sflList []bean.SFLReplayDetectData
	query := fmt.Sprintf("SELECT * FROM `%s` WHERE create_time >= ? AND create_time <= ?", tableName)
	err := db.GetDB().Raw(query, lastTime, nowTime).Scan(&sflList).Error
	if err != nil {
		logger.Error("get SflReplayDetect table err:", err)
	}

	var sflToDbMap sync.Map
	for _, sflInfo := range sflList {
		if sflInfo.SerialNum == "" {
			sflInfo.SerialNum = sflInfo.DroneName
		}
		if cache, ok := sflToDbMap.Load(sflInfo.SerialNum); !ok { //查询map中是否有该ObjId   没有的话存储，有的话判断本条数据与已经存储的数据的时间间隔

			sflAnalysis := &CommonAnalysis{
				Sn:            sflInfo.SerialNum,
				DroneName:     sflInfo.DroneName,
				Freq:          sflInfo.UFreq,
				Height:        sflInfo.DroneHeight,
				CreateTime:    sflInfo.CreateTime,
				AvgHeight:     sflInfo.DroneHeight,
				LastTime:      sflInfo.CreateTime,
				DroneYawAngle: sflInfo.DroneYawAngle,
				Count:         1,
			}
			sflToDbMap.Store(sflInfo.SerialNum, sflAnalysis)
		} else { //map中存在  比较该条数据与map中数据的时间间隔
			sflMap := cache.(*CommonAnalysis)
			sflMap.AvgHeight = ((sflMap.AvgHeight * float64(sflMap.Count)) + sflInfo.DroneHeight) / float64(sflMap.Count+1)           //更新平均高度
			sflMap.DroneYawAngle = ((sflMap.DroneYawAngle * float64(sflMap.Count)) + sflInfo.DroneYawAngle) / float64(sflMap.Count+1) //
			sflMap.Count = sflMap.Count + 1                                                                                           //更新条数
			if sflMap.LastTime-sflInfo.CreateTime > TimeInterval {                                                                    //大于5秒为第二次飞行,存储到数据库，并移除map中该条记录
				start := time.Unix(sflMap.CreateTime/1000, (sflMap.CreateTime%1000)*int64(time.Millisecond))
				end := time.Unix(sflInfo.CreateTime/1000, (sflInfo.CreateTime%1000)*int64(time.Millisecond))
				duration := end.Sub(start)

				flight := bean.FlightList{
					DroneName:     sflInfo.DroneName,
					Freq:          sflInfo.UFreq,
					Vendor:        strings.Split(sflInfo.DroneName, " ")[0],
					DevType:       devType,
					SerialNum:     sflInfo.SerialNum,
					BeginTime:     time.Unix(0, sflMap.CreateTime*int64(time.Millisecond)).Format("2006-01-02 15:04:05"),
					EndTime:       time.Unix(0, sflInfo.CreateTime*int64(time.Millisecond)).Format("2006-01-02 15:04:05"),
					DurationTime:  duration.Minutes(),
					Height:        sflMap.AvgHeight,
					DroneYawAngle: sflMap.DroneYawAngle,
					Protocol:      "Tcp",
				}
				WriteToDbFlight(flight)
				sflToDbMap.Delete(sflInfo.SerialNum)
			} else {
				sflMap.LastTime = sflInfo.CreateTime
				sflToDbMap.Store(sflInfo.SerialNum, sflMap)
			}
		}
	}
	sflToDbMap.Range(func(key, value interface{}) bool {
		sflMap := value.(*CommonAnalysis)
		start := time.Unix(sflMap.CreateTime/1000, (sflMap.CreateTime%1000)*int64(time.Millisecond))
		end := time.Unix(sflMap.LastTime/1000, (sflMap.LastTime%1000)*int64(time.Millisecond))
		duration := end.Sub(start)
		flight := bean.FlightList{
			DroneName:     sflMap.DroneName,
			Freq:          sflMap.Freq,
			Vendor:        strings.Split(sflMap.DroneName, " ")[0],
			DevType:       devType,
			SerialNum:     sflMap.Sn,
			BeginTime:     time.Unix(0, sflMap.CreateTime*int64(time.Millisecond)).Format("2006-01-02 15:04:05"),
			EndTime:       time.Unix(0, sflMap.LastTime*int64(time.Millisecond)).Format("2006-01-02 15:04:05"),
			DurationTime:  duration.Minutes(),
			Height:        sflMap.AvgHeight,
			DroneYawAngle: sflMap.DroneYawAngle,
			Protocol:      "Tcp",
		}
		WriteToDbFlight(flight)
		sflToDbMap.Delete(sflMap.Sn)
		return true // 返回 true 继续遍历，返回 false 停止遍历
	})
}
func AnalysisUrd360Detect(lastTime int64, nowTime int64, tableName string, devType int32) {
	//获取需要分析的数据
	logger.Debugf("Analysis Urd360 Detect Data,lastTime:%v , nowTime:%v , tableName:%v", lastTime, nowTime, tableName)
	var urdList []UrdDroneInfoReplay
	query := fmt.Sprintf("SELECT * FROM `%s` WHERE create_time >= ? AND create_time <= ?", tableName)
	err := db.GetDB().Raw(query, lastTime, nowTime).Scan(&urdList).Error
	if err != nil {
		logger.Error("get UrdDroneInfoReplay table err:", err)
	}

	var urd360ToDbMap sync.Map
	for _, urd360Info := range urdList {
		if cache, ok := urd360ToDbMap.Load(urd360Info.UniqueID); !ok { //查询map中是否有该ObjId   没有的话存储，有的话判断本条数据与已经存储的数据的时间间隔

			urd360Analysis := &CommonAnalysis{
				Sn:         urd360Info.UniqueID,
				DroneName:  urd360Info.UniqueID,
				Freq:       urd360Info.Frequency,
				Height:     float64(urd360Info.Height),
				CreateTime: urd360Info.CreateTime,
				AvgHeight:  float64(urd360Info.Height),
				LastTime:   urd360Info.CreateTime,
				Count:      1,
			}
			urd360ToDbMap.Store(urd360Info.UniqueID, urd360Analysis)
		} else { //map中存在  比较该条数据与map中数据的时间间隔
			urd360Map := cache.(*CommonAnalysis)
			urd360Map.AvgHeight = ((urd360Map.AvgHeight * float64(urd360Map.Count)) + float64(urd360Info.Height)) / float64(urd360Map.Count+1) //更新条数
			urd360Map.Count = urd360Map.Count + 1                                                                                              //更新平均高度
			if urd360Map.LastTime-urd360Info.CreateTime > TimeInterval {                                                                       //大于5秒为第二次飞行,存储到数据库，并移除map中该条记录
				start := time.Unix(urd360Map.CreateTime/1000, (urd360Map.CreateTime%1000)*int64(time.Millisecond))
				end := time.Unix(urd360Info.CreateTime/1000, (urd360Info.CreateTime%1000)*int64(time.Millisecond))
				duration := end.Sub(start)

				flight := bean.FlightList{
					DroneName: urd360Info.UniqueID,
					Freq:      urd360Info.Frequency,
					//Vendor:       strings.Split(urd360Info.DroneName, " ")[0],
					DevType:      devType,
					SerialNum:    urd360Info.UniqueID,
					BeginTime:    time.Unix(0, urd360Map.CreateTime*int64(time.Millisecond)).Format("2006-01-02 15:04:05"),
					EndTime:      time.Unix(0, urd360Info.CreateTime*int64(time.Millisecond)).Format("2006-01-02 15:04:05"),
					DurationTime: duration.Minutes(),
					Height:       urd360Map.AvgHeight,
					Protocol:     "Tcp",
				}
				WriteToDbFlight(flight)
				urd360ToDbMap.Delete(urd360Info.UniqueID)
			} else {
				urd360Map.LastTime = urd360Info.CreateTime
				urd360ToDbMap.Store(urd360Info.UniqueID, urd360Map)
			}
		}
	}
	urd360ToDbMap.Range(func(key, value interface{}) bool {
		urd360Map := value.(*CommonAnalysis)
		start := time.Unix(urd360Map.CreateTime/1000, (urd360Map.CreateTime%1000)*int64(time.Millisecond))
		end := time.Unix(urd360Map.LastTime/1000, (urd360Map.LastTime%1000)*int64(time.Millisecond))
		duration := end.Sub(start)
		flight := bean.FlightList{
			DroneName:    urd360Map.DroneName,
			Freq:         urd360Map.Freq,
			Vendor:       strings.Split(urd360Map.DroneName, " ")[0],
			DevType:      devType,
			SerialNum:    urd360Map.Sn,
			BeginTime:    time.Unix(0, urd360Map.CreateTime*int64(time.Millisecond)).Format("2006-01-02 15:04:05"),
			EndTime:      time.Unix(0, urd360Map.LastTime*int64(time.Millisecond)).Format("2006-01-02 15:04:05"),
			DurationTime: duration.Minutes(),
			Height:       urd360Map.AvgHeight,
			Protocol:     "Tcp",
		}
		WriteToDbFlight(flight)
		urd360ToDbMap.Delete(urd360Map.Sn)
		return true // 返回 true 继续遍历，返回 false 停止遍历
	})
}

type Result struct {
	AverageFlightTime float64 `json:"average_flight_time"`
	AverageAltitude   float64 `json:"average_altitude"`
}

func (p *Statist) EventList(ctx context.Context, req *client.EventReq, res *client.EventRsp) error {
	var flightEvents []bean.FlightList
	var result Result
	if req.FindKey == "" {
		err := db.GetDB().Model(&bean.FlightList{}).
			Where("begin_time >= ? AND end_time <= ? and duration_time >= 0", req.BeginTime, req.EndTime).
			Order("begin_time desc").
			Find(&flightEvents).Error
		if err != nil {
			logger.Errorf("query event list error:%v", err)
			return err
		}
	} else { //模糊查询
		err := db.GetDB().Model(&bean.FlightList{}).
			Where("begin_time >= ? AND end_time <= ? and duration_time >= 0", req.BeginTime, req.EndTime).
			Where("drone_name LIKE ? OR vendor LIKE ? OR freq LIKE ? OR serial_num LIKE ? OR height LIKE ? OR drone_yaw_angle LIKE ?", "%"+req.FindKey+"%", "%"+req.FindKey+"%", "%"+req.FindKey+"%", "%"+req.FindKey+"%", "%"+req.FindKey+"%", "%"+req.FindKey+"%").
			Order("begin_time desc").
			Find(&flightEvents).Error
		if err != nil {
			logger.Errorf("query event list error:%v", err)
			return err
		}
	}
	err := db.GetDB().Model(&bean.FlightList{}).
		Select("avg(duration_time) as average_flight_time, avg(height) as average_altitude").
		Where("begin_time >= ? and end_time <= ? and duration_time >= 0", req.BeginTime, req.EndTime).
		Find(&result).Error
	if err != nil {
		logger.Errorf("calculate avg error:%v", err)
		return err
	}
	count := 0
	vendorMap := make(map[string]int32)
	freqMap := make(map[string]int32)
	hourMap := make(map[int]int)
	for _, eventInfo := range flightEvents {
		count++
		if strings.Contains(eventInfo.SerialNum, " ") {
			eventInfo.SerialNum = ""
		}
		if req.FullLoad == true {
			res.EventList = append(res.EventList, &client.Event{
				BeginTime: eventInfo.BeginTime,
				EndTime:   eventInfo.EndTime,
				Duration:  eventInfo.DurationTime,
				Freq:      eventInfo.Freq,
				DroneName: eventInfo.DroneName,
				Protocol:  eventInfo.Protocol,
				SerialNum: eventInfo.SerialNum,
				DevType:   eventInfo.DevType,
			})
		} else {
			for _, devType := range req.DevTypeList { //匹配设备
				if devType.DevType == eventInfo.DevType {
					res.EventList = append(res.EventList, &client.Event{
						BeginTime: eventInfo.BeginTime,
						EndTime:   eventInfo.EndTime,
						Duration:  eventInfo.DurationTime,
						Freq:      eventInfo.Freq,
						DroneName: eventInfo.DroneName,
						Protocol:  eventInfo.Protocol,
						SerialNum: eventInfo.SerialNum,
						DevType:   eventInfo.DevType,
					})
				}
			}
		}

		if eventInfo.Vendor == "" {
			// 统计供应商分布
			eventInfo.Vendor = "unKnow"
		}
		vendorMap[eventInfo.Vendor]++

		if eventInfo.Freq != 0.0 {
			// 统计工作频段分布
			freqKey := fmt.Sprintf("%.2f", eventInfo.Freq)
			freqMap[freqKey]++

		}
		// 统计24小时分布
		parsedTime, err := time.Parse("2006-01-02 15:04:05", eventInfo.BeginTime)
		if err != nil {
			fmt.Printf("Error parsing time: %v\n", err)
			continue
		}

		hour := parsedTime.Hour()
		hourMap[hour]++
	}
	res.Count = int32(count)
	res.DurationAvg = result.AverageFlightTime
	res.HeightAvg = result.AverageAltitude
	// 构建供应商分布列表
	for vendorName, countVendor := range vendorMap {
		vendorScale := float32(countVendor) / float32(len(flightEvents))
		res.VendorList = append(res.VendorList, &client.VendorAvg{
			VendorName:  vendorName,
			Count:       countVendor,
			VendorScale: vendorScale,
		})
	}

	// 构建工作频段分布列表
	for freqName, countFreq := range freqMap {
		freqScale := float32(countFreq) / float32(len(flightEvents))
		res.FreqList = append(res.FreqList, &client.FreqAvg{
			FreqName:  freqName,
			Count:     countFreq,
			FreqScale: freqScale,
		})
	}

	// 构建24小时分布列表
	for hourName, countHour := range hourMap {
		res.HourList = append(res.HourList, &client.HourAvg{
			HourName: int32(hourName),
			Count:    int32(countHour),
		})
	}
	logger.Debug("Event List End")
	return nil
}

func (p *Statist) QueryBySql(ctx context.Context, req *client.QueryBySqlRequest, res *client.QueryBySqlResponse) error {
	logger.Info("query by sql req:", req)
	rows, err := db.GetDB().Raw(req.Sql).Rows()
	if err != nil {
		return err
	}
	defer rows.Close()
	maps := p.scanRowsToMap(rows)
	jsonStr, _ := jsoniter.Marshal(maps)
	res.Result = string(jsonStr)
	return nil
}

func (p *Statist) scanRowsToMap(rows *sql.Rows) []map[string]interface{} {
	res := make([]map[string]interface{}, 0)          //  定义结果 map
	colTypes, _ := rows.ColumnTypes()                 // 列信息
	var rowParam = make([]interface{}, len(colTypes)) // 传入到 rows.Scan 的参数 数组
	var rowValue = make([]interface{}, len(colTypes)) // 接收数据一行列的数组

	for i, colType := range colTypes {
		rowValue[i] = reflect.New(colType.ScanType())           // 跟据数据库参数类型，创建默认值 和类型
		rowParam[i] = reflect.ValueOf(&rowValue[i]).Interface() // 跟据接收的数据的类型反射出值的地址
	}
	// 遍历
	for rows.Next() {
		rows.Scan(rowParam...) // 赋值到 rowValue 中
		record := make(map[string]interface{})
		for i, colType := range colTypes {
			if rowValue[i] == nil {
				record[colType.Name()] = ""
			} else {
				record[colType.Name()] = rowValue[i]
			}
		}
		res = append(res, record)

	}
	return res
}

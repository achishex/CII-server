package handler

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"reflect"
	"strings"
	"sync"
	"time"

	"adasgitlab.autel.com/tools/cuav_server/repo/utils"

	"github.com/allegro/bigcache/v3"

	"adasgitlab.autel.com/tools/cuav_server/entity/utils/helper"

	"adasgitlab.autel.com/tools/cuav_plugin/broker"
	"google.golang.org/protobuf/proto"

	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"gorm.io/gorm"

	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/entity/config"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
)

const (
	SysConfigFpv       int32 = 1
	SysConfigTracerS   int32 = 2
	SysConfigTracerPro int32 = 3
	SysConfigTracerP   int32 = 4
)

type SystemConfig struct {
}

func NewSystemConfig() *SystemConfig {
	return &SystemConfig{}
}

func (s *SystemConfig) Insert(ctx context.Context, req *client.CrudReq, res *client.CrudRes) error {
	var model bean.SystemConfig
	err := db.GetDB().Model(&bean.SystemConfig{}).Where("id = ?", req.Id).First(&model).Error
	if err == nil {
		return errors.New("record already exists")
	}
	if err == gorm.ErrRecordNotFound {
		s.generate(&model, req)
		err := db.GetDB().Model(&bean.SystemConfig{}).Create(&model).Error
		if err != nil {
			logger.Errorf("create system config error:%v", err)
			return err
		}
		return nil
	}
	return err
}

func (s *SystemConfig) Update(ctx context.Context, req *client.CrudReq, res *client.CrudRes) error {
	var model bean.SystemConfig
	s.generate(&model, req)
	err := db.GetDB().Model(&bean.SystemConfig{}).Where("id = ?", req.Id).Save(&model).Error
	if err != nil {
		logger.Errorf("update failed,error:%v", err)
		return err
	}
	var sysconfig bean.SystemConfig
	err = db.GetDB().Model(&bean.SystemConfig{}).First(&sysconfig).Error
	if err != nil {
		logger.Errorf("query system config failed,err:%v", err)
		return err
	}
	config := config.C2ConfigStr{
		Id:            int64(sysconfig.Id),
		Longitude:     sysconfig.Longitude, //围栏区经度
		Latitude:      sysconfig.Latitude,  //围栏区纬度
		Heading:       int64(sysconfig.Heading),
		WarningRadius: sysconfig.WarningRadius,
		CounterRadius: sysconfig.CounterRadius,
		FenceRadius:   sysconfig.FenceRadius,
		ScannerRadius: sysconfig.ScannerRadius,
		Height:        sysconfig.Height,
		C2Longitude:   sysconfig.C2Longitude,
		C2Latitude:    sysconfig.C2Latitude,
	}
	C2Config.Set("c2config", config)
	return nil
}

func (s *SystemConfig) Delete(ctx context.Context, req *client.CrudReq, res *client.CrudRes) error {
	var model bean.SystemConfig
	s.generate(&model, req)
	err := db.GetDB().Model(&bean.SystemConfig{}).Where("id = ?", model.Id).Delete(&model).Error
	if err != nil {
		logger.Errorf("delete failed,error:%v", err)
		return err
	}
	return nil
}

// ModifyLonLat 根据策略更改经纬度
func (s *SystemConfig) ModifyLonLat(ctx context.Context, req *client.UpdateLonLatInfoReq, res *client.UpdateLonLatInfoRsp) error {
	var err error
	res.Code = 1

	var sysConfig bean.SystemConfig
	err = db.GetDB().Model(&bean.SystemConfig{}).First(&sysConfig).Error
	if err != nil {
		logger.Errorf("query system config failed,err:%v", err)
		res.Code = 2
		return err
	}
	//
	if req.GetLatitude() <= 0 {
		logger.Infof("req latitude is nil")
		req.Latitude = sysConfig.Latitude
	}
	if req.GetLongitude() <= 0 {
		logger.Infof("req longitude is nil")
		req.Longitude = sysConfig.Longitude
	}
	// 如果
	if req.GetSceneType() == 1 {
		// 相对围栏区经纬度

		sysConfig.Longitude = req.Longitude
		sysConfig.Latitude = req.Latitude

		err := db.GetDB().Model(&bean.SystemConfig{}).Where("id = ?", sysConfig.Id).Save(&sysConfig).Error
		if err != nil {
			logger.Errorf("update failed,error:%v", err)
			res.Code = 2
			return err
		}

	} else if req.GetSceneType() == 2 || req.GetSceneType() == 3 {
		// 相对侦测设备经纬度; 相对于c2经纬度
		sysConfig.C2Latitude = req.Latitude
		sysConfig.C2Longitude = req.Longitude

		err := db.GetDB().Model(&bean.SystemConfig{}).Where("id = ?", sysConfig.Id).Save(&sysConfig).Error
		if err != nil {
			logger.Errorf("update failed,error:%v", err)
			res.Code = 2
			return err
		}
	}

	GetDroneDistanceProcHandler().WriteToCache(req.GetSceneType())

	config := config.C2ConfigStr{
		Id:            int64(sysConfig.Id),
		Longitude:     sysConfig.Longitude, //围栏区经度
		Latitude:      sysConfig.Latitude,  //围栏区纬度
		Heading:       int64(sysConfig.Heading),
		WarningRadius: sysConfig.WarningRadius,
		CounterRadius: sysConfig.CounterRadius,
		FenceRadius:   sysConfig.FenceRadius,
		ScannerRadius: sysConfig.ScannerRadius,
		Height:        sysConfig.Height,
		C2Longitude:   sysConfig.C2Longitude,
		C2Latitude:    sysConfig.C2Latitude,
	}

	//
	C2Config.Set("c2config", config)

	logger.Infof("set c2config cache: %+v", sysConfig)
	return nil
}
func (s *SystemConfig) GetSystemConfig(ctx context.Context, req *client.ConfigReq, res *client.ConfigRes) error {
	var model bean.SystemConfig
	err := db.GetDB().Model(&bean.SystemConfig{}).First(&model).Error
	if err != nil {
		logger.Errorf("query system config failed,err:%v", err)
		return err
	}
	res.Id = model.Id
	res.Latitude = model.Latitude
	res.Heading = model.Heading
	res.Arch = model.Arch
	res.EType = model.Etype
	res.TerminalId = model.TerminalId
	res.CounterRadius = model.CounterRadius
	res.WarningRadius = model.WarningRadius
	res.FenceRadius = model.FenceRadius
	res.Longitude = model.Longitude
	res.ScannerRadius = model.ScannerRadius
	res.Height = model.Height
	res.C2Longitude = model.C2Longitude
	res.C2Latitude = model.C2Latitude
	return nil
}
func (s *SystemConfig) generate(model *bean.SystemConfig, req *client.CrudReq) {
	model.Id = req.Id
	model.Longitude = req.Longitude
	model.TerminalId = req.TerminalId
	model.Latitude = req.Latitude
	model.Arch = req.Arch
	model.Heading = req.Heading
	model.Etype = req.EType
	model.CounterRadius = req.CounterRadius
	model.WarningRadius = req.WarningRadius
	model.FenceRadius = req.FenceRadius
	model.ScannerRadius = req.ScannerRadius
	model.Height = req.Height
	model.C2Longitude = req.C2Longitude
	model.C2Latitude = req.C2Latitude
}

var notifySysCfgItem *NotifySysCfgData = &NotifySysCfgData{
	NotifyFpvInterval: time.Now(),
}
var notifyTracerSSysCfgItem *NotifySysCfgData = &NotifySysCfgData{
	NotifyFpvInterval: time.Now(),
}

type NotifySysCfgData struct {
	lk                sync.Mutex
	NotifyFpvInterval time.Time
}

func (p *NotifySysCfgData) Lock() {
	p.lk.Lock()
}
func (p *NotifySysCfgData) Unlock() {
	p.lk.Unlock()
}
func (p *NotifySysCfgData) GetTime() time.Time {
	return p.NotifyFpvInterval
}
func (p *NotifySysCfgData) UpdateTime(tm time.Time) {
	p.NotifyFpvInterval = tm
}

func (s *SystemConfig) NotifyFpvConfig(req *client.CrudReq) {
	if req == nil {
		return
	}
	if !FvpOnLineStatus.IsOnLine() {
		return
	}

	notifySysCfgItem.Lock()
	defer notifySysCfgItem.Unlock()

	if time.Since(notifySysCfgItem.GetTime()) < 1*time.Second {
		return
	}
	logger.Infof("update since: %v second", time.Since(notifySysCfgItem.GetTime())/time.Second)

	notifySysCfgItem.UpdateTime(time.Now())
	itemData, err := proto.Marshal(req)
	if err != nil {
		logger.Errorf("marshal sys req msg fail, e: %v", err)
		return
	}

	toWriteDownCfg := &client.SystemConfigInfo{
		MsgType: SysConfigFpv,
		Data:    itemData,
	}

	out, err := proto.Marshal(toWriteDownCfg)
	if err != nil {
		logger.Error("marshal fpv sys config err:", err)
		return
	}

	_ = mq.FpvMsgBroker.Publish(mq.FpvSysConfig, broker.NewMessage(out))
	logger.Infof("has fvp config sys, devSn: %v", "")
}

func GetOnlineTracerSSn() ([]string, []string, []string) {
	var TracerSDevStatus map[string]any = make(map[string]any)
	DevStatusMap.Range(func(k any, v any) bool {
		if reflect.ValueOf(k).Kind() != reflect.String {
			return true
		}
		TracerSDevStatus[k.(string)] = v
		return true
	})

	snList, proSnList, pSnList := []string{}, []string{}, []string{}
	var tracerSnPrefix string = fmt.Sprintf("%d_", common.DEV_V2DRONEID) // %d_%s
	for k, v := range TracerSDevStatus {
		if len(k) <= 0 {
			continue
		}
		index := strings.Index(k, tracerSnPrefix)
		if index <= -1 || index > 0 {
			continue
		}

		droneId, ok := v.(*Device)
		if !ok || droneId == nil {
			continue
		}
		if droneId.SubDeviceType == 9 {
			sns := strings.Split(k, tracerSnPrefix)
			if len(sns) <= 1 || len(sns) > 2 {
				continue
			}
			proSnList = append(proSnList, sns[1])

		} else if droneId.WorkMode == 2 || droneId.WorkMode == 3 { //tracerS
			sns := strings.Split(k, tracerSnPrefix)
			if len(sns) <= 1 || len(sns) > 2 {
				continue
			}
			snList = append(snList, sns[1])
		} else if droneId.WorkMode == 1 { //tracerP
			sns := strings.Split(k, tracerSnPrefix)
			if len(sns) <= 1 || len(sns) > 2 {
				continue
			}
			pSnList = append(pSnList, sns[1])
		}
	}
	return snList, proSnList, pSnList
}
func (s *SystemConfig) NotifyTracerSConfig(req *client.CrudReq) {
	if req == nil {
		return
	}

	snList, proList, plist := GetOnlineTracerSSn()
	if len(snList) <= 0 && len(proList) <= 0 && len(plist) <= 0 {
		//logger.Infof("has not any online tracerS device.")
		return
	}
	//logger.Infof("need to send sys config for tracerS, as has online tracerS")

	notifyTracerSSysCfgItem.Lock()
	defer notifyTracerSSysCfgItem.Unlock()

	if time.Since(notifyTracerSSysCfgItem.GetTime()) < time.Second {
		return
	}

	logger.Infof("update since: %v, last update time: %v",
		time.Since(notifyTracerSSysCfgItem.GetTime()), notifyTracerSSysCfgItem.GetTime())

	notifyTracerSSysCfgItem.UpdateTime(time.Now())
	itemData, err := proto.Marshal(req)
	if err != nil {
		logger.Errorf("marshal sys req msg fail, e: %v", err)
		return
	}
	if len(snList) > 0 {
		toWriteDownCfg := &client.SystemConfigInfo{
			MsgType: SysConfigTracerS,
			Data:    itemData,
		}

		out, err := proto.Marshal(toWriteDownCfg)
		if err != nil {
			logger.Error("marshal tracerS sys config err:", err)
			return
		}

		_ = mq.FpvMsgBroker.Publish(mq.FpvSysConfig, broker.NewMessage(out))
		logger.Infof("has tracerS config sys, devSn: %v", snList)
	}

	if len(proList) > 0 {
		toWriteDownCfg := &client.SystemConfigInfo{
			MsgType: SysConfigTracerPro,
			Data:    itemData,
		}

		out, err := proto.Marshal(toWriteDownCfg)
		if err != nil {
			logger.Error("marshal tracerPro sys config err:", err)
			return
		}

		_ = mq.FpvMsgBroker.Publish(mq.FpvSysConfig, broker.NewMessage(out))
		logger.Infof("has tracerPro config sys, devSn: %v", snList)
	}

	if len(plist) > 0 {
		toWriteDownCfg := &client.SystemConfigInfo{
			MsgType: SysConfigTracerP,
			Data:    itemData,
		}

		out, err := proto.Marshal(toWriteDownCfg)
		if err != nil {
			logger.Error("marshal tracerP sys config err:", err)
			return
		}

		_ = mq.FpvMsgBroker.Publish(mq.FpvSysConfig, broker.NewMessage(out))
		logger.Infof("has tracerP config sys, devSn: %v", snList)
	}

}

var GetUnionLatLonResHandle = utils.SingletonFactory[UnionLatLonResource](nil)

// UnionLatLonResource 定义一个统一的经纬度数据源，用于数据回放使用：
type UnionLatLonResource struct {
	writeDownTimer *helper.GeneralTaskTimer
	tmrDur         string // eg: "1s"
	ctx            context.Context
	CancelFunc     context.CancelFunc
	cache          *bigcache.BigCache //存本地经纬度信息。
}

func (u *UnionLatLonResource) init() {
	u.tmrDur = "800ms"
	u.ctx, u.CancelFunc = context.WithCancel(context.Background())
	u.writeDownTimer = helper.NewGeneralTaskTimer(u.tmrDur, helper.RegisterTaskProcess(u))
	//
	var e error
	u.cache, e = bigcache.New(u.ctx, bigcache.Config{
		Shards:      4,
		LifeWindow:  5 * time.Second,
		CleanWindow: 5 * time.Second,
		Verbose:     false,
	})

	if e != nil {
		logger.Errorf("init cache fail, e: %v", e)
	}
}
func (u *UnionLatLonResource) Run() {
	u.init()
	u.writeDownTimer.DoTask(u.ctx)
	logger.Infof("begin to write down lon, lat data task.")
}

func (u *UnionLatLonResource) StopTask() {
	logger.Infof("stop task for write down lon, lat data now")
	if u.CancelFunc != nil {
		u.CancelFunc()
	}
	u.CancelFunc = nil
}

// Process 具体任务业务逻辑
func (u *UnionLatLonResource) Process() error {
	cfg, exist := C2Config.Get("c2config")
	if exist {
		//if fpv is online, then write down config info.
		req := &client.CrudReq{
			C2Longitude: cfg.C2Longitude,
			C2Latitude:  cfg.C2Latitude,
		}
		sysCfgHandle := new(SystemConfig)

		sysCfgHandle.NotifyFpvConfig(req)
		sysCfgHandle.NotifyTracerSConfig(req)
		return nil
	}

	var keyCache = "local_lon_lat_data"
	var sysConfig bean.SystemConfig
	var cached bool = false

	data, e := u.cache.Get(keyCache)
	if e != nil || len(data) <= 0 {
		e = db.GetDB().Model(&bean.SystemConfig{}).First(&sysConfig).Error
		if e != nil {
			logger.Errorf("query system config failed,err:%v", e)
			return e
		}
		if sysConfig.C2Latitude <= 0 || sysConfig.C2Longitude <= 0 {
			logger.Errorf("get c2 lon,lat value is nil")
		}

		cfgBin, e := json.Marshal(&sysConfig)
		if e != nil || len(cfgBin) <= 0 {
			logger.Errorf("marsh sys config fail, e: %v", e)
			return e
		}
		//
		e = u.cache.Set(keyCache, cfgBin)
		if e != nil {
			logger.Error("set key: %v value to fail", e)
		} else {
			cached = true
		}
	}

	if !cached {
		data, e = u.cache.Get(keyCache)
		if e != nil || len(data) <= 0 {
			logger.Errorf("get lon, lat cache fail, e: %v", e)
			return e
		}
		e = json.Unmarshal(data, &sysConfig)
		if e != nil {
			logger.Errorf("unmarshal fail, e: %v", e)
			return e
		}
	}

	req := &client.CrudReq{
		C2Longitude: sysConfig.C2Longitude,
		C2Latitude:  sysConfig.C2Latitude,
	}
	sysCfgHandle := new(SystemConfig)

	sysCfgHandle.NotifyFpvConfig(req)
	sysCfgHandle.NotifyTracerSConfig(req)
	return nil
}

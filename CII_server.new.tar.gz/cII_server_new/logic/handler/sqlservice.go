package handler

import (
	"context"

	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
)

type SqlSrv struct {
}

func NewSqlSrv() *SqlSrv {
	return &SqlSrv{}
}

func (s *SqlSrv) Exec(ctx context.Context, req *client.ExecReq, res *client.ExecRes) error {
	err := db.SqliteExecSqlFile(req.DbFile, req.SqlFile, req.SqlName)
	if err != nil {
		return err
	}
	return nil
}

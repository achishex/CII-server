package handler

import (
	"context"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	jsoniter "github.com/json-iterator/go"

	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
)

type FenceModel struct{}

func NewFenceModel() *FenceModel {
	return &FenceModel{}
}

func (f *FenceModel) Insert(ctx context.Context, req *client.AddFenceRequest) (*bean.Fences, error) {
	var (
		colorByte []byte
		err       error
	)
	colorByte, err = jsoniter.Marshal(req.Color)
	if err != nil {
		logger.Errorf("Insert Marshal err: %+v", err)
	}
	now := time.Now().Format(layout)
	fences := bean.Fences{
		Name:              req.AreaName,
		AreaType:          req.AreaType,
		Perimeter:         req.Perimeter,
		Area:              req.Area,
		IsCloud:           false,
		CentroidLongitude: req.CentroidLongitude,
		CentroidLatitude:  req.CentroidLatitude,
		Geometry:          req.Geometry,
		CreateTime:        now,
		UpdateTime:        now,
		IsDelete:          false,
		Color:             string(colorByte),
		FenceType:         req.FenceType,
		XRadius:           req.XRadius,
		YRadius:           req.YRadius,
	}
	if err := db.GetDB().Model(&bean.Fences{}).Create(&fences).Error; err != nil {
		logger.Errorf("Insert.Create err: %+v", err)
		return nil, err
	}
	return &fences, nil
}

func (f *FenceModel) First(ctx context.Context, id string) (*bean.Fences, error) {
	var fences bean.Fences
	if err := db.GetDB().Model(&bean.Fences{}).Where("id = ?", id).First(&fences).Error; err != nil {
		logger.Errorf("First err: %+v", err)
		return nil, err
	}
	return &fences, nil
}

func (f *FenceModel) FindByName(ctx context.Context, name string) ([]bean.Fences, error) {
	fences := make([]bean.Fences, 0)
	if err := db.GetDB().Model(&bean.Fences{}).Where("name = ? and is_delete = ? and is_cloud = ?", name, false, false).Find(&fences).Error; err != nil {
		logger.Errorf("First err: %+v", err)
		return nil, err
	}
	return fences, nil
}

func (f *FenceModel) Update(ctx context.Context, id string, field bean.Fences) error {
	if err := db.GetDB().Model(&bean.Fences{}).Where("id= ?", id).Updates(&field).Error; err != nil {
		logger.Errorf("Update err: %+v", err)
		return err
	}
	return nil
}

func (f *FenceModel) List(pageSize, pageNum int) ([]*bean.Fences, int64, error) {
	var (
		count  int64
		fences = make([]*bean.Fences, 0)
	)
	if err := db.GetDB().Model(&bean.Fences{}).Where("is_delete = ? ", false).Count(&count).Error; err != nil {
		logger.Errorf("List.Count err: %+v", err)
		return nil, count, err
	}
	if err := db.GetDB().Model(&bean.Fences{}).Where("is_delete = ? ", false).Limit(pageSize).
		Offset((pageNum - 1) * pageSize).Order("id desc").Find(&fences).Error; err != nil {
		logger.Errorf("List.Find err: %+v", err)
		return nil, count, err
	}
	return fences, count, nil
}

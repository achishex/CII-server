package handler

import (
	"fmt"
	"time"
)

const (
	TimeFormatStr string = "20060102"
)

func CheckIsSameDay(t1Second, t2Second int64) bool {
	t1 := time.Unix(t1Second/1e3, 0)
	y1, m1, d1 := t1.Date()
	t2 := time.Unix(t2Second/1e3, 0)

	y2, m2, d2 := t2.Date()

	if y1 == y2 && m1 == m2 && d1 == d2 {
		return true
	}
	return false
}
func Format20060102OnTime(tm int64) string { //milli
	return time.UnixMilli(tm).Format(TimeFormatStr)
}

type DayTimeInfo struct {
	beginTime int64 //millisecond
	endTime   int64
	mydString string //yearmonthday
}

func (d *DayTimeInfo) String() string {
	if d == nil {
		return ""
	}

	ret := fmt.Sprintf("begin: %v, end: %v, dateFormat: %v", d.beginTime, d.endTime, d.mydString)
	return ret
}

func MinCall[T ~int64 | ~int32](t1, t2 T) T {
	if t1 < t2 {
		return t1
	}
	return t2
}

// SplitTimeByDay() begin, end unit is milli second. and begin, end is in diff day..
func SplitTimeByDay(begin, end int64) []DayTimeInfo {
	ret := []DayTimeInfo{}

	get24Hour := func(v int64) int64 { //millisecond
		tm := time.UnixMilli(v)
		hour24Tm := time.Date(tm.Year(), tm.Month(), tm.Day(), 23, 59, 59, 0, time.Local)
		return hour24Tm.UnixMilli()
	}

	stopCirc := false
	for begin < MinCall(get24Hour(begin), end) {
		if stopCirc {
			break
		}

		endTime := get24Hour(begin)
		if get24Hour(begin) >= end {
			endTime = end
			stopCirc = true
		}

		ret = append(ret, DayTimeInfo{
			beginTime: begin,
			endTime:   endTime,
			mydString: Format20060102OnTime(begin),
		})

		//next day begin.
		tomorrowTime := time.UnixMilli(begin).AddDate(0, 0, 1)
		tomorrowTimeZero := time.Date(tomorrowTime.Year(), tomorrowTime.Month(), tomorrowTime.Day(), 0, 0, 0, 0, time.Local)
		begin = tomorrowTimeZero.UnixMilli()
	}
	return ret
}

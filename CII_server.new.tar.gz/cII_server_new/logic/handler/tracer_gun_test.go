package handler

import (
	"adasgitlab.autel.com/tools/cuav_server/proto/mavlink"
	"encoding/binary"
	"testing"
)

func TestTracerGun(t *testing.T) {
	data := &mavlink.TracerGunGetFreqListResponse{
		GroupNum0: 1,
		GroupNum1: 2,
	}
	for i := 0; i < int(data.GroupNum0); i++ {
		data.FreqList0 = append(data.FreqList0, &mavlink.GroupFreqList{
			//起始频点，单位MHz
			IFreqStart: uint32(i + 100),
			//终止频点，单位MHz
			IFreqStop: uint32(i + 200),
			//1: 使能该组参数
			//0: 去使能该组参数
			GroupEnabled: uint32(i + 300),
		})
	}

	for i := 0; i < int(data.GroupNum1); i++ {
		data.FreqList0 = append(data.FreqList1, &mavlink.GroupFreqList{
			//起始频点，单位MHz
			IFreqStart: uint32(i + 1000),
			//终止频点，单位MHz
			IFreqStop: uint32(i + 2000),
			//1: 使能该组参数
			//0: 去使能该组参数
			GroupEnabled: uint32(i + 3000),
		})
	}

	groupNum0Len := binary.Size(data.GroupNum0)
	t.Logf("group0 nums: %v", groupNum0Len)

	structSize := binary.Size(mavlink.GroupFreqList{})
	t.Logf("struct size: %v", structSize)
}

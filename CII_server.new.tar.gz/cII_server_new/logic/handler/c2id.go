package handler

import (
	"context"
	"errors"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"gorm.io/gorm"

	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
)

type C2UId struct {
}

func NewC2Id() *C2UId {
	return &C2UId{}
}
func (w *C2UId) Insert(ctx context.Context, req *client.C2IdInsertReq, res *client.C2IdInsertRsp) error {
	var model bean.C2Id

	model.C2Id = req.C2Id

	// logger.Info("Into Insert Log ID")
	if db.GetDB() == nil {
		logger.Debug("insert db fail, db is not init ")
		return errors.New(" db is not init ")
	}
	var c2id bean.C2Id
	if err := db.GetDB().Model(&bean.C2Id{}).Where("id = ?", 1).First(&c2id).Error; err != nil {
		if err == gorm.ErrRecordNotFound {
			if err := db.GetDB().Model(&bean.C2Id{}).Create(&model).Error; err != nil {
				logger.Errorf("create c2id error: %v", err)
				return err
			}
			return nil
		}
		logger.Errorf("query c2id error:", err)
		return err
	}
	return nil
}

func (w *C2UId) List(ctx context.Context, req *client.C2IdListReq, rsp *client.C2IdListRsp) error {
	var model bean.C2Id
	ticker := time.NewTicker(100 * time.Millisecond)
	defer ticker.Stop()
	timeout := time.After(3 * time.Second)
	shouldBreak := false
	for {
		select {
		case <-ticker.C:
			if db.GetDB() != nil {
				shouldBreak = true
			}
		case <-timeout:
			logger.Error("let it panic,db not initialized in 3 seconds")
			shouldBreak = true
		}
		if shouldBreak {
			break
		}
		time.Sleep(100 * time.Millisecond)
	}

	err := db.GetDB().Model(&bean.C2Id{}).Find(&model).Error
	if err != nil {
		return errors.New("query C2 Id failed")
	}
	rsp.C2Id = model.C2Id
	return nil
}

func GetDevGuid() string {
	defer func() {
		if err := recover(); err != nil {
			logger.Error("GetDevGuid faile")
		}
	}()

	machGuid := ""
	c2id := &client.C2IdListRsp{}
	err := NewC2Id().List(context.Background(), &client.C2IdListReq{}, c2id)
	if err != nil {
		logger.Error("Cloud Platorm List C2Id err:", err)
	}

	if c2id.C2Id != "" {
		machGuid = c2id.C2Id
	}
	// logger.Info("c2id machGuid:", machGuid)
	return machGuid
}

func (w *C2UId) UpdateByC2Id(ctx context.Context, c2Id string, field map[string]interface{}) error {
	var model bean.C2Id
	err := db.GetDB().Model(&bean.C2Id{}).Where("c2_id=?", c2Id).First(&model).Error
	if err != nil {
		logger.Errorf("UpdateByC2Id First err: %v", err)
		return err
	}
	if err = db.GetDB().Model(&bean.C2Id{}).Where("c2_id=?", c2Id).Updates(field).Error; err != nil {
		logger.Errorf("UpdateByC2Id Updates err: %v", err)
		return err
	}
	return nil
}

func (u *C2UId) QueryByC2SN(ctx context.Context, req *client.QueryByC2SNReq, rsp *client.QueryByC2SNRsp) error {
	var model bean.C2Id
	err := db.GetDB().Model(&bean.C2Id{}).Where("c2_id = ?", req.C2Id).First(&model).Error
	if err != nil {
		logger.Errorf("query domain by name err:%v", err)
		return err
	}
	rsp.Domain = model.Domain
	rsp.SiteName = model.SiteName
	rsp.Sid = model.Sid
	rsp.Tid = model.Tid
	rsp.Token = model.Token
	return nil
}

func (u *C2UId) QueryAllMsgByID(ctx context.Context, ID int32) (*bean.C2IdPlus, error) {

	var model bean.C2IdPlus
	err := db.GetDB().Model(&bean.C2Id{}).Where("id = ?", ID).First(&model).Error
	if err != nil {
		logger.Errorf("query domain by name err:%v", err)
		return nil, err
	}

	return &model, nil
}

package handler

import (
	"context"
	"errors"
	"math"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"gorm.io/gorm"

	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
	"adasgitlab.autel.com/tools/cuav_server/repo/utils"
)

type User struct {
}

func NewUser() *User {
	return &User{}
}

func (u *User) Register(ctx context.Context, req *client.RegisterReq, res *client.RegisterRes) error {
	var model bean.User
	err := db.GetDB().Model(&bean.User{}).Where("name = ?", req.GetName()).First(&model).Error
	if !errors.Is(err, gorm.ErrRecordNotFound) {
		return errors.New("user name is not exists")
	}

	model.Name = req.GetName()
	// model.Password = req.GetPassword()
	model.Password = common.ComputeMD5(req.Password)
	model.Email = req.Email
	model.Gender = req.Gender
	model.Mobile = req.Mobile
	model.PushToken = req.GetPushToken()
	model.NickName = req.NickName
	model.CrtTime = utils.ParseTimeToString(time.Now())
	model.UpdateTime = utils.ParseTimeToString(time.Now())
	model.IsDelete = false
	err = db.GetDB().Create(&model).Error
	if err != nil {
		logger.Errorf("register user error:%v", err)
		res.Code = 1001
		return errors.New("register user fail")
	}
	res.Name = model.Name
	res.Role = model.Role
	res.Email = model.Email
	res.Gender = model.Gender
	res.IsDelete = model.IsDelete
	res.NickName = model.NickName
	res.Mobile = model.Mobile
	res.PushToken = model.PushToken
	return nil
}

func (u *User) generateReq(model *bean.User, req *client.UserCrudReq) {
	model.ID = req.Id
	model.Name = req.Name
	model.Password = req.Password
	model.Mobile = req.Mobile
	model.Gender = req.Gender
	model.Email = req.Email
	model.PushToken = req.PushToken
	model.NickName = req.NickName
	model.Role = req.Role
	if req.UpdateTime == "" {
		model.UpdateTime = utils.ParseTimeToString(time.Now())
	} else {
		model.UpdateTime = req.UpdateTime
	}
	model.IsDelete = req.IsDelete
}

func (u *User) generateUpdateReq(model *bean.User, req *client.UpdateReq) {
	model.ID = req.Id
	model.Name = req.Name
	// model.Password = req.Password
	model.Password = common.ComputeMD5(req.Password)
	model.Mobile = req.Mobile
	model.Email = req.Email
	model.NickName = req.NickName
	model.IsDelete = req.IsDelete
	model.UpdateTime = utils.ParseTimeToString(time.Now())
}

func (u *User) generateRes(res *client.GetUserInfoRes, model *bean.User) {
	res.Id = model.ID
	res.Name = model.Name
	res.Role = model.Role
	res.Email = model.Email
	res.Gender = model.Gender
	res.IsDelete = model.IsDelete
	res.NickName = model.NickName
	res.Mobile = model.Mobile
	res.PushToken = model.PushToken
	res.IsDelete = model.IsDelete
}

func (u *User) Login(ctx context.Context, req *client.LoginReq, res *client.LoginRes) error {
	if req.Name == "" || req.Password == "" {
		return errors.New("username or password can not be empty")
	}
	logger.Debug("req.Password = ", req.Password)
	password := common.ComputeMD5(req.Password)
	var model bean.User
	err := db.GetDB().Model(&bean.User{}).Where("name = ?", req.Name).First(&model).Error
	if err != nil {
		if err == gorm.ErrRecordNotFound {
			return errors.New("user does not exists")
		}
		return errors.New("login fail")
	}
	//pwd := utils.BcryptMake([]byte(loginReq.Password))
	logger.Debug("model.Password = ", model.Password)
	logger.Debug("password = ", password)
	if password != model.Password {
		return errors.New("the password is incorrect")
	}
	if model.IsDelete {
		return errors.New("this user is disable")
	}
	res.Id = model.ID
	res.Role = model.Role
	res.Name = model.Name
	res.NickName = model.NickName
	res.Gender = model.Gender
	res.Mobile = model.Mobile
	res.Email = model.Email
	res.PushToken = model.PushToken
	res.IsDelete = model.IsDelete
	return nil
}

func (u *User) GetUserInfo(ctx context.Context, req *client.GetUserInfoReq, res *client.GetUserInfoRes) error {
	var model bean.User
	err := db.GetDB().Model(&bean.User{}).First(&model, req.Id).Error
	if err != nil {
		err = errors.New("user does not exists")
		return err
	}
	u.generateRes(res, &model)
	return nil
}

func (u *User) Insert(ctx context.Context, req *client.UserCrudReq, res *client.UserCrudRes) error {
	logger.Debugf("req %+v", req)
	req.Password = common.ComputeMD5(req.Password)
	var err error
	var i int64
	err = db.GetDB().Model(&bean.User{}).Where("name = ?", req.Name).Count(&i).Error
	if err != nil {
		res.Code = 1007
		logger.Errorf("Db insert error:%v", err)
		return errors.New("create user fail")
	}
	if i > 0 {
		res.Code = 1006
		err = errors.New("username all ready exists")
		return err
	}
	var model bean.User
	u.generateReq(&model, req)
	err = db.GetDB().Model(&bean.User{}).Create(&model).Error
	if err != nil {
		res.Code = 1007
		logger.Errorf("Db create user error:%v", err)
		return errors.New("create user fail")
	}
	return nil
}

func (u *User) InsertAndUpdate(ctx context.Context, req *client.UserCrudReq, res *client.UserCrudRes) error {
	logger.Debugf("req %+v", req)
	var err error
	var i int64
	err = db.GetDB().Model(&bean.User{}).Where("name = ?", req.Name).Count(&i).Error
	if err != nil {
		res.Code = 1007
		logger.Errorf("Db insert error:%v", err)
		return errors.New("create user fail")
	}
	if i > 0 { //用户存在则更新

		var model bean.User
		u.generateReq(&model, req)
		// 更新updater字段为0
		err = db.GetDB().Model(&bean.User{}).Where("name != ?", req.Name).Update("updater", "0").Error
		if err != nil {
			res.Code = 1007
			logger.Errorf("Db update updater error:%v", err)
			return errors.New("update updater fail")
		}

		err = db.GetDB().Model(&bean.User{}).Where("name = ?", req.Name).Update("updater", "1").Error
		if err != nil {
			res.Code = 1007
			logger.Errorf("Db Updates user error:%v", err)
			return errors.New("Updates user fail")
		}
		if req.Password != "" {
			err = db.GetDB().Model(&bean.User{}).Where("name = ?", req.Name).Update("password", req.Password).Error
			if err != nil {
				res.Code = 1007
				logger.Errorf("Db Updates user password error:%v", err)
				return errors.New("Updates user password fail")
			}
		}

	} else {
		var model bean.User
		u.generateReq(&model, req)
		err = db.GetDB().Model(&bean.User{}).Create(&model).Error
		if err != nil {
			res.Code = 1007
			logger.Errorf("Db create user error:%v", err)
			return errors.New("create user fail")
		}
		err = db.GetDB().Model(&bean.User{}).Where("name = ?", req.Name).Update("updater", "1").Error
		if err != nil {
			res.Code = 1007
			logger.Errorf("Db Updates user error:%v", err)
			return errors.New("Updates user fail")
		}
	}

	return nil
}

func (u *User) GetAllUser(ctx context.Context, req *client.GetAllUserReq, res *client.GetAllUserRes) error {
	var list []*bean.User
	err := db.GetDB().Model(&bean.User{}).Find(&list).Error
	if err != nil {
		return errors.New("query User list failed")
	}
	for _, v := range list {
		var model client.GetUserInfoRes
		u.generate(&model, *v)
		res.User = append(res.User, &model)
	}
	return nil
}
func (u *User) generate(model *client.GetUserInfoRes, list bean.User) {
	model.Name = list.Name
	model.Password = list.Password
	model.Updater = list.Updater
}

func (u *User) Update(ctx context.Context, req *client.UpdateReq, res *client.UserCrudRes) error {
	var model bean.User
	err := db.GetDB().Model(&bean.User{}).Where("id = ?", req.Id).First(&model).Error
	if err != nil {
		if err == gorm.ErrRecordNotFound {
			return errors.New("user does not exits")
		}
		return err
	}
	var i int64
	db.GetDB().Model(&bean.User{}).Where("name = ? and id != ?", req.Name, req.Id).Count(&i)
	if i > 0 {
		err = errors.New("username all ready exists")
		return err
	}
	u.generateUpdateReq(&model, req)
	err = db.GetDB().Model(&bean.User{}).Where("id = ?", req.Id).Save(&model).Error
	if err != nil {
		res.Code = 1008
		logger.Errorf("Db update fail:%v", err)
		return errors.New("update fail")
	}
	return nil
}

func (u *User) ChangePwd(ctx context.Context, req *client.ChangePwdReq, res *client.ChangePwdRes) error {
	var model bean.User
	err := db.GetDB().Model(&bean.User{}).Where("id", req.Id).First(&model).Error
	if err != nil {
		return errors.New("user does not exists")
	}
	if model.Password != common.ComputeMD5(req.OdlPwd) {
		res.Code = 1004
		return errors.New("the password is incorrect")
	}
	model.Password = common.ComputeMD5(req.NewPwd)
	err = db.GetDB().Model(&bean.User{}).Where("id = ?", req.Id).Updates(&model).Error
	if err != nil {
		res.Code = 1008
		return errors.New("update fail")
	}
	return nil
}

func (u *User) UpdateStatus(ctx context.Context, req *client.StatusReq, res *client.StatusRes) error {
	m := map[string]interface{}{
		"id":        req.Id,
		"is_delete": req.IsDelete,
	}
	err := db.GetDB().Table(bean.User{}.TableName()).Where("id = ?", req.Id).Updates(&m).Error
	if err != nil {
		res.Code = 1008
		return errors.New("update fail")
	}
	return nil
}
func (u *User) List(ctx context.Context, req *client.UserListReq, res *client.UserListRes) error {
	var users []*client.User
	if req.Page <= 0 {
		req.Page = 1
	}
	if req.Size <= 0 {
		req.Size = 10
	}
	var i int64
	err := db.GetDB().Model(&bean.User{}).Count(&i).Error
	if err != nil {
		res.Code = 1009
		logger.Errorf("count total record error:%v", err)
		return errors.New("count total record fail")
	}
	t := float64(i)
	t = t / float64(req.Size)
	res.Total = int32(math.Ceil(t))
	err = db.GetDB().Model(&bean.User{}).Limit(int(req.Size)).Offset(int(req.Size * (req.Page - 1))).Order("crt_time desc").Find(&users).Error
	if err != nil {
		logger.Errorf("query list error:", err)
		return errors.New("query list fail")
	}
	res.Users = users
	return nil

}

func (u *User) CheckUserByPhoneOrEmail(ctx context.Context, req *client.UserVerifyReq, res *client.UserVerifyRes) error {
	if req.Phone != "" {
		var i int64
		db.GetDB().Model(&bean.User{}).Where("mobile = ?", req.Phone).Count(&i)
		if i == 0 {
			res.Res = true
		} else {
			res.Res = false
		}
		return nil
	} else {
		var i int64
		db.GetDB().Model(&bean.User{}).Where("email = ?", req.Email).Count(&i)
		if i == 0 {
			res.Res = true
		} else {
			res.Res = false
		}
		return nil
	}
}

func (u *User) ResetPwd(ctx context.Context, req *client.ResetPwdReq, res *client.ResetPwdRes) error {
	logger.Debug("before req = ", req)

	req.NewPwd = common.ComputeMD5(req.NewPwd)

	if req.Email != "" && req.Phone != "" {
		return errors.New("parameter binding fail")
	}
	if req.Email == "" && req.Phone == "" {
		return errors.New("parameter binding fail")
	}
	if req.Phone != "" {
		err := db.GetDB().Model(&bean.User{}).Where("mobile = ? ", req.Phone).Update("password", req.NewPwd).Error
		if err != nil {
			logger.Errorf("reset user password by mobile:%v error:", req.Phone, err)
			return errors.New("reset password fail")
		}
	} else {
		err := db.GetDB().Model(&bean.User{}).Where("email = ? ", req.Email).Update("password", req.NewPwd).Error
		if err != nil {
			logger.Errorf("reset user password by email:%v error:", req.Email, err)
			return errors.New("reset password fail")
		}
	}
	return nil
}

func (u *User) Delete(ctx context.Context, req *client.DeleteReq, res *client.UserCrudRes) error {
	err := db.GetDB().Model(&bean.User{}).Delete(&bean.User{}, &req.Ids).Error
	if err != nil {
		logger.Errorf("delete users error:%v", err)
		return err
	}
	return nil
}

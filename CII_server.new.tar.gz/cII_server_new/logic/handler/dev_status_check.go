package handler

import (
	"context"
	"errors"
	"sync"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/slink_proto/slinkv2"
	"adasgitlab.autel.com/tools/slink_proto/slinkv2/msgid"

	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/rpc/codec"
)

type DevInfoOpsFunc struct {
	devType      int32
	statusCheck  func(sn string) error
	versionFetch func(sn string, ip string) error
}

type DevInfoOpsFuncCollection map[int32]*DevInfoOpsFunc

var (
	devInfoOpsFuncItem  map[int32]*DevInfoOpsFunc
	devStatusChecksOnce sync.Once
)

// GetDevStatusCheckHandle 获取设备状态函数句柄
func GetDevStatusCheckHandle() DevInfoOpsFuncCollection {
	devStatusChecksOnce.Do(func() {
		devInfoOpsFuncItem = make(map[int32]*DevInfoOpsFunc)
	})
	return devInfoOpsFuncItem
}

// RegisterDevOpsProc 注册设备状态检查函数
func RegisterDevOpsProc() {
	GetDevStatusCheckHandle().registerStatusCheck(int32(common.DEV_RADAR), RadarStatusCheck)
	GetDevStatusCheckHandle().registerDevInfoFetch(int32(common.DEV_RADAR), RadarVersionFetch)
	// add others.
}

// registerStatusCheck 内部注册函数
func (m DevInfoOpsFuncCollection) registerStatusCheck(devType int32, proc func(sn string) error) {
	if v, ok := GetDevStatusCheckHandle()[devType]; !ok || v == nil {
		GetDevStatusCheckHandle()[devType] = &DevInfoOpsFunc{
			devType:     devType,
			statusCheck: proc,
		}
		return
	}

	GetDevStatusCheckHandle()[devType].devType = devType
	GetDevStatusCheckHandle()[devType].statusCheck = proc
	return
}

// registerDevInfoFetch 注册设备版本信息
func (m DevInfoOpsFuncCollection) registerDevInfoFetch(devType int32, proc func(sn string, devIp string) error) {
	if v, ok := GetDevStatusCheckHandle()[devType]; !ok || v == nil {
		GetDevStatusCheckHandle()[devType] = &DevInfoOpsFunc{
			devType:      devType,
			versionFetch: proc,
		}
		return
	}

	GetDevStatusCheckHandle()[devType].devType = devType
	GetDevStatusCheckHandle()[devType].versionFetch = proc
}

// MustCheckDevStatus 状态检查函数对某种设备处理
func (m DevInfoOpsFuncCollection) MustCheckDevStatus(devType uint32, sn string) error {
	if m == nil {
		return errors.New("devStatusChecks not been init")
	}

	handle := (map[int32]*DevInfoOpsFunc)(m)
	if op, ok := handle[int32(devType)]; ok && op != nil {
		if e := op.statusCheck(sn); e != nil {
			logger.Errorf("check dev: %v fail, e: %v", sn, e)
			return e
		}
		return nil
	}
	logger.Errorf("not register dev status check proc, devType: %v, sn: %v", devType, sn)
	return errors.New("has not dev check")
}

// FetchDevVersionInfo 查询设备版本号并更新到本地数据库
func (m DevInfoOpsFuncCollection) FetchDevVersionInfo(devType uint32, sn string, devIp string) error {
	if m == nil {
		return errors.New("dev info ops func not been init")
	}
	handle := (map[int32]*DevInfoOpsFunc)(m)
	if op, ok := handle[int32(devType)]; ok && op != nil {
		if e := op.versionFetch(sn, devIp); e != nil {
			logger.Errorf("fetch version fail, e: %v, sn: %v", e, sn)
			return e
		}
	}
	return nil
}

// NeedParallelProcess 判断消息是否需要异步处理。
func (m DevInfoOpsFuncCollection) NeedParallelProcess(protoType uint32, sn string, data any) bool {
	var runType bool = true
	//defer func() {
	//	logger.Infof("run pkg proc type: %v", runType)
	//}()

	if protoType == uint32(codec.SerializationTypePB) {
		var pkg *slinkv2.PacketV2 = data.(*slinkv2.PacketV2)
		if pkg == nil {
			return runType
		}

		if pkg.GetMsgID() >= msgid.RadarIdV2State && pkg.GetSourceID() == uint8(common.DEV_RADAR&0xFF) {
			//logger.Infof("need not parallel run logic, sn: %v, msgId: 0x%X", sn, pkg.GetMsgID())
			runType = false
			return runType
		}
	}
	return runType
}

// GetDevStatus 根据设备类型查询设备的状态。
func GetDevStatus(devType int32, sn string) int32 {
	devTypStr := "radar"
	switch common.DeviceType(devType) {
	case common.DEV_RADAR:
		devTypStr = "radar"

	case common.DEV_SCREEN:
		devTypStr = ""

	case common.DEV_SFL:
		devTypStr = "Sfl"

	case common.DEV_V2DRONEID:
		devTypStr = "DroneID"

	case common.DEV_FPV:
		devTypStr = "Fpv"
	case common.DEV_SFL200:
		devTypStr = "Sfl200"
	case common.DEV_DPH110:
		devTypStr = "Dph110"
	case common.DEV_HUNTER_PLATFORM:
		devTypStr = "GunPlatform"

	default:
		devTypStr = ""
	}

	var radarVersion int32 = 0
	if devType == int32(common.DEV_RADAR) {
		radarVersion = int32(codec.VersionTypeV2)
	}
	statusRes := &client.GetStatusRes{}
	err := NewEquipList().GetStatus(context.Background(), &client.GetStatusReq{Sn: sn, EType: devTypStr}, statusRes, radarVersion)
	if err != nil {
		logger.Errorf("GetStatus err: %v", err.Error())
		return 0
	}
	return statusRes.IsEnable
}

// RadarStatusCheck 注册雷达设备状态检查函数具体实现
func RadarStatusCheck(sn string) error {
	//dbequip := &client.EquipListRes{}
	//err := NewEquipList().List(context.Background(), &client.EquipListReq{}, dbequip)
	//if err != nil {
	//	logger.Error("Get EquipList err: ", err)
	//	return err
	//}

	enable := GetDevStatus(int32(common.DEV_RADAR), sn)
	if enable == common.DeviceDisenable {
		return errors.New("dev is disable")
	}
	return nil
}

// RadarVersionFetch 获取设备的信息并更新数据库
func RadarVersionFetch(sn string, devIp string) error {
	defer func() {
		if e := recover(); e != nil {
			logger.Errorf("get dev version panic, e: %v", e)
			return
		}
	}()

	time.Sleep(2 * time.Second)
	err := NewEquipList().Update(context.Background(), &client.EquipCrudReq{
		Sn:       sn,
		IsOnline: true,
		Ip:       devIp,
	}, &client.EquipCrudRes{})
	if err != nil {
		logger.Error("Update EquipList err: ", err)
	} else {
		logger.Infof("update radar app version to db succ, sn: %v", sn)
	}

	//if conn := connmgr.Instance().GetConn(sn); conn == nil {
	//	logger.Errorf("sn %s getConn is nil", sn)
	//	return nil
	//}
	//
	//logger.Info("Send radar GetVersionInfo Start")
	//dev := FindCacheDevice(sn, common.DEV_RADAR)
	//if dev == nil {
	//	logger.Infof("radar not online, dev: %v", sn)
	//	return nil
	//}
	//
	//d := &Radar{Device: dev}
	//rsp, err := d.RadarGetConfig(sn)
	//logger.Infof("RadarVersionFetch RadarGetConfig: %+v", rsp)
	//if err != nil {
	//	logger.Infof("RadarVersionFetch RadarGetConfig err: %v \n", err)
	//	return nil
	//}
	//if rsp != nil && rsp.GetVersion() != "" {
	//	err = NewEquipList().Update(context.Background(), &client.EquipCrudReq{
	//		Sn:         sn,
	//		DevVersion: rsp.GetVersion(),
	//		IsOnline:   true,
	//		Ip:         devIp,
	//	}, &client.EquipCrudRes{})
	//	if err != nil {
	//		logger.Error("Update EquipList err: ", err)
	//	} else {
	//		logger.Infof("update radar app version to db succ, sn: %v", sn)
	//	}
	//}
	return nil
}

package handler

import (
	"context"
	"fmt"
	"strconv"
	"sync/atomic"
	"time"

	"github.com/allegro/bigcache/v3"

	"adasgitlab.autel.com/tools/cuav_plugin/broker"
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/helper"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
	"google.golang.org/protobuf/proto"
)

const (
	ReplayRunStatusInit    = 0
	ReplayRunStatusRunning = 1
	ReplayRunStatusPaused  = 2
	ReplayRunStatusStop    = 3
)

const (
	ReplayBaseFreqMs = 100 // unit ms
)

// GlobalGetMaxPriorityFunc 获取最大优先级值，直接使用全局变量，然后调用： GenericGetMaxPriority()
var GlobalGetMaxPriorityFunc = NewGetMaxPriority()

type IGetMaxPriority interface {
	GenericGetMaxPriority() int64
}

func NewGetMaxPriority() IGetMaxPriority {
	f := getMaxPriority
	return funcGetMaxPriority(f)
}

func getMaxPriority() int64 {
	tm, _ := time.Parse(time.DateTime, "2100-01-02 15:04:05")
	return tm.UnixMilli()
}

type funcGetMaxPriority func() int64

func (f funcGetMaxPriority) GenericGetMaxPriority() int64 {
	return f()
}

// PQItem 队列元素定义
type PQItem[T any] struct {
	Priority int64 // 标识优先级的字段,目前使用时间戳，毫秒级。
	Index    int   //队列中数据存储的索引号，用户快速更新队列中某个记录
	//定义业务数据类型
	Value T //目前可以存任何数值，基本类型，结构体等。
}

func (p *PQItem[T]) String() string {
	s := fmt.Sprintf("priority: %v, value: %v", p.Priority, p.Value)
	return s
}

// ValueType 定义新类型， 如果业务类型 不是string, 直接 用 type ValueType= 新类型 替换即可。
type ValueType = string

// LocalMem 定义本地缓存对象
type LocalMem struct {
	//您可能会遇到系统内存报告呈指数级增长的情况，但这是预期的行为。
	//Go运行时以块或'span '分配内存，并通过将其状态更改为'idle'来通知操作系统 业务不需要不再需要它们。
	//在操作系统需要重新使用该地址之前，“span”将一直是进程资源使用的一部分。
	cache *bigcache.BigCache
	//config
	Shards             int
	LifeWindow         time.Duration // 30*time.Minute; is a time. After that time, an entry can be called dead but not deleted.
	CleanWindow        time.Duration // 31*time.Minute; is a time. After that time, all the dead entries will be deleted, but not the entries that still have life
	HardMaxCacheSizeMB int32
	MaxEntriesInWindow int32 //空闲窗口的个数.
}

func (l *LocalMem) GetCache() *bigcache.BigCache {
	return l.cache
}
func (l *LocalMem) ResetLocalMem() {
	if l == nil {
		return
	}

	if l.cache == nil {
		return
	}
	l.cache.Reset()
}

type InitLocalMemItem func(*LocalMem)

func GetShardsNums(n int) int {
	if n <= 3 {
		return 2
	}
	x := GetShardsNums(n / 2)
	return x * 2
}
func WithLocalMemCfgShare(s int) InitLocalMemItem {
	if s <= 0 {
		s = 1024
	}
	return func(l *LocalMem) {
		l.Shards = GetShardsNums(s)
	}
}
func WithLocalMemCfgLifWin(tm time.Duration) InitLocalMemItem {
	if tm <= 0 {
		tm = 30 * time.Minute
	}
	return func(l *LocalMem) {
		l.LifeWindow = tm
	}
}
func WithLocalMemCfgCleanWin(tm time.Duration) InitLocalMemItem {
	if tm <= 0 {
		tm = 1 * time.Minute
	}
	return func(l *LocalMem) {
		l.CleanWindow = tm
	}
}
func WithHardMaxCacheSize(szMb int32) InitLocalMemItem {
	if szMb <= 0 {
		szMb = 0
	}

	return func(l *LocalMem) {
		l.HardMaxCacheSizeMB = szMb
	}
}
func WithMaxEntriesInWindow(itemNums int32) InitLocalMemItem {
	if itemNums <= 0 {
		itemNums = QueryItemMaxLen + 100
	}
	//
	return func(l *LocalMem) {
		l.MaxEntriesInWindow = itemNums
	}
}
func InitLocalMem(ctx context.Context, ops ...InitLocalMemItem) *LocalMem {
	l := &LocalMem{}
	for _, f := range ops {
		f(l)
	}

	var e error
	l.cache, e = bigcache.New(ctx, bigcache.Config{
		Shards:             l.Shards,
		LifeWindow:         l.LifeWindow,
		CleanWindow:        l.CleanWindow,
		Verbose:            false,
		HardMaxCacheSize:   int(l.HardMaxCacheSizeMB), //500MB
		MaxEntriesInWindow: int(l.MaxEntriesInWindow),
	})
	//
	if e != nil {
		logger.Errorf("init local mem on big cache fail, e: %v", e)
		return nil
	}
	return l
}

// CreateDefaultLocalMem 业务可以直接调用该方法。
func CreateDefaultLocalMem(ctx context.Context) *LocalMem {
	return InitLocalMem(ctx, WithMaxEntriesInWindow(QueryItemMaxLen+100),
		WithLocalMemCfgShare(128),
		WithLocalMemCfgLifWin(0),
		WithLocalMemCfgCleanWin(0),
		WithHardMaxCacheSize(500))
}
func (l *LocalMem) Get(k string) ([]byte, error) {
	return l.cache.Get(k)
}
func (l *LocalMem) Set(k string, data []byte) error {
	return l.cache.Set(k, data)
}
func (l *LocalMem) Delete(k string) error {
	return l.cache.Delete(k)
}

// ReplayTaskBase 定义任务基本类型
type ReplayTaskBase struct {
	QueueRef     *helper.SkyFendPQWrap[ValueType] // 一个任务维持一个队列
	SingleMemRef *LocalMem                        // 一个任务维持一个本地内存池

	//目前一种业务类型和一个sn共同决定一个任务。
	ReplayType int32  //task type
	Sn         string //sn value
	DevType    int32  //sn type

	//从队列中读取记录的时间上限值，结果就是取 <= boundUnixTimeMs 的记录， boundUnixTimeMs 初始值为start replay begin time
	BoundUnixTimeMs    int64
	TaskMngRef         *DataReplayer //定义管理器索引
	TaskQueueRemainLen int32

	QueryDbEndTime int64 //这个值由请求时携带的字段来确定
	QueryStartTime int64 //用db加载数据来更新 queue中值。初始值用请求参数填充。在load完后，就不再向load进程发通知。
	//
	DefaultQueueSize       int32 //就是每次从db加载数据的个数
	TriggerLoadDbQueueSize int32 //触发从db中加载数据时队列中个数，小于等于该值需要去加载数据
}

func (rb *ReplayTaskBase) BasicInfo() string {
	s := fmt.Sprintf("sn: %v, dev type: %v, task type: %v, bound time: %v, db query start time: %v, end time: %v",
		rb.Sn, helper.DevTypeFromIntToStr(rb.DevType), GetReplayDataTypeDesc(rb.ReplayType), rb.BoundUnixTimeMs, rb.QueryStartTime, rb.QueryDbEndTime)
	return s
}
func (rb *ReplayTaskBase) GetDevSnTaskType() string {
	r := fmt.Sprintf("sn: %v, devType: %v, taskType: %v", rb.Sn, rb.DevType, GetReplayDataTypeDesc(rb.ReplayType))
	return r
}

func (rb *ReplayTaskBase) UpdateLoadDbStartTime(tm int64) {
	if tm <= 0 {
		return
	}
	rb.QueryStartTime = tm
	logger.Infof("update load db start time: %v", tm)
}
func (rb *ReplayTaskBase) GetStartLoadTime() int64 {
	return rb.QueryStartTime
}
func (rb *ReplayTaskBase) GetEndLoadTime() int64 {
	return rb.QueryDbEndTime
}
func (rb *ReplayTaskBase) NeedLoadFromDb() bool {
	if rb.QueryStartTime >= rb.QueryDbEndTime {
		logger.Infof("relay has load all data, sn: %v, busiType: %v, qStartTm: %v, qEndTm: %v",
			rb.Sn, GetReplayDataTypeDesc(rb.ReplayType), rb.QueryStartTime, rb.QueryDbEndTime)

		return false
	}
	if rb.TaskQueueRemainLen > rb.TriggerLoadDbQueueSize {
		logger.Infof("task queue remain len: %v, trigger load queue size: %v,sn: %v,devType: %v, taskType: %v, not load to queue",
			rb.TaskQueueRemainLen, rb.TriggerLoadDbQueueSize, rb.Sn, rb.DevType, GetReplayDataTypeDesc(rb.ReplayType))
		return false
	}

	logger.Infof("need to load msg from db to queue, queue remain item nums: %v, sn: %v, devType: %v, busiType: %v",
		rb.TaskQueueRemainLen, rb.Sn, rb.DevType, GetReplayDataTypeDesc(rb.ReplayType))

	return true
}
func (rb *ReplayTaskBase) GetTaskQRemainLen() int32 {
	return rb.TaskQueueRemainLen
}
func (rb *ReplayTaskBase) GetDevType() int32 {
	return rb.DevType
}
func (rb *ReplayTaskBase) GetLoadDbMsgNums() int32 {
	return rb.DefaultQueueSize
}

func (rb *ReplayTaskBase) FetchData() []*helper.SkyFendPQItem[ValueType] {
	var popList []*helper.SkyFendPQItem[ValueType]

	fetchDataFactor := 1
	dur := int64(ReplayBaseFreqMs * fetchDataFactor) //保持取出数据长度不变，倍数变化只体现在定时器的时间间隔上。
	lastQueryPriority := rb.BoundUnixTimeMs

	//每次只会从队列中取 priority <= rb.BoundUnixTimeMs 的记录。取出后的记录会从队列中删除。
	rb.BoundUnixTimeMs += dur //when timer wake firstly, this func called. boundUnixTimeMs is begin_time + timer_wait_time.

	logger.Infof("last query priority: %v, cur query queue priority: %v, timer wait time: %v ms, task info: %v",
		lastQueryPriority, rb.BoundUnixTimeMs, dur, rb.GetDevSnTaskType())

	popList = rb.QueueRef.PopLesserPriority(rb.BoundUnixTimeMs)

	rb.TaskQueueRemainLen = int32(rb.QueueRef.Len())

	if len(popList) > 0 {
		firstNode, endNode := popList[0], popList[len(popList)-1]

		logger.Infof("get item  nums from queue: %v, %s, first priority: %v, last priority: %v",
			len(popList), rb.GetDevSnTaskType(), firstNode.Priority, endNode.Priority)
	}
	return popList
}

type IReplayTaskAbstract interface {
	BasicInfo() string

	DoTask()
	GetData() [][]byte
	GetDevType() int32
	GetTaskQRemainLen() int32

	NeedLoadFromDb() bool
	GetLoadDbMsgNums() int32

	UpdateLoadDbStartTime(tm int64)
	GetStartLoadTime() int64
	GetEndLoadTime() int64
}

// ReplayDevices 定义设备及类型
type ReplayDevices struct {
	sn      string
	devType int32
}
type ReplayContext struct {
	BeginTime        int64            // millisecond
	EndTime          int64            //millisecond
	Rate             int32            //1,2,3,4,..6
	ReplayDeviceList []*ReplayDevices //回放设备列表
	ReplayDevTypMap  map[string]int32 //回放设备列表映射, key 是sn, value is dev type
}

func (rc *ReplayContext) GetRate() int32 {
	return rc.Rate
}

// NewReplayReduce
func NewReplayReduce() *ReplayReduce {
	r := &ReplayReduce{
		ToReduceData: &client.ReplayMixMsgList{},
	}
	return r
}

type ReplayReduceSimple struct {
	Sn       string
	DevType  int32
	TaskType []int32
	DataNums []int32
}

func (p *ReplayReduceSimple) String() string {
	var s string
	s = fmt.Sprintf("sn: %v, devType:%v, taskType: ", p.Sn, helper.DevTypeFromIntToStr(p.DevType))
	for _, task := range p.TaskType {
		s += " " + GetReplayDataTypeDesc(task)
	}

	s += ", data nums: "
	for _, n := range p.DataNums {
		s += " " + strconv.Itoa(int(n))
	}
	return s
}

type SliceReplayReduceSimple []ReplayReduceSimple

func (s SliceReplayReduceSimple) String() string {
	ret := ""
	st := []ReplayReduceSimple(s)
	for _, v := range st {
		ret += v.String() + " "
	}
	return ret
}

type ReplayReduce struct {
	ToReduceData *client.ReplayMixMsgList
	Simple       []ReplayReduceSimple
}

func (rr *ReplayReduce) AppendReplayDataOnDev(sn string, devType int32) {
	item := &client.ReplayMixMsgItem{
		Sn:      sn,
		DevType: devType,
	}
	rr.ToReduceData.ReplayData = append(rr.ToReduceData.ReplayData, item)

	s := ReplayReduceSimple{
		Sn:      sn,
		DevType: devType,
	}
	rr.Simple = append(rr.Simple, s)
}

func (rr *ReplayReduce) TransReplayData() {
	if rr.ToReduceData == nil {
		return
	}
	if len(rr.ToReduceData.ReplayData) <= 0 {
		logger.Info("replay is empty")
		return
	}
	logger.Infof("send client msg nums: %v, %v", len(rr.ToReduceData.ReplayData),
		SliceReplayReduceSimple(rr.Simple).String())

	msg, err := proto.Marshal(rr.ToReduceData)
	if err != nil {
		logger.Errorf("marshal replay data fail, e: %v", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgReplayTranData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal replay data err:", err)
		return
	}

	_ = mq.DataReplayMix.Publish(mq.ReplayTransMsgTopic, broker.NewMessage(out))
	logger.Infof("publish replay trans msg to client done")
}

func (rr *ReplayReduce) FillDetect(sn string, devType int32, taskType int32, data [][]byte, fillData *client.ReplayMixMsgItem) {
	if fillData == nil {
		return
	}
	if devType == int32(client.EnumDevTypeList_TracerSDevTypeEnum) {
		fillData.FreqDetect = data
		logger.Infof("fill tracerS detect info, sn: %v, devType: %v, taskType: %v, data nums: %v",
			sn, devType, GetReplayDataTypeDesc(taskType), len(fillData.FreqDetect))
	} else {
		fillData.Detect = data
	}
	return
}
func (rr *ReplayReduce) FillReplayDetailOnDev(sn string, devType int32, taskType int32, data [][]byte) {
	if rr.ToReduceData == nil || len(rr.ToReduceData.ReplayData) <= 0 {
		logger.Errorf("not call AppendReplayDataOnDev() before fill detail")
		return
	}
	if len(data) <= 0 {
		logger.Infof("has no data to filled.")
		return
	}

	toFillData := rr.ToReduceData.ReplayData[len(rr.ToReduceData.ReplayData)-1]
	if toFillData == nil {
		logger.Errorf("to fill data item is nil, task Type: %v", GetReplayDataTypeDesc(taskType))
		return
	}

	s := rr.Simple[len(rr.Simple)-1]
	s.TaskType = append(s.TaskType, taskType)
	s.DataNums = append(s.DataNums, int32(len(data)))
	rr.Simple[len(rr.Simple)-1] = s

	switch taskType {
	case ReplayTypeHEART:
		toFillData.HeartBeat = data

	case ReplayTypeDetect:
		rr.FillDetect(sn, devType, taskType, data, toFillData)

	case ReplayTypePosture:
		toFillData.Posture = data

	case ReplayTypeHit:
		toFillData.SflHitStatus = data

	case ReplayTypeSpectrum:
		toFillData.UrdSpec = data

	case ReplayTypeC2SysConfig:
		toFillData.ReplayC2SysConfig = data

	default:
		logger.Infof("not support business task type: %v", GetReplayDataTypeDesc(taskType))
	}
}

type DelSnChData struct {
	SnLists []string
}
type DataReplayer struct {
	Status         atomic.Int32
	ReplayTimers   *helper.GeneralTaskTimer //not init in create DataReplayer obj.
	PauseTimerHour int32                    //set larger wait time for task timer.

	Tasks        map[string]map[int32]IReplayTaskAbstract //first key is sn, second key is business data type
	ReplayQueues map[string]map[int32]*helper.SkyFendPQWrap[ValueType]
	ReplayMem    map[string]map[int32]*LocalMem

	ReplayCtx *ReplayContext //保存replay start请求的一些信息。作为一次回放数据请求的上下文。

	// 主要是控制任务结束
	CtrlTmrCtx    context.Context
	CancelTmrFunc context.CancelFunc

	BaseReplayFreq int32 // 根据设备上报的频率，制定数据回放时的发送频率。

	// 控制删除sn的通道，sn关联的任务 都统一放在一个线程里操作。
	DelSnNotifyReqCh chan DelSnChData
	DelSnNotifyAckCh chan bool
	//
	AddSnNotifyReqCh chan []*AddedNewReplaySnItem
	AddSnNotifyAckCh chan bool

	TaskReduceHandle *ReplayReduce

	LoadMsgHandle *LoadMsgManager
	//
	ChSeq    atomic.Int64
	StopFlag atomic.Bool
}

func NewReplayTaskMng() *DataReplayer {
	r := new(DataReplayer)
	r.setStatus(ReplayRunStatusInit)
	r.StopFlag.Store(false)
	r.ReplayCtx = new(ReplayContext)
	r.ReplayCtx.ReplayDevTypMap = make(map[string]int32)

	r.BaseReplayFreq = ReplayBaseFreqMs
	r.InitQueueTaskMem()
	r.InitChan()

	r.PauseTimerHour = 24 // hour time.
	return r
}

func (r *DataReplayer) InitQueueTaskMem() {
	r.Tasks = make(map[string]map[int32]IReplayTaskAbstract)
	r.ReplayQueues = make(map[string]map[int32]*helper.SkyFendPQWrap[ValueType])
	r.ReplayMem = make(map[string]map[int32]*LocalMem)
}
func (r *DataReplayer) InitChan() {
	r.DelSnNotifyReqCh = make(chan DelSnChData, 10)
	r.DelSnNotifyAckCh = make(chan bool, 1)

	r.AddSnNotifyReqCh = make(chan []*AddedNewReplaySnItem, 10)
	r.AddSnNotifyAckCh = make(chan bool, 1)
}
func (r *DataReplayer) GetLocalMemHandler(sn string, businessType int32) *LocalMem {
	if r == nil {
		return nil
	}

	businessMem, ok := r.ReplayMem[sn]
	if !ok || businessMem == nil || len(businessMem) <= 0 {
		logger.Errorf("1) not exist mem handler for sn: %v, business type: %v", sn, businessType)
		return nil
	}

	memItem, ok := businessMem[businessType]
	if !ok || memItem == nil {
		logger.Errorf("2) not exist mem handler for sn: %v, business type: %v", sn, businessType)
		return nil
	}
	return memItem
}

func (r *DataReplayer) TransformRate(rate int32) string {
	strBaseRate := fmt.Sprintf("%vms", r.BaseReplayFreq)
	if rate <= 1 {
		logger.Infof("start replay: 1 multi rate of base, base is: %v ", ReplayBaseFreqMs)

	} else if rate <= 2 {
		strBaseRate = fmt.Sprintf("%dms", ReplayBaseFreqMs/2)
		logger.Infof("start replay: 2 multi rate of base, now rate: %v ", strBaseRate)

	} else if rate <= 3 {
		strBaseRate = fmt.Sprintf("%dms", ReplayBaseFreqMs/3)
		logger.Infof("start replay: 3 multi rate of base, now rate: %v ", strBaseRate)

	} else if rate <= 4 {
		strBaseRate = fmt.Sprintf("%dms", ReplayBaseFreqMs/4)
		logger.Infof("start replay: 4 multi rate of base, now rate: %v ", strBaseRate)

	} else {
		strBaseRate = fmt.Sprintf("%dms", ReplayBaseFreqMs/6)
		logger.Infof("start replay: 6 multi rate of base, now rate: %v ", strBaseRate)
	}
	return strBaseRate
}

func (r *DataReplayer) setStatus(status int32) {
	r.Status.Store(status)
}

// SetReplayStartTime init ReplayContext field. called by business.
func (r *DataReplayer) SetReplayStartTime(bt int64) {
	if bt <= 0 {
		return
	}
	r.ReplayCtx.BeginTime = bt
}
func (r *DataReplayer) SetReplayEndTime(et int64) {
	if et <= 0 {
		return
	}
	r.ReplayCtx.EndTime = et
}
func (r *DataReplayer) SetSnType(sn string, devType int32) {
	if len(sn) <= 0 {
		return
	}
	if r.ReplayCtx == nil || r.ReplayCtx.ReplayDevTypMap == nil {
		return
	}
	r.ReplayCtx.ReplayDevTypMap[sn] = devType
}
func (r *DataReplayer) FindReplayDevType(sn string) (int32, error) {

	if r == nil || r.ReplayCtx == nil || r.ReplayCtx.ReplayDevTypMap == nil || len(sn) <= 0 {
		return 0, fmt.Errorf("is no supported sn: %v", sn)
	}
	if devType, ok := r.ReplayCtx.ReplayDevTypMap[sn]; ok {
		return devType, nil
	}
	logger.Errorf("not find replay dev type for sn: %v", sn)
	return 0, fmt.Errorf("not find dev type for sn: %v", sn)
}
func (r *DataReplayer) SetReplayRate(rate int32) {
	if r == nil || r.ReplayCtx == nil {
		return
	}
	logger.Infof("change rate in replay context from: %v to %v", r.ReplayCtx.Rate, rate)
	r.ReplayCtx.Rate = rate
}
func (r *DataReplayer) AddOneReplayDevToList(sn string, devType int32) {
	devItem := &ReplayDevices{
		sn:      sn,
		devType: devType,
	}
	r.ReplayCtx.ReplayDeviceList = append(r.ReplayCtx.ReplayDeviceList, devItem)
}
func (r *DataReplayer) SetReplayDevList(snIn []string, devs []int32) {
	if len(snIn) <= 0 || len(devs) <= 0 {
		return
	}
	if len(snIn) != len(devs) {
		logger.Errorf("input param for sn and dev type len is not eq, check it")
		return
	}

	//clear history dev list
	r.ReplayCtx.ReplayDeviceList = r.ReplayCtx.ReplayDeviceList[:0]

	for i := 0; i < len(snIn); i++ {
		r.AddOneReplayDevToList(snIn[i], devs[i])
	}
}

func (r *DataReplayer) InsertDataQueue(item *MsgToQueue) {
	if item == nil {
		logger.Infof("is nil")
		return
	}

	snQueue, ok := r.ReplayQueues[item.Sn]
	if !ok || snQueue == nil {
		logger.Errorf("not exist queue handle, sn: %v", item.Sn)
		return
	}

	busiQueue, ok := snQueue[item.BusiType]
	if !ok || busiQueue == nil {
		logger.Errorf("not exist queue handle for busitype: %v, sn: %v", GetReplayDataTypeDesc(item.BusiType), item.Sn)
		return
	}

	busiQueue.Push(&item.SkyFendPQItem)
	logger.Infof("insert item to queue done, item: %v, sn: %v, busiType: %v ", item.SkyFendPQItem, item.Sn, GetReplayDataTypeDesc(item.BusiType))

	tsks, ok := r.Tasks[item.Sn]
	if !ok || tsks == nil {
		logger.Errorf("not exist task for sn: %v", item.Sn)
		return
	}
	busiTsk, ok := tsks[item.BusiType]
	if !ok || busiTsk == nil {
		logger.Errorf("not exist task for sn: %v, busi type: %v", item.Sn, GetReplayDataTypeDesc(item.BusiType))
		return
	}

	busiTsk.UpdateLoadDbStartTime(item.Priority)
}

func (r *DataReplayer) ProcessReceiveAddSnNotify() {
	var (
		ok         bool
		notifyAck  bool
		newSnItems []*AddedNewReplaySnItem
	)

	select {
	case newSnItems, ok = <-r.AddSnNotifyReqCh:
		if ok {
			if len(newSnItems) > 0 {
				logger.Infof("to add replay, sn list: %v", newSnItems)
			}
			notifyAck = true
		}
	default:
		//
	}

	for _, item := range newSnItems {
		r.AddReplayTaskBySn(item)
	}

	if notifyAck {
		logger.Info("begin to notify business add dev replay list.")
		r.AddSnNotifyAckCh <- true
		logger.Info("end notify business add dev replay list done.")
	}
}
func (r *DataReplayer) ProcessReceiveDelSnNotify() {
	var (
		toDelDevList DelSnChData
		ok           bool
		notifyAck    bool
	)

	if r.StopFlag.Load() == true {
		logger.Infof("begin to receive del sn notify:")
		select {
		case toDelDevList, ok = <-r.DelSnNotifyReqCh:
			if ok {
				if len(toDelDevList.SnLists) > 0 {
					logger.Infof("to del dev list from replay is: %v", toDelDevList.SnLists)
				}
				notifyAck = true
			} else {
				logger.Infof("receive close chan.")
			}
		}

		logger.Infof("is stop sn list.....")
		//删除设备统一放在 定时器线程中; 如果任务定时器被销毁或者暂停，防止阻塞业务，这是需要业务手动去删除设备。

		for _, sn := range toDelDevList.SnLists {
			r.DeleteReplayTaskBySn(sn)
		}

		if notifyAck {
			logger.Info("begin to notify business del dev list.")

			r.DelSnNotifyAckCh <- true

			logger.Info("end notify business del dev list done.")
		}
	}
}

func (r *DataReplayer) CheckSnOnQueueAndSendNotifyToLoader(sn string) {
	if len(sn) <= 0 {
		return
	}

	snTasks, ok := r.Tasks[sn]
	if !ok || len(snTasks) <= 0 {
		logger.Errorf("not exist tasks for sn: %v", sn)
	}
	devType, _ := r.FindReplayDevType(sn)

	for taskType, taskItem := range snTasks { //所有 has started 业务
		if taskItem.NeedLoadFromDb() {
			notifyMsg := &QueueToDbMsg{
				Sn:        sn,
				DevType:   devType,
				TaskType:  taskType,
				BatchNums: taskItem.GetLoadDbMsgNums(),
				StartTime: taskItem.GetStartLoadTime(),
				EndTime:   taskItem.GetEndLoadTime(),
				Seq:       r.ChSeq.Add(1),
			}

			r.LoadMsgHandle.SendNotifyToDb(notifyMsg)

			logger.Infof("as need load db, send load notify to loader. sn: %v, sn type: %v, taskType: %v, notify: %v",
				sn, devType, taskType, notifyMsg)
		}
	}
}
func (r *DataReplayer) CheckLoadSendNotifyLoader() {

	for sn := range r.Tasks { //一个设备下的所有业务类型业务。
		r.CheckSnOnQueueAndSendNotifyToLoader(sn)
	}
}
func (r *DataReplayer) ReceiveDbMsgAndInsertMq() {
	dataFromDb := r.LoadMsgHandle.ReceiveMsgFromDb()
	if dataFromDb != nil {
		for _, msgItem := range dataFromDb {
			if msgItem == nil {
				continue
			}
			r.InsertDataQueue(msgItem)
		}
	}
}

// Process 实现定时器任务 功能逻辑入口。
func (r *DataReplayer) Process() error {
	r.ProcessReceiveDelSnNotify()
	r.ProcessReceiveAddSnNotify()

	r.ReceiveDbMsgAndInsertMq()

	r.CheckLoadSendNotifyLoader()

	//每次向app 推送数据，新建一个临时对象
	toReplayData := NewReplayReduce()

	for sn, snTasks := range r.Tasks { //一个设备下的所有业务类型业务。

		devType, _ := r.FindReplayDevType(sn)

		snFieldFilled := false
		for taskType, taskItem := range snTasks { //所有 has started 业务
			taskItem.DoTask() // one task for one sn and business, eg: heart, detect, posture, and so on;
			if len(taskItem.GetData()) > 0 {
				if snFieldFilled == false {
					snFieldFilled = true
					toReplayData.AppendReplayDataOnDev(sn, devType)
				}
				toReplayData.FillReplayDetailOnDev(sn, devType, taskType, taskItem.GetData())
			}
		}
	}

	toReplayData.TransReplayData()
	return nil
}

// StartWorkTimer waitTm format like: "1ms", "200ms", "1s"; called by business, eg: receive api request, then start timer to work.
func (r *DataReplayer) StartWorkTimer(tm string) {
	if len(tm) <= 0 {
		logger.Infof("timer work start time is empty")
		return
	}
	//
	logger.Infof("begin to start timer, during: %v", tm)
	//...
	r.CtrlTmrCtx, r.CancelTmrFunc = context.WithCancel(context.Background())

	r.LoadMsgHandle = NewLoadMsgManager(r.CtrlTmrCtx, r)
	r.LoadMsgHandle.WaitNotifyToLoad()

	r.ReplayTimers = helper.NewGeneralTaskTimer(tm, helper.RegisterTaskProcess(r))

	r.CheckLoadSendNotifyLoader()
	r.ReplayTimers.DoTask(r.CtrlTmrCtx)
}
func (r *DataReplayer) ModifyWorkTimer(tm string) {
	if len(tm) <= 0 {
		logger.Infof("tm is nil")
		return
	}
	if r.ReplayTimers == nil {
		return
	}

	r.ReplayTimers.ResetTimeDur(tm)
}
func (r *DataReplayer) StopWorkTimer() {
	if r.ReplayTimers == nil {
		return
	}
	logger.Info("now, stop all work task with timer.")
	r.CancelTmrFunc()
}

func (r *DataReplayer) CloseNotifyReqChan() {
	logger.Infof("begin to close notify chan.")

	if r.DelSnNotifyReqCh != nil {
		close(r.DelSnNotifyReqCh)
		r.DelSnNotifyReqCh = nil
	}

	if r.AddSnNotifyReqCh != nil {
		close(r.AddSnNotifyReqCh)
		r.AddSnNotifyReqCh = nil
	}

	logger.Infof("close notify chan end.")
}

func (r *DataReplayer) CloseNotifyAckChan() {

	logger.Infof("begin to close notify  ack chan.")
	if r.AddSnNotifyAckCh != nil {
		close(r.AddSnNotifyAckCh)
	}
	if r.DelSnNotifyAckCh != nil {
		close(r.DelSnNotifyAckCh)
	}
	logger.Infof("end close notify ack chan.")
}

// CreateReplayQueue called by business
func (r *DataReplayer) CreateReplayQueue(sn string, replayType int32) *helper.SkyFendPQWrap[ValueType] {
	var ret *helper.SkyFendPQWrap[ValueType] = nil
	typeMap, ok := r.ReplayQueues[sn]

	if ok {
		if typeMap == nil {
			typeMap = make(map[int32]*helper.SkyFendPQWrap[ValueType])
			typeMap[replayType] = helper.NewSkyFendWrap[ValueType]() //CreateDefaultPriorityQueue()
			r.ReplayQueues[sn] = typeMap

		} else {
			if _, ok1 := typeMap[replayType]; !ok1 {
				r.ReplayQueues[sn][replayType] = helper.NewSkyFendWrap[ValueType]() // CreateDefaultPriorityQueue()
			}
		}

		logger.Infof("register business queue, task type: %v to task manager, sn: %v", replayType, sn)
		ret = r.ReplayQueues[sn][replayType]
		return ret
	}

	typeMap = make(map[int32]*helper.SkyFendPQWrap[ValueType])
	typeMap[replayType] = helper.NewSkyFendWrap[ValueType]() // CreateDefaultPriorityQueue()
	r.ReplayQueues[sn] = typeMap

	ret = r.ReplayQueues[sn][replayType]
	logger.Infof("register business queue: %v to task manager, sn: %v", replayType, sn)
	return ret
}
func (r *DataReplayer) CreateReplayMem(ctx context.Context, sn string, replayType int32) *LocalMem {
	var ret *LocalMem

	typeMap, ok := r.ReplayMem[sn]
	if ok {
		if typeMap == nil {
			typeMap = make(map[int32]*LocalMem)
			typeMap[replayType] = CreateDefaultLocalMem(ctx)
			r.ReplayMem[sn] = typeMap
		} else {
			if _, ok1 := typeMap[replayType]; !ok1 {
				r.ReplayMem[sn][replayType] = CreateDefaultLocalMem(ctx)
			}
		}
		logger.Infof("register local mem for business: %v to task manager, sn: %v", replayType, sn)

		ret = r.ReplayMem[sn][replayType]
		return ret
	}

	typeMap = make(map[int32]*LocalMem)
	typeMap[replayType] = CreateDefaultLocalMem(ctx)
	r.ReplayMem[sn] = typeMap
	logger.Infof("register local mem for business: %v to task manager, sn: %v", replayType, sn)

	ret = r.ReplayMem[sn][replayType]
	return ret
}

func (r *DataReplayer) CreateReplayTask(sn string, replayType int32, task IReplayTaskAbstract) {
	if task == nil {
		logger.Errorf("input task is not init, is not normal logic.")
		return
	}

	typeMap, ok := r.Tasks[sn]
	if ok {
		if typeMap == nil {
			typeMap = make(map[int32]IReplayTaskAbstract)
			typeMap[replayType] = task
			r.Tasks[sn] = typeMap
		} else {
			if _, ok1 := typeMap[replayType]; !ok1 {
				r.Tasks[sn][replayType] = task
			}
		}
		logger.Infof("register task for business: %v to task manager, sn: %v", GetReplayDataTypeDesc(replayType), sn)
		return
	}

	typeMap = make(map[int32]IReplayTaskAbstract)
	typeMap[replayType] = task
	r.Tasks[sn] = typeMap
	logger.Infof("register task for business: %v to task manager, sn: %v", GetReplayDataTypeDesc(replayType), sn)
}

// AddReplayTaskBySn 中入参：AddedNewReplaySnItem 中包含 新增sn的 start/end time.
func (r *DataReplayer) AddReplayTaskBySn(item *AddedNewReplaySnItem) {
	if item == nil {
		return
	}

	r.AddOneReplayDevToList(item.Sn, item.DevType)

	r.SetSnType(item.Sn, item.DevType)

	for taskType := range ReplayDataTypes {
		noExistTaskType := FilterTask(item.DevType, taskType)
		if noExistTaskType {
			logger.Infof("sn: %v, devType: %v, taskType: %v, need not to run task", item.Sn, item.DevType, taskType)
			continue
		}

		q := r.CreateReplayQueue(item.Sn, taskType)
		m := r.CreateReplayMem(context.Background(), item.Sn, taskType)
		r.CreateReplayTask(item.Sn, taskType,
			NewReplayTask(q, m, item.Sn, item.DevType, taskType, r,
				WithConsumerQueueBoundTime(item.StartTime),
				WithQueryEndTime(item.EndTime),
				WithQueryStartTime(item.StartTime),
				WithQueryLen(QueryItemMaxLen)))

		r.CheckSnOnQueueAndSendNotifyToLoader(item.Sn)
	}

	logger.Infof("add new replay task for sn: %v", item)
}

func (r *DataReplayer) DeleteReplayTaskBySn(sn string) {

	r.LoadMsgHandle.SendDelLoadOnSn(&SignalDelSnTask{
		Sn: sn,
	})

	if r.Tasks != nil {
		if _, ok := r.Tasks[sn]; ok {
			delete(r.Tasks, sn)
		}
	}

	if r.ReplayQueues != nil {
		if _, ok := r.ReplayQueues[sn]; ok {
			delete(r.ReplayQueues, sn)
		}
	}

	if r.ReplayMem != nil {
		if tasksMem, ok := r.ReplayMem[sn]; ok {
			for _, mV := range tasksMem {
				if mV == nil {
					continue
				}
				mV.ResetLocalMem()
			}
			delete(r.ReplayMem, sn)
		}
	}

	//从设备和设备类型关系表中删除设备记录.
	if r.ReplayCtx != nil && r.ReplayCtx.ReplayDevTypMap != nil {
		delete(r.ReplayCtx.ReplayDevTypMap, sn)
	}

	//从播放列表上下文中删除 sn
	if r.ReplayCtx != nil && len(r.ReplayCtx.ReplayDeviceList) > 0 {
		for i := 0; i < len(r.ReplayCtx.ReplayDeviceList); i++ {
			item := r.ReplayCtx.ReplayDeviceList[i]
			if item != nil && item.sn == sn {
				r.ReplayCtx.ReplayDeviceList = append(r.ReplayCtx.ReplayDeviceList[:i], r.ReplayCtx.ReplayDeviceList[i+1:]...)
			}
		}
	}

	logger.Infof("exclude task from task manager on sn: %v", sn)
}
func (r *DataReplayer) StopAllReplayTasks() {
	if r.Tasks == nil || len(r.Tasks) <= 0 {
		return
	}

	var toDelSn []string
	for sn := range r.Tasks {
		toDelSn = append(toDelSn, sn)
	}

	if r.IsPause() { //如果当前是暂停状态，需要手动释放任务。
		for _, sn := range toDelSn {
			r.DeleteReplayTaskBySn(sn)
		}
	} else {
		logger.Infof("send signal to del sn and stop tasks, del sn: %v", toDelSn)
		TasksMng.StopFlag.Store(true)
		toNotifyDelSn := DelSnChData{
			SnLists: toDelSn,
		}
		TasksMng.DelSnNotifyReqCh <- toNotifyDelSn

		logger.Infof("begin to receive del sn list ack, sn list: %v", toDelSn)
		<-TasksMng.DelSnNotifyAckCh
		logger.Infof("end: receive del sn list ack, sn list: %v", toDelSn)
		TasksMng.StopFlag.Store(false)
	}

	logger.Infof("del sn from replay dev list.")
}

// GetStatus called by business
func (r *DataReplayer) GetStatus() int32 {
	return r.Status.Load()
}
func (r *DataReplayer) IsSameStatus(status int32) bool {
	return r.GetStatus() == status
}

// SetRunning called by business
func (r *DataReplayer) SetRunning() {
	logger.Infof("set current replay status: %v", ReplayRunStatusRunning)
	r.setStatus(ReplayRunStatusRunning)
}
func (r *DataReplayer) IsRunning() bool {
	return r.IsSameStatus(ReplayRunStatusRunning)
}
func (r *DataReplayer) SetPause() {
	r.setStatus(ReplayRunStatusPaused)
}
func (r *DataReplayer) IsPause() bool {
	return r.IsSameStatus(ReplayRunStatusPaused)
}
func (r *DataReplayer) SetStop() {
	r.setStatus(ReplayRunStatusStop)
}
func (r *DataReplayer) IsStop() bool {
	return r.IsSameStatus(ReplayRunStatusStop)
}

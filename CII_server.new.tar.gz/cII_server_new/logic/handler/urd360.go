package handler

import (
	"bytes"
	"context"
	"encoding/base64"
	"fmt"
	"sync/atomic"
	"text/template"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/config"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/cache"
	jsoniter "github.com/json-iterator/go"
)

type Urd360Service struct {
	CmdId int32
}

func NewUrd360Service() *Urd360Service {
	return &Urd360Service{}
}

func (u *Urd360Service) StartMonitor(ctx context.Context, req *client.Urd360StartMonitorRequest, rsp *client.Urd360StartMonitorResponse) error {
	cmdId := atomic.AddInt32(&u.CmdId, 1)
	if uint8(cmdId) == 0 {
		cmdId = atomic.AddInt32(&u.CmdId, 1)
	}
	info, err := UrdStartMonitor(req.Sn, uint8(cmdId))
	if err != nil {
		logger.Error("UrdStartMonitor error:", err)
		rsp.Result = -1 //-1:失败
		rsp.Info = info
		return nil
	}
	rsp.Result = 1 //1:成功
	rsp.Info = info
	return nil
}

func (u *Urd360Service) StopMonitor(ctx context.Context, req *client.Urd360StopMonitorRequest, rsp *client.Urd360StopMonitorResponse) error {
	cmdId := atomic.AddInt32(&u.CmdId, 1)
	if uint8(cmdId) == 0 {
		cmdId = atomic.AddInt32(&u.CmdId, 1)
	}
	info, err := UrdStopMonitor(req.Sn, uint8(cmdId))
	if err != nil {
		logger.Error("UrdStopMonitor error:", err)
		rsp.Result = -1 //-1:失败
		rsp.Info = info
		return nil
	}
	rsp.Result = 1 //1:成功
	rsp.Info = info
	return nil
}

func (u *Urd360Service) UpdateConfig(ctx context.Context, req *client.Urd360UpdateConfigRequest, rsp *client.Urd360UpdateConfigResponse) error {
	cmdId := atomic.AddInt32(&u.CmdId, 1)
	if uint8(cmdId) == 0 {
		cmdId = atomic.AddInt32(&u.CmdId, 1)
	}
	// 实际增益换算成配置的增益，实际增益为（gain-195）/2
	for i, _ := range req.Configs {
		req.Configs[i].Gain = req.Configs[i].Gain*2 + 195
	}
	// 生成配置文件
	var content []byte
	if req.Configs != nil {
		// 使用自定义函数来实现索引加1
		funcs := template.FuncMap{"add": func(x, y int) int {
			return x + y
		}}

		t := template.Must(template.New("config").Funcs(funcs).Parse(Urd360ConfigTemplate))

		var buf bytes.Buffer
		if err := t.Execute(&buf, req.Configs); err != nil {
			rsp.Info = "Error executing template:" + err.Error()
			rsp.Result = -1 //-1:失败
			rsp.Info = "生成配置文件失败"
			return nil
		}

		content = buf.Bytes()
	}

	info, err := UrdUpdateConfig(req.Sn, uint8(cmdId), content)
	if err != nil {
		logger.Error("UrdUpdateConfig error:", err)
		rsp.Result = -1 //-1:失败
		rsp.Info = info
		return nil
	}

	// 配置增益换算回实际增益，实际增益为（gain-195）/2
	for i, _ := range req.Configs {
		req.Configs[i].Gain = (req.Configs[i].Gain - 195) / 2
	}
	// 保存配置
	configs, _ := jsoniter.Marshal(req.Configs)
	cache.FileCache.Put(context.Background(), fmt.Sprintf("%s_%s", UrdConfigPrefix, req.Sn), configs, 0)

	rsp.Result = 1 //1:成功
	rsp.Info = info
	return nil
}

func (u *Urd360Service) GetConfig(ctx context.Context, req *client.Urd360GetConfigRequest, rsp *client.Urd360GetConfigResponse) error {
	// 获取配置
	content, _, err := cache.FileCache.Get(context.Background(), fmt.Sprintf("%s_%s", UrdConfigPrefix, req.Sn))
	if err != nil {
		logger.Error("GetConfig error:", err)
		rsp.Result = -1 //-1:失败
		rsp.Info = err.Error()
		return nil
	}
	configs, ok := content.([]byte)
	if !ok {
		configs, _ = base64.StdEncoding.DecodeString(content.(string))
	}
	jsoniter.Unmarshal(configs, &rsp.Configs)

	rsp.Result = 1 //1:成功
	rsp.Info = "获取配置文件成功"
	return nil
}

func (u *Urd360Service) Enable(ctx context.Context, req *client.Urd360EnableRequest, rsp *client.Urd360EnableResponse) error {
	err := UrdEnable(req.Sn, req.Enable)
	if err != nil {
		logger.Error("UrdEnable error:", err)
		rsp.Status = -1 //-1:失败
		return nil
	}
	rsp.Status = 1 //1:成功
	return nil
}

func (u *Urd360Service) StartSpectrum(ctx context.Context, req *client.Urd360StartSpectrumRequest, rsp *client.Urd360StartSpectrumResponse) error {
	err := StartUrdSpectrumTCPConnection(config.GetGlobalConfig().Server.Urd360TcpIp, config.GetGlobalConfig().Server.Urd360SpectrumPort, req.Sn)
	if err != nil {
		logger.Error("UrdStartSpectrum error:", err)
		rsp.Result = -1 //-1:失败
		rsp.Info = err.Error()
		return nil
	}
	rsp.Result = 1 //1:成功
	return nil
}

func (u *Urd360Service) StopSpectrum(ctx context.Context, req *client.Urd360StopSpectrumRequest, rsp *client.Urd360StopSpectrumResponse) error {
	err := StopUrdSpectrumTCPConnection(req.Sn)
	if err != nil {
		logger.Error("UrdStopSpectrum error:", err)
		rsp.Result = -1 //-1:失败
		rsp.Info = err.Error()
		return nil
	}
	rsp.Result = 1 //1:成功
	return nil
}

const Urd360ConfigTemplate = `[Testing Information]
freq_num={{len .}}
{{range $index, $element := .}}
[freq{{add $index 1}}]
freq={{.Frequency}}
scan_num={{.ScanNum}}
gain={{.Gain}}
scan_time={{.ScanTime}}
scan_cycle={{.ScanCycle}}
{{end}}`

package handler

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/helper"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/proto/mavlink"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
	"google.golang.org/protobuf/proto"
	"sync"
	at "sync/atomic"
	"time"

	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
	broker2 "go-micro.dev/v4/broker"
	uber_atomic "go.uber.org/atomic"
)

type FpvOnlineManager struct {
	isOnline *at.Bool
	sn       *uber_atomic.String
}

var FvpOnLineStatus *FpvOnlineManager = &FpvOnlineManager{
	isOnline: new(at.Bool),
	sn:       uber_atomic.NewString(""),
}

func (p *FpvOnlineManager) SetOnLine() {
	if p == nil || p.isOnline == nil {
		return
	}
	p.isOnline.Store(true)
}
func (p *FpvOnlineManager) SetOffLine() {
	if p == nil || p.isOnline == nil {
		return
	}
	p.isOnline.Store(false)
}
func (p *FpvOnlineManager) Store(s *string) {
	if p == nil || s == nil {
		return
	}
	p.sn.Store(*s)
}
func (p *FpvOnlineManager) Load() string {
	if p == nil || p.sn == nil {
		return ""
	}
	return p.sn.Load()
}

func (p *FpvOnlineManager) IsOnLine() bool {
	if p == nil || p.isOnline == nil || !p.isOnline.Load() {
		return false
	}
	return true
}

func consumeReplayFpvHeartInfo() {
	heartEntities := make([]bean.FpvReplayHeartData, 0, batchSize)
	mu := sync.Mutex{}

	_, _ = mq.FpvMsgBroker.Subscribe(mq.FpvTopic, func(event broker2.Event) error {
		entity := client.ClientReport{}
		if err := proto.Unmarshal(event.Message().Body, &entity); err != nil {
			logger.Errorf("consume FpvHeart Unmarshal error: %v", err)
			return err
		}
		if entity.MsgType != common.ClientMsgIDFPVHeartBeat {
			return nil
		}

		dataInfo := client.FpvHeartInfo{}
		if err := proto.Unmarshal(entity.Data, &dataInfo); err != nil {
			logger.Errorf("parse fpv heart info fail, e: %v", err)
			return err
		}
		if dataInfo.Header == nil || dataInfo.GetData() == nil {
			logger.Errorf("parse data info is nil for fpv heart")
			return nil
		}
		if dataInfo.GetHeader().MsgType != mavlink.FpvHeartReportMsg {
			return nil
		}

		//just write dev online status.
		if dataInfo.GetData().GetIsOnline() != common.DevOnline {
			FvpOnLineStatus.SetOffLine()
			return nil
		}
		sn := dataInfo.GetData().GetSn()

		FvpOnLineStatus.SetOnLine()
		FvpOnLineStatus.Store(&sn)

		mu.Lock()
		defer mu.Unlock()

		heartEntities = append(heartEntities, bean.FpvReplayHeartData{
			Sn:            sn,
			IsOnline:      helper.TranBaseType[int, int32](dataInfo.GetData().GetIsOnline()),
			BatteryStatus: helper.TranBaseType[int, int32](dataInfo.GetData().GetBatteryStatus()),
			Electricity:   helper.TranBaseType[int, int32](dataInfo.GetData().GetElectricity()),
			WorkMode:      helper.TranBaseType[int, int32](dataInfo.GetData().GetWorkMode()),
			WorkStatus:    helper.TranBaseType[int, int32](dataInfo.GetData().GetWorkStatus()),
			AlarmLevel:    helper.TranBaseType[int, int32](dataInfo.GetData().GetAlarmLevel()),
			CreateTime:    time.Now().UnixMilli(),
		})

		createBusiHeartTable[bean.FpvReplayHeartData](db.GetDB(), sn, 0)
		if err := db.GetDB().Table(bean.FpvReplayHeartData{}.GetTableName(sn)).Create(&heartEntities).Error; err != nil {
			logger.Errorf("consume fpv heart data, write to db fail, e: %v", err)
		}

		heartEntities = helper.ClearSlice[bean.FpvReplayHeartData](heartEntities)
		return nil
	})
}

func consumeReplayFpvDetectInfo() {
	detectEntities := make([]bean.FpvReplayDetectData, 0, batchSize)
	mu := sync.Mutex{}

	_, _ = mq.FpvMsgBroker.Subscribe(mq.FpvTopic, func(event broker2.Event) error {
		entity := client.ClientReport{}
		if err := proto.Unmarshal(event.Message().Body, &entity); err != nil {
			logger.Errorf("consume fpv detect Unmarshal error: %v", err)
			return err
		}
		if entity.MsgType != common.ClientMsgIDFPVFreq {
			return nil
		}

		dataInfo := client.FpvDetectInfo{}
		if err := proto.Unmarshal(entity.Data, &dataInfo); err != nil {
			logger.Errorf("parse fpv detect info fail, e: %v", err)
			return err
		}
		if dataInfo.Header == nil || dataInfo.GetData() == nil {
			logger.Errorf("parse data info is nil for fpv detect")
			return nil
		}
		if dataInfo.GetHeader().GetMsgType() != mavlink.FpvFreqReportMsg {
			return nil
		}

		sn := dataInfo.GetData().GetSn()
		qxPower := dataInfo.GetData().GetQxPower()
		dxPower := dataInfo.GetData().GetDxPower()
		dxHorizon := dataInfo.GetData().GetDxHorizon()

		if len(dataInfo.GetData().GetList()) <= 0 {
			return nil
		}

		mu.Lock()
		defer mu.Unlock()

		for _, droneItem := range dataInfo.GetData().GetList() {
			if droneItem == nil {
				continue
			}
			detectEntities = append(detectEntities, bean.FpvReplayDetectData{
				Sn:            sn,
				QxPower:       qxPower,
				DxPower:       dxPower,
				DxHorizon:     dxHorizon,
				UavNumber:     droneItem.GetUavNumber(),
				DroneName:     droneItem.GetDroneName(),
				DroneHorizon:  droneItem.GetDroneHorizon(),
				UFreq:         droneItem.GetUFreq(),
				UDangerLevels: droneItem.GetUDangerLevels(),
				CreateTime:    time.Now().UnixMilli(),
			})
		}

		createBusiDetectTable[bean.FpvReplayDetectData](db.GetDB(), sn, int32(common.DEV_FPV))
		if err := db.GetDB().Table(bean.FpvReplayDetectData{}.GetTableName(sn)).Create(&detectEntities).Error; err != nil {
			logger.Errorf("consume fpv detect data, write to db fail, e: %v", err)
		}

		detectEntities = helper.ClearSlice[bean.FpvReplayDetectData](detectEntities)
		return nil
	})
}

func consumerReplayC2Config() {
	mu := sync.Mutex{}

	_, _ = mq.FpvMsgBroker.Subscribe(mq.FpvSysConfig, func(event broker2.Event) error {
		entity := client.SystemConfigInfo{}

		if err := proto.Unmarshal(event.Message().Body, &entity); err != nil {
			logger.Errorf("consume fpv sys config Unmarshal error: %v", err)
			return err
		}
		if len(entity.GetData()) <= 0 {
			logger.Infof("sys config is data is nil")
			return nil
		}
		dstItem := &client.CrudReq{}
		if err := proto.Unmarshal(entity.GetData(), dstItem); err != nil {
			logger.Errorf("unmarshal sys config fail for fpv, e: %v", err)
			return err
		}

		if entity.MsgType == SysConfigFpv {
			consumerReplayFpvc2Cfg(&mu, dstItem)

		} else if entity.MsgType == SysConfigTracerS {
			consumerReplayC2CfgTracerS(&mu, dstItem)

		} else if entity.MsgType == SysConfigTracerPro {
			consumerReplayC2CfgTracerS(&mu, dstItem)

		} else if entity.MsgType == SysConfigTracerP {
			consumerReplayC2CfgTracerS(&mu, dstItem)
			return nil
		}
		return nil
	})
}
func consumerReplayFpvc2Cfg(mu *sync.Mutex, dstItem *client.CrudReq) {
	if mu == nil || dstItem == nil {
		return
	}

	sysCfgEntities := make([]bean.FpvReplaySysConfigData, 0, batchSize) //暂时放弃批量写的能力
	sn := FvpOnLineStatus.Load()

	mu.Lock()
	defer mu.Unlock()

	sysCfgEntities = append(sysCfgEntities, bean.FpvReplaySysConfigData{
		Sn:            sn,
		Longitude:     dstItem.GetLongitude(),
		Latitude:      dstItem.GetLatitude(),
		Heading:       dstItem.GetHeading(),
		Arch:          dstItem.GetArch(),
		TerminalId:    dstItem.GetTerminalId(),
		EType:         dstItem.GetEType(),
		WarningRadius: dstItem.GetWarningRadius(),
		CounterRadius: dstItem.GetCounterRadius(),
		FenceRadius:   dstItem.GetFenceRadius(),
		ScannerRadius: dstItem.GetScannerRadius(),
		Height:        dstItem.GetHeight(),
		C2Longitude:   dstItem.GetC2Longitude(),
		C2Latitude:    dstItem.GetC2Latitude(),
		CreateTime:    time.Now().UnixMilli(),
	})

	createSysConfigTable[bean.FpvReplaySysConfigData](db.GetDB(), sn)
	if err := db.GetDB().Table(bean.FpvReplaySysConfigData{}.GetTableName(sn)).Create(&sysCfgEntities).Error; err != nil {
		logger.Errorf("consume fpv sys cfg data, write to db fail, e: %v", err)
	}
	return
}

package handler

import (
	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"context"
	"fmt"
	"io"
	"net"
	"strconv"
	"sync"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/server"
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/ip"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/proto/mavlink"
	"adasgitlab.autel.com/tools/cuav_server/repo/cache"
	"adasgitlab.autel.com/tools/cuav_server/repo/utils"
	v4Cache "go-micro.dev/v4/cache"
)

var (
	updBroadCasting        = 1
	updBroadCastEnd        = 2
	C2Id             int64 = 0
	C2IdKey                = "c2_uuid"
	udpBroadCastPort       = 1800

	udpBroadCastStartId = "0001241800"
	udpBroadCastMu      sync.Mutex
)

var (
	udpBroadCastManager = NewUdpBroadCastManager()
)

// udp广播管理
type UdpBroadCastManager struct {
	Status       int // 1--广播中，2--广播结束
	BroadCastMap sync.Map
	mu           sync.Mutex
	SnMap        map[string]string
}

type UdpBroadCast struct {
	cancel context.CancelFunc
	waitCh chan int //暂时没超时的概念
}

func NewUdpBroadCastManager() *UdpBroadCastManager {
	return &UdpBroadCastManager{}
}

func GetC2Id() {
	cacheHelper := cache.GetPersist()
	v, _, err := cacheHelper.Get(context.Background(), C2IdKey)
	if err != nil && err != v4Cache.ErrKeyNotFound {
		logger.Error("获取uuid 错误:", err)
		return
	}
	var cid int64
	if v != nil {
		cid = int64(v.(float64))
	}
	if cid <= 0 {
		cid = utils.SnowFlakeNode.Generate().Int64()
		cacheHelper.Put(context.Background(), C2IdKey, cid, 0)
	}
	C2Id = cid
	logger.Debug("generating random C2ID = ", C2Id)
}

func SetC2SN() {
	defer func() {
		if r := recover(); r != nil {
			logger.Error("SetC2SN occurred:", r)
			time.Sleep(time.Second * 1)
			SetC2SN()
		}
	}()
	fmt.Println("C2Id = ", C2Id)
	appSn := strconv.Itoa(int(C2Id))
	if devSn, err := common.GetC2DevSn(); err == nil {
		appSn = devSn
	}
	if bean.C2Sn != "" {
		appSn = bean.C2Sn
	}
	logger.Debug("use device SN = ", appSn)
	// uploadcloud.CloudCli.C2Sn = appSn
	res := &client.C2IdInsertRsp{}
	if err := NewC2Id().Insert(context.Background(), &client.C2IdInsertReq{
		C2Id: appSn,
	}, res); err != nil {
		logger.Error("Cloud Platorm Insert C2Id err:", err)
		time.Sleep(1 * time.Second)
		SetC2SN()
	}
}
func StartUdpBroadCast(startId string) error {
	startId = udpBroadCastStartId
	StopUdpBroadCast(startId)
	if _, ok := udpBroadCastManager.BroadCastMap.Load(startId); !ok {
		ctx, cancel := context.WithCancel(context.Background())
		bc := &UdpBroadCast{
			cancel: cancel,
			waitCh: make(chan int),
		}
		udpBroadCastManager.BroadCastMap.Store(startId, bc)
		udpBroadCastManager.Status = updBroadCasting
		udpBroadCastManager.SnMap = make(map[string]string, 0)
		go bc.Start(ctx)
	}
	return nil
}

func ConfirmDeviceConn(snList []string) error {
	logger.Info("设备发现确认：", snList)
	udpBroadCastManager.mu.Lock()
	defer udpBroadCastManager.mu.Unlock()
	for _, sn := range snList {
		udpBroadCastManager.SnMap[sn] = sn
	}
	return nil
}

func StopUdpBroadCast(startId string) error {
	startId = udpBroadCastStartId
	udpBroadCastMu.Lock()
	defer udpBroadCastMu.Unlock()
	if v, ok := udpBroadCastManager.BroadCastMap.Load(startId); ok {
		bc := v.(*UdpBroadCast)
		if bc.cancel != nil {
			bc.cancel()
		}
		udpBroadCastManager.BroadCastMap.Delete(startId)
		udpBroadCastManager.Status = updBroadCastEnd
	}
	return nil
}

func (bc *UdpBroadCast) Start(ctx context.Context) {
	logger.Info("udp broadCast start...")
	t := time.NewTicker(2 * time.Second)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
			localIps, broadIps, err := ip.GetBroadcastAddress()
			if err != nil {
				logger.Errorf("获取udp广播地址错误: %v", err)
				continue
			}
			logger.Info("upd广播地址集合: ", broadIps)
			for i, ip := range localIps {
				if i >= len(broadIps) {
					continue
				}
				go func(ctx context.Context, localIp string, broadIp string) {
					bc.Send(ctx, localIp, broadIp)
				}(ctx, ip, broadIps[i])
			}
		}
	}
}

func (bc *UdpBroadCast) Send(ctx context.Context, localIp string, broadIp string) {
	logger.Infof("开始udp广播:%s,%s", localIp, broadIp)
	res := mavlink.UdpBroadCastMessage{}
	resBuff := res.CreateUdpBoardMessage(0, localIp, uint16(server.TcpChannelPort))
	// 协议, 发送者,接收者
	conn, err := net.DialUDP("udp",
		&net.UDPAddr{
			IP: net.ParseIP(localIp),
		},
		&net.UDPAddr{
			IP:   net.ParseIP(broadIp),
			Port: udpBroadCastPort,
		})
	if err != nil {
		//logger.Fatal("创建udp广播错误:", err) // 会退出整个程序
		logger.Error("创建udp广播错误:", err)
		return
	}
	defer conn.Close()
	if _, err = conn.Write(resBuff); err != nil {
		logger.Errorf("%s, %s udp广播错误:%v", localIp, broadIp, err)
		return
	}
	logger.Debugf("%s, %s udp广播成功", localIp, broadIp)
}

func UdpHandle(ctx context.Context, conn *net.UDPConn) error {
	cacheBuff := make([]byte, 0)
	packetLen := 0
	buff := make([]byte, common.MaxReceiveSize)
	for {
		n, udpAddr, err := conn.ReadFromUDP(buff)
		if err != nil {
			// 通常遇到的错误是连接中断或被关闭，用io.EOF表示
			if err == io.EOF {
				logger.Info("udp conn receive close:", conn.RemoteAddr())
			} else {
				logger.Info("udp conn receive err:", err)
			}
			break
		}
		if n <= 0 {
			continue
		}
		if buff[mavlink.FrameLoc] == mavlink.FrameStart {
			packetLen = mavlink.GetPacketLen(buff[:n])
		}
		logger.Infof("udp receive data:[% x], len: %d packetLen: %d cachebuff len:%d", buff[:n], n, packetLen, len(cacheBuff))
		//通过dataLen和n 处理接收长度小于1024 但是是拆包的情况。这里用队列会好些，不过队列的个数会有点多
		if packetLen > n && packetLen > len(cacheBuff)+n {
			cacheBuff = append(cacheBuff, buff[:n]...)
			logger.Info("udp 当前buf长度:", len(cacheBuff))
			continue
		}

		cacheBuff = append(cacheBuff, buff[:n]...)
		if cacheBuff[mavlink.FrameLoc] != mavlink.FrameStart {
			logger.Info("udp 首字节1不对清空buf")
			cacheBuff = make([]byte, 0)
			packetLen = 0
			continue
		}
		//如果拆包后剩下mavlink前3位以内
		packetLen = mavlink.GetPacketLen(cacheBuff)
		//处理粘包、粘包+拆包
		for packetLen > 0 && len(cacheBuff) >= packetLen && cacheBuff[mavlink.FrameLoc] == mavlink.FrameStart {
			DealUpdPackage(udpAddr, cacheBuff[:packetLen])
			cacheBuff = cacheBuff[packetLen:]
			logger.Infof("udp 处理buf:%d,剩余buf:%d", packetLen, len(cacheBuff))
			if len(cacheBuff) > 0 {
				//再判断一次帧头，不符合直接抛弃
				if cacheBuff[mavlink.FrameLoc] != mavlink.FrameStart {
					logger.Info("udp 首字节2不对清空buf")
					cacheBuff = make([]byte, 0)
					packetLen = 0
					break
				}
				packetLen = mavlink.GetPacketLen(cacheBuff)
				if packetLen <= mavlink.HeaderLen+mavlink.CrcLen {
					packetLen = 0
					break
				}
			} else {
				packetLen = 0
			}
		}
	}
	return nil
}

func DealUpdPackage(udpAddr *net.UDPAddr, dataBuff []byte) {
	msgId := dataBuff[mavlink.MsgIdLoc]
	switch msgId {
	case mavlink.RadarUdpBroadcastResponse: //解析回复响应
		DealDeviceBroadcastConfirm(udpAddr, dataBuff, mavlink.RadarUdpBroadcastResponse)
		break
	}
}

// 创建信道
func DealDeviceBroadcastConfirm(udpAddr *net.UDPAddr, dataBuff []byte, msgId int) {
	logger.Infof("udp [%s] 接收到获取信道确认消息:[% x]", udpAddr.String(), dataBuff)
	devType := dataBuff[mavlink.SenderLoc] & 0xFF
	devId := common.DeviceType(devType)
	dev := &Device{
		Msg:   dataBuff,
		MsgId: msgId,
		UdpIp: udpAddr.IP.String(),
	}
	switch devId {
	case common.DEV_RADAR:
		radar := &Radar{
			Device: dev,
		}
		radar.ReceiveGetChannelReq()
		break
	case common.DEV_AEAG:
		break
	case common.DEV_SCREEN:
		screen := &Screen{
			Device: dev,
		}
		screen.ReceiveGetChannelReq()
		break
	case common.DEV_V2DRONEID:
		droneId := &DroneID{
			Device: dev,
		}
		droneId.ReceiveGetChannelReq()
		break
	case common.DEV_FPV:
		fpv := &Fpv{
			Device: dev,
		}
		fpv.ReceiveGetChannelReq()
		break
	case common.DEV_SFL:
		sfl := &Sfl{
			Device: dev,
		}
		sfl.ReceiveGetChannelReq()
		break
	case common.DEV_AGX:
		agx := &Agx{
			Device: dev,
		}
		agx.ReceiveGetChannelReq()
		break
	case common.DEV_HUNTER_PLATFORM:
		hp := &GunsPlatform{
			Device: dev,
		}
		hp.ReceiveGetChannelReq()
		break
	case common.DEV_TracerGun:
		hp := &TracerGun{
			Device: dev,
		}
		hp.ReceiveGetChannelReq()
		break
	}
}

// 下发信道
func UdpBroadcastSendChannel(devSn string, serverAddr string, sourceId uint8, tcpSvc *server.TcpServer) {
	rsp := &mavlink.UdpBroadcastConfirmResponse{}
	dataBuff := rsp.CreateUdpBoardMessage(devSn, sourceId, tcpSvc.Ip, uint16(tcpSvc.Port))
	// 协议, 发送者,接收者
	conn, err := net.Dial("udp", fmt.Sprintf("%s:%d", serverAddr, udpBroadCastPort))
	if err != nil {
		logger.Error("create client err:", serverAddr)
		return
	}
	defer conn.Close()
	_, err = conn.Write(dataBuff)
	logger.Infof("sourceid: %d udp发送tcp通信地址:[%s:%d] write result %v", sourceId, tcpSvc.Ip, tcpSvc.Port, err)
}

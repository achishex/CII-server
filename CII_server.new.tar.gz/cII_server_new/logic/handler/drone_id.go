package handler

import (
	"bytes"
	"context"
	"crypto/rand"
	"encoding/binary"
	"errors"
	"fmt"
	"io"
	"math/big"
	"os"
	"reflect"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"adasgitlab.autel.com/tools/cuav_server/entity/config"

	"github.com/allegro/bigcache/v3"
	"google.golang.org/protobuf/proto"

	"adasgitlab.autel.com/tools/cuav_server/repo/utils/threading"

	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
	"adasgitlab.autel.com/tools/cuav_server/repo/monitoring"

	"adasgitlab.autel.com/tools/cuav_server/repo/utils"

	"adasgitlab.autel.com/tools/cuav_server/proto/client"

	"adasgitlab.autel.com/tools/cuav_plugin/broker"
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"

	"adasgitlab.autel.com/tools/slink_proto/slinkv1"

	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/server"
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/helper"
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/ip"
	"adasgitlab.autel.com/tools/cuav_server/proto/mavlink"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
)

const (
	DroneIDTcpPort        = 12000
	DroneIDServerMaxCount = 500

	DroneHeightPrecision        = 10
	DroneYawAnglePrecision      = 100
	DroneSpeedPrecision         = 100
	DroneVerticalSpeedPrecision = 100
	DroneHorizonPrecision       = 100
	DronePitchPrecision         = 100
	DroneDirection              = 100
	FreqPrecision               = 1000
	NoiseFloorPrecision         = 1000
	AmpMeanPrecision            = 1000
)

type TracerType uint16

// 定义枚举值
const (
	STP100 = 0x71 // 1 (TracerP)
	STS100 = 0x72 // 2 (TracerS)
	MAX4T  = 0x73 // 3 (遥控器)
	STA100 = 0x74 // 4 (机载Tracer)
	SFL100 = 0x75 // 5 (云台)
	SEH100 = 0x76 // 6 SEH100(车载Tracer)
	SFL110 = 0x77 //7 (云台+TracerS)
	RRFD   = 0x78 //8 RRFD(阵列天线)
	STC100 = 0x79 //9 STC100(TracerPRO)
	STS120 = 0x7A //10 STS120(中电子)
)

// 定义枚举值对应的十六进制值
var TracerMap = map[TracerType]uint16{
	STP100: 1,
	STS100: 2,
	MAX4T:  3,
	STA100: 4,
	SFL100: 5,
	SEH100: 6,
	SFL110: 7,
	RRFD:   8,
	STC100: 9,
	STS120: 10,
}

const (
	// 前端发给后端的数据采集指令
	CollectDataTracerOpen = 1
	CollectDataTracerEnd  = 2
	//全频段采集开始
	CollectDataWholeFreqOpen = 3
	//全频段采集结束
	CollectDataWholeFreqEnd = 4

	// 发给设备的数据 采集指令
	CollectDataToDevEnd   = 0
	CollectDataToDevBegin = 1
	//全频段采集开始
	CollectDataWholeFreqToDevBegin = 2
	//全频段采集结束
	CollectDataWholeFreqToDevEnd = 3
)

// 设备给c2上报数据采集状态
const (
	DEV_COLLECT_STATUS_COLLECTING   = 1
	DEV_COLLECT_STATUS_GZIPING      = 2
	DEV_COLLECT_STATUS_UPLOAD_BEGIN = 3
	DEV_COLLECT_STATUS_UPLOAD_ING   = 4
	DEV_COLLECT_STATUS_UPLOAD_END   = 5
	DEV_COLLECT_STATUS_ERR          = 0xFF
)

const (
	COLLECT_STATUS_INIT        int32 = 0 // 初始状态
	COLLECT_STATUS_BEGIN       int32 = 1 // 开始采集
	COLLECT_STATUS_ZIP         int32 = 2 // 压缩
	COLLECT_STATUS_TRANS_BEGIN int32 = 3 // 开始上传
	COLLECT_STATUS_TRANS_ING   int32 = 4 // 上传中
	COLLECT_STATUS_TRANS_DONE  int32 = 5 //上传完成
	COLLECT_STATUS_ERR         int32 = 6 // 出现错误
)

const (
	ReportCollectStatusIng  uint32 = 1 // 采集中
	ReportCollectStatusFail uint32 = 2 // 采集失败
	ReportCollectStatusDone uint32 = 3 // 采集完成
	ReportCollectGzip       uint32 = 4 //压缩中
	ReportCollectTraning    uint32 = 5 //传输中
)

const (
	RFreqOpen  = 1
	RFreqClose = 0
)

var (
	DroneIDTcpServerLock sync.Mutex
	DroneIDTcpServerMap  sync.Map //= make(map[string]*server.TcpServer, 0)
)
var (
	droneIDTypeMap  sync.Map
	droneIDTypeLock sync.Mutex
)

var (
	timeFreqMap     = newTimeFreqMap()
	realtimeFreqMap = newTimeFreqMap()
	TimeFreqLen     = 128 * 3002 * 2
	RealtimeFreqLen = 128 * 300 * 2
)

var (
	gTracerEnDecrytpChan           = make(chan mavlink.TracerEncryptDataSteam, 1024)
	gTracerStartEnDeCryProcessFlag = true
)

type TimeFreqMap struct {
	mux   *sync.Mutex
	cache map[string]*bytes.Buffer
}

func (t *TimeFreqMap) Len(sn string) int {
	t.mux.Lock()
	defer t.mux.Unlock()
	buff, ok := t.cache[sn]
	if !ok {
		return 0
	}
	return buff.Len()
}

func (t *TimeFreqMap) ReadAll(sn string) []byte {
	t.mux.Lock()
	defer t.mux.Unlock()
	buff, ok := t.cache[sn]
	if !ok {
		return nil
	}
	content, _ := io.ReadAll(buff)
	return content
}

func (t *TimeFreqMap) Write(sn string, content []byte) {
	t.mux.Lock()
	defer t.mux.Unlock()
	buff, ok := t.cache[sn]
	if !ok {
		buff = bytes.NewBuffer(make([]byte, 0))
	}
	buff.Write(content)
	t.cache[sn] = buff
}

func (t *TimeFreqMap) Reset(sn string) {
	t.mux.Lock()
	defer t.mux.Unlock()
	buff, ok := t.cache[sn]
	if !ok {
		buff = bytes.NewBuffer(make([]byte, 0))
	}
	buff.Reset()
	t.cache[sn] = buff
}

func newTimeFreqMap() *TimeFreqMap {
	return &TimeFreqMap{
		mux:   &sync.Mutex{},
		cache: make(map[string]*bytes.Buffer),
	}
}

// InitDroneIDCounter 注册到初始化流程中; 将加入到 registerMetricHandles()，初始化对象。
func InitDroneIDCounter() {
	dbMetric := monitoring.NewMetricDbOpsInst(nil,
		monitoring.WithDBOnMetricDBOPS(db.GetMonitorDB()),
		monitoring.WithTabNameOnMetricDBOPS("Counter_DroneID"), // 本地文件存储数据库表名，需要自定义
		monitoring.WithIsDebugOnMetricDBOPS(true))

	droneCounter := &monitoring.DeviceCounter{}
	droneCounter.Counter = monitoring.NewMetricCounterDecorator(
		monitoring.CreatePromPusherClientOnBackend(),
		dbMetric, "", monitoring.VectorOpts, "")

	monitoring.DevCounterMetricHandle.RegisterCounterMetric(int(common.DEV_V2DRONEID), droneCounter, GetDevGuid)
}

type DroneID struct {
	*Device
	dt                 common.DeviceType
	BusinessDeviceType int32 // 1: tracerP, 2: tracerS, 9: tracerPro
}

var _ DeviceIfer = (*DroneID)(nil)

// SetDevice 要使用GetOnLineDev 接口，必须要给该设备实现 DeviceIfer 接口
func (tg *DroneID) SetDevice(d *Device) {
	tg.Device = d
}

func NewDroneID(conn Connection, d []byte, dataLen int, remoteIp string, remotePort int, localIp string, serverPort int,
	mailBox map[int]*WaitTaskManager, dlimit *devLimit) DeviceInterface {
	droneDev := &DroneID{
		Device: &Device{
			Conn:        conn,
			Msg:         d,
			MsgLen:      dataLen,
			SourceId:    d[mavlink.SenderLoc],
			RemoteIp:    remoteIp,
			RemotePort:  remotePort,
			LocalIp:     localIp,
			ServerPort:  serverPort,
			WaitTaskMap: mailBox,
		},
	}
	//if len(d) <= mavlink.MsgIdLoc+1 {
	//	return droneDev
	//}
	//
	//monitoring.DevCounterMetricHandle.Inc(int(common.DEV_V2DRONEID),
	//	GetSnByPort(droneDev.ServerPort),
	//	TranIntToHex(int(d[mavlink.MsgIdLoc])))
	return droneDev
}

func GetSnByPort(port int) string {
	if port <= 0 {
		return ""
	}
	snGeneral, ok := DevSnMap.Load(port)
	if !ok {
		return ""
	}
	if sn, ok := snGeneral.(string); ok {
		return sn
	}
	return ""
}
func TranIntToHex(n int) string {
	hexStr := fmt.Sprintf("%x", n)
	return hexStr
}

func (d *DroneID) Deal() {
	if d.MsgLen <= 0 {
		logger.Errorf("message len: 0 remoteIP: %v", d.Device.RemoteIp)
		return
	}

	d.MsgId = int(d.Msg[mavlink.MsgIdLoc])
	switch d.MsgId {
	case mavlink.DroneIDGetVersionInfo:
		d.ReceiveGetVersionInfo()
	case mavlink.TracerGetDevTypeInfo:
		d.ReceiveGetDevTypeInfo()
	case mavlink.DRONEIDMsgGetChannel:
		d.ReceiveGetChannelReq()
	case mavlink.DRONEIDMsgHeartbeat:
		d.Heart()
	case mavlink.TracerIdGetVersionInfo:
		d.ReceiveTracerGetVersionInfo()
	case mavlink.TracerIdRequestUpgrade:
		d.ReceiveTracerRequestUpgrade()
	case mavlink.TracerIdSendUpdatePkg:
		d.ReceiveTracerSendUpdatePkg()
	case mavlink.TracerIdVerifyImage:
		d.ReceiveTracerVerifyImage()
	case mavlink.TracerIdGetTimeoutRetryTime:
		// 获取运行超时重试时间
		d.ReceiveTracerGetUpdateTimeoutRetryTime()
	case mavlink.TracerIdWriteUpdateData:
		d.ReceiveTracerWriteUpdateData()
	case mavlink.TracerIdGetUpdateWriteStatus:
		d.ReceiveTracerGetUpdateWriteStatus()
	case mavlink.TracerIdRunApp:
		d.ReceiveTracerRunApp()
	case mavlink.TracerIdGetLogList:
		d.ReceiveGetLogList()
	case mavlink.TracerIdGetLogFile:
		d.ReceiveTracerLog()
	case mavlink.TracerIdGetLogResponse:
		d.ReceiveGetLog()
	case mavlink.TracerIdDeleteLog:
		d.ReceiveDelLog()
	case mavlink.TracerIdGetTime:
		d.ReceiveGetTime()
	case mavlink.TracerGetWorkMode:
		d.ReceiveSendGetWorkMode()
	case mavlink.TracerSetOrientationMode:
		d.ReceiveSendSetOrientationMode()
		// detect logic
	case mavlink.TracerIdGetDetectRes:
		d.ReceiveDetectRes()
	case mavlink.TracerIdGetDronIdRemoteIdDetectRes:
		d.ReceiveDetectDronIdRemoteIdRes()
	case mavlink.TracerIdGetRemoteIdDetectRes:
		d.ReceiveRemoteIdDetectRes()
	case mavlink.TracerIdGetFreqDetectRes:
		d.ReceiveFreqDetectRes()
	case mavlink.TracerIdGetNewFreqDetectRes:
		d.ReceiveNewFreqDetectRes()
	case mavlink.TracerIdGetFreqDataRes:
		d.ReceiveFreqDataRes()
	case mavlink.TracerIdGetNoiseFloorDataRes:
		d.ReceiveNoiseFloorDataRes()
	case mavlink.TracerSGetNoiseBaseDataRes:
		d.ReceiveFreqNoiseBaseDataRes()
	case mavlink.TracerSetNoiseFloor:
		d.ReceiveTracerSetNoiseFloor()
	case mavlink.TracerSetNoiseFloorV2:
		d.ReceiveTracerSetNoiseFloorV2()
	case mavlink.TracerIdGetFreqDetectResExp:
		d.ReceiveFreqDetectExp()
	case mavlink.TracerIdGetUasSystemInfoRes:
		d.ReceiveUasSystemInfoRes()
	case mavlink.TracerCliSend:
		d.ReceiveTracerCli()
	case mavlink.TracerSetWhiteList:
		d.ReceiveTracerSetWhite()
	case mavlink.TracerSetAlarmLevel:
		d.ReceiveTracerSetAlarm()
	case mavlink.TracerSetHideMode:
		d.ReceiveTracerSetHideMode()
	case mavlink.TracerIdUpgradeF1:
		d.ReceiveTracerUpdateF1()
	case mavlink.TracerIdUpgradeF2:
		d.ReceiveTracerUpdateF2()
	case mavlink.TracerIdUpgradeF3:
		d.ReceiveTracerUpdateF3()
	case mavlink.FpvPushVideoStreams:
		d.TransferVideoStream()
	case mavlink.TracerControlVideo:
		d.ProcVideoCmdResponse()
	case mavlink.TracerSetVideoParam:
		d.ReceiveTracerSetVideoParam()
	case mavlink.TracerIdSetRadioFreq:
		d.ReceiveSetRadioFreq()
	case mavlink.TracerProUploadWifiDetectRet:
		d.ReceiveWifiDetectUpload()
	case mavlink.TracerFreqDetectNodeList:
		d.ReceiveFreqDetectNodeList()
	case mavlink.TracerProSetOrient:
		d.ReceiveSetOrientResponse()
	case mavlink.TracerCollectData:
		d.ReceiveTracerCollectResponse()
	case mavlink.TracerTimeFreqDataCollect:
		d.TransCollectData()
	case mavlink.TracerSetTimeFreq:
		d.ReceiveSetTimeFreq()
	case mavlink.TracerTimeFreq:
		d.HandleTimeFreqData()
	case mavlink.TracerRealtimeFreq:
		d.HandleRealtimeFreqDataV2()
	case mavlink.TracerDroneIdEncrypt:
		d.ReciveEncryptDataSteam()
	case mavlink.TracerDroneIdDecrytp:
		d.ReceiveDecryptDataResult()
	case mavlink.TracerFreqSpectrumSet:
		d.ReceiveFreqSpectrumSet()
	case mavlink.TracerFreqSpectrumGet:
		d.ReceiveGetFreqSpectrum()
	case mavlink.TracerSetInvalidFreqList:
		d.ReceiveSetInvalidFreqList()
	case mavlink.TracerGetInvalidFreqList:
		d.ReceiveGetInvalidFreqList()
	case mavlink.TracerConfigProtoParseParam:
		d.ReceiveConfigProtoParseParam()
	case mavlink.TracerGetProtoParseParam:
		d.ReceiveGetProtoParseParam()
	default:
		logger.Error("unknown message id:", d.MsgId)
	}
}

func (d *DroneID) UnmarshalFreqDetectNodeList(data *mavlink.TracerFreqDetectNodeListResponse) error {
	buf := new(bytes.Buffer)
	if e := binary.Write(buf, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); e != nil {
		return fmt.Errorf("parse TracerFreqDetectNodeListResponse fail, e: %v", e)
	}

	if e := binary.Read(buf, binary.LittleEndian, &data.FreqNums); e != nil {
		return fmt.Errorf("parse TracerFreqDetectNodeListResponse.freqNums fail, e: %v", e)
	}

	if data.FreqNums <= 0 {
		return nil
	}

	start := mavlink.HeaderLen + binary.Size(data.FreqNums)
	end := d.MsgLen - mavlink.CrcLen
	buffer2 := new(bytes.Buffer)
	if e := binary.Write(buffer2, binary.LittleEndian, d.Msg[start:end]); e != nil {
		return fmt.Errorf("parse TracerFreqDetectNodeListResponse fail, e: %v", e)
	}
	for i := 0; i < int(data.FreqNums); i++ {
		var freqValue uint32 = 0
		if err := binary.Read(buffer2, binary.LittleEndian, &freqValue); err != nil {
			return fmt.Errorf("parse freq node list value fail, e: %v", err)
		}
		data.FreqList = append(data.FreqList, freqValue)
	}
	return nil
}

// ReceiveFreqDetectNodeList 接收 freq detect 节点列表
func (d *DroneID) ReceiveFreqDetectNodeList() {
	res := &mavlink.TracerFreqDetectNodeListResponse{}
	if err := d.UnmarshalFreqDetectNodeList(res); err != nil {
		logger.Errorf("parse freq detect node list response fail, e: %v", err)
		return
	}
	logger.Debugf("receive Send FreqDetectNodeList：%+v", *res)
	manager, ok := d.WaitTaskMap[mavlink.TracerFreqDetectNodeList]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *DroneID) updateStatusOnLine(sn string, tracerType uint16, heartInfo *mavlink.DroneIDReport) {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_V2DRONEID, sn)
	if cache, ok := DevStatusMapOnEvent.Load(cacheKey); ok {
		dev := cache.(*Device)
		dev.LastHeartTime = time.Now()
		dev.GetStatusInterval = time.Now()
		return
	}

	dev := &Device{
		Sn:                sn,
		Status:            common.DevOnline,
		RemoteIp:          d.RemoteIp,
		RemotePort:        d.RemotePort,
		LocalIp:           d.LocalIp,
		ServerPort:        d.ServerPort,
		DevType:           common.DEV_V2DRONEID,
		FirstHeartTime:    time.Now(),
		LastHeartTime:     time.Now(),
		SourceId:          d.SourceId,
		IsEnable:          d.GetStatus(sn, tracerType), //Notice...
		GetStatusInterval: time.Now(),
		SessionId:         GetGlobalSessionId(),
		WorkMode:          int32(heartInfo.WorkMode),
	}
	DevStatusMapOnEvent.Store(cacheKey, dev)

	equipModel, err := GetEquipBySn(sn)
	name := sn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	dataInfo := &client.DroneStatusInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        sn,
			EquipType: int32(common.DEV_V2DRONEID),
			MsgType:   mavlink.TracerEventOnLine,
		},
		Data: &client.DroneIDReport{
			Sn:       sn,
			IsOnline: common.DevOnline,
			EventId:  utils.GetEventId(dev.SessionId),
		},
	}
	if err == nil {
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgTracerStatusEventData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Infof("tracer heartbeat event has reported, devSn: %v,report:%v", sn, dataInfo.Data)
	return
}
func (d *DroneID) updateWorkModeOnHeartBeat(sn string, mode int32) {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_V2DRONEID, sn)
	if cache, ok := DevStatusMap.Load(cacheKey); ok {
		dev := cache.(*Device)
		dev.WorkMode = mode
	}
}
func (d *DroneID) getSubDeviceType(sn string) uint16 {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_V2DRONEID, sn)
	if cache, ok := DevStatusMap.Load(cacheKey); ok {
		if cache != nil {
			dev := cache.(*Device)
			if dev != nil {
				return dev.SubDeviceType
			}
		}
	}
	return 0
}
func (d *DroneID) updateStatus(sn string) int32 {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_V2DRONEID, sn)
	if cache, ok := DevStatusMap.Load(cacheKey); ok {
		dev := cache.(*Device)
		dev.Status = common.DevOnline
		dev.Conn = d.Conn
		dev.WaitTaskMap = d.WaitTaskMap
		dev.RemoteIp = d.RemoteIp
		dev.LastHeartTime = time.Now()
		dev.GetStatusInterval = time.Now()
		if dev.SubDeviceType == 0 && d.BusinessDeviceType > 0 {
			dev.SubDeviceType = uint16(d.BusinessDeviceType)
			logger.Debugf("update sub device type to %v", d.BusinessDeviceType)
		}
		return common.DeviceEnable
	} else {
		dev := &Device{
			Sn:                sn,
			Conn:              d.Conn,
			Status:            common.DevOnline,
			RemoteIp:          d.RemoteIp,
			RemotePort:        d.RemotePort,
			LocalIp:           d.LocalIp,
			ServerPort:        d.ServerPort,
			DevType:           common.DEV_V2DRONEID,
			FirstHeartTime:    time.Now(),
			LastHeartTime:     time.Now(),
			SourceId:          d.SourceId,
			IsEnable:          common.DeviceEnable, //Notice...
			GetStatusInterval: time.Now(),
			WaitTaskMap:       d.WaitTaskMap,
			SubDeviceType:     uint16(d.BusinessDeviceType),
		}

		logger.Debugf("sub dev type: %v", dev.SubDeviceType)
		DevStatusMap.Store(cacheKey, dev)
		go func() {
			time.Sleep(time.Second * 2)
			//发送白名单给tracer设备
			go SendDevWhiteList()
			if d.Conn == nil {
				return
			}
			runVer, appVer, bootVer, HwVer, protoVer, err := d.TracerGetVersionInfo(dev.Sn)
			logger.Infof("Tracer get  Ver: %v, %v, %v, %v, %v \n",
				runVer, appVer, bootVer, HwVer, protoVer)
			if err != nil {
				logger.Infof("Tracer get  Ver runVer: %v err: %v \n", runVer, err)
			}
			if appVer != "" {
				err = NewEquipList().Update(context.Background(), &client.EquipCrudReq{
					Sn:         sn,
					DevVersion: appVer,
					IsOnline:   true,
				}, &client.EquipCrudRes{})
				if err != nil {
					logger.Error("Update EquipList err: ", err)
				}
			}
		}()
		return common.DeviceEnable
	}
}

func (d *DroneID) Heart() string {
	heart := &mavlink.DroneIDHeartbeat{}
	if err := d.UnmarshalPayload(heart); err != nil {
		//使用旧协议

		heartOld := &mavlink.DroneIDHeartbeatOld{}
		if err := d.UnmarshalPayloadOld(heartOld); err != nil {
			logger.Errorf(err.Error())
			return ""
		}
		devSn := ByteToString(heartOld.Info.SN[:])
		if devSn != "" {
			if converTracerType(heart.Info.TracerType) > 0 {
				d.BusinessDeviceType = int32(converTracerType(heart.Info.TracerType))
			}

			// update device status
			d.updateStatus(devSn)
			d.updateWorkModeOnHeartBeat(devSn, int32(heart.Info.WorkMode))
			d.HeartReportOld(devSn, heartOld)
		}
		return devSn
	}

	devSn := ByteToString(heart.Info.SN[:])
	if devSn != "" {
		if converTracerType(heart.Info.TracerType) > 0 {
			d.BusinessDeviceType = int32(converTracerType(heart.Info.TracerType))
		} else {
			//因为tracerP 目前默认是 0
			d.BusinessDeviceType = int32(converTracerType(STP100))
			heart.Info.TracerType = STP100
		}
		// update device status
		d.updateStatus(devSn)
		d.updateWorkModeOnHeartBeat(devSn, int32(heart.Info.WorkMode))
		d.HeartReport(devSn, heart)
	}
	return devSn
}

func (d *DroneID) HeartReport(devSn string, heartInfo *mavlink.DroneIDHeartbeat) {
	var report mavlink.DroneIDReport
	report.IsOnline = common.DevOnline
	report.Electricity = heartInfo.Info.Electricity
	report.TimeStamp = heartInfo.Info.TimeStamp
	report.Sn = devSn
	report.BatteryStatus = heartInfo.Info.BatteryStatus
	report.WorkMode = heartInfo.Info.WorkMode
	report.WorkStatus = heartInfo.Info.WorkStatus
	report.Fault = heartInfo.Info.Fault
	report.AlarmLevel = heartInfo.Info.AlarmLevel
	report.BuzzerOn = heartInfo.Info.Buzzer
	report.VibrationOn = heartInfo.Info.Vibration
	report.StealthModeOn = heartInfo.Info.StealthMode
	report.TracerType = converTracerType(heartInfo.Info.TracerType)

	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	msg := common.EquipmentMessageBoxEntity{
		Name:      name,
		Sn:        devSn,
		MsgType:   mavlink.DRONEIDMsgHeartbeat,
		EquipType: int(common.DEV_V2DRONEID),
		Info:      report,
	}
	if err == nil {
		msg.ParentType = equipModel.ParentType
		msg.ParentSn = equipModel.ParentSn
		msg.IsIntegrated = equipModel.IsIntegrated
	}
	_ = mq.V2DroneIdBroker.Publish(mq.V2DroneIdTopic, broker.NewMessage(msg))

	go d.updateStatusOnLine(devSn, report.TracerType, &report)
	logger.Infof("heartbeat has reported:%+v, type: %v", report, report.TracerType)
}
func converTracerType(tracerType uint16) uint16 {
	tracer := TracerMap[TracerType(tracerType)]
	return tracer
}
func (d *DroneID) HeartReportOld(devSn string, heartInfo *mavlink.DroneIDHeartbeatOld) {
	var report mavlink.DroneIDReport
	report.IsOnline = common.DevOnline
	report.Electricity = heartInfo.Info.Electricity
	report.TimeStamp = heartInfo.Info.TimeStamp
	report.Sn = devSn
	report.BatteryStatus = heartInfo.Info.BatteryStatus
	report.WorkMode = heartInfo.Info.WorkMode
	report.WorkStatus = heartInfo.Info.WorkStatus
	report.AlarmLevel = heartInfo.Info.AlarmLevel

	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	msg := common.EquipmentMessageBoxEntity{
		Name:      name,
		Sn:        devSn,
		MsgType:   mavlink.DRONEIDMsgHeartbeat,
		EquipType: int(common.DEV_V2DRONEID),
		Info:      report,
	}
	if err == nil {
		msg.ParentType = equipModel.ParentType
		msg.ParentSn = equipModel.ParentSn
		msg.IsIntegrated = equipModel.IsIntegrated
	}
	_ = mq.V2DroneIdBroker.Publish(mq.V2DroneIdTopic, broker.NewMessage(msg))
	//todo 旧协议没有子设备类型
	go d.updateStatusOnLine(devSn, 0, &report)
	logger.Infof("heartbeat has reported, devSn: %v, Drone size: %v", devSn)
}

func (d *DroneID) UnmarshalPayload(data *mavlink.DroneIDHeartbeat) error {
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}

	return nil
}
func (d *DroneID) UnmarshalPayloadOld(data *mavlink.DroneIDHeartbeatOld) error {
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)

	}

	return nil
}

func V2DroneIDOfflineReport(sn string, port int) {
	var tcpServer *server.TcpServer
	if s, ok := DroneIDTcpServerMap.Load(sn); ok {
		tcpServer = s.(*server.TcpServer)

		if tcpServer != nil {
			tcpServer.Stop()
		}
		deviceUsedPorts.Delete(tcpServer.Port)
		DroneIDTcpServerMap.Delete(sn)
		DevSnMap.Delete(tcpServer.Port)
		tcpServer = nil
	}
	//
	dev := FindCacheDevice(sn, common.DEV_V2DRONEID)
	if dev != nil {
		d := &DroneID{Device: dev}
		d.collectTaskOffline(sn)
	}

	cacheKey := fmt.Sprintf("%d_%s", common.DEV_V2DRONEID, sn)
	DevStatusMap.Delete(cacheKey)
	equipModel, err := GetEquipBySn(sn)
	name := sn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	msg := common.EquipmentMessageBoxEntity{
		Name: name,
		Sn:   sn,
		Info: &mavlink.DroneIDReport{
			TimeStamp:     uint32(time.Now().Unix()),
			Electricity:   0,
			Sn:            sn,
			IsOnline:      common.DevOffline,
			BatteryStatus: 0,
			WorkMode:      0,
			WorkStatus:    0,
			AlarmLevel:    0,
		},
		MsgType:   mavlink.DRONEIDMsgHeartbeat,
		EquipType: int(common.DEV_V2DRONEID),
	}
	if err == nil {
		msg.ParentType = equipModel.ParentType
		msg.ParentSn = equipModel.ParentSn
		msg.IsIntegrated = equipModel.IsIntegrated
	}
	IsSerialMap = false
	_ = mq.V2DroneIdBroker.Publish(mq.V2DroneIdTopic, broker.NewMessage(msg))
	TracerOffLineEventReport(sn)
	logger.Info("send tracer offline:", msg)
}

func (d *DroneID) GetStatus(sn string, tracerType ...uint16) int32 {
	statusRes := &client.GetStatusRes{}
	getStatusReq := &client.GetStatusReq{
		Sn:    sn,
		EType: "DroneID",
	}
	if len(tracerType) > 0 {
		getStatusReq.SubDevType = int64(tracerType[0])
	} else {
		getStatusReq.SubDevType = int64(converTracerType(uint16(STP100)))
	}
	err := NewEquipList().GetStatus(context.Background(), getStatusReq, statusRes)

	if err != nil {
		logger.Errorf("GetStatus err: %v", err.Error())
		return 0
	}

	return statusRes.IsEnable
}

func (d *DroneID) UnMarshalGetChannelReq() string {
	devSn := ""
	switch d.MsgId {
	case mavlink.DRONEIDMsgGetChannel:
		req := &mavlink.DroneIDGetChannelRequest{}
		d.GetPacket(req)
		devSn = ByteToString(req.Sn[:])
		break
	case mavlink.RadarUdpBroadcastResponse:
		req := &mavlink.UdpBroadcastConfirmRequest{}
		d.GetPacket(req)
		devSn = strings.TrimRight(string(req.Sn[:]), string(rune(0)))
		break
	default:
		break
	}
	return devSn
}

func (d *DroneID) TcpServerCheck(devSn string, localIP []string) *server.TcpServer {
	var tcpServer *server.TcpServer
	if s, ok := DroneIDTcpServerMap.Load(devSn); ok {
		tcpServer = s.(*server.TcpServer)
		isAlike := false
		for _, ip := range localIP {
			if ip == tcpServer.Ip {
				isAlike = true
			}
		}
		if isAlike == false { //查找的本地IP没有与之前相同的
			if tcpServer != nil {
				tcpServer.Stop()
			}
			deviceUsedPorts.Delete(tcpServer.Port)
			DroneIDTcpServerMap.Delete(devSn)
			DevSnMap.Delete(tcpServer.Port)
			tcpServer = nil
		}
	}

	//注册tcp服务
	if tcpServer == nil {
		port, err := ip.GetFreeTcpPort()
		if err != nil {
			logger.Error("droneid tcp 获取可用端口失败：", err)
			port = d.getRandPort(DroneIDTcpPort, DroneIDTcpPort+DroneIDServerMaxCount)
		}
		tcpServer = server.NewTcpServer(port, Handle)
		DroneIDTcpServerMap.Store(devSn, tcpServer)
		tcpServer.ServerType = uint8(common.DEV_V2DRONEID)
		tcpServer.ServerName = devSn
		localAddr, _ := ip.GetLocalIp(d.UdpIp)
		tcpServer.Ip = localAddr
		go tcpServer.Start()
	}
	return tcpServer
}

func (d *DroneID) ReceiveGetChannelReq() {
	DroneIDTcpServerLock.Lock()
	defer DroneIDTcpServerLock.Unlock()

	devSn := d.UnMarshalGetChannelReq()
	if devSn == "" {
		logger.Info("device sn empty")
		return
	}

	if isContinue := d.deviceDiscover(devSn); !isContinue {
		logger.Error("droneID等待设备确认：", devSn)
		return
	}
	d.GetStatus(devSn)
	//if status := d.GetStatus(devSn); status == common.DeviceDisenable {
	//	logger.Infof("device %v disable", devSn)
	//	return
	//}

	localIP := make([]string, 0)

	localIps, broadIps, err := ip.GetBroadcastAddress()
	if err != nil {
		logger.Error("Get IP error :%v", err)
	}
	for i, ip := range localIps {
		if i >= len(broadIps) {
			continue
		}
		localIP = append(localIP, ip)
	}
	logger.Debugf("[tracer] localIP:%v,", localIP)

	tcpServer := d.TcpServerCheck(devSn, localIP)
	DevSnMap.Store(tcpServer.Port, devSn)
	d.ServerPort = tcpServer.Port
	//DroneIDSnMaps.Store(tcpServer.Port, devSn)

	//响应
	switch d.MsgId {
	case mavlink.DRONEIDMsgGetChannel:
		addr := d.LocalIp
		tcpServer.Ip = addr
		tcpServer.LastHeartTime = time.Now()
		res := &mavlink.DroneIDGetChannelResponse{}
		resBuff := res.CreateGetChannelResponse(addr, uint16(tcpServer.Port))
		n, err := d.Conn.Write(resBuff)
		logger.Info("droneID响应获取信道：", addr, n, err)
		break
	case mavlink.RadarUdpBroadcastResponse:
		logger.Info("[DroneID] receive Broadcast BB Msg")
		UdpBroadcastSendChannel(devSn, d.UdpIp, d.SourceId, tcpServer)
		break
	default:
		break
	}

	return
}

func (d *DroneID) GetPacket(message mavlink.Message) *mavlink.MavPacket {
	logger.Infof("GetPacket is [% x]", d.Msg)
	req := mavlink.NewNullPacket(message)
	buff := &bytes.Buffer{}
	if err := binary.Write(buff, binary.LittleEndian, d.Msg); err != nil {
		logger.Error("GetPacket write buff err:", err)
		return nil

	}
	if err := binary.Read(buff, binary.LittleEndian, &req.Header); err != nil {
		logger.Error("GetPacket read header err:", err)
		return nil
	}
	if err := binary.Read(buff, binary.LittleEndian, req.Msg); err != nil {
		logger.Error("GetPacket read msg err:", err)
		return nil
	}
	return req
}

func (d *DroneID) getPort() int {
	screenPortMutex.Lock()
	defer screenPortMutex.Unlock()
	startPort := int(ScreenTcpPort)
	usedPort, ok := deviceUsedPorts.Load(startPort)
	for ok && usedPort.(int) > 0 {
		startPort++
		usedPort, ok = deviceUsedPorts.Load(startPort)
	}
	deviceUsedPorts.Store(startPort, startPort)
	return startPort
}

func (d *DroneID) getRandPort(min, max int64) int {
	maxBigInt := big.NewInt(max)
	i, _ := rand.Int(rand.Reader, maxBigInt)
	_, ok := deviceUsedPorts.Load(i.Int64())
	port := i.Int64()
	//缓存不存在或者符合范围
	if !ok && (port > min && port < max) {
		deviceUsedPorts.Store(port, port)
		return int(port)
	}
	return d.getRandPort(min, max)
}

func (d *DroneID) deviceDiscover(sn string) bool {
	return true
}

func (d *DroneID) SendGetVersionInfo(sn string) (*client.DroneIDGetVersionInfoResponse, error) {
	req := &mavlink.DroneIDGetVersionInfoRequest{}
	buff := req.Create()
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request droneID version info err: %v", err)
		return nil, fmt.Errorf("request droneID version info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.DroneIDGetVersionInfo]
	if !ok {
		manager = NewWaitTaskManager(mavlink.DroneIDGetVersionInfo, true, 0)
		d.WaitTaskMap[mavlink.DroneIDGetVersionInfo] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request droneID version info err: %v", checkNetConnErr)
			return nil, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.DroneIDGetVersionInfoResponse)
	if !ok {
		return nil, errors.New("response err type")
	}

	r := &client.DroneIDGetVersionInfoResponse{}
	r.Company = ByteToString(res.CompanyName[:])
	r.Sn = ByteToString(res.DeviceSn[:])
	r.PsVersion = ByteToString(res.PsVersion[:])
	r.PlVersion = ByteToString(res.PlVersion[:])
	r.Ip = ByteToString(res.DeviceIP[:])
	logger.Debug("response droneID version result:%+v", *r)
	if r.PsVersion != "" {
		err = NewEquipList().Update(context.Background(), &client.EquipCrudReq{
			Sn:         sn,
			DevVersion: r.PsVersion,
		}, &client.EquipCrudRes{})
		if err != nil {
			logger.Error("Update EquipList err: ", err)
		}
	}
	return r, nil
}

func (d *DroneID) ReceiveGetVersionInfo() {
	res := &mavlink.DroneIDGetVersionInfoResponse{}
	d.GetPacket(res)
	logger.Debug("receive droneID version info:%+v", *res)
	manager, ok := d.WaitTaskMap[mavlink.DroneIDGetVersionInfo]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *DroneID) SendGetDevTypeInfo() (int32, error) {
	req := &mavlink.TracerGetDevTypeInfoRequest{}
	buff := req.Create()
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request droneID version info err: %v", err)
		return 0, fmt.Errorf("request droneID version info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.TracerGetDevTypeInfo]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerGetDevTypeInfo, true, time.Second*3)
		d.WaitTaskMap[mavlink.TracerGetDevTypeInfo] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request droneID version info err: %v", checkNetConnErr)
			return 0, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.TracerGetDevTypeInfoResponse)
	if !ok {
		return 0, errors.New("response err type")
	}

	logger.Debug("response droneID version result:%+v", *res)
	return int32(res.DevType), nil
}

func (d *DroneID) ReceiveGetDevTypeInfo() {
	res := &mavlink.TracerGetDevTypeInfoResponse{}
	d.GetPacket(res)
	logger.Debug("receive droneID DevType info:%+v", *res)
	manager, ok := d.WaitTaskMap[mavlink.TracerGetDevTypeInfo]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}
func SendDroneIDHeart() {
	ticker := time.NewTicker(time.Second * 1)
	defer ticker.Stop()
	for range ticker.C {
		DevStatusMap.Range(func(key, value interface{}) bool {
			dev := value.(*Device)
			if dev.DevType == common.DEV_V2DRONEID && dev.Status == common.DevOnline {
				reqMode := &DroneID{
					Device: dev,
					dt:     common.DEV_V2DRONEID,
				}
				reqMode.SendExtHeartbeat()
			}
			return true
		})
	}
}

func (d *DroneID) SendExtHeartbeat() error {
	GunHeartSum++
	if GunHeartSum > 255 {
		GunHeartSum = 0
	}
	req := &mavlink.DroneIDHeartbeatExtRequest{
		GunHeartSum,
	}
	reqBuff := req.CreateScreenHeartbeatExt()
	if d != nil && d.Conn != nil {
		n, err := d.Conn.Write(reqBuff)
		logger.Infof("c2发送droneID心跳结果：%v, %v, %v, 0x[% x]", GunHeartSum, n, err, reqBuff)
		if err != nil {
			equipModel, err := GetEquipBySn(d.Sn)
			name := d.Sn
			if equipModel != nil && equipModel.Name != "" {
				name = equipModel.Name
			}
			msg := common.EquipmentMessageBoxEntity{
				Name: name,
				Sn:   d.Sn,
				Info: &mavlink.DroneIDReport{
					TimeStamp: uint32(time.Now().Unix()),
					Sn:        d.Sn,
					IsOnline:  common.DevOffline,
				},
				MsgType:   mavlink.DRONEIDMsgHeartbeat,
				EquipType: int(common.DEV_V2DRONEID),
			}
			if err == nil {
				msg.ParentType = equipModel.ParentType
				msg.ParentSn = equipModel.ParentSn
				msg.IsIntegrated = equipModel.IsIntegrated
			}
			IsSerialMap = false
			_ = mq.V2DroneIdBroker.Publish(mq.V2DroneIdTopic, broker.NewMessage(msg))
			logger.Infof("send tracer offline: %+v", msg)
		}
		return err
	}
	return nil
}

func ByteToString(data []byte) string {
	nullIndex := bytes.IndexByte(data, 0)
	if nullIndex >= 0 {
		data = data[:nullIndex]
	}
	return string(data)
}

func (d *DroneID) TracerGetVersionInfo(sn string) (uint32, string, string, string, string, error) {
	logger.Info("TracerGetVersionInfo Start")
	defer func() {
		if r := recover(); r != nil {
			logger.Error("Tracer Get Version Info occurred:", r)
			return
		}
	}()
	req := &mavlink.TracerGetVersionRequest{}
	buff := req.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerIdGetVersionInfo]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerIdGetVersionInfo, true, time.Second*3)
		d.WaitTaskMap[mavlink.TracerIdGetVersionInfo] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("TracerGetVersionInfo buff: %02X \n", buff)

	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("TracerGetVersionInfo 发送获取Tracer版本信息失败: ", err)
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 0, "", "", "", "", checkNetConnErr
		}
		return 0, "", "", "", "", err
	}
	res := result.(*mavlink.TracerGetVersionResponse)
	logger.Debugf("TracerGetVersionInfo 获取Tracer版本信息结果：%#v", res)
	logger.Info("TracerGetVersionInfo End")
	if d.TrimStringSpace(res.AppVersion[:]) != "" {
		err = NewEquipList().Update(context.Background(), &client.EquipCrudReq{
			Sn:         sn,
			DevVersion: d.TrimStringSpace(res.AppVersion[:]),
		}, &client.EquipCrudRes{})
		if err != nil {
			logger.Error("Update EquipList err: ", err)
		}
	}
	return res.RunVersion,
		d.TrimStringSpace(res.AppVersion[:]),
		d.TrimStringSpace(res.BootVersion[:]),
		d.TrimStringSpace(res.HwVersion[:]),
		d.TrimStringSpace(res.ProtocolVersion[:]),
		nil
}

func (d *DroneID) TrimStringSpace(strArr []byte) string {
	tmp := make([]byte, 0)
	for _, v := range strArr {
		if v == 0x00 {
			break
		}
		tmp = append(tmp, v)
	}
	return string(tmp)
}

func (d *DroneID) ReceiveTracerGetVersionInfo() {
	res := &mavlink.TracerGetVersionResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveTracerGetVersionInfo 接收到Tracer版本信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.TracerIdGetVersionInfo]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// TracerResetSystem 系统复位
func (d *DroneID) TracerResetSystem(rq *client.ResetSystemRequest) (int32, error) {
	logger.Info("TracerResetSystem Start")
	req := &mavlink.TracerResetSystemRequest{
		ResetCode: mavlink.TracerOtaReSetCode,
		Type:      uint16(4),
	}
	buff := req.Create()

	logger.Debugf("TracerResetSystem buff: %02X \n", buff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("TracerResetSystem 发送反制抢系统复位信息失败: ", err)
		return 1, err
	}
	logger.Infof("TracerResetSystem End")
	return 0, nil
}

// TracerRequestUpgrade 请求固件升级
func (d *DroneID) TracerRequestUpgrade(data [256]byte, tryCount int) (int32, error) {
	logger.Info("TracerRequestUpgrade Start")
	var req = &mavlink.TracerRequestUpgradeRequest{
		Data: data,
	}
	buff := req.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerIdRequestUpgrade]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerIdRequestUpgrade, true, 0)
		d.WaitTaskMap[mavlink.TracerIdRequestUpgrade] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("TracerRequestUpgrade buff: %02X \n", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("TracerRequestUpgrade 请求固件升级: ", err)
		return 1, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("TracerRequestUpgrade WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 1, checkNetConnErr
		}
		return 1, err
	}
	res := result.(*mavlink.TracerRequestUpgradeResponse)
	logger.Debugf("TracerRequestUpgrade 请求固件升级：%#v", res)
	logger.Info("TracerRequestUpgrade End")
	// 嵌入是boot有个bug第一次请求A7会返回1;睡眠2两秒再重试
	if res.Status != 0 {
		if tryCount > 0 {
			tryCount--
			time.Sleep(2 * time.Second)
			return d.TracerRequestUpgrade(data, tryCount)
		}
	}
	return int32(res.Status), nil
}

// ReceiveTracerRequestUpgrade 获取请求固件升级响应
func (d *DroneID) ReceiveTracerRequestUpgrade() {
	res := &mavlink.TracerRequestUpgradeResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveTracerRequestUpgrade 获取请求固件升级响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.TracerIdRequestUpgrade]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// TracerSendUpdatePkg 发送升级固件数据
func (d *DroneID) TracerSendUpdatePkg(offset uint32, imageData []uint8) (*mavlink.TracerSendUpdatePkgResponse, error) {
	logger.Info("TracerSendUpdatePkg Start offset:", offset)
	req := &mavlink.TracerSendUpdatePkgRequest{
		ImageOffset: offset,
		ImageLength: uint32(len(imageData)),
		ImageData:   imageData,
	}
	buff, err := req.Create()
	if err != nil {
		return nil, err
	}

	// 超时重发
	result, err := d.TimeOutRepeatSendBuff(buff, 3, 5*time.Second, mavlink.TracerIdSendUpdatePkg)
	if err != nil {
		logger.Errorf("TracerSendUpdatePkg 获取发送升级固件数据信息结果报错：%#v", err)
		logger.Errorf("TracerSendUpdatePkg Err buff: %v", buff)
		logger.Errorf("TracerSendUpdatePkg WaitTask Err %s", err.Error())
		return nil, err
	}
	res := result.(*mavlink.TracerSendUpdatePkgResponse)
	logger.Debugf("TracerSendUpdatePkg 获取发送升级固件数据信息结果：%#v", result)
	return res, nil
}

// ReceiveTracerSendUpdatePkg 获取发送升级固件数据响应
func (d *DroneID) ReceiveTracerSendUpdatePkg() {
	res := &mavlink.TracerSendUpdatePkgResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveTracerSendUpdatePkg 获取发送升级固件数据响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.TracerIdSendUpdatePkg]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// TimeOutRepeatSendBuff 超时重发字节数据
func (d *DroneID) TimeOutRepeatSendBuff(buff []byte, tryCount int, timeOut time.Duration, messageId int) (interface{}, error) {
	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[messageId]
	if !ok {
		manager = NewWaitTaskManager(messageId, true, timeOut)
		d.WaitTaskMap[messageId] = manager
	}
	task := manager.AddTask(nil, nil)
	if d.Conn == nil {
		manager.DeleteTask(task.TaskId)
		fmt.Println("TimeOutRepeatSendBuff device conn is nil")
		return nil, errors.New("device conn is nil")
	}
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("TimeOutRepeatSendBuff 发送信息失败: ", err)
		fmt.Printf("TimeOutRepeatSendBuff 发送信息失败:  %v \n", err)
		manager.DeleteTask(task.TaskId)
		return nil, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		// 超时重试
		if tryCount > 0 {
			tryCount--
			fmt.Println("TimeOutRepeatSendBuff tryCount: ", tryCount)
			return d.TimeOutRepeatSendBuff(buff, tryCount, timeOut, messageId)
		}
	}
	return result, err
}

// TracerVerifyImage 校验固件镜像
func (d *DroneID) TracerVerifyImage() (int32, error) {
	logger.Info("TracerVerifyImage Start")
	req := &mavlink.TracerVerifyImageRequest{}
	buff := req.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerIdVerifyImage]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerIdVerifyImage, true, 0)
		d.WaitTaskMap[mavlink.TracerIdVerifyImage] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("TracerVerifyImage buff: %02X \n", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("TracerVerifyImage 发送校验固件镜像信息失败: ", err)
		return 1, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("TracerVerifyImage WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 1, checkNetConnErr
		}
		return 1, err
	}
	res := result.(*mavlink.TracerVerifyImageResponse)
	logger.Debugf("TracerVerifyImage 获取校验固件镜像信息结果：%#v", res)
	logger.Info("TracerVerifyImage End")
	return int32(res.Status), nil
}

// ReceiveTracerVerifyImage 获取校验固件镜像响应
func (d *DroneID) ReceiveTracerVerifyImage() {
	res := &mavlink.TracerVerifyImageResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveTracerVerifyImage 获取校验固件镜像响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.TracerIdVerifyImage]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// TracerGetUpdateTimeoutRetryTime 获取固件升级超时重试时间
func (d *DroneID) TracerGetUpdateTimeoutRetryTime() (*mavlink.TracerGetUpdateTimeoutRetryTimeResponse, error) {
	req := &mavlink.TracerGetUpdateTimeoutRetryTimeRequest{}
	buff := req.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerIdGetTimeoutRetryTime]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerIdGetTimeoutRetryTime, true, 20*time.Second)
		d.WaitTaskMap[mavlink.TracerIdGetTimeoutRetryTime] = manager
	}
	task := manager.AddTask(nil, nil)

	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("发送获取固件升级超时重试时间信息失败: ", err)
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return nil, checkNetConnErr
		}
		return nil, err
	}
	res := result.(*mavlink.TracerGetUpdateTimeoutRetryTimeResponse)
	logger.Debugf("获取固件升级超时重试时间信息结果：%#v", res)

	return res, nil
}

// ReceiveTracerGetUpdateTimeoutRetryTime 获取固件升级超时重试时间响应
func (d *DroneID) ReceiveTracerGetUpdateTimeoutRetryTime() {
	res := &mavlink.TracerGetUpdateTimeoutRetryTimeResponse{}
	d.GetPacket(res)
	logger.Debugf("获取固件升级超时重试时间回复信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.TracerIdGetTimeoutRetryTime]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// TracerSendUpgradeF1
func (d *DroneID) TracerSendUpgradeF1(fileName string, c2Ip string) (int32, error) {
	logger.Info("TracerSendUpgradeF1 Start")

	req := &mavlink.TracerUpdateF1Request{}
	buff := req.Create(fileName, c2Ip)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerIdUpgradeF1]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerIdUpgradeF1, true, 0)
		d.WaitTaskMap[mavlink.TracerIdUpgradeF1] = manager
	}
	task := manager.AddTask(nil, nil)
	logger.Debugf("TracerSendUpgradeF1 buff: %02X \n", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("TracerSendUpgradeF1 发送写入固件数据信息失败: ", err)
		return 1, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("TracerSendUpgradeF1 WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 1, checkNetConnErr
		}
		return 1, err
	}
	res := result.(*mavlink.TracerUpdateF1Response)
	logger.Debugf("TracerUpdateF1Response 获取写入固件数据信息结果：%#v", res)
	logger.Info("TracerUpdateF1Response End")
	return int32(res.Status), nil
}

// ReceiveTracerUpdateF1 获取请求固件升级响应
func (d *DroneID) ReceiveTracerUpdateF1() {
	res := &mavlink.TracerUpdateF1Response{}
	d.GetPacket(res)
	logger.Debugf("ReceiveTracerUpdateF1 获取请求固件升级响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.TracerIdUpgradeF1]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// TracerSendUpgradeF2
func (d *DroneID) TracerSendUpgradeF2() (int32, error) {
	logger.Info("TracerSendUpgradeF2 Start")
	req := &mavlink.TracerUpdateF2Request{}
	buff := req.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerIdUpgradeF2]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerIdUpgradeF2, true, time.Second*30)
		d.WaitTaskMap[mavlink.TracerIdUpgradeF2] = manager
	}
	task := manager.AddTask(nil, nil)
	logger.Debugf("TracerSendUpgradeF2 buff: %02X \n", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("TracerSendUpgradeF2 发送写入固件数据信息失败: ", err)
		return -1, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("TracerSendUpgradeF2 WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return -1, checkNetConnErr
		}
		return -1, err
	}
	res := result.(*mavlink.TracerUpdateF2Response)
	logger.Debugf("TracerUpdateF2Response 获取写入固件数据信息结果：%#v", res)
	logger.Info("TracerUpdateF2Response End")
	return int32(res.Progress), nil
}

// ReceiveTracerUpdateF2 获取请求固件升级响应
func (d *DroneID) ReceiveTracerUpdateF2() {
	res := &mavlink.TracerUpdateF2Response{}
	d.GetPacket(res)
	logger.Debugf("ReceiveTracerUpdateF2 获取请求固件升级响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.TracerIdUpgradeF2]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// TracerSendUpgradeF3
func (d *DroneID) TracerSendUpgradeF3() (int32, error) {
	logger.Info("TracerSendUpgradeF3 Start")

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerIdUpgradeF3]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerIdUpgradeF3, true, time.Second*30)
		d.WaitTaskMap[mavlink.TracerIdUpgradeF3] = manager
	}
	task := manager.AddTask(nil, nil)

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("TracerSendUpgradeF3 WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 1, checkNetConnErr
		}
		return 1, err
	}
	res := result.(*mavlink.TracerUpdateF3Response)
	logger.Debugf("TracerUpdateF3Response 获取写入固件数据信息结果：%#v", res)
	logger.Info("TracerUpdateF3Response End")
	return int32(res.UpgradeResult), nil
}

// ReceiveTracerUpdateF3 获取请求固件升级响应
func (d *DroneID) ReceiveTracerUpdateF3() {
	res := &mavlink.TracerUpdateF3Response{}
	d.GetPacket(res)
	logger.Debugf("ReceiveTracerUpdateF3 获取请求固件升级响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.TracerIdUpgradeF3]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// TracerWriteUpdateData 写入固件数据
func (d *DroneID) TracerWriteUpdateData() (int32, error) {
	logger.Info("TracerWriteUpdateData Start")
	req := &mavlink.TracerWriteUpdateDataRequest{}
	buff := req.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerIdWriteUpdateData]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerIdWriteUpdateData, true, 0)
		d.WaitTaskMap[mavlink.TracerIdWriteUpdateData] = manager
	}
	task := manager.AddTask(nil, nil)
	logger.Debugf("TracerWriteUpdateData buff: %02X \n", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("TracerWriteUpdateData 发送写入固件数据信息失败: ", err)
		return 1, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("TracerWriteUpdateData WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 1, checkNetConnErr
		}
		return 1, err
	}
	res := result.(*mavlink.TracerWriteUpdateDataResponse)
	logger.Debugf("TracerWriteUpdateData 获取写入固件数据信息结果：%#v", res)
	logger.Info("TracerWriteUpdateData End")
	return int32(res.Status), nil
}

// ReceiveTracerWriteUpdateData 获取写入固件数据响应
func (d *DroneID) ReceiveTracerWriteUpdateData() {
	res := &mavlink.TracerWriteUpdateDataResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveTracerWriteUpdateData 获取写入固件数据响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.TracerIdWriteUpdateData]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// TracerGetUpdateWriteStatus 获取固件写入状态
func (d *DroneID) TracerGetUpdateWriteStatus() (*mavlink.TracerGetUpdateWriteStatusResponse, error) {
	logger.Info("TracerGetUpdateWriteStatus Start")
	req := &mavlink.TracerGetUpdateWriteStatusRequest{}
	buff := req.Create()
	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerIdGetUpdateWriteStatus]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerIdGetUpdateWriteStatus, true, 0)
		d.WaitTaskMap[mavlink.TracerIdGetUpdateWriteStatus] = manager
	}
	task := manager.AddTask(nil, nil)

	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("TracerGetUpdateWriteStatus 发送获取固件写入状态信息失败: ", err)
		return nil, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("TracerGetUpdateWriteStatus WaitTask Err: %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return nil, checkNetConnErr
		}
		return nil, err
	}
	res := result.(*mavlink.TracerGetUpdateWriteStatusResponse)
	logger.Debugf("TracerGetUpdateWriteStatus 获取固件写入状态信息结果：%#v", res)
	logger.Info("TracerGetUpdateWriteStatus End")
	return res, nil
}

// ReceiveTracerGetUpdateWriteStatus 获取固件写入状态回复结果
func (d *DroneID) ReceiveTracerGetUpdateWriteStatus() {
	res := &mavlink.TracerGetUpdateWriteStatusResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveTracerGetUpdateWriteStatus 获取固件写入状态回复信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.TracerIdGetUpdateWriteStatus]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// TracerRunApp 运行固件App
func (d *DroneID) TracerRunApp() (int32, error) {
	logger.Info("TracerRunApp Start")
	req := &mavlink.TracerRunAppRequest{}
	buff := req.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerIdRunApp]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerIdRunApp, true, 0)
		d.WaitTaskMap[mavlink.TracerIdRunApp] = manager
	}
	task := manager.AddTask(nil, nil)
	logger.Debugf("TracerRunApp buff: %02X \n", buff)

	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("TracerRunApp 发送运行固件App信息失败: ", err)
		return 1, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("TracerRunApp WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 1, checkNetConnErr
		}
		return 1, err
	}
	res := result.(*mavlink.TracerRunAppResponse)
	logger.Debugf("TracerRunApp 获取运行固件App信息结果：%#v", res)
	logger.Info("TracerRunApp End")
	return int32(res.Status), nil
}

// ReceiveTracerRunApp 获取运行固件App响应
func (d *DroneID) ReceiveTracerRunApp() {
	res := &mavlink.TracerRunAppResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveTracerRunApp 获取运行固件App响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.TracerIdRunApp]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *DroneID) Send(sn string, reqBuff []byte) error {
	radarSendLock.Lock()
	defer radarSendLock.Unlock()
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_V2DRONEID, sn)
	cache, ok := DevStatusMap.Load(cacheKey)
	if !ok {
		return errors.New("设备未连接")
	}
	dev := cache.(*Device)
	//检查状态
	if dev.Status != common.DevOnline {
		errors.New("设备离线")
	}
	if _, err := dev.Conn.Write(reqBuff); err != nil {
		return err
	}
	return nil
}

// SendGetWorkMode 发送请求DroneId工作模式
func (d *DroneID) SendGetWorkMode() (int32, error) {
	logger.Info("---> Send Get Work Mode")
	req := &mavlink.TracerGetWorkModeRequest{}
	buff := req.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerGetWorkMode]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerGetWorkMode, true, 0)
		d.WaitTaskMap[mavlink.TracerGetWorkMode] = manager
	}
	task := manager.AddTask(nil, nil)

	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("Send Get Work Mode err: ", err)
		return 1, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send Get Work Mode err %s", err.Error())
		return 1, err
	}
	res := result.(*mavlink.TracerGetWorkModeResponse)

	logger.Info("-->End Send Get Work Mode")
	return int32(res.Status), nil
}

func (d *DroneID) ReceiveSendGetWorkMode() {
	res := &mavlink.TracerGetWorkModeResponse{}
	d.GetPacket(res)
	logger.Debugf("receive Send Get Work Mode：%+v", *res)
	manager, ok := d.WaitTaskMap[mavlink.TracerGetWorkMode]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}
func (d *DroneID) SendSetOrientationModeOnWifi(status uint8, uavNumber uint16, wifiMac string, uFreq uint32) (int32, error) {
	logger.Infof("send set orientation wifi mode")

	req := &mavlink.TracerProSetOrientRequest{}
	buff := req.Create(status, uavNumber, wifiMac, uFreq)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerProSetOrient]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerProSetOrient, true, 0)
		d.WaitTaskMap[mavlink.TracerProSetOrient] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Send Tracer Orientation wifi is :[%v]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send Set Orientation Mode wifi err:[%v].Buff is [%v]", err, buff)
		return 1, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send Set Orientation Mode wifi err %s", err.Error())
		return 1, err
	}
	res := result.(*mavlink.TracerProSetOrientResponse) // res.Status : 0 fail, 1: successful
	//如果是第一次记录，不会有记录项: Azimuth; 该值在定向过程中返回时被填充。
	TracerSOrientInstance().DoTracerSOrientLog(int32(res.Status), status,
		&TracerSOrientationSession{
			Sn:          d.Sn,
			DroneNumber: uint32(uavNumber),
			DroneName:   wifiMac,
			Freq:        uFreq,
			Status:      TracerSBeginOrienting,
		}, WriteDBForOrient)

	logger.Info("-->End Set Orientation wifi Mode")
	return int32(res.Status), nil
}

// SendSetOrientationMode 发送请求DroneId工作模式
func (d *DroneID) SendSetOrientationMode(status uint8, uavNumber uint8, uamName string, uFreq uint32) (int32, error) {
	logger.Info("---> Send Set Orientation Mode")
	req := &mavlink.TracerSetOrientationModeRequest{}
	buff := req.Create(status, uavNumber, uamName, uFreq)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerSetOrientationMode]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerSetOrientationMode, true, 0)
		d.WaitTaskMap[mavlink.TracerSetOrientationMode] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Send Tracer info is :[%v]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send Set Orientation Mode err:[%v].Buff is [%v]", err, buff)
		return 1, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send Set Orientation Mode err %s", err.Error())
		return 1, err
	}
	res := result.(*mavlink.TracerSetOrientationModeResponse) // res.Status : 0 fail, 1: successful

	//如果是第一次记录，不会有记录项: Azimuth; 该值在定向过程中返回时被填充。
	TracerSOrientInstance().DoTracerSOrientLog(int32(res.Status), status,
		&TracerSOrientationSession{
			Sn:          d.Sn,
			DroneNumber: uint32(uavNumber),
			DroneName:   uamName,
			Freq:        uFreq,
			Status:      TracerSBeginOrienting,
		}, WriteDBForOrient)

	logger.Info("-->End Set Orientation Mode")
	return int32(res.Status), nil
}

func (d *DroneID) ReceiveSendSetOrientationMode() {
	res := &mavlink.TracerSetOrientationModeResponse{}
	d.GetPacket(res)
	logger.Debugf("receive Send Set Orientation Mode：%+v", *res)
	manager, ok := d.WaitTaskMap[mavlink.TracerSetOrientationMode]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// SendTracerCli 发送请求DroneId  Cmd
func (d *DroneID) SendTracerCli(cmd string) ([]byte, error) {
	logger.Info("---> Send Tracer Cli")
	req := &mavlink.TracerCliRequest{
		Handle: 1,
		Cmd:    append([]byte(cmd), 0),
	}

	buff := req.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerCliSend]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerCliSend, true, 0)
		d.WaitTaskMap[mavlink.TracerCliSend] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Send Tracer Cli is :[%v]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send Tracer Cli err:[%v].Buff is [%v]", err, buff)
		return nil, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send Tracer Cli err %s", err.Error())
		return nil, err
	}
	res := result.(*mavlink.TracerCliResponse)

	logger.Info("-->End Set Tracer Cli")
	return res.CmdResult, nil
}

func (d *DroneID) ReceiveTracerCli() {
	res := &mavlink.TracerCliResponse{}
	var cmdRes []byte
	var status uint32
	var result uint32
	cmdRes = make([]byte, len(d.Msg)-14-mavlink.HeaderLen)
	err := mavlink.Read(bytes.NewReader(d.Msg[mavlink.HeaderLen+4:]), binary.LittleEndian, &status, 4)
	if err != nil {
		logger.Error("msg Decode Tracer Cli status err:%v", err)
		return
	}
	err = mavlink.Read(bytes.NewReader(d.Msg[mavlink.HeaderLen+8:]), binary.LittleEndian, &result, 4)
	if err != nil {
		logger.Error("msg Decode Tracer Cli result err:%v", err)
		return
	}

	err = mavlink.Read(bytes.NewReader(d.Msg[mavlink.HeaderLen+12:]), binary.LittleEndian, &cmdRes, len(d.Msg)-14-mavlink.HeaderLen)
	if err != nil {
		logger.Error("msg Decode Tracer Cli  cmdRes err:%v", err)
		return
	}
	logger.Info("cmdRes is :", cmdRes)

	//resultCode := strconv.Itoa(int(result))
	resCmd := string(cmdRes)

	logger.Info("resCmd is :", resCmd)

	res.CmdResult = []byte(resCmd)
	manager, ok := d.WaitTaskMap[mavlink.TracerCliSend]
	if ok {
		manager.CompletedTask(res, nil)
	}
	logger.Debugf("Receive Tracer Cli res.CmdResult is ", res.CmdResult)
	return
}

// SendGetLogList -----------------------------日志列表-----------------------------------------------
// 发送请求DroneId日志列表指令
func (d *DroneID) SendGetLogList(sn string) (*mavlink.DroneIdGetLogListResponseAll, error) {
	logger.Info("-->Into Send Get LogList To DroneId")
	defer func() {
		if r := recover(); r != nil {
			logger.Error("DroneID Get LogList occurred:", r)
			return
		}
	}()
	req := mavlink.DroneIdGetLogListRequest{}
	reqBuff := req.CreateDroneIdGetLogList()
	logger.Info("Send GetLogList Tracer msg is:", reqBuff)
	if err := d.Send(sn, reqBuff); err != nil {
		logger.Error("-->Send Get LogList To DroneId fail !,err is : ", err)
		return nil, err
	}
	manager, ok := d.WaitTaskMap[mavlink.TracerIdGetLogList]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerIdGetLogList, true, time.Second*10)
		d.WaitTaskMap[mavlink.TracerIdGetLogList] = manager
	}
	result, err := manager.Wait()
	if err != nil {
		logger.Error("-->Wait err:", err)
		return nil, err
	}
	logger.Info("-->Send Get LogList To DroneId End")
	return result.(*mavlink.DroneIdGetLogListResponseAll), nil
}

// ReceiveGetLogList 接收DroneId日志列表返回，组包
func (d *DroneID) ReceiveGetLogList() {
	logger.Info("-->into Revceive Get LogList DroneId")

	var PkgTotalNum uint32
	var PkgCurNum uint32
	var LogNameLen uint32
	var LogDataLen uint32
	var LogName []byte

	err := mavlink.Read(bytes.NewReader(d.Msg[mavlink.HeaderLen:]), binary.LittleEndian, &PkgTotalNum, 4)
	logger.Debug("PkgTotalNum : ", PkgTotalNum)

	err = mavlink.Read(bytes.NewReader(d.Msg[mavlink.HeaderLen+4:]), binary.LittleEndian, &PkgCurNum, 4)
	logger.Debug("PkgCurNum : ", PkgCurNum)

	if err != nil {
		logger.Error("msg Decode err:%v", err)
		return
	}
	msg := &mavlink.DroneIdGetLogListResponse{}
	index := mavlink.HeaderLen + 8

	for {
		//退出条件
		if len(d.Msg)-index < mavlink.CrcLen+1 {
			break
		}
		//解析LogNameLen
		err = mavlink.Read(bytes.NewReader(d.Msg[index:]), binary.LittleEndian, &LogNameLen, 4)
		if err != nil {
			logger.Error("msg Decode LogNameLen err:%v", err)
			return
		}
		//解析LogDataLen
		index = index + 4
		err = mavlink.Read(bytes.NewReader(d.Msg[index:]), binary.LittleEndian, &LogDataLen, 4)
		if err != nil {
			logger.Error("msg Decode LogDataLen err:%v", err)
			return
		}
		//解析LogName
		index = index + 4
		LogName = make([]byte, LogNameLen)
		err = mavlink.Read(bytes.NewReader(d.Msg[index:]), binary.LittleEndian, &LogName, int(LogNameLen))
		if err != nil {
			logger.Error("msg Decode LogName err:%v", err)
			return
		}

		logger.Debug("LogName : ", string(LogName))
		index = index + int(LogNameLen)

		if strings.Contains(string(LogName), ".txt") || strings.Contains(string(LogName), ".log") {
			msg.DroneIdLogInfo = append(msg.DroneIdLogInfo, mavlink.DroneIdLogInfo{
				LogNameLen: LogNameLen,
				LogDataLen: LogDataLen,
				LogName:    LogName,
			})
		}
	}

	var i interface{} = msg
	if PkgTotalNum != PkgTotalNum {
		logger.Info("-->Revceive ing DroneId")
		mavlink.DroneIdResAll.SetData(i.(*mavlink.DroneIdGetLogListResponse))
	} else {
		mavlink.DroneIdResAll.SetData(i.(*mavlink.DroneIdGetLogListResponse))
		logger.Info("DroneId Loglist res is %v", msg)
		manager, ok := d.WaitTaskMap[mavlink.TracerIdGetLogList]
		if ok {
			manager.CompletedTask(&mavlink.DroneIdResAll, nil)
		}
		logger.Info("-->Revceive Get LogList end DroneId")
	}
}

// SendGetLog -----------------------------请求日志-----------------------------------------------
// 发送请求DroneId日志指令
func (d *DroneID) SendGetLog(sn, filePath string, logInfo DeviceLogList) (*mavlink.DroneIdGetLogMsgResponse, error) {
	logger.Info("-->Into Send Get Log To DroneID")
	logger.Info("DroneID LogName : ", logInfo.LogName)
	defer func() {
		if r := recover(); r != nil {
			logger.Error("DroneId Get Log occurred:", r)
			return
		}
	}()
	var num uint32
	binary.Read(rand.Reader, binary.LittleEndian, &num)

	req := mavlink.DroneIdGetLogRequestAll{}
	logreq := make([]*mavlink.DroneIdGetLogRequest, 0)

	logfile := &mavlink.DroneIdLogFileInfo{
		LogId:      num,
		LogNameLen: uint32(len(logInfo.LogName)),
		LogName:    []byte(logInfo.LogName),
	}
	logreq = append(logreq, &mavlink.DroneIdGetLogRequest{
		LogNum:      1,
		LogFileInfo: [1]mavlink.DroneIdLogFileInfo{*logfile},
	})

	FileNameMap.Set(num, logInfo.LogName, filePath+"/droneID/"+sn+"/"+logInfo.LogName)

	reqBuff := req.CreateDroneIdGetLog(logreq)

	//创建文件夹
	dirpath := ""
	if strings.Contains(logInfo.LogName, "/") {
		index := strings.LastIndex(logInfo.LogName, "/")
		dirpath = filePath + "/droneID/" + sn + "/" + logInfo.LogName[:index]
	} else {
		dirpath = filePath + "/droneID/" + sn
	}
	err := helper.CreateDirIfNotExist(dirpath)
	if err != nil {
		logger.Error("Create directory error : ", err)
	} else {
		logger.Info("Directory created successfully.")
	}

	logger.Info("-->File Path is :", filePath+"/droneID/"+sn+"/"+logInfo.LogName)
	logger.Info("Send GetLog Tracer msg is:", reqBuff)
	if err = d.Send(sn, reqBuff); err != nil {
		logger.Error("-->Send Get Log To DroneID Fail,err : ", err)
		return nil, err
	}
	logger.Info("Send Get File To DroneID")

	manager, ok := d.WaitTaskMap[mavlink.TracerIdGetLog]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerIdGetLog, true, time.Second*600)
		d.WaitTaskMap[mavlink.TracerIdGetLog] = manager
	}
	// TODO 处理包序
	result, err := manager.Wait()
	if err != nil {
		logger.Error("-->Wait Fail,err : ", err)
		return nil, err
	}
	logger.Info("-->Send Get DroneID Log End")
	return result.(*mavlink.DroneIdGetLogMsgResponse), nil
}

func (d *DroneID) GetTracerLog(filePath string, logType int32, dayNum int32) (int32, error) {
	var logId uint32
	binary.Read(rand.Reader, binary.LittleEndian, &logId)
	FileNameMap.Set(logId, "", filePath)

	req := &mavlink.GetTracerLogRequest{
		LogId: logId,
		Type:  uint32(logType),
	}
	if logType == 2 {
		binary.LittleEndian.PutUint32(req.Reserved[:], uint32(dayNum))
	}
	reqBuff := req.Create()
	logger.Debugf("GetTracerLog req is :%x, %v", reqBuff, req.LogId)
	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerIdGetLogFile]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerIdGetLogFile, true, 0)
		d.WaitTaskMap[mavlink.TracerIdGetLogFile] = manager
	}
	task := manager.AddTask(nil, nil)

	// 发送请求
	if _, err := d.Conn.Write(reqBuff); err != nil {
		logger.Errorf("GetTracerLog Write err:[%v], Buff is [%v]", err, reqBuff)
		return Fail, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("GetTracerLog WaitTask err %s", err.Error())
		return Fail, err
	}

	res, ok := result.(*mavlink.GetTracerLogResponse)
	if !ok {
		err := fmt.Errorf("GetTracerLog result type error, got %v", reflect.TypeOf(result))
		logger.Error(err)
		return Fail, err
	}
	logger.Infof("-->End GetTracerLog, result: %+v", res)
	return int32(res.Status), nil
}

// ReceiveTracerLog C2获取tracer获取数据应答
func (d *DroneID) ReceiveTracerLog() {
	res := &mavlink.GetTracerLogResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveTracerLog 获取tracer获取数据应答：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.TracerIdGetLogFile]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *DroneID) getSn() string {
	value, ok := DevSnMap.Load(d.ServerPort)
	if !ok {
		logger.Errorf("getSn failed, port: %d", d.ServerPort)
		return ""
	}
	sn, ok := value.(string)
	if !ok {
		logger.Errorf("getSn failed, port: %d", d.ServerPort)
		return ""
	}
	return sn
}

func (d *DroneID) SetTimeFreq(freq uint32, mode uint32) (int32, error) {
	req := mavlink.TracerSetTimeFreqRequest{
		Mode: uint8(mode), //1-定频模式 或 2-固频率模式
		Freq: freq,
	}

	reqBuff := req.Create()

	// 接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerSetTimeFreq]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerSetTimeFreq, true, 0)
		d.WaitTaskMap[mavlink.TracerSetTimeFreq] = manager
	}
	task := manager.AddTask(nil, nil)

	// 发送请求
	if _, err := d.Conn.Write(reqBuff); err != nil {
		logger.Errorf("SetTimeFreq Write err:[%v], Buff is [%v]", err, reqBuff)
		return Fail, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("SetTimeFreq WaitTask err %s", err.Error())
		return Fail, err
	}

	res, ok := result.(*mavlink.TracerSetTimeFreqResponse)
	if !ok {
		err := fmt.Errorf("SetTimeFreq result type error, got %v", reflect.TypeOf(result))
		logger.Error(err)
		return Fail, err
	}
	logger.Infof("-->End SetTimeFreq, result: %+v", res)
	return int32(res.Status), nil
}

func (d *DroneID) ReceiveSetTimeFreq() {
	res := &mavlink.TracerSetTimeFreqResponse{}
	d.GetPacket(res)
	logger.Debug("receive droneID DevType info:%+v", *res)
	manager, ok := d.WaitTaskMap[mavlink.TracerSetTimeFreq]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// ReceiveGetLog 接收DroneId日志文件返回
func (d *DroneID) ReceiveGetLog() {
	logger.Info("-->into Receive Get Log")

	var (
		writeProgress float64 //文件写入成功百分比
		status        = Success
	)

	LogId, PkgTotalNum, PkgCurNum, fileTotalSize, msg, err := d.receiveGetLog(d.Msg)
	if err != nil {
		logger.Errorf("ReceiveGetLog err:%v", err)
		status = Fail
	}

	if status == Success {
		if PkgCurNum == 0 && PkgTotalNum == 0 { //空包不进行处理
			logger.Info("ReceiveGetLog receive empty packets")
			return
		}
		fileInfo, isExist := FileNameMap.Get(LogId)
		if !isExist {
			logger.Error("ReceiveGetLog File Name Map Get err")
			return
		}

		if PkgCurNum != PkgTotalNum {
			logger.Debug("-->Receive log ing")
			if PkgCurNum == 1 {
				//新建文件写入
				err = os.WriteFile(fileInfo.FilePath, msg, 0644)
				if err != nil {
					logger.Error("ReceiveGetLog WriteFile err:", err)
					status = Fail
				}
			} else {
				//追加写入
				file, err := os.OpenFile(fileInfo.FilePath, os.O_WRONLY|os.O_APPEND, 0644)
				if err != nil {
					logger.Error("ReceiveGetLog open file err:", err)
					status = Fail
				}
				_, err = file.Write(msg)
				if err != nil {
					logger.Errorf("ReceiveGetLog WriteString err:%v", err)
					status = Fail
				}
				defer file.Close()
			}
		} else {
			logger.Debug("-->Receive log end")
			if PkgTotalNum == 1 {
				//新建文件写入
				err = os.WriteFile(fileInfo.FilePath, msg, 0644)
				if err != nil {
					logger.Error("ReceiveGetLog last packet WriteFile err:", err)
					status = Fail
				}
			} else {
				//追加写入
				file, err := os.OpenFile(fileInfo.FilePath, os.O_WRONLY|os.O_APPEND, 0644)
				if err != nil {
					logger.Error("ReceiveGetLog last packet OpenFile err:", err)
					status = Fail
				}
				_, err = file.Write(msg)
				if err != nil {
					logger.Errorf("ReceiveGetLog last packet Write err:%v", err)
					status = Fail
				}
				defer file.Close()
			}
			FileNameMap.Del(LogId)
		}

		if status == Success {
			writeProgress = float64(PkgCurNum) * 100 / float64(PkgTotalNum)

			req := &mavlink.GetTracerLogRsp{}
			reqBuff := req.Create(PkgCurNum)
			logger.Debugf("ReceiveGetLog req is :[% x], pageIndex: %v", reqBuff, PkgCurNum)
			if _, err := d.Conn.Write(reqBuff); err != nil {
				logger.Errorf("ReceiveGetLog Write err:[%v], Buff is [%v]", err, reqBuff)
				return
			}
		}
	}

	tracerLogData := &client.TracerLogData{
		Status:        int32(status),
		WriteProgress: writeProgress,
		FileTotalSize: fileTotalSize,
	}
	d.reportTracerWriteProgress(tracerLogData)
	logger.Debugf("-->ReceiveGetLog pageIndex: %v success", PkgCurNum)
}

func (d *DroneID) receiveGetLog(msg []byte) (uint32, uint32, uint32, uint32, []byte, error) {
	var (
		logId    uint32
		pkgMax   uint32
		pkgIndex uint32
		fileSize uint32
		dataLen  uint32
		data     []byte
	)
	err := mavlink.Read(bytes.NewReader(msg[mavlink.HeaderLen:mavlink.HeaderLen+4]), binary.LittleEndian, &logId, 4)
	if err != nil {
		logger.Error("receiveGetLog LogId Decode err:%v", err)
		return 0, 0, 0, 0, nil, err
	}
	err = mavlink.Read(bytes.NewReader(msg[mavlink.HeaderLen+4:mavlink.HeaderLen+8]), binary.LittleEndian, &fileSize, 4)
	if err != nil {
		logger.Error("receiveGetLog fileTotalSize Decode err:%v", err)
		return 0, 0, 0, 0, nil, err
	}

	err = mavlink.Read(bytes.NewReader(msg[mavlink.HeaderLen+8:mavlink.HeaderLen+12]), binary.LittleEndian, &pkgMax, 4)
	if err != nil {
		logger.Error("receiveGetLog PkgTotalNum Decode err:%v", err)
		return 0, 0, 0, 0, nil, err
	}
	err = mavlink.Read(bytes.NewReader(msg[mavlink.HeaderLen+12:mavlink.HeaderLen+16]), binary.LittleEndian, &pkgIndex, 4)
	if err != nil {
		logger.Error("receiveGetLog PkgCurNum Decode err:%v", err)
		return 0, 0, 0, 0, nil, err
	}
	err = mavlink.Read(bytes.NewReader(msg[mavlink.HeaderLen+16:mavlink.HeaderLen+20]), binary.LittleEndian, &dataLen, 4)
	if err != nil {
		logger.Error("receiveGetLog PkgCurNum Decode err:%v", err)
		return 0, 0, 0, 0, nil, err
	}

	logger.Debugf("pkgMax : %d, pkgIndex : %d, logId: %d, fileSize: %d, dataLen: %d", pkgMax, pkgIndex, logId, fileSize, dataLen)

	data = make([]byte, dataLen)
	err = mavlink.Read(bytes.NewReader(msg[mavlink.HeaderLen+20:mavlink.HeaderLen+20+dataLen]), binary.LittleEndian, &data, int(dataLen))
	if err != nil {
		logger.Error("receiveGetLog data Decode err:%v", err)
		return 0, 0, 0, 0, nil, err
	}
	//data = d.Msg[mavlink.HeaderLen+20 : len(d.Msg)-mavlink.CrcLen]
	return logId, pkgMax, pkgIndex, fileSize, data, err
}

// reportTracerWriteProgress 上报前端写入进度
func (d *DroneID) reportTracerWriteProgress(tracerLogData *client.TracerLogData) {
	sn := d.Sn
	equipModel, err := GetEquipBySn(sn)
	name := sn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	msg := &client.TracerLogExportReport{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        sn,
			EquipType: int32(common.DEV_V2DRONEID),
			MsgType:   mavlink.TracerIdGetLog,
		},
		Data: tracerLogData,
	}
	if err == nil {
		msg.Header.ParentType = int32(equipModel.ParentType)
		msg.Header.ParentSn = equipModel.ParentSn
		msg.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msgOut, err := proto.Marshal(msg)
	if err != nil {
		logger.Errorf("reportTracerWriteProgress Marshal msg err:%v", err)
		return
	}
	report := &client.ClientReport{
		MsgType: int32(common.ClientMsgIDTracerLogExport),
		Data:    msgOut,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Errorf("reportTracerWriteProgress Marshal msg err:%v", err)
		return
	}
	_ = mq.TracerLogExportBroker.Publish(mq.TracerLogExportTopic, broker.NewMessage(out))
	logger.Infof("-->reportTracerWriteProgress report msg %+v success", msg)
}

// SendDelLog -----------------------------删除日志-----------------------------------------------
// 发送删除DroneId日志指令
func (d *DroneID) SendDelLog(sn string, logDir string) (*mavlink.DroneIdDelLogResponse, error) {
	logger.Info("-->Into Send Del Log")
	req := mavlink.DroneIdDelLogRequestAll{}
	reqBuff := req.CreateDroneIdDelLog(logDir)
	if err := d.Send(sn, reqBuff); err != nil {
		logger.Error("-->Send Del Log To DroneId Fail,err : ", err)
		return nil, err
	}
	manager, ok := d.WaitTaskMap[mavlink.TracerIdDeleteLog]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerIdDeleteLog, true, 0)
		d.WaitTaskMap[mavlink.TracerIdDeleteLog] = manager
	}
	// TODO 处理包序
	result, err := manager.Wait()
	if err != nil {
		logger.Error("-->Send Del Log Wait err : ", err)
		return nil, err
	}
	logger.Info("-->Send Del Log End")
	return result.(*mavlink.DroneIdDelLogResponse), nil
}

// ReceiveDelLog 接收DroneId日志文件返回
func (d *DroneID) ReceiveDelLog() {
	logger.Info("-->into Receive Del Log")
	res := &mavlink.DroneIdDelLogResponse{}
	d.GetPacket(res)
	logger.Info("Del Log response : ", res.Status)
	manager, ok := d.WaitTaskMap[mavlink.TracerIdDeleteLog]
	if ok {
		manager.CompletedTask(res, nil)
	}
	logger.Info("-->Receive Del Log end")
}

// ReceiveGetTime 接收DroneId获取时间消息
func (d *DroneID) ReceiveGetTime() {
	logger.Info("-->into Send Time To DroneID")
	res := &mavlink.DroneIdGetTimeResponse{}
	time1 := time.Now().UTC()
	resTime := time1.Format("20060102150405.000")

	var byteArr [20]byte

	for k := range resTime {
		byteArr[k] = resTime[k]
	}

	rspBuf := res.CreateGetTimeMessage(byteArr)
	logger.Debugf("Send Time To DroneID Data:%v", rspBuf)

	n, err := d.Conn.Write(rspBuf)
	logger.Debugf("Send Time To DroneID：%v,%#v", n, res)
	if err != nil {
		logger.Error("Send Time To DroneID err:", err)
		return
	}
	logger.Info("--->End Send Time To DroneID")
	return
}

func (d *DroneID) UpdateTracerTypeByDetect(detectType int32, devSn string) {
	tracerName := ""
	if detectType == mavlink.TracerIdGetDetectRes {
		tracerName = helper.DevTypeFromIntToStr(int32(client.EnumDevTypeList_TracerPDevTypeEnum))

	} else if detectType == mavlink.TracerIdGetRemoteIdDetectRes {
		tracerName = helper.DevTypeFromIntToStr(int32(client.EnumDevTypeList_TracerPDevTypeEnum))

	} else if detectType == mavlink.TracerIdGetFreqDetectRes {
		tracerName = helper.DevTypeFromIntToStr(int32(client.EnumDevTypeList_TracerSDevTypeEnum))

	} else {
	}
	if len(tracerName) <= 0 {
		return
	}

	{
		key := devSn + ":" + "tracer_type_check"

		droneIDTypeLock.Lock()
		defer droneIDTypeLock.Unlock()

		_, ok := droneIDTypeMap.Load(key)
		if ok {
			return
		}
		droneIDTypeMap.Store(key, 1)
	}

	err := NewEquipList().UpdateSomeFields(context.Background(), &client.UpdateCondReq{Sn: devSn, Etype: tracerName}, nil)
	if err != nil {
		logger.Errorf("update tracer etype fail, e: %v", err)
		return
	}
	logger.Info("update tracer etype succ, sn: %v, etype: %v", devSn, tracerName)
}

// ReceiveDetectRes 收到Tracer侦测结果
func (d *DroneID) ReceiveDetectRes() {
	logger.Info("--->Into Receive Detect Res")
	result := &mavlink.TracerDetectResult{}
	if err := d.UnmarshalPayloadDetectRes(result); err != nil {
		logger.Errorf(err.Error())
		return
	}
	devSn := ByteToString(result.Info.SN[:])
	d.updateStatus(devSn)
	//if isEnable := d.updateStatus(devSn); isEnable == common.DeviceDisenable {
	//	logger.Infof("device %v disable", devSn)
	//	return
	//}
	if len(result.Description) == 0 {
		return
	}
	if devSn != "" {
		d.detectReport(devSn, result)
	}
	//收到Tracer侦测到无人机数据，向数据库记录当天有记录
	if _, exist := RadarReplayMap.Get(devSn); exist {
		return
	}
	RadarReplayMap.Set(devSn, devSn, true)
	time1 := time.Now()
	resTime := time1.Format("20060102")
	NewDevSchedule().Insert(context.Background(), &client.DevScheduleInsertReq{Sn: devSn, Date: resTime, Information: 1}, &client.DevScheduleInsertRsp{})
	logger.Info("--->End Receive Detect Res")
}

// ReceiveDetectDronIdRemoteIdRes 收到Tracer侦测结果
func (d *DroneID) ReceiveDetectDronIdRemoteIdRes() {
	logger.Info("--->Into Receive  ReceiveDetectDronIdRemoteIdRes  Res")
	result := &mavlink.TracerDetectDroneIdRemoteIdResult{}
	if err := d.UnmarshalPayloadDroneIdRemoteIdDetectRes(result); err != nil {
		logger.Errorf(err.Error())
		return
	}
	devSn := ByteToString(result.Info.SN[:])
	d.updateStatus(devSn)
	//if isEnable := d.updateStatus(devSn); isEnable == common.DeviceDisenable {
	//	logger.Infof("device %v disable", devSn)
	//	return
	//}

	if len(result.Description) == 0 {
		logger.Error("no uav report description = 0")
		return
	}

	if devSn != "" {
		d.detectDronIdRemoteIdReport(devSn, result)
	} else {
		logger.Error("devsn is nil")
	}
	//收到Tracer侦测到无人机数据，向数据库记录当天有记录
	if _, exist := RadarReplayMap.Get(devSn); exist {
		return
	}
	RadarReplayMap.Set(devSn, devSn, true)
	time1 := time.Now()
	resTime := time1.Format("20060102")
	NewDevSchedule().Insert(context.Background(), &client.DevScheduleInsertReq{Sn: devSn, Date: resTime, Information: 1}, &client.DevScheduleInsertRsp{})
	logger.Info("--->End ReceiveDetectDronIdRemoteIdRes Receive Detect Res")
}

func (d *DroneID) updateDetectEventOne(sn string, detectInfo []*mavlink.TracerDetectDescriptionReport) {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_V2DRONEID, sn)
	if cache, ok := DevDetectMapOnEvent.Load(cacheKey); ok {
		detect := cache.(*DetectEvent)
		detect.LastReceiveTime = time.Now()
		return
	}
	if len(detectInfo) <= 0 {
		logger.Infof("detect uav info is empty")
		return
	}

	detect := &DetectEvent{
		Sn:              sn,
		LastReceiveTime: time.Now(),
		DevType:         common.DEV_V2DRONEID,
		SessionId:       GetGlobalSessionId(),
	}
	DevDetectMapOnEvent.Store(cacheKey, detect)

	var info []*client.TracerDetectDescription
	for _, desc := range detectInfo {
		if desc == nil {
			continue
		}
		info = append(info, &client.TracerDetectDescription{
			ProductType:        int32(desc.ProductType),
			DroneName:          desc.DroneName,
			SerialNum:          desc.SerialNum,
			DroneLongitude:     desc.DroneLongitude,
			DroneLatitude:      desc.DroneLatitude,
			DroneHeight:        desc.DroneHeight,
			DroneYawAngle:      desc.DroneYawAngle,
			DroneSpeed:         desc.DroneSpeed,
			DroneVerticalSpeed: desc.DroneVerticalSpeed,
			OperatorLongitude:  desc.OperatorLongitude,
			OperatorLatitude:   desc.OperatorLatitude,
			Freq:               desc.Freq,
			Distance:           int32(desc.Distance),
			DangerLevels:       int32(desc.DangerLevels),
			Role:               desc.Role,
		})
	}

	equipModel, err := GetEquipBySn(sn)
	name := sn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	eventDetectInfo := &client.TracerDetectInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        sn,
			EquipType: int32(common.DEV_V2DRONEID),
			MsgType:   mavlink.TracerEventDetectAppear,
		},
		Data: &client.TracerDetectReport{
			EventId: utils.GetEventId(detect.SessionId),
			Sn:      sn,
			Info:    info,
		},
	}
	if err == nil {
		eventDetectInfo.Header.ParentType = int32(equipModel.ParentType)
		eventDetectInfo.Header.ParentSn = equipModel.ParentSn
		eventDetectInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}

	buBuff, err := proto.Marshal(eventDetectInfo)
	if err != nil {
		logger.Errorf("Marshal TracerDetectInfo err %v", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgTracerDetectEventData,
		Data:    buBuff,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}
	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Infof("tracer detect uav event has reported, devSn: %v,report:%v", sn, detectInfo)
}
func (d *DroneID) detectReport(devSn string, detectInfo *mavlink.TracerDetectResult) {
	logger.Info("--->Into Report Detect Res")
	var report mavlink.TracerDetectReport
	report.Description = make([]*mavlink.TracerDetectDescriptionReport, 0, len(detectInfo.Description))
	report.Sn = devSn

	//查白名单中的无人机，在Tracer侦测结果中添加无人机角色
	whiteList := &client.ListResAll{}
	err := NewWhiteList().ListAll(context.Background(), &client.ListReqAll{}, whiteList)
	if err != nil {
		logger.Error("Get whiteList err: ", err)
		return
	}

	for _, drone := range detectInfo.Description {
		//1-敌军 2-友军 3-未知 4-中立     批量导入为2友军
		var role int32
		for _, info := range whiteList.WhiteList {
			if info.Sn == ByteToString(drone.SerialNum[:]) {
				role = info.Role
			}
		}
		if role == ERRTYPE {
			role = ENEMY
		}
		droneShow := genDroneName(DroneNameGen{
			DetectType: droneIDType,
			DroneName:  ByteToString(drone.DroneName[:]),
			DroneSN:    ByteToString(drone.SerialNum[:]),
		})
		r := &mavlink.TracerDetectDescriptionReport{
			ProductType: drone.ProductType,
			// DroneName:          ByteToString(drone.DroneName[:]),
			DroneName:          droneShow,
			SerialNum:          ByteToString(drone.SerialNum[:]),
			DroneLongitude:     detectInfo.DroneCoordinateConvert(float64(drone.DroneLongitude)),
			DroneLatitude:      detectInfo.DroneCoordinateConvert(float64(drone.DroneLatitude)),
			DroneHeight:        float64(drone.DroneHeight) / DroneHeightPrecision,
			DroneYawAngle:      float64(drone.DroneYawAngle) / DroneYawAnglePrecision,
			DroneSpeed:         float64(drone.DroneSpeed) / DroneSpeedPrecision,
			DroneVerticalSpeed: float64(drone.DroneVerticalSpeed) / DroneVerticalSpeedPrecision,
			OperatorLongitude:  detectInfo.DroneCoordinateConvert(float64(drone.OperatorLongitude)),
			OperatorLatitude:   detectInfo.DroneCoordinateConvert(float64(drone.OperatorLatitude)),
			Freq:               float64(drone.Freq) / FreqPrecision,
			Distance:           drone.Distance,
			DangerLevels:       drone.DangerLevels,
			Role:               role,
			DroneType:          ByteToString(drone.DroneName[:]),
		}

		//计算无人机威胁等级
		if role != FRIEND {
			fd, err := NewAlarmControl().GetDroneThreatLevel(&GetThreatLevelReq{
				DroneSn:        r.SerialNum,
				DroneObjId:     0,
				DroneLongitude: r.DroneLongitude,
				DroneLatitude:  r.DroneLatitude,
				DevSn:          devSn,
			})
			if err != nil {
				logger.Errorf("detectReport Get drone threat level err: %v", err)
			} else {
				r.AlarmId = fd.AlarmId
				r.EventId = fd.EventId
				r.ScenesId = fd.ScenesId
				r.ThreatLevel = fd.ThreatLevel
			}
		}
		report.Description = append(report.Description, r)
	}

	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	msg := common.EquipmentMessageBoxEntity{
		Name:      name,
		Sn:        devSn,
		MsgType:   mavlink.TracerIdGetDetectRes,
		EquipType: int(common.DEV_V2DRONEID),
		Info:      report,
	}
	if err == nil {
		msg.ParentType = equipModel.ParentType
		msg.ParentSn = equipModel.ParentSn
		msg.IsIntegrated = equipModel.IsIntegrated
	}
	_ = mq.TracerDetectBroker.Publish(mq.TracerDetectTopic, broker.NewMessage(msg))

	go d.updateDetectEventOne(devSn, report.Description)
	logger.Infof("Tracer Detect has reported, devSn: %v, Drone size: %v", devSn, len(report.Description))
	logger.Info("--->End Report Detect Res")
}

const (
	toDot  = 100
	toDot2 = 10
	toEDot = 1e7
)

func (d *DroneID) detectDronIdRemoteIdReport(devSn string, detectInfo *mavlink.TracerDetectDroneIdRemoteIdResult) {
	logger.Info("--->Into Report DronIdRemoteId Detect Res")
	var report mavlink.TracerDronIdRemoteIdDetectReport
	report.Description = make([]*mavlink.TracerDronIdRemoteIdDetectDescriptionReport, 0, len(detectInfo.Description))
	report.Sn = devSn
	report.BusinessDeviceType = int32(d.getSubDeviceType(devSn))

	//查白名单中的无人机，在Tracer侦测结果中添加无人机角色
	whiteList := &client.ListResAll{}
	err := NewWhiteList().ListAll(context.Background(), &client.ListReqAll{}, whiteList)
	if err != nil {
		logger.Error("Get whiteList err: ", err)
		return
	}
	tracks := make([]*mavlink.TracerDetectDescriptionReport, len(detectInfo.Description))
	logger.Debugf("detectInfo.Description = %+v", detectInfo.Description)
	for _, drone := range detectInfo.Description {
		//1-敌军 2-友军 3-未知 4-中立     批量导入为2友军
		var role int32
		for _, info := range whiteList.WhiteList {
			if info.Sn == ByteToString(drone.SerialNum[:]) {
				role = info.Role
			}
		}
		if role == ERRTYPE {
			role = ENEMY
		}
		droneShow := genDroneName(DroneNameGen{
			DetectType: droneIDType,
			DroneName:  ByteToString(drone.Name[:]),
			DroneSN:    ByteToString(drone.SerialNum[:]),
		})
		r := &mavlink.TracerDronIdRemoteIdDetectDescriptionReport{
			// Name:      ByteToString(drone.Name[:]),
			Name:      droneShow,
			SerialNum: ByteToString(drone.SerialNum[:]),
			// Uuid:           ByteToString(drone.Uuid[:]),
			Direction:      float64(drone.Direction) / toDot,
			Speed:          float64(drone.Speed) / toDot,
			VerticalSpeed:  float64(drone.VerticalSpeed) / toDot,
			Height:         float64(drone.Height) / toDot2,
			Longitude:      float64(drone.Longitude) / toEDot,
			Latitude:       float64(drone.Latitude) / toEDot,
			PilotLongitude: float64(drone.PilotLongitude) / toEDot,
			PilotLatitude:  float64(drone.PilotLatitude) / toEDot,
			HomeLongitude:  float64(drone.HomeLongitude) / toEDot,
			HomeLatitude:   float64(drone.HomeLatitude) / toEDot,
			// RecordTime:                drone.RecordTime,
			AliveTime:            drone.AliveTime, //无人机生命周期 (ms) 1
			TargetMask:           drone.TargetMask,
			TypeCodeRid:          drone.TypeCodeRid,
			SeqNumRid:            drone.SeqNumRid,
			ClassificationType:   drone.ClassificationType,
			OperationStatus:      drone.OperationStatus,
			HeightType:           drone.HeightType,
			OperatorLocationType: drone.OperatorLocationType,
			SignalFreqRid:        drone.SignalFreqRid,
			SignalPowerRid:       drone.SignalPowerRid,
			NoisePowerRid:        drone.NoisePowerRid,
			TimestampRid:         drone.TimestampRid,
			ReserveRid:           drone.ReserveRid,
			TypeCodeDid:          drone.TypeCodeDid,
			SeqNumDid:            drone.SeqNumDid,
			Altitude:             float64(drone.Altitude) / toDot2,
			SpeedX:               float64(drone.SpeedX) / toDot,
			SpeedY:               float64(drone.SpeedY) / toDot,
			SignalFreqDid:        drone.SignalFreqDid,
			SignalPowerDidCh1:    drone.SignalPowerDidCh1,
			SignalPowerDidCh2:    drone.SignalPowerDidCh2,
			GpsClock:             drone.GpsClock,
			ReserveDid:           drone.ReserveDid,
			Role:                 role,
			DroneType:            ByteToString(drone.Name[:]),
		}
		logger.Debugf("drone info = %+v", r)
		//计算无人机威胁等级
		if role != FRIEND {
			fd, err := NewAlarmControl().GetDroneThreatLevel(&GetThreatLevelReq{
				DroneSn:        r.SerialNum,
				DroneObjId:     0,
				DroneLongitude: r.Longitude,
				DroneLatitude:  r.Latitude,
				DevSn:          devSn,
			})
			if err != nil {
				logger.Errorf("detectDronIdRemoteIdReport GetDroneThreatLevel err: %v", err)
			} else {
				r.AlarmId = fd.AlarmId
				r.EventId = fd.EventId
				r.ThreatLevel = fd.ThreatLevel
				r.ScenesId = fd.ScenesId
			}
		}

		report.Description = append(report.Description, r)
		tracks = append(tracks, &mavlink.TracerDetectDescriptionReport{
			DroneName:          r.Name,
			SerialNum:          r.SerialNum,
			DroneLongitude:     r.Longitude,
			DroneLatitude:      r.Latitude,
			DroneHeight:        r.Height,
			DroneSpeed:         r.Speed,
			DroneVerticalSpeed: r.VerticalSpeed,
			OperatorLongitude:  r.PilotLongitude,
			OperatorLatitude:   r.PilotLatitude,
			Role:               r.Role,
		})
	}

	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	msg := common.EquipmentMessageBoxEntity{
		Name:      name,
		Sn:        devSn,
		MsgType:   mavlink.TracerIdGetDronIdRemoteIdDetectRes,
		EquipType: int(common.DEV_V2DRONEID),
		Info:      report,
	}
	if err == nil {
		msg.ParentType = equipModel.ParentType
		msg.ParentSn = equipModel.ParentSn
		msg.IsIntegrated = equipModel.IsIntegrated
	}
	_ = mq.TracerDetectBroker.Publish(mq.TracerDetectTopic, broker.NewMessage(msg))

	go d.updateDetectEventOne(devSn, tracks)
	logger.Infof("Tracer droneId remoteId Detect has reported, devSn: %v, Drone size: %v", devSn, len(report.Description))
	logger.Info("--->End Report droneId remoteId Detect Res")
}

func (d *DroneID) UnmarshalPayloadDetectRes(data *mavlink.TracerDetectResult) error {
	deviceInfoLen := binary.Size(mavlink.TracerDetectInfo{})
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}

	start := mavlink.HeaderLen + deviceInfoLen
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializeDrone(d.Msg[start:end]); err != nil {
		return err
	}

	return nil
}

func (d *DroneID) UnmarshalPayloadDroneIdRemoteIdDetectRes(data *mavlink.TracerDetectDroneIdRemoteIdResult) error {
	deviceInfoLen := binary.Size(mavlink.TracerDroneIdRemoteIdDetectInfo{})
	logger.Debug("deviceInfoLen = ", deviceInfoLen)
	buff := &bytes.Buffer{}
	logger.Debug("byte len = ", len(d.Msg))
	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	logger.Debug("buff = ", buff.Bytes())

	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}
	logger.Debug("data.Info = ", data.Info)
	logger.Debug("data.Info DroneNum = ", data.Info.DroneNum)
	logger.Debug("data.Info SN = ", string(data.Info.SN[:]))

	numtmp := data.Info.DroneNum
	numstr := strconv.FormatUint(uint64(numtmp), 16)
	logger.Debug("numstr = ", numstr)

	start := mavlink.HeaderLen + deviceInfoLen
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializeDrone(d.Msg[start:end]); err != nil {
		return err
	}

	return nil
}

// ReceiveUasSystemInfoRes 收到Tracer侦测uav系统信息结果
func (d *DroneID) ReceiveUasSystemInfoRes() {
	logger.Info("--->Into Receive  ReceiveUasSystemInfoRes  Res")
	result := &mavlink.TracerDetectUavSystemDataResult{}
	var upload []byte
	var err error
	if upload, err = d.UnmarshalUasSystemInfoRes(result); err != nil {
		logger.Error("UnmarshalUasSystemInfoRes:", err)
		return
	}
	devSn := ByteToString(result.Info.SN[:])

	if len(result.Description) == 0 {
		logger.Error("ReceiveUasSystemInfoRes Description is empty")
		return
	}
	if devSn != "" {
		d.detectUasSystemInfoReport(devSn, result, upload)
	}
	logger.Info("--->End ReceiveUasSystemInfoRes Receive Detect Res")
}
func (d *DroneID) detectUasSystemInfoReport(devSn string, detectInfo *mavlink.TracerDetectUavSystemDataResult, upload []byte) {
	logger.Info("--->Into Report detectUasSystemInfoReport Detect Res")
	var report mavlink.TracerDetectUavSystemDataReport
	report.Sn = devSn
	report.Description = upload
	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	msg := common.EquipmentMessageBoxEntity{
		Name:      name,
		Sn:        devSn,
		MsgType:   mavlink.TracerIdGetUasSystemInfoRes,
		EquipType: int(common.DEV_V2DRONEID),
		Info:      report,
	}
	if err == nil {
		msg.ParentType = equipModel.ParentType
		msg.ParentSn = equipModel.ParentSn
		msg.IsIntegrated = equipModel.IsIntegrated
	}
	_ = mq.TracerDetectBroker.Publish(mq.TracerDetectTopic, broker.NewMessage(msg))
	logger.Info("--->End detect UasSystemInfo Report Res")
}

func (d *DroneID) UnmarshalUasSystemInfoRes(data *mavlink.TracerDetectUavSystemDataResult) ([]byte, error) {
	deviceInfoLen := binary.Size(mavlink.TracerDetectUavSystemDataInfo{})
	buff := &bytes.Buffer{}
	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		logger.Error("UnmarshalPayload write buff err: %v", err)
		return d.Msg, fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		logger.Error("UnmarshalPayload read data err: %v", err)
		return d.Msg, fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}
	start := mavlink.HeaderLen + deviceInfoLen
	end := d.MsgLen - mavlink.CrcLen
	transferStart := mavlink.HeaderLen
	if err := data.DeserializeDrone(d.Msg[start:end]); err != nil {
		logger.Error("UnmarshalPayload read data err: %v", err)
		return d.Msg[start:end], err
	}

	return d.Msg[transferStart:end], nil
}

// ReceiveRemoteIdDetectRes 收到Tracer Remote侦测结果
func (d *DroneID) ReceiveRemoteIdDetectRes() {
	logger.Info("--->Into Receive Remote Detect Res")
	result := &mavlink.TracerRemoteDetectResult{}
	if err := d.UnmarshalPayloadRemoteDetectRes(result); err != nil {
		logger.Errorf(err.Error())
		return
	}

	devSn := ByteToString(result.Info.SN[:])
	if len(result.Description) == 0 {
		return
	}
	if devSn != "" {
		d.updateStatus(devSn)
		//if isEnable := d.updateStatus(devSn); isEnable == common.DeviceDisenable {
		//	logger.Infof("device %v disable", devSn)
		//	return
		//}
		d.remoteIdDetectReport(devSn, result)
	}
	logger.Info("--->End Receive Remote Detect Res")
}

func (d *DroneID) updateRemoteDetectEvent(sn string, detectInfo []*mavlink.TracerRemoteDetectDescriptionReport) {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_V2DRONEID, sn)
	if cache, ok := DevDetectMapOnEvent.Load(cacheKey); ok {
		detect := cache.(*DetectEvent)
		detect.LastReceiveTime = time.Now()
		return
	}
	if len(detectInfo) <= 0 {
		logger.Infof("detect uav info is empty")
		return
	}

	detect := &DetectEvent{
		Sn:              sn,
		LastReceiveTime: time.Now(),
		DevType:         common.DEV_V2DRONEID,
		SessionId:       GetGlobalSessionId(),
	}
	DevDetectMapOnEvent.Store(cacheKey, detect)

	var info []*client.TracerDetectDescription
	for _, desc := range detectInfo {
		if desc == nil {
			continue
		}
		info = append(info, &client.TracerDetectDescription{
			ProductType:    int32(desc.ProductType),
			DroneName:      desc.DroneName,
			SerialNum:      desc.SerialNum,
			DroneLongitude: desc.DroneLongitude,
			DroneLatitude:  desc.DroneLatitude,
			Role:           desc.Role,
		})
	}

	equipModel, err := GetEquipBySn(sn)
	name := sn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	eventDetectInfo := &client.TracerDetectInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        sn,
			EquipType: int32(common.DEV_V2DRONEID),
			MsgType:   mavlink.TracerEventDetectAppear,
		},
		Data: &client.TracerDetectReport{
			EventId: utils.GetEventId(detect.SessionId),
			Sn:      sn,
			Info:    info,
		},
	}
	if err == nil {
		eventDetectInfo.Header.ParentType = int32(equipModel.ParentType)
		eventDetectInfo.Header.ParentSn = equipModel.ParentSn
		eventDetectInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}

	buBuff, err := proto.Marshal(eventDetectInfo)
	if err != nil {
		logger.Errorf("Marshal TracerDetectInfo err %v", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgTracerDetectEventData,
		Data:    buBuff,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}
	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Infof("tracer detect uav event has reported, devSn: %v,report:%v", sn, detectInfo)
}
func (d *DroneID) remoteIdDetectReport(devSn string, detectInfo *mavlink.TracerRemoteDetectResult) {
	logger.Info("--->Into Receive Remote Report Res")
	var report mavlink.TracerRemoteDetectReport
	report.Description = make([]*mavlink.TracerRemoteDetectDescriptionReport, 0, len(detectInfo.Description))
	report.Sn = devSn

	//查白名单中的无人机，在Tracer侦测结果中添加无人机角色
	whiteList := &client.ListResAll{}
	err := NewWhiteList().ListAll(context.Background(), &client.ListReqAll{}, whiteList)
	if err != nil {
		logger.Error("Get whiteList err: ", err)
		return
	}
	for _, drone := range detectInfo.Description {
		//1-敌军 2-友军 3-未知 4-中立     批量导入为2友军
		var role int32
		for _, info := range whiteList.WhiteList {
			if info.Sn == ByteToString(drone.SerialNum[:]) {
				role = info.Role
			}
		}
		if role == ERRTYPE {
			role = ENEMY
		}
		droneShow := genDroneName(DroneNameGen{
			DetectType: droneIDType,
			DroneName:  ByteToString(drone.DroneName[:]),
			DroneSN:    ByteToString(drone.SerialNum[:]),
		})
		r := &mavlink.TracerRemoteDetectDescriptionReport{
			ProductType: drone.ProductType,
			// DroneName:           ByteToString(drone.DroneName[:]),
			DroneName:           droneShow,
			SerialNum:           ByteToString(drone.SerialNum[:]),
			DroneLongitude:      detectInfo.DroneCoordinateConvert(float64(drone.DroneLongitude)),
			DroneLatitude:       detectInfo.DroneCoordinateConvert(float64(drone.DroneLatitude)),
			DroneHeight:         float64(drone.DroneHeight) / DroneHeightPrecision,
			DroneDirection:      float64(drone.DroneDirection) / DroneDirection,
			DroneSpeedderection: drone.DroneSpeedderection,
			DroneSpeed:          float64(drone.DroneSpeed) / DroneSpeedPrecision,
			DroneVerticalSpeed:  float64(drone.DroneVerticalSpeed) / DroneSpeedPrecision,
			OperatorLongitude:   detectInfo.DroneCoordinateConvert(float64(drone.OperatorLongitude)),
			OperatorLatitude:    detectInfo.DroneCoordinateConvert(float64(drone.OperatorLatitude)),
			Freq:                float64(drone.Freq) / FreqPrecision,
			Distance:            drone.Distance,
			DangerLevels:        drone.DangerLevels,
			Role:                role,
			DroneType:           ByteToString(drone.DroneName[:]),
		}
		//计算无人机威胁等级
		if role != FRIEND {
			fd, err := NewAlarmControl().GetDroneThreatLevel(&GetThreatLevelReq{
				DroneSn:        r.SerialNum,
				DroneObjId:     0,
				DroneLongitude: r.DroneLongitude,
				DroneLatitude:  r.DroneLatitude,
				DevSn:          devSn,
			})
			if err != nil {
				logger.Errorf("remoteIdDetectReport GetDroneThreatLevel error: %v", err)
			} else {
				r.AlarmId = fd.AlarmId
				r.EventId = fd.EventId
				r.ThreatLevel = fd.ThreatLevel
				r.ScenesId = fd.ScenesId
			}
		}
		report.Description = append(report.Description, r)
	}

	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	msg := common.EquipmentMessageBoxEntity{
		Name:      name,
		Sn:        devSn,
		MsgType:   mavlink.TracerIdGetRemoteIdDetectRes,
		EquipType: int(common.DEV_V2DRONEID),
		Info:      report,
	}
	if err == nil {
		msg.ParentSn = equipModel.ParentSn
		msg.ParentType = equipModel.ParentType
		msg.IsIntegrated = equipModel.IsIntegrated
	}
	_ = mq.TracerDetectBroker.Publish(mq.TracerDetectTopic, broker.NewMessage(msg))

	go d.updateRemoteDetectEvent(devSn, report.Description)
	logger.Info("--->End Receive Remote Report Res")
	logger.Infof("Tracer Detect Remote has reported, devSn: %v, Drone size: %v", devSn, len(report.Description))
}

func (d *DroneID) UnmarshalPayloadRemoteDetectRes(data *mavlink.TracerRemoteDetectResult) error {
	deviceInfoLen := binary.Size(mavlink.TracerRemoteDetectInfo{})
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}

	start := mavlink.HeaderLen + deviceInfoLen
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializeDrone(d.Msg[start:end]); err != nil {
		return err
	}

	return nil
}

// ReceiveFreqDetectRes 收到Tracer 频谱侦测结果
func (d *DroneID) ReceiveFreqDetectRes() {
	logger.Info("--->Into Receive Freq Detect Res")
	result := &mavlink.TracerFreqDetectResult{}
	if err := d.UnmarshalPayloadFreqDetectRes(result); err != nil {
		logger.Errorf(err.Error())
		return
	}

	devSn := ByteToString(result.Info.SN[:])
	if len(result.Description) == 0 {
		return
	}
	if devSn != "" {
		d.updateStatus(devSn)
		//if isEnable := d.updateStatus(devSn); isEnable == common.DeviceDisenable {
		//	logger.Infof("device %v disable", devSn)
		//	return
		//}
		d.freqDetectReport(devSn, result)
	}
	logger.Info("--->End Receive Freq Detect Res")
}
func (d *DroneID) updateFreqDetectEvent(sn string, detectInfo []*mavlink.TracerFreqDetectDescription) {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_V2DRONEID, sn)
	if cache, ok := DevDetectMapOnEvent.Load(cacheKey); ok {
		detect := cache.(*DetectEvent)
		detect.LastReceiveTime = time.Now()
		return
	}
	if len(detectInfo) <= 0 {
		logger.Infof("detect uav info is empty")
		return
	}

	detect := &DetectEvent{
		Sn:              sn,
		LastReceiveTime: time.Now(),
		DevType:         common.DEV_V2DRONEID,
		SessionId:       GetGlobalSessionId(),
	}
	DevDetectMapOnEvent.Store(cacheKey, detect)

	var info []*client.TracerDetectDescription
	for _, desc := range detectInfo {
		if desc == nil {
			continue
		}
		info = append(info, &client.TracerDetectDescription{
			ProductType: int32(desc.UavNumber),
			DroneName:   string(desc.DroneName[:]),
			SerialNum:   strconv.FormatInt(int64(desc.UavNumber), 10),
			//DroneLongitude: desc.DroneLongitude,
			//DroneLatitude:  desc.DroneLatitude,
		})
	}

	equipModel, err := GetEquipBySn(sn)
	name := sn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	eventDetectInfo := &client.TracerDetectInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        sn,
			EquipType: int32(common.DEV_V2DRONEID),
			MsgType:   mavlink.TracerEventDetectAppear,
		},
		Data: &client.TracerDetectReport{
			EventId: utils.GetEventId(detect.SessionId),
			Sn:      sn,
			Info:    info,
		},
	}
	if err == nil {
		eventDetectInfo.Header.ParentType = int32(equipModel.ParentType)
		eventDetectInfo.Header.ParentSn = equipModel.ParentSn
		eventDetectInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}

	buBuff, err := proto.Marshal(eventDetectInfo)
	if err != nil {
		logger.Errorf("Marshal TracerDetectInfo err %v", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgTracerDetectEventData,
		Data:    buBuff,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}
	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Infof("tracer detect uav event has reported, devSn: %v,report:%v", sn, detectInfo)
}
func (d *DroneID) freqDetectReport(devSn string, detectInfo *mavlink.TracerFreqDetectResult) {
	logger.Info("--->Into Receive Freq Report Res")

	var report mavlink.TracerFreqDetectReport
	report.Description = make([]*mavlink.TracerFreqDetectDescriptionReport, 0, len(detectInfo.Description))
	report.Sn = devSn
	report.DxPower = float64(detectInfo.Info.DxPower)
	report.QxPower = float64(detectInfo.Info.QxPower)
	report.DxHorizon = float64(detectInfo.Info.DxHorizon) / DroneHorizonPrecision

	for _, drone := range detectInfo.Description {
		tempDroneHorizon := drone.DroneHorizon

		if tempDroneHorizon > MAXDroneHorizon {
			tempDroneHorizon = Invalid
		}
		droneShow := genDroneName(DroneNameGen{
			DetectType:   droneFreqType,
			DroneName:    ByteToString(drone.DroneName[:]),
			DroneUNumber: drone.UavNumber,
		})
		r := &mavlink.TracerFreqDetectDescriptionReport{
			UavNumber: uint32(drone.UavNumber),
			// DroneName:     ByteToString(drone.DroneName[:]),
			DroneName:     droneShow,
			DroneHorizon:  float64(tempDroneHorizon) / DroneHorizonPrecision,
			UFreq:         float64(drone.UFreq) / FreqPrecision,
			UDangerLevels: drone.UDangerLevels,
			Recerve:       drone.Recerve,
			DroneType:     ByteToString(drone.DroneName[:]),
		}
		logger.Infof("droneID Detect Freq data: %+v", *r)
		report.Description = append(report.Description, r)
	}

	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	msg := common.EquipmentMessageBoxEntity{
		Name:      name,
		Sn:        devSn,
		MsgType:   mavlink.TracerIdGetFreqDetectRes,
		EquipType: int(common.DEV_V2DRONEID),
		Info:      report,
	}
	if err == nil {
		msg.ParentType = equipModel.ParentType
		msg.ParentSn = equipModel.ParentSn
		msg.IsIntegrated = equipModel.IsIntegrated
	}
	_ = mq.TracerDetectBroker.Publish(mq.TracerDetectTopic, broker.NewMessage(msg))

	go d.updateFreqDetectEvent(devSn, detectInfo.Description)
	logger.Info("--->End Receive Freq Report Res")
	logger.Infof("Tracer Detect Freq has reported, devSn: %v, Drone size: %v", devSn, len(report.Description))
}

func (d *DroneID) UnmarshalPayloadFreqDetectRes(data *mavlink.TracerFreqDetectResult) error {
	deviceInfoLen := binary.Size(mavlink.TracerFreqDetectInfo{})
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}

	start := mavlink.HeaderLen + deviceInfoLen
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializeDrone(d.Msg[start:end]); err != nil {
		return err
	}

	return nil
}

// ReceiveNewFreqDetectRes 收到Tracer 频谱侦测结果
func (d *DroneID) ReceiveNewFreqDetectRes() {
	logger.Info("--->Into Receive New Freq Detect Res")
	result := &mavlink.TracerNewFreqDetectResult{}
	if err := d.UnmarshalPayloadNewFreqDetectRes(result); err != nil {
		logger.Errorf(err.Error())
		return
	}

	devSn := ByteToString(result.Info.SN[:])
	if len(result.Description) == 0 {
		return
	}
	if devSn != "" {
		d.updateStatus(devSn)
		//if isEnable := d.updateStatus(devSn); isEnable == common.DeviceDisenable {
		//	logger.Infof("device %v disable", devSn)
		//	return
		//}
		d.newfreqDetectReport(devSn, result)
	}
	logger.Info("--->End Receive New Freq Detect Res")
}

func (d *DroneID) updateDetectEventNew(sn string, detectInfo []*mavlink.TracerNewFreqDetectDescription) {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_V2DRONEID, sn)
	if cache, ok := DevDetectMapOnEvent.Load(cacheKey); ok {
		detect := cache.(*DetectEvent)
		detect.LastReceiveTime = time.Now()
		return
	}
	if len(detectInfo) <= 0 {
		logger.Infof("detect uav info is empty")
		return
	}

	detect := &DetectEvent{
		Sn:              sn,
		LastReceiveTime: time.Now(),
		DevType:         common.DEV_V2DRONEID,
		SessionId:       GetGlobalSessionId(),
	}
	DevDetectMapOnEvent.Store(cacheKey, detect)

	var info []*client.TracerDetectDescription
	for _, desc := range detectInfo {
		if desc == nil {
			continue
		}
		info = append(info, &client.TracerDetectDescription{
			ProductType: int32(desc.UavNumber),
			DroneName:   string(desc.DroneName[:]),
			SerialNum:   strconv.FormatInt(int64(desc.UavNumber), 10),
			//DroneLongitude: desc.DroneLongitude,
			//DroneLatitude:  desc.DroneLatitude,
		})
	}

	equipModel, err := GetEquipBySn(sn)
	name := sn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	eventDetectInfo := &client.TracerDetectInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        sn,
			EquipType: int32(common.DEV_V2DRONEID),
			MsgType:   mavlink.TracerEventDetectAppear,
		},
		Data: &client.TracerDetectReport{
			EventId: utils.GetEventId(detect.SessionId),
			Sn:      sn,
			Info:    info,
		},
	}
	if err == nil {
		eventDetectInfo.Header.ParentType = int32(equipModel.ParentType)
		eventDetectInfo.Header.ParentSn = equipModel.ParentSn
		eventDetectInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}

	buBuff, err := proto.Marshal(eventDetectInfo)
	if err != nil {
		logger.Errorf("Marshal TracerDetectInfo err %v", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgTracerDetectEventData,
		Data:    buBuff,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}
	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Infof("tracer detect uav event has reported, devSn: %v,report:%v", sn, detectInfo)

}
func (d *DroneID) newfreqDetectReport(devSn string, detectInfo *mavlink.TracerNewFreqDetectResult) {
	logger.Info("--->Into Receive New Freq Report Res")
	var report mavlink.TracerFreqDetectReport
	report.Description = make([]*mavlink.TracerFreqDetectDescriptionReport, 0, len(detectInfo.Description))
	report.Sn = devSn
	report.DxPower = float64(detectInfo.Info.DxPower)
	report.QxPower = float64(detectInfo.Info.QxPower)
	report.DxHorizon = float64(detectInfo.Info.DxHorizon) / DroneHorizonPrecision

	for _, drone := range detectInfo.Description {
		tempDroneHorizon := drone.DroneHorizon

		if tempDroneHorizon > MAXDroneHorizon {
			tempDroneHorizon = Invalid
		}
		dist := fmt.Sprintf("%.1f", drone.Dist)
		distResult, _ := strconv.ParseFloat(dist, 64)
		droneShow := genDroneName(DroneNameGen{
			DetectType:   droneFreqType,
			DroneName:    ByteToString(drone.DroneName[:]),
			DroneUNumber: drone.UavNumber,
		})
		r := &mavlink.TracerFreqDetectDescriptionReport{
			UavNumber: uint32(drone.UavNumber),
			// DroneName:     ByteToString(drone.DroneName[:]),
			DroneName:     droneShow,
			DroneHorizon:  float64(tempDroneHorizon) / DroneHorizonPrecision,
			UFreq:         float64(drone.UFreq) / FreqPrecision,
			UDangerLevels: drone.UDangerLevels,
			UMoving:       int32(drone.UMoving),
			Dist:          distResult,
			Recerve:       drone.Recerve,
			DroneType:     ByteToString(drone.DroneName[:]),
		}
		logger.Infof("droneID Detect Freq data: %+v", *r)
		report.Description = append(report.Description, r)
	}

	go d.updateDetectEventNew(devSn, detectInfo.Description)

	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	msg := common.EquipmentMessageBoxEntity{
		Name:      name,
		Sn:        devSn,
		MsgType:   mavlink.TracerIdGetFreqDetectRes,
		EquipType: int(common.DEV_V2DRONEID),
		Info:      report,
	}
	if err == nil {
		msg.ParentType = equipModel.ParentType
		msg.ParentSn = equipModel.ParentSn
		msg.IsIntegrated = equipModel.IsIntegrated
	}
	_ = mq.TracerDetectBroker.Publish(mq.TracerDetectTopic, broker.NewMessage(msg))
	logger.Info("--->End Receive New Freq Report Res")
	logger.Infof("Tracer Detect New Freq has reported, devSn: %v, Drone size: %v", devSn, len(report.Description))
}

func (d *DroneID) UnmarshalPayloadNewFreqDetectRes(data *mavlink.TracerNewFreqDetectResult) error {
	deviceInfoLen := binary.Size(mavlink.TracerNewFreqDetectInfo{})
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}

	start := mavlink.HeaderLen + deviceInfoLen
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializeDrone(d.Msg[start:end]); err != nil {
		return err
	}

	return nil
}

// ReceiveFreqDataRes 收到Tracer 频谱仪数据 E4
func (d *DroneID) ReceiveFreqDataRes() {
	logger.Info("--->Into Receive Freq Data Res")
	result := &mavlink.TracerSFreqDataResult{}
	if err := d.UnmarshalPayloadFreqDataRes(result); err != nil {
		logger.Errorf(err.Error())
		return
	}

	devSn := ByteToString(result.Info.SN[:])

	if devSn != "" {
		d.updateStatus(devSn)
		//if isEnable := d.updateStatus(devSn); isEnable == common.DeviceDisenable {
		//	logger.Infof("device %v disable", devSn)
		//	return
		//}
		d.freqDataReport(devSn, result)
	}
	logger.Info("--->End Receive Freq Detect Res")
}

// ReceiveNoiseFloorDataRes 收到Tracer上报噪底检测
func (d *DroneID) ReceiveNoiseFloorDataRes() {
	logger.Info("--->Into Receive NoiseFloor Data Res")
	result := &mavlink.TracerNoiseFloorDataResult{}
	if err := d.UnmarshalPayloadNoiseFloorDataRes(result); err != nil {
		logger.Errorf(err.Error())
		return
	}

	devSn := ByteToString(result.Info.SN[:])
	if devSn != "" {
		d.updateStatus(devSn)

		d.noiseFloorDataReport(devSn, result)
	}
	logger.Info("--->End Receive Freq Detect Res")
}

// ReceiveFreqNoiseBaseDataRes 接收tracerS的噪底监测数据上报
func (d *DroneID) ReceiveFreqNoiseBaseDataRes() {
	logger.Infof("---> to ReceiveNoiseBaseDataRes ")
	result := &mavlink.TracerSNoiseBaseDataResult{}
	if err := d.UnmarshalPayloadNoiseBaseDataRes(result); err != nil {
		logger.Errorf(err.Error())
		return
	}
	devSn := ByteToString(result.BaseInfo.Sn[:])
	if devSn != "" {
		d.updateStatus(devSn)

		d.noiseBaseFreqDataReport(devSn, result)
	}
	logger.Info("--->End Receive Freq Noise Res")
}

func (d *DroneID) UnmarshalPayloadNoiseBaseDataRes(data *mavlink.TracerSNoiseBaseDataResult) error {
	deviceInfoLen := binary.Size(mavlink.TracerSNoiseBaseDataBase{})
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.BaseInfo); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}

	start := mavlink.HeaderLen + deviceInfoLen
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializeNoiseAuxiliaryData(d.Msg[start:end]); err != nil {
		return err
	}
	return nil
}

func (d *DroneID) ReceiveFreqDetectExp() {
	logger.Infof("call ReceiveFreqDetectExp")
	result := new(mavlink.TracerSFreqDetectExp)
	if e := d.UnmarshalPayLoadFreqDetectExp(result); e != nil {
		logger.Errorf("parse TracerSFreqDetectExp from bin fail, e: %v", e)
		return
	}

	devSn := ByteToString(result.Info.SN[:])
	if len(devSn) <= 0 {
		return
	}
	if len(result.Desc) == 0 {
		return
	}
	d.updateStatus(devSn)
	d.freqDetectExpReport(devSn, result)

	for _, detectInfo := range result.Desc {
		if detectInfo == nil {
			continue
		}
		TracerSOrientInstance().DoOrientLogicOnDetect(devSn, detectInfo)
	}
}

func (d *DroneID) updateDetectEventExp(sn string, detectInfo []*mavlink.TracerSFreqDetectExpDesc) {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_V2DRONEID, sn)
	if cache, ok := DevDetectMapOnEvent.Load(cacheKey); ok {
		detect := cache.(*DetectEvent)
		detect.LastReceiveTime = time.Now()
		return
	}
	if len(detectInfo) <= 0 {
		logger.Infof("detect uav info is empty")
		return
	}

	detect := &DetectEvent{
		Sn:              sn,
		LastReceiveTime: time.Now(),
		DevType:         common.DEV_V2DRONEID,
		SessionId:       GetGlobalSessionId(),
	}
	DevDetectMapOnEvent.Store(cacheKey, detect)

	var info []*client.TracerDetectDescription
	for _, desc := range detectInfo {
		if desc == nil {
			continue
		}
		info = append(info, &client.TracerDetectDescription{
			ProductType: int32(desc.UavNumber),
			DroneName:   string(desc.DroneName[:]),
			SerialNum:   strconv.FormatInt(int64(desc.UavNumber), 10),
			//DroneLongitude: desc.DroneLongitude,
			//DroneLatitude:  desc.DroneLatitude,
		})
	}

	equipModel, err := GetEquipBySn(sn)
	name := sn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	eventDetectInfo := &client.TracerDetectInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        sn,
			EquipType: int32(common.DEV_V2DRONEID),
			MsgType:   mavlink.TracerEventDetectAppear,
		},
		Data: &client.TracerDetectReport{
			EventId: utils.GetEventId(detect.SessionId),
			Sn:      sn,
			Info:    info,
		},
	}
	if err == nil {
		eventDetectInfo.Header.ParentType = int32(equipModel.ParentType)
		eventDetectInfo.Header.ParentSn = equipModel.ParentSn
		eventDetectInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}

	buBuff, err := proto.Marshal(eventDetectInfo)
	if err != nil {
		logger.Errorf("Marshal TracerDetectInfo err %v", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgTracerDetectEventData,
		Data:    buBuff,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}
	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Infof("tracer detect uav event has reported, devSn: %v,report:%v", sn, detectInfo)
}

func (d *DroneID) freqDetectExpReport(devSn string, detectInfo *mavlink.TracerSFreqDetectExp) {
	logger.Info("--->Into Receive Freq Report expand")
	var report mavlink.TracerFreqDetectReport
	report.Description = make([]*mavlink.TracerFreqDetectDescriptionReport, 0, len(detectInfo.Desc))
	report.Sn = devSn
	report.DxPower = float64(detectInfo.Info.DxPower)
	report.QxPower = float64(detectInfo.Info.QxPower)
	report.DxHorizon = float64(detectInfo.Info.DxHorizon) / DroneHorizonPrecision
	report.StartAngle = float64(detectInfo.Info.StartAngle) / DroneHorizonPrecision
	report.EndAngle = float64(detectInfo.Info.EndAngle) / DroneHorizonPrecision

	for _, drone := range detectInfo.Desc {
		tempDroneHorizon := drone.DroneHorizon

		if tempDroneHorizon > MAXDroneHorizon {
			tempDroneHorizon = Invalid
		}
		dist := fmt.Sprintf("%.1f", drone.Reserve4)
		distResult, _ := strconv.ParseFloat(dist, 64)
		droneShow := genDroneName(DroneNameGen{
			DetectType:   droneFreqType,
			DroneName:    ByteToString(drone.DroneName[:]),
			DroneUNumber: uint8(drone.UavNumber),
		})
		r := &mavlink.TracerFreqDetectDescriptionReport{
			UavNumber: drone.UavNumber,
			// DroneName:     ByteToString(drone.DroneName[:]),
			DroneName:     droneShow,
			DroneHorizon:  float64(tempDroneHorizon) / DroneHorizonPrecision,
			UFreq:         float64(drone.UFreq) / FreqPrecision,
			UDangerLevels: drone.UDangerLevels,
			UMoving:       int32(drone.Reserve1),
			Dist:          distResult,
			Recerve:       drone.Reserve42,
			IsSptOrient:   drone.IsSptOrient,
			OrientState:   drone.OrientState,
			AmpMean:       float64(drone.AmpMean) / AmpMeanPrecision,
			DroneType:     ByteToString(drone.DroneName[:]),
		}
		logger.Infof("droneID Detect Freq data: %+v", *r)
		report.Description = append(report.Description, r)
	}

	go d.updateDetectEventExp(devSn, detectInfo.Desc)

	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	msg := common.EquipmentMessageBoxEntity{
		Name:      name,
		Sn:        devSn,
		MsgType:   mavlink.TracerIdGetFreqDetectRes,
		EquipType: int(common.DEV_V2DRONEID),
		Info:      report,
	}
	if err == nil {
		msg.ParentType = equipModel.ParentType
		msg.ParentSn = equipModel.ParentSn
		msg.IsIntegrated = equipModel.IsIntegrated
	}
	_ = mq.TracerDetectBroker.Publish(mq.TracerDetectTopic, broker.NewMessage(msg))
	logger.Infof("Tracer Detect Freq expand has reported, devSn: %v, Drone size: %v", devSn, len(report.Description))
}
func (d *DroneID) UnmarshalPayLoadFreqDetectExp(data *mavlink.TracerSFreqDetectExp) error {
	deviceInfoLen := binary.Size(mavlink.TracerFreqDetectInfoExp{})
	buff := new(bytes.Buffer)

	if e := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); e != nil {
		return fmt.Errorf("parse TracerFreqDetectInfo from bin fail, e: %v", e)
	}
	if e := binary.Read(buff, binary.LittleEndian, &data.Info); e != nil {
		return fmt.Errorf("parse TracerSFreqDetectExp.Info fail, e: %v", e)
	}
	start := mavlink.HeaderLen + deviceInfoLen
	end := d.MsgLen - mavlink.CrcLen

	if e := data.DeserializeFreqData(d.Msg[start:end]); e != nil {
		return e
	}
	return nil
}
func (d *DroneID) UnmarshalPayloadFreqDataRes(data *mavlink.TracerSFreqDataResult) error {
	deviceInfoLen := binary.Size(mavlink.TracerSFreqDataInfo{})
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}

	start := mavlink.HeaderLen + deviceInfoLen
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializeFreqData(d.Msg[start:end]); err != nil {
		return err
	}

	return nil
}
func (d *DroneID) UnmarshalPayloadNoiseFloorDataRes(data *mavlink.TracerNoiseFloorDataResult) error {
	deviceInfoLen := binary.Size(mavlink.TracerNoiseFloorDataInfo{})
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}

	start := mavlink.HeaderLen + deviceInfoLen
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializeNoiseFloorData(d.Msg[start:end]); err != nil {
		return err
	}

	return nil
}
func (d *DroneID) noiseBaseFreqDataReport(devSn string, freqData *mavlink.TracerSNoiseBaseDataResult) {
	report := &client.NoiseBaseTracerSInfo{}
	report.NoisePowerInfoItems = make([]*client.NoiseBasePowerInfo, 0, len(freqData.PowerInfo))
	report.Sn = devSn
	report.Freq = int32(freqData.BaseInfo.Freq)
	report.FreqStart = int32(freqData.BaseInfo.FreqStart)
	report.FreqEnd = int32(freqData.BaseInfo.FreqEnd)
	report.FreqStep = int32(freqData.BaseInfo.FreqStep)

	for _, description := range freqData.PowerInfo {
		report.NoisePowerInfoItems = append(report.NoisePowerInfoItems, &client.NoiseBasePowerInfo{
			MaxPower:  utils.Float64Precision(float64(description.MaxPower), 3),
			MeanPower: utils.Float64Precision(float64(description.MeanPower), 3),
		})
	}

	payload, _ := proto.Marshal(report)
	reportCli := &client.ClientReport{
		MsgType: common.ClientMsgIDTracerSNoiseBaseData,
		Data:    payload,
	}
	out, err := proto.Marshal(reportCli)
	if err != nil {
		logger.Error("Tracer BaseTracerS marshal client report got error: %v", err)
		return
	}
	_ = mq.FpvMsgBroker.Publish(mq.FpvTopic, broker.NewMessage(out))
	logger.Infof("BaseTracerS info, sn: %v, report: %v", devSn, report)
}
func (d *DroneID) noiseFloorDataReport(devSn string, freqData *mavlink.TracerNoiseFloorDataResult) {
	logger.Info("--->Into Receive noiseFloor Data Res")
	report := client.TracerNoiseFloorDataReport{}
	report.Info = make([]*client.TracerNoiseFloorDataDescriptionCh, 0, len(freqData.Description1))
	report.Sn = devSn
	report.SampleNum = freqData.Info.SampleNum
	report.Freq = uint32(freqData.Info.Freq)
	for _, description := range freqData.Description1 {
		report.Info = append(report.Info, &client.TracerNoiseFloorDataDescriptionCh{
			Ch1Val: float64(description.Ch1Val) / NoiseFloorPrecision,
			Ch2Val: float64(description.Ch2Val) / NoiseFloorPrecision,
		})
	}
	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	msg := common.EquipmentMessageBoxEntity{
		Name:      name,
		Sn:        devSn,
		MsgType:   mavlink.TracerIdGetNoiseFloorDataRes,
		EquipType: int(common.DEV_V2DRONEID),
		Info:      report,
	}
	if err == nil {
		msg.ParentSn = equipModel.ParentSn
		msg.ParentType = equipModel.ParentType
		msg.IsIntegrated = equipModel.IsIntegrated
	}

	_ = mq.TracerDetectBroker.Publish(mq.TracerDetectTopic, broker.NewMessage(msg))
	logger.Infof("Tracer   noiseFloor info, report: %v", report)
	logger.Infof("Tracer   noiseFloor data, devSn: %v", devSn)
}
func (d *DroneID) updateDetectEvent(sn string, detectInfo []*mavlink.TracerSFreqDataDescription) {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_V2DRONEID, sn)
	if cache, ok := DevDetectMapOnEvent.Load(cacheKey); ok {
		detect := cache.(*DetectEvent)
		detect.LastReceiveTime = time.Now()
		return
	}
	if len(detectInfo) <= 0 {
		logger.Infof("detect uav info is empty")
		return
	}

	detect := &DetectEvent{
		Sn:              sn,
		LastReceiveTime: time.Now(),
		DevType:         common.DEV_V2DRONEID,
		SessionId:       GetGlobalSessionId(),
	}
	DevDetectMapOnEvent.Store(cacheKey, detect)

	var info []*client.TracerDetectDescription
	for _, desc := range detectInfo {
		if desc == nil {
			continue
		}
		info = append(info, &client.TracerDetectDescription{
			Freq: float64(desc.AmpValue),
		})
	}

	equipModel, err := GetEquipBySn(sn)
	name := sn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	eventDetectInfo := &client.TracerDetectInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        sn,
			EquipType: int32(common.DEV_V2DRONEID),
			MsgType:   mavlink.TracerEventDetectAppear,
		},
		Data: &client.TracerDetectReport{
			EventId: utils.GetEventId(detect.SessionId),
			Sn:      sn,
			Info:    info,
		},
	}
	if err == nil {
		eventDetectInfo.Header.ParentType = int32(equipModel.ParentType)
		eventDetectInfo.Header.ParentSn = equipModel.ParentSn
		eventDetectInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}

	buBuff, err := proto.Marshal(eventDetectInfo)
	if err != nil {
		logger.Errorf("Marshal TracerDetectInfo err %v", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgTracerDetectEventData,
		Data:    buBuff,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}
	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Infof("tracer detect uav event has reported, devSn: %v,report:%v", sn, detectInfo)
}
func (d *DroneID) freqDataReport(devSn string, freqData *mavlink.TracerSFreqDataResult) {
	logger.Info("--->Into Receive Freq Data Res")
	report := client.TracerSFreqDataReport{}
	report.Info = make([]*client.TracerSFreqDataDescription, 0, len(freqData.Description))
	report.Sn = devSn
	report.FreqNum = int32(freqData.Info.FreqNum)
	for _, description := range freqData.Description {
		report.Info = append(report.Info, &client.TracerSFreqDataDescription{
			AmpValue: description.AmpValue,
		})

	}
	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	msg := common.EquipmentMessageBoxEntity{
		Name:      name,
		Sn:        devSn,
		MsgType:   mavlink.TracerIdGetFreqDataRes,
		EquipType: int(common.DEV_V2DRONEID),
		Info:      report,
	}
	if err == nil {
		msg.IsIntegrated = equipModel.IsIntegrated
		msg.ParentSn = equipModel.ParentSn
		msg.ParentType = equipModel.ParentType
	}
	d.updateDetectEvent(devSn, freqData.Description)

	_ = mq.TracerDetectBroker.Publish(mq.TracerDetectTopic, broker.NewMessage(msg))
	logger.Info("--->End Receive Freq Data Report Res len:", len(report.Info))
	logger.Infof("Tracers  Freq data, devSn: %v", devSn)
}

// HandleBroadCast 处理广播消息
func (d *DroneID) HandleBroadCast(ctx context.Context, req *slinkv1.UdpBroadcastConfirmRequest) (*slinkv1.UdpBroadcastConfirmResponse, error) {
	if req.GetSn() == "" {
		logger.Info("device sn empty")
		return nil, errors.New("device sn empty")
	}
	//d.GetStatus(req.GetSn())
	//if status := d.GetStatus(req.GetSn()); status == common.DeviceDisenable {
	//	logger.Infof("device %v disable", req.GetSn())
	//	return nil, nil
	//}

	localIP := make([]string, 0)
	localIps, broadIps, err := ip.GetBroadcastAddress()
	if err != nil {
		logger.Error("Get IP error :%v", err)
	}
	for i, ip := range localIps {
		if i >= len(broadIps) {
			continue
		}
		localIP = append(localIP, ip)
	}
	logger.Debugf("[tracer] localIP:%v,", localIP)

	tcpServer := d.TcpServerCheck(req.GetSn(), localIP)
	DevSnMap.Store(tcpServer.Port, req.GetSn())
	d.ServerPort = tcpServer.Port

	//响应
	rsp := &slinkv1.UdpBroadcastConfirmResponse{
		Sn:       req.Sn,
		Addr:     ip.IPV4(tcpServer.Ip),
		Port:     uint16(tcpServer.Port),
		ConnType: 1,
	}
	return rsp, nil
}

// SendTracerSetWhite 发送设置tracer白名单
func (d *DroneID) SendTracerSetWhite(snList []mavlink.TracerWhiteInfo) (int, error) {
	logger.Info("---> Send Tracer Set White")
	defer func() {
		if r := recover(); r != nil {
			logger.Error("Tracer Set White occurred:", r)
			return
		}
	}()
	req := mavlink.TracerSetWhiteRequestAll{}
	whitelist := make([]mavlink.TracerWhiteInfo, 0)
	for _, s := range snList {
		whitelist = append(whitelist, mavlink.TracerWhiteInfo{Serial: s.Serial})
	}
	reqInfo := &mavlink.TracerSetWhiteRequest{
		WhiteNum:  uint16(len(whitelist)),
		WhiteList: whitelist,
	}

	buff := req.Create(reqInfo)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerSetWhiteList]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerSetWhiteList, true, time.Millisecond*300)
		d.WaitTaskMap[mavlink.TracerSetWhiteList] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Send Tracer Set White is :[%v]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send Tracer Set White  err:[%v].Buff is [%v]", err, buff)
		return Fail, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send Tracer Set White  err %s", err.Error())
		return Fail, err
	}
	res := result.(*mavlink.TracerSetWhiteResponse)

	logger.Info("-->End Set Tracer Set Alarm")
	return int(res.Status), nil
}

func (d *DroneID) ReceiveTracerSetWhite() {
	logger.Info("-->into Receive Tracer Set White")
	res := &mavlink.TracerSetWhiteResponse{}
	d.GetPacket(res)
	logger.Debugf("Set White 接收到tracer 信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.TracerSetWhiteList]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// SendTracerSetAlarm 发送设置tracer告警
func (d *DroneID) SendTracerSetAlarm(level int) (int, error) {
	logger.Info("---> Send Tracer Set Alarm")
	req := &mavlink.TracerSetAlarmRequest{}
	buff := req.Create(level)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerSetAlarmLevel]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerSetAlarmLevel, true, 0)
		d.WaitTaskMap[mavlink.TracerSetAlarmLevel] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Send Tracer Set Alarm is :[%v]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send Tracer Set Alarm  err:[%v].Buff is [%v]", err, buff)
		return Fail, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send Tracer Set Alarm  err %s", err.Error())
		return Fail, err
	}
	res := result.(*mavlink.TracerSetAlarmResponse)

	logger.Info("-->End Set Tracer Set Alarm")
	return int(res.Status), nil
}

func (d *DroneID) ReceiveTracerSetAlarm() {
	logger.Info("-->into Receive Set Alarm")
	res := &mavlink.TracerSetAlarmResponse{}
	d.GetPacket(res)
	logger.Debugf("Set Alarm 接收到tracer 信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.TracerSetAlarmLevel]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// SendTracerSetHideMode 发送设置tracer隐蔽模式
func (d *DroneID) SendTracerSetHideMode(level int) (int, error) {
	logger.Info("---> Send Tracer Set HideMode")
	req := &mavlink.TracerSetHideModeRequest{}

	buff := req.Create(level)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerSetHideMode]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerSetHideMode, true, 0)
		d.WaitTaskMap[mavlink.TracerSetHideMode] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Send Tracer Set HideMode is :[%v]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send Tracer Set HideMode  err:[%v].Buff is [%v]", err, buff)
		return Fail, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send Tracer Set HideMode  err %s", err.Error())
		return Fail, err
	}
	res := result.(*mavlink.TracerSetHideModeResponse)

	logger.Info("-->End Set Tracer Set HideMode")
	return int(res.Status), nil
}

func (d *DroneID) ReceiveTracerSetHideMode() {
	logger.Info("-->into Receive Set Hide Mode")
	res := &mavlink.TracerSetHideModeResponse{}
	d.GetPacket(res)
	logger.Debugf("Set HideMode 接收到tracer 信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.TracerSetHideMode]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}
func SendDevWhiteList() {
	deviceInfo := &client.EquipListRes{}
	err := NewEquipList().List(context.Background(), &client.EquipListReq{}, deviceInfo)
	if err != nil {
		logger.Info("Get EquipList err: ", err)
	}
	//查白名单中的无人机，在Tracer侦测结果中添加无人机角色
	whiteList := &client.ListResAll{}
	err = NewWhiteList().ListAll(context.Background(), &client.ListReqAll{}, whiteList)
	if err != nil {
		logger.Error("Get whiteList err: ", err)
		return
	}
	logger.Info("Get EquipList is : ", whiteList.WhiteList)
	snList := make([]mavlink.TracerWhiteInfo, 0)

	for _, all := range whiteList.WhiteList {
		if all.Role == FRIEND {
			var tempSn [32]byte
			copy(tempSn[:], all.Sn)
			snList = append(snList, mavlink.TracerWhiteInfo{Serial: tempSn})
		}
	}
	for _, equip := range deviceInfo.Equips {
		if equip.Etype == "DroneID" {
			tracerInfo := FindCacheDevice(equip.Sn, common.DEV_V2DRONEID)
			if tracerInfo == nil {
				continue
			} else {
				dev := &DroneID{Device: tracerInfo}
				dev.SendTracerSetWhite(snList)
			}

		}
	}
}

const (
	VideoFail = 0
)

// ControlVideoCmd send Tracer Video control
func (d *DroneID) ControlVideoCmd(op uint8, uavName uint8, droneName []uint8, freq uint32) (int32, error) {
	tmpArray := [mavlink.DevSNLen]uint8{}
	copy(tmpArray[:], droneName)

	req := &mavlink.TracerVideoControlRequest{
		Status:    op,
		UavName:   uavName,
		DroneName: tmpArray,
		Freq:      freq,
	}

	buf := req.Build(uint8(common.DEV_V2DRONEID))
	if buf == nil {
		return VideoFail, errors.New("build send to tracer pkg fail")
	}

	mng, ok := d.WaitTaskMap[mavlink.TracerControlVideo]
	if !ok {
		mng = NewWaitTaskManager(mavlink.TracerControlVideo, true, 5*time.Second)
		d.WaitTaskMap[mavlink.TracerControlVideo] = mng
	}

	task := mng.AddTask(nil, nil)

	logger.Debugf("send tracer video msg: [% x]", buf)

	if _, e := d.Conn.Write(buf); e != nil {
		logger.Errorf("send tracer video control fail, e: %v, value: %v", e, buf)
		return VideoFail, e
	}

	ret, e := mng.WaitTask(task)
	if e != nil {
		logger.Errorf("set tracer video control response, fail,e: %v", e)
		return VideoFail, e
	}

	res := ret.(*mavlink.TracerVideoControlResponse)
	if res.Status == 0 {
		return VideoFail, nil
	}
	return int32(res.Status), nil
}
func (d *DroneID) ProcVideoCmdResponse() {
	logger.Info("--->Into Receive video cmd star/stop response from device")
	result := &mavlink.TracerVideoControlResponse{}

	d.GetPacket(result)
	logger.Debugf("ProcVideoCmdResponse 获取信息：%#v", result)
	manager, ok := d.WaitTaskMap[mavlink.TracerControlVideo]
	if ok {
		manager.CompletedTask(result, nil)
	}
	logger.Infof("process video cmd star/stop response from device.")
	return
}

// TransferVideoStream 接收视频流数据
func (d *DroneID) TransferVideoStream() {
	FpvVideoInstance().UpdateStatusOnPushingVideo()

	logger.Info("receive fpv transfer video stream.")
	videoStreamPkg := &mavlink.FpvTransferVideoStreamPkg{}

	readBegin := mavlink.HeaderLen
	offSet := mavlink.DevSNLen
	readEnd := readBegin + offSet
	err := mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, &videoStreamPkg.SN, offSet)
	logger.Debug("SN : ", ByteToString(videoStreamPkg.SN[:]))

	// struct 转 pb协议
	devSn := ByteToString(videoStreamPkg.SN[:])
	if devSn == "" {
		return
	}
	d.updateStatus(devSn)

	readBegin = readEnd
	offSet = 4
	readEnd = readBegin + offSet
	err = mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, &videoStreamPkg.FrameIndex, offSet)
	logger.Debug("FrameIndex : ", videoStreamPkg.FrameIndex)

	readBegin = readEnd
	offSet = 4
	readEnd = readBegin + offSet
	err = mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, &videoStreamPkg.PkgMax, offSet)
	logger.Debug("PkgMax : ", videoStreamPkg.PkgMax)

	readBegin = readEnd
	offSet = 4
	readEnd = readBegin + offSet
	_ = mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, &videoStreamPkg.PkgIndex, offSet)
	logger.Debug("PkgIndex : ", videoStreamPkg.PkgIndex)

	readBegin = readEnd
	offSet = 4
	readEnd = readBegin + offSet
	_ = mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, &videoStreamPkg.DataLen, offSet)
	logger.Debug("DataLen : ", videoStreamPkg.DataLen)

	if videoStreamPkg.PkgMax == 0 && videoStreamPkg.PkgIndex == 0 {
		return
	}
	if videoStreamPkg.DataLen <= 0 {
		logger.Errorf("has no msg data")
		return
	}
	logger.Infof("sub pkg data len: %v, this pkg total pkg len: %v", videoStreamPkg.DataLen, d.MsgLen)

	readBegin = readEnd
	offSet = int(videoStreamPkg.DataLen)
	readEnd = readBegin + offSet
	videoStreamPkg.Data = make([]byte, offSet)
	//  是否需要循环等待去读。应该不需要，框架根据头部长度已经把数据读完整了。
	err = mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, videoStreamPkg.Data, offSet)
	if err != nil {
		logger.Errorf("msg decode fail, e: %v", err)
		return
	}
	// 必须先更新值内容，然后在更新索引，因为更新值比更新索引更耗时，如果顺序互换，由于并发性，有可能索引建立，但是值未就绪，倒置取完整数据时异常。
	FpvVideoFrameIndexMng.SetData(int32(videoStreamPkg.FrameIndex),
		int32(videoStreamPkg.PkgIndex), videoStreamPkg.Data)

	FpvVideoFrameIndexMng.SetFramePkgIndex(int32(videoStreamPkg.FrameIndex),
		int32(videoStreamPkg.PkgIndex), int32(videoStreamPkg.PkgMax))

	if !FpvVideoFrameIndexMng.IsFullPkg(int32(videoStreamPkg.FrameIndex)) {
		logger.Infof("continue to receive pkg, frameIndex: %v", videoStreamPkg.FrameIndex)
		return
	}

	responseBuf := []byte{}
	for i := 0; i < int(videoStreamPkg.PkgMax); i++ {
		bufData := FpvVideoFrameIndexMng.GetData(int32(videoStreamPkg.FrameIndex), int32(i))
		if bufData == nil {
			logger.Infof("get incompletely frame index, omit this get, frame index: %v, pkgIndex: %v",
				videoStreamPkg.FrameIndex, i)
			return
		}
		responseBuf = append(responseBuf, bufData...)

	}
	// delete after receive all packages .
	for i := 0; i < int(videoStreamPkg.PkgMax); i++ {
		ii := int32(i)
		fIndex := int32(videoStreamPkg.FrameIndex)

		go func() {
			FpvVideoFrameIndexMng.DelData(fIndex, ii)
			FpvVideoFrameIndexMng.DelFrameIndex(fIndex)
		}()
	}

	logger.Infof("whole pkg len: %v, frameIndex: %v", len(responseBuf), videoStreamPkg.FrameIndex)

	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	msgProto := &client.FpvVideoStreams{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        devSn,
			MsgType:   mavlink.FpvVideoStreamMsg,
			EquipType: int32(common.DEV_FPV),
		},
		//
		Data: &client.FpvVideoStreamItem{
			FrameIndex: videoStreamPkg.FrameIndex,
			PackIndex:  videoStreamPkg.PkgIndex,
			PackMax:    videoStreamPkg.PkgMax,
			DataLen:    uint32(len(responseBuf)),
			Data:       responseBuf,
		},
		EndVideoCond: &client.VideoMsgForEnd{
			UavSeqNo:  FpvVideoInstance().UavSeqNo,
			DroneName: FpvVideoInstance().DroneName,
			UFreq:     FpvVideoInstance().UFreq,
			Sn:        devSn,
			DevType:   3,
		},
	}
	if err == nil {
		msgProto.Header.ParentType = int32(equipModel.ParentType)
		msgProto.Header.ParentSn = equipModel.ParentSn
		msgProto.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msgProtoBin, e := proto.Marshal(msgProto)
	if e != nil {
		logger.Errorf("marshal FpvVideoStreams fail, e: %v", e)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgIdTransferFpvVideoStream,
		Data:    msgProtoBin,
	}
	out, e := proto.Marshal(report)
	if e != nil {
		logger.Errorf("marshal report data fail, e: %v", e)
		return
	}
	e = mq.FpvMsgBroker.Publish(mq.FpvTopic, broker.NewMessage(out))
	if e != nil {
		logger.Errorf("push msg on topic: %v fail", mq.FpvTopic)
		return
	}
	logger.Info("--->End Receive fpv video stream")
}

func TracerDetectDisappearEventReport(sn string) {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_V2DRONEID, sn)
	eventId := ""

	if cache, ok := DevDetectMapOnEvent.Load(cacheKey); ok {
		dev := cache.(*DetectEvent)
		eventId = utils.GetEventId(dev.SessionId)

	} else {
		logger.Infof("not exist on event status context, sn: %v", sn)
		return
	}
	DevDetectMapOnEvent.Delete(cacheKey)

	equipModel, err := GetEquipBySn(sn)
	name := sn
	if equipModel.Name != "" {
		name = equipModel.Name
	}
	eventDetectInfo := &client.TracerDetectInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        sn,
			EquipType: int32(common.DEV_V2DRONEID),
			MsgType:   mavlink.TracerEventDetectDisappear,
		},
		Data: &client.TracerDetectReport{
			EventId: eventId,
			Sn:      sn,
		},
	}
	if err == nil {
		eventDetectInfo.Header.ParentType = int32(equipModel.ParentType)
		eventDetectInfo.Header.ParentSn = equipModel.ParentSn
		eventDetectInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}

	buBuff, err := proto.Marshal(eventDetectInfo)
	if err != nil {
		logger.Errorf("Marshal TracerDetectInfo err %v", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgTracerDetectEventData,
		Data:    buBuff,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}
	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Infof("tracer detect disappear uav event has reported, devSn: %v", sn)
}

func TracerOffLineEventReport(sn string) {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_V2DRONEID, sn)
	eventId := ""

	if cache, ok := DevStatusMapOnEvent.Load(cacheKey); ok {
		dev := cache.(*Device)
		eventId = utils.GetEventId(dev.SessionId)
	} else {
		logger.Infof("not exist on event status context, sn: %v", sn)
		return
	}

	DevStatusMapOnEvent.Delete(cacheKey)

	equipModel, err := GetEquipBySn(sn)
	name := sn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	dataInfo := &client.DroneStatusInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        sn,
			EquipType: int32(common.DEV_V2DRONEID),
			MsgType:   mavlink.TracerEventOffLine,
		},
		Data: &client.DroneIDReport{
			Sn:       sn,
			IsOnline: common.DevOffline,
			EventId:  eventId,
		},
	}
	if err == nil {
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgTracerStatusEventData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Infof("tracer Offline event report: %v", report)
}

func (d *DroneID) ReceiveTracerSetVideoParam() {
	logger.Info("-->into Receive Set Video Parameters")
	res := &mavlink.TracerSetVideoParamResponse{}
	d.GetPacket(res)
	logger.Debugf("Set Video Parameters 接收到tracer 信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.TracerSetVideoParam]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// SendTracerSetVideoParam 发送设置tracer视频参数
func (d *DroneID) SendTracerSetVideoParam(freqOffset int32, reserve uint32) (int, error) {
	logger.Info("---> Send Tracer Set Video Parameters")
	req := &mavlink.TracerSetVideoParamRequest{}
	buff := req.Create(freqOffset, reserve)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerSetVideoParam]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerSetVideoParam, true, 0)
		d.WaitTaskMap[mavlink.TracerSetVideoParam] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Send Tracer Set Video Parameters is :[%v]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send Tracer Set Video Parameters err:[%v].Buff is [%v]", err, buff)
		return Fail, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send Tracer Set Video Parameters err %s", err.Error())
		return Fail, err
	}
	res := result.(*mavlink.TracerSetVideoParamResponse)

	logger.Info("-->End Set Tracer Set Video Parameters")
	return int(res.Status), nil
}

func (d *DroneID) GetDetectFreqList(sn string) ([]uint32, error) {
	logger.Info("---> Send GetDetectFreqList")
	req := &mavlink.TracerFreqDetectNodeListRequest{}
	buff := req.Create(0)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerFreqDetectNodeList]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerFreqDetectNodeList, true, 0)
		d.WaitTaskMap[mavlink.TracerFreqDetectNodeList] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Send Tracer GetDetectFreqList is :[% x]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send Tracer GetDetectFreqList err:[%v].Buff is [% x]", err, buff)
		return nil, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send Tracer GetDetectFreqList err %s", err.Error())
		return nil, err
	}
	res := result.(*mavlink.TracerFreqDetectNodeListResponse)

	logger.Info("-->End GetDetectFreqList")
	return res.FreqList, nil
}

var (
	sessionCollMng = &SessionCollectMng{
		collects: make(map[string]*ClientCollectSession),
	}
)

// SessionCollectMng 多设备下的数据收集管理器
type SessionCollectMng struct {
	lk       sync.Mutex
	collects map[string]*ClientCollectSession
}

func (sm *SessionCollectMng) GetPkgIndex(sn string) (error, int32) {
	if sm == nil {
		return fmt.Errorf("is nil"), 0
	}
	sm.lk.Lock()
	defer sm.lk.Unlock()

	item, ok := sm.collects[sn]
	if !ok || item == nil {
		return fmt.Errorf("not exist sn: %v", sn), 0
	}
	return item.GetCurrentPkgIndex()
}
func (sm *SessionCollectMng) SetPkgIndex(sn string, index int32) error {
	if sm == nil {
		return fmt.Errorf("is nil")
	}
	sm.lk.Lock()
	defer sm.lk.Unlock()

	item, ok := sm.collects[sn]
	if !ok || item == nil {
		return fmt.Errorf("not exist sn: %v", sn)
	}

	item.SetCurrentPkgIndex(index)
	return nil
}

// GetFileParameters 获取文件参数
func (sm *SessionCollectMng) GetFileParameters(sn string) (uint32, uint32, string) {
	var (
		fileSze        uint32 = 0
		receivedFileSz uint32 = 0
		filePath       string = ""
	)

	if sm == nil || sn == "" {
		return fileSze, receivedFileSz, filePath
	}
	sm.lk.Lock()
	defer sm.lk.Unlock()
	item, ok := sm.collects[sn]
	if !ok || item == nil {
		return fileSze, receivedFileSz, filePath
	}
	return item.GetFileParameters(sn)
}
func (sm *SessionCollectMng) GetToDevStopMode(sn string) (uint8, error) {
	if sm == nil || sn == "" {
		return 0, fmt.Errorf("param is nil")
	}
	sm.lk.Lock()
	defer sm.lk.Unlock()
	item, ok := sm.collects[sn]
	if !ok || item == nil {
		return 0, fmt.Errorf("not exist sn")
	}
	return item.tmOutStopMode, nil
}

// UpdateReceiveFileSz 更新接收到的文件长度，返回已接收的数据长度
func (sm *SessionCollectMng) UpdateReceiveFileSz(sn string, sz uint32) uint32 {
	if sm == nil || sn == "" {
		return 0
	}
	item, ok := sm.collects[sn]
	if !ok || item == nil {
		return 0
	}
	return item.AddFileSize(sz)
}
func (sm *SessionCollectMng) IsBegin(sn string) bool {
	if sm == nil || sn == "" || sm.collects == nil {
		return false
	}
	sm.lk.Lock()
	defer sm.lk.Unlock()

	item, ok := sm.collects[sn]
	if !ok || item == nil {
		return false
	}
	return item.IsBeginStatus(sn)
}

// UnRegister 从管理器中停止 collect任务，删除任务
func (sm *SessionCollectMng) UnRegister(sn string) {
	if sn == "" {
		return
	}

	sm.lk.Lock()
	defer sm.lk.Unlock()
	if sm == nil || sm.collects == nil {
		return
	}

	if s, ok := sm.collects[sn]; ok {
		if s != nil {
			s.StopSession()
			time.Sleep(10 * time.Millisecond)
		}
		delete(sm.collects, sn)

		logger.Infof("del client collect session, sn: %v", sn)
	}
}

func (sm *SessionCollectMng) CheckCurrentReceiveStatus(sn string, status int32) bool {
	if sm == nil || sn == "" {
		return false
	}
	sm.lk.Lock()
	defer sm.lk.Unlock()

	s, ok := sm.collects[sn]
	if !ok || s == nil {
		return false
	}
	return s.CompareAndSwapCurrentStatus(status)
}

// Register 将 client collection session 加入到全局管理器对象中
func (sm *SessionCollectMng) Register(sn string, fileName string, taskTimeoutCB CollectTimeoutCallback,
	initFn func(string, string, CollectTimeoutCallback, uint8) *ClientCollectSession, toDevStopMode uint8) {
	if sn == "" {
		return
	}
	sm.lk.Lock()
	defer sm.lk.Unlock()

	if sm.collects == nil {
		sm.collects = make(map[string]*ClientCollectSession)
	}

	collectItem := initFn(sn, fileName, taskTimeoutCB, toDevStopMode)
	//
	sm.collects[sn] = collectItem
}

// IsRegistered 是否包含 sn 对应的 client collect data
func (sm *SessionCollectMng) IsRegistered(sn string) bool {
	if sn == "" {
		return false
	}

	sm.lk.Lock()
	defer sm.lk.Unlock()

	if sm.collects == nil {
		return false
	}
	_, ok := sm.collects[sn]
	if ok {
		return true
	}
	return false
}

// WriteBuffToFile 写文件
func (sm *SessionCollectMng) WriteBuffToFile(sn string, buf []byte) error {
	if sm == nil || sn == "" || len(buf) == 0 {
		logger.Error("sn is nil or buf is nil")
		return nil
	}

	var sessionHandle *ClientCollectSession = nil
	{
		sm.lk.Lock()
		defer sm.lk.Unlock()
		item, ok := sm.collects[sn]
		if !ok || item == nil {
			return nil
		}
		sessionHandle = item
	}

	if sessionHandle == nil {
		logger.Error("sessionHandle is nil")
		return nil
	}
	sessionHandle.WriteBufToFile(sn, buf)
	return nil
}
func (sm *SessionCollectMng) StartSession(sn string) {
	if sn == "" {
		return
	}
	sm.lk.Lock()
	defer sm.lk.Unlock()

	if sm.collects == nil {
		return
	}

	c, ok := sm.collects[sn]
	if !ok || c == nil {
		return
	}
	c.StartSessionTask(sn)
}
func (mc *SessionCollectMng) UpdateTime(sn string) {
	if mc == nil || sn == "" {
		return
	}
	mc.lk.Lock()
	defer mc.lk.Unlock()

	if item, ok := mc.collects[sn]; ok && item != nil {
		item.UpdateCollectTime()
	}
}
func (mc *SessionCollectMng) UpdateFileSize(sn string, fz uint32) {
	if fz == 0 || mc == nil || sn == "" {
		return
	}
	mc.lk.Lock()
	defer mc.lk.Unlock()

	if item, ok := mc.collects[sn]; ok && item != nil {
		item.UpdateFileSize(fz)
	}
}

// ClientCollectSession 数据收集会话, 由client 发起创建
type ClientCollectSession struct {
	sn                string
	fileName          string
	finStatus         atomic.Int32 // 有限状态机
	fileSize          uint32       // 单位: byte
	receiveCurrStatus atomic.Int32 // 接收上报的当前状态，默认是从1开始

	sessionTmout string // 10s
	Ctx          context.Context
	CancelFunc   context.CancelFunc
	workTmr      *helper.GeneralTaskTimer //
	//
	LastCollectTime atomic.Int64           // unit is second, latest collect time
	timeoutCB       CollectTimeoutCallback //定时器超时后的业务逻辑处理
	tmOutStopMode   uint8                  //超时时发送结束采集模式：0:停止采集，3：停止一键采集（全频段扫描）

	receiveFileSize atomic.Uint32 // unit byte

	currentPkgIndex atomic.Int32
}

func (s *ClientCollectSession) SetCurrentPkgIndex(index int32) {
	if index < 0 {
		return
	}
	s.currentPkgIndex.Store(index)
}
func (s *ClientCollectSession) GetCurrentPkgIndex() (error, int32) {
	if s == nil {
		return fmt.Errorf("handle is nil"), 0
	}
	return nil, s.currentPkgIndex.Load()
}

func (s *ClientCollectSession) GetFileParameters(sn string) (uint32, uint32, string) {
	var (
		fileSze        uint32 = 0
		receivedFileSz uint32 = 0
		filePath       string = ""
	)
	if s == nil || s.sn != sn {
		return fileSze, receivedFileSz, filePath
	}

	return s.fileSize, s.receiveFileSize.Load(), s.fileName
}

// AddFileSize 增加新增 文件内容
func (s *ClientCollectSession) AddFileSize(sz uint32) uint32 {
	if s == nil {
		return sz
	}
	return s.receiveFileSize.Add(sz)
}

// WriteBufToFile 向指定文件写内容
func (s *ClientCollectSession) WriteBufToFile(sn string, buff []byte) {
	if s == nil || s.fileName == "" || len(buff) == 0 {
		logger.Errorf("file name is nil or to write buf is nil")
		return
	}
	fHandle, err := os.OpenFile(s.fileName, os.O_WRONLY|os.O_CREATE|os.O_APPEND, 0644)
	if err != nil {
		logger.Errorf("open file: %v  fail, err: %v", s.fileName, err)
		return
	}
	defer fHandle.Close()

	fInfo, e := fHandle.Stat()
	if e != nil {
		logger.Errorf("stat file info fail, e: %v, sn: %v", e, sn)
		return
	}

	fileSz := fInfo.Size()
	toBufLen := int64(len(buff))

	if (fInfo.Size() + int64(len(buff))) > int64(s.fileSize) {
		logger.Errorf("write file fail, file size now: %v, to buf size: %v, to write file size: %v, sn: %v",
			fileSz, toBufLen, s.fileSize, sn)
		return
	}

	n, err := fHandle.Write(buff)
	if err != nil {
		logger.Errorf("write data to file: %v fail, err: %v, sn: %v", s.fileName, err, sn)
		return
	}
	logger.Infof("write to file: %v, ret nums: %v, sn: %v", s.fileName, n, sn)
}

// UpdateFileSize 更新收集数据文件大小
func (s *ClientCollectSession) UpdateFileSize(sz uint32) {
	if sz <= 0 || s == nil {
		return
	}
	s.fileSize = sz
}

// UpdateCollectTime 更新设备收集数据上报时间点
func (s *ClientCollectSession) UpdateCollectTime() {
	if s == nil {
		return
	}
	s.LastCollectTime.Store(time.Now().Unix())
}

// InitSession 初始化 会话信息
func (s *ClientCollectSession) InitSession(sn string, fileName string, taskTmOutCB CollectTimeoutCallback, stopMode uint8) *ClientCollectSession {
	s.sn = sn
	s.sessionTmout = "500ms"
	s.fileName = fileName
	//
	s.finStatus.Store(COLLECT_STATUS_BEGIN)
	s.receiveCurrStatus.Store(COLLECT_STATUS_INIT)
	s.Ctx, s.CancelFunc = context.WithCancel(context.Background())
	s.workTmr = helper.NewGeneralTaskTimer(s.sessionTmout, helper.RegisterTaskProcess(s))
	s.timeoutCB = taskTmOutCB
	s.tmOutStopMode = stopMode
	return s
}

func (s *ClientCollectSession) IsBeginStatus(sn string) bool {
	if s.sn != sn {
		return false
	}
	return s.finStatus.Load() == COLLECT_STATUS_BEGIN
}

// StartSessionTask 启动会话任务
func (s *ClientCollectSession) StartSessionTask(sn string) {
	if s == nil || len(sn) == 0 || s.workTmr == nil {
		return
	}
	s.workTmr.DoTask(s.Ctx) // call process
}

func (s *ClientCollectSession) StopSession() {
	logger.Infof("stop client collection session, sn: %v, now", s.sn)
	if s.CancelFunc != nil {
		s.CancelFunc()
	}
	s.CancelFunc = nil
	s.workTmr = nil
	s.finStatus.Store(COLLECT_STATUS_INIT)
	s.receiveCurrStatus.Store(COLLECT_STATUS_INIT)
}
func (s *ClientCollectSession) CompareAndSwapCurrentStatus(status int32) bool {
	if s == nil {
		return false
	}
	curStatus := s.receiveCurrStatus.Load()
	if curStatus == status || curStatus == status-1 {
		s.receiveCurrStatus.Store(status)
		return true
	}
	logger.Errorf("cur received status: %v, receive status: %v", curStatus, status)
	return false
}

// Process 定时检测 数据
func (s *ClientCollectSession) Process() error {
	if time.Now().Unix()-s.LastCollectTime.Load() < 15 {
		return nil
	}

	logger.Errorf("has not receive collect data for 10 second, sn: %v, last receive time: %v", s.sn, s.LastCollectTime.Load())
	s.timeoutCB(s.sn) //1. stop timer. 2. delete session
	return nil
}

type CollectTimeoutCallback func(string)

// collectTaskTimeoutCB 检测定时器检测到已经开始的数据收集任务超时
func (d *DroneID) collectTaskTimeoutCB(sn string) {
	fileSz, receivedSz, fileName := sessionCollMng.GetFileParameters(sn)
	logger.Infof("filesz: %v, receivesz: %v, sn: %v", fileSz, receivedSz, sn)
	logger.Infof("collect task time out callback proc, sn: %v, send stop to dev", sn)

	mode, err := sessionCollMng.GetToDevStopMode(sn)
	if err != nil {
		logger.Errorf("get to dev stop mode fail, err: %v, sn: %v", err, sn)
	} else {
		d.closeCollect(sn, mode)
	}

	sessionCollMng.UnRegister(sn)
	d.reportCollectStatus(sn, ReportCollectStatusFail, fileName, receivedSz, fileSz, 11)
}

// collectTaskOffline 数据收集开始后，设备离线的处理
func (d *DroneID) collectTaskOffline(sn string) {
	fileSz, receivedSz, fileName := sessionCollMng.GetFileParameters(sn)
	logger.Infof("filesz: %v, receivesz: %v, sn: %v", fileSz, receivedSz, sn)
	logger.Infof("collect task on dev offline, sn: %v, send stop to dev", sn)
	mode, err := sessionCollMng.GetToDevStopMode(sn)
	if err != nil {
		logger.Errorf("get to dev stop mode fail, err: %v, sn: %v", err, sn)
	} else {
		d.closeCollect(sn, mode)
	}
	sessionCollMng.UnRegister(sn)
	d.reportCollectStatus(sn, ReportCollectStatusFail, fileName, receivedSz, fileSz, 11)
}

// openCollect 发送打开数据收集
func (d *DroneID) openCollect(sn string, fileName string, toDevOpenMode uint8) (int32, error) {
	sessionCollMng.UnRegister(sn)

	var toDevEndMode uint8 = CollectDataToDevEnd

	switch toDevOpenMode {
	case CollectDataToDevBegin:
		toDevEndMode = CollectDataToDevEnd

	case CollectDataWholeFreqToDevBegin:
		toDevEndMode = CollectDataWholeFreqToDevEnd
	}

	s := &ClientCollectSession{}
	sessionCollMng.Register(sn, fileName, d.collectTaskTimeoutCB, s.InitSession, toDevEndMode)

	logger.Info("---> Send to device openCollect: ", toDevOpenMode)
	req := &mavlink.TracerCollectRequest{
		Op: toDevOpenMode,
	}
	buff := req.Create(int32(toDevOpenMode))

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerCollectData]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerCollectData, true, 0)
		d.WaitTaskMap[mavlink.TracerCollectData] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Send Tracer setOpenCollect is :[% x]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send Tracer setOpenCollect err:[%v].Buff is [%v]", err, buff)
		sessionCollMng.UnRegister(sn)
		return 0, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send Tracer setOpenCollect err %s", err.Error())
		sessionCollMng.UnRegister(sn)
		return 0, err
	}

	// 只有等设备有响应才进行后续的动作。
	sessionCollMng.StartSession(sn)

	res := result.(*mavlink.TracerCollectResponse)

	logger.Info("-->End openCollect")
	return int32(res.Status), nil
}

// closeCollect 发送关闭收集收集
func (d *DroneID) closeCollect(sn string, mode uint8) (int32, error) {
	logger.Info("---> Send closeCollect: ", mode)

	req := &mavlink.TracerCollectRequest{
		Op: mode,
	}
	buff := req.Create(int32(mode))

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerCollectData]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerCollectData, true, 0)
		d.WaitTaskMap[mavlink.TracerCollectData] = manager
	}
	task := manager.AddTask(nil, nil)
	logger.Debugf("Send Tracer closeCollect is :[% x]", buff)

	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send Tracer closeCollect err:[%v].Buff is [%v]", err, buff)
		manager.DeleteTask(task.TaskId)
		return 0, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send Tracer closeCollect err %s", err.Error())
		return 0, err
	}
	defer func() {
		sessionCollMng.UnRegister(sn)
	}()

	res := result.(*mavlink.TracerCollectResponse)

	logger.Info("-->End closeCollect")
	return int32(res.Status), nil
}

// SendCollectData 发送数据收集请求
func (d *DroneID) SendCollectData(sn string, op int32, fileName string) (int32, error) {
	var (
		status int32 = 0
		err    error
	)

	switch op {
	case CollectDataTracerOpen:
		if len(fileName) == 0 {
			return 0, errors.New("file name is empty on open")
		}
		status, err = d.openCollect(sn, fileName, CollectDataToDevBegin)

	case CollectDataWholeFreqOpen:
		if len(fileName) == 0 {
			return 0, errors.New("file name is empty on open")
		}
		status, err = d.openCollect(sn, fileName, CollectDataWholeFreqToDevBegin)

	case CollectDataTracerEnd:
		status, err = d.closeCollect(sn, CollectDataToDevEnd)

	case CollectDataWholeFreqEnd:
		status, err = d.closeCollect(sn, CollectDataWholeFreqToDevEnd)

	default:
		return 0, errors.New("not support op")
	}
	return status, err
}

// collectPkgIndex 接收 收集数据分包号 信息
type collectPkgIndex struct {
	curPkgIndex   uint32
	maxPkgNums    uint32
	ReceivedIndex map[uint32]any // key is pkg index
	done          bool
}

// CollectTmpLocalCache 数据收集缓存全包信息
type CollectTmpLocalCache struct {
	fileContent *bigcache.BigCache
	lk          sync.Mutex
	rel         map[string]*collectPkgIndex
}

func (c *CollectTmpLocalCache) GetKey(sn string, pkgIndex uint32) string {
	key := fmt.Sprintf("%v:%v", sn, pkgIndex)
	return key

}
func (c *CollectTmpLocalCache) SetReceiveDone(sn string) {
	if c == nil {
		return
	}
	c.lk.Lock()
	defer c.lk.Unlock()
	if c.rel == nil {
		return
	}

	item, ok := c.rel[sn]
	if !ok || item == nil {
		return
	}
	item.done = true
}
func (c *CollectTmpLocalCache) IsSetReceiveDone(sn string) bool {
	if c == nil || sn == "" {
		return false
	}
	c.lk.Lock()
	defer c.lk.Unlock()
	if c.rel == nil {
		return false
	}

	item, ok := c.rel[sn]
	if !ok || item == nil {
		return false
	}
	return item.done
}
func (c *CollectTmpLocalCache) GetData(sn string, pkgIndex uint32) []byte {
	if c == nil || sn == "" {
		return nil
	}
	key := c.GetKey(sn, pkgIndex)
	ret, err := c.fileContent.Get(key)
	if err != nil {
		logger.Errorf("get pkg data fail, e: %v, pkg index: %v,sn: %v",
			err, pkgIndex, sn)
		return nil
	}
	return ret
}
func (c *CollectTmpLocalCache) SetData(sn string, pkgIndex uint32, data []byte) {
	key := c.GetKey(sn, pkgIndex)
	c.fileContent.Set(key, data)
}

// DelPkgIndexes 删除 sn 下的所有 pkg index
func (c *CollectTmpLocalCache) DelPkgIndexes(sn string) {
	if c == nil || sn == "" {
		return
	}

	c.lk.Lock()
	defer c.lk.Unlock()

	if c.rel == nil {
		return
	}
	delete(c.rel, sn)
}

func (c *CollectTmpLocalCache) DelData(sn string, pkgIndex uint32) {
	key := c.GetKey(sn, pkgIndex)
	c.fileContent.Delete(key)
}
func (c *CollectTmpLocalCache) SetPkgIndex(sn string, pkgIndex uint32, maxPkgNums uint32) {
	c.lk.Lock()
	defer c.lk.Unlock()

	if _, ok := c.rel[sn]; !ok {
		c.rel[sn] = &collectPkgIndex{}
		c.rel[sn].ReceivedIndex = make(map[uint32]any)
	}

	c.rel[sn].ReceivedIndex[pkgIndex] = true
	c.rel[sn].maxPkgNums = maxPkgNums
	c.rel[sn].curPkgIndex = pkgIndex
}
func (c *CollectTmpLocalCache) GetPkgMaxNums(sn string) uint32 {
	if c == nil || c.rel == nil || len(sn) == 0 {
		return 0
	}
	if item, ok := c.rel[sn]; ok && item != nil {
		return item.maxPkgNums
	}
	return 0
}
func (c *CollectTmpLocalCache) isCompletePackage(sn string) bool {
	c.lk.Lock()
	defer c.lk.Unlock()

	if v, ok := c.rel[sn]; !ok || v == nil {
		return false
	}
	if len(c.rel[sn].ReceivedIndex) < int(c.rel[sn].maxPkgNums) {
		return false
	}
	return true
}

var (
	tmpFileContentCollect, _ = bigcache.New(context.Background(),
		bigcache.Config{
			Shards:       128,
			LifeWindow:   30 * time.Second,
			CleanWindow:  5 * time.Second,
			StatsEnabled: false,
			Verbose:      false})

	tempFileCache = &CollectTmpLocalCache{
		fileContent: tmpFileContentCollect,
		rel:         make(map[string]*collectPkgIndex),
	}
)

// procCollectErrStatus 注销设备sn collection session, 上报错误
func (d *DroneID) procCollectErrStatus(sn string, errCode uint32) {
	if sn == "" {
		return
	}
	fileSz, receivedSz, fileName := sessionCollMng.GetFileParameters(sn)
	logger.Infof("filesz: %v, receivesz: %v, sn: %v", fileSz, receivedSz, sn)
	sessionCollMng.UnRegister(sn)
	d.reportCollectStatus(sn, ReportCollectStatusFail, fileName, receivedSz, fileSz, errCode)
}

// reportCollectStatus 上报数据收集状态
func (d *DroneID) reportCollectStatus(devSn string, status uint32, fName string, receiveFileSz uint32, totalFileSz uint32, errCode uint32) {
	if status != ReportCollectStatusFail {
		errCode = 0
	}
	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	msgProto := &client.TracerCollectDataReport{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        devSn,
			MsgType:   mavlink.FpvVideoStreamMsg,
			EquipType: int32(common.DEV_V2DRONEID),
		},

		Data: &client.TracerCollectInfo{
			Status:          status,
			FileName:        fName,
			ReceiveFileSize: receiveFileSz,
			FileTotalSize:   totalFileSz,
			ErrCode:         errCode,
		},
	}
	if err == nil {
		msgProto.Header.ParentType = int32(equipModel.ParentType)
		msgProto.Header.ParentSn = equipModel.ParentSn
		msgProto.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msgProtoBin, e := proto.Marshal(msgProto)
	if e != nil {
		logger.Errorf("marshal collection status  fail, e: %v", e)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgIDTracerCollectData,
		Data:    msgProtoBin,
	}
	out, e := proto.Marshal(report)
	if e != nil {
		logger.Errorf("marshal report data fail, e: %v", e)
		return
	}
	e = mq.FpvMsgBroker.Publish(mq.FpvTopic, broker.NewMessage(out))
	if e != nil {
		logger.Errorf("push msg on topic: %v fail", mq.FpvTopic)
		return
	}
	logger.Infof("send report, value: +%v", msgProto)
}

func (d *DroneID) HandleRealtimeFreqDataV2() {
	timeFreq := &mavlink.TracerTimeFreqData{}
	err := timeFreq.Deserialize(d.Msg)
	if err != nil {
		logger.Error("timeFreq deserialize got err: %v", err)
		return
	}
	sn := ""
	idx := bytes.IndexByte(timeFreq.SnName[:], 0)
	if idx == -1 {
		idx = len(timeFreq.SnName)
	}
	sn = string(timeFreq.SnName[:idx])
	if timeFreq.FrameIdx == 0 {
		realtimeFreqMap.Reset(sn)
	}
	realtimeFreqMap.Write(sn, timeFreq.Data)
	if timeFreq.FrameIdx == timeFreq.FrameNum-1 {
		content := realtimeFreqMap.ReadAll(sn)
		if len(content) != RealtimeFreqLen {
			return
		}
		arr := make([]int32, 0)
		for i, _ := range content {
			if i%2 == 0 {
				tmp := binary.LittleEndian.Uint16(content[i : i+2])
				arr = append(arr, int32(int16(tmp)))
			}
		}
		data := &client.TracerTimeFreqData{
			Sn:   sn,
			Data: arr,
		}
		payload, _ := proto.Marshal(data)
		report := &client.ClientReport{
			MsgType: common.ClientMsgIdTracerRealtimeFreq,
			Data:    payload,
		}
		out, err := proto.Marshal(report)
		if err != nil {
			logger.Error("TracerTimeFreqData marshal client report got error: %v", err)
			return
		}
		_ = mq.FpvMsgBroker.Publish(mq.FpvTopic, broker.NewMessage(out))
	}
}

func (d *DroneID) HandleTimeFreqData() {
	timeFreq := &mavlink.TracerTimeFreqData{}
	err := timeFreq.Deserialize(d.Msg)
	if err != nil {
		logger.Error("timeFreq deserialize got err: %v", err)
		return
	}
	sn := ""
	idx := bytes.IndexByte(timeFreq.SnName[:], 0)
	if idx == -1 {
		idx = len(timeFreq.SnName)
	}
	sn = string(timeFreq.SnName[:idx])
	if timeFreq.FrameIdx == 0 {
		timeFreqMap.Reset(sn)
	}
	//TODO: add freq field, need proto with client.
	timeFreqMap.Write(sn, timeFreq.Data)
	if timeFreq.FrameIdx == timeFreq.FrameNum-1 {
		content := timeFreqMap.ReadAll(sn)
		if len(content) != TimeFreqLen {
			return
		}
		arr := make([]int32, 0)
		for i, _ := range content {
			if i%2 == 0 {
				tmp := binary.LittleEndian.Uint16(content[i : i+2])
				arr = append(arr, int32(int16(tmp)))
			}
		}
		data := &client.TracerTimeFreqData{
			Sn:   sn,
			Data: arr,
		}
		payload, _ := proto.Marshal(data)
		report := &client.ClientReport{
			MsgType: common.ClientMsgIdTracerTimeFreq,
			Data:    payload,
		}
		out, err := proto.Marshal(report)
		if err != nil {
			logger.Error("TracerTimeFreqData marshal client report got error: %v", err)
			return
		}
		_ = mq.FpvMsgBroker.Publish(mq.FpvTopic, broker.NewMessage(out))
	}
}

var (
	curRunningStatus uint32 = DEV_COLLECT_STATUS_COLLECTING
)

// TransCollectData 转发数据收集
func (d *DroneID) TransCollectData() {
	logger.Infof("receive trans collect data")
	collectStatus := &mavlink.TraceTimeFreqCollectReport{}

	// dev sn; 25 bytes
	readBegin := mavlink.HeaderLen
	offset := mavlink.DevSNLen
	readEnd := readBegin + offset
	err := mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, &collectStatus.SN, offset)
	devSn := ByteToString(collectStatus.SN[:])
	if devSn == "" || err != nil {
		logger.Errorf("collect report dev sn is empty")
		return
	}
	d.updateStatus(devSn)

	// status; 26 bytes
	readBegin = readEnd
	offset = 1
	readEnd = readBegin + offset
	err = mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, &collectStatus.Status, offset)
	logger.Debugf("sn: %v, status: %v", devSn, collectStatus.Status)

	if !sessionCollMng.IsBegin(devSn) {
		logger.Errorf("sn: %v not been triggered by client cmd; send stop cmd to history collect data.", devSn)

		mode, err := sessionCollMng.GetToDevStopMode(devSn)
		if err != nil {
			logger.Errorf("get to dev stop mode fail, err: %v, sn: %v", err, devSn)
		} else {
			d.closeCollect(devSn, mode)
		}
		return
	}

	sessionCollMng.UpdateTime(devSn)

	if collectStatus.Status == DEV_COLLECT_STATUS_ERR {

		var paramOne uint32 = 0
		readBegin = readEnd
		offset = 4
		readEnd = readBegin + offset
		err = mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, &paramOne, offset)

		logger.Infof("receive fail status, sn: %v, err code: %v", devSn, paramOne)

		d.procCollectErrStatus(devSn, paramOne)
		return
	}

	if !sessionCollMng.CheckCurrentReceiveStatus(devSn, int32(collectStatus.Status)) {
		logger.Errorf("sn: %v, receive status: %v not fit for cur status.", devSn, collectStatus.Status)
		return
	}

	if collectStatus.Status <= DEV_COLLECT_STATUS_GZIPING {
		procStatus := ReportCollectStatusIng
		if collectStatus.Status == DEV_COLLECT_STATUS_GZIPING {
			procStatus = ReportCollectGzip
		}
		fileSz, receivedSz, fileName := sessionCollMng.GetFileParameters(devSn)
		logger.Infof("filesz: %v, receivesz: %v, sn: %v", fileSz, receivedSz, devSn)
		d.reportCollectStatus(devSn, procStatus, fileName, receivedSz, fileSz, 0)
		return
	}

	// 开始上传，上传中，上传完成， 30 bytes
	var paramOne uint32 = 0
	readBegin = readEnd
	offset = 4
	readEnd = readBegin + offset
	err = mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, &paramOne, offset)

	//文件大小
	if collectStatus.Status == DEV_COLLECT_STATUS_UPLOAD_BEGIN {
		collectStatus.ParamOne = paramOne
		logger.Debugf("sn: %v, file size: %v", devSn, paramOne)
		sessionCollMng.UpdateFileSize(devSn, paramOne) // 记录文件大小

		fileSz, receivedSz, fileName := sessionCollMng.GetFileParameters(devSn)
		logger.Infof("filesz: %v, receivesz: %v, sn: %v", fileSz, receivedSz, devSn)
		d.reportCollectStatus(devSn, ReportCollectTraning, fileName, receivedSz, fileSz, 0)
		return
	}

	if collectStatus.Status == DEV_COLLECT_STATUS_UPLOAD_ING {
		// 最大分包数
		collectStatus.ParamOne = paramOne
		logger.Debugf("sn: %v, max package nums: %v", devSn, paramOne)

		// 分包序列号
		readBegin = readEnd
		offset = 4
		readEnd = readBegin + offset
		err = mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, &collectStatus.PkgIndex, offset)
		logger.Debugf("sn: %v, pkg index: %v", devSn, collectStatus.PkgIndex)

		err, pkgIndex := sessionCollMng.GetPkgIndex(devSn)
		if err != nil {
			logger.Errorf("get cache received pkg index fail, err: %v, sn: %v", devSn)

		} else {
			if collectStatus.PkgIndex == 0 {
				_ = sessionCollMng.SetPkgIndex(devSn, int32(collectStatus.PkgIndex))

			} else if pkgIndex == int32(collectStatus.PkgIndex-1) {
				_ = sessionCollMng.SetPkgIndex(devSn, int32(collectStatus.PkgIndex))

			} else {

				logger.Errorf("sn: %v, cache received pkg index: %v, current receiving pkg index: %v, miss middle pkg", devSn, pkgIndex, collectStatus.PkgIndex)
				d.procCollectErrStatus(devSn, ReportCollectStatusFail)
				return
			}
		}

		// 发送数据长度
		readBegin = readEnd
		offset = 4
		readEnd = readBegin + offset
		err = mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, &collectStatus.DataLen, offset)
		logger.Debugf("sn: %v, pkg data len: %v", devSn, collectStatus.DataLen)
		sessionCollMng.UpdateReceiveFileSz(devSn, collectStatus.DataLen)

		// 数据内容
		readBegin = readEnd
		offset = int(collectStatus.DataLen)
		readEnd = readBegin + offset
		collectStatus.Data = make([]byte, offset)

		err = mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, collectStatus.Data, offset)
		if err != nil {
			logger.Errorf("msg decode data pkg fail,sn: %v,e: %v", devSn, err)
			return
		}

		fileSz, receivedSz, fileName := sessionCollMng.GetFileParameters(devSn)
		logger.Infof("filesz: %v, receivesz: %v, sn: %v", fileSz, receivedSz, devSn)
		d.reportCollectStatus(devSn, ReportCollectTraning, fileName, receivedSz, fileSz, 0)
		err = sessionCollMng.WriteBuffToFile(devSn, collectStatus.Data)
		if err != nil {
			logger.Errorf("write data to buf fail, sn: %v, pkgIndex: %v, maxPkgNums: %v",
				devSn, collectStatus.PkgIndex, collectStatus.ParamOne)
			return
		}

		if collectStatus.PkgIndex < collectStatus.ParamOne-1 {
			logger.Debugf("is not full pkg, sn: %v, maxPkgNums: %v, curPkgIndex: %v, cur pkg len: %v",
				devSn, collectStatus.ParamOne, collectStatus.PkgIndex, collectStatus.DataLen)
			return
		}
		logger.Infof("receive complete package, sn: %v, cur pkgIndex: %v, maxPkgNums: %v",
			devSn, collectStatus.PkgIndex, collectStatus.ParamOne)
		return
	}

	if collectStatus.Status == DEV_COLLECT_STATUS_UPLOAD_END {
		logger.Infof("receive collect done : %v, sn: %v", DEV_COLLECT_STATUS_UPLOAD_END, devSn)
		d.receiveDonePkgProc(devSn)
	}
}

func (d *DroneID) writeCollectCacheToFile(devSn string) {
	var buff []byte
	for i := uint32(0); i < tempFileCache.GetPkgMaxNums(devSn); i++ {
		cacheBuff := tempFileCache.GetData(devSn, i)
		if cacheBuff != nil {
			buff = append(buff, cacheBuff...)
		}
	}

	sessionCollMng.WriteBuffToFile(devSn, buff)
}

// deleteCollectCache 删除本地 collect 数据收集
func (d *DroneID) deleteCollectCache(devSn string) {
	logger.Infof("del collect file content cache, sn: %v", devSn)
	for i := uint32(0); i < tempFileCache.GetPkgMaxNums(devSn); i++ {
		toDelPkgIndex := i

		threading.GoSafe(func() {
			tempFileCache.DelData(devSn, toDelPkgIndex)
		})
	}

	threading.GoSafe(func() {
		tempFileCache.DelPkgIndexes(devSn)
	})
}

// receiveDonePkgProc 完整包后逻辑处理： 写文件，删除状态机
func (d *DroneID) receiveDonePkgProc(devSn string) {
	fileSz, receivedSz, fileName := sessionCollMng.GetFileParameters(devSn)
	logger.Infof("filesz: %v, receivesz: %v, sn: %v", fileSz, receivedSz, devSn)
	sessionCollMng.UnRegister(devSn)
	d.reportCollectStatus(devSn, ReportCollectStatusDone, fileName, receivedSz, fileSz, 0)
	logger.Info("--->End Receive tracer collection data")
}

// ReceiveTracerCollectResponse 设备收据收集指令响应处理
func (d *DroneID) ReceiveTracerCollectResponse() {
	res := &mavlink.TracerCollectResponse{}
	d.GetPacket(res)
	logger.Debugf("receive Send collect data response: %+v", *res)
	manager, ok := d.WaitTaskMap[mavlink.TracerCollectData]
	if ok {
		manager.CompletedTask(res, nil)
	} else {
		logger.Errorf("not find task for cmd: %x", mavlink.TracerCollectData)
	}
	return
}

// SendSetTracerNoiseFloor 发送设置tracer噪底检测
func (d *DroneID) SendSetTracerNoiseFloor(freq int32) (int, error) {
	logger.Info("---> Send Tracer Set NoiseFloor")
	req := &mavlink.TracerSetNoiseFloorRequest{}
	buff := req.Create(freq)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerSetNoiseFloor]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerSetNoiseFloor, true, 0)
		d.WaitTaskMap[mavlink.TracerSetNoiseFloor] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Send Tracer Set NoiseFloor is :[%v]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send Tracer Set NoiseFloor err:[%v].Buff is [%v]", err, buff)
		return Fail, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send Tracer Set NoiseFloor err %s", err.Error())
		return Fail, err
	}
	res := result.(*mavlink.TracerSetNoiseFloorResponse)

	logger.Info("-->End Set Tracer Set NoiseFloor")
	return int(res.Status), nil
}

func (d *DroneID) ReceiveTracerSetNoiseFloor() {
	logger.Info("-->into Receive Set NoiseFloor")
	res := &mavlink.TracerSetNoiseFloorResponse{}
	d.GetPacket(res)
	logger.Debugf("Set NoiseFloor 接收到tracer 信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.TracerSetNoiseFloor]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// SendSetTracerNoiseFloorV2 发送设置tracer噪底检测
func (d *DroneID) SendSetTracerNoiseFloorV2(request *client.TracerNoiseSet) (int, error) {
	logger.Info("---> Send Tracer Set NoiseFloor v2:req:", request.FreqList)
	list := make([]uint32, 0)
	for _, info := range request.FreqList {
		list = append(list, uint32(info))
	}
	req := &mavlink.TracerSetNoiseFloorV2Request{
		Flag:     uint8(request.Status),
		FreqNum:  uint32(len(request.FreqList)),
		FreqList: list,
		Reserve:  0,
	}
	buff := req.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerSetNoiseFloorV2]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerSetNoiseFloorV2, true, 0)
		d.WaitTaskMap[mavlink.TracerSetNoiseFloorV2] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Send Tracer Set NoiseFloor v2 is :[%v]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send Tracer Set NoiseFloor v2 err:[%v].Buff is [%v]", err, buff)
		return Fail, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send Tracer Set NoiseFloor v2 err %s", err.Error())
		return Fail, err
	}
	res := result.(*mavlink.TracerSetNoiseFloorV2Response)

	logger.Info("-->End Set Tracer Set NoiseFloor v2")
	return int(res.Status), nil
}

func (d *DroneID) ReceiveTracerSetNoiseFloorV2() {
	logger.Info("-->into Receive Set NoiseFloor v2")
	res := &mavlink.TracerSetNoiseFloorV2Response{}
	d.GetPacket(res)
	logger.Debugf("Set NoiseFloor v2 接收到tracer 信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.TracerSetNoiseFloorV2]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// SetRadioFreq 发送射频开关请求
func (d *DroneID) SetRadioFreq(mode int32) int32 {
	if mode != 0 && mode != 1 {
		logger.Errorf("set radio freq req mode not 0 && not 1")
		return 0
	}

	req := &mavlink.TracerSetRFReq{
		Flag: uint8(mode),
	}
	buff := req.Create(uint8(common.DEV_V2DRONEID))
	logger.Infof("send radio freq buf: % x", buff)

	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request droneID radio freq freq info err: %v, remote addr: %v", err, d.Conn)
		return 0 // fail
	}
	manager, ok := d.WaitTaskMap[mavlink.TracerIdSetRadioFreq]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerIdSetRadioFreq, true, 0)
		d.WaitTaskMap[mavlink.TracerIdSetRadioFreq] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request droneID SetRadio info err: %v", checkNetConnErr)
			return 0 //fail
		}
	}
	res, ok := result.(*mavlink.TracerSetRFRsp)
	if !ok {
		return 0 // fail
	}
	logger.Infof("sn: %v, mode op: %v, ret: %v, dev ret: %+v", d.Sn, mode, res.Result, res)
	return int32(res.Result)
}

// ReceiveSetRadioFreq 接收回报
func (d *DroneID) ReceiveSetRadioFreq() {
	logger.Info("--->Into Receive ReceiveSetRadioFreq")
	result := &mavlink.TracerSetRFRsp{}

	d.GetPacket(result)
	logger.Debugf("TracerSetRFRsp 获取信息：%#v", result)
	manager, ok := d.WaitTaskMap[mavlink.TracerIdSetRadioFreq]
	if ok {
		manager.CompletedTask(result, nil)
	}
	logger.Infof("process ReceiveSetRadioFreq response from device.")
	return
}

func GetTracerOnLineTracer() []string {
	droneIds := []string{}
	DevStatusMap.Range(func(key, value interface{}) bool {
		dev := value.(*Device)
		if dev != nil && dev.DevType == common.DEV_V2DRONEID && len(dev.Sn) > 0 {
			droneIds = append(droneIds, dev.Sn)
		}
		return true
	})

	logger.Infof("online tracer sn list: %+v", droneIds)
	return droneIds
}

func (d *DroneID) TransDetectToTracerGun(result *mavlink.TracerProWifiDetectResult) {
	if result == nil {
		return
	}
	var dev *Device = nil
	DevStatusMap.Range(func(key, value interface{}) bool {
		dev = value.(*Device)
		if dev.Status == common.DevOnline && dev.DevType == common.DEV_TracerGun {
			//logger.Debugf("find tracer gun device, sn: %v", dev.Sn)
			return false
		} else {
			dev = nil
			return true
		}
	})
	if dev == nil {
		return
	}

	go func() {
		var tempSN [25]uint8
		copy(tempSN[:], ByteToString(result.Info.SN[:]))

		dstData := &mavlink.TracerGunDetectFromTracerRequest{
			Info: mavlink.TraceGunProWifiDetect{
				SN:          tempSN,
				QxPower:     result.Info.QxPower,
				DxPower:     result.Info.DxPower,
				DxHorizon:   result.Info.DxHorizon,
				StartAngle:  result.Info.StartAngle,
				EndAngle:    result.Info.EndAngle,
				OrientState: result.Info.OrientState,
				UDroneNum:   result.Info.UDroneNum,
			},
		}

		for i := 0; i < int(result.Info.UDroneNum); i++ {
			var tempDroneName [25]uint8
			copy(tempDroneName[:], ByteToString(result.Description[i].DroneName[:]))

			dstData.Description = append(dstData.Description, &mavlink.TracerGunWifiDetectDesc{
				UavNumber:     result.Description[i].UavNumber,
				WifiMac:       result.Description[i].WifiMac,
				DroneName:     tempDroneName,
				DroneHorizon:  result.Description[i].DroneHorizon,
				Freq:          result.Description[i].Freq,
				DangerLevels:  result.Description[i].DangerLevels,
				Reserve1Byte:  result.Description[i].Reserve1Byte,
				Reserve4Byte1: result.Description[i].Reserve4Byte1,
				Reserve4Byte2: result.Description[i].Reserve4Byte2,
				IsSptOrient:   result.Description[i].IsSptOrient,
				AmpMean:       result.Description[i].AmpMean,
			})

		}

		tracerGun := &TracerGun{Device: dev}
		err := tracerGun.TransDetectToTracerGun(dstData)
		if err != nil {
			logger.Debugf("trans detect from tracer to tracer gun fail. err: %v", err)
		}
	}()

}

func (d *DroneID) ReceiveWifiDetectUpload() {
	logger.Infof("enter Call ReceiveWifiDetectUpload")
	result := new(mavlink.TracerProWifiDetectResult)
	if e := d.UnmarshalWifeDetect(result); e != nil {
		logger.Errorf("parse UnmarshalWifeDetect fail, e: %v", e)
		return
	}
	devSn := ByteToString(result.Info.SN[:])
	if len(devSn) <= 0 {
		logger.Errorf("wifi detect sn is nil")
		return
	}

	d.updateStatus(devSn)
	d.wifiDetectUploadReport(devSn, result)

	for _, detectInfo := range result.Description {
		if detectInfo == nil {
			continue
		}
		detectInfoItem := &mavlink.TracerSFreqDetectExpDesc{
			UavNumber:    uint32(detectInfo.UavNumber),
			IsSptOrient:  detectInfo.IsSptOrient,
			DroneHorizon: detectInfo.DroneHorizon,
		}
		TracerSOrientInstance().DoOrientLogicOnDetect(devSn, detectInfoItem)
	}

	d.TransDetectToTracerGun(result)

}
func (d *DroneID) UnmarshalWifeDetect(data *mavlink.TracerProWifiDetectResult) error {
	uavInfoLen := binary.Size(mavlink.TraceProWifiDetect{})
	buf := new(bytes.Buffer)

	if e := binary.Write(buf, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); e != nil {
		return fmt.Errorf("parse tracerProWifiDetect fail, e: %v", e)
	}
	if e := binary.Read(buf, binary.LittleEndian, &data.Info); e != nil {
		return fmt.Errorf("parse tracerProWifiDetect.Info fail, e: %v", e)
	}

	start := mavlink.HeaderLen + uavInfoLen
	end := d.MsgLen - mavlink.CrcLen

	if e := data.DeserializeFreqData(d.Msg[start:end]); e != nil {
		fmt.Errorf("deserial fail, e: %v", e)
	}
	return nil
}
func (d *DroneID) wifiDetectUploadReport(devSn string, data *mavlink.TracerProWifiDetectResult) {
	logger.Info("--->Into Receive wifi upload Report")
	var report mavlink.TracerFreqDetectReport
	report.Description = make([]*mavlink.TracerFreqDetectDescriptionReport, 0, len(data.Description))
	report.Sn = devSn
	//
	report.DxPower = float64(data.Info.DxPower)
	report.QxPower = float64(data.Info.QxPower)
	report.DxHorizon = float64(data.Info.DxHorizon) / DroneHorizonPrecision
	report.StartAngle = float64(data.Info.StartAngle) / DroneHorizonPrecision
	report.EndAngle = float64(data.Info.EndAngle) / DroneHorizonPrecision
	report.OrientStatus = data.Info.OrientState
	report.BusiDeviceType = 3

	for _, drone := range data.Description {
		tempDroneHorizon := drone.DroneHorizon

		if tempDroneHorizon > MAXDroneHorizon {
			tempDroneHorizon = Invalid
		}

		droneName := genDroneName(DroneNameGen{
			DetectType:   droneFreqType,
			DroneName:    ByteToString(drone.DroneName[:]),
			DroneUNumber: uint8(drone.UavNumber),
		})

		dist := fmt.Sprintf("%.1f", drone.Reserve4Byte1)
		distResult, _ := strconv.ParseFloat(dist, 64)
		r := &mavlink.TracerFreqDetectDescriptionReport{
			UavNumber:     uint32(drone.UavNumber),
			DroneName:     droneName,
			DroneHorizon:  float64(tempDroneHorizon) / DroneHorizonPrecision,
			UFreq:         float64(drone.Freq) / FreqPrecision,
			UDangerLevels: drone.DangerLevels,
			UMoving:       int32(drone.Reserve1Byte),
			Dist:          distResult,
			Recerve:       drone.Reserve4Byte2,
			IsSptOrient:   drone.IsSptOrient,
			WifiMac:       utils.HexByteToString(drone.WifiMac[:]),
			AmpMean:       float64(drone.AmpMean) / AmpMeanPrecision,
		}
		logger.Infof("droneID Detect wifi data: %+v", *r)
		report.Description = append(report.Description, r)
	}

	equipModel, err := GetEquipBySn(devSn)
	if equipModel == nil {
		return
	}
	name := devSn
	if equipModel.Name != "" {
		name = equipModel.Name
	}
	msg := common.EquipmentMessageBoxEntity{
		Name:      name,
		Sn:        devSn,
		MsgType:   mavlink.TracerIdGetFreqDetectRes,
		EquipType: int(common.DEV_V2DRONEID),
		Info:      report,
	}
	if err == nil {
		msg.ParentType = equipModel.ParentType
		msg.ParentSn = equipModel.ParentSn
		msg.IsIntegrated = equipModel.IsIntegrated
	}
	_ = mq.TracerDetectBroker.Publish(mq.TracerDetectTopic, broker.NewMessage(msg))
	logger.Info("--->End Receive wifi detect Report Res")
	logger.Infof("Tracer Detect wifi has reported, devSn: %v, Drone size: %v", devSn, len(report.Description))
}
func (d *DroneID) ReceiveSetOrientResponse() {
	res := &mavlink.TracerProSetOrientResponse{}
	d.GetPacket(res)
	logger.Debugf("receive Send Set Orientation wifi Mode：%+v", *res)
	manager, ok := d.WaitTaskMap[mavlink.TracerProSetOrient]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func stringToUint8Array(str string) ([25]uint8, error) {
	if len(str) > 25 {
		return [25]uint8{}, fmt.Errorf("string too long, maximum 25 characters allowed")
	}
	var arr [25]uint8
	copy(arr[:], []byte(str))
	return arr, nil
}

func (d *DroneID) ReciveEncryptDataSteam() {
	data := &mavlink.TracerEncryptDataSteam{}
	err := data.Deserialize(d.Msg)
	if err != nil {
		logger.Error("data deserialize got err: %v", err)
		return
	}

	//注意：主流程不能被阻塞
	handleObj := getHandleDecryDataProcess()
	handleObj.SendData(data)
	logger.Debugf("data = %+v", data)
	logger.Debugf("dev sn = %s", string(data.SnName[:]))
}

type DecryptDetectMsg struct {
	toDecryDataChan chan *mavlink.TracerEncryptDataSteam
	refreshTokenTmr *time.Timer //
	tokenDataChan   chan *string
	refreshDurTime  time.Duration
}

func (p *DecryptDetectMsg) SendData(data *mavlink.TracerEncryptDataSteam) {
	select {
	case p.toDecryDataChan <- data:
	default:
		logger.Infof("[consumer toDecryDataChan too slow]. send to chan is block.")
	}

}

const (
	RetTypeClose   = 0
	RetTypeToken   = 1
	RetTypeMsgOn   = 2
	RetTypeTimerOn = 3
)

type taskResInTracerDecrypt struct {
	msg   *mavlink.TracerEncryptDataSteam
	token *string

	// 0: 接收退出; 1: token 有效; 2: msg 有效; 3: 定时器触发
	retType int32
}

func (p *DecryptDetectMsg) GetData() *mavlink.TracerEncryptDataSteam {
	return <-p.toDecryDataChan
}

func (p *DecryptDetectMsg) GetTaskMsg() *taskResInTracerDecrypt {
	var retItem = &taskResInTracerDecrypt{
		retType: RetTypeClose,
	}

	select {
	case msg, ok := <-p.toDecryDataChan:
		if !ok {
			logger.Infof("receive close signal from chan *mavlink.TracerEncryptDataSteam")
			break
		}
		retItem.retType = RetTypeMsgOn
		retItem.msg = msg
		break

	case token, ok := <-p.tokenDataChan:
		if !ok {
			logger.Infof("close token gen chan.")
			break
		}

		retItem.token = token
		retItem.retType = RetTypeToken
		logger.Infof("allocate new token: %v", token)

	case <-p.refreshTokenTmr.C:
		threading.GoSafe(func() {
			token, err := GetTracerCryptToken()
			if err != nil {
				logger.Error("get token err = ", err)
			} else {

				logger.Infof("decrypt_token: %v", token)
				p.tokenDataChan <- &token
			}
		})

		p.refreshTokenTmr.Reset(p.refreshDurTime)
		logger.Infof("timer allocate token is working...")
		retItem.retType = RetTypeTimerOn
	}
	return retItem
}

// 通过调用 utils.SingletonFactory() 给 getHandleDecryDataProcess 变量进行赋值。
// 调用该函数 utils.SingletonFactory() 返回一个匿名函数， 并赋值给 getHandleDecryDataProcess，
// 通过 getHandleDecryDataProcess() 运行匿名函数并返回 *DecryptDetectMsg 对象,
// 多次调用 getHandleDecryDataProcess() 只会运行一次匿名函数，并返回第一次运行的 *DecryptDetectMsg 对象。
var getHandleDecryDataProcess = utils.SingletonFactory(func(inParams *DecryptDetectMsg) {
	inParams.toDecryDataChan = make(chan *mavlink.TracerEncryptDataSteam, 1024)
	refreshTokenSecondCfgDefault := int((8 * time.Hour) / time.Second)
	cfg := config.GetGlobalConfig().TracerUavCrypt
	if cfg != nil {
		if cfg.RefreshIntervalSecond > 0 {
			refreshTokenSecondCfgDefault = cfg.RefreshIntervalSecond
		}
	}

	inParams.refreshDurTime = time.Duration(refreshTokenSecondCfgDefault) * time.Second
	logger.Infof("token refresh interval: %+v", inParams.refreshDurTime)
	inParams.refreshTokenTmr = time.NewTimer(inParams.refreshDurTime)
	inParams.tokenDataChan = make(chan *string, 10)
	go TracerDecryptData(inParams)
})

// 1. 获取token(get url 方式)
// 2. 对data 使用token 解密(get url 方式)
// 3. 向设备 发送 0x4A 消息
func TracerDecryptData(in *DecryptDetectMsg) {
	token, err := GetTracerCryptToken()
	if err != nil {
		logger.Error("get token err = ", err)
	} else {
		logger.Infof("decrypt_token: %v", token)
	}
	//
	for {
		taskRet := in.GetTaskMsg()
		if taskRet == nil {
			logger.Infof("invalid result data.")
			break
		}
		if taskRet.retType == RetTypeClose {
			logger.Infof("receive close ")
			break
		}
		if taskRet.retType == RetTypeTimerOn {
			logger.Infof("receive timer begin working.")
			continue
		}

		if taskRet.retType == RetTypeToken {
			if taskRet.token != nil {
				logger.Infof("get new token: %v, old token: %v", *(taskRet.token), token)
				token = *(taskRet.token)
				continue
			}
			logger.Debugf("get token is empty.")
			continue
		}

		//logger.Debugf("use token: %v", token)
		RawData := taskRet.msg
		logger.Debugf("RawData = %+v", RawData)
		dataA3 := RawData.DataA3
		data80 := RawData.Data80
		var snNullIndx int
		for snNullIndx = 0; snNullIndx < 25; snNullIndx++ {
			if RawData.SnName[snNullIndx] == 0 {
				break
			}
		}
		sn := string(RawData.SnName[:snNullIndx])
		uniquID := RawData.UniqueID

		dev := FindCacheDevice(sn, common.DEV_V2DRONEID)
		if dev == nil {
			logger.Debugf("sn = ", sn)
			logger.Debug("设备未在线")
			continue
		}

		{
			if token == "" {
				token, err = GetTracerCryptToken()
				if err != nil {
					logger.Error("repeated get token err = ", err)
				}
			}
			deDataA3, err, errCode := GetTracerDecrypt(token, dataA3)

			if err != nil {
				logger.Error("err = ", err)
				d := &DroneID{Device: dev}
				req := bean.TracerDecryptSend{
					UniqueId: uniquID,
					Result:   uint32(errCode),
					JsonLen:  uint32(len(deDataA3)),
					JsonData: deDataA3,
				}
				logger.Debugf("req = %+v", req)
				_, err = d.SendTracerDecryptData(&req)
				if err != nil {
					logger.Error("---->SendTracerDecryptData err:", err)

				} else {
					logger.Debug("SendTracerDecryptData OK...")
				}
			} else {
				deDataA3Len := len(deDataA3)
				d := &DroneID{Device: dev}
				req := bean.TracerDecryptSend{
					UniqueId: uniquID,
					Result:   0,
					JsonLen:  uint32(deDataA3Len),
					JsonData: deDataA3,
				}
				logger.Debugf("req = %+v", req)
				_, err = d.SendTracerDecryptData(&req)
				if err != nil {
					logger.Error("---->SendTracerDecryptData err:", err)

				} else {
					logger.Debug("SendTracerDecryptData OK...")
				}
			}

		}

		{
			if len(data80) == 0 {
				logger.Debug("pkg not contains dataA3,do not reponse")
			} else {
				deData80, err, errCode := GetTracerDecrypt(token, data80)
				if err != nil {
					logger.Error("err = ", err)
					d := &DroneID{Device: dev}
					req := bean.TracerDecryptSend{
						UniqueId: uniquID,
						Result:   uint32(errCode),
						JsonLen:  uint32(len(deData80)),
						JsonData: deData80,
					}
					logger.Debugf("req = %+v", req)
					_, err = d.SendTracerDecryptData(&req)
					if err != nil {
						logger.Error("---->GetTracerDecrypt err:", err)

					}

				} else {
					deData80Len := len(deData80)
					d := &DroneID{Device: dev}
					req := bean.TracerDecryptSend{
						UniqueId: uniquID,
						Result:   0,
						JsonLen:  uint32(deData80Len),
						JsonData: deData80,
					}
					logger.Debugf("req = %+v", req)
					_, err = d.SendTracerDecryptData(&req)
					if err != nil {
						logger.Error("---->Send Tracer Set Alarm err:", err)

					}
				}
			}

		}

	}

}

// SendTracerDecryptData 发送tracer解密数据
func (d *DroneID) SendTracerDecryptData(msg *bean.TracerDecryptSend) (int, error) {
	logger.Info("---> SendTracerDecryptData ")
	req := &mavlink.SendTracerDecryptDataRequest{}
	buff := req.Create(msg)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerDroneIdDecrytp]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerDroneIdDecrytp, true, 0)
		d.WaitTaskMap[mavlink.TracerDroneIdDecrytp] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("SendTracerDecryptDatais :[%+v]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("SendTracerDecryptData err:[%v].Buff is [%v]", err, buff)
		return Fail, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("SendTracerDecryptData  err %s", err.Error())
		return Fail, err
	}
	res := result.(*mavlink.SendTracerDecryptDataResponse)

	logger.Info("-->End SendTracerDecryptData ", res)
	return 0, nil
}

func (d *DroneID) ReceiveDecryptDataResult() {
	res := &mavlink.SendTracerDecryptDataResponse{}
	d.GetPacket(res)
	logger.Debug("ReceiveDecryptDataResult :%+v", *res)
	manager, ok := d.WaitTaskMap[mavlink.TracerDroneIdDecrytp]
	if ok {
		manager.CompletedTask(res, nil)
	}
}

type DroneNameGen struct {
	DetectType   int32  // 1:协议解析 2：频谱侦测
	DroneName    string //无人机机型
	DroneSN      string //无人机 SN
	DroneUNumber uint8  //无人机unumber
}

const (
	droneIDType   = 1
	droneFreqType = 2
)

func genDroneName(d DroneNameGen) string {
	if d.DetectType == droneIDType {
		totalLen := len(d.DroneSN)
		if totalLen >= 4 {
			droneNameShow := fmt.Sprintf("%s#%s", d.DroneName, d.DroneSN[totalLen-4:])
			logger.Debug("droneNameShow = ", droneNameShow)
			return droneNameShow
		} else {
			logger.Error("drone sn ")
			return d.DroneName
		}
	} else if d.DetectType == droneFreqType {
		droneNameShow := fmt.Sprintf("%s#%d", d.DroneName, d.DroneUNumber)
		logger.Debug("droneNameShow = ", droneNameShow)
		return droneNameShow
	}
	logger.Error("error Drone Detect Type")
	return d.DroneName
}

func (d *DroneID) SetFreqSpectrum(req *client.FreqSpectrumSetReq) error {
	devReq := &mavlink.SetTracerFReqSpectrumReq{}
	buff := devReq.Create(req)
	if buff == nil {
		logger.Errorf("create dev request buf is nil.")
		return fmt.Errorf("dev req buf is nil")
	}
	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerFreqSpectrumSet]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerFreqSpectrumSet, true, 0)
		d.WaitTaskMap[mavlink.TracerFreqSpectrumSet] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Send SetFreqSpectrum: [% x]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send Tracer SetFreqSpectrum  err:[%v].Buff is [% v]", err, buff)
		return err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send Tracer SetFreqSpectrum err %s", err.Error())
		return err
	}
	res := result.(*mavlink.SetTracerFReqSpectrumResponse)

	logger.Info("-->End Set Tracer SetFreqSpectrum")
	if res.Status == 0 {
		return fmt.Errorf("response status fail, %v", res.Status)
	}
	return nil
}
func (d *DroneID) ReceiveFreqSpectrumSet() {
	res := &mavlink.SetTracerFReqSpectrumResponse{}
	d.GetPacket(res)
	logger.Debug("ReceiveFreqSpectrumSet :%+v", *res)
	manager, ok := d.WaitTaskMap[mavlink.TracerFreqSpectrumSet]
	if ok {
		manager.CompletedTask(res, nil)
	}
}
func (d *DroneID) GetFreqSpectrum() (*client.FreqSpectrumGetResp, error) {
	devReq := &mavlink.GetTracerFreqSpectrumReq{}
	buff := devReq.Create()
	if buff == nil {
		logger.Errorf("create dev request buf is nil.")
		return nil, fmt.Errorf("dev req buf is nil")
	}
	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerFreqSpectrumGet]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerFreqSpectrumGet, true, 0)
		d.WaitTaskMap[mavlink.TracerFreqSpectrumGet] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Send GetFreqSpectrum: [% x]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send Tracer GetFreqSpectrum  err:[%v].Buff is [% v]", err, buff)
		return nil, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send Tracer GetFreqSpectrum err %s", err.Error())
		return nil, err
	}
	res := result.(*mavlink.GetTracerFreqSpectrumResp)
	if res == nil {
		logger.Errorf("get freq spectrum response is nil")
		return nil, fmt.Errorf("spectrum response is nil")
	}

	logger.Info("-->End Set Tracer GetFreqSpectrum")

	resp := &client.FreqSpectrumGetResp{}
	for idx, param := range res.Items {
		switch idx {
		case 0:
			item := &client.DetectTarget{}
			resp.DetectTarget = item
			if param&uint32(1<<0) > 0 {
				item.DigitalWit = true
			}
			if param&uint32(1<<1) > 0 {
				item.WifiWit = true
			}
			if param&uint32(1<<2) > 0 {
				item.AnalogWit = true
			}
			if param&uint32(1<<3) > 0 {
				item.RcUplink = true
			}
			if param&uint32(1<<4) > 0 {
				item.RcDownlink = true
			}
		case 1:
			logger.Infof("param: % x ", param)
			item := &client.AnalogDetectBand{}
			resp.AnalogDetectBand = item

			if param&uint32(1<<0) > 0 {
				item.Band_09 = true
			}
			if param&uint32(1<<1) > 0 {
				item.Band_12 = true
			}
			if param&uint32(1<<2) > 0 {
				item.Band_24 = true
			}
			if param&uint32(1<<3) > 0 {
				item.Band_33 = true
			}
			if param&uint32(1<<4) > 0 {
				item.Band_49 = true
			}
			if param&uint32(1<<5) > 0 {
				item.Band_52 = true
			}
			if param&uint32(1<<6) > 0 {
				item.Band_55 = true
			}
			if param&uint32(1<<7) > 0 {
				item.Band_58Low = true
			}
			if param&uint32(1<<8) > 0 {
				item.Band_58 = true
			}
			if param&uint32(1<<9) > 0 {
				item.Band_58High = true
			}
		case 2:
			item := &client.DetectSensitivity{}
			resp.DetectSensitivity = item
			item.Level = int32(param)
		case 3:
			item := &client.CustomLib{}
			resp.CustomLib = item
			item.Code = int32(param)
		case 4:
			item := &client.PreciseStrike{}
			resp.PreciseStrike = item

		case 5:
			item := &client.DirectionalDetection{}
			resp.DirectionalDetection = item
			if param == 1 {
				item.Enable = true
			} else {
				item.Enable = false
			}
		}
	}
	return resp, nil
}

func (d *DroneID) UnmarshalGetFreqSpectrum(data *mavlink.GetTracerFreqSpectrumResp) error {
	itemNumLen := binary.Size(mavlink.GetTracerFreqSpectrumResp{}.ItemNum)
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &(data.ItemNum)); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}

	start := mavlink.HeaderLen + itemNumLen
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializeFreqParam(d.Msg[start:end]); err != nil {
		return err
	}
	return nil
}
func (d *DroneID) ReceiveGetFreqSpectrum() {
	logger.Info("--->Into Receive GetFreqSpectrum")

	result := &mavlink.GetTracerFreqSpectrumResp{}
	if err := d.UnmarshalGetFreqSpectrum(result); err != nil {
		logger.Errorf("unmarshal response fail, err: %v", err)
		return
	}

	manager, ok := d.WaitTaskMap[mavlink.TracerFreqSpectrumGet]
	if ok {
		manager.CompletedTask(result, nil)
	}
	return
}

func (d *DroneID) SetInvalidFreqRange(req *client.SetInvalidFreqRangeReq) error {
	devReq := &mavlink.SetInvalidFreqListRequest{}
	buff := devReq.Create(req.List)
	if buff == nil {
		logger.Errorf("create InvalidFreqRange buf is nil.")
		return fmt.Errorf("dev InvalidFreqRange buf is nil")
	}
	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerSetInvalidFreqList]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerSetInvalidFreqList, true, 0)
		d.WaitTaskMap[mavlink.TracerSetInvalidFreqList] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Send SetInvalidFreqRange: [% x]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send Tracer SetInvalidFreqRange  err:[%v].Buff is [% v]", err, buff)
		return err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send Tracer SetInvalidFreqRange err %s", err.Error())
		return err
	}
	res := result.(*mavlink.SetInvalidFreqListResponse)

	logger.Info("-->End Set Tracer SetInvalidFreqRange")
	if res.Status == 0 {
		return fmt.Errorf("response status fail, %v", res.Status)
	}
	return nil
}

func (d *DroneID) ReceiveSetInvalidFreqList() {
	logger.Info("--->Into Receive ReceiveSetInvalidFreqList")
	res := &mavlink.SetInvalidFreqListResponse{}
	d.GetPacket(res)
	logger.Debug("ReceiveFreqSpectrumSet :%+v", *res)
	manager, ok := d.WaitTaskMap[mavlink.TracerSetInvalidFreqList]
	if ok {
		manager.CompletedTask(res, nil)
	}
}

func (d *DroneID) GetInvalidFreqRange() (*client.GetInvalidFreqRangeRsp, error) {
	devReq := &mavlink.GetTracerFreqSpectrumReq{}
	buff := devReq.Create()
	if buff == nil {
		logger.Errorf("create dev request buf is nil.")
		return nil, fmt.Errorf("dev req buf is nil")
	}
	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerGetInvalidFreqList]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerGetInvalidFreqList, true, 0)
		d.WaitTaskMap[mavlink.TracerGetInvalidFreqList] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Send GetInvalidFreqRange: [% x]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send Tracer GetInvalidFreqRange  err:[%v].Buff is [% v]", err, buff)
		return nil, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send Tracer GetInvalidFreqRange err %s", err.Error())
		return nil, err
	}
	res := result.(*mavlink.GetInvalidFreqListResponse)
	if res == nil {
		logger.Errorf("get GetInvalidFreqRange response is nil")
		return nil, fmt.Errorf("GetInvalidFreqRange response is nil")
	}

	logger.Info("-->End Set GetInvalidFreqRange")
	retGet := &client.GetInvalidFreqRangeRsp{}
	for _, item := range res.Items {
		retGet.List = append(retGet.List, &client.FreqRange{
			StartFreq: int32(item.StartFreq),
			EndFreq:   int32(item.EndFreq),
		})
	}
	return retGet, nil
}

func (d *DroneID) ReceiveGetInvalidFreqList() {
	logger.Info("--->Into Receive ReceiveGetInvalidFreqList")
	result := &mavlink.GetInvalidFreqListResponse{}

	if err := d.UnmarshalInvalidFreqList(result); err != nil {
		logger.Errorf("unmarshal response fail, err: %v", err)
		return
	}

	manager, ok := d.WaitTaskMap[mavlink.TracerGetInvalidFreqList]
	if ok {
		manager.CompletedTask(result, nil)
	}
	return

}

func (d *DroneID) UnmarshalInvalidFreqList(data *mavlink.GetInvalidFreqListResponse) error {
	itemNumLen := binary.Size(mavlink.GetInvalidFreqListResponse{}.Num)
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &(data.Num)); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}

	start := mavlink.HeaderLen + itemNumLen
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializeInvalidFreqList(d.Msg[start:end]); err != nil {
		return err
	}
	return nil
}

func (d *DroneID) SetProtocolParseParam(data *client.SetProtocolParseParamReq) error {
	devReq := &mavlink.SetProtoParseParamRequest{}
	buff := devReq.Create(data)
	if buff == nil {
		logger.Errorf("create SetProtoParseParamRequest buf is nil.")
		return fmt.Errorf("dev SetProtoParseParamRequest buf is nil")
	}
	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerConfigProtoParseParam]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerConfigProtoParseParam, true, 0)
		d.WaitTaskMap[mavlink.TracerConfigProtoParseParam] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Send SetProtoParseParamRequest: [% x]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send Tracer SetProtoParseParamRequest  err:[%v].Buff is [% v]", err, buff)
		return err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send Tracer SetProtoParseParamRequest err %s", err.Error())
		return err
	}
	res := result.(*mavlink.SetProtoParseParamResponse)

	logger.Info("-->End Set Tracer SetProtoParseParamRequest")
	if res.Status == 0 {
		return fmt.Errorf("response status fail, %v", res.Status)
	}
	return nil
}

func (d *DroneID) ReceiveConfigProtoParseParam() {
	res := &mavlink.SetProtoParseParamResponse{}
	d.GetPacket(res)
	logger.Debug("ReceiveConfigProtoParseParam :%+v", *res)
	manager, ok := d.WaitTaskMap[mavlink.TracerConfigProtoParseParam]
	if ok {
		manager.CompletedTask(res, nil)
	}
}

func (d *DroneID) GetProtocolParseParam() (*client.GetProtocolParseParamRsp, error) {
	devReq := &mavlink.GetProtoParseParamRequest{}
	buff := devReq.Create()
	if buff == nil {
		logger.Errorf("create GetProtocolParseParam buf is nil.")
		return nil, fmt.Errorf("dev GetProtocolParseParam buf is nil")
	}
	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.TracerGetProtoParseParam]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerGetProtoParseParam, true, 0)
		d.WaitTaskMap[mavlink.TracerGetProtoParseParam] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Send GetProtoParseParamRequest: [% x]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send Tracer GetProtoParseParamRequest  err:[%v].Buff is [% v]", err, buff)
		return nil, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send Tracer GetProtoParseParamRequest err %s", err.Error())
		return nil, err
	}
	res := result.(*mavlink.GetProtoParseParamResponse)
	if res == nil {
		return nil, fmt.Errorf("get proto parse param response is nil")
	}

	logger.Info("-->End Set Tracer GetProtoParseParamRequest")
	ret := &client.GetProtocolParseParamRsp{
		ItemNum: uint32(res.ItemNum),
	}
	for i := 0; i < int(res.ItemNum); i++ {
		ret.Params = append(ret.Params, res.Params[i])
	}
	return ret, nil
}

func (d *DroneID) ReceiveGetProtoParseParam() {
	logger.Info("--->Into Receive ReceiveGetProtoParseParam")
	result := &mavlink.GetProtoParseParamResponse{}
	if err := d.UnmarshalGetParseProtoParam(result); err != nil {
		logger.Errorf("unmarshal response fail, err: %v", err)
		return
	}

	manager, ok := d.WaitTaskMap[mavlink.TracerFreqSpectrumGet]
	if ok {
		manager.CompletedTask(result, nil)
	}
	return
}

func (d *DroneID) UnmarshalGetParseProtoParam(data *mavlink.GetProtoParseParamResponse) error {
	itemNumLen := binary.Size(mavlink.GetProtoParseParamResponse{}.ItemNum)
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &(data.ItemNum)); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}

	start := mavlink.HeaderLen + itemNumLen
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializeParams(d.Msg[start:end]); err != nil {
		return err
	}
	return nil
}

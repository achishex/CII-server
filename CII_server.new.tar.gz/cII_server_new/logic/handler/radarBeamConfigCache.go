package handler

import (
	"go-micro.dev/v4/logger"

	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
)

type RadarBeamCfg struct{}

func NewRadarBeamCfg() *RadarBeamCfg {
	return &RadarBeamCfg{}
}

func (r *RadarBeamCfg) Update(radarBeamConfig *bean.RadarBeamConfig) error {
	return db.GetDB().Model(&bean.RadarBeamConfig{}).Updates(radarBeamConfig).Error
}

func (r *RadarBeamCfg) First() (*bean.RadarBeamConfig, error) {
	var radarBeamConfig bean.RadarBeamConfig
	if err := db.GetDB().Model(&bean.RadarBeamConfig{}).First(&radarBeamConfig).Error; err != nil {
		logger.Errorf("get radar beam config error: %v", err)
		return nil, err
	}
	return &radarBeamConfig, nil
}

package handler

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/entity/config"
	"adasgitlab.autel.com/tools/cuav_server/repo/utils"
	"context"
	"errors"
	"fmt"
	"strconv"
	"time"
)

func GetTracerCryptToken() (string, error) {
	config := config.GetGlobalConfig().TracerUavCrypt
	if config == nil || config.LoginUrl == "" || config.UserName == "" || config.Password == "" {
		errMsg := "lack of config msg"
		logger.Error(errMsg)
		return "", errors.New(errMsg)
	}

	response, err := utils.HttpClientGetTpl[bean.TokenResponse](context.Background(), map[string]string{
		"username": config.UserName,
		"password": config.Password,
	}, utils.WithUrl(config.LoginUrl), utils.WithTimeOut(1000*time.Millisecond))

	if err != nil {
		return "", err
	}

	// 打印并返回token
	logger.Debug("Token:", response.Data.Token)
	return response.Data.Token, nil
}

// GetTracerDecrypt code 不是 200，则直接返回 具体code, 如果是 err, 则返回 1， 其他的返回 0
func GetTracerDecrypt(token string, bytes []byte) (string, error, int) {
	var text string
	for _, b := range bytes {
		text += fmt.Sprintf("%02X", b)
	}
	logger.Debug("text = ", text)
	config := config.GetGlobalConfig().TracerUavCrypt

	if config == nil || config.DecryptUrl == "" {
		errMsg := "lack of config msg"
		logger.Error(errMsg)
		return "", errors.New(errMsg), 1
	}
	code, codeMsg, body, err := utils.HttpClientGet(context.Background(), map[string]string{
		"hex":   text,
		"token": token,
	}, utils.WithUrl(config.DecryptUrl), utils.WithTimeOut(5*time.Second))
	if err != nil {
		logger.Errorf("decrypt err: %v", err)
		return "", err, 1
	}

	if code != 200 {
		logger.Errorf("http code: %v, code msg: %v", code, codeMsg)
		return "", errors.New(strconv.Itoa(code)), code
	}
	return string(body), nil, 0
}

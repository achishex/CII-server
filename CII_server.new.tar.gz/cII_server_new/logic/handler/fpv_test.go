package handler

import (
	"testing"
)

func TestFpvDemo(t *testing.T) {

	FpvVideoFrameIndexMng.SetFramePkgIndex(1, 0, 3)
	FpvVideoFrameIndexMng.SetData(1, 0, []byte("111111"))
	t.Log(FpvVideoFrameIndexMng.IsFullPkg(1) == false)

	FpvVideoFrameIndexMng.SetFramePkgIndex(1, 1, 3)
	FpvVideoFrameIndexMng.SetData(1, 1, []byte("22222222"))
	t.Log(FpvVideoFrameIndexMng.IsFullPkg(1) == false)

	FpvVideoFrameIndexMng.SetFramePkgIndex(1, 2, 3)
	FpvVideoFrameIndexMng.SetData(1, 2, []byte("333333"))

	t.Log(FpvVideoFrameIndexMng.IsFullPkg(1) == true)

	responseBuf := []byte{}
	for i := 0; i < 3; i++ {
		bufData := FpvVideoFrameIndexMng.GetData(int32(1), int32(i))
		t.Logf("%v", string(bufData))

		responseBuf = append(responseBuf, bufData...)
		FpvVideoFrameIndexMng.DelData(int32(1), int32(i))

		FpvVideoFrameIndexMng.DelFrameIndex(int32(1))
	}
	t.Logf("%v", string(responseBuf))
}

//func TestFpvWriteFile(t *testing.T) {
//	var data string = "this is demo"
//	for i := 0; i < 3; i++ {
//		wbuf := data + strconv.Itoa(i)
//		WriteOneFrameToFile([]byte(wbuf), int32(i))
//	}
//}

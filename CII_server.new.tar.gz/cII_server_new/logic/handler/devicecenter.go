package handler

import (
	"adasgitlab.autel.com/tools/cuav_server/repo/utils/threading"
	"context"
	"errors"
	"fmt"
	"math"
	"reflect"
	"strconv"
	"strings"
	"time"

	"adasgitlab.autel.com/tools/cuav_server/rpc/connmgr"

	"adasgitlab.autel.com/tools/slink_proto/slinkv2/generatecode/golang/bizproto"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"

	"adasgitlab.autel.com/tools/cuav_server/entity/utils/helper"
	"adasgitlab.autel.com/tools/cuav_server/proto/mavlink"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
	"adasgitlab.autel.com/tools/cuav_server/rpc/codec"

	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/cache"
)

type DeviceCenter struct{}

func NewDeviceCenter() *DeviceCenter {
	return &DeviceCenter{}
}

const (
	DevOnLine    = 1
	DevOffLine   = 2
	DevAllStatus = 3
)

func (e *DeviceCenter) GetOtaLatestVersionPkg(ctx context.Context, in *client.OtaDevicePkgPullRequest, out *client.OtaDevicePkgPullResponse) error {
	out.Status = 1

	var onlineDevList []string
	DevStatusMap.Range(func(key, value interface{}) bool {
		dev := value.(*Device)
		onlineDevList = append(onlineDevList, dev.Sn)
		return true
	})

	if in.GetDeviceStatus() == DevOnLine {
		if len(onlineDevList) <= 0 {
			logger.Errorf("no online devices for request online device ota latest version.")
			return nil
		}
		return e.ProcessOnlineDeviceOta(ctx, onlineDevList, in.Area, out)

	} else if in.GetDeviceStatus() == DevOffLine {
		//TODO:
		return nil

	} else if in.GetDeviceStatus() == DevAllStatus {
		//TODO:
		return nil

	}

	return nil
}

// GetSystemInfo 雷达 获取系统信息 0xD2
func (e *DeviceCenter) GetSystemInfo(ctx context.Context, req *client.GetSystemInfoRequest, rsp *client.GetSystemInfoResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_RADAR)
	if dev == nil {
		return errors.New("设备未在线")
	}
	radar := &Radar{Device: dev}
	workMode, value, err := radar.SendGetSystemInfo(req.Sn, uint8(req.DataType))
	if err != nil {
		return err
	}
	rsp.DataType = req.DataType
	rsp.Value = value
	rsp.WorkMode = int32(workMode)
	radar.LogOperator(req, rsp, err)
	return err
}

// SetSystemStatus 雷达 设置系统状态 0xD1
func (e *DeviceCenter) SetSystemStatus(ctx context.Context, req *client.SetSystemStatusRequest, rsp *client.SetSystemStatusResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_RADAR)
	if dev == nil {
		return errors.New("设备未在线")
	}
	radar := &Radar{Device: dev}
	result, err := radar.SendSetSystemStatus(req.Sn, uint8(req.Status), uint8(req.WorkMode))
	radar.LogOperator(req, result, err)
	if err != nil {
		return err
	}
	rsp.Status = int32(result.Status)
	return nil
}

// SetSn 雷达 设置序列号 0xD4
func (e *DeviceCenter) SetSn(ctx context.Context, req *client.SetSnRequest, rsp *client.SetSnResponse) error {
	dev := FindCacheDevice(req.CurSn, common.DEV_RADAR)
	if dev == nil {
		return errors.New("设备未在线")
	}
	radar := &Radar{Device: dev}
	result, err := radar.SendSetSn(req.CurSn)
	if err != nil {
		return err
	}
	rsp.Status = int32(result.Status)
	return nil
}

// GetCryptKey 雷达 获取通讯加密密钥 0xA0
func (e *DeviceCenter) GetCryptKey(ctx context.Context, req *client.GetCryptKeyRequest, rsp *client.GetCryptKeyResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_RADAR)
	if dev == nil {
		return errors.New("设备未在线")
	}
	radar := &Radar{Device: dev}
	result, err := radar.SendGetCryptKey(req.Sn)
	if err != nil {
		return err
	}
	rsp.Status = int32(result.Status)
	rsp.CryptType = int32(result.MsgType)
	rsp.Key = result.GetSecret()
	return nil
}

// DeleteDev 删除设备
func (e *DeviceCenter) DeleteDev(ctx context.Context, req *client.DelReq, rsp *client.DelRsp) error {
	rsp.Status = 0
	err := NewEquipList().Delete(context.Background(), &client.EquipDeleteReq{
		Ids: req.Ids,
	}, &client.EquipCrudRes{})
	if err != nil {
		rsp.Status = 1
		logger.Error("Delete EquipList err: ", err)
		return errors.New("删除数据库失败")
	}
	for _, sn := range req.Sn {
		dev, devType := FindCacheDeviceAndType(sn)
		if devType == common.DEV_RADAR {
			radar := &Radar{Device: dev}
			radar.SendSetWifiDisConnNotDetect(sn)
		}
	}
	return nil
}

// SetWifiDisConn 雷达 设置wifi断开连接 0xB1
func (e *DeviceCenter) SetWifiDisConn(ctx context.Context, req *client.SetWifiDisConnRequest, rsp *client.SetWifiDisConnResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_RADAR)
	if dev == nil {
		return errors.New("设备未在线")
	}
	radar := &Radar{Device: dev}
	result, err := radar.SendSetWifiDisConn(req.Sn)
	radar.LogOperator(req, result, err)
	if err != nil {
		return err
	}
	rsp.Status = int32(result.Status)
	return nil
}

// SetUploadMode 雷达 设置上报模式 0x11
func (e *DeviceCenter) SetUploadMode(ctx context.Context, req *client.SetUploadModeRequest, rsp *client.SetUploadModeResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_RADAR)
	if dev == nil {
		return errors.New("设备未在线")
	}
	radar := &Radar{Device: dev}
	result, err := radar.SendSetUploadMode(req.Sn, uint8(req.CheckType), uint8(req.Status), uint8(req.Route), uint8(req.Cycle))
	radar.LogOperator(req, result, err)
	if err != nil {
		return err
	}
	rsp.Status = int32(result.Status)
	return nil
}

// RadarGetBeamConfig 雷达 获取波控配置信息 0x15
func (e *DeviceCenter) RadarGetBeamConfig(ctx context.Context, req *client.RadarGetBeamConfigRequest, rsp *client.RadarGetBeamConfigResponse) error {
	//模拟数据返回
	if IsSimulateMode == 1 && req.Sn == "radar0000000000" {
		rsp.TrSwitchCtrl = 1
		rsp.WorkMode = 2
		rsp.WorkWaveCode = 3
		rsp.WorkFreqCode = 4
		rsp.PrfPeriod = 5
		rsp.AccuNum = 6
		rsp.CohesionVelThre = 7
		rsp.CohesionRgnThre = 8
		rsp.ClutterMapSwitch = 9
		rsp.ClutterMapUpdateCoef = 10
		rsp.AziCalcSlope = 11
		rsp.AziCalcPhase = 12
		rsp.EleCalcSlope = 13
		rsp.EleCalcPhase = 14
		rsp.AziScanCenter = 15
		rsp.AziScanScope = 120
		rsp.EleScanCenter = 0
		rsp.EleScanScope = EleScanScope
		rsp.CoherentDetectSwitch = 19
		rsp.NoiseCoef = 20
		rsp.ClutterCoef = 21
		rsp.CfarCoef = 22
		rsp.FocusRangeMin = 23
		rsp.FocusRangeMax = 34
		rsp.ClutterCurveNum = 25
		rsp.LobeCompCoef = 26
		rsp.Sn = req.Sn
		rsp.ScanRadius = 900
		return nil
	}

	dev := FindCacheDevice(req.Sn, common.DEV_RADAR)
	if dev == nil {
		return errors.New("设备未在线")
	}
	radar := &Radar{Device: dev}
	result, err := radar.SendBeamSteerConfig(req.Sn)
	radar.LogOperator(req, result, err)
	if err != nil {
		return err
	}
	rsp.TrSwitchCtrl = int32(result.TrSwitchCtrl)
	rsp.WorkMode = int32(result.WorkMode)
	rsp.WorkWaveCode = int32(result.WorkWaveCode)
	rsp.WorkFreqCode = int32(result.WorkFreqCode)
	rsp.PrfPeriod = int32(result.PrfPeriod)
	rsp.AccuNum = int32(result.AccuNum)
	rsp.CohesionVelThre = int32(result.CohesionVelThre)
	rsp.CohesionRgnThre = int32(result.CohesionRgnThre)
	rsp.ClutterMapSwitch = int32(result.ClutterMapSwitch)
	rsp.ClutterMapUpdateCoef = int32(result.ClutterMapUpdateCoef)
	rsp.AziCalcSlope = int32(result.AziCalcSlope)
	rsp.AziCalcPhase = int32(result.AziCalcPhase)
	rsp.EleCalcSlope = int32(result.EleCalcSlope)
	rsp.EleCalcPhase = int32(result.EleCalcPhase)
	rsp.AziScanCenter = int32(result.AziScanCenter)
	rsp.AziScanScope = int32(result.AziScanScope)
	rsp.EleScanCenter = int32(result.EleScanCenter)
	rsp.EleScanScope = int32(result.EleScanScope)
	rsp.CoherentDetectSwitch = int32(result.CoherentDetectSwitch)
	rsp.NoiseCoef = int32(result.NoiseCoef)
	rsp.ClutterCoef = int32(result.ClutterCoef)
	rsp.CfarCoef = int32(result.CfarCoef)
	rsp.FocusRangeMin = int32(result.FocusRangeMin)
	rsp.FocusRangeMax = int32(result.FocusRangeMax)
	rsp.ClutterCurveNum = int32(result.ClutterCurveNum)
	rsp.LobeCompCoef = int32(result.LobeCompCoef)
	rsp.WaveFrequencyChannel = int32(result.WaveFrequencyChannel)
	rsp.Sn = req.Sn
	rsp.ScanRadius = 900
	// 获取扫描半径
	//v, _, err := cache.GetPersist().Get(context.Background(), req.Sn+"-"+"scan_radius")
	//if err != nil {
	//	logger.Debug("get scan_radius failed: ", err)
	//	return nil
	//}
	//if v != nil {
	//	rsp.ScanRadius = int32(v.(float64))
	//}
	return nil
}

func (e *DeviceCenter) RadarGetBeamAndParam(ctx context.Context, req *client.RadarGetBeamConfigRequest, rsp *client.RadarGetBeamConfigResponse) error {
	//模拟数据返回
	if IsSimulateMode == 1 && req.Sn == "radar0000000000" {
		rsp.TrSwitchCtrl = 1
		rsp.WorkMode = 2
		rsp.WorkWaveCode = 3
		rsp.WorkFreqCode = 4
		rsp.PrfPeriod = 5
		rsp.AccuNum = 6
		rsp.CohesionVelThre = 7
		rsp.CohesionRgnThre = 8
		rsp.ClutterMapSwitch = 9
		rsp.ClutterMapUpdateCoef = 10
		rsp.AziCalcSlope = 11
		rsp.AziCalcPhase = 12
		rsp.EleCalcSlope = 13
		rsp.EleCalcPhase = 14
		rsp.AziScanCenter = 15
		rsp.AziScanScope = 120
		rsp.EleScanCenter = 0
		rsp.EleScanScope = EleScanScope
		rsp.CoherentDetectSwitch = 19
		rsp.NoiseCoef = 20
		rsp.ClutterCoef = 21
		rsp.CfarCoef = 22
		rsp.FocusRangeMin = 23
		rsp.FocusRangeMax = 34
		rsp.ClutterCurveNum = 25
		rsp.LobeCompCoef = 26
		rsp.Sn = req.Sn
		rsp.ScanRadius = 900
		return nil
	}

	dev := FindCacheDevice(req.Sn, common.DEV_RADAR)
	if dev == nil {
		return errors.New("设备未在线")
	}
	radar := &Radar{Device: dev}
	// 获取雷达波束范围
	result, err := radar.SendBeamSteerConfig(req.Sn)
	radar.LogOperator(req, result, err)
	if err != nil {
		logger.Errorf("RadarGetConfig SendBeamSteerConfig err: %v", err)
		return err
	}
	// 获取雷达杂波抑制参数
	getCSResp, err := radar.SendGetClutterSuppression()
	radar.LogOperator(req, getCSResp, err)
	if err != nil {
		logger.Errorf("RadarGetConfig SendGetClutterSuppression err: %v", err)
		return err
	}
	rsp.TrSwitchCtrl = int32(result.TrSwitchCtrl)
	rsp.WorkMode = int32(result.WorkMode)
	rsp.WorkWaveCode = int32(result.WorkWaveCode)
	rsp.WorkFreqCode = int32(result.WorkFreqCode)
	rsp.PrfPeriod = int32(result.PrfPeriod)
	rsp.AccuNum = int32(result.AccuNum)
	rsp.CohesionVelThre = int32(result.CohesionVelThre)
	rsp.CohesionRgnThre = int32(result.CohesionRgnThre)
	rsp.ClutterMapSwitch = int32(result.ClutterMapSwitch)
	rsp.ClutterMapUpdateCoef = int32(result.ClutterMapUpdateCoef)
	rsp.AziCalcSlope = int32(result.AziCalcSlope)
	rsp.AziCalcPhase = int32(result.AziCalcPhase)
	rsp.EleCalcSlope = int32(result.EleCalcSlope)
	rsp.EleCalcPhase = int32(result.EleCalcPhase)
	rsp.AziScanCenter = int32(result.AziScanCenter)
	rsp.AziScanScope = int32(result.AziScanScope)
	rsp.EleScanCenter = int32(result.EleScanCenter)
	rsp.EleScanScope = int32(result.EleScanScope)
	rsp.CoherentDetectSwitch = int32(result.CoherentDetectSwitch)
	rsp.NoiseCoef = int32(result.NoiseCoef)
	rsp.ClutterCoef = int32(result.ClutterCoef)
	rsp.CfarCoef = int32(result.CfarCoef)
	rsp.FocusRangeMin = int32(result.FocusRangeMin)
	rsp.FocusRangeMax = int32(result.FocusRangeMax)
	rsp.ClutterCurveNum = int32(result.ClutterCurveNum)
	rsp.LobeCompCoef = int32(result.LobeCompCoef)
	rsp.WaveFrequencyChannel = int32(result.WaveFrequencyChannel)
	rsp.Sn = req.Sn
	rsp.ScanRadius = 900
	rsp.DetectMode = int32(getCSResp.DetectMode)
	rsp.Distance = int32(getCSResp.Distance)
	rsp.Param = int32(getCSResp.Param)
	// 获取扫描半径
	//v, _, err := cache.GetPersist().Get(context.Background(), req.Sn+"-"+"scan_radius")
	//if err != nil {
	//	logger.Debug("get scan_radius failed: ", err)
	//	return nil
	//}
	//if v != nil {
	//	rsp.ScanRadius = int32(v.(float64))
	//}
	return nil
}

// 雷达 开始探测 0xC1
func (e *DeviceCenter) RadarStartDetect(ctx context.Context, req *client.RadarStartDetectRequest, rsp *client.RadarStartDetectResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_RADAR)
	if dev == nil {
		return errors.New("设备未在线")
	}
	radar := &Radar{Device: dev}
	result, err := radar.SendStartDetect(req.Sn)
	radar.LogOperator(req, result, err)
	if err != nil {
		return err
	}
	rsp.Status = int32(result.Status)
	return nil
}

// 雷达 结束探测 0xC2
func (e *DeviceCenter) RadarEndDetect(ctx context.Context, req *client.RadarEndDetectRequest, rsp *client.RadarEndDetectResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_RADAR)
	if dev == nil {
		return errors.New("设备未在线")
	}
	radar := &Radar{Device: dev}
	result, err := radar.SendEndDetect(req.Sn, true)
	radar.LogOperator(req, result, err)
	if err != nil {
		return err
	}
	rsp.Status = int32(result.Status)
	return nil
}

// 雷达 波控范围设置 0xC4
func (e *DeviceCenter) RadarSetBeamSchedule(ctx context.Context, req *client.RadarSetBeamScheduleRequest, rsp *client.RadarSetBeamScheduleResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_RADAR)
	if dev == nil {
		return errors.New("设备未在线")
	}
	radar := &Radar{Device: dev}
	result, err := radar.SendSetBeamSize(req.Sn, req.EleScanCenter, req.EleScanScope, req.AziScanCenter, req.AziScanScope, req.WaveFrequencyChannel)
	radar.LogOperator(req, result, err)
	if err != nil {
		return err
	}
	rsp.Status = int32(result.Status)
	if result.Status == 1 {
		return nil
	}
	// 设置扫描半径
	err = cache.GetPersist().Put(context.Background(), req.Sn+"-"+"scan_radius", float64(req.ScanRadius), 0)
	if err != nil {
		logger.Debug("set scan_radius failed: ", err)
		return errors.New("set scan_radius failed")
	}
	return nil
}

// 雷达设备波束范围和杂波抑制
func (e *DeviceCenter) RadarSetBeamAndParam(ctx context.Context, req *client.RadarSetBeamAndParamRequest, rsp *client.RadarSetBeamScheduleResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_RADAR)
	if dev == nil {
		return errors.New("设备未在线")
	}
	radar := &Radar{Device: dev}
	status, err := radar.SendSetBeamAndParam(req)
	radar.LogOperator(req, status, err)
	if err != nil {
		return err
	}
	rsp.Status = int32(status)
	if status == 0 {
		rsp.Status = 2
	}
	if status == 1 {
		return nil
	}
	// 设置扫描半径
	err = cache.GetPersist().Put(context.Background(), req.Sn+"-"+"scan_radius", float64(req.ScanRadius), 0)
	if err != nil {
		logger.Debug("set scan_radius failed: ", err)
		return errors.New("set scan_radius failed")
	}
	return nil
}

func (e *DeviceCenter) GetEquipList(ctx context.Context, req *client.GetEquipListRequest, rsp *client.GetEquipListResponse) error {
	logger.Info("receive GetEquipList")
	equips := make([]*client.EquipInfo, 0)
	DevStatusMap.Range(func(key, value any) bool {
		dev := value.(*Device)
		if dev.DevType == common.DEV_RADAR {
			//启用时逻辑不经过这，缓存还没做
			enable := dev.IsEnable
			curStatus := &client.GetStatusRes{}
			err := NewEquipList().GetStatus(ctx, &client.GetStatusReq{Sn: dev.Sn}, curStatus)
			if err == nil {
				dev.IsEnable = curStatus.IsEnable
				enable = curStatus.IsEnable
			}
			equips = append(equips, &client.EquipInfo{
				Id:         0,
				Reverse:    "",
				TerminalId: "",
				Etype:      "radar",
				TcpPort:    1001,
				UdpPort:    0,
				Ip:         dev.RemoteIp,
				CrtTime:    dev.LastHeartTime.Format("2006-01-02 15:04:05"),
				//Status:     1,
				UpdateTime: dev.LastHeartTime.Format("2006-01-02 15:04:05"),
				Vendor:     "",
				Frequency:  "",
				Model:      "",
				Protocol:   "",
				Name:       dev.Name,
				Content:    "",
				IsEnable:   enable,
				IsOnline:   int32(dev.Status),
				Sn:         dev.Sn,
			})
		} else if dev.DevType == common.DEV_AEAG {
			equips = append(equips, &client.EquipInfo{
				Id:         0,
				Reverse:    "",
				TerminalId: "",
				Etype:      "RF",
				TcpPort:    1001,
				UdpPort:    0,
				Ip:         dev.RemoteIp,
				CrtTime:    dev.LastHeartTime.Format("2006-01-02 15:04:05"),
				//Status:     1,
				UpdateTime: dev.LastHeartTime.Format("2006-01-02 15:04:05"),
				Vendor:     "",
				Frequency:  "",
				Model:      "",
				Protocol:   "",
				Name:       dev.Name,
				Content:    "",
				IsEnable:   common.DeviceEnable, //枪没有禁用、启用
				IsOnline:   int32(dev.Status),
				Sn:         dev.Sn,
			})
		} else if dev.DevType == common.DEV_SCREEN {
			equips = append(equips, &client.EquipInfo{
				Id:         0,
				Reverse:    "",
				TerminalId: "",
				Etype:      "RF",
				TcpPort:    1001,
				UdpPort:    0,
				Ip:         dev.RemoteIp,
				CrtTime:    dev.LastHeartTime.Format("2006-01-02 15:04:05"),
				UpdateTime: dev.LastHeartTime.Format("2006-01-02 15:04:05"),
				Vendor:     "",
				Frequency:  "",
				Model:      "",
				Protocol:   "",
				Name:       dev.Sn,
				Content:    "",
				IsEnable:   common.DeviceEnable, //屏没有禁用、启用
				IsOnline:   int32(dev.Status),
				Sn:         dev.Sn,
			})
		} else if dev.DevType == common.DEV_TracerGun {
			equips = append(equips, &client.EquipInfo{
				Id:         0,
				Reverse:    "",
				TerminalId: "",
				Etype:      helper.DevTypeTracerGun,
				TcpPort:    1001,
				UdpPort:    0,
				Ip:         dev.RemoteIp,
				CrtTime:    dev.LastHeartTime.Format("2006-01-02 15:04:05"),
				//Status:     1,
				UpdateTime: dev.LastHeartTime.Format("2006-01-02 15:04:05"),
				Vendor:     "",
				Frequency:  "",
				Model:      "",
				Protocol:   "",
				Name:       dev.Sn,
				Content:    "",
				IsEnable:   common.DeviceEnable, //屏没有禁用、启用
				IsOnline:   int32(dev.Status),
				Sn:         dev.Sn,
			})
		}
		return true
	})
	rsp.Equips = equips
	return nil
}

// 反制枪 获取版本信息 0xAB
func (e *DeviceCenter) GunGetSoftVer(ctx context.Context, req *client.GunGetSoftVersionRequest, rsp *client.GunGetSoftVersionResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SCREEN)
	if dev == nil {
		return errors.New("设备未在线")
	}
	gun := &CounterGun{Device: dev}
	runVer, ver, bootVer, hwVer, protocolVer, err := gun.SendGetAEAGSoftVer(req.Sn)
	logger.Infof("gunLoopCheckIsInBootUpdateMod Ver: %v, %v, %v, %v, %v \n",
		runVer, ver, bootVer, hwVer, protocolVer)
	logger.Infof("GunGetSoftVer Ver: %v, %v, %v, %v, %v \n",
		runVer, ver, bootVer, hwVer, protocolVer)
	gun.LogOperator(req, rsp, err)
	if err != nil {
		return err
	}
	dbequip := &client.EquipListRes{}
	err = NewEquipList().List(context.Background(), &client.EquipListReq{}, dbequip)
	if err != nil {
		logger.Error("Get EquipList err: ", err)
	}
	for _, equip := range dbequip.Equips {
		if equip.Sn == req.Sn {
			rsp.Ip = equip.Ip
		}
	}
	rsp.Version = ver
	if rsp.Version != "" {
		err = NewEquipList().Update(context.Background(), &client.EquipCrudReq{
			Sn:         req.Sn,
			DevVersion: rsp.Version,
		}, &client.EquipCrudRes{})
		if err != nil {
			logger.Error("Update EquipList err: ", err)
		}
	}
	return nil
}

// 反制枪 设置白名单 0x22
func (e *DeviceCenter) GunSetWhiteList(ctx context.Context, req *client.GunSetWhiteListRequest, rsp *client.GunSetWhiteListResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SCREEN)
	if dev == nil {
		return errors.New("设备未在线")
	}
	gun := &CounterGun{Device: dev}
	statusRes, err := gun.SendSetWhiteList(req.Sn, req.UavName)
	gun.LogOperator(req, rsp, err)
	if err != nil {
		return err
	}
	rsp.Status = int32(statusRes.Status)
	return nil
}

// 反制枪 获取所有白名单 0x24
func (e *DeviceCenter) GunGetWhiteList(ctx context.Context, req *client.GunGetWhiteListRequest, rsp *client.GunGetWhiteListResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SCREEN)
	if dev == nil {
		return errors.New("设备未在线")
	}
	gun := &CounterGun{Device: dev}
	uavs, err := gun.SendGetWhiteList(req.Sn)
	gun.LogOperator(req, rsp, err)
	if err != nil {
		return err
	}
	rsp.Uavs = uavs
	return nil
}

// 反制枪 枪打击 0x23
func (e *DeviceCenter) GunHit(ctx context.Context, req *client.GunHitRequest, rsp *client.GunHitResponse) error {
	//改为屏打击，屏演示版本还没有sn
	dev := FindCacheDevice(req.Sn, common.DEV_SCREEN)
	if dev == nil {
		return errors.New("设备未在线")
	}
	hitDevice := &Screen{Device: dev}
	res, err := hitDevice.SendHit(req.Sn, uint8(req.Mode), uint8(req.HitFreq), uint16(req.DroneLongitude), uint16(req.DroneLatitude), uint16(req.DroneAltitude), 10)
	if err != nil {
		return err
	}
	rsp.Status = int32(res.Status)
	return nil
}

func (e *DeviceCenter) SendGunHitData(ctx context.Context, req *client.SendGunHitDataRequest, rsp *client.SendGunHitDataResponse) error {
	//改为屏打击，屏演示版本还没有sn
	dev := FindCacheDevice(req.Sn, common.DEV_SCREEN)
	if dev == nil {
		return errors.New("设备未在线")
	}
	hitDevice := &Screen{Device: dev}
	res, err := hitDevice.SendUavData(req)
	if err != nil {
		return err
	}
	rsp.Status = int32(res.Status)
	return nil
}

func (e *DeviceCenter) SendGunHitResult(ctx context.Context, req *client.SendGunHitResultRequest, rsp *client.SendGunHitResultResponse) error {
	//改为屏打击，屏演示版本还没有sn
	dev := FindCacheDevice(req.Sn, common.DEV_SCREEN)
	if dev == nil {
		return errors.New("设备未在线")
	}
	//hitDevice := &Screen{Device: dev}
	//res, err := hitDevice.SendUavData(req.Sn, uint8(0), uint8(0), uint16(0), uint16(0), uint16(0), 10)
	//if err != nil {
	//	return err
	//}
	//rsp.Status = int32(res.Status)
	return nil
}

func (e *DeviceCenter) AddSimulateDevice(ctx context.Context, req *client.AddSimulateDeviceRequest, rsp *client.AddSimulateDeviceResponse) error {
	AddSimulateDevice(req.Status, req.MsgType)
	rsp.Status = 1
	return nil
}

func (e *DeviceCenter) PostureCalibration(ctx context.Context, req *client.PostureCalibrationRequest, rsp *client.PostureCalibrationResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_RADAR)
	if dev == nil {
		return errors.New("设备未在线")
	}
	radar := &Radar{Device: dev}
	result, err := radar.PostureCalibration()
	if err != nil {
		return err
	}
	rsp.Status = int32(result.Status)
	return nil
}

func (e *DeviceCenter) PostureCalibrationManual(ctx context.Context, req *client.PostureCalibrationManualRequest, rsp *client.PostureCalibrationManualResponse) error {
	logger.Infof("PostureCalibrationManual req: %+v", req)
	dev := FindCacheDevice(req.Sn, common.DEV_RADAR)
	if dev == nil {
		return errors.New("设备未在线")
	}
	radar := &Radar{Device: dev}

	//雷达v1 heading 转换
	h := req.UHeading
	heading := RotateSizeTransfer(&h)
	logger.Infof("heading convert before: %v, after: %v", req.UHeading, heading)

	result, err := radar.PostureCalibrationManual(&mavlink.PostureCalibrationManualRequest{
		ULongitude: int32(req.ULongitude * RadarPostureReduce20),
		ULatitude:  int32(req.ULatitude * RadarPostureReduce20),
		UAltitude:  int32(req.UAltitude * RadarPostureReduce),
		UHeading:   int32((*heading) * RadarPostureReduce),
		UPitching:  int32(req.UPitching * RadarPostureReduce),
		URolling:   int32(req.URolling * RadarPostureReduce),
	})
	if err != nil {
		return err
	}
	rsp.Status = int32(result.Status)
	return nil
}

func (e *DeviceCenter) RadarGetVersionInfo(ctx context.Context, req *client.RadarGetVersionInfoRequest, rsp *client.RadarGetVersionInfoResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_RADAR)
	if dev == nil {
		return errors.New("设备未在线")
	}
	radar := &Radar{Device: dev}
	runVer, appVer, bootVer, hwVer, protoVer, err := radar.SendGetVersionInfo(req.Sn)
	if err != nil {
		return err
	}
	rsp.Sn = req.Sn
	rsp.RunVersion = int64(runVer)
	rsp.AppVersion = appVer
	rsp.BootVersion = bootVer
	rsp.HwVersion = hwVer
	rsp.ProtocolVersion = protoVer
	return nil
}

func (e *DeviceCenter) DroneIDGetVersionInfo(ctx context.Context, req *client.DroneIDGetVersionInfoRequest, rsp *client.DroneIDGetVersionInfoResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_V2DRONEID)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &DroneID{Device: dev}
	rsp, err := d.SendGetVersionInfo(req.Sn)
	if err != nil {
		return err
	}
	return nil
}

// TracerGetVersionInfo 获取Tracer版本信息
func (e *DeviceCenter) TracerGetVersionInfo(ctx context.Context, req *client.TracerGetVersionInfoRequest, rsp *client.TracerGetVersionInfoResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_V2DRONEID)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &DroneID{Device: dev}
	runVer, appVer, bootVer, hwVer, protoVer, err := d.TracerGetVersionInfo(req.Sn)
	if err != nil {
		return err
	}
	rsp.Sn = req.Sn
	rsp.RunVersion = int64(runVer)
	rsp.AppVersion = appVer
	rsp.BootVersion = bootVer
	rsp.HwVersion = hwVer
	rsp.ProtocolVersion = protoVer
	return nil
}

// TracerGetInfo 获取Tracer设备信息
func (e *DeviceCenter) TracerGetInfo(ctx context.Context, req *client.TracerGetInfoRequest, rsp *client.TracerGetInfoResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_V2DRONEID)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &DroneID{Device: dev}
	_, appVer, _, _, _, err := d.TracerGetVersionInfo(req.Sn)
	if err != nil {
		return err
	}
	rsp.Ip = dev.RemoteIp
	rsp.AppVersion = appVer
	return nil
}

// TracerGetWorkMode 获取tracer工作模式
func (e *DeviceCenter) TracerGetWorkMode(ctx context.Context, req *client.TracerGetWorkModeRequest, rsp *client.TracerGetWorkModeResponse) error {
	logger.Info("---->Into Get Trace Work Mode,sn:", req.Sn)

	dev := FindCacheDevice(req.Sn, common.DEV_V2DRONEID)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &DroneID{Device: dev}
	result, err := d.SendGetWorkMode()
	if err != nil {
		logger.Info("---->End Get Trace Work Mode")
		return err
	}
	rsp.Status = result
	logger.Info("---->End Get Trace Work Mode")
	return nil
}

// TracerSetOrientationMode 设置tracer定向模式
func (e *DeviceCenter) TracerSetOrientationMode(ctx context.Context, req *client.TracerSetOrientationModeRequest, rsp *client.TracerSetOrientationModeResponse) error {
	logger.Infof("---->Into Set Orientation Mode,req: %v", req)
	dev := FindCacheDevice(req.Sn, common.DEV_V2DRONEID)
	if dev == nil {
		return errors.New("设备未在线")
	}
	d := &DroneID{Device: dev}

	if req.BusinessDeviceType == 3 {
		result, err := d.SendSetOrientationModeOnWifi(uint8(req.Status),
			uint16(req.UavNumber), req.WifiMac, uint32(req.UFreq))
		if err != nil {
			logger.Infof("send set orientation mode on wifi fail, e: %v", err)
			return err
		}
		rsp.Status = result
		logger.Info("---->End Set Orientation wifi Mode")
		return nil
	}

	result, err := d.SendSetOrientationMode(uint8(req.Status), uint8(req.UavNumber), req.DroneName, uint32(req.UFreq))
	if err != nil {
		logger.Info("---->End Set Orientation Mode")
		return err
	}
	rsp.Status = result
	logger.Info("---->End Set Orientation Mode")
	return nil
}

func (e *DeviceCenter) GunSetStatus(ctx context.Context, req *client.GunSetStatusRequest, rsp *client.GunSetStatusResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SCREEN)
	if dev == nil {
		return errors.New("设备未在线")
	}
	gun := &Screen{Device: dev}
	statusRes, err := gun.SendCloseConn(req.Sn)
	if err != nil {
		return err
	}
	rsp.Status = int32(statusRes.Status)
	return nil
}

func (e *DeviceCenter) SetDeviceStatus(ctx context.Context, req *client.SetDeviceStatusRequest, rsp *client.SetDeviceStatusResponse) error {
	dev := FindCacheDevice(req.Sn, common.DeviceType(req.DeviceType))
	if dev == nil {
		logger.Info("device has offline")
		return nil
	}

	if req.Status == common.DeviceDisenable {
		dev.Close()
		dev.IsEnable = common.DeviceDisenable
	} else if req.Status == common.DeviceEnable {
		dev.IsEnable = common.DeviceEnable
	} else {
		return fmt.Errorf("set status %v err", req.Status)
	}

	rsp.Status = 1
	return nil
}

func (e *DeviceCenter) StartUdpBroadCast(ctx context.Context, req *client.StartUdpBroadCastRequest, rsp *client.StartUdpBroadCastResponse) error {
	if err := StartUdpBroadCast(req.Id); err != nil {
		return err
	}
	rsp.Status = 1
	return nil
}

func (e *DeviceCenter) StopUdpBroadCast(ctx context.Context, req *client.StopUdpBroadCastRequest, rsp *client.StopUdpBroadCastResponse) error {
	if err := StopUdpBroadCast(req.Id); err != nil {
		return err
	}
	rsp.Status = 1
	return nil
}

func (e *DeviceCenter) ConfirmDeviceConn(ctx context.Context, req *client.ConfirmDeviceConnRequest, rsp *client.ConfirmDeviceConnResponse) error {
	if err := ConfirmDeviceConn(req.SnList); err != nil {
		return err
	}
	rsp.Status = 1
	return nil
}

// StartSelfCheck 导航诱骗  开始自检
func (e *DeviceCenter) StartSelfCheck(ctx context.Context, req *client.SelfCheckRequest, rsp *client.SelfCheckResponse) error {

	if req.Sn == "" {
		rsp.ErrCode = 2
		logger.Debug("nsf sn is nil")
		return errors.New("sn is nil")
	}

	devP := FindCacheDeviceNSF(req.Sn, common.DEV_NSF4000)

	if devP == nil {
		rsp.ErrCode = 2
		logger.Debug("nsf not online")
		return errors.New("设备未在线")
	}
	dev, ok := devP.(*ControllerNSF4000)
	if ok {
		res := dev.SelfCheckCom(req)
		rsp.ErrCode = int32(res)
		logger.Debug("res = ", res)
	} else {
		logger.Debug("unknow dev type")
		rsp.ErrCode = 2
		return errors.New("设备不支持自检")
	}

	return nil
}

// StartInduce 导航诱骗  开始工作模式
func (e *DeviceCenter) StartInduce(ctx context.Context, req *client.InduceRequest, rsp *client.InduceResponse) error {
	rsp.Status = 1
	logger.Info("------->Into Start Induce:", req)
	if req.Sn == "" {
		rsp.Status = 2
		logger.Debug("nsf sn is nil")
		return errors.New("sn is nil")
	}

	devP := FindCacheDeviceNSF(req.Sn, common.DEV_NSF4000)

	if devP == nil {
		rsp.Status = 2
		logger.Debug("nsf not online")
		return errors.New("设备未在线")
	}
	var res int

	dev, ok := devP.(*ControllerNSF4000)
	if ok {
		res = dev.SetPlay(req)
	} else if dev2, ok := devP.(*ControllerNSFGXW); ok {
		logger.Debug("NSFGXW dev type")
		res = dev2.SetPlay(req)

	} else {
		logger.Debug("unknow dev type")
		return errors.New("未识别的设备类型")
	}

	if res == -1 {
		rsp.Status = 2
	}
	enableStartTime := time.Now().UnixMilli()
	logger.Debug("enableStartTime = ", enableStartTime)
	logger.Debug("req.Enable = ", req.Enable)

	nsf := common.Nsf4000MapInfo{}
	if rsp.Status == 1 {
		nsf.Sn = req.Sn
		if req.WorkMode != 0 {
			nsf.Enable = req.Enable
			nsf.WorkMode = req.WorkMode
			nsf.Radius = req.Radius
		} else {
			nsf.Radius = req.Radius
		}
		nsf.Angle = req.Angle
		nsf.EnableStartTime = enableStartTime
		Nsf4000Statue.Set(req.Sn, nsf)
	}
	logger.Debug("nsf=%v", nsf)
	logger.Info("------->End Start Induce rsp:", rsp.Status)
	return nil
}

// GetInduceVer 导航诱骗  获取版本号
func (e *DeviceCenter) GetInduceVer(ctx context.Context, req *client.GetInduceVerRequest, rsp *client.GetInduceVerResponse) error {
	rsp.Status = 1
	logger.Info("------->Into Get Induce Ver:", req.Sn)
	devP := FindCacheDeviceNSF(req.Sn, common.DEV_NSF4000)
	if devP == nil {
		rsp.Status = 2
		return errors.New("设备未在线")
	}

	dev, ok := devP.(*ControllerNSF4000)
	if ok {
		rsp.Status = 1
		rsp.Sn = dev.Sn
		rsp.Ip = dev.NFSIP
		rsp.Version = dev.Version
	} else if dev2, ok := devP.(*ControllerNSFGXW); ok {
		//TODO SNFGXW
		logger.Debug("dev2 = ", dev2)
		logger.Debug("ip = ", dev2.NFSIP)
		rsp.Status = 1
		rsp.Sn = dev2.Sn
		rsp.Ip = dev2.NFSIP
		rsp.Version = dev2.Version
		logger.Debug("NSFGXW dev type,rsp =", rsp)
	} else {
		logger.Debug("unknow dev type")
		return errors.New("未识别的设备类型")
	}

	logger.Info("------->End Get Induce Ver:", rsp.Ip, rsp.Version)
	return nil
}

// EnableInduce 导航诱骗  启用禁用
func (e *DeviceCenter) EnableInduce(ctx context.Context, req *client.EnableInduceRequest, rsp *client.EnableInduceResponse) error {
	logger.Info("Enable Induce is :", req.Enable)
	rsp.Status = 1

	devP := FindCacheDeviceNSF(req.Sn, common.DEV_NSF4000)
	//禁用时关闭工作模式
	if req.Enable == 2 && devP != nil { //禁用时发关闭工作，并上报前端
		// dev.SetClose()

		dev, ok := devP.(*ControllerNSF4000)
		if ok {
			dev.SetClose()
		} else if _, ok := devP.(*ControllerNSFGXW); ok {
			//TODO SNFGXW
			logger.Debug("NSFGXW dev type")

		} else {
			logger.Debug("unknow dev type")
			return errors.New("未识别的设备类型")
		}

	}
	err := NewEquipList().SetEnableState(context.Background(), &client.SetEnableReq{Sn: req.Sn, Status: req.Enable, EType: "Spoofer"}, &client.SetEnableRes{})
	if err != nil {
		logger.Error("Enable Induce err:", err)
		rsp.Status = 2
		return err
	}

	rsp.Status = 1
	return nil
}

// GetInduceConfig 获取导航诱导参数
func (e *DeviceCenter) GetInduceConfig(ctx context.Context, req *client.GetInduceConfigRequest, rsp *client.GetInduceConfigResponse) error {
	logger.Info("Get Induce Config Sn is :", req.Sn)

	dev := FindCacheDeviceNSF(req.Sn, common.DEV_NSF4000)
	if dev == nil {
		return errors.New("设备未在线")
	}
	listInfo := &client.Nsf4000ListRsp{}
	err := NewNsf4000().List(context.Background(), &client.Nsf4000ListReq{}, listInfo)
	if err != nil {
		logger.Error("Get Induce config err:", err)
		return err
	}
	rsp.Radius = 200
	rsp.Power = 0
	rsp.DefenseLevelSpeed = 20
	rsp.DefenseVerticalSpeed = 0
	rsp.Longitude = 113.81022061
	rsp.Latitude = 22.63407730
	rsp.Height = 50
	rsp.DriveLevelSpeed = 5
	rsp.DriveVerticalSpeed = 5
	for _, info := range listInfo.ConfigList {
		if info.Sn == req.Sn {
			rsp.Radius = info.Radius
			rsp.Power = info.Power
			rsp.DefenseLevelSpeed = info.DefenseLevelSpeed
			rsp.DefenseVerticalSpeed = info.DefenseVerticalSpeed
			rsp.Longitude = info.Longitude
			rsp.Latitude = info.Latitude
			rsp.Height = info.Height
			rsp.DriveLevelSpeed = info.DriveLevelSpeed
			rsp.DriveVerticalSpeed = info.DriveVerticalSpeed
			rsp.DefenseLongitude = info.DefenseLongitude
			rsp.DefenseLatitude = info.DefenseLatitude
			rsp.AreaStopLongitude = info.AreaStopLongitude
			rsp.AreaStopLatitude = info.AreaStopLatitude
			rsp.X = info.X
			rsp.Y = info.Y
		}
	}
	logger.Info("Get Induce Config is :", rsp)
	return nil
}

// DeleteInduceConfig 删除诱导设备的本地配置
func (e *DeviceCenter) DeleteInduceConfig(_ context.Context, sn string) error {
	if len(sn) <= 0 {
		return errors.New("sn is empty")
	}
	err := NewNsf4000().Delete(context.Background(), sn)
	if err != nil {
		logger.Error("Get Induce config err:", err)
		return err
	}
	return nil
}

// SetInduceConfig 设置导航诱导参数
func (e *DeviceCenter) SetInduceConfig(ctx context.Context, req *client.SetInduceConfigRequest, rsp *client.SetInduceConfigResponse) error {
	logger.Infof("Set Induce Config Sn is:%v", req)
	rsp.Status = 1
	dev := FindCacheDeviceNSF(req.Sn, common.DEV_NSF4000)
	if dev == nil {
		rsp.Status = 2
		return errors.New("设备未在线")
	}
	err := NewNsf4000().InsertAndUpdate(context.Background(), &client.Nsf4000InsertAndUpdateReq{
		Sn:                   req.Sn,
		Radius:               req.Radius,
		Power:                req.Power,
		DefenseLevelSpeed:    req.DefenseLevelSpeed,
		DefenseVerticalSpeed: req.DefenseVerticalSpeed,
		Longitude:            req.Longitude,
		Latitude:             req.Latitude,
		Height:               req.Height,
		DriveLevelSpeed:      req.DriveLevelSpeed,
		DriveVerticalSpeed:   req.DriveVerticalSpeed,
		DefenseLongitude:     req.DefenseLongitude,
		DefenseLatitude:      req.DefenseLatitude,
		AreaStopLongitude:    req.AreaStopLongitude,
		AreaStopLatitude:     req.AreaStopLatitude,
		X:                    req.X,
		Y:                    req.Y,
	}, &client.Nsf4000InsertAndUpdateRsp{})
	if err != nil {
		rsp.Status = 2
		logger.Error("Insert Induce config err:", err)
		return nil
	}

	logger.Info("Set Induce Config is :", rsp)
	return nil
}

// GetB3L1InduceConfig 获取导航诱导B3L1参数
func (e *DeviceCenter) GetB3L1InduceConfig(ctx context.Context, req *client.GetInduceB3L1ConfigRequest, rsp *client.GetInduceB3L1ConfigResponse) error {
	logger.Info("Get Induce B3L1 Config Sn is :", req.Sn)

	dev := FindCacheDeviceNSF(req.Sn, common.DEV_NSF4000)
	if dev == nil {
		return errors.New("设备未在线")
	}
	listInfo := &client.Nsf4000B3L1ListRsp{}
	err := NewNsf4000().ListB3L1(context.Background(), &client.Nsf4000B3L1ListReq{}, listInfo)
	if err != nil {
		logger.Error("Get Induce B3L1 config err:", err)
		return err
	}
	rsp.PosTemp = 1
	for _, info := range listInfo.ConfigB3L1List {
		if info.Sn == req.Sn {
			rsp.PosTemp = info.PosTemp
		}
	}
	logger.Info("Get Induce B3L1 Config is :", rsp)
	PosTemp = GetNsf4000PosTemp(req.Sn)
	return nil
}

// SetInduceConfig 设置导航诱导参数
func (e *DeviceCenter) SetB3L1InduceConfig(ctx context.Context, req *client.SetInduceB3L1ConfigRequest, rsp *client.SetInduceB3L1ConfigResponse) error {
	logger.Infof("Set Induce B3L1 Config Sn is:%v", req)
	rsp.Status = 1
	dev := FindCacheDeviceNSF(req.Sn, common.DEV_NSF4000)
	if dev == nil {
		rsp.Status = 2
		return errors.New("设备未在线")
	}
	devHandler, ok := dev.(*ControllerNSF4000)
	if ok {
		// devHandler.SetPlay(req)
		if req.PosTemp == 1 {
			B3Cmd1 := "$SET,PpsSynSrc,1" + "\r\n"
			B3Cmd2 := "$SET,SynUppsMode,3" + "\r\n"
			devHandler.SendMsg([]byte(B3Cmd1))
			devHandler.SendMsg([]byte(B3Cmd2))
			logger.Info("Send L1 or B3 mode to NSF4000 B3Cmd1: ", B3Cmd1)
			logger.Info("Send L1 or B3 mode to NSF4000 B3Cmd1: ", B3Cmd2)
		} else if req.PosTemp == 2 {
			L1Cmd1 := "$SET,PpsSynSrc,0" + "\r\n"
			L1Cmd2 := "$SET,SynUppsMode,0" + "\r\n"
			devHandler.SendMsg([]byte(L1Cmd1))
			devHandler.SendMsg([]byte(L1Cmd2))
			logger.Info("Send L1 or B3 mode to NSF4000 L1Cmd1: ", L1Cmd1)
			logger.Info("Send L1 or B3 mode to NSF4000 L1Cmd2: ", L1Cmd2)
		}

	} else {
		rsp.Status = 2
		return errors.New("设备未在线")

	}

	err := NewNsf4000().InsertAndUpdateB3L1(context.Background(), &client.Nsf4000InsertAndUpdateB3L1Req{
		Sn:      req.Sn,
		PosTemp: req.PosTemp,
	}, &client.Nsf4000InsertAndUpdateB3L1Rsp{})
	if err != nil {
		rsp.Status = 2
		logger.Error("Insert B3L1 Induce config err:", err)
		return nil
	}

	logger.Info("Set B3L1 Induce Config is :", rsp)
	PosTemp = GetNsf4000PosTemp(req.Sn)
	devHandler.PosUploadTime = 0
	return nil
}

// TracerCli 给tracer下发指令
func (e *DeviceCenter) TracerCli(ctx context.Context, req *client.TracerCliRequest, rsp *client.TracerCliResponse) error {
	logger.Info("---->Into Set Tracer Cli ,sn:", req.Sn, req.Cmd)
	dev := FindCacheDevice(req.Sn, common.DEV_V2DRONEID)
	if dev == nil {
		return errors.New("设备未在线")
	}
	if dev.WaitTaskMap == nil {
		return errors.New("send err")
	}
	d := &DroneID{Device: dev}
	result, err := d.SendTracerCli(req.Cmd)
	if err != nil {
		logger.Info("---->Send Tracer Cli err:", err)
		return err
	}
	logger.Info("---->result:", string(result))
	rsp.Result = string(result)
	logger.Info("---->End Tracer Cli")

	return nil
}

// TracerSetHideMode 给tracer下发设置隐蔽模式
func (e *DeviceCenter) TracerSetHideMode(ctx context.Context, req *client.TracerSetHideModeRequest, rsp *client.TracerSetHideModeResponse) error {
	logger.Info("---->Into Set Tracer Set Hide Mode ,sn:", req.Sn, req.HideMode)
	dev := FindCacheDevice(req.Sn, common.DEV_V2DRONEID)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &DroneID{Device: dev}
	status, err := d.SendTracerSetHideMode(int(req.HideMode))
	if err != nil {
		logger.Info("---->Send Tracer Set HideMode err:", err)
		return err
	}
	rsp.Status = int32(status)
	if status == 0 {
		rsp.Status = 2
	}
	logger.Info("---->End Tracer Set HideMode,rsp:", rsp)

	return nil
}

// TracerSetAlarm 给tracer下发设置告警设置
func (e *DeviceCenter) TracerSetAlarm(ctx context.Context, req *client.TracerSetAlarmRequest, rsp *client.TracerSetAlarmResponse) error {
	logger.Info("---->Into Set Tracer Set Alarm ,sn:", req.Sn, req.Alarm)
	dev := FindCacheDevice(req.Sn, common.DEV_V2DRONEID)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &DroneID{Device: dev}
	status, err := d.SendTracerSetAlarm(int(req.Alarm))
	if err != nil {
		logger.Info("---->Send Tracer Set Alarm err:", err)
		return err
	}
	rsp.Status = int32(status)
	if status == 0 {
		rsp.Status = 2
	}
	logger.Info("---->End Tracer Set Alarm,rsp:", rsp)
	return nil
}

// FpvSendSetHitMode Fpv发送设置打击模式
func (e *DeviceCenter) FpvSendSetHitMode(ctx context.Context, req *client.FpvSendSetHitModeRequest, rsp *client.FpvSendSetHitModeResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_FPV)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Fpv{Device: dev}
	status, err := d.FpvSendSetHitMode(req)
	if err != nil {
		return err
	}
	rsp.Status = status
	if status == 0 {
		rsp.Status = 2
	}
	return nil
}

// FpvSendGetVersion Fpv发送获取版本信息
func (e *DeviceCenter) FpvSendGetVersion(ctx context.Context, req *client.FpvSendGetVersionRequest, rsp *client.FpvSendGetVersionResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_FPV)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Fpv{Device: dev}
	rsp, err := d.FpvSendGetVersion(req.Sn)
	if err != nil {
		return err
	}
	return nil
}

// FpvSendGetHitMode Fpv发送获取打击模式
func (e *DeviceCenter) FpvSendGetHitMode(ctx context.Context, req *client.FpvSendGetHitModeRequest, rsp *client.FpvSendGetHitModeResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_FPV)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Fpv{Device: dev}
	status, err := d.FpvSendGetHitMode()
	if err != nil {
		return err
	}
	rsp.Status = status
	if status == 0 {
		rsp.Status = 2
	}
	return nil
}

// FpvSendHitUav Fpv发送全面打击
func (e *DeviceCenter) FpvSendHitUav(ctx context.Context, req *client.FpvSendHitRequest, rsp *client.FpvSendHitResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_FPV)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Fpv{Device: dev}
	status, err := d.FpvSendHit()
	if err != nil {
		return err
	}
	rsp.Status = status
	if status == 0 {
		rsp.Status = 2
	}
	return nil
}

// FpvSendStopHit Fpv发送停止打击
func (e *DeviceCenter) FpvSendStopHit(ctx context.Context, req *client.FpvSendStopHitRequest, rsp *client.FpvSendStopHitResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_FPV)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Fpv{Device: dev}
	status, err := d.FpvSendStopHit()
	if err != nil {
		return err
	}
	rsp.Status = status
	if status == 0 {
		rsp.Status = 2
	}
	return nil
}

// FpvSendSetHitTime Fpv发送设置打击时间
func (e *DeviceCenter) FpvSendSetHitTime(ctx context.Context, req *client.FpvSendSetHitTimeRequest, rsp *client.FpvSendSetHitTimeResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_FPV)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Fpv{Device: dev}
	status, err := d.FpvSendSetHitTime(req)
	if err != nil {
		return err
	}
	rsp.Status = status
	if status == 0 {
		rsp.Status = 2
	}
	return nil
}

// FpvSendGetHitTime Fpv发送获取打击时间
func (e *DeviceCenter) FpvSendGetHitTime(ctx context.Context, req *client.FpvSendGetHitTimeRequest, rsp *client.FpvSendGetHitTimeResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_FPV)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Fpv{Device: dev}
	time, err := d.FpvSendGetHitTime()
	if err != nil {
		return err
	}
	rsp.HitTime = time
	return nil
}

// FpvCli 给Fpv下发指令
func (e *DeviceCenter) FpvCli(ctx context.Context, req *client.FpvCliRequest, rsp *client.FpvCliResponse) error {
	logger.Info("---->Into Set Fpv Cli ,sn:", req.Sn, req.Cmd)
	dev := FindCacheDevice(req.Sn, common.DEV_FPV)
	if dev == nil {
		return errors.New("设备未在线")
	}
	d := &Fpv{Device: dev}
	result, err := d.SendFpvCli(req.Cmd)
	if err != nil {
		logger.Info("---->Send Fpv Cli err:", err)
		return err
	}
	logger.Info("---->result:", string(result))
	rsp.Result = string(result)
	logger.Info("---->End Fpv Cli")

	return nil
}

// SflGetVersionInfo Sfl获取版本信息
func (e *DeviceCenter) SflGetVersionInfo(ctx context.Context, req *client.SflGetVersionRequest, rsp *client.SflGetVersionResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Sfl{Device: dev}
	version, err := d.SendGetVersionInfo(req.Sn)
	if err != nil {
		return err
	}
	listInfo := &client.EquipListRes{}
	if err := NewEquipList().List(ctx, nil, listInfo); err == nil {
		for _, v := range listInfo.Equips {
			if v == nil {
				continue
			}
			if v.GetSn() == req.Sn {
				rsp.Ip = v.GetIp()
				break
			}
		}
	}

	rsp.Sn = req.Sn
	rsp.Version = version
	return nil
}

// SflStopHitSet 发送停止打击消息
func (e *DeviceCenter) SflStopHitSet(ctx context.Context, req *client.SflStopHitRequest, rsp *client.SflStopHitResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Sfl{Device: dev}
	status, err := d.SendSflStopHitReq()
	if err != nil {
		return err
	}
	rsp.Status = int32(status)
	if status == 0 {
		rsp.Status = 2
	}
	return nil
}

// SflGNSSSet ...
func (e *DeviceCenter) SflGNSSSet(ctx context.Context, req *client.SflSetGNSSRequest, rsp *client.SflSetGNSSResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Sfl{Device: dev}
	status, err := d.SflGNSSSetReq(req)
	if err != nil {
		logger.Debug("err = ", err)
		return err
	}
	rsp.Status = int32(status)
	if status == 0 {
		rsp.Status = 2
	}
	return nil
}

// SflGNSSGet ...
func (e *DeviceCenter) SflGNSSGet(ctx context.Context, req *client.SflGetGNSSRequest, rsp *client.SflGetGNSSResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		return errors.New("设备未在线")
	}
	logger.Debug("req = ", req)
	logger.Debug("req sn = ", req.Sn)
	logger.Debug("dev = ", dev)
	d := &Sfl{Device: dev}
	status, err := d.SflGNSSGetReq()
	if err != nil {
		return err
	}
	fmt.Println("status = ", status)
	// GunLatitudeTion        = 1e7
	toFloat := 1e7
	// float64(heartInfo.Info.GunLatitude) / GunLatitudeTion
	rsp.Altitude = status.Altitude
	rsp.Latitude = float64(status.Latitude) / toFloat
	rsp.Longitude = float64(status.Longitude) / toFloat
	rsp.Type = uint32(status.Type)
	return nil
}

// SflHitAngleSet 发送打击点信息配置
func (e *DeviceCenter) SflHitAngleSet(ctx context.Context, req *client.SflHitAngleRequest, rsp *client.SflHitAngleResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Sfl{Device: dev}

	status, err := d.SendSflHitAngleSet(req)
	if err != nil {
		return err
	}
	rsp.Status = int32(status)
	if status == 0 {
		rsp.Status = 2
	}

	return nil
}

// SflOnOffSet 发送开关机
func (e *DeviceCenter) SflOnOffSet(ctx context.Context, req *client.SflOnOffRequest, rsp *client.SflOnOffResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Sfl{Device: dev}

	status, err := d.SendSflOnOffSet(req)
	if err != nil {
		return err
	}
	rsp.Status = int32(status)
	if status == 0 {
		rsp.Status = 2
	}

	return nil
}

// SflDetectInfo 侦测信息查询
func (e *DeviceCenter) SflDetectInfo(ctx context.Context, req *client.SflDetectInfoRequest, rsp *client.SflDetectInfoResponse) error {
	//查数据库
	var result *client.SflDetectInfoResponse
	var err error
	if req.FindKey == "" {
		result, err = FindSflDetectInfo(req)
		if err != nil {
			return err
		}
	} else {
		result, err = FindSflDetectInfoByKey(req)
		if err != nil {
			return err
		}
	}

	rsp.List = result.List
	rsp.DetectNum = result.DetectNum
	rsp.HitNum = result.HitNum
	return nil
}

// SflDetectInfoExport  侦测信息导出
func (e *DeviceCenter) SflDetectInfoExport(ctx context.Context, req *client.SflDetectInfoExportRequest, rsp *client.SflDetectInfoExportResponse) error {
	//查数据库
	result, err := FindSflDetectExportInfo(ctx, req)
	//result, err := FindSflDetectExportInfoV2(ctx, req)
	if err != nil {
		return err
	}
	rsp.Status = int32(result)
	return nil
}

// SflReSet 发送复位
func (e *DeviceCenter) SflReSet(ctx context.Context, req *client.SflResetRequest, rsp *client.SflResetResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Sfl{Device: dev}

	status, err := d.SendSflReset()
	if err != nil {
		return err
	}
	rsp.Status = int32(status)
	if status == 0 {
		rsp.Status = 2
	}
	logger.Info("Sfl Reset rsp", rsp.Status)
	return nil
}

// SflSendHitUav 手动选择打击无人机
func (e *DeviceCenter) SflSendHitUav(ctx context.Context, req *client.SflSendHitUavRequest, rsp *client.SflSendHitUavResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Sfl{Device: dev}

	status, err := d.SendSflHitUav(req)
	if err != nil {
		return err
	}
	rsp.Status = int32(status)
	if status == 0 {
		rsp.Status = -1
	}
	logger.Info("Sfl Reset rsp", rsp.Status)
	return nil
}

// SflGetStatus 发送获取状态
func (e *DeviceCenter) SflGetStatus(ctx context.Context, req *client.SflGetStatusRequest, rsp *client.SflGetStatusResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Sfl{Device: dev}

	result, err := d.SendSflGetStatus()
	if err != nil {
		return err
	}
	rsp.Sn = req.Sn
	rsp.HitAngleEnd = result.HitAngleEnd
	rsp.HitAngleBegin = result.HitAngleBegin
	rsp.HitMode = result.HitMode
	rsp.HitPitch1 = result.HitPitch1
	rsp.HitPitch2 = result.HitPitch2
	rsp.HitTime = result.HitTime

	return nil
}

// SflGetPower 发送获取开关机
func (e *DeviceCenter) SflGetPower(ctx context.Context, req *client.SflGetPowerRequest, rsp *client.SflGetPowerResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Sfl{Device: dev}

	result, status, err := d.SendSflGetPower()
	if err != nil {
		return err
	}
	rsp.PowerStatus = int32(result)
	rsp.Status = int32(status)
	if status == 0 {
		rsp.Status = 2
	}
	return nil
}

// SflSetHitMode 发送设置工作模式
func (e *DeviceCenter) SflSetHitMode(ctx context.Context, req *client.SflSetHitModeRequest, rsp *client.SflSetHitModeResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Sfl{Device: dev}

	status, err := d.SendSflSetHitMode(req.HitMode)
	if err != nil {
		return err
	}
	rsp.Status = int32(status)
	if status == 0 {
		rsp.Status = 2
	}
	return nil
}

// SflGetHitMode 发送获取工作模式
func (e *DeviceCenter) SflGetHitMode(ctx context.Context, req *client.SflGetHitModeRequest, rsp *client.SflGetHitModeResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Sfl{Device: dev}

	result, err := d.SendSflGetHitMode()
	if err != nil {
		return err
	}
	rsp.Status = int32(result)
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// 启动/停止打击
func (e *DeviceCenter) SflTurnHit(ctx context.Context, req *client.SflTurnHitRequest, rsp *client.SflTurnHitResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &Sfl{Device: dev}

	result, err := d.SendSflTurnHit(req.StartStop)
	if err != nil {
		return err
	}
	rsp.Status = int32(result)
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// 水平方向转动
func (e *DeviceCenter) SflHorizontalTurn(ctx context.Context, req *client.SflHorizontalTurnRequest, rsp *client.SflHorizontalTurnResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &Sfl{Device: dev}

	result, err := d.SendSflHorizontalTurn(req)
	if err != nil {
		return err
	}
	rsp.Status = int32(result)
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// 垂直方向转动
func (e *DeviceCenter) SflVerticalTurn(ctx context.Context, req *client.SflVerticalTurnRequest, rsp *client.SflVerticalTurnResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &Sfl{Device: dev}

	result, err := d.SendSflVerticalTurn(req)
	if err != nil {
		return err
	}
	rsp.Status = int32(result)
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// SflCrashStop 哨兵塔急停
func (e *DeviceCenter) SflCrashStop(ctx context.Context, req *client.SflCrashStopRequest, rsp *client.SflCrashStopResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &Sfl{Device: dev}

	result, err := d.SendSflCrashStop()
	if err != nil {
		return err
	}
	rsp.Status = int32(result)
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// SflSetPreciseHit 设置精准打击特性
func (e *DeviceCenter) SflSetPreciseHit(ctx context.Context, req *client.SflSetPreciseHitRequest, rsp *client.SflSetPreciseHitResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &Sfl{Device: dev}

	result, err := d.SflSetPreciseHit(req)
	if err != nil {
		return err
	}
	rsp.Status = int32(result)
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// SflGetPreciseHit 获取精准打击特性
func (e *DeviceCenter) SflGetPreciseHit(ctx context.Context, req *client.SflGetPreciseHitRequest, rsp *client.SflGetPreciseHitResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &Sfl{Device: dev}

	result, err := d.SflGetPreciseHit()
	if err != nil {
		return err
	}
	rsp.Enable = int32(result)
	return nil
}

// SflSetInvalidFreq 设置无效无人机频点
func (e *DeviceCenter) SflSetInvalidFreq(ctx context.Context, req *client.SflSetInvalidFreqRequest, rsp *client.SflSetInvalidFreqResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &Sfl{Device: dev}

	result, err := d.SflSetInvalidFreq(req)
	if err != nil {
		return err
	}
	rsp.Status = int32(result)
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// SflGetInvalidFreq 获取无效无人机频点
func (e *DeviceCenter) SflGetInvalidFreq(ctx context.Context, req *client.SflGetInvalidFreqRequest, rsp *client.SflGetInvalidFreqResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &Sfl{Device: dev}

	freqList, err := d.SflGetInvalidFreq()
	if err != nil {
		return err
	}
	rsp.FreqList = freqList
	logger.Info("---->End SflGetInvalidFreq,rsp:", rsp)
	return nil
}

// SflSetHitRadius 设置打击半径
func (e *DeviceCenter) SflSetHitRadius(ctx context.Context, req *client.SflSetAutoHitRadiusRequest, rsp *client.SflSetAutoHitRadiusResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &Sfl{Device: dev}

	result, err := d.SendSflSetHitRadius(req)
	if err != nil {
		return err
	}
	rsp.Status = int32(result)
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// SflGetHitRadius 获取打击半径
func (e *DeviceCenter) SflGetHitRadius(ctx context.Context, req *client.SflGetAutoHitRadiusRequest, rsp *client.SflGetAutoHitRadiusResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &Sfl{Device: dev}

	result, err := d.SendSflGetHitRadius(req)
	if err != nil {
		return err
	}
	rsp.Radius = int32(result)
	return nil
}

// SflSetSwitchParameter 设置开关参数
func (e *DeviceCenter) SflSetSwitchParameter(ctx context.Context, req *client.SflSetSwitchParameterRequest, rsp *client.SflSetSwitchParameterResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &Sfl{Device: dev}

	result, err := d.SflSetSwitchParameter(req)
	if err != nil {
		return err
	}
	rsp.Status = int32(result)
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// SflGetSwitchParameter 获取开关参数
func (e *DeviceCenter) SflGetSwitchParameter(ctx context.Context, req *client.SflGetSwitchParameterRequest, rsp *client.SflGetSwitchParameterResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &Sfl{Device: dev}

	result, err := d.SflGetSwitchParameter(req)
	if err != nil {
		return err
	}
	response := make([]*client.SflSwitchParameter, 0)
	for _, parameter := range result {
		response = append(response, &client.SflSwitchParameter{
			Type:   parameter.Type,
			Enable: parameter.Enable,
		})
	}
	rsp.SwitchParameter = response
	return nil
}

// SflSetNoise 哨兵塔设置噪声
func (e *DeviceCenter) SflSetNoise(ctx context.Context, req *client.SflSetNoiseRequest, rsp *client.SflSetNoiseResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &Sfl{Device: dev}

	result, err := d.SendSflSetNoise(req)
	if err != nil {
		return err
	}
	rsp.Status = int32(result)
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// SflSetFreqCmd 哨兵塔设置频点采集指令
func (e *DeviceCenter) SflSetFreqCmd(ctx context.Context, req *client.SflSetFreqCmdRequest, rsp *client.SflSetFreqCmdResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &Sfl{Device: dev}

	result, err := d.SendSflSetFreqCmd(req.GetSn(), req.GetOp(), req.GetFileName())
	if err != nil {
		return err
	}
	rsp.Status = result
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// SflGetFreqNodeList 获取频点列表
func (e *DeviceCenter) SflGetFreqNodeList(ctx context.Context, req *client.SflGetFreqListRequest, rsp *client.SflGetFreqListResponse) error {

	rsp.Status = 1
	logger.Info("---->Into SflGetFreqNodeList,sn:", req.Sn, req)
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		rsp.Status = 2
		return errors.New("设备未在线")
	}

	d := &Sfl{Device: dev}
	freqNodeList, err := d.SendSflGetFreqNodeList()
	if err != nil {
		logger.Info("---->Send SflGetFreqNodeList err:", err)
		rsp.Status = 2
		return err
	}
	rsp.FreqList = freqNodeList
	logger.Info("---->End SflGetFreqNodeList,rsp:", rsp)
	return nil
}

// SflSetPosture 设置标定设备姿态
func (e *DeviceCenter) SflSetPosture(ctx context.Context, req *client.SflSetPostureRequest, rsp *client.SflSetPostureResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &Sfl{Device: dev}

	result, err := d.SendSflSetPosture(req)
	if err != nil {
		return err
	}
	rsp.Status = int32(result)
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// SflGetPosture 获取标定设备姿态
func (e *DeviceCenter) SflGetPosture(ctx context.Context, req *client.SflGetPostureRequest, rsp *client.SflGetPostureResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &Sfl{Device: dev}

	result, err := d.SendSflGetPosture(req)
	if err != nil {
		return err
	}
	rsp.Set = result.Set
	rsp.Pitch = result.Pitch
	rsp.Raw = result.Raw
	return nil
}

// AgxSelectUav Agx发送选中无人机
func (e *DeviceCenter) AgxSelectUav(ctx context.Context, req *client.AgxSelectUavRequest, rsp *client.AgxSelectUavResponse) error {
	logger.Info("Agx Send Agx Select Uav,req:", req)
	dev := FindCacheDevice(req.Sn, common.DeviceType(req.EquipType))
	if dev == nil {
		return errors.New("设备未在线")
	}
	d := &Agx{Device: dev}
	result, err := d.AgxSelectUav(req)
	if err != nil {
		logger.Error("Agx Select Uav err:", err)
		return err
	}
	rsp.Status = result
	if rsp.Status == Success {
		rsp.Status = 0
	} else {
		rsp.Status = 1
	}
	return nil
}

// AgxSelectSflUav Agx发送选中Sfl探测的无人机
func (e *DeviceCenter) AgxSelectSflUav(ctx context.Context, req *client.AgxSelectSflUavRequest, rsp *client.AgxSelectSflUavResponse) error {
	logger.Info("Agx Send Agx Select Sfl Uav,req:", req)
	dev := FindCacheDevice(req.AgxSn, common.DeviceType(req.EquipType))
	if dev == nil {
		return errors.New("设备未在线")
	}
	d := &Agx{Device: dev}
	status, err := d.AgxSelectSflUav(req)
	if err != nil {
		logger.Error("Agx Select Sfl Uav err:", err)
		return err
	}
	rsp.Status = status
	if status == 0 {
		rsp.Status = 2
	}
	return nil
}

// AgxTrackClassification Agx分类跟踪目标类别
func (e *DeviceCenter) AgxTrackClassification(ctx context.Context, req *client.AgxTrackClassificationRequest, rsp *client.AgxTrackClassificationResponse) error {
	logger.Info("Agx Send Agx Track Classification,req:", req)
	dev := FindCacheDevice(req.Sn, common.DeviceType(req.EquipType))
	if dev == nil {
		return errors.New("设备未在线")
	}
	d := &Agx{Device: dev}
	status, err := d.AgxTrackClassification(req)
	if err != nil {
		logger.Error("Agx Track Classification err:", err)
		return err
	}
	rsp.Status = status
	return nil
}

type SqTable struct {
	Name string
}

func isSameDay(starttime, endtime int64) bool {
	time1 := time.Unix(starttime/1000, 0)
	time2 := time.Unix(endtime/1000, 0)

	// 获取日期部分
	date1 := time1.Format("2006-01-02")
	date2 := time2.Format("2006-01-02")
	return date1 == date2
}

const (
	durationSplitTime = 5000 //5秒
)

func splitTimes(timeSeri []int64) []*client.DeviceDetailListRespUtil {
	if len(timeSeri) == 0 {
		logger.Debug("len timeSeri = 0")
		return nil
	}
	startTime := timeSeri[0]
	endTime := timeSeri[0]
	rsptime := make([]*client.DeviceDetailListRespUtil, 0)
	sep := 0
	logger.Debug("len timeSeri = ", len(timeSeri))
	for _, t := range timeSeri[1:] {
		// logger.Debug("t-endTime = ", t-endTime)
		if t-endTime > durationSplitTime {
			// logger.Debug("t = ", t)
			// ss := time.Unix(startTime/1000, 0) //  return with debug message
			// sss := ss.Format("2006-01-02 15:04:05")
			// s := fmt.Sprintf("%s__%s", sss, strconv.FormatInt(startTime, 10))

			s := strconv.FormatInt(startTime, 10)

			// ee := time.Unix(endTime/1000, 0) // return with debug message
			// eee := ee.Format("2006-01-02 15:04:05")
			// e := fmt.Sprintf("%s__%s", eee, strconv.FormatInt(endTime, 10))
			e := strconv.FormatInt(endTime, 10)

			rsptime = append(rsptime, &client.DeviceDetailListRespUtil{StartTime: s, EndTime: e})
			startTime = t
			sep++
		}
		endTime = t
	}
	s := strconv.FormatInt(startTime, 10)
	e := strconv.FormatInt(endTime, 10)
	rsptime = append(rsptime, &client.DeviceDetailListRespUtil{StartTime: s, EndTime: e})

	return rsptime
}

/*
DeviceDetailList handle层
*/
func (e *DeviceCenter) DeviceDetailList(ctx context.Context, req *client.DeviceDetailListReq, rsp *client.DeviceDetailListResp) error {
	startTimeInt, err := strconv.ParseInt(req.StartTime, 10, 64)
	if err != nil {
		logger.Error("error startTime format")
		return errors.New("error startTime format")
	}
	logger.Debug("startTimeInt  = ", startTimeInt)
	endTimeInt, err := strconv.ParseInt(req.EndTime, 10, 64)
	if err != nil {
		logger.Error("error endTime format")
		return errors.New("error endTime format")
	}
	logger.Debug("endTimeInt  = ", endTimeInt)
	if startTimeInt > endTimeInt {
		logger.Error("start time larger than end time")
		return errors.New("start time larger than end time")
	}

	dateTime := time.Unix(startTimeInt/1000, 0) // 转换为 time.Time 对象
	startTimeStr := dateTime.Format("20060102")
	var sns []string

	for _, u := range req.DevList {
		sns = append(sns, u.Sn)
	}

	var detectsTable []string
	var xxxTable []string
	logger.Debug("sns = ", sns)
	for _, snu := range sns {
		var tmpTable []SqTable
		sPrefix := snu + "_%_" + startTimeStr
		if isSameDay(startTimeInt, endTimeInt) {
			result := db.GetDB().Raw("SELECT name FROM sqlite_master WHERE type='table' AND name LIKE ? ", sPrefix).Scan(&tmpTable)
			if result.Error != nil {
				logger.Error(result.Error)
			}
		} else {
			dtmp := time.Unix(endTimeInt/1000, 0)
			endTimeStr := dtmp.Format("20060102")
			ePrefix := snu + "_%_" + endTimeStr
			result := db.GetDB().Raw("SELECT name FROM sqlite_master WHERE type='table' AND (name LIKE ? OR name LIKE ?)", sPrefix, ePrefix).Scan(&tmpTable)
			if result.Error != nil {
				logger.Error(result.Error)
			}
		}
		for _, t := range tmpTable {
			fmt.Println("table name = **************> ", t.Name)
			if strings.Contains(t.Name, ReplayDetectName) {
				logger.Debug("detect table = ", t.Name)
				detectsTable = append(detectsTable, "\""+t.Name+"\"")
				logger.Debug("detectsTable = ", detectsTable)
			} else {
				xxxTable = append(xxxTable, "\""+t.Name+"\"")
			}
		}
	}
	timeSeri := make([]int64, 0)
	if len(detectsTable) > 0 {
		childSQL := fmt.Sprintf("SELECT create_time FROM %s WHERE create_time >= %d AND create_time <= %d ", detectsTable[0], startTimeInt, endTimeInt)
		var child string
		for _, dt := range detectsTable[1:] {
			child = fmt.Sprintf(" %s UNION SELECT create_time FROM %s WHERE create_time >= %d AND create_time <= %d ", child, dt, startTimeInt, endTimeInt)
		}
		formSQL := fmt.Sprintf("%s%s", childSQL, child)
		detectSQL := fmt.Sprintf("SELECT create_time FROM ( %s ) AS combined_times ORDER BY create_time;", formSQL)
		logger.Debug("detectSQL = ", detectSQL)
		err = db.GetDB().Raw(detectSQL).Scan(&timeSeri).Error
		if err != nil {
			logger.Debug(err)
		}
		logger.Debug("timeSeri = ", timeSeri)
		spResult := splitTimes(timeSeri)
		logger.Debug("sp_result = ", spResult)
		rsp.DroneTimeList = spResult
	}

	if len(xxxTable) > 0 {
		childSQL := fmt.Sprintf("SELECT create_time FROM %s  WHERE create_time >= %d AND create_time <= %d ", xxxTable[0], startTimeInt, endTimeInt)
		var child string
		for _, dt := range xxxTable[1:] {
			child = fmt.Sprintf("%s UNION SELECT create_time FROM %s WHERE create_time >= %d AND create_time <= %d", child, dt, startTimeInt, endTimeInt)
		}
		formSQL := fmt.Sprintf("%s%s", childSQL, child)
		detectSQL := fmt.Sprintf("SELECT create_time FROM ( %s) AS combined_times ORDER BY create_time;", formSQL)

		logger.Debug("detectSQL = ", detectSQL)
		err = db.GetDB().Raw(detectSQL).Scan(&timeSeri).Error
		if err != nil {
			logger.Debug(err)
		}
		logger.Debug("timeSeri = ", timeSeri)
		spResult := splitTimes(timeSeri)
		logger.Debug("sp_result = ", spResult)

		rsp.DevTimeList = spResult
	}
	return nil

}

// AgxCalibration Agx发送标定
func (e *DeviceCenter) AgxCalibration(ctx context.Context, req *client.AgxCalibrationRequest, rsp *client.AgxCalibrationRespone) error {
	logger.Info("Agx Send Calibration,req:", req)
	dev := FindCacheDevice(req.Sn, common.DeviceType(req.EquipType))
	if dev == nil {
		return errors.New("设备未在线")
	}
	d := &Agx{Device: dev}
	result, err := d.AgxCalibration(req)
	if err != nil {
		logger.Error("Agx Calibration err:", err)
		return err
	}
	rsp.Result = result
	return nil
}

// AgxCalibration Agx发送标定
func (e *DeviceCenter) AgxSetCalibrationPara(ctx context.Context, req *client.AgxSetCalibrationParaRequest, rsp *client.AgxSetCalibrationParaRespone) error {
	logger.Info("req :", req)
	dev := FindCacheDevice(req.Sn, common.DeviceType(req.EquipType))
	if dev == nil {
		return errors.New("设备未在线")
	}
	d := &Agx{Device: dev}
	result, err := d.AgxSetCalibrationPara(req)
	if err != nil {
		logger.Error("Agx Calibration err:", err)
		return err
	}
	rsp.Result = result
	return nil
}

// AgxCalibration Agx发送标定
func (e *DeviceCenter) AgxGetCalibrationPara(ctx context.Context, req *client.AgxGetCalibrationParaRequest, rsp *client.AgxGetCalibrationParaRespone) error {
	logger.Info("Agx Send Calibration,req:", req)
	dev := FindCacheDevice(req.Sn, common.DeviceType(req.EquipType))
	if dev == nil {
		return errors.New("设备未在线")
	}
	d := &Agx{Device: dev}
	result, err := d.AgxGetCalibrationPara(req, rsp)
	if err != nil {
		logger.Error("Agx Calibration err:", err)
		return err
	}
	logger.Debugf("result = %+v", result)
	// rsp.result = result
	return nil
}

// RadarSetClutterSuppression 设置杂波抑制参数
func (e *DeviceCenter) RadarSetClutterSuppression(ctx context.Context, req *client.RadarSetClutterSuppressionRequest, rsp *client.RadarSetClutterSuppressionResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_RADAR)
	if dev == nil {
		return errors.New("设备未在线")
	}
	radar := &Radar{Device: dev}
	result, err := radar.SendSetClutterSuppression(req)
	radar.LogOperator(req, result, err)
	if err != nil {
		return err
	}
	rsp.Status = int32(result.Status)
	return nil
}

// RadarGetClutterSuppression 雷达获取杂波抑制信息
func (e *DeviceCenter) RadarGetClutterSuppression(ctx context.Context, req *client.RadarGetClutterSuppressionRequest, rsp *client.RadarGetClutterSuppressionResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_RADAR)
	if dev == nil {
		return errors.New("设备未在线")
	}
	radar := &Radar{Device: dev}
	result, err := radar.SendGetClutterSuppression()
	radar.LogOperator(req, result, err)
	if err != nil {
		return err
	}
	rsp.DetectMode = int32(result.DetectMode)
	rsp.Param = int32(result.Param)
	rsp.Distance = int32(result.Distance)
	return nil
}

// TracerSetVideoParam 给tracer下发设置视频参数
func (e *DeviceCenter) TracerSetVideoParam(ctx context.Context, req *client.TracerSetVideoParamRequest, rsp *client.TracerSetVideoParamResponse) error {
	logger.Info("---->Into Set Tracer Set Video Parameters,sn:", req.Sn, req)
	dev := FindCacheDevice(req.Sn, common.DEV_V2DRONEID)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &DroneID{Device: dev}
	status, err := d.SendTracerSetVideoParam(req.FreqOffset, req.Reserve)
	if err != nil {
		logger.Info("---->Send Tracer Set Video Parameters err:", err)
		return err
	}
	rsp.Status = int32(status)
	if status == 0 {
		rsp.Status = 2
	}
	logger.Info("---->End Tracer Set Video Parameters,rsp:", rsp)
	return nil
}

func (e *DeviceCenter) TracerDetectFreqList(ctx context.Context,
	req *client.TracerGetFreqListRequest,
	rsp *client.TracerGetFreqListResponse) error {

	rsp.Status = 1
	logger.Info("---->Into TracerDetectFreqList,sn:", req.Sn, req)
	dev := FindCacheDevice(req.Sn, common.DEV_V2DRONEID)
	if dev == nil {
		rsp.Status = 2
		return errors.New("设备未在线")
	}

	d := &DroneID{Device: dev}
	freqNodeList, err := d.GetDetectFreqList(req.GetSn())
	if err != nil {
		logger.Info("---->Send GetDetectFreqList err:", err)
		rsp.Status = 2
		return err
	}
	rsp.FreqList = freqNodeList
	logger.Info("---->End GetDetectFreqList,rsp:", rsp)
	return nil
}

// TracerSetNoiseFloor 给tracer下发设置噪底检测
func (e *DeviceCenter) TracerSetNoiseFloor(ctx context.Context, req *client.TracerSetNoiseFloorRequest, rsp *client.TracerSetNoiseFloorResponse) error {
	logger.Info("---->Into Set Tracer Set NoiseFloor,sn:", req.Sn, req)
	dev := FindCacheDevice(req.Sn, common.DEV_V2DRONEID)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &DroneID{Device: dev}
	status, err := d.SendSetTracerNoiseFloor(req.Freq)
	if err != nil {
		logger.Info("---->Send Tracer Set NoiseFloor err:", err)
		return err
	}
	rsp.Status = int32(status)
	if status == 0 {
		rsp.Status = 2
	}
	logger.Info("---->End Tracer Set NoiseFloor,rsp:", rsp)
	return nil
}

// TracerCollectData tracer数据收集入口
func (e *DeviceCenter) TracerCollectData(ctx context.Context, req *client.CollectDataRequest, rsp *client.CollectDataResponse) error {
	logger.Infof("-----> into TracerCollectData, req: %+v", req)
	dev := FindCacheDevice(req.GetSn(), common.DEV_V2DRONEID)
	if dev == nil {
		return errors.New("device is offline")
	}

	d := &DroneID{Device: dev}
	status, err := d.SendCollectData(req.GetSn(), req.GetOp(), req.GetFileName())
	if err != nil {
		logger.Infof("---->Send Tracer collect data err: %v", err)
		status = 0
	}
	rsp.Status = int32(status)
	if status == 0 { // 0: fail
		rsp.Status = 2
	} else {
		rsp.Status = 1
	}
	logger.Infof("---->End TracerCollectData, rsp: %+v", rsp)
	return nil
}

func (e *DeviceCenter) TracerLogExport(ctx context.Context, req *client.TracerLogExportRequest, rsp *client.TracerLogExportResponse) error {
	logger.Infof("-----> into TracerLogExport, req: %+v", req)
	dev := FindCacheDevice(req.GetSn(), common.DEV_V2DRONEID)
	if dev == nil {
		return errors.New("device is offline")
	}
	d := &DroneID{Device: dev}

	status, err := d.GetTracerLog(req.FilePath, req.GetLogType(), req.GetDayNum())
	if err != nil {
		logger.Errorf("---->TracerLogExport err: %v", err)
		return err
	}
	if status == 0 {
		rsp.Status = Success
	} else {
		rsp.Status = Fail
	}
	logger.Infof("---->End TracerLogExport, rsp: %+v", rsp)
	return nil
}

func (e *DeviceCenter) TracerSetTimeFreq(ctx context.Context, req *client.TracerSetTimeFreqRequest, rsp *client.TracerSetTimeFreqResponse) error {
	logger.Infof("-----> into TracerSetTimeFreq, req: %+v", req)
	dev := FindCacheDevice(req.GetSn(), common.DEV_V2DRONEID)
	if dev == nil {
		return errors.New("device is offline")
	}
	if req.Mode != 1 && req.Mode != 2 {
		return errors.New("mode is not support")
	}
	d := &DroneID{Device: dev}

	status, err := d.SetTimeFreq(req.Freq, req.Mode)
	if err != nil {
		logger.Errorf("---->TracerSetTimeFreq err: %v", err)
		return err
	}
	if status == 1 {
		rsp.Status = Success
	} else {
		rsp.Status = Fail
	}
	logger.Infof("---->End TracerSetTimeFreq, rsp: %+v", rsp)
	return nil
}

// SflHitModeSet 发送打击模式配置
func (e *DeviceCenter) SflHitModeSet(ctx context.Context, req *client.SflHitModeRequest, rsp *client.SflHitModeResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Sfl{Device: dev}

	status, err := d.SendSflHitModeSet(req)
	if err != nil {
		return err
	}
	rsp.Status = int32(status)
	if status == 0 {
		rsp.Status = 2
	}
	return nil
}

// RadarSetConfig 配置雷达参数
func (e *DeviceCenter) RadarSetConfig(ctx context.Context, req *client.RadarSetConfigRequest, rsp *client.RadarSetConfigResponse) error {
	logger.Debugf("---->Into Radar Set Config req: %+v", req)
	//兼容非一体化设备
	equipModel, err := GetEquipBySn(req.GetParentSn())
	if err != nil {
		logger.Error("RadarSetConfig GetEquipBySn err", err)
	}
	//一体化设备，请求近程雷视
	if req.GetParentSn() != "" && equipModel != nil && equipModel.IsIntegrated == 1 {
		dev := FindCacheDevice(req.GetParentSn(), common.DeviceType(req.GetParentType()))
		if dev == nil {
			return errors.New("设备未在线")
		}
		agx := &Agx{Device: dev}
		err := agx.ForwardRadarSetConfig(req, rsp)
		if err != nil {
			logger.Errorf("RadarSetConfig ForwardRadarSetConfig err", err)
		}
		return err
	}

	dev := FindCacheDevice(req.Sn, common.DEV_RADAR)
	if dev == nil {
		return errors.New("设备未在线")
	}
	radar := &Radar{Device: dev}
	if dev.ProtoType == codec.SerializationTypeSlink {
		if req.Longitude == nil && req.EleScanCenter == nil && req.FilterLevel == nil && req.Mode == nil {
			logger.Errorf("RadarSetConfig parameter is illegal: %v", req)
			return errors.New("RadarSetConfig parameter is illegal")
		}
		if req.Longitude != nil && req.Latitude != nil && req.Altitude != nil && req.Heading != nil && req.Pitching != nil && req.Rolling != nil {
			// 1. 手动标定姿态
			// 正反转换
			heading := RotateSizeTransfer(req.Heading)
			logger.Infof("heading convert before: %v, after: %v", req.Heading, heading)
			result, err := radar.PostureCalibrationManual(&mavlink.PostureCalibrationManualRequest{
				ULongitude: int32(req.GetLongitude() * RadarPostureReduce20),
				ULatitude:  int32(req.GetLatitude() * RadarPostureReduce20),
				UAltitude:  int32(req.GetAltitude() * RadarPostureReduce),
				UHeading:   int32((*heading) * RadarPostureReduce),
				UPitching:  int32(req.GetPitching() * RadarPostureReduce),
				URolling:   int32(req.GetRolling() * RadarPostureReduce),
			})
			if err != nil {
				logger.Errorf("RadarSetConfig PostureCalibrationManual err: %v", err)
				return err
			}
			if result.Status != 0 {
				logger.Errorf("RadarSetConfig PostureCalibrationManual fail: %+v", result)
				type PostureCalibrationManualRequest struct {
					Longitude float64 `json:"longitude"`
					Latitude  float64 `json:"latitude"`
					Altitude  float64 `json:"altitude"`
					Heading   float64 `json:"heading"`
					Pitching  float64 `json:"pitching"`
					Rolling   float64 `json:"rolling"`
				}
				rsp.Status = uint32(result.Status)
				rsp.ErrCode = getJsonTag(PostureCalibrationManualRequest{})
				return nil
			}
			rsp.Status = uint32(result.Status)
		}
		if req.EleScanCenter != nil && req.EleScanScope != nil && req.AziScanCenter != nil && req.AziScanScope != nil && req.FChannel != nil {
			// 2. 设置波控范围
			result, err := radar.SendSetBeamSize(req.Sn, int32(req.GetEleScanCenter()), int32(req.GetEleScanScope()), int32(req.GetAziScanCenter()), int32(req.GetAziScanScope()), int32(req.GetFChannel()))
			radar.LogOperator(req, result, err)
			if err != nil {
				logger.Errorf("RadarSetConfig SendSetBeamSize err: %v", err)
				return err
			}
			if result.Status != 0 {
				logger.Errorf("RadarSetConfig SendSetBeamSize fail: %+v", result)
				type SendSetBeamSizeRequest struct {
					EleScanCenter float32 `json:"eleScanCenter"`
					EleScanScope  float32 `json:"eleScanScope"`
					AziScanCenter float32 `json:"aziScanCenter"`
					AziScanScope  float32 `json:"aziScanScope"`
					FChannel      uint32  `json:"fChannel"`
				}
				rsp.Status = uint32(result.Status)
				rsp.ErrCode = getJsonTag(SendSetBeamSizeRequest{})
				return nil
			}
			rsp.Status = uint32(result.Status)
		}
		if req.FilterLevel != nil && req.RadarScanRadius != nil {
			// 3. 设置滤波等级
			result, err := radar.SendSetClutterSuppression(&client.RadarSetClutterSuppressionRequest{
				Sn:         req.Sn,
				Distance:   int32(req.GetRadarScanRadius()),
				Param:      int32(req.GetFilterLevel()),
				DetectMode: 1,
			})
			radar.LogOperator(req, result, err)
			if err != nil {
				logger.Errorf("RadarSetConfig SendSetClutterSuppression err: %v", err)
				return err
			}
			if result.Status != 0 {
				logger.Errorf("RadarSetConfig SendSetClutterSuppression fail: %+v", result)
				type SetClutterSuppressionRequest struct {
					RadarScanRadius uint32 `json:"radarScanRadius"`
					FilterLevel     uint32 `json:"filterLevel"`
				}
				rsp.Status = uint32(result.Status)
				rsp.ErrCode = getJsonTag(SetClutterSuppressionRequest{})
				return nil
			}
			rsp.Status = uint32(result.Status)
		}
		if req.GetMode() != 0 {
			switch req.GetMode() {
			// 自动标定
			case uint32(common.AUTOPOSTURECALIBRATION):
				result, err := radar.PostureCalibration()
				if err != nil {
					logger.Errorf("RadarSetConfig PostureCalibration err: %v", err)
					return err
				}
				if result.Status != 0 {
					logger.Errorf("RadarSetConfig PostureCalibration fail: %+v", result)
					rsp.Status = uint32(result.Status)
					return nil
				}
				rsp.Status = uint32(result.Status)
			// 雷达开始侦测
			case uint32(common.STARTDETECT):
				result, err := radar.SendStartDetect(req.GetSn())
				radar.LogOperator(req, result, err)
				if err != nil {
					logger.Errorf("RadarSetConfig SendStartDetect err: %v", err)
					return err
				}
				if result.Status != 0 {
					logger.Errorf("RadarSetConfig SendStartDetect fail: %+v", result)
					rsp.Status = uint32(result.Status)
					return nil
				}
				rsp.Status = uint32(result.Status)
			// 雷达结束侦测
			case uint32(common.ENDDETECT):
				result, err := radar.SendEndDetect(req.GetSn(), true)
				radar.LogOperator(req, result, err)
				if err != nil {
					logger.Errorf("RadarSetConfig SendEndDetect err: %v", err)
					return err
				}
				if result.Status != 0 {
					logger.Errorf("RadarSetConfig SendEndDetect fail: %+v", result)
					rsp.Status = uint32(result.Status)
					return nil
				}
				rsp.Status = uint32(result.Status)
			}
		}
		return nil
	}

	result, err := radar.RadarSetConfig(req.Sn, &bizproto.RadarC2Config{
		Version:         req.Version,
		Longitude:       req.Longitude,
		Latitude:        req.Latitude,
		Altitude:        req.Altitude,
		Heading:         req.Heading,
		Pitching:        req.Pitching,
		Rolling:         req.Rolling,
		EleScanCenter:   req.EleScanCenter,
		EleScanScope:    req.EleScanScope,
		AziScanCenter:   req.AziScanCenter,
		AziScanScope:    req.AziScanScope,
		RadarScanRadius: req.RadarScanRadius,
		FilterLevel:     req.FilterLevel,
		Electricity:     req.Electricity,
		Status:          req.Status,
		SysStatus:       req.SysStatus,
		FChannel:        req.FChannel,
		TChannel:        req.TChannel,
		Mode:            req.Mode,
		ClutterMode:     req.ClutterMode,
	})
	radar.LogOperator(req, result, err)
	if err != nil {
		return err
	}
	rsp.Status = result.Status
	rsp.ErrCode = make([]*client.RadarC2ErrCode, 0)
	for _, info := range result.ErrCode {
		tmp := &client.RadarC2ErrCode{}
		tmp.Code = info.Code
		tmp.Name = info.Name
		rsp.ErrCode = append(rsp.ErrCode, tmp)
	}
	return nil
}

// RadarGetConfig 获取雷达配置参数回复
func (e *DeviceCenter) RadarGetConfig(ctx context.Context, req *client.RadarGetConfigRequest, rsp *client.RadarGetConfigResponse) error {
	logger.Debugf("RadarGetConfig req: %v", req)
	//兼容非一体化设备
	equipModel, err := GetEquipBySn(req.GetParentSn())
	if err != nil {
		logger.Error("RadarSetConfig GetEquipBySn err", err)
	}
	if req.GetParentSn() != "" && equipModel != nil && equipModel.IsIntegrated == 1 {
		dev := FindCacheDevice(req.GetParentSn(), common.DeviceType(req.GetParentType()))
		if dev == nil {
			return errors.New("设备未在线")
		}
		agx := &Agx{
			Device: dev,
		}
		err := agx.ForwardRadarGetConfig(req, rsp)
		if err != nil {
			logger.Errorf("RadarGetConfig ForwardRadarGetConfig err", err)
		}
		return err
	}

	dev := FindCacheDevice(req.Sn, common.DEV_RADAR)
	if dev == nil {
		return errors.New("设备未在线")
	}
	radar := &Radar{Device: dev}
	if dev.ProtoType == codec.SerializationTypeSlink {
		// 1. 获取版本号
		_, appVer, _, _, _, err := radar.SendGetVersionInfo(req.Sn)
		if err != nil {
			logger.Errorf("RadarGetConfig SendGetVersionInfo err: %v", err)
			return err
		}
		// 2. 获取波控范围
		result, err := radar.SendBeamSteerConfig(req.Sn)
		radar.LogOperator(req, result, err)
		if err != nil {
			logger.Errorf("RadarGetConfig SendBeamSteerConfig err: %v", err)
			return err
		}
		// 3. 获取杂波抑制
		filterLevelRes, err := radar.SendGetClutterSuppression()
		if err != nil {
			logger.Errorf("RadarGetConfig SendGetClutterSuppression err: %v", err)
			return err
		}
		// 4. 姿态信息从表 radar_tcp_posture_info 获取最新一条
		postureInfo, err := NewRadarTcpDataCache().GetLastPosture(ctx, req.Sn)
		if err != nil {
			logger.Errorf("RadarGetConfig GetLastPosture err: %v", err)
			return err
		}
		logger.Debugf("RadarGetConfig GetLastPosture result: %+v", postureInfo)
		// 组装返回结果
		aziScanCenter := helper.TranBaseType[float32, int8](result.AziScanCenter)
		aziScanScope := helper.TranBaseType[float32, uint8](result.AziScanScope)
		eleScanScope := helper.TranBaseType[float32, uint8](result.EleScanScope)
		eleScanCenter := helper.TranBaseType[float32, int8](result.EleScanCenter)
		fChannel := helper.TranBaseType[uint32, uint8](result.WaveFrequencyChannel)

		rsp.Sn = &(req.Sn)
		rsp.Version = &appVer
		rsp.AziScanCenter = &aziScanCenter
		rsp.AziScanScope = &aziScanScope
		rsp.EleScanScope = &eleScanScope
		rsp.EleScanCenter = &eleScanCenter
		rsp.FChannel = &fChannel
		rsp.RadarScanRadius = &(filterLevelRes.Distance)
		rsp.FilterLevel = &(filterLevelRes.Param)
		rsp.Longitude = &(postureInfo.Longitude)
		rsp.Latitude = &(postureInfo.Latitude)
		rsp.Altitude = &(postureInfo.Altitude)
		rsp.Heading = &(postureInfo.Heading)
		rsp.Pitching = &(postureInfo.Pitching)
		rsp.Rolling = &(postureInfo.Rolling)
		rsp.VersionType = codec.VersionTypeV1Str
		return nil
	}
	result, err := radar.RadarGetConfig(req.Sn)
	radar.LogOperator(req, result, err)
	if err != nil {
		return err
	}
	rsp.Sn = result.Sn
	rsp.Version = result.Version
	rsp.Longitude = result.Longitude
	rsp.Latitude = result.Latitude
	rsp.Altitude = result.Altitude
	rsp.Heading = result.Heading
	rsp.Pitching = result.Pitching
	rsp.Rolling = result.Rolling
	rsp.EleScanCenter = result.EleScanCenter
	rsp.EleScanScope = result.EleScanScope
	rsp.AziScanCenter = result.AziScanCenter
	rsp.AziScanScope = result.AziScanScope
	rsp.RadarScanRadius = result.RadarScanRadius
	rsp.FilterLevel = result.FilterLevel
	rsp.Electricity = result.Electricity
	rsp.Status = result.Status
	rsp.SysStatus = result.SysStatus
	rsp.FChannel = result.FChannel
	rsp.TChannel = result.TChannel
	rsp.VersionType = codec.VersionTypeV2Str
	rsp.ClutterMode = result.ClutterMode
	return nil
}

// RadarSetMask 配置雷达Mask
func (e *DeviceCenter) RadarSetMask(ctx context.Context, req *client.RadarSetMaskRequest, rsp *client.RadarSetMaskResponse) error {
	logger.Debugf("---->Into Radar Set Mask req: %+v", req)
	//兼容非一体化设备
	equipModel, err := GetEquipBySn(req.GetParentSn())
	if err != nil {
		logger.Error("RadarSetMask GetEquipBySn err", err)
	}
	if req.GetParentSn() != "" && equipModel != nil && equipModel.IsIntegrated == 1 {
		dev := FindCacheDevice(req.GetParentSn(), common.DeviceType(req.GetParentType()))
		if dev == nil {
			return errors.New("设备未在线")
		}
		agx := &Agx{Device: dev}
		err := agx.ForwardRadarSetMask(req, rsp)
		if err != nil {
			logger.Error("RadarSetMask ForwardRadarMask err", err)
		}
		return err
	}
	dev := FindCacheDevice(req.Sn, common.DEV_RADAR)
	if dev == nil {
		return errors.New("设备未在线")
	}
	radar := &Radar{Device: dev}

	radarSetMaskReq := &bizproto.RadarC2Mask{
		Sn:        &(req.Sn),
		AllDelete: req.AllDeleteValue,
		ItemMask:  make([]*bizproto.RadarMaskZoneInfo, 0),
	}

	for _, item := range req.GetItemMasks() {
		if item.GetOrder() < 0 || item.GetOrder() > 2 {
			return errors.New("param order must be 0-2")
		}
		if len(item.GetName()) > 128 {
			return errors.New("param name length must be less than 128")
		}

		for _, val := range item.GetClassification() {
			if _, ok := bitMapping[val]; !ok {
				return errors.New("param classification must be 0-6")
			}
		}
		//数组转换成uint32
		classification := int32ArrayToUint32(item.GetClassification())
		tmp := &bizproto.RadarMaskZoneInfo{
			Order:          item.Order,
			RangStart:      item.RangeStart,
			RangEnd:        item.RangeEnd,
			AzimuthStart:   item.AzimuthStart,
			AzimuthEng:     item.AzimuthEnd,
			ElevationStart: item.ElevationStart,
			ElevationEnd:   item.ElevationEnd,
			VelocityStart:  item.VelocityStart,
			VelocityEnd:    item.VelocityEnd,
			RcsStart:       item.RcsStart,
			RcsEnd:         item.RcsEnd,
			HighStart:      item.HeightStart,
			HighEnd:        item.HeightEnd,
			TargetType:     &classification,
			Name:           item.Name,
			Number:         item.Number,
			Used:           item.InvalidTag,
		}
		radarSetMaskReq.ItemMask = append(radarSetMaskReq.ItemMask, tmp)
	}
	result, err := radar.RadarSetMask(req.Sn, radarSetMaskReq)
	if err != nil {
		return err
	}
	rsp.AllDeleteResult = result.AllResult
	rsp.ItemResults = make([]*client.RadarMaskResult, 0)
	for _, info := range result.ItemResult {
		tmp := &client.RadarMaskResult{
			Order:  info.Order,
			Name:   info.Name,
			Result: info.Result,
			Number: info.Number,
		}
		rsp.ItemResults = append(rsp.ItemResults, tmp)
	}
	return nil
}

// RadarGetMask 获取雷达Mask
func (e *DeviceCenter) RadarGetMask(ctx context.Context, req *client.RadarGetMaskRequest, rsp *client.RadarGetMaskResponse) error {
	logger.Debugf("RadarGetMask req: %+v", req)
	//兼容非一体化设备
	equipModel, err := GetEquipBySn(req.GetParentSn())
	if err != nil {
		logger.Error("RadarSetMask GetEquipBySn err", err)
	}
	if req.GetParentSn() != "" && equipModel != nil && equipModel.IsIntegrated == 1 {
		dev := FindCacheDevice(req.GetParentSn(), common.DeviceType(req.GetParentType()))
		if dev == nil {
			return errors.New("设备未在线")
		}
		agx := &Agx{Device: dev}
		err := agx.ForwardRadarGetMask(req, rsp)
		if err != nil {
			logger.Error("RadarGetMask ForwardRadarMask err", err)
		}
		return err
	}
	dev := FindCacheDevice(req.Sn, common.DEV_RADAR)
	if dev == nil {
		return errors.New("设备未在线")
	}
	radar := &Radar{Device: dev}
	result, err := radar.RadarGetMask(req.Sn)
	if err != nil {
		return err
	}

	//嵌入式返回默认值
	invalidTag := result.GetAllDelete()
	if invalidTag == 2 {
		invalidTag = 0
	} else if invalidTag == 3 {
		invalidTag = 1
	}
	rsp.InvalidTag = &invalidTag
	rsp.ItemMasks = make([]*client.RadarMaskInfo, 0)
	for _, info := range result.ItemMask {
		tmp := &client.RadarMaskInfo{
			Order:          info.Order,
			RangeStart:     info.RangStart,
			RangeEnd:       info.RangEnd,
			AzimuthStart:   info.AzimuthStart,
			AzimuthEnd:     info.AzimuthEng,
			ElevationStart: info.ElevationStart,
			ElevationEnd:   info.ElevationEnd,
			VelocityStart:  info.VelocityStart,
			VelocityEnd:    info.VelocityEnd,
			RcsStart:       info.RcsStart,
			RcsEnd:         info.RcsEnd,
			Name:           info.Name,
			Classification: Uint32ToIntArray(info.GetTargetType()),
			HeightStart:    info.HighStart,
			HeightEnd:      info.HighEnd,
			Number:         info.Number,
			InvalidTag:     info.Used,
		}
		rsp.ItemMasks = append(rsp.ItemMasks, tmp)
	}
	return nil
}

// 定义每个int32值对应的bit位
var bitMapping = map[int32]uint32{
	0: 1,  // 无人机 -> bit位0
	1: 2,  // 车 -> bit位1
	2: 4,  // 人 -> bit位2
	3: 8,  // 船 -> bit位3
	4: 16, // 鸟 -> bit位4
	5: 32, // 轻型飞行器 -> bit位5
	6: 64, // 未识别 -> bit位6
}

// 数组转换成uint32
func int32ArrayToUint32(arr []int32) uint32 {
	result := uint32(0)

	for _, value := range arr {
		if bit, ok := bitMapping[value]; ok {
			result |= bit
		}
	}
	return result
}

// uint32转换成数组
func Uint32ToIntArray(result uint32) []int32 {
	// 定义每个bit位对应的int值
	bitMapping := map[uint32]int32{
		1:  0, // bit位0 -> 无人机
		2:  1, // bit位1 -> 车
		4:  2, // bit位2 -> 人
		8:  3, // bit位3 -> 船
		16: 4, // bit位4 -> 鸟
		32: 5, // bit位5 -> 轻型飞行器
		64: 6, // bit位6 -> 未识别
	}
	arr := make([]int32, 0)
	for bit := uint32(1); bit <= 64; bit *= 2 {
		if result&bit > 0 {
			arr = append(arr, bitMapping[bit])
		}
	}
	return arr
}

func getJsonTag(i any) []*client.RadarC2ErrCode {
	var code uint32 = 100
	errCode := make([]*client.RadarC2ErrCode, 0)
	iType := reflect.TypeOf(i)
	for i := 0; i < iType.NumField(); i++ {
		field := iType.Field(i)
		if jsonTag := field.Tag.Get("json"); jsonTag != "" {
			tmp := &client.RadarC2ErrCode{
				Name: jsonTag,
				Code: code,
			}
			errCode = append(errCode, tmp)
		}
	}
	return errCode
}

func RotateSizeTransfer(heading *float64) *float64 {
	if heading == nil {
		return nil
	}
	newHeading := *heading
	if newHeading == 0 || newHeading == 360 {
		return &newHeading
	}
	intHeading := math.Abs(newHeading)

	intResult := math.Mod(360-intHeading, 360)
	result := intResult
	if newHeading < 0 {
		result = 360 - result
	}
	//雷视临时需求
	//get、set不需要补偿
	//result = result + float64(TempHeading)
	return &result
}

//// AirTracerGetVersionInfo 发送获取机载Tracer版本信息
//func (e *DeviceCenter) AirTracerGetVersionInfo(ctx context.Context, req *client.AirTracerGetVersionRequest, rsp *client.AirTracerGetVersionResponse) error {
//	dev := FindCacheDevice(req.Sn, common.DEV_Air_Tracer)
//	if dev == nil {
//		return errors.New("设备未在线")
//	}
//
//	d := &Fpv{Device: dev}
//	rsp, err := d.FpvSendGetVersion()
//	if err != nil {
//		return err
//	}
//	return nil
//}

// Sfl200SetWorkMode 设置工作模式
func (e *DeviceCenter) Sfl200SetWorkMode(ctx context.Context, req *client.Sfl200SetWorkModeRequest, rsp *client.Sfl200SetWorkModeResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL200)
	if dev == nil {
		rsp.Status = Fail
		logger.Errorf("sfl200 is not online")
		return errors.New("sfl200 is not online")
	}
	sfl200 := &Sfl200{Device: dev}
	result, err := sfl200.Sfl200SetWorkMode(req)
	if err != nil {
		logger.Errorf("Sfl200SetWorkMode  error: %v", err)
		return err
	}
	rsp.Status = result
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// Sfl200GetWorkMode 获取工作模式
func (e *DeviceCenter) Sfl200GetWorkMode(ctx context.Context, req *client.Sfl200GetWorkModeRequest, rsp *client.Sfl200GetWorkModeResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL200)
	if dev == nil {
		logger.Errorf("sfl200 is not online")
		return errors.New("sfl200 is not online")
	}
	sfl200 := &Sfl200{Device: dev}
	result, err := sfl200.Sfl200GetWorkMode(req)
	if err != nil {
		logger.Errorf("Sfl200SetWorkMode  error: %v", err)
		return err
	}
	rsp.WorkMode = result
	return nil
}

// Sfl200SetAutoHitConfig 自动察打模式指令参数配置
func (e *DeviceCenter) Sfl200SetAutoHitConfig(ctx context.Context, req *client.Sfl200SetAutoHitConfigRequest, rsp *client.Sfl200SetAutoHitConfigResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL200)
	if dev == nil {
		rsp.Status = Fail
		logger.Errorf("sfl200 is not online")
		return errors.New("sfl200 is not online")
	}
	sfl200 := &Sfl200{Device: dev}
	result, err := sfl200.Sfl200SetAutoHitConfig(req)
	if err != nil {
		logger.Errorf("Sfl200SetAutoHitConfig  error: %v", err)
		return err
	}
	rsp.Status = result
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// Sfl200GetAutoHitConfig 自动察打模式指令参数获取
func (e *DeviceCenter) Sfl200GetAutoHitConfig(ctx context.Context, req *client.Sfl200GetAutoHitConfigRequest, rsp *client.Sfl200GetAutoHitConfigResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL200)
	if dev == nil {
		logger.Errorf("sfl200 is not online")
		return errors.New("sfl200 is not online")
	}
	sfl200 := &Sfl200{Device: dev}
	result, err := sfl200.Sfl200GetAutoHitConfig(req)
	if err != nil {
		logger.Errorf("Sfl200GetAutoHitConfig  error: %v", err)
		return err
	}

	logger.Debug("result = ", result)
	rsp.SysDzWType = int32(result.SysDZWType)
	rsp.SysDzPPdx = int32(result.SysDZPPDX)
	rsp.SysYPEnable = int32(result.SysYPEnable)
	rsp.SysYPCdt1 = int32(result.SysYPCdt1)
	rsp.SysYPCdt2 = int32(result.SysYPCdt2)
	rsp.SysYPMtd = int32(result.SysYPMtd)
	rsp.SysCDWType = int32(result.SysCDWType)
	rsp.SysCDMType = int32(result.SysCDMType)
	rsp.SysCdWD1 = int32(result.SysCDWD1)
	rsp.SysCdWD2 = int32(result.SysCDWD2)
	rsp.SysCdWD3 = int32(result.SysCDWD3)
	rsp.SysCdWT1 = int32(result.SysCDWT1)
	rsp.SysCdWT2 = int32(result.SysCDWT2)
	rsp.SysCdWT3 = int32(result.SysCDWT3)
	logger.Debug("rsp = ", rsp)
	return nil
}

// Sfl200PtzFollowUav 目标PTZ跟踪
func (e *DeviceCenter) Sfl200PtzFollowUav(ctx context.Context, req *client.Sfl200PtzFollowUavRequest, rsp *client.Sfl200PtzFollowUavResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL200)
	if dev == nil {
		rsp.Status = Fail
		logger.Errorf("sfl200 is not online")
		return errors.New("sfl200 is not online")
	}
	sfl200 := &Sfl200{Device: dev}
	result, err := sfl200.Sfl200PtzFollowUav(req)
	if err != nil {
		logger.Errorf("Sfl200PtzFollowUav  error: %v", err)
		return err
	}
	rsp.Status = result
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// Sfl200DealUav 目标打击处置
func (e *DeviceCenter) Sfl200DealUav(ctx context.Context, req *client.Sfl200DealUavRequest, rsp *client.Sfl200DealUavResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL200)
	if dev == nil {
		rsp.Status = Fail
		logger.Errorf("sfl200 is not online")
		return errors.New("sfl200 is not online")
	}
	sfl200 := &Sfl200{Device: dev}
	result, err := sfl200.Sfl200DealUav(req)
	if err != nil {
		logger.Errorf("Sfl200DealUav  error: %v", err)
		return err
	}
	rsp.Status = result
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// Sfl200FreqDirect 频谱目标定向
func (e *DeviceCenter) Sfl200FreqDirect(ctx context.Context, req *client.Sfl200FreqDirectRequest, rsp *client.Sfl200FreqDirectResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL200)
	if dev == nil {
		rsp.Status = Fail
		logger.Errorf("sfl200 is not online")
		return errors.New("sfl200 is not online")
	}
	sfl200 := &Sfl200{Device: dev}
	result, err := sfl200.Sfl200FreqDirect(req)
	if err != nil {
		logger.Errorf("Sfl200FreqDirect  error: %v", err)
		return err
	}
	rsp.Status = result
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// Sfl200FreqDirectHit 频谱目标定向打击
func (e *DeviceCenter) Sfl200FreqDirectHit(ctx context.Context, req *client.Sfl200FreqDirectHitRequest, rsp *client.Sfl200FreqDirectHitResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL200)
	if dev == nil {
		rsp.Status = Fail
		logger.Errorf("sfl200 is not online")
		return errors.New("sfl200 is not online")
	}
	sfl200 := &Sfl200{Device: dev}
	result, err := sfl200.Sfl200FreqDirectHit(req)
	if err != nil {
		logger.Errorf("Sfl200FreqDirectHit  error: %v", err)
		return err
	}
	rsp.Status = result
	if result == 0 {
		rsp.Status = -1
	}
	return nil
}

// Sfl200StartStopHit 开关打击
func (e *DeviceCenter) Sfl200StartStopHit(ctx context.Context, req *client.Sfl200StartStopHitRequest, rsp *client.Sfl200StartStopHitResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL200)
	if dev == nil {
		rsp.Status = Fail
		logger.Errorf("sfl200 is not online")
		return errors.New("sfl200 is not online")
	}
	sfl200 := &Sfl200{Device: dev}
	result, err := sfl200.Sfl200StartStopHit(req)
	if err != nil {
		logger.Errorf("Sfl200StartStopHit  error: %v", err)
		return err
	}
	rsp.Status = result
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// Sfl200TurnSfl 　转台手动控制
func (e *DeviceCenter) Sfl200TurnSfl(ctx context.Context, req *client.Sfl200TurnSflRequest, rsp *client.Sfl200TurnSflResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL200)
	if dev == nil {
		rsp.Status = Fail
		logger.Errorf("sfl200 is not online")
		return errors.New("sfl200 is not online")
	}
	sfl200 := &Sfl200{Device: dev}
	result, err := sfl200.Sfl200TurnSfl(req)
	if err != nil {
		logger.Errorf("Sfl200TurnSfl  error: %v", err)
		return err
	}
	rsp.Status = result
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// Sfl200StartNsf4000 　开启导航诱骗干扰
func (e *DeviceCenter) Sfl200StartNsf4000(ctx context.Context, req *client.Sfl200StartNsf4000Request, rsp *client.Sfl200StartNsf4000Response) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL200)
	if dev == nil {
		rsp.Status = Fail
		logger.Errorf("sfl200 is not online")
		return errors.New("sfl200 is not online")
	}
	sfl200 := &Sfl200{Device: dev}
	result, err := sfl200.Sfl200StartNsf4000(req)
	if err != nil {
		logger.Errorf("Sfl200StartNsf4000  error: %v", err)
		return err
	}
	rsp.Status = result
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// Sfl200SystemWorkSetting 　系统工作参数配置
func (e *DeviceCenter) Sfl200SystemWorkSetting(ctx context.Context, req *client.Sfl200SystemWorkSettingRequest, rsp *client.Sfl200SystemWorkSettingResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL200)
	if dev == nil {
		rsp.Status = Fail
		logger.Errorf("sfl200 is not online")
		return errors.New("sfl200 is not online")
	}
	sfl200 := &Sfl200{Device: dev}
	result, err := sfl200.Sfl200SystemWorkSetting(req)
	if err != nil {
		logger.Errorf("Sfl200SystemWorkSetting  error: %v", err)
		return err
	}
	rsp.Status = result
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// Sfl200SystemWorkGet 　系统工作参数获取
func (e *DeviceCenter) Sfl200SystemWorkGet(ctx context.Context, req *client.Sfl200SystemWorkGetRequest, rsp *client.Sfl200SystemWorkGetResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL200)
	if dev == nil {
		logger.Errorf("sfl200 is not online")
		return errors.New("sfl200 is not online")
	}
	sfl200 := &Sfl200{Device: dev}
	result, err := sfl200.Sfl200SystemWorkGet(req)
	if err != nil {
		logger.Errorf("Sfl200SystemWorkGet  error: %v", err)
		return err
	}

	rsp.SysGBIMode = int32(result.SysGBIMode)
	rsp.SysGBJd = result.SysGBJd
	rsp.SysGBWd = result.SysGBWd
	rsp.SysGBGd = result.SysGBGd
	rsp.SysGBJTime1 = int32(result.SysGBJTime1)
	rsp.SysGBJTime2 = int32(result.SysGBJTime2)
	rsp.SysGBJTime3 = int32(result.SysGBJTime3)
	rsp.SysGBJMode = int32(result.SysGBJMode)
	rsp.SysGBJF0 = int32(result.SysGBJF0)
	rsp.SysGBJF1 = int32(result.SysGBJF1)
	rsp.SysGBJF2 = int32(result.SysGBJF2)
	rsp.SysGBJF3 = int32(result.SysGBJF3)
	rsp.SysGBJF4 = int32(result.SysGBJF4)
	rsp.SysGBJF5 = int32(result.SysGBJF5)
	rsp.SysGBJF6 = int32(result.SysGBJF6)
	rsp.SysGBJFPV1 = int32(result.SysGBJFpv1)
	rsp.SysGBJFPV2 = int32(result.SysGBJFpv2)
	return nil
}

// GunsPlatformSetNoise 设置噪声
func (e *DeviceCenter) GunsPlatformSetNoise(ctx context.Context, req *client.GunsPlatformSetNoiseRequest, rsp *client.GunsPlatformSetNoiseResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_HUNTER_PLATFORM)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &GunsPlatform{Device: dev}

	result, err := d.SendSetNoise(req)
	if err != nil {
		return err
	}
	rsp.Status = int32(result)
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// GunsPlatformGetFreqNodeList 获取频点列表
func (e *DeviceCenter) GunsPlatformGetFreqNodeList(ctx context.Context, req *client.GunsPlatformGetFreqListRequest, rsp *client.GunsPlatformGetFreqListResponse) error {

	rsp.Status = 1
	logger.Info("---->Into GunsPlatformGetFreqNodeList,sn:", req.Sn, req)
	dev := FindCacheDevice(req.Sn, common.DEV_HUNTER_PLATFORM)
	if dev == nil {
		rsp.Status = 2
		return errors.New("设备未在线")
	}

	d := &GunsPlatform{Device: dev}
	freqNodeList, err := d.SendGetFreqNodeList()
	if err != nil {
		logger.Info("---->Send GunsPlatformGetFreqNodeList err:", err)
		rsp.Status = 2
		return err
	}
	rsp.FreqList = freqNodeList
	logger.Info("---->End GunsPlatformGetFreqNodeList,rsp:", rsp)
	return nil
}

// GunsPlatformSetFreqCmd 设置频点采集指令
func (e *DeviceCenter) GunsPlatformSetFreqCmd(ctx context.Context, req *client.GunsPlatformSetFreqCmdRequest, rsp *client.GunsPlatformSetFreqCmdResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_HUNTER_PLATFORM)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &GunsPlatform{Device: dev}

	result, err := d.SendSetFreqCmd(req.GetSn(), req.GetOp(), req.GetFileName())
	if err != nil {
		return err
	}
	rsp.Status = result
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// Sfl200GetVersionInfo 　系统SFL200版本号
func (e *DeviceCenter) Sfl200GetVersionInfo(ctx context.Context, req *client.Sfl200GetVersionRequest, rsp *client.Sfl200GetVersionResponse) error {
	logger.Info("Get Sfl200 Version req = ", req)
	dev := FindCacheDevice(req.Sn, common.DEV_SFL200)
	if dev == nil {
		logger.Errorf("sfl200 is not online")
		return errors.New("sfl200 is not online")
	}
	sfl200 := &Sfl200{Device: dev}
	result, err := sfl200.Sfl200GetVersionInfo(req)
	if err != nil {
		logger.Errorf("Sfl200SystemWorkGet  error: %v", err)
		return err
	}
	conn := connmgr.Instance().GetConn(req.Sn)
	if conn == nil {
		logger.Errorf("sn %s GetConn nil,req:", req)
	}
	logger.Info("Sfl200 ip:", conn.Conn.RemoteAddr().String())
	ipIndex := strings.Index(conn.Conn.RemoteAddr().String(), ":")
	rsp.Sfl200Ip = conn.Conn.RemoteAddr().String()[:ipIndex]
	rsp.Sfl200Sn = req.Sn
	rsp.Sfl200Version = ByteToString(result.Sfl200ServerVersion[:])
	rsp.AgxVersion = ByteToString(result.AgxVersion[:])
	rsp.Sfl100Version = ByteToString(result.Sfl100Version[:])
	rsp.FusionVersion = ByteToString(result.FusionVersion[:])
	rsp.TracerPVersion = ByteToString(result.TracerPVersion[:])
	rsp.RadarVersion = ByteToString(result.RadarVersion[:])
	rsp.SpoofVersion = ByteToString(result.SpooferVersion[:])
	logger.Info("Get Sfl200 Version rsp = ", rsp)
	return nil
}

// GunsPlatformGetVersionInfo GunsPlatform获取版本信息
func (e *DeviceCenter) GunsPlatformGetVersionInfo(ctx context.Context, req *client.GunsPlatformGetVersionRequest, rsp *client.GunsPlatformGetVersionResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_HUNTER_PLATFORM)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &GunsPlatform{Device: dev}
	version, err := d.SendGetVersionInfo(req.Sn)
	if err != nil {
		return err
	}

	listInfo := &client.EquipListRes{}
	if err := NewEquipList().List(ctx, nil, listInfo); err == nil {
		for _, v := range listInfo.Equips {
			if v == nil {
				continue
			}
			if v.GetSn() == req.Sn {
				rsp.Ip = v.GetIp()
				break
			}
		}
	}

	rsp.Sn = req.Sn
	rsp.Version = version
	return nil
}

// GunsPlatformStopHitSet 发送停止打击消息
func (e *DeviceCenter) GunsPlatformStopHitSet(ctx context.Context, req *client.GunsPlatformStopHitRequest, rsp *client.GunsPlatformStopHitResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_HUNTER_PLATFORM)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &GunsPlatform{Device: dev}
	status, err := d.SendGunsPlatformStopHitReq()
	if err != nil {
		return err
	}
	rsp.Status = int32(status)
	if status == 0 {
		rsp.Status = 2
	}
	return nil
}

// GunsPlatformGNSSSet ...
func (e *DeviceCenter) GunsPlatformGNSSSet(ctx context.Context, req *client.GunsPlatformSetGNSSRequest, rsp *client.GunsPlatformSetGNSSResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_HUNTER_PLATFORM)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &GunsPlatform{Device: dev}
	status, err := d.GunsPlatformGNSSSetReq(req)
	if err != nil {
		logger.Debug("err = ", err)
		return err
	}
	rsp.Status = int32(status)
	if status == 0 {
		rsp.Status = 2
	}
	return nil
}

// GunsPlatformGNSSGet ...
func (e *DeviceCenter) GunsPlatformGNSSGet(ctx context.Context, req *client.GunsPlatformGetGNSSRequest, rsp *client.GunsPlatformGetGNSSResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_HUNTER_PLATFORM)
	if dev == nil {
		return errors.New("设备未在线")
	}
	logger.Debug("req = ", req)
	logger.Debug("req sn = ", req.Sn)
	logger.Debug("dev = ", dev)
	d := &GunsPlatform{Device: dev}
	status, err := d.GunsPlatformGNSSGetReq()
	if err != nil {
		return err
	}
	fmt.Println("status = ", status)
	// GunLatitudeTion        = 1e7
	toFloat := 1e7
	// float64(heartInfo.Info.GunLatitude) / GunLatitudeTion
	rsp.Altitude = status.Altitude
	rsp.Latitude = float64(status.Latitude) / toFloat
	rsp.Longitude = float64(status.Longitude) / toFloat
	rsp.Type = uint32(status.Type)
	return nil
}

// GunsPlatformHitAngleSet 发送打击点信息配置
func (e *DeviceCenter) GunsPlatformHitAngleSet(ctx context.Context, req *client.GunsPlatformHitAngleRequest, rsp *client.GunsPlatformHitAngleResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_HUNTER_PLATFORM)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &GunsPlatform{Device: dev}

	status, err := d.SendGunsPlatformHitAngleSet(req)
	if err != nil {
		return err
	}
	rsp.Status = int32(status)
	if status == 0 {
		rsp.Status = 2
	}

	return nil
}

// GunsPlatformOnOffSet 发送开关机
func (e *DeviceCenter) GunsPlatformOnOffSet(ctx context.Context, req *client.GunsPlatformOnOffRequest, rsp *client.GunsPlatformOnOffResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_HUNTER_PLATFORM)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &GunsPlatform{Device: dev}

	status, err := d.SendGunsPlatformOnOffSet(req)
	if err != nil {
		return err
	}
	rsp.Status = int32(status)
	if status == 0 {
		rsp.Status = 2
	}

	return nil
}

// GunsPlatformReSet 发送复位
func (e *DeviceCenter) GunsPlatformReSet(ctx context.Context, req *client.GunsPlatformResetRequest, rsp *client.GunsPlatformResetResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_HUNTER_PLATFORM)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &GunsPlatform{Device: dev}

	status, err := d.SendGunsPlatformReset()
	if err != nil {
		return err
	}
	rsp.Status = int32(status)
	if status == 0 {
		rsp.Status = 2
	}
	logger.Info("GunsPlatform Reset rsp", rsp.Status)
	return nil
}

// GunsPlatformSendHitUav 手动选择打击无人机
func (e *DeviceCenter) GunsPlatformSendHitUav(ctx context.Context, req *client.GunsPlatformSendHitUavRequest, rsp *client.GunsPlatformSendHitUavResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_HUNTER_PLATFORM)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &GunsPlatform{Device: dev}

	status, err := d.SendGunsPlatformHitUav(req)
	if err != nil {
		return err
	}
	rsp.Status = int32(status)
	if status == 0 {
		rsp.Status = -1
	}
	logger.Info("GunsPlatform Reset rsp", rsp.Status)
	return nil
}

// GunsPlatformGetStatus 发送获取状态
func (e *DeviceCenter) GunsPlatformGetStatus(ctx context.Context, req *client.GunsPlatformGetStatusRequest, rsp *client.GunsPlatformGetStatusResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_HUNTER_PLATFORM)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &GunsPlatform{Device: dev}

	result, err := d.SendGunsPlatformGetStatus()
	if err != nil {
		return err
	}
	rsp.Sn = req.Sn
	rsp.HitAngleEnd = result.HitAngleEnd
	rsp.HitAngleBegin = result.HitAngleBegin
	rsp.HitMode = result.HitMode
	rsp.HitPitch1 = result.HitPitch1
	rsp.HitPitch2 = result.HitPitch2
	rsp.HitTime = result.HitTime

	return nil
}

// GunsPlatformGetPower 发送获取开关机
func (e *DeviceCenter) GunsPlatformGetPower(ctx context.Context, req *client.GunsPlatformGetPowerRequest, rsp *client.GunsPlatformGetPowerResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_HUNTER_PLATFORM)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &GunsPlatform{Device: dev}

	result, status, err := d.SendGunsPlatformGetPower()
	if err != nil {
		return err
	}
	rsp.PowerStatus = int32(result)
	rsp.Status = int32(status)
	if status == 0 {
		rsp.Status = 2
	}
	return nil
}

// GunsPlatformSetHitMode 发送设置工作模式
func (e *DeviceCenter) GunsPlatformSetHitMode(ctx context.Context, req *client.GunsPlatformSetHitModeRequest, rsp *client.GunsPlatformSetHitModeResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_HUNTER_PLATFORM)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &GunsPlatform{Device: dev}

	status, err := d.SendGunsPlatformSetHitMode(req.HitMode)
	if err != nil {
		return err
	}
	rsp.Status = int32(status)
	if status == 0 {
		rsp.Status = 2
	}
	return nil
}

// GunsPlatformGetHitMode 发送获取工作模式
func (e *DeviceCenter) GunsPlatformGetHitMode(ctx context.Context, req *client.GunsPlatformGetHitModeRequest, rsp *client.GunsPlatformGetHitModeResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_HUNTER_PLATFORM)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &GunsPlatform{Device: dev}

	result, err := d.SendGunsPlatformGetHitMode()
	if err != nil {
		return err
	}
	rsp.Status = int32(result)
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// 启动/停止打击
func (e *DeviceCenter) GunsPlatformTurnHit(ctx context.Context, req *client.GunsPlatformTurnHitRequest, rsp *client.GunsPlatformTurnHitResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_HUNTER_PLATFORM)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &GunsPlatform{Device: dev}

	result, err := d.SendGunsPlatformTurnHit(req.StartStop)
	if err != nil {
		return err
	}
	rsp.Status = int32(result)
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// 水平方向转动
func (e *DeviceCenter) GunsPlatformHorizontalTurn(ctx context.Context, req *client.GunsPlatformHorizontalTurnRequest, rsp *client.GunsPlatformHorizontalTurnResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_HUNTER_PLATFORM)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &GunsPlatform{Device: dev}

	result, err := d.SendGunsPlatformHorizontalTurn(req)
	if err != nil {
		return err
	}
	rsp.Status = int32(result)
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// 垂直方向转动
func (e *DeviceCenter) GunsPlatformVerticalTurn(ctx context.Context, req *client.GunsPlatformVerticalTurnRequest, rsp *client.GunsPlatformVerticalTurnResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_HUNTER_PLATFORM)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &GunsPlatform{Device: dev}

	result, err := d.SendGunsPlatformVerticalTurn(req)
	if err != nil {
		return err
	}
	rsp.Status = int32(result)
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// GunsPlatformCrashStop 哨兵塔急停
func (e *DeviceCenter) GunsPlatformCrashStop(ctx context.Context, req *client.GunsPlatformCrashStopRequest, rsp *client.GunsPlatformCrashStopResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_HUNTER_PLATFORM)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &GunsPlatform{Device: dev}

	result, err := d.SendGunsPlatformCrashStop()
	if err != nil {
		return err
	}
	rsp.Status = int32(result)
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// GunsPlatformHitModeSet 发送打击模式配置
func (e *DeviceCenter) GunsPlatformHitModeSet(ctx context.Context, req *client.GunsPlatformHitModeRequest, rsp *client.GunsPlatformHitModeResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_HUNTER_PLATFORM)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &GunsPlatform{Device: dev}

	status, err := d.SendGunsPlatformHitModeSet(req)
	if err != nil {
		return err
	}
	rsp.Status = int32(status)
	if status == 0 {
		rsp.Status = 2
	}
	return nil
}

// GunsPlatformSetPreciseHit 设置精准打击特性
func (e *DeviceCenter) GunsPlatformSetPreciseHit(ctx context.Context, req *client.GunsPlatformSetPreciseHitRequest, rsp *client.GunsPlatformSetPreciseHitResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_HUNTER_PLATFORM)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &GunsPlatform{Device: dev}

	result, err := d.GunsPlatformSetPreciseHit(req)
	if err != nil {
		return err
	}
	rsp.Status = int32(result)
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// GunsPlatformGetPreciseHit 获取精准打击特性
func (e *DeviceCenter) GunsPlatformGetPreciseHit(ctx context.Context, req *client.GunsPlatformGetPreciseHitRequest, rsp *client.GunsPlatformGetPreciseHitResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_HUNTER_PLATFORM)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &GunsPlatform{Device: dev}

	result, err := d.GunsPlatformGetPreciseHit()
	if err != nil {
		return err
	}
	rsp.Enable = int32(result)
	return nil
}

// GunsPlatformSetInvalidFreq 设置无效无人机频点
func (e *DeviceCenter) GunsPlatformSetInvalidFreq(ctx context.Context, req *client.GunsPlatformSetInvalidFreqRequest, rsp *client.GunsPlatformSetInvalidFreqResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_HUNTER_PLATFORM)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &GunsPlatform{Device: dev}

	result, err := d.GunsPlatformSetInvalidFreq(req)
	if err != nil {
		return err
	}
	rsp.Status = int32(result)
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// GunsPlatformGetInvalidFreq 获取无效无人机频点
func (e *DeviceCenter) GunsPlatformGetInvalidFreq(ctx context.Context, req *client.GunsPlatformGetInvalidFreqRequest, rsp *client.GunsPlatformGetInvalidFreqResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_HUNTER_PLATFORM)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &GunsPlatform{Device: dev}

	freqList, err := d.GunsPlatformGetInvalidFreq()
	if err != nil {
		return err
	}
	rsp.FreqList = freqList
	logger.Info("---->End GunsPlatformGetInvalidFreq,rsp:", rsp)
	return nil
}

// GunsPlatformSetHitRadius 设置打击半径
func (e *DeviceCenter) GunsPlatformSetHitRadius(ctx context.Context, req *client.GunsPlatformSetAutoHitRadiusRequest, rsp *client.GunsPlatformSetAutoHitRadiusResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_HUNTER_PLATFORM)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &GunsPlatform{Device: dev}

	result, err := d.SendGunsPlatformSetHitRadius(req)
	if err != nil {
		return err
	}
	rsp.Status = int32(result)
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// GunsPlatformGetHitRadius 获取打击半径
func (e *DeviceCenter) GunsPlatformGetHitRadius(ctx context.Context, req *client.GunsPlatformGetAutoHitRadiusRequest, rsp *client.GunsPlatformGetAutoHitRadiusResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_HUNTER_PLATFORM)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &GunsPlatform{Device: dev}

	result, err := d.SendGunsPlatformGetHitRadius(req)
	if err != nil {
		return err
	}
	rsp.Radius = int32(result)
	return nil
}

// GunsPlatformSetSwitchParameter 设置开关参数
func (e *DeviceCenter) GunsPlatformSetSwitchParameter(ctx context.Context, req *client.GunsPlatformSetSwitchParameterRequest, rsp *client.GunsPlatformSetSwitchParameterResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_HUNTER_PLATFORM)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &GunsPlatform{Device: dev}

	result, err := d.GunsPlatformSetSwitchParameter(req)
	if err != nil {
		return err
	}
	rsp.Status = int32(result)
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// GunsPlatformGetSwitchParameter 获取开关参数
func (e *DeviceCenter) GunsPlatformGetSwitchParameter(ctx context.Context, req *client.GunsPlatformGetSwitchParameterRequest, rsp *client.GunsPlatformGetSwitchParameterResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_HUNTER_PLATFORM)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &GunsPlatform{Device: dev}

	result, err := d.GunsPlatformGetSwitchParameter(req)
	if err != nil {
		return err
	}
	response := make([]*client.GunsPlatformSwitchParameter, 0)
	for _, parameter := range result {
		response = append(response, &client.GunsPlatformSwitchParameter{
			Type:   parameter.Type,
			Enable: parameter.Enable,
		})
	}
	rsp.SwitchParameter = response
	return nil
}

func (e *DeviceCenter) TracerPToAgx(request *mavlink.TracerPSendToAGX) error {
	logger.Info("TracerPToAgx request:", request)
	DevStatusMap.Range(func(key, value interface{}) bool {
		dev := value.(*Device)
		if dev.DevType == common.DEV_AGX {
			d := &Agx{
				Device: dev,
				dt:     common.DEV_AGX,
			}
			logger.Info("agx sn is :", d.Sn)
			_, err := d.TracerPToAGXSend(request)
			if err != nil {
				logger.Error("Agx TracerPToAgx err:", err)
				return true
			}
		}
		return true
	})
	return nil
}

// AgxPTZGetMessage Agx获取PTZ信息
func (e *DeviceCenter) AgxGetPTZMsgDev(ctx context.Context, req *client.AgxPTZMsgRequest, rsp *client.AgxPTZMsgResponse) error {
	logger.Info(" :", req)
	dev := FindCacheDevice(req.Sn, common.DeviceType(req.EquipType))
	if dev == nil {
		return errors.New("设备未在线")
	}
	d := &Agx{Device: dev}
	result, err := d.AgxPTZGetMessage(req, rsp)
	if err != nil {
		logger.Error("AgxGetPTZMsgDev err:", err)
		return err
	}
	logger.Debug("result = ", result)
	return nil
}

// AgxPTZConctrlReq Agx获取PTZ信息
func (e *DeviceCenter) AgxPTZConctrlReq(ctx context.Context, req *client.AgxPTZControlRequest, rsp *client.AgxPTZControlResponse) error {
	logger.Info(" :", req)
	dev := FindCacheDevice(req.Sn, common.DeviceType(req.EquipType))
	if dev == nil {
		return errors.New("设备未在线")
	}
	d := &Agx{Device: dev}
	result, err := d.AgxPTZControlReq(req, rsp)
	if err != nil {
		logger.Error("Agx Calibration err:", err)
		return err
	}
	logger.Debug("result = ", result)
	return nil
}

// AgxControlPTZZoomReq Agx控制PTZ缩放请求
func (e *DeviceCenter) AgxControlPTZZoomReq(ctx context.Context, req *client.AgxZoomControlRequest, rsp *client.AgxZoomControlResponse) error {
	logger.Info("AgxControlPTZZoomReq req: ", req)
	dev := FindCacheDevice(req.Sn, common.DeviceType(req.EquipType))
	if dev == nil {
		return errors.New("设备未在线")
	}
	d := &Agx{Device: dev}
	result, err := d.AgxControlPTZZoom(req, rsp)
	if err != nil {
		logger.Error("Agx Calibration err:", err)
		return err
	}
	logger.Debug("result = ", result)
	return nil
}

// AgxUserStatusSet ...
func (e *DeviceCenter) AgxUserStatusSet(ctx context.Context, req *client.AgxUserStatuSetRequest, rsp *client.AgxUserStatuSetResponse) error {
	logger.Info(" :", req)
	dev := FindCacheDevice(req.Sn, common.DeviceType(req.EquipType))
	if dev == nil {
		return errors.New("设备未在线")
	}
	d := &Agx{Device: dev}
	result, err := d.AgxUserStatusSetting(req, rsp)
	if err != nil {
		logger.Error("Agx Calibration err:", err)
		return err
	}
	logger.Debug("result = ", result)
	return nil
}

// AgxGetVersion ...
func (e *DeviceCenter) AgxGetVersion(ctx context.Context, req *client.AgxGetVersionRequest, rsp *client.AgxGetVersionResponse) error {
	logger.Info(" :", req)
	dev := FindCacheDevice(req.Sn, common.DeviceType(req.EquipType))
	if dev == nil {
		return errors.New("设备未在线")
	}
	d := &Agx{Device: dev}
	result, err := d.AgxGetVersion(req, rsp)
	if err != nil {
		logger.Error("Agx Calibration err:", err)
		return err
	}
	rsp.Sn = result.Sn
	rsp.AiVersion = result.AiVersion
	rsp.KernelVersion = result.KernelVersion
	rsp.HwVersion = result.HwVersion
	rsp.AppVersion = result.AppVersion
	rsp.BootVersion = result.BootVersion
	rsp.FusionVersion = result.FusionVersion
	logger.Debug("result = ", result)
	return nil
}

// AgxGetInfo Agx获取雷视设备信息
func (e *DeviceCenter) AgxGetInfo(ctx context.Context, req *client.AgxGetInfoRequest, rsp *client.AgxGetInfoResponse) error {
	logger.Info("req :", req)
	dev := FindCacheDevice(req.Sn, common.DeviceType(req.EquipType))
	if dev == nil {
		return errors.New("设备未在线")
	}
	d := &Agx{Device: dev}
	result, err := d.AgxGetInfo(req)
	if err != nil {
		logger.Error("AgxGetInfo err:", err)
		return err
	}

	rsp.Ip1 = result.Ip1
	rsp.Ip2 = result.Ip2
	rsp.Sn = result.Sn
	rsp.AppVersion = result.AppVersion
	rsp.Longitude = result.Longitude
	rsp.Latitude = result.Latitude
	rsp.Declination = result.Declination
	logger.Debug("result = ", result)
	return nil
}

// Srp100Calibration srp100开始、退出标定
func (e *DeviceCenter) Srp100Calibration(ctx context.Context, req *client.Srp100CalibrationRequest, rsp *client.Srp100CalibrationResponse) error {
	logger.Debugf("Srp100Calibration req: %v", req)
	dev := FindCacheDevice(req.SrpSn, common.DEV_AGX)
	if dev == nil {
		return errors.New("设备未在线")
	}
	d := &Agx{Device: dev}
	err := d.SendSrp100Calibration(req, rsp)
	if err != nil {
		logger.Error("Srp100Calibration err:", err)
		return err
	}
	return nil
}

// Srp100GetCalibrationStatus 获取srp100标定状态
func (e *DeviceCenter) Srp100GetCalibrationStatus(ctx context.Context, req *client.Srp100GetCalibrationStatusRequest, rsp *client.Srp100GetCalibrationStatusResponse) error {
	logger.Debugf("Srp100GetCalibrationStatus req: %v", req)
	if req.State != 0 {
		return errors.New("Srp100GetCalibrationStatus invalid param")
	}
	dev := FindCacheDevice(req.SrpSn, common.DEV_AGX)
	if dev == nil {
		return errors.New("设备未在线")
	}
	d := &Agx{Device: dev}
	err := d.Srp100GetCalibrationStatus(req, rsp)
	if err != nil {
		logger.Error("Srp100GetCalibrationStatus err:", err)
		return err
	}
	return nil
}

// Srp100UserHandTargetPoint 用户下发手点像素目标值
func (e *DeviceCenter) Srp100UserHandTargetPoint(ctx context.Context, req *client.Srp100UserHandTargetPointRequest, rsp *client.Srp100UserHandTargetPointResponse) error {
	logger.Debugf("Srp100UserHandTargetPoint req: %v", req)
	dev := FindCacheDevice(req.SrpSn, common.DEV_AGX)
	if dev == nil {
		return errors.New("设备未在线")
	}
	d := &Agx{Device: dev}
	err := d.Srp100UserHandTarget(req, rsp)
	if err != nil {
		logger.Error("Srp100UserHandTargetPoint err:", err)
		return err
	}
	return nil
}

// Srp100GetCalibrationResult 查询标定结果
func (e *DeviceCenter) Srp100GetCalibrationResult(ctx context.Context, req *client.Srp100GetCalibrationResultRequest, rsp *client.Srp100GetCalibrationResultResponse) error {
	logger.Debugf("Srp100GetCalibrationResult req: %v", req)
	if req.Spec == 1 && req.RadarSn == "" {
		return errors.New("Srp100GetCalibrationResult invalid param")
	}
	dev := FindCacheDevice(req.SrpSn, common.DEV_AGX)
	if dev == nil {
		return errors.New("设备未在线")
	}
	d := &Agx{Device: dev}
	err := d.Srp100GetCalibrationResult(req, rsp)
	if err != nil {
		logger.Error("Srp100GetCalibrationResult err:", err)
		return err
	}
	return nil
}

// Srp100ConfirmCalibration 目标已锁定，是否确认当前锁定
func (e *DeviceCenter) Srp100ConfirmCalibration(ctx context.Context, req *client.Srp100ConfirmCalibrationRequest, rsp *client.Srp100ConfirmCalibrationResponse) error {
	logger.Debugf("Srp100ConfirmCalibration req: %v", req)
	dev := FindCacheDevice(req.SrpSn, common.DEV_AGX)
	if dev == nil {
		return errors.New("设备未在线")
	}
	d := &Agx{Device: dev}
	err := d.Srp100ConfirmCalibration(req, rsp)
	if err != nil {
		logger.Error("Srp100ConfirmCalibration err:", err)
		return err
	}
	return nil
}

// DPH110SetConfig 配置DPH110参数 todo 先记录数据库，与设备暂不交互
func (e *DeviceCenter) DPH110SetConfig(ctx context.Context, req *client.RadarSetConfigRequest, rsp *client.RadarSetConfigResponse) error {
	logger.Debugf("---->Into DPH110 Set Config req: %+v", req)
	err := NewDPH110Config().Upsert(req)
	if err != nil {
		logger.Errorf("DPH110SetConfig err: %+v", err)
		return err
	}
	rsp.Status = 0
	return nil
}

// DPH110GetConfig 获取DPH110配置参数回复
func (e *DeviceCenter) DPH110GetConfig(ctx context.Context, req *client.RadarGetConfigRequest, rsp *client.RadarGetConfigResponse) error {
	logger.Debugf("---->Into DPH110 Get Config req: %+v", req)
	dbModel, err := NewDPH110Config().First(req.GetSn())
	if err != nil {
		logger.Errorf("DPH110GetConfig err: %+v", err)
		return err
	}
	rsp.Longitude = &(dbModel.Longitude)
	rsp.Latitude = &(dbModel.Latitude)
	rsp.Altitude = &(dbModel.Altitude)
	rsp.Heading = &(dbModel.Heading)
	rsp.Pitching = &(dbModel.Pitching)
	rsp.Rolling = &(dbModel.Rolling)
	rsp.EleScanCenter = &(dbModel.EleScanCenter)
	rsp.EleScanScope = &(dbModel.EleScanScope)
	rsp.AziScanCenter = &(dbModel.AziScanCenter)
	rsp.AziScanScope = &(dbModel.AziScanScope)
	scanRadius := helper.TranBaseType[uint32, int32](dbModel.RadarScanRadius)
	rsp.RadarScanRadius = &scanRadius
	filterLevel := helper.TranBaseType[uint32, int32](dbModel.FilterLevel)
	rsp.FilterLevel = &filterLevel
	fChannel := helper.TranBaseType[uint32, int32](dbModel.FChannel)
	rsp.FChannel = &fChannel
	tChannel := helper.TranBaseType[uint32, int32](dbModel.TChannel)
	rsp.TChannel = &tChannel
	return nil
}

// EmailAlarmSelectDevice 邮件告警选择设备
func (e *DeviceCenter) EmailAlarmSelectDevice(ctx context.Context, req *client.EmailAlarmSettingRequest, rsp *client.EmailAlarmSettingResponse) error {
	logger.Debugf("---->Into EmailAlarmSelectDevice req: %+v", req)
	//更新数据库进行记录
	alarmDevice := make([]*client.AlarmDeviceList, 0)
	for _, device := range req.AlarmDevices {
		alarmDevice = append(alarmDevice, &client.AlarmDeviceList{
			IsSelect:   device.IsSelect,
			DeviceType: device.DeviceType,
		})
	}
	err := NewEmailAlarm().UpdateEmailAlarm(context.Background(), &client.EmailAlarmDeviceReq{
		IsAlarm:      req.IsAlarm,
		EmailSwitch:  req.EmailSwitch,
		AlarmDevices: alarmDevice,
	}, &client.EmailAlarmDeviceRes{})
	if err != nil {
		logger.Errorf("EmailAlarmSelectDevice err: %+v", err)
		rsp.Status = Fail
		return err
	}
	rsp.Status = Success
	logger.Info("EmailAlarmSelectDevice success")

	return nil
}

// GetEmailAlarmConfig 获取邮件告警配置
func (e *DeviceCenter) GetEmailAlarmConfig(ctx context.Context, req *client.EmailAlarmSettingGetRequest, rsp *client.EmailAlarmSettingGetResponse) error {
	logger.Debugf("---->Into GetEmailAlarmConfig req: %+v", req)

	alarmSetting := &client.GetEmailAlarmSettingRes{}
	err := NewEmailAlarm().GetEmailAlarmSetting(context.Background(), &client.GetEmailAlarmSettingReq{}, alarmSetting)
	if err != nil {
		logger.Errorf("GetEmailAlarmConfig err: %+v", err)
		return err
	}

	rsp.Email = alarmSetting.Email
	rsp.IsAlarm = alarmSetting.IsAlarm
	rsp.EmailSwitch = alarmSetting.EmailSwitch
	for _, device := range alarmSetting.AlarmDevices {
		rsp.AlarmDevices = append(rsp.AlarmDevices, &client.AlarmDevice{
			IsSelect:   device.IsSelect,
			DeviceType: device.DeviceType,
		})
	}

	logger.Info("GetEmailAlarmConfig success, rsp: %+v", rsp)

	return nil
}

// UpdateEmailAlarm 更新邮件地址
func (e *DeviceCenter) UpdateEmailAlarm(ctx context.Context, req *client.EmailAlarmUpdateEmailRequest, rsp *client.EmailAlarmUpdateEmailResponse) error {
	logger.Debugf("---->Into UpdateEmailAlarm req: %+v", req)

	err := NewEmailAlarm().UpdateEmail(context.Background(), &client.EmailAlarmReq{
		Email:    req.Email,
		Language: req.Language,
	}, &client.EmailAlarmRes{})
	if err != nil {
		logger.Errorf("UpdateEmailAlarm err: %+v", err)
		rsp.Status = Fail
		return err
	}
	rsp.Status = Success
	logger.Info("UpdateEmailAlarm success, rsp: %+v", rsp)

	return nil
}

// GetSbp100DevInfo 获取sbp100设备信息
func (e *DeviceCenter) GetSbp100DevInfo(ctx context.Context, req *client.GetSbp100DevInfoRequest, rsp *client.GetSbp100DevInfoResponse) error {
	logger.Debugf("GetSbp100DevInfo req: %v", req)
	dev := FindCacheDevice(req.Sn, common.DEV_SBP100)
	if dev == nil {
		return errors.New("设备未在线")
	}
	d := &Agx{Device: dev}
	result, err := d.AgxGetInfo(&client.AgxGetInfoRequest{
		Sn:        req.Sn,
		EquipType: common.DEV_SBP100,
	})
	if err != nil {
		logger.Error("AgxGetInfo err:", err)
		return err
	}

	rsp.Ip = result.Ip1
	rsp.Sn = result.Sn
	rsp.Version = result.AppVersion
	rsp.Longitude = result.Longitude
	rsp.Latitude = result.Latitude
	logger.Debug("---> End GetSbp100DevInfo result: ", result)
	return nil
}

// Sbp100TurnOnOff sbp100开启、关闭开关
func (e *DeviceCenter) Sbp100TurnOnOff(ctx context.Context, req *client.Sbp100TurnOnOffRequest, rsp *client.Sbp100TurnOnOffResponse) error {
	logger.Debugf("Sbp100TurnOnOff req: %v", req)
	dev := FindCacheDevice(req.Sn, common.DEV_LASER)
	if dev == nil {
		return errors.New("设备未在线")
	}
	d := &Sbp100{Agx: &Agx{Device: dev}}
	err := d.Sbp100TurnOnOff(req, rsp)
	if err != nil {
		logger.Error("Sbp100TurnOnOff err:", err)
		return err
	}
	return nil
}

// Sbp100FireZero sbp100打击点修正
func (e *DeviceCenter) Sbp100FireZero(ctx context.Context, req *client.Sbp100FireZeroRequest, rsp *client.Sbp100FireZeroResponse) error {
	logger.Debugf("Sbp100FireZero req: %v", req)
	dev := FindCacheDevice(req.Sn, common.DEV_LASER)
	if dev == nil {
		return errors.New("设备未在线")
	}
	d := &Sbp100{Agx: &Agx{Device: dev}}
	err := d.Sbp100FireZero(req, rsp)
	if err != nil {
		logger.Error("Sbp100FireZero err:", err)
		return err
	}
	return nil
}

// Sbp100FireRange sbp100开启、关闭测距
func (e *DeviceCenter) Sbp100FireRange(ctx context.Context, req *client.Sbp100FireRangeRequest, rsp *client.Sbp100FireRangeResponse) error {
	logger.Debugf("Sbp100FireRange req: %v", req)
	dev := FindCacheDevice(req.Sn, common.DEV_LASER)
	if dev == nil {
		return errors.New("设备未在线")
	}
	d := &Sbp100{Agx: &Agx{Device: dev}}
	err := d.Sbp100FireRange(req, rsp)
	if err != nil {
		logger.Error("Sbp100FireRange err:", err)
		return err
	}
	return nil
}

// Sbp100OnOffLight sbp100开启、关闭照明
func (e *DeviceCenter) Sbp100OnOffLight(ctx context.Context, req *client.Sbp100OnOffLightRequest, rsp *client.Sbp100OnOffLightResponse) error {
	logger.Debugf("Sbp100OnOffLight req: %v", req)
	dev := FindCacheDevice(req.Sn, common.DEV_LASER)
	if dev == nil {
		return errors.New("设备未在线")
	}
	d := &Sbp100{Agx: &Agx{Device: dev}}
	err := d.Sbp100OnOffLight(req, rsp)
	if err != nil {
		logger.Error("Sbp100OnOffLight err:", err)
		return err
	}
	return nil
}

// Sbp100FireMainLaser sbp100开启、停止打击
func (e *DeviceCenter) Sbp100FireMainLaser(ctx context.Context, req *client.Sbp100FireMainLaserRequest, rsp *client.Sbp100FireMainLaserResponse) error {
	logger.Debugf("Sbp100FireMainLaser req: %v", req)
	dev := FindCacheDevice(req.Sn, common.DEV_LASER)
	if dev == nil {
		return errors.New("设备未在线")
	}
	d := &Sbp100{Agx: &Agx{Device: dev}}
	err := d.Sbp100FireMainLaser(req, rsp)
	if err != nil {
		logger.Error("Sbp100FireMainLaser err:", err)
		return err
	}
	return nil
}

// SelectUavToLaserDevice 下发指定目标给激光设备
func (e *DeviceCenter) SelectUavToLaserDevice(ctx context.Context, req *client.SelectUavToLaserDeviceReq, rsp *client.SelectUavToLaserDeviceRsp) error {
	logger.Debugf("SelectUavToLaserDevice req: %v", req)
	dev := FindCacheDevice(req.AgxSn, common.DEV_SBP100)
	if dev == nil {
		return errors.New("设备未在线")
	}
	d := &Sbp100{Agx: &Agx{Device: dev}}
	err := d.SelectUavToLaserDevice(req, rsp)
	if err != nil {
		logger.Error("SelectUavToLaserDevice err:", err)
		return err
	}
	return nil
}

// TracerGunGetFreqList tracerGun 获取频段
func (e *DeviceCenter) TracerGunGetFreqList(ctx context.Context, req *client.TracerGunGetFreqListRequest, rsp *client.TracerGunGetFreqListResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_TracerGun)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &TracerGun{Device: dev}
	status, err := d.TracerGunGetFreqList()
	if err != nil || status == nil {
		return err
	}
	rsp.FreqList1 = status.FreqList1
	rsp.FreqList0 = status.FreqList0
	return nil
}

// TracerGunSetFreqList tracerGun 设置频段
func (e *DeviceCenter) TracerGunSetFreqList(ctx context.Context, req *client.TracerGunSetFreqListRequest, rsp *client.TracerGunSetFreqListResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_TracerGun)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &TracerGun{Device: dev}
	status, err := d.TracerGunSetFreqList(req)
	if err != nil {
		return err
	}
	rsp.Status = status
	if status == 0 {
		rsp.Status = 2
	}
	return nil
}

// TracerGunResetFreqList tracerGun 初始化频段
func (e *DeviceCenter) TracerGunResetFreqList(ctx context.Context, req *client.TracerGunResetFreqListRequest, rsp *client.TracerGunResetFreqListResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_TracerGun)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &TracerGun{Device: dev}
	status, err := d.TracerGunResetFreqList(req)
	if err != nil {
		return err
	}
	rsp.Status = status
	if status == 0 {
		rsp.Status = 2
	}
	return nil
}

// TracerGunDelAddFreqList 增加或者删除打击频谱参数
func (e *DeviceCenter) TracerGunDelAddFreqList(ctx context.Context, req *client.TracerGunAddDelFreqRequest, rsp *client.TracerGunAddDelFreqResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_TracerGun)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &TracerGun{Device: dev}
	status, err := d.TracerGunDelAndFreqList(req)
	if err != nil {
		return err
	}
	rsp.Status = status
	if status == 0 {
		rsp.Status = 2
	}
	return nil
}

// TracerGunSetJamStatus tracerGun 设置打击模式
func (e *DeviceCenter) TracerGunSetJamStatus(ctx context.Context, req *client.TracerGunSetJamStatusRequest, rsp *client.TracerGunSetJamStatusResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_TracerGun)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &TracerGun{Device: dev}
	status, err := d.TracerGunSetJamStatus(req)
	if err != nil {
		return err
	}
	rsp.Status = status
	if status == 0 {
		rsp.Status = 2
	}
	return nil
}

// TracerGunGetJamStatus tracerGun 获取打击模式
func (e *DeviceCenter) TracerGunGetJamStatus(ctx context.Context, req *client.TracerGunGetJamStatusRequest, rsp *client.TracerGunGetJamStatusResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_TracerGun)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &TracerGun{Device: dev}
	status, err := d.TracerGunGetJamStatus()
	if err != nil {
		return err
	}
	rsp.JamStatus = status
	return nil
}

// TraceGunGetInfo 获取Tracer gun 设备信息
func (e *DeviceCenter) TraceGunGetInfo(ctx context.Context, req *client.TracerGunGetInfoRequest, rsp *client.TracerGunGetInfoResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_TracerGun)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &TracerGun{Device: dev}
	data, err := d.GetVersionInfo(req.Sn)
	if err != nil {
		return err
	}
	if data == nil {
		logger.Errorf("get device version info is empty")
		return fmt.Errorf("not get device version info.")
	}
	*rsp = *(data)
	return nil
}

func (e *DeviceCenter) DemoTestCall(ctx context.Context, req *client.DemoTestReq, rsp *client.DemoTestResp) error {
	return nil
}

func (e *DeviceCenter) TracerSetFreqSpectrum(ctx context.Context, req *client.FreqSpectrumSetReq, rsp *client.FreqSpectrumSetResp) error {
	logger.Infof("----> TracerSetFreqSpectrum, req: %+v", req)

	dev := FindCacheDevice(req.GetSn(), common.DEV_V2DRONEID)
	if dev == nil {
		return errors.New("device is offline")
	}

	d := &DroneID{Device: dev}
	if err := d.SetFreqSpectrum(req); err != nil {
		logger.Errorf("process err: %v", err)
		rsp.Status = Fail
	} else {
		rsp.Status = Success
	}
	logger.Infof("---->End TracerSetFreqSpectrum, rsp: %+v", rsp)
	return nil
}

func (e *DeviceCenter) TracerGetFreqSpectrum(ctx context.Context, req *client.FreqSpectrumGetReq, rsp *client.FreqSpectrumGetResp) error {
	logger.Infof("----> TracerGetFreqSpectrum, req: %+v", req)

	dev := FindCacheDevice(req.GetSn(), common.DEV_V2DRONEID)
	if dev == nil {
		return errors.New("device is offline")
	}

	d := &DroneID{Device: dev}
	data, err := d.GetFreqSpectrum()
	if err != nil {
		logger.Errorf("TracerGetFreqSpectrum err: %v", err)
		return err
	}

	rsp.DetectTarget = data.DetectTarget
	rsp.AnalogDetectBand = data.AnalogDetectBand
	rsp.DetectSensitivity = data.DetectSensitivity
	rsp.CustomLib = data.CustomLib
	rsp.PreciseStrike = data.PreciseStrike
	rsp.DirectionalDetection = data.DirectionalDetection
	logger.Infof("---->End TracerGetFreqSpectrum, rsp: %+v", rsp)
	return nil
}

func (e *DeviceCenter) TracerSetInvalidFreqRange(ctx context.Context, req *client.SetInvalidFreqRangeReq, rsp *client.SetInvalidFreqRangeRsp) error {
	logger.Infof("----> TracerSetInvalidFreqRange, req: %+v", req)

	dev := FindCacheDevice(req.GetSn(), common.DEV_V2DRONEID)
	if dev == nil {
		return errors.New("device is offline")
	}

	d := &DroneID{Device: dev}
	if err := d.SetInvalidFreqRange(req); err != nil {
		logger.Errorf("process err: %v", err)
		rsp.Status = Fail
	} else {
		rsp.Status = Success
	}
	logger.Infof("---->End TracerSetFreqSpectrum, rsp: %+v", rsp)
	return nil
}
func (e *DeviceCenter) TracerGetInvalidFreqRange(ctx context.Context, req *client.GetInvalidFreqRangeReq, rsp *client.GetInvalidFreqRangeRsp) error {
	logger.Infof("----> TracerGetInvalidFreqRange, req: %+v", req)

	dev := FindCacheDevice(req.GetSn(), common.DEV_V2DRONEID)
	if dev == nil {
		return errors.New("device is offline")
	}

	d := &DroneID{Device: dev}
	data, err := d.GetInvalidFreqRange()
	if err != nil || data == nil {
		logger.Errorf("TracerGetInvalidFreqRange err: %v", err)
		return err
	}

	rsp.List = data.List
	logger.Infof("---->End TracerGetInvalidFreqRange, rsp: %+v", rsp)
	return nil
}

func (e *DeviceCenter) TracerSetProtocolParseParam(ctx context.Context, req *client.SetProtocolParseParamReq, rsp *client.SetProtocolParseParamRsp) error {
	logger.Infof("----> TracerSetProtocolParseParam, req: %+v", req)
	dev := FindCacheDevice(req.GetSn(), common.DEV_V2DRONEID)
	if dev == nil {
		return errors.New("device is offline")
	}

	d := &DroneID{Device: dev}
	err := d.SetProtocolParseParam(req)
	if err != nil {
		rsp.Status = Fail
		logger.Errorf("TracerSetProtocolParseParam err: %v", err)
		return err
	}
	rsp.Status = Success
	logger.Infof("---->End TracerGetInvalidFreqRange, rsp: %+v", rsp)
	return nil
}

func (e *DeviceCenter) TracerGetProtocolParseParam(ctx context.Context, req *client.GetProtocolParseParamReq, rsp *client.GetProtocolParseParamRsp) error {
	logger.Infof("----> TracerGetProtocolParseParam, req: %+v", req)
	dev := FindCacheDevice(req.GetSn(), common.DEV_V2DRONEID)
	if dev == nil {
		return errors.New("device is offline")
	}

	d := &DroneID{Device: dev}
	data, err := d.GetProtocolParseParam()
	if err != nil || data == nil {
		logger.Errorf("TracerGetProtocolParseParam err: %v", err)
		return err
	}
	rsp.ItemNum = data.ItemNum
	rsp.Params = data.Params
	logger.Infof("---->End TracerGetProtocolParseParam, rsp: %+v", rsp)
	return nil
}

// Sfl101GetVersionInfo Sfl101获取版本信息
func (e *DeviceCenter) Sfl101GetVersionInfo(ctx context.Context, req *client.Sfl101GetVersionRequest, rsp *client.Sfl101GetVersionResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL101)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Sfl101{Device: dev}
	version, err := d.SendGetVersionInfo(req.Sn)
	if err != nil {
		return err
	}
	listInfo := &client.EquipListRes{}
	if err := NewEquipList().List(ctx, nil, listInfo); err == nil {
		for _, v := range listInfo.Equips {
			if v == nil {
				continue
			}
			if v.GetSn() == req.Sn {
				rsp.Ip = v.GetIp()
				break
			}
		}
	}

	rsp.Sn = req.Sn
	rsp.Version = version
	return nil
}

// Sfl101StopHitSet 发送停止打击消息
func (e *DeviceCenter) Sfl101StopHitSet(ctx context.Context, req *client.Sfl101StopHitRequest, rsp *client.Sfl101StopHitResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL101)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Sfl101{Device: dev}
	status, err := d.SendSfl101StopHitReq()
	if err != nil {
		return err
	}
	rsp.Status = int32(status)
	if status == 0 {
		rsp.Status = 2
	}
	return nil
}

// Sfl101GNSSSet ...
func (e *DeviceCenter) Sfl101GNSSSet(ctx context.Context, req *client.Sfl101SetGNSSRequest, rsp *client.Sfl101SetGNSSResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL101)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Sfl101{Device: dev}
	status, err := d.Sfl101GNSSSetReq(req)
	if err != nil {
		logger.Debug("err = ", err)
		return err
	}
	rsp.Status = int32(status)
	if status == 0 {
		rsp.Status = 2
	}
	return nil
}

// Sfl101GNSSGet ...
func (e *DeviceCenter) Sfl101GNSSGet(ctx context.Context, req *client.Sfl101GetGNSSRequest, rsp *client.Sfl101GetGNSSResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL101)
	if dev == nil {
		return errors.New("设备未在线")
	}
	logger.Debug("req = ", req)
	logger.Debug("req sn = ", req.Sn)
	logger.Debug("dev = ", dev)
	d := &Sfl101{Device: dev}
	status, err := d.Sfl101GNSSGetReq()
	if err != nil {
		return err
	}
	fmt.Println("status = ", status)
	// GunLatitudeTion        = 1e7
	toFloat := 1e7
	// float64(heartInfo.Info.GunLatitude) / GunLatitudeTion
	rsp.Altitude = status.Altitude
	rsp.Latitude = float64(status.Latitude) / toFloat
	rsp.Longitude = float64(status.Longitude) / toFloat
	rsp.Type = uint32(status.Type)
	return nil
}

// Sfl101HitAngleSet 发送打击点信息配置
func (e *DeviceCenter) Sfl101HitAngleSet(ctx context.Context, req *client.Sfl101HitAngleRequest, rsp *client.Sfl101HitAngleResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL101)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Sfl101{Device: dev}

	status, err := d.SendSfl101HitAngleSet(req)
	if err != nil {
		return err
	}
	rsp.Status = int32(status)
	if status == 0 {
		rsp.Status = 2
	}

	return nil
}

// Sfl101OnOffSet 发送开关机
func (e *DeviceCenter) Sfl101OnOffSet(ctx context.Context, req *client.Sfl101OnOffRequest, rsp *client.Sfl101OnOffResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL101)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Sfl101{Device: dev}

	status, err := d.SendSfl101OnOffSet(req)
	if err != nil {
		return err
	}
	rsp.Status = int32(status)
	if status == 0 {
		rsp.Status = 2
	}

	return nil
}

// Sfl101DetectInfo 侦测信息查询
func (e *DeviceCenter) Sfl101DetectInfo(ctx context.Context, req *client.Sfl101DetectInfoRequest, rsp *client.Sfl101DetectInfoResponse) error {
	//查数据库
	var result *client.Sfl101DetectInfoResponse
	var err error
	if req.FindKey == "" {
		result, err = FindSfl101DetectInfo(req)
		if err != nil {
			return err
		}
	} else {
		result, err = FindSfl101DetectInfoByKey(req)
		if err != nil {
			return err
		}
	}

	rsp.List = result.List
	rsp.DetectNum = result.DetectNum
	rsp.HitNum = result.HitNum
	return nil
}

// Sfl101DetectInfoExport  侦测信息导出
func (e *DeviceCenter) Sfl101DetectInfoExport(ctx context.Context, req *client.Sfl101DetectInfoExportRequest, rsp *client.Sfl101DetectInfoExportResponse) error {
	//查数据库
	result, err := FindSfl101DetectExportInfo(ctx, req)
	//result, err := FindSfl101DetectExportInfoV2(ctx, req)
	if err != nil {
		return err
	}
	rsp.Status = int32(result)
	return nil
}

// Sfl101ReSet 发送复位
func (e *DeviceCenter) Sfl101ReSet(ctx context.Context, req *client.Sfl101ResetRequest, rsp *client.Sfl101ResetResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL101)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Sfl101{Device: dev}

	status, err := d.SendSfl101Reset()
	if err != nil {
		return err
	}
	rsp.Status = int32(status)
	if status == 0 {
		rsp.Status = 2
	}
	logger.Info("Sfl101 Reset rsp", rsp.Status)
	return nil
}

// Sfl101SendHitUav 手动选择打击无人机
func (e *DeviceCenter) Sfl101SendHitUav(ctx context.Context, req *client.Sfl101SendHitUavRequest, rsp *client.Sfl101SendHitUavResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL101)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Sfl101{Device: dev}

	status, err := d.SendSfl101HitUav(req)
	if err != nil {
		return err
	}
	rsp.Status = int32(status)
	if status == 0 {
		rsp.Status = -1
	}
	logger.Info("Sfl101 Reset rsp", rsp.Status)
	return nil
}

// Sfl101GetStatus 发送获取状态
func (e *DeviceCenter) Sfl101GetStatus(ctx context.Context, req *client.Sfl101GetStatusRequest, rsp *client.Sfl101GetStatusResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL101)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Sfl101{Device: dev}

	result, err := d.SendSfl101GetStatus()
	if err != nil {
		return err
	}
	rsp.Sn = req.Sn
	rsp.HitAngleEnd = result.HitAngleEnd
	rsp.HitAngleBegin = result.HitAngleBegin
	rsp.HitMode = result.HitMode
	rsp.HitPitch1 = result.HitPitch1
	rsp.HitPitch2 = result.HitPitch2
	rsp.HitTime = result.HitTime

	return nil
}

// Sfl101GetPower 发送获取开关机
func (e *DeviceCenter) Sfl101GetPower(ctx context.Context, req *client.Sfl101GetPowerRequest, rsp *client.Sfl101GetPowerResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL101)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Sfl101{Device: dev}

	result, status, err := d.SendSfl101GetPower()
	if err != nil {
		return err
	}
	rsp.PowerStatus = int32(result)
	rsp.Status = int32(status)
	if status == 0 {
		rsp.Status = 2
	}
	return nil
}

// Sfl101SetHitMode 发送设置工作模式
func (e *DeviceCenter) Sfl101SetHitMode(ctx context.Context, req *client.Sfl101SetHitModeRequest, rsp *client.Sfl101SetHitModeResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL101)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Sfl101{Device: dev}

	status, err := d.SendSfl101SetHitMode(req.HitMode)
	if err != nil {
		return err
	}
	rsp.Status = int32(status)
	if status == 0 {
		rsp.Status = 2
	}
	return nil
}

// Sfl101GetHitMode 发送获取工作模式
func (e *DeviceCenter) Sfl101GetHitMode(ctx context.Context, req *client.Sfl101GetHitModeRequest, rsp *client.Sfl101GetHitModeResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL101)
	if dev == nil {
		return errors.New("设备未在线")
	}

	d := &Sfl101{Device: dev}

	result, err := d.SendSfl101GetHitMode()
	if err != nil {
		return err
	}
	rsp.Status = int32(result)
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// 启动/停止打击
func (e *DeviceCenter) Sfl101TurnHit(ctx context.Context, req *client.Sfl101TurnHitRequest, rsp *client.Sfl101TurnHitResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL101)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &Sfl101{Device: dev}

	result, err := d.SendSfl101TurnHit(req.StartStop)
	if err != nil {
		return err
	}
	rsp.Status = int32(result)
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// 水平方向转动
func (e *DeviceCenter) Sfl101HorizontalTurn(ctx context.Context, req *client.Sfl101HorizontalTurnRequest, rsp *client.Sfl101HorizontalTurnResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL101)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &Sfl101{Device: dev}

	result, err := d.SendSfl101HorizontalTurn(req)
	if err != nil {
		return err
	}
	rsp.Status = int32(result)
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// 垂直方向转动
func (e *DeviceCenter) Sfl101VerticalTurn(ctx context.Context, req *client.Sfl101VerticalTurnRequest, rsp *client.Sfl101VerticalTurnResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL101)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &Sfl101{Device: dev}

	result, err := d.SendSfl101VerticalTurn(req)
	if err != nil {
		return err
	}
	rsp.Status = int32(result)
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// Sfl101CrashStop 哨兵塔急停
func (e *DeviceCenter) Sfl101CrashStop(ctx context.Context, req *client.Sfl101CrashStopRequest, rsp *client.Sfl101CrashStopResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL101)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &Sfl101{Device: dev}

	result, err := d.SendSfl101CrashStop()
	if err != nil {
		return err
	}
	rsp.Status = int32(result)
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// Sfl101SetPreciseHit 设置精准打击特性
func (e *DeviceCenter) Sfl101SetPreciseHit(ctx context.Context, req *client.Sfl101SetPreciseHitRequest, rsp *client.Sfl101SetPreciseHitResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL101)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &Sfl101{Device: dev}

	result, err := d.Sfl101SetPreciseHit(req)
	if err != nil {
		return err
	}
	rsp.Status = int32(result)
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// Sfl101GetPreciseHit 获取精准打击特性
func (e *DeviceCenter) Sfl101GetPreciseHit(ctx context.Context, req *client.Sfl101GetPreciseHitRequest, rsp *client.Sfl101GetPreciseHitResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL101)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &Sfl101{Device: dev}

	result, err := d.Sfl101GetPreciseHit()
	if err != nil {
		return err
	}
	rsp.Enable = int32(result)
	return nil
}

// Sfl101SetInvalidFreq 设置无效无人机频点
func (e *DeviceCenter) Sfl101SetInvalidFreq(ctx context.Context, req *client.Sfl101SetInvalidFreqRequest, rsp *client.Sfl101SetInvalidFreqResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL101)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &Sfl101{Device: dev}

	result, err := d.Sfl101SetInvalidFreq(req)
	if err != nil {
		return err
	}
	rsp.Status = int32(result)
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// Sfl101GetInvalidFreq 获取无效无人机频点
func (e *DeviceCenter) Sfl101GetInvalidFreq(ctx context.Context, req *client.Sfl101GetInvalidFreqRequest, rsp *client.Sfl101GetInvalidFreqResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL101)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &Sfl101{Device: dev}

	freqList, err := d.Sfl101GetInvalidFreq()
	if err != nil {
		return err
	}
	rsp.FreqList = freqList
	logger.Info("---->End Sfl101GetInvalidFreq,rsp:", rsp)
	return nil
}

// Sfl101SetHitRadius 设置打击半径
func (e *DeviceCenter) Sfl101SetHitRadius(ctx context.Context, req *client.Sfl101SetAutoHitRadiusRequest, rsp *client.Sfl101SetAutoHitRadiusResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL101)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &Sfl101{Device: dev}

	result, err := d.SendSfl101SetHitRadius(req)
	if err != nil {
		return err
	}
	rsp.Status = int32(result)
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// Sfl101GetHitRadius 获取打击半径
func (e *DeviceCenter) Sfl101GetHitRadius(ctx context.Context, req *client.Sfl101GetAutoHitRadiusRequest, rsp *client.Sfl101GetAutoHitRadiusResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL101)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &Sfl101{Device: dev}

	result, err := d.SendSfl101GetHitRadius(req)
	if err != nil {
		return err
	}
	rsp.Radius = int32(result)
	return nil
}

// Sfl101SetSwitchParameter 设置开关参数
func (e *DeviceCenter) Sfl101SetSwitchParameter(ctx context.Context, req *client.Sfl101SetSwitchParameterRequest, rsp *client.Sfl101SetSwitchParameterResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL101)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &Sfl101{Device: dev}

	result, err := d.Sfl101SetSwitchParameter(req)
	if err != nil {
		return err
	}
	rsp.Status = int32(result)
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// Sfl101GetSwitchParameter 获取开关参数
func (e *DeviceCenter) Sfl101GetSwitchParameter(ctx context.Context, req *client.Sfl101GetSwitchParameterRequest, rsp *client.Sfl101GetSwitchParameterResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL101)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &Sfl101{Device: dev}

	result, err := d.Sfl101GetSwitchParameter(req)
	if err != nil {
		return err
	}
	response := make([]*client.Sfl101SwitchParameter, 0)
	for _, parameter := range result {
		response = append(response, &client.Sfl101SwitchParameter{
			Type:   parameter.Type,
			Enable: parameter.Enable,
		})
	}
	rsp.SwitchParameter = response
	return nil
}

// Sfl101SetNoise 哨兵塔设置噪声
func (e *DeviceCenter) Sfl101SetNoise(ctx context.Context, req *client.Sfl101SetNoiseRequest, rsp *client.Sfl101SetNoiseResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL101)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &Sfl101{Device: dev}

	result, err := d.SendSfl101SetNoise(req)
	if err != nil {
		return err
	}
	rsp.Status = int32(result)
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// Sfl101SetFreqCmd 哨兵塔设置频点采集指令
func (e *DeviceCenter) Sfl101SetFreqCmd(ctx context.Context, req *client.Sfl101SetFreqCmdRequest, rsp *client.Sfl101SetFreqCmdResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL101)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &Sfl101{Device: dev}

	result, err := d.SendSfl101SetFreqCmd(req.GetSn(), req.GetOp(), req.GetFileName())
	if err != nil {
		return err
	}
	rsp.Status = result
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// Sfl101GetFreqNodeList 获取频点列表
func (e *DeviceCenter) Sfl101GetFreqNodeList(ctx context.Context, req *client.Sfl101GetFreqListRequest, rsp *client.Sfl101GetFreqListResponse) error {

	rsp.Status = 1
	logger.Info("---->Into Sfl101GetFreqNodeList,sn:", req.Sn, req)
	dev := FindCacheDevice(req.Sn, common.DEV_SFL101)
	if dev == nil {
		rsp.Status = 2
		return errors.New("设备未在线")
	}

	d := &Sfl101{Device: dev}
	freqNodeList, err := d.SendSfl101GetFreqNodeList()
	if err != nil {
		logger.Info("---->Send Sfl101GetFreqNodeList err:", err)
		rsp.Status = 2
		return err
	}
	rsp.FreqList = freqNodeList
	logger.Info("---->End Sfl101GetFreqNodeList,rsp:", rsp)
	return nil
}

// Sfl101HitModeSet 发送打击模式配置
func (e *DeviceCenter) Sfl101HitModeSet(ctx context.Context, req *client.Sfl101HitModeRequest, rsp *client.Sfl101HitModeResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL101)
	if dev == nil {
		return errors.New("设备未在线")
	}
	d := &Sfl101{Device: dev}
	status, err := d.SendSfl101HitModeSet(req)
	if err != nil {
		return err
	}
	rsp.Status = int32(status)
	if status == 0 {
		rsp.Status = 2
	}
	return nil
}

// Sfl101SetPosture 设置标定设备姿态
func (e *DeviceCenter) Sfl101SetPosture(ctx context.Context, req *client.Sfl101SetPostureRequest, rsp *client.Sfl101SetPostureResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL101)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &Sfl101{Device: dev}

	result, err := d.SendSfl101SetPosture(req)
	if err != nil {
		return err
	}
	rsp.Status = int32(result)
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// Sfl101GetPosture 获取标定设备姿态
func (e *DeviceCenter) Sfl101GetPosture(ctx context.Context, req *client.Sfl101GetPostureRequest, rsp *client.Sfl101GetPostureResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL101)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &Sfl101{Device: dev}

	result, err := d.SendSfl101GetPosture(req)
	if err != nil {
		return err
	}
	rsp.Set = result.Set
	rsp.Pitch = result.Pitch
	rsp.Raw = result.Raw
	return nil
}

// SvhStartStopHit Svh开始停止打击
func (e *DeviceCenter) SvhStartStopHit(ctx context.Context, req *client.StartStopHitRequest, rsp *client.StartStopHitResponse) error {
	if req.IsStart { //开启打击     先关tracer 再开打击
		if req.TracerSn != "" {
			dev := FindCacheDevice(req.TracerSn, common.DEV_V2DRONEID)
			if dev == nil {
				return errors.New("设备未在线")
			}

			d := &DroneID{Device: dev}

			result := d.SetRadioFreq(int32(0))
			logger.Info("SetRadioFreq result:", result)
			if result == 0 {
				rsp.Status = 2
				return errors.New("result is 0")
			}
		}

		devSvh := FindCacheDevice(req.Sn, common.DEV_SVH)
		if devSvh == nil {
			return errors.New("devSvh is offline")
		}

		svh := &Svh{Device: devSvh}

		hit := 1
		stop := 0
		result1, err := svh.SvhStartStopHit(req, hit, stop)
		if err != nil {
			logger.Error("result1 is :", result1)
			return err
		}
		rsp.Status = int32(result1)
		if result1 == 0 {
			rsp.Status = 2
		}
		return nil

	} else { //关闭打击  先关打击、再开侦测
		devSvh := FindCacheDevice(req.Sn, common.DEV_SVH)
		if devSvh == nil {
			return errors.New("devSvh is offline")
		}

		svh := &Svh{Device: devSvh}

		hit := 0
		stop := 1
		result1, err := svh.SvhStartStopHit(req, hit, stop)
		if err != nil {
			logger.Error("result1 is :", result1)
			return err
		}
		rsp.Status = int32(result1)
		if result1 == 0 {
			rsp.Status = 2
			return errors.New("close svh err rsp 2")
		}

		if req.TracerSn != "" {
			dev := FindCacheDevice(req.TracerSn, common.DEV_V2DRONEID)
			if dev == nil {
				return errors.New("设备未在线")
			}

			d := &DroneID{Device: dev}

			result := d.SetRadioFreq(int32(1))
			logger.Info("SetRadioFreq result:", result)
			rsp.Status = result
			if result == 0 {
				rsp.Status = 2
				return errors.New("result is 0")
			}
		}

	}
	return nil
}

// GetFreqConfig Svh 获取频段设置
func (e *DeviceCenter) SvhGetFreqConfig(ctx context.Context, req *client.SvhGetFreqConfigRequest, rsp *client.SvhGetFreqConfigResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SVH)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &Svh{Device: dev}

	result, err := d.SendSvhGetFreqConfig(req)
	if err != nil {
		return err
	}
	rsp.FreqList1 = result.FreqList1
	rsp.FreqList2 = result.FreqList2
	rsp.GroupNum = result.GroupNum
	rsp.GroupNum2 = result.GroupNum2
	return nil
}

// SvhGetFreqConfig 频段设置
func (e *DeviceCenter) SvhSetFreqConfig(ctx context.Context, req *client.SvhSetFreqConfigRequest, rsp *client.SvhSetFreqConfigResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SVH)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &Svh{Device: dev}

	result, err := d.SendSvhSetFreqConfig(req)
	if err != nil {
		return err
	}
	rsp.Status = uint32(result)
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// SvhAddDelFreqConfig 增加删除频段设置
func (e *DeviceCenter) SvhAddDelFreqConfig(ctx context.Context, req *client.SvhAddDelFreqConfigRequest, rsp *client.SvhAddDelFreqConfigResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SVH)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &Svh{Device: dev}

	result, err := d.SendSvhAddDelFreqConfig(req)
	if err != nil {
		return err
	}
	rsp.Status = uint32(result)
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// SvhResetFreqConfig 重置频段设置
func (e *DeviceCenter) SvhResetFreqConfig(ctx context.Context, req *client.SvhResetFreqConfigRequest, rsp *client.SvhResetFreqConfigResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SVH)
	if dev == nil {
		return errors.New("dev is offline")
	}

	d := &Svh{Device: dev}

	result, err := d.SendSvhResetFreqConfig(req)
	if err != nil {
		return err
	}
	rsp.Status = uint32(result)
	if result == 0 {
		rsp.Status = 2
	}
	return nil
}

// SvhGetVersionInfo ...
func (e *DeviceCenter) SvhGetVersionInfo(ctx context.Context, req *client.SvhGetVersionRequest, rsp *client.SvhGetVersionResponse) error {
	logger.Info(" :", req)
	dev := FindCacheDevice(req.Sn, common.DEV_SVH)
	if dev == nil {
		return errors.New("设备未在线")
	}
	d := &Svh{Device: dev}
	result, err := d.SendSvhGetVersionInfo(req)
	if err != nil {
		logger.Error("Send SvhGetVersionInfo err:", err)
		return err
	}
	rsp.Sn = result.Sn
	rsp.Company = result.Company
	rsp.Ip = result.Ip
	rsp.PlVersion = result.PlVersion
	rsp.PsVersion = result.PsVersion
	rsp.DeviceName = result.DeviceName
	logger.Debug("result = ", result)
	return nil
}

// GetOnLineDev 获取在线设备节点
func GetOnLineDev[T DeviceIfer](sn string, devType int32) (T, error) {
	d, err := buildDevice[T](sn, devType)
	dev, _ := d.(T)
	if err != nil {
		return dev, err
	}
	return dev, nil
}

// buildDevice 根据设备类型获取在线设备节点; 返回设备的一个接口，每种设备要实现 DeviceIfer 接口的  SetDevice(*Device) 方法。
func buildDevice[D DeviceIfer](sn string, devType int32) (DeviceIfer, error) {
	dev := FindCacheDevice(sn, common.DeviceType(devType))
	if dev == nil {
		return nil, fmt.Errorf("device is offline, dev sn: %v", sn)
	}
	var m1 D
	if reflect.TypeOf(m1).Kind() == reflect.Ptr {
		msg := reflect.New(reflect.TypeOf(m1).Elem())
		x := msg.Interface().(DeviceIfer)
		x.SetDevice(dev)
		return x, nil
	} else {
		msg := reflect.New(reflect.TypeOf(m1))
		x := msg.Interface().(DeviceIfer)
		x.SetDevice(dev)
		return x, nil
	}
}

// SFLNoiseFloorSet sfl设置采集频点
func (e *DeviceCenter) SFLNoiseFloorSet(ctx context.Context, req *client.SFLNoiseSet, resp *client.SFLNoiseFloorSetResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_SFL)
	if dev == nil {
		resp.Result = Fail
		return errors.New("设备未在线")
	}

	d := &Sfl{Device: dev}
	sendReq := &client.SflSetNoiseRequest{
		Sn: req.Sn,
	}
	res, err := d.SendSflSetNoise(sendReq)
	if err != nil {
		resp.Result = Fail
		logger.Errorf("SFLNoiseFloorSet error: %s", err.Error())
		return err
	}
	resp.Result = int32(res)
	if res == 0 {
		resp.Result = 2
	}

	return nil
}

// TracerNoiseFloorSet tracer设置采集频点
func (e *DeviceCenter) TracerNoiseFloorSet(ctx context.Context, req *client.TracerNoiseSet, resp *client.TracerNoiseFloorSetResponse) error {
	dev := FindCacheDevice(req.Sn, common.DEV_V2DRONEID)
	if dev == nil {
		resp.Result = Fail
		return errors.New("设备未在线")
	}

	d := &DroneID{Device: dev}
	res, err := d.SendSetTracerNoiseFloorV2(req)
	if err != nil {
		resp.Result = Fail
		logger.Errorf("TracerNoiseFloorSet error: %s", err.Error())
		return err
	}
	resp.Result = int32(res)
	if res == 0 {
		resp.Result = 2
	}

	return nil
}

func (e *DeviceCenter) Stp120OnSwitch(ctx context.Context, req *client.Stp120OnOffRequest, rsp *client.Stp120OnOffResponse) error {
	rsp.Status = 1
	d, err := GetOnLineDev[*STP120](req.GetSn(), common.DEV_STP120)
	if err != nil {
		logger.Errorf("err: %v, dev: %v", err, req.GetSn())
		rsp.Status = 2
		return nil
	}

	if err := d.SwitchOn(ctx, req.Switch); err != nil {
		logger.Errorf("send switch to device err: %v", err)
		rsp.Status = 2
	}
	return nil
}

func (e *DeviceCenter) Stp120Reboot(ctx context.Context, req *client.Stp120RebootRequest, rsp *client.Stp120RebootResponse) error {
	rsp.Status = 1
	d, err := GetOnLineDev[*STP120](req.GetSn(), common.DEV_STP120)
	if err != nil {
		logger.Errorf("err: %v, dev: %v", err, req.GetSn())
		rsp.Status = 2
		return nil
	}
	if req.Switch != 0 {
		logger.Errorf("req reboot parameter value is not 1")
		return fmt.Errorf("wrong reboot parameter: %v", req.GetSwitch())
	}

	if err := d.Reboot(ctx, req.Switch); err != nil {
		logger.Errorf("send reboot to device err: %v", err)
		rsp.Status = 2
	}
	return nil
}
func (e *DeviceCenter) GetGNSS(ctx context.Context, req *client.Stp120GetGNSSRequest, rsp *client.Stp120GetGNSSResponse) error {
	d, err := GetOnLineDev[*STP120](req.GetSn(), common.DEV_STP120)
	if err != nil {
		logger.Errorf("err: %v, dev: %v", err, req.GetSn())
		return nil
	}

	if ret, err := d.GetGNSS(ctx); err != nil {
		logger.Errorf("send get gnss to device err: %v", err)
		return err
	} else {
		toFloat := 1e7
		rsp.Altitude = ret.Altitude
		rsp.Latitude = float64(ret.Latitude) / toFloat
		rsp.Longitude = float64(ret.Longitude) / toFloat
		rsp.Type = uint32(ret.Type)
	}
	return nil
}
func (e *DeviceCenter) SetGNSS(ctx context.Context, req *client.Stp120SetGNSSRequest, rsp *client.Stp120SetGNSSResponse) error {
	rsp.Status = 1
	//
	d, err := GetOnLineDev[*STP120](req.GetSn(), common.DEV_STP120)
	if err != nil {
		logger.Errorf("err: %v, dev: %v", err, req.GetSn())
		return nil
	}

	if err := d.SetGNSS(ctx, req); err != nil {
		logger.Errorf("send switch to device err: %v", err)
		rsp.Status = 2
		return nil
	}
	return nil
}

func (e *DeviceCenter) Stp120GetVersion(ctx context.Context, req *client.Stp120GetVersionRequest, rsp *client.Stp120GetVersionResponse) error {
	var err error
	var version string

	d, err := GetOnLineDev[*STP120](req.GetSn(), common.DEV_STP120)
	if err != nil {
		logger.Errorf("err: %v, dev: %v", err, req.GetSn())
		return err
	}

	version, err = d.GetVersion(ctx, req.GetSn())
	if err != nil {
		logger.Errorf("send get gnss to device err: %v", err)
		return err
	}
	listInfo := &client.EquipListRes{}
	if err := NewEquipList().List(ctx, nil, listInfo); err == nil {
		for _, v := range listInfo.Equips {
			if v == nil {
				continue
			}
			if v.GetSn() == req.Sn {
				rsp.Ip = v.GetIp()
				break
			}
		}
	}
	rsp.Sn = req.Sn
	rsp.Version = version
	return nil
}
func (e *DeviceCenter) GetDetectFreqNodeList(ctx context.Context, req *client.GetFreqListRequest, rsp *client.GetFreqListResponse) error {
	rsp.Status = 1

	if req.GetOp() != 1 {
		logger.Errorf("not get op value")
		rsp.Status = 2
		return nil
	}

	switch common.DeviceType(req.GetDevType()) {
	case common.DEV_STP120:
		d, err := GetOnLineDev[*STP120](req.GetSn(), common.DEV_STP120)
		if err != nil {
			logger.Errorf("err: %v, dev: %v", err, req.GetSn())
			rsp.Status = 2
			return nil
		}

		if nodeList, err := d.GetFreqNodeList(uint8(0)); err != nil {
			logger.Errorf("send reboot to device err: %v", err)
			rsp.Status = 2
		} else {
			rsp.FreqList = nodeList
		}
	case common.DEV_SFL:
		d, err := GetOnLineDev[*Sfl](req.GetSn(), int32(common.DEV_SFL))
		if err != nil {
			logger.Errorf("err: %v, dev: %v", err, req.GetSn())
			rsp.Status = 2
			return nil
		}
		if nodeList, err := d.SendSflGetFreqNodeList(); err != nil {
			logger.Errorf("send reboot to device err: %v", err)
			rsp.Status = 2
		} else {
			rsp.FreqList = nodeList
		}

	default:
		logger.Errorf("not implement dev type logic: %v", req.GetDevType())
		rsp.Status = 2
		return nil
	}
	return nil
}
func (e *DeviceCenter) SetFreqCmd(ctx context.Context, req *client.DeviceSetFreqCmdRequest, rsp *client.DeviceSetFreqCmdResponse) error {
	rsp.Status = 1

	switch common.DeviceType(req.GetDevType()) {
	case common.DEV_STP120:
		d, err := GetOnLineDev[*STP120](req.GetSn(), common.DEV_STP120)
		if err != nil {
			logger.Errorf("err: %v, dev: %v", err, req.GetSn())
			rsp.Status = 2
			return nil
		}

		if err := d.SetFreqCmd(req); err != nil {
			logger.Errorf("send set freq cmd to device err: %v", err)
			rsp.Status = 2
		}
	case common.DEV_SFL:
		d, err := GetOnLineDev[*Sfl](req.GetSn(), int32(common.DEV_SFL))
		if err != nil {
			logger.Errorf("err: %v, dev: %v", err, req.GetSn())
			rsp.Status = 2
			return nil
		}
		req := &client.SflSetNoiseRequest{
			Sn:   req.GetSn(),
			Mode: req.GetMode(),
			Freq: req.GetFreq(),
		}
		if status, err := d.SendSflSetNoise(req); err == nil {
			rsp.Status = int32(status)
		} else {
			rsp.Status = 2
		}
		return nil

	default:
		logger.Errorf("not implement dev type logic: %v", req.GetDevType())
		rsp.Status = 2
		return nil
	}
	return nil
}

func (e *DeviceCenter) PerformanceEvaluate(ctx context.Context, req *client.EnvBaseNoiseRequest, rsp *client.EnvBaseNoiseResponse) error {
	rsp.Status = 1
	if req.Op != 1 && req.Op != 2 {
		logger.Errorf("input param is not valid, %v", req.GetOp())
		rsp.Status = 2
		return nil
	}

	switch req.GetDevType() {
	case common.DEV_STP120:
		d, err := GetOnLineDev[*STP120](req.GetSn(), common.DEV_STP120)
		if err != nil {
			logger.Errorf("err: %v, dev: %v", err, req.GetSn())
			rsp.Status = 2
			return nil
		}

		if err := d.PerformanceEvaluate(ctx, req); err != nil {
			logger.Errorf("send performance evaluate to device err: %v", err)
			rsp.Status = 2
			return nil
		}
	case int32(common.DEV_SFL):
		d, err := GetOnLineDev[*Sfl](req.GetSn(), int32(common.DEV_SFL))
		if err != nil {
			logger.Errorf("err: %v, dev: %v", err, req.GetSn())
			rsp.Status = 2
			return nil
		}
		if err := d.PerformanceEvaluate(ctx, req); err != nil {
			logger.Errorf("send performance evaluate to device err: %v", err)
			rsp.Status = 2
			return nil
		}

	default:
		logger.Errorf("not support dev type: %v", req.GetDevType())
		rsp.Status = 2
		return nil
	}
	return nil
}

func (e *DeviceCenter) PerformanceEvaluateSet(ctx context.Context, req *client.PerformanceEvaluateReferenceRequest, rsp *client.PerformanceEvaluateReferenceResponse) error {
	rsp.Status = 1
	if req.Op != 1 && req.Op != 2 {
		logger.Errorf("input param is not valid, %v", req.GetOp())
		rsp.Status = 2
		return nil
	}

	switch req.GetDevType() {
	case common.DEV_STP120:
		d, err := GetOnLineDev[*STP120](req.GetSn(), common.DEV_STP120)
		if err != nil {
			logger.Errorf("err: %v, dev: %v", err, req.GetSn())
			return nil
		}

		if err := d.ReferencePerformanceEvaluate(ctx, req); err != nil {
			logger.Errorf("send performance evaluate to device err: %v", err)
			rsp.Status = 2
			return nil
		}

	case int32(common.DEV_SFL):
		d, err := GetOnLineDev[*Sfl](req.GetSn(), int32(common.DEV_SFL))
		if err != nil {
			logger.Errorf("err: %v, dev: %v", err, req.GetSn())
			return nil
		}

		if err := d.ReferencePerformanceEvaluate(ctx, req); err != nil {
			logger.Errorf("send performance evaluate to device err: %v", err)
			rsp.Status = 2
			return nil
		}
	default:
		logger.Errorf("not support dev type: %v", req.GetDevType())
		rsp.Status = 2
		return nil
	}
	return nil
}

func (e *DeviceCenter) BoardFunctionStart(ctx context.Context, req *client.StartSwitchOnRequestBatchReq, rsp *client.StartSwitchOnRequestBatchResponse) error {
	wg := threading.NewRoutineGroupWrap()
	if req.GetFreqCmdSetReport() != nil {
		wg.Run(func() {
			response := &client.DeviceSetFreqCmdResponse{}
			_ = NewDeviceCenter().SetFreqCmd(ctx, req.GetFreqCmdSetReport(), response)
			rsp.FreqCmdSetReportResponse = response
		})
	}
	if req.GetPerformanceEvaluateStart() != nil {
		wg.Run(func() {
			response := &client.EnvBaseNoiseResponse{}
			_ = NewDeviceCenter().PerformanceEvaluate(ctx, req.GetPerformanceEvaluateStart(), response)
			rsp.PerformanceEvaluateResponse = response
		})
	}

	if req.GetPerformanceEvaluateRefSet() != nil {
		wg.Run(func() {
			response := &client.PerformanceEvaluateReferenceResponse{}
			_ = NewDeviceCenter().PerformanceEvaluateSet(ctx, req.GetPerformanceEvaluateRefSet(), response)
			rsp.PerformanceEvaluateRefSetResponse = response
		})
	}

	wg.Wait()
	return nil
}

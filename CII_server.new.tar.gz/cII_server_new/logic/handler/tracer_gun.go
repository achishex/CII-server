package handler

import (
	"bytes"
	"context"
	"crypto/rand"
	"encoding/binary"
	"errors"
	"fmt"
	"math/big"
	"strings"
	"sync"
	"time"

	"adasgitlab.autel.com/tools/cuav_plugin/broker"
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/slink_proto/slinkv1"
	"google.golang.org/protobuf/proto"

	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/server"
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/ip"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/proto/mavlink"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
)

const (
	TracerGunTcpPort        = 20000
	TracerGunServerMaxCount = 500
)
const (
	// 打击状态
	TracerGunStopHit  = 0 //空闲
	TracerGunStartHit = 1 //打击中
)

var (
	TracerGunTcpServerLock sync.Mutex
	TracerGunTcpServerMap  sync.Map
	TracerGunHeartSum      uint8
)

type TracerGun struct {
	*Device
	dt common.DeviceType
}

var _ DeviceIfer = (*TracerGun)(nil)

// SetDevice 要使用GetOnLineDev 接口，必须要给该设备实现 DeviceIfer 接口
func (tg *TracerGun) SetDevice(d *Device) {
	tg.Device = d
}

func (d *TracerGun) SendExtHeartbeat() error {
	TracerGunHeartSum++
	if TracerGunHeartSum > 255 {
		TracerGunHeartSum = 0
	}
	req := &mavlink.TracerGunHeartbeatExtRequest{
		Sum: TracerGunHeartSum,
	}
	reqBuff := req.CreateTracerGunHeartbeatExt()
	if d != nil && d.Conn != nil {
		_, err := d.Conn.Write(reqBuff)
		logger.Infof("TracerGun c2发送心跳结果：%X", reqBuff)
		if err != nil {
			equipModel, err := GetEquipBySn(d.Sn)
			name := d.Sn
			if equipModel != nil && equipModel.Name != "" {
				name = equipModel.Name
			}
			dataInfo := &client.TracerGunHeartInfo{
				Header: &client.EquipmentMessageBoxEntity{
					Name:      name,
					Sn:        d.Sn,
					EquipType: int32(common.DEV_TracerGun),
					MsgType:   mavlink.C2SendHeartbeatToTracerGun,
				},
				Data: &client.TracerGunHeart{
					Sn:       d.Sn,
					IsOnline: common.DevOffline,
				},
			}
			if err == nil {
				dataInfo.Header.ParentType = int32(equipModel.ParentType)
				dataInfo.Header.ParentSn = equipModel.ParentSn
				dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
			}
			msg, err := proto.Marshal(dataInfo)
			if err != nil {
				logger.Error("marshal dataInfo err:", err)
				return err
			}
			report := &client.ClientReport{
				MsgType: common.ClientMsgTracerGunHeartData,
				Data:    msg,
			}
			out, err := proto.Marshal(report)
			if err != nil {
				logger.Error("marshal report err:", err)
				return err
			}
			_ = mq.TracerGunBroker.Publish(mq.TracerGunTopic, broker.NewMessage(out))
			logger.Info("TracerGun Offline report:", report)
		}
		return err
	}
	return nil
}

func SendTracerGunHeart() {
	ticker := time.NewTicker(time.Second * 1)
	defer ticker.Stop()
	for range ticker.C {
		DevStatusMap.Range(func(key, value interface{}) bool {
			dev := value.(*Device)
			if dev.DevType == common.DEV_TracerGun && dev.Status == common.DevOnline {
				reqMode := &TracerGun{
					Device: dev,
					dt:     common.DEV_TracerGun,
				}
				reqMode.SendExtHeartbeat()
			}
			return true
		})
	}
}

func NewTracerGun(conn Connection, d []byte, dataLen int, remoteIp string, remotePort int, localIp string, serverPort int,
	mailBox map[int]*WaitTaskManager, dlimit *devLimit) DeviceInterface {
	tracerGun := &TracerGun{
		Device: &Device{
			Conn:        conn,
			Msg:         d,
			MsgLen:      dataLen,
			SourceId:    d[mavlink.SenderLoc],
			RemoteIp:    remoteIp,
			RemotePort:  remotePort,
			LocalIp:     localIp,
			ServerPort:  serverPort,
			WaitTaskMap: mailBox,
		},
	}
	return tracerGun
}
func (d *TracerGun) Deal() {
	defer func() {
		if err := recover(); err != nil {
			logger.Error("TracerGun deal 接收到panic:", err)
		}
	}()

	if d.MsgLen <= 0 {
		logger.Error("TracerGun 数据为null,不作处理:", d.Device.RemoteIp)
		return
	}
	d.MsgId = int(d.Msg[mavlink.MsgIdLoc])
	switch d.MsgId {
	case mavlink.TracerGunReportHeart: //上报心跳
		d.Heart()
	case mavlink.TraceGunHeartBeatGun:
		d.TransGunHearBeat() //转发枪的心跳包
	case mavlink.TracerGunGetFreqList:
		d.ReceiveTracerGunGetFreqList()
	case mavlink.TracerGunSetFreqList:
		d.ReceiveTracerGunSetFreqList()
	case mavlink.TracerGunResetFreqList:
		d.ReceiveTracerGunResetFreqList()
	case mavlink.TracerGunSetJamState:
		d.ReceiveTracerGunSetJamState()
	case mavlink.TracerGunGetJamState:
		d.ReceiveTracerGunGetJamState()
	case mavlink.TracerGunAddOrDelHitFreqList:
		d.ReceiveTraceGunAddDelFreqList()
	case mavlink.TracerGunGetVersionInfo:
		d.ReceiveGetVersion()

	//case mavlink.TracerGunSendHitMsg:
	//	d.ReceiveTracerGunSendHitMsg()

	default:
		logger.Error("TracerGun 未知TracerGun消息id:", d.MsgId)
		break
	}
}
func (d *TracerGun) ReceiveGetVersion() {
	res := &mavlink.TraceGunGetVersionResponse{}
	d.GetPacket(res)
	logger.Debug("receive TracerGun version info:%+v", *res)
	manager, ok := d.WaitTaskMap[mavlink.TracerGunGetVersionInfo]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *TracerGun) ReportGunHeartBeat(devSn string, result *mavlink.TraceGunHeartBeatOnGun, online int32) {
	dataInfo := &client.TracerGunTransHeartInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      devSn,
			Sn:        devSn,
			EquipType: int32(common.DEV_TracerGun),
			MsgType:   mavlink.TraceGunHeartBeatGun,
		},
		Data: &client.GunHeartOnTracerGun{
			// 0: 熄屏，1：亮屏
			ScreenStatus: int32(result.Info.ScreenStatus),
			// 0-100% 电量百分比
			Electricity: uint32(result.Info.Electricity),
			// 0: 电池， 1： 电池+适配器， 2：适配器
			BatteryStatus: uint32(result.Info.BatteryStatus),
			// 枪的工作状态
			// bit0~bit3:
			// 0：待机
			// 1: 侦测
			// 2：打击飞控图传
			// 3：打击GNSS
			// 4：打击飞控图传 + 打击GNSS
			// 5：水平扫描中
			// 6：水平瞄准中
			// 7：异常1（水平扫描角度不足）
			// 8：异常2（无法识别目标方向）
			// 9：瞄准完成
			// 10：允许进入定向模式
			// 11：不允许进入定向模式
			// 12：低电量不进行打击
			// 13：高温不进行打击
			// 14：打击FPV
			// 15：机型不支持进入定向模式
			// bit4:
			// 0: 没有故障
			// 1：有故障
			// bit5:
			// 0: 设备温度正常
			// 1：设备过热 //bit6:
			// 0: 设备可打击
			// 1：设备高温，不允许打击
			WorkStatus: int32(result.Info.WorkStatus),
			// bit0~bit3:
			// 0x00: 未检测到无人机，无报警
			// 0x01: 一级报警
			// 0x02: 二级报警
			// 0x03: 三级报警
			// bit4:
			// 0: 蜂鸣器不响
			// 1：蜂鸣器响
			// bit5:
			// 0：马达振动关闭
			// 1：马达振动打开
			AlarmLevel: uint32(result.Info.AlarmLevel),
			// 0：打击所有范围
			// 1：打击小于2G
			// 2：打击2-4G
			// 3：打击4-6G
			// 4：打击2G、2-4G
			// 5：打击2-4G 、4-6G
			// 6：打击2G、4-6G
			HitFreq: uint32(result.Info.HitFreq),
			// LSB 侦测扫描频率 (mHz)
			DetectFreq: uint32(result.Info.DetectFreq),
			// LSB枪俯仰角（0.00001°）
			Elevation: int32(result.Info.Elevation),
			// LSB枪经度（0.00001°）
			GunLongitude: float32(result.Info.GunLongitude) / 1e5,
			// LSB枪纬度（0.00001°）
			GunLatitude: float32(result.Info.GunLatitude) / 1e5,
			// LSB枪海拔高度（m）
			GunAltitude: int32(result.Info.GunAltitude),
			// LSB枪卫星数量
			SatellitesNum: uint32(result.Info.SatellitesNum),
			// LSB枪方位（0.00001°）
			GunDirection: float32(result.Info.GunDirection) / 1e5,
			// 建议打击时间（秒）
			ReHitTime: uint32(result.Info.ReHitTime),
			// 已经打击时间（秒）
			HitTime: uint32(result.Info.HitTime),
			// 模式6水平瞄准中的起始方位角
			StartAngle: float32(result.Info.StartAngle),
			// 模式6水平瞄准中的结束方位角
			EndAngle: float32(result.Info.EndAngle),
			IsOnline: online,
		},
	}

	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgTracerGunHeartGun,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}
	_ = mq.TracerGunBroker.Publish(mq.TracerGunTopic, broker.NewMessage(out))
	logger.Infof("gun heartbeat has reported, devSn: %v, msg: %+v", devSn, dataInfo)
}

// TransGunHearBeat 转发枪的心跳数据
func (d *TracerGun) TransGunHearBeat() {
	result := &mavlink.TraceGunHeartBeatOnGun{}
	if err := d.UnmarshalPayloadGunHeartBeat(result); err != nil {
		logger.Errorf("parse gun_tracer payload fail, err: %v", err.Error())
		return
	}

	devSn := d.getSn()
	if devSn != "" {
		logger.Debugf("receive gun self heartbeat.")
		d.updateStatus(devSn, 0)
		d.ReportGunHeartBeat(devSn, result, common.DevOnline)
		d.updateGunStatus(devSn)
	}
}

func (d *TracerGun) UnmarshalPayloadGunHeartBeat(data *mavlink.TraceGunHeartBeatOnGun) error {
	deviceInfoLen := binary.Size(mavlink.TraceGunHeartBeatOnGunBase{})
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}

	start := mavlink.HeaderLen + deviceInfoLen
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializeDrone(d.Msg[start:end]); err != nil {
		return err
	}
	return nil
}

func (d *TracerGun) UnmarshalPayloadHeartBeat(data *mavlink.TracerGunHeartbeat) error {
	deviceInfoLen := binary.Size(mavlink.TracerGunHeartBeatInfo{})
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}

	start := mavlink.HeaderLen + deviceInfoLen
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializePaItems(d.Msg[start:end]); err != nil {
		return err
	}

	return nil
}

// Heart 处理TracerGun发过来的心跳消息
func (d *TracerGun) Heart() {
	heart := &mavlink.TracerGunHeartbeat{}
	if err := d.UnmarshalPayloadHeartBeat(heart); err != nil {
		logger.Errorf("trace gun heartbeat msg parse fail: %v", err.Error())
		return
	}
	devSn := d.getSn()
	if devSn != "" {
		d.updateStatus(devSn, 0)
		dataInfo := &client.TracerGunHeartInfo{
			Header: &client.EquipmentMessageBoxEntity{
				Name:      devSn,
				Sn:        devSn,
				EquipType: int32(common.DEV_TracerGun),
				MsgType:   mavlink.TracerGunReportHeart,
			},
			Data: &client.TracerGunHeart{
				Sn:            devSn,
				IsOnline:      common.DevOnline,
				ConnectStatus: uint32(heart.Info.ConnectStatus),
				HitStatus:     uint32(heart.Info.HitStatus),
				FaultStatus:   uint32(heart.Info.FaultStatus),
				Electricity:   uint32(heart.Info.Electricity),
				Temperature:   uint32(heart.Info.Temperature),
				Electricity2:  uint32(heart.Info.Electricity2),
				FanSpeed:      uint32(heart.Info.FanSpeed),
			},
		}
		for i := 0; i < len(heart.PaItems); i++ {
			dataInfo.Data.PadItems = append(dataInfo.Data.PadItems, &client.TracerGunHeartBeatPaItem{
				PaNo:    heart.PaItems[i].PaNo,
				ErrCode: heart.PaItems[i].ErrCode,
				Current: heart.PaItems[i].Current, //当前功放电流值
				Watt:    heart.PaItems[i].Watt,    //当前功放输出功率
			})
		}

		logger.Infof("trace gun to app frontend data: %+v", dataInfo)
		msg, err := proto.Marshal(dataInfo)
		if err != nil {
			logger.Error("marshal dataInfo err:", err)
			return
		}
		report := &client.ClientReport{
			MsgType: common.ClientMsgTracerGunHeartData,
			Data:    msg,
		}
		out, err := proto.Marshal(report)
		if err != nil {
			logger.Error("marshal report err:", err)
			return
		}

		_ = mq.TracerGunBroker.Publish(mq.TracerGunTopic, broker.NewMessage(out))
		//if dataInfo.Data.WorkMode == TracerGunStartHit {
		//	//关闭tracer探测
		//	for _, tracerSn := range GetTracerOnLineTracer() {
		//		tracerDev := FindCacheDevice(tracerSn, common.DEV_V2DRONEID)
		//		if tracerDev == nil {
		//			continue
		//		}
		//		dev := &DroneID{
		//			Device: tracerDev,
		//		}
		//		dev.SetRadioFreq(RFreqClose)
		//	}
		//} else if dataInfo.Data.WorkMode == TracerGunStopHit {
		//	//开启tracer探测
		//	//关闭tracer探测
		//	for _, tracerSn := range GetTracerOnLineTracer() {
		//		tracerDev := FindCacheDevice(tracerSn, common.DEV_V2DRONEID)
		//		if tracerDev == nil {
		//			continue
		//		}
		//		dev := &DroneID{
		//			Device: tracerDev,
		//		}
		//		dev.SetRadioFreq(RFreqOpen)
		//	}
		//}
	}
}

func (d *TracerGun) TracerGunGetFreqList() (*client.TracerGunGetFreqListResponse, error) {
	logger.Info("-->into Send TracerGun TracerGunGetFreqList msg")
	req := &mavlink.TracerGunGetFreqListRequest{}
	rsp := &client.TracerGunGetFreqListResponse{}
	buff := req.Create()
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("write TracerGun GetFreqList info err: %v", err)
		return rsp, fmt.Errorf("write TracerGun GetFreqList info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.TracerGunGetFreqList]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerGunGetFreqList, true, 0)
		d.WaitTaskMap[mavlink.TracerGunGetFreqList] = manager
	}
	task := manager.AddTask(nil, nil)

	result, err := manager.WaitTask(task)
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request TracerGun GetFreqList info err: %v", checkNetConnErr)
			return rsp, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.TracerGunGetFreqListResponse)
	if !ok {
		return rsp, errors.New("response err type")
	}
	logger.Debug("response TracerGun GetFreqList result:%+v", *res)
	for _, list := range res.FreqList0 {
		rsp.FreqList0 = append(rsp.FreqList0, &client.TracerGunFreqList{
			IFreqStart:   int32(list.IFreqStart),
			IFreqEnd:     int32(list.IFreqStop),
			GroupEnabled: int32(list.GroupEnabled),
		})
	}
	for _, list := range res.FreqList1 {
		rsp.FreqList1 = append(rsp.FreqList1, &client.TracerGunFreqList{
			IFreqStart:   int32(list.IFreqStart),
			IFreqEnd:     int32(list.IFreqStop),
			GroupEnabled: int32(list.GroupEnabled),
		})
	}
	return rsp, nil
}
func (d *TracerGun) ReceiveTracerGunGetFreqList() {
	logger.Info("-->into Receive Get GetFreqList")
	res := &mavlink.TracerGunGetFreqListResponse{}
	if err := d.UnmarshalPayloadTracerGunFreqList(res); err != nil {
		logger.Errorf(err.Error())
		return
	}
	logger.Debugf("TracerGun GetFreqList 接收到Sfl信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.TracerGunGetFreqList]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *TracerGun) UnmarshalPayloadTracerGunFreqList(data *mavlink.TracerGunGetFreqListResponse) error {
	groupNum0Len := binary.Size(data.GroupNum0)
	buff := &bytes.Buffer{}
	start := mavlink.HeaderLen // begin of index  ch0
	if err := binary.Write(buff, binary.LittleEndian, d.Msg[start:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.GroupNum0); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}

	start += groupNum0Len //begin of index 0 list
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializeFreqList0(d.Msg[start:end]); err != nil {
		return err
	}

	buff = &bytes.Buffer{}
	start += int(data.GroupNum0) * binary.Size(mavlink.GroupFreqList{}) // begin of index ch1
	if err := binary.Write(buff, binary.LittleEndian, d.Msg[start:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.GroupNum1); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}

	groupNum1Len := binary.Size(data.GroupNum1)
	start += groupNum1Len // begin of index 1 list
	if err := data.DeserializeFreqList1(d.Msg[start:end]); err != nil {
		return err
	}
	return nil
}

func (d *TracerGun) TracerGunSetFreqList(request *client.TracerGunSetFreqListRequest) (int32, error) {
	logger.Info("-->into Send TracerGun TracerGunSetFreqList")
	req := &mavlink.TracerGunSetFreqListRequest{}

	buff := req.Create(request)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("write TracerGun SetFreqList buf err: %v", err)
		return Fail, fmt.Errorf("request TracerGun SetFreqList info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.TracerGunSetFreqList]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerGunSetFreqList, true, 0)
		d.WaitTaskMap[mavlink.TracerGunSetFreqList] = manager
	}
	task := manager.AddTask(nil, nil)
	result, err := manager.WaitTask(task)
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request TracerGun SetFreqList info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.TracerGunSetFreqListResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response TracerGun SetFreqList result:%+v", *res)
	return int32(res.Status), nil
}

// 只适用与固定长度的消息
func (d *TracerGun) GetPacket(message mavlink.Message) *mavlink.MavPacket {
	logger.Infof("GetPacket is [% x]", d.Msg)
	req := mavlink.NewNullPacket(message)
	buff := &bytes.Buffer{}
	if err := binary.Write(buff, binary.LittleEndian, d.Msg); err != nil {
		return nil
	}
	if err := binary.Read(buff, binary.LittleEndian, &req.Header); err != nil {
		logger.Error("packet binary header err:", err)
		return nil
	}
	if err := binary.Read(buff, binary.LittleEndian, req.Msg); err != nil {
		logger.Errorf("%d packet binary msg err: %v", req.Header.MessageID, err)
		return nil
	}
	return req
}

func (d *TracerGun) ReceiveTracerGunSetFreqList() {
	logger.Info("-->into Receive SetFreqList")
	res := &mavlink.TracerGunSetFreqListResponse{}
	d.GetPacket(res)
	logger.Debugf("TracerGun GetFreqList 接收到Sfl信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.TracerGunSetFreqList]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *TracerGun) TracerGunDelAndFreqList(request *client.TracerGunAddDelFreqRequest) (int32, error) {
	logger.Info("-->into Send TracerGun Add or Del FreqList msg")
	req := &mavlink.TraceGunAddDelFreqListRequest{}
	buff := req.Create(request)

	manager, ok := d.WaitTaskMap[mavlink.TracerGunAddOrDelHitFreqList]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerGunAddOrDelHitFreqList, true, 0)
		d.WaitTaskMap[mavlink.TracerGunAddOrDelHitFreqList] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf(" Send TracerGun Add or Del FreqList msg :[% x]", buff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request TracerGun Reset FreqList info err: %v", err)
		return Fail, fmt.Errorf("request TracerGun Reset FreqList info err: %v", err)
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("send tracer gun add or del task fail, err: %v", err)
		return Fail, err
	}

	res, ok := result.(*mavlink.TraceGunAddDelFreqListResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}

	logger.Debug("response TracerGun Add and Del FreqList result:%+v", *res)
	return int32(res.Status), nil
}

func (d *TracerGun) TracerGunResetFreqList(request *client.TracerGunResetFreqListRequest) (int32, error) {
	logger.Info("-->into Send TracerGun Reset FreqList msg")
	req := &mavlink.TracerGunResetFreqListRequest{}

	buff := req.Create(request)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request TracerGun Reset FreqList info err: %v", err)
		return Fail, fmt.Errorf("request TracerGun Reset FreqList info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.TracerGunResetFreqList]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerGunResetFreqList, true, 0)
		d.WaitTaskMap[mavlink.TracerGunResetFreqList] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request TracerGun Reset FreqList info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.TracerGunResetFreqListResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response TracerGun ResetFreqList result:%+v", *res)
	return int32(res.Status), nil
}
func (d *TracerGun) ReceiveTracerGunResetFreqList() {
	logger.Info("-->into Receive ResetFreqList")
	res := &mavlink.TracerGunResetFreqListResponse{}
	d.GetPacket(res)
	logger.Debugf("TracerGun ResetFreqList 接收到Sfl信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.TracerGunResetFreqList]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *TracerGun) TracerGunSetJamStatus(request *client.TracerGunSetJamStatusRequest) (int32, error) {
	logger.Info("-->into Send TracerGun SetJamStatus msg")
	req := &mavlink.TracerGunSetJamStatusRequest{}

	buff := req.Create(request)
	logger.Debugf(" Send TracerGun SetJamStatus msg :[% x]", buff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request TracerGun SetJamStatus info err: %v", err)
		return Fail, fmt.Errorf("request TracerGun SetJamStatus info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.TracerGunSetJamState]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerGunSetJamState, true, 0)
		d.WaitTaskMap[mavlink.TracerGunSetJamState] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request TracerGun SetJamStatus info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.TracerGunSetJamStatusResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response TracerGun SetJamStatus result:%+v", *res)
	return int32(res.Status), nil
}
func (d *TracerGun) ReceiveTracerGunSetJamState() {
	logger.Info("-->into Receive SetJamState")
	res := &mavlink.TracerGunSetJamStatusResponse{}
	d.GetPacket(res)
	logger.Debugf("TracerGun SetJamState 接收到TracerGun信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.TracerGunSetJamState]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *TracerGun) GetVersionInfo(sn string) (*client.TracerGunGetInfoResponse, error) {
	req := &mavlink.TraceGunGetVersionRequest{}
	buff := req.Create()
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request TracerGun version info err: %v", err)
		return nil, fmt.Errorf("request TracerGun version info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.TracerGunGetVersionInfo]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerGunGetVersionInfo, true, 0)
		d.WaitTaskMap[mavlink.TracerGunGetVersionInfo] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request TracerGun version info err: %v", checkNetConnErr)
			return nil, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.TraceGunGetVersionResponse)
	if !ok {
		return nil, errors.New("response err type")
	}

	r := &client.TracerGunGetInfoResponse{}
	r.Company = ByteToString(res.CompanyName[:])
	r.Sn = ByteToString(res.DeviceSn[:])
	r.PsVersion = ByteToString(res.PsVersion[:])
	r.PlVersion = ByteToString(res.PlVersion[:])
	r.Ip = ByteToString(res.DeviceIP[:])
	logger.Debug("response droneID version result:%+v", *r)
	if r.PsVersion != "" {
		err = NewEquipList().Update(context.Background(), &client.EquipCrudReq{
			Sn:         sn,
			DevVersion: r.PsVersion,
			IsOnline:   true,
		}, &client.EquipCrudRes{})
		if err != nil {
			logger.Error("Update EquipList err: ", err)
		}
	}
	return r, nil
}

func (d *TracerGun) TracerGunGetJamStatus() (int32, error) {
	logger.Info("-->into Send TracerGun GetJamStatus msg")
	req := &mavlink.TracerGunGetJamStatusRequest{}

	buff := req.Create()
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request TracerGun GetJamStatus info err: %v", err)
		return Fail, fmt.Errorf("request TracerGun GetJamStatus info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.TracerGunGetJamState]
	if !ok {
		manager = NewWaitTaskManager(mavlink.TracerGunGetJamState, true, 0)
		d.WaitTaskMap[mavlink.TracerGunGetJamState] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request TracerGun GetJamStatus info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.TracerGunGetJamStatusResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response TracerGun GetJamStatus result:%+v", *res)
	return int32(res.JamStatus), nil
}
func (d *TracerGun) ReceiveTracerGunGetJamState() {
	logger.Info("-->into Receive GetJamState")
	res := &mavlink.TracerGunGetJamStatusResponse{}
	d.GetPacket(res)
	logger.Debugf("TracerGun GetJamState 接收到TracerGun信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.TracerGunGetJamState]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}
func (d *TracerGun) ReceiveTraceGunAddDelFreqList() {
	logger.Info("-->into Receive TraceGunAddDelFreqList")
	res := &mavlink.TraceGunAddDelFreqListResponse{}
	d.GetPacket(res)
	logger.Debugf("TracerGun TraceGunAddDelFreqList 接收到TracerGun信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.TracerGunAddOrDelHitFreqList]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}
func (d *TracerGun) TransDetectToTracerGun(data *mavlink.TracerGunDetectFromTracerRequest) error {
	if data == nil {
		return nil
	}
	buff := data.Create()
	logger.Debugf("Send TransDetectToTracerGun msg:[% x]", buff)
	_, err := d.Conn.Write(buff)
	if err != nil {
		logger.Errorf("request TransDetectToTracerGun err: %v", err)
		return fmt.Errorf("request TransDetectToTracerGun err: %v", err)
	}
	return nil
}

//func (d *TracerGun) TracerGunSendHitMsg(status int32) error {
//	logger.Info("-->into Send TracerGun SendHitMsg msg")
//	req := &mavlink.TracerGunSendHitMsgRequest{}
//
//	buff := req.Create(int(status))
//	if _, err := d.Conn.Write(buff); err != nil {
//		logger.Errorf("request TracerGun SendHitMsg info err: %v", err)
//		return fmt.Errorf("request TracerGun SendHitMsg info err: %v", err)
//	}
//	return nil
//}
//func (d *TracerGun) ReceiveTracerGunSendHitMsg() {
//	logger.Info("-->into Receive SendHitMsg")
//	res := &mavlink.TracerGunSendHitMsgResponse{}
//	d.GetPacket(res)
//	logger.Debugf("TracerGun SendHitMsg 接收到TracerGun信息：%#v", res)
//	//发给tracer消息
//
//	if res.RequestHit == 2 { //开始打击
//		//给tracer发停止
//		for _, tracerSn := range GetTracerOnLineTracer() {
//			tracerDev := FindCacheDevice(tracerSn, common.DEV_V2DRONEID)
//			if tracerDev == nil {
//				continue
//			}
//			dev := &DroneID{
//				Device: tracerDev,
//			}
//			resTracer := dev.SetRadioFreq(RFreqClose)
//
//			gunSn := d.getSn()
//			gunDev := FindCacheDevice(gunSn, common.DEV_TracerGun)
//			if gunDev == nil {
//				return
//			}
//			devGun := &TracerGun{
//				Device: gunDev,
//			}
//			if resTracer == 1 { //关闭成功 给枪发可以开始打击
//				devGun.TracerGunSendHitMsg(TracerGunStartHit)
//			} else if resTracer == 0 { //关闭失败   给枪发不可开始打击
//				devGun.TracerGunSendHitMsg(TracerGunStopHit)
//			}
//		}
//	} else if res.RequestHit == 3 { //停止打击
//		//给tracer发启动
//		for _, tracerSn := range GetTracerOnLineTracer() {
//			tracerDev := FindCacheDevice(tracerSn, common.DEV_V2DRONEID)
//			if tracerDev == nil {
//				continue
//			}
//			dev := &DroneID{
//				Device: tracerDev,
//			}
//			resTracer := dev.SetRadioFreq(RFreqOpen)
//			gunSn := d.getSn()
//			gunDev := FindCacheDevice(gunSn, common.DEV_TracerGun)
//			if gunDev == nil {
//				return
//			}
//			devGun := &TracerGun{
//				Device: gunDev,
//			}
//			if resTracer == 1 { //关闭成功 给枪发可以开始打击
//				devGun.TracerGunSendHitMsg(TracerGunStartHit)
//			} else if resTracer == 0 { //关闭失败   给枪发不可开始打击
//				devGun.TracerGunSendHitMsg(TracerGunStopHit)
//			}
//		}
//	}
//
//	return
//}

// HandleBroadCast 处理广播消息
func (d *TracerGun) HandleBroadCast(ctx context.Context, req *slinkv1.UdpBroadcastConfirmRequest) (*slinkv1.UdpBroadcastConfirmResponse, error) {

	if req.GetSn() == "" {
		logger.Info("device sn empty")
		return nil, errors.New("device sn empty")
	}
	d.GetStatus(req.GetSn(), int(req.DeviceType))
	logger.Debug("req.DeviceType = ", req.DeviceType)

	localIP := make([]string, 0)
	localIps, broadIps, err := ip.GetBroadcastAddress()
	if err != nil {
		logger.Error("Get IP error :%v", err)
	}
	for i, ip := range localIps {
		if i >= len(broadIps) {
			continue
		}
		localIP = append(localIP, ip)
	}
	logger.Debugf("[Fpv] localIP:%v,", localIP)

	tcpServer := d.TcpServerCheck(req.GetSn(), localIP, uint8(req.DeviceType))
	DevSnMap.Store(tcpServer.Port, req.GetSn())
	d.ServerPort = tcpServer.Port
	var tempSn [32]byte
	for i, v := range []byte(req.GetSn()) {
		tempSn[i] = v
	}
	//响应
	rsp := &slinkv1.UdpBroadcastConfirmResponse{
		Sn:       tempSn,
		Addr:     ip.IPV4(tcpServer.Ip),
		Port:     uint16(tcpServer.Port),
		ConnType: 1,
	}
	return rsp, nil
}
func (d *TracerGun) ReceiveGetChannelReq() {
	TracerGunTcpServerLock.Lock()
	defer TracerGunTcpServerLock.Unlock()

	devSn := d.UnMarshalGetChannelReq()
	if devSn == "" {
		logger.Info("TracerGun device sn empty")
		return
	}

	localIP := make([]string, 0)

	localIps, broadIps, err := ip.GetBroadcastAddress()
	if err != nil {
		logger.Error("GunsPlatform Get IP error :%v", err)
	}
	for i, ip := range localIps {
		if i >= len(broadIps) {
			continue
		}
		localIP = append(localIP, ip)
	}
	logger.Debugf("[GunsPlatform] localIP:%v,", localIP)

	tcpServer := d.TcpServerCheck(devSn, localIP, uint8(d.DevType))
	DevSnMap.Store(tcpServer.Port, devSn)
	d.ServerPort = tcpServer.Port

	//响应
	switch d.MsgId {
	case mavlink.TracerGunUdpBroadcastResponse:
		logger.Info("[TracerGun] receive Broadcast BB Msg")
		UdpBroadcastSendChannel(devSn, d.UdpIp, d.SourceId, tcpServer)
		break
	default:
		break
	}

	return
}
func (d *TracerGun) UnMarshalGetChannelReq() string {
	devSn := ""
	switch d.MsgId {
	case mavlink.TracerGunUdpBroadcastResponse:
		req := &mavlink.UdpBroadcastConfirmRequest{}
		d.GetPacket(req)
		devSn = strings.TrimRight(string(req.Sn[:]), string(rune(0)))
		break
	default:
		break
	}
	return devSn
}

func (d *TracerGun) TcpServerCheck(devSn string, localIP []string, devType uint8) *server.TcpServer {
	var tcpServer *server.TcpServer
	if s, ok := TracerGunTcpServerMap.Load(devSn); ok {
		tcpServer = s.(*server.TcpServer)
		isAlike := false
		for _, ip := range localIP {
			if ip == tcpServer.Ip {
				isAlike = true
			}
		}
		if isAlike == false { //查找的本地IP没有与之前相同的
			if tcpServer != nil {
				tcpServer.Stop()
			}
			deviceUsedPorts.Delete(tcpServer.Port)
			TracerGunTcpServerMap.Delete(devSn)
			DevSnMap.Delete(tcpServer.Port)
			tcpServer = nil
		}
	}

	//注册tcp服务
	if tcpServer == nil {
		port, err := ip.GetFreeTcpPort()
		if err != nil {
			logger.Error("TracerGun tcp 获取可用端口失败：", err)
			port = d.getRandPort(TracerGunTcpPort, TracerGunTcpPort+TracerGunServerMaxCount)
		}
		tcpServer = server.NewTcpServer(port, Handle)
		TracerGunTcpServerMap.Store(devSn, tcpServer)
		tcpServer.ServerType = uint8(common.DEV_TracerGun)
		tcpServer.ServerType = devType
		tcpServer.ServerName = devSn
		localAddr, _ := ip.GetLocalIp(d.UdpIp)
		tcpServer.Ip = localAddr
		go tcpServer.Start()
	}
	return tcpServer
}

func (d *TracerGun) getRandPort(min, max int64) int {
	maxBigInt := big.NewInt(max)
	i, _ := rand.Int(rand.Reader, maxBigInt)
	_, ok := deviceUsedPorts.Load(i.Int64())
	port := i.Int64()
	//缓存不存在或者符合范围
	if !ok && (port > min && port < max) {
		deviceUsedPorts.Store(port, port)
		return int(port)
	}
	return d.getRandPort(min, max)
}
func (d *TracerGun) getSn() string {
	if sn, ok := DevSnMap.Load(d.ServerPort); ok {
		return sn.(string)
	}
	return ""
}

func (d *TracerGun) updateGunStatus(sn string) {
	nowTm := time.Now()
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_TracerGun, sn)
	if cache, ok := DevStatusMap.Load(cacheKey); ok {
		dev := cache.(*Device)
		dev.SubDevTimeStamp = nowTm
	}
}
func (d *TracerGun) updateStatus(sn string, subDevType int) int32 {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_TracerGun, sn)
	if cache, ok := DevStatusMap.Load(cacheKey); ok {
		dev := cache.(*Device)
		dev.Status = common.DevOnline
		dev.Conn = d.Conn
		dev.WaitTaskMap = d.WaitTaskMap
		dev.RemoteIp = d.RemoteIp
		dev.LastHeartTime = time.Now()
		dev.GetStatusInterval = time.Now()
		return common.DeviceEnable
	} else {
		dev := &Device{
			Sn:                sn,
			Conn:              d.Conn,
			Status:            common.DevOnline,
			RemoteIp:          d.RemoteIp,
			RemotePort:        d.RemotePort,
			LocalIp:           d.LocalIp,
			ServerPort:        d.ServerPort,
			DevType:           common.DEV_TracerGun,
			FirstHeartTime:    time.Now(),
			LastHeartTime:     time.Now(),
			SourceId:          d.SourceId,
			IsEnable:          d.GetStatus(sn, subDevType),
			GetStatusInterval: time.Now(),
			WaitTaskMap:       d.WaitTaskMap,
		}
		DevStatusMap.Store(cacheKey, dev)
		time.Sleep(time.Second * 2)
		if d.Conn == nil {
			return dev.IsEnable
		}
		_, err := d.GetVersionInfo(sn)
		if err != nil {
			logger.Errorf("TracerGun GetVersionInfo err: %v", err)
		}

		return dev.IsEnable
	}
}
func (d *TracerGun) GetStatus(sn string, subDevType int) int32 {
	statusRes := &client.GetStatusRes{}
	err := NewEquipList().GetStatus(context.Background(), &client.GetStatusReq{Sn: sn, EType: "TracerGun", SubDevType: int64(subDevType)}, statusRes)
	if err != nil {
		logger.Errorf("GetStatus err: %v", err.Error())
		return 0
	}

	return statusRes.IsEnable
}

// TracerGunReportOffline  上报tracer+gun 离线
func TracerGunReportOffline(sn string, devType common.DeviceType) {
	equipModel, err := GetEquipBySn(sn)
	name := sn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	msg := &client.TracerGunHeartInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        sn,
			EquipType: int32(common.DEV_TracerGun),
			MsgType:   mavlink.TracerGunReportHeart,
		},
		Data: &client.TracerGunHeart{
			Sn:       sn,
			IsOnline: common.DevOffline,
		},
	}
	if err == nil {
		msg.Header.ParentType = int32(equipModel.ParentType)
		msg.Header.ParentSn = equipModel.ParentSn
		msg.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msgOut, err := proto.Marshal(msg)
	if err != nil {
		logger.Error("marshal msg err:", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgTracerGunHeartData,
		Data:    msgOut,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}
	logger.Debugf("tracer gun is offline,sn: %v, msg: %+v", sn, msg)
	_ = mq.TracerGunBroker.Publish(mq.TracerGunTopic, broker.NewMessage(out))

	//发送枪的离线消息
	gunTracer := &TracerGun{}
	result := &mavlink.TraceGunHeartBeatOnGun{}
	gunTracer.ReportGunHeartBeat(sn, result, common.DevOffline)
}

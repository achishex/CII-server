package handler

import (
	"context"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/api/websocket"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/config"
	"google.golang.org/protobuf/types/known/emptypb"
)

type AppAgent struct {
	WskServerAddr common.IpAddr
	WskServer     *websocket.WebSocketServer
}

func NewAppAgent() *AppAgent {
	return &AppAgent{
		WskServerAddr: common.IpAddr{
			Ip:   config.GetGlobalConfig().Server.WebsocketIp,
			Port: config.GetGlobalConfig().Server.WebsocketPort,
		},
		WskServer: &websocket.WebSocketServer{
			ServerAddr: common.IpAddr{
				Ip:   config.GetGlobalConfig().Server.WebsocketIp,
				Port: config.GetGlobalConfig().Server.WebsocketPort,
			},
		}}
}

func (a *AppAgent) Start(ctx context.Context, req *emptypb.Empty, empty *emptypb.Empty) error {
	logger.Infof("Received AppAgent.Start")
	a.WskServer.Start()
	return nil
}

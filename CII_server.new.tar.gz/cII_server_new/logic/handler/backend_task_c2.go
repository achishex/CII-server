package handler

const (
	MiniGunBatteryCapInvalidVal = -1
	MiniGunHitting              = 1
	MiniGunEndHit               = 2
)

//var (
//	bladerHitStatusOnce sync.Once
//	bladerHitStatusItem *BladerHitStatusManager = nil
//
//	bladerTimerRetDataOnce  sync.Once
//	bladderTimerRetDataItem *MiniGunTimerRetData = nil
//)
//
//// GetBladerTimerRetDataObj 获取定时器查询任务结果句柄（单例）
//func GetBladerTimerRetDataObj() *MiniGunTimerRetData {
//	bladerTimerRetDataOnce.Do(func() {
//		bladderTimerRetDataItem = NewMiniGunTimerRetData()
//	})
//	return bladderTimerRetDataItem
//}
//
//type MiniGunTimerRetData struct {
//	Ver        string
//	BatteryCap int8 //电池百分比
//	lk         sync.RWMutex
//	sn         string
//	StrikeMode int8
//}
//
//func NewMiniGunTimerRetData() *MiniGunTimerRetData {
//	return &MiniGunTimerRetData{
//		StrikeMode: 0,
//	}
//}
//func (r *MiniGunTimerRetData) SetVersion(v string) {
//	if r == nil || len(v) <= 0 {
//		return
//	}
//	r.lk.Lock()
//	defer r.lk.Unlock()
//	r.Ver = v
//}
//func (r *MiniGunTimerRetData) GetVersion() string {
//	if r == nil {
//		return ""
//	}
//	r.lk.RLock()
//	defer r.lk.RUnlock()
//	return r.Ver
//}
//func (r *MiniGunTimerRetData) SetBatteryCap(bc int8) {
//	if r == nil || (bc > 100) || bc <= MiniGunBatteryCapInvalidVal {
//		logger.Infof("bc more than 100, val: %v", bc)
//		return
//	}
//	r.lk.Lock()
//	defer r.lk.Unlock()
//
//	r.BatteryCap = bc
//}
//func (r *MiniGunTimerRetData) GetBatteryCap() int8 {
//	if r == nil {
//		return -1
//	}
//	r.lk.RLock()
//	defer r.lk.RUnlock()
//
//	return r.BatteryCap
//}
//func (r *MiniGunTimerRetData) SetStrikeMode(s int8) {
//	if s < GunStatusNormal || s > GunStatusSpoof {
//		return
//	}
//	r.lk.Lock()
//	defer r.lk.Unlock()
//
//	r.StrikeMode = s
//}
//func (r *MiniGunTimerRetData) GetStrikeMode() int8 {
//	r.lk.RLock()
//	defer r.lk.RUnlock()
//
//	return r.StrikeMode
//}
//
//// GetBladerHitStatusObj 获取打击状态句柄（单例）
//func GetBladerHitStatusObj() *BladerHitStatusManager {
//	bladerHitStatusOnce.Do(func() {
//		bladerHitStatusItem = NewBladerHitStatusManager()
//	})
//	return bladerHitStatusItem
//}
//
//type BladerHitStatusManager struct {
//	status int8 // 1: 打击中， 2: 打击结束
//	lk     sync.RWMutex
//}
//
//func NewBladerHitStatusManager() *BladerHitStatusManager {
//	return &BladerHitStatusManager{
//		status: MiniGunEndHit,
//	}
//}
//
//func (p *BladerHitStatusManager) IsHitting() bool {
//	if p == nil {
//		return false
//	}
//	//
//	p.lk.RLock()
//	defer p.lk.RUnlock()
//
//	return p.status == MiniGunHitting
//}
//func (p *BladerHitStatusManager) BeginHit() {
//	if p == nil {
//		return
//	}
//
//	p.lk.Lock()
//	defer p.lk.Unlock()
//
//	p.status = MiniGunHitting
//}
//func (p *BladerHitStatusManager) EndHit() {
//	if p == nil {
//		return
//	}
//
//	p.lk.Lock()
//	defer p.lk.Unlock()
//
//	p.status = MiniGunEndHit
//}
//
//// QuerySnOnMiniGun 查询sn
//func QuerySnOnMiniGun(s *server.TcpServer, ctx context.Context, conn net.Conn) (string, error) {
//	miniGun := &MiniGun{Device: &Device{
//		Conn:    conn,
//		Name:    "Blader",
//		DevType: common.Dev_Blader,
//	}}
//	time.Sleep(100 * time.Millisecond)
//	remoteAddr := strings.Split(conn.RemoteAddr().String(), ":")
//	var mailBox map[int]*WaitTaskManager
//	mbox, ok := GWaitTaskMap.Load(remoteAddr[0])
//	if !ok {
//		mailBox = make(map[int]*WaitTaskManager)
//		GWaitTaskMap.Store(remoteAddr[0], mailBox)
//		logger.Infof("QuerySnOnMiniGun remote addr: %v, %p", remoteAddr, mailBox)
//	} else {
//		mailBox = mbox.(map[int]*WaitTaskManager)
//		logger.Infof("has WaitTaskManager, remote addr: %v, %p", remoteAddr, mailBox)
//	}
//	miniGun.WaitTaskMap = mailBox
//
//	var sn string = ""
//	for i := 0; i < 3; i++ {
//		sn = miniGun.QueryDevSn()
//		if len(sn) <= 0 {
//			logger.Infof("get gun sn is empty")
//			continue
//		}
//		break
//	}
//	if len(sn) <= 0 {
//		logger.Infof("get gun sn is empty, try 3 times")
//		return "", fmt.Errorf("get gun sn is empty")
//	}
//
//	LocalAddr := strings.Split(conn.LocalAddr().String(), ":")
//	serverPort, _ := strconv.Atoi(LocalAddr[1])
//
//	cacheKey := fmt.Sprintf("%d_%s", common.Dev_Blader, sn)
//	if cache, ok := DevStatusMap.Load(cacheKey); ok {
//		dev := cache.(*Device)
//		dev.LastHeartTime = time.Now()
//		dev.Status = common.DevOnline
//		dev.Conn = miniGun.Conn
//		dev.WaitTaskMap = miniGun.WaitTaskMap
//		dev.ServerPort = serverPort
//		logger.Infof("update dev status to DevStatusMap, sn: %v", sn)
//		//
//	} else {
//		dev := &Device{
//			Name:           "gun",
//			Sn:             sn,
//			Conn:           miniGun.Conn,
//			Status:         common.DevOnline,
//			DevType:        common.Dev_Blader,
//			FirstHeartTime: time.Now(),
//			LastHeartTime:  time.Now(),
//			ServerPort:     serverPort,
//		}
//		DevStatusMap.Store(cacheKey, dev)
//		logger.Infof("insert new dev status to DevStatusMap, sn: %v, cacheKey: %v", sn, cacheKey)
//	}
//	//
//
//	DevSnMap.Store(serverPort, sn) //现在只有一台枪和c2连接
//	logger.Infof("store DevSnMap, server port: %v, sn: %v", serverPort, sn)
//	return sn, nil
//}
//
//func OnFailSendHeartBeat(sn string, conn net.Conn) {
//	logger.Infof("write heart beat to mini gun fail as connect is invalid, sn: %v", sn)
//	if conn != nil {
//		logger.Infof("now close connect with mini gun, sn: %v.", sn)
//		conn.Close()
//
//		if GetBladerHitStatusObj().IsHitting() {
//			logger.Infof("is hitting on blader, set blader hit end, and send notify to app, spoofer, tracers, sn: %v", sn)
//			{
//				d := &MiniGun{
//					Device: &Device{
//						Conn: conn,
//						Sn:   sn,
//					},
//				}
//
//				strikeMode := GetBladerTimerRetDataObj().GetStrikeMode()
//				logger.Infof("when close connect, current strike mode: %v", strikeMode)
//				d.SendHitStop(uint8(strikeMode))
//				GetBladerTimerRetDataObj().SetStrikeMode(GunStatusNormal) //
//			}
//		}
//	}
//}
//func SendHeartBeatWithFailCB(sn string, conn net.Conn, failCB func(sn string, conn net.Conn)) {
//	threading.GoSafe(func() {
//		tmr := time.NewTicker(1 * time.Second)
//		defer tmr.Stop()
//
//		remoteAddr := strings.Split(conn.RemoteAddr().String(), ":")
//		var mailBox map[int]*WaitTaskManager
//		mbox, _ := GWaitTaskMap.Load(remoteAddr[0])
//		mailBox = mbox.(map[int]*WaitTaskManager)
//
//		for range tmr.C {
//			miniGun := &MiniGun{Device: &Device{
//				Conn:        conn,
//				Sn:          sn,
//				Name:        "Blader",
//				DevType:     common.Dev_Blader,
//				WaitTaskMap: mailBox,
//			}}
//
//			tryNums := 3
//			ret := int32(0)
//
//			for i := 0; i < tryNums; {
//				wtime := int32(500)
//				if GetBladerHitStatusObj().IsHitting() {
//					logger.Infof("is hitting, wait heartbeat timeout, Blader sn: %v, i: %v", sn, i)
//					wtime = 2000
//				}
//
//				ret = miniGun.SendHeartBeat(wtime)
//				if ret >= 0 {
//					break
//				}
//				i++
//			}
//
//			if ret < 0 {
//				failCB(sn, conn)
//				return
//			}
//		}
//	})
//}
//
//// SendHeartBeatToMiniGun 任务主动发送心跳包，检测连接是否在。
//func SendHeartBeatToMiniGun(sn string, conn net.Conn) {
//	threading.GoSafe(func() {
//		tmr := time.NewTicker(1 * time.Second)
//		defer tmr.Stop()
//
//		remoteAddr := strings.Split(conn.RemoteAddr().String(), ":")
//		var mailBox map[int]*WaitTaskManager
//		mbox, _ := GWaitTaskMap.Load(remoteAddr[0])
//		mailBox = mbox.(map[int]*WaitTaskManager)
//
//		for range tmr.C {
//			miniGun := &MiniGun{Device: &Device{
//				Conn:        conn,
//				Sn:          sn,
//				Name:        "Blader",
//				DevType:     common.Dev_Blader,
//				WaitTaskMap: mailBox,
//			}}
//
//			tryNums := 3
//			ret := int32(0)
//
//			for i := 0; i < tryNums; {
//				wtime := int32(500)
//				if GetBladerHitStatusObj().IsHitting() {
//					logger.Infof("is hitting, wait heartbeat timeout, Blader sn: %v, i: %v", sn, i)
//					wtime = 2000
//				}
//
//				ret = miniGun.SendHeartBeat(wtime)
//				if ret >= 0 {
//					break
//				}
//				i++
//			}
//
//			if ret < 0 {
//				logger.Infof("write heart beat to mini gun fail as connect is invalid, sn: %v", sn)
//				if conn != nil {
//					logger.Infof("now close connect with mini gun, sn: %v.", sn)
//					conn.Close()
//
//					if GetBladerHitStatusObj().IsHitting() {
//						logger.Infof("is hitting on blader, set blader hit end, and send notify to app, spoofer, tracers, sn: %v", sn)
//						{
//							d := &MiniGun{
//								Device: &Device{
//									Conn: conn,
//									Sn:   sn,
//								},
//							}
//
//							strikeMode := GetBladerTimerRetDataObj().GetStrikeMode()
//							logger.Infof("when close connect, current strike mode: %v", strikeMode)
//							d.SendHitStop(uint8(strikeMode))
//							GetBladerTimerRetDataObj().SetStrikeMode(GunStatusNormal) //
//						}
//					}
//				}
//				return
//			}
//		}
//	})
//}
//func ReportDevStatus(s *server.TcpServer, conn net.Conn, sn string, closeCh chan struct{}) {
//	WriteMiniGunToDb(sn, conn)
//	ReportOnline(sn, closeCh)
//	SendHeartBeatWithFailCB(sn, conn, OnFailSendHeartBeat)
//	MonitorDevOffLine(s, conn, sn, closeCh)
//}
//
//func WriteMiniGunToDb(sn string, conn net.Conn) {
//	miniGun := &MiniGun{Device: &Device{
//		Conn:    conn,
//		Name:    "Blader",
//		DevType: common.Dev_Blader,
//	}}
//	ret := miniGun.GetStatus(sn)
//	fmt.Sprintf("get sn status: %v, sn: %v", ret, sn)
//}
//
//// ReportOnline 构建消息通知前端设备上线
//func ReportOnline(devSn string, closeCh chan struct{}) {
//	threading.GoSafe(func() {
//		tmr := time.NewTicker(100 * time.Millisecond)
//		defer tmr.Stop()
//
//		for {
//			select {
//			case <-tmr.C:
//				reportDevStatusWrapper(devSn, common.DevOnline)
//			case <-closeCh:
//				logger.Infof("report online stop, sn: %v, exit ", devSn)
//				return
//			}
//		}
//	})
//}
//func ReportOffLine(devSn string) {
//	reportDevStatusWrapper(devSn, common.DevOffline)
//}
//
//func MonitorDevOffLine(s *server.TcpServer, conn net.Conn, sn string, closeCh chan struct{}) {
//	select {
//	case <-closeCh:
//		logger.Infof("dev sn offline, sn: %v, del DevSnMap port: %v, remote addr: %v",
//			sn, s.Port, conn.RemoteAddr())
//
//		DevSnMap.Delete(s.Port)
//		cacheKey := fmt.Sprintf("%d_%s", common.Dev_Blader, sn)
//		DevStatusMap.Delete(cacheKey)
//		ReportOffLine(sn)
//	}
//}
//
//var countReport int = 0
//
//// reportDevStatusWrapper 上报设备状态
//func reportDevStatusWrapper(devSn string, status int32) {
//	dataInfo := &client.MiniGunStatusInfo{
//		Header: &client.EquipmentMessageBoxEntity{
//			Name:      devSn,
//			Sn:        devSn,
//			EquipType: int32(common.Dev_Blader),
//			MsgType:   mavlink.MiniGunStatus,
//		},
//		Data: &client.MiniGunStatusReport{
//			Sn:         devSn,
//			IsOnline:   status, //common.DevOnline,
//			BatteryCap: int32(GetBladerTimerRetDataObj().GetBatteryCap()),
//			Version:    GetBladerTimerRetDataObj().GetVersion(),
//			StrikeMode: int32(GetBladerTimerRetDataObj().GetStrikeMode()),
//		},
//	}
//	logger.Infof("report data: %v", dataInfo.Data)
//
//	msg, err := proto.Marshal(dataInfo)
//	if err != nil {
//		logger.Error("marshal dataInfo err:", err)
//		return
//	}
//	report := &client.ClientReport{
//		MsgType: common.ClientMsgMiniGunStatus,
//		Data:    msg,
//	}
//	out, err := proto.Marshal(report)
//	if err != nil {
//		logger.Error("marshal report err:", err)
//		return
//	}
//	mq.MiniGunStatusReportBroker.Publish(mq.MiniGunStatusTopic, broker.NewMessage(out))
//
//	if status == common.DevOnline {
//		countReport = countReport + 1
//	}
//	if countReport%10 == 0 {
//		logger.Infof("blader status report, sn:%v, status: %v,  reported: %v", devSn, status, report)
//	}
//}
//
//func DelTaskOnPort(conn net.Conn) {
//	remoteAddr := strings.Split(conn.RemoteAddr().String(), ":")
//	GWaitTaskMap.Delete(remoteAddr[0])
//}
//
//func QueryVersion(conn net.Conn) string {
//	miniGun := &MiniGun{Device: &Device{
//		Conn:    conn,
//		Name:    "Blader",
//		DevType: common.Dev_Blader,
//	}}
//
//	remoteAddr := strings.Split(conn.RemoteAddr().String(), ":")
//	var mailBox map[int]*WaitTaskManager
//	mbox, ok := GWaitTaskMap.Load(remoteAddr[0])
//	if !ok {
//		mailBox = make(map[int]*WaitTaskManager)
//		GWaitTaskMap.Store(remoteAddr[0], mailBox)
//		logger.Infof("QueryVersion remote addr: %v, %p", remoteAddr, mailBox)
//	} else {
//		mailBox = mbox.(map[int]*WaitTaskManager)
//		logger.Infof("has WaitTaskManager, remote addr: %v, %p", remoteAddr, mailBox)
//	}
//	miniGun.WaitTaskMap = mailBox
//
//	var version string = ""
//	for i := 0; i < 3; i++ {
//		version = miniGun.GetDevVersion()
//		if len(version) <= 0 {
//			logger.Infof("get gun version is empty")
//			time.Sleep(10 * time.Millisecond)
//			continue
//		}
//		break
//	}
//
//	logger.Infof("get mini gun version: %v", version)
//	return version
//}
//func QueryBatteryCap(conn net.Conn) int8 {
//	miniGun := &MiniGun{Device: &Device{
//		Conn:    conn,
//		Name:    "Blader",
//		DevType: common.Dev_Blader,
//	}}
//
//	remoteAddr := strings.Split(conn.RemoteAddr().String(), ":")
//	var mailBox map[int]*WaitTaskManager
//	mbox, ok := GWaitTaskMap.Load(remoteAddr[0])
//	if !ok {
//		mailBox = make(map[int]*WaitTaskManager)
//		GWaitTaskMap.Store(remoteAddr[0], mailBox)
//		logger.Infof("QueryBatteryCap remote addr: %v, %p", remoteAddr, mailBox)
//	} else {
//		mailBox = mbox.(map[int]*WaitTaskManager)
//		logger.Infof("has WaitTaskManager, remote addr: %v, %p", remoteAddr, mailBox)
//	}
//	miniGun.WaitTaskMap = mailBox
//
//	var capRet int8 = MiniGunBatteryCapInvalidVal
//	for i := 0; i < 3; i++ {
//		capRet = miniGun.GetBatteryCapacity()
//		if capRet <= MiniGunBatteryCapInvalidVal {
//			logger.Infof("get gun battery cap is empty")
//			time.Sleep(10 * time.Millisecond)
//			continue
//		}
//		break
//	}
//	logger.Infof("get mini gun battery cap: %v", capRet)
//	return capRet
//}
//
//var (
//	HasGetBladerVersion int32 = 0
//)
//
//func BatchTasks(connI1 net.Conn, snI2 string, closeCh chan struct{}) {
//	doTasks := func(conn net.Conn, sn string) (string, int8) {
//		var (
//			miniGunVersion         = ""
//			miniGunBatteryCap int8 = 0
//		)
//		wgWrap := threading.NewRoutineGroupWrap()
//
//		if atomic.LoadInt32(&HasGetBladerVersion) == 0 {
//			wgWrap.Run(func() {
//				miniGunVersion = QueryVersion(conn)
//				GetBladerTimerRetDataObj().SetVersion(miniGunVersion)
//				if len(miniGunVersion) > 0 {
//					atomic.StoreInt32(&HasGetBladerVersion, 1)
//				}
//			})
//		}
//
//		wgWrap.Run(func() {
//			time.Sleep(10 * time.Millisecond)
//			miniGunBatteryCap = QueryBatteryCap(conn)
//			GetBladerTimerRetDataObj().SetBatteryCap(miniGunBatteryCap)
//		})
//		wgWrap.Wait()
//
//		return miniGunVersion, miniGunBatteryCap
//	}
//
//	v, bc := doTasks(connI1, snI2)
//	logger.Infof("get version: %v, battery cap: %v, sn: %v", v, bc, snI2)
//
//	threading.GoSafe(func() {
//		tmr := time.NewTicker(10 * time.Second)
//		defer tmr.Stop()
//
//		for {
//			select {
//			case <-tmr.C:
//				doTasks(connI1, snI2)
//
//			case <-closeCh:
//				logger.Infof("batch query batch task exist, sn: %v, exit ", snI2)
//				return
//			}
//		}
//	})
//}

// BackendC2ToDev 设备连接c2后，c2 后端主动向设备发起的逻辑。
//func BackendC2ToDev(s *server.TcpServer, ctx context.Context, conn net.Conn, closeCh chan struct{}) {
//	sn, err := QuerySnOnMiniGun(s, ctx, conn)
//	if err != nil {
//		logger.Errorf("get sn fail, e: %v, need to restart it", err)
//		_ = <-closeCh
//		return
//	}
//
//	BatchTasks(conn, sn, closeCh)
//	ReportDevStatus(s, conn, sn, closeCh)
//}

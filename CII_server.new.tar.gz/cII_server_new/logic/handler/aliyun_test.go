package handler

import (
	"reflect"
	"testing"
	"time"

	"adasgitlab.autel.com/tools/cuav_server/entity/config"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/test"
	"github.com/agiledragon/gomonkey"
	"github.com/aliyun/alibaba-cloud-sdk-go/services/dysmsapi"
	"github.com/patrickmn/go-cache"
	"gopkg.in/gomail.v2"
)

func Test_aliSdk_CheckVerificationCode(t *testing.T) {
	type fields struct {
		verificationCodeCache    *cache.Cache
		verificationCodeReqCache *cache.Cache
	}
	type args struct {
		phoneOrEmail     string
		verificationCode string
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		wantErr bool
	}{
		{
			name: "Case1",
			fields: fields{
				verificationCodeCache:    cache.New(time.Minute*5, time.Minute*5),
				verificationCodeReqCache: cache.New(time.Minute*5, time.Minute*5),
			},
			args: args{
				phoneOrEmail:     "89765@qq.com",
				verificationCode: "success",
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			a := &aliSdk{
				verificationCodeCache:    tt.fields.verificationCodeCache,
				verificationCodeReqCache: tt.fields.verificationCodeReqCache,
			}
			a.verificationCodeCache.SetDefault("89765@qq.com", "success")
			if err := a.CheckVerificationCode(tt.args.phoneOrEmail, tt.args.verificationCode); (err != nil) != tt.wantErr {
				t.Errorf("aliSdk.CheckVerificationCode() error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

func Test_aliSdk_SendSms(t *testing.T) {
	test.LoggerMock()
	config.Global = &config.GlobalConfig{
		Sms: &config.Sms{
			AccessKeyId:        "accessKeyId",
			AccessKeySecret:    "accessKeySecret",
			SignName:           "signName",
			CnTemplatecode:     "cntemplateCode",
			AbroadTemplatecode: "abroadtemplateCode",
		},
	}
	//Mock依赖API
	d := &dysmsapi.Client{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(d), "SendSms", func(_ *dysmsapi.Client, request *dysmsapi.SendSmsRequest) (response *dysmsapi.SendSmsResponse, err error) {
		return nil, nil
	})
	patches.ApplyFunc(CreateRandCode, func() string {
		return "147588"
	})
	defer patches.Reset()

	type fields struct {
		verificationCodeCache    *cache.Cache
		verificationCodeReqCache *cache.Cache
	}
	type args struct {
		phone      string
		numberType int32
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    string
		wantErr bool
	}{
		{
			name: "Case1",
			fields: fields{
				verificationCodeCache:    cache.New(time.Minute*5, time.Minute*5),
				verificationCodeReqCache: cache.New(time.Minute*5, time.Minute*5),
			},
			args: args{
				phone:      "182345678",
				numberType: 1,
			},
			want:    "147588",
			wantErr: false,
		},
		{
			name: "Case2",
			fields: fields{
				verificationCodeCache:    cache.New(time.Minute*5, time.Minute*5),
				verificationCodeReqCache: cache.New(time.Minute*5, time.Minute*5),
			},
			args: args{
				phone:      "182345678",
				numberType: 2,
			},
			want:    "147588",
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			a := &aliSdk{
				verificationCodeCache:    tt.fields.verificationCodeCache,
				verificationCodeReqCache: tt.fields.verificationCodeReqCache,
			}
			got, err := a.SendSms(tt.args.phone, tt.args.numberType)
			if (err != nil) != tt.wantErr {
				t.Errorf("aliSdk.SendSms() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if got != tt.want {
				t.Errorf("aliSdk.SendSms() = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_aliSdk_SendEmail(t *testing.T) {
	config.Global = &config.GlobalConfig{
		Email: &config.Email{
			SmtpHost:     "smtpHost",
			SmtpPort:     1,
			Sender:       "sender",
			Password:     "password",
			EmailSubject: "emailSubject",
		},
	}
	//Mock依赖API
	d := &gomail.Dialer{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(d), "DialAndSend", func(_ *gomail.Dialer, m ...*gomail.Message) error {
		return nil
	})
	patches.ApplyFunc(CreateRandCode, func() string {
		return "147588"
	})
	defer patches.Reset()

	type fields struct {
		verificationCodeCache    *cache.Cache
		verificationCodeReqCache *cache.Cache
	}
	type args struct {
		email string
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    string
		wantErr bool
	}{
		{
			name: "Case1",
			fields: fields{
				verificationCodeCache:    cache.New(time.Minute*5, time.Minute*5),
				verificationCodeReqCache: cache.New(time.Minute*5, time.Minute*5),
			},
			args: args{
				email: "876e5t@autel.com",
			},
			want:    "147588",
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			a := &aliSdk{
				verificationCodeCache:    tt.fields.verificationCodeCache,
				verificationCodeReqCache: tt.fields.verificationCodeReqCache,
			}
			got, err := a.SendEmail(tt.args.email)
			if (err != nil) != tt.wantErr {
				t.Errorf("aliSdk.SendEmail() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if got != tt.want {
				t.Errorf("aliSdk.SendEmail() = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_aliSdk_NotifySms(t *testing.T) {
	test.LoggerMock()
	config.Global = &config.GlobalConfig{
		SmsNotify: &config.SmsNotify{
			AccessKeyId:     "accessKeyId",
			AccessKeySecret: "accessKeySecret",
			SignName:        "signName",
			TemplateCode: map[int32]string{
				1: "12325432677",
			},
		},
	}
	//Mock依赖API
	d := &dysmsapi.Client{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(d), "SendSms", func(_ *dysmsapi.Client, request *dysmsapi.SendSmsRequest) (response *dysmsapi.SendSmsResponse, err error) {
		return &dysmsapi.SendSmsResponse{
			Code: "OK",
		}, nil
	})
	defer patches.Reset()

	type fields struct {
		verificationCodeCache    *cache.Cache
		verificationCodeReqCache *cache.Cache
	}
	type args struct {
		req *client.SmsNotifyReq
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		wantErr bool
	}{
		{
			name: "Case1",
			fields: fields{
				verificationCodeCache:    cache.New(time.Minute*5, time.Minute*5),
				verificationCodeReqCache: cache.New(time.Minute*5, time.Minute*5),
			},
			args: args{
				req: &client.SmsNotifyReq{
					Phone:        "1823456789",
					TemplateType: 1,
				},
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			a := &aliSdk{
				verificationCodeCache:    tt.fields.verificationCodeCache,
				verificationCodeReqCache: tt.fields.verificationCodeReqCache,
			}
			if err := a.NotifySms(tt.args.req); (err != nil) != tt.wantErr {
				t.Errorf("aliSdk.NotifySms() error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

func Test_aliSdk_NotifyEmail(t *testing.T) {
	config.Global = &config.GlobalConfig{
		Email: &config.Email{
			SmtpHost:     "smtpHost",
			SmtpPort:     1,
			Sender:       "sender",
			Password:     "password",
			EmailSubject: "emailSubject",
		},
	}
	//Mock依赖API
	d := &gomail.Dialer{}
	patches := gomonkey.NewPatches()
	patches.ApplyMethod(reflect.TypeOf(d), "DialAndSend", func(_ *gomail.Dialer, m ...*gomail.Message) error {
		return nil
	})
	patches.ApplyFunc(CreateRandCode, func() string {
		return "147588"
	})
	defer patches.Reset()

	type fields struct {
		verificationCodeCache    *cache.Cache
		verificationCodeReqCache *cache.Cache
	}
	type args struct {
		req *client.NotifyReq
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		wantErr bool
	}{
		{
			name: "Case1",
			fields: fields{
				verificationCodeCache:    cache.New(time.Minute*5, time.Minute*5),
				verificationCodeReqCache: cache.New(time.Minute*5, time.Minute*5),
			},
			args: args{
				req: &client.NotifyReq{
					Email:        "865454@autel.com",
					TemplateType: 1,
				},
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			a := &aliSdk{
				verificationCodeCache:    tt.fields.verificationCodeCache,
				verificationCodeReqCache: tt.fields.verificationCodeReqCache,
			}
			if err := a.NotifyEmail(tt.args.req); (err != nil) != tt.wantErr {
				t.Errorf("aliSdk.NotifyEmail() error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

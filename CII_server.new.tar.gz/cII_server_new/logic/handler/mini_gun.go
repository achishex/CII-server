package handler

const (
	// 打击状态
	GunHitStatusOpen  = 1
	GunHitStatusClose = 0

	// 状态
	GunStatusNormal = 0
	GunStatusGnss   = 1
	GunStatusAll    = 2
	GunStatusSpoof  = 3
)

type eventIdType int32

var eventIdDes = map[int32]string{
	MinGunHitStartEventId: "gun hit begin",
	MinGunHitEndEventId:   "gun hit end",
}

const (
	MinGunHitStartEventId = 1000
	MinGunHitEndEventId   = 10001
)
const (
	BladerHitBegin = 1
	BladerHitEnd   = 2
)

//type MiniGun struct {
//	*Device
//	dt common.DeviceType
//}
//
//// NewMiniGun 创建设备对象，用于收到完整包的消息处理
//func NewMiniGun(conn Connection, d []byte, dataLen int, remoteIp string, remotePort int, localIp string, serverPort int,
//	mailBox map[int]*WaitTaskManager, dlimit *devLimit) DeviceInterface {
//	return &MiniGun{
//		Device: &Device{
//			Conn:        conn,
//			Msg:         d,
//			MsgLen:      dataLen,
//			SourceId:    d[mavlink.SenderLoc],
//			RemoteIp:    remoteIp,
//			RemotePort:  remotePort,
//			LocalIp:     localIp,
//			ServerPort:  serverPort,
//			WaitTaskMap: mailBox,
//		},
//	}
//}
//
//// getSn 根据mavlink头部的souceid获取sn, 映射关系在连接创建后获取设备sn时创建
//func (d *MiniGun) getSn(sourceId uint8) string {
//	if sn, ok := DevSnMap.Load(d.ServerPort); ok {
//		return sn.(string)
//	}
//	logger.Errorf("not find sn for sourceId: %v, tcpServerPort: %v", sourceId, d.ServerPort)
//	return ""
//}
//
//// GetPacket 只适用与固定长度的消息,interface、[]byte、嵌套结构体不支持
//func (d *MiniGun) GetPacket(message mavlink.Message) *mavlink.MavPacket {
//	logger.Infof("GetPacket is [% x]", d.Msg)
//	req := mavlink.NewNullPacket(message)
//	buff := &bytes.Buffer{}
//	if err := binary.Write(buff, binary.LittleEndian, d.Msg); err != nil {
//		logger.Error("GetPacket write buff err:", err)
//		return nil
//
//	}
//	if err := binary.Read(buff, binary.LittleEndian, &req.Header); err != nil {
//		logger.Error("GetPacket read header err:", err)
//		return nil
//	}
//	if err := binary.Read(buff, binary.LittleEndian, req.Msg); err != nil {
//		logger.Error("GetPacket read msg err:", err)
//		return nil
//	}
//	return req
//}
//
//// GetHitStatusReport 打击模式和状态上报
//func (d *MiniGun) GetHitStatusReport() error {
//	resp := &mavlink.MiniGunHitStatusReport{}
//	d.GetPacket(resp)
//
//	d.Sn = d.getSn(d.SourceId)
//	if len(d.Sn) > 0 {
//		logger.Infof("recv gun hit mode and status report, %v", resp)
//		if resp.StrikeStatus == GunHitStatusOpen {
//			logger.Infof("open spoof hit on gun, sn: %v", d.Sn)
//
//			d.SendHitStart(resp.StrikeMode)
//
//		} else if resp.StrikeStatus == GunHitStatusClose {
//			logger.Infof("close hit on gun, sn: %v", d.Sn)
//			//
//			d.SendHitStop(resp.StrikeMode)
//		}
//	}
//	return nil
//}
//
//func (d *MiniGun) RecvHeartBeat() error {
//	resp := &mavlink.MiniGunHeartBeatResp{}
//	d.GetPacket(resp)
//	logger.Infof("接收心跳回报, sn: %v", d.Sn)
//
//	manager, ok := d.WaitTaskMap[mavlink.MiniGunHeartBeat]
//	if ok {
//		logger.Infof("send complete task.")
//		manager.CompletedTask(resp, nil)
//	} else {
//		logger.Infof("not exist task for cmd: %x", mavlink.MiniGunHeartBeat)
//	}
//	return nil
//}
//
//// RecvGetSn 查询 sn 回报处理
//func (d *MiniGun) RecvGetSn() error {
//	resp := &mavlink.MiniGunFetchSnResp{}
//	d.GetPacket(resp)
//
//	logger.Infof("接收 get sn: %+v", resp)
//	manager, ok := d.WaitTaskMap[mavlink.MiniGunGetSn]
//	if ok {
//		logger.Infof("send complete task.")
//		manager.CompletedTask(resp, nil)
//	} else {
//		logger.Infof("not exist task for cmd: %x", mavlink.MiniGunGetSn)
//	}
//	return nil
//}
//
//// RecvGetVersionRsp 获取版本号回报
//func (d *MiniGun) RecvGetVersionRsp() error {
//	resp := &mavlink.MiniGunVersionResp{}
//	d.GetPacket(resp)
//
//	logger.Infof("接收 get version: %+v", resp)
//	manager, ok := d.WaitTaskMap[mavlink.MiniGunGetVersion]
//	if ok {
//		logger.Infof("send complete task.")
//		manager.CompletedTask(resp, nil)
//	} else {
//		logger.Infof("not exist task for cmd: %x", mavlink.MiniGunGetVersion)
//	}
//	return nil
//}
//
//// RecvGetBatteryCapRsp 获取电池量回报
//func (d *MiniGun) RecvGetBatteryCapRsp() error {
//	resp := &mavlink.MiniGunBatteryCapResp{}
//	d.GetPacket(resp)
//
//	logger.Infof("接收 get battery cap: %+v", resp)
//	manager, ok := d.WaitTaskMap[mavlink.MiniGunGetBatteryCap]
//	if ok {
//		logger.Infof("send complete task.")
//		manager.CompletedTask(resp, nil)
//	} else {
//		logger.Infof("not exist task for cmd: %x", mavlink.MiniGunGetBatteryCap)
//	}
//	return nil
//}
//
//// Deal 设备消息的处理函数
//func (d *MiniGun) Deal() {
//	if d.MsgLen <= 0 {
//		logger.Error("数据为null,不作处理: ", d.Device.RemoteIp)
//		return
//	}
//
//	msgId := d.Msg[mavlink.MsgIdLoc]
//	switch msgId {
//	case mavlink.MiniGunUpdateStatus:
//		d.GetHitStatusReport()
//
//	case mavlink.MiniGunGetSn:
//		d.RecvGetSn()
//
//	case mavlink.MiniGunHeartBeat:
//		d.RecvHeartBeat()
//
//	case mavlink.MiniGunGetVersion:
//		d.RecvGetVersionRsp()
//
//	case mavlink.MiniGunGetBatteryCap:
//		d.RecvGetBatteryCapRsp()
//
//	default:
//		logger.Errorf("mini gun 未知消息id: %x", msgId)
//		break
//	}
//}
//
//// SendStartHitToSpoofer mini gun 开始打击时给 spoofer 发送的指令 0:成功 -1:至少有一个失败，调用所有接口
//func SendStartHitToSpoofer() int32 {
//	var result int32
//	DevStatusNfsMap.Range(func(key, devP any) bool {
//		req := &client.InduceRequest{}
//		req.Enable = true
//		req.WorkMode = int32(config.DIRECTIONALDRIVE)
//		req.Angle = -1
//		req.DriveVerticalSpeed = 5
//		logger.Debug("SendStartHitToSpoofer = ", req)
//		if dev2, ok := devP.(*ControllerNSFGXW); ok {
//			logger.Debug("NSFGXW dev  = ", dev2)
//			ret := dev2.SetPlay(req)
//			if ret != 0 {
//				result = int32(ret)
//			}
//			logger.Debug(" ret = ", ret, " result = ", result)
//		}
//		return true
//	})
//	return result
//}
//
//// SendStopHitToSpoofer mini gun 结束打击时给 spoofer 发送的指令 0:成功 -1:至少有一个失败，调用所有接口
//func SendStopHitToSpoofer() int32 {
//	var result int32
//	DevStatusNfsMap.Range(func(key, devP any) bool {
//		req := &client.InduceRequest{}
//		req.Enable = false
//		if dev2, ok := devP.(*ControllerNSFGXW); ok {
//			logger.Debug("NSFGXW dev dev2 ", dev2)
//			ret := dev2.SetPlay(req)
//			if ret != 0 {
//				result = int32(ret)
//			}
//			logger.Debug(" ret = ", ret, " result = ", result)
//		}
//		return true
//	})
//
//	return result
//}
//
//// SendStartHitToTracers mini gun 开始打击时给 tracers 发送的指令
//func SendStartHitToTracers() int32 {
//	for _, tracerSn := range GetTracerOnLineTracer() {
//		tracerDev := FindCacheDevice(tracerSn, common.DEV_V2DRONEID)
//		if tracerDev == nil {
//			continue
//		}
//
//		dev := &DroneID{
//			Device: tracerDev,
//		}
//		dev.SetRadioFreq(RFreqClose)
//	}
//	return 0
//}
//
//// SendStopHitToTracers mini gun 结束打击时给 tracers 发送的指令
//func SendStopHitToTracers() int32 {
//	for _, tracerSn := range GetTracerOnLineTracer() {
//		tracerDev := FindCacheDevice(tracerSn, common.DEV_V2DRONEID)
//		if tracerDev == nil {
//			continue
//		}
//
//		dev := &DroneID{
//			Device: tracerDev,
//		}
//		dev.SetRadioFreq(RFreqOpen)
//	}
//	return 0
//}
//
//// GetLongLat 获取当前经纬度
//func (d *MiniGun) GetLongLat() (float64, float64, error) {
//	configInfo := &client.ConfigRes{}
//	e := NewSystemConfig().GetSystemConfig(context.Background(), nil, configInfo)
//	return configInfo.C2Longitude, configInfo.C2Latitude, e
//}
//
//// ReportHitStatus 上报打击状态， op: 1 开始打击，2： 结束打击
//func ReportHitStatus(sn string, op int32) {
//	dataInfo := &client.BladerHitStatusInfo{
//		Header: &client.EquipmentMessageBoxEntity{
//			Name:      sn,
//			Sn:        sn,
//			EquipType: int32(common.Dev_Blader),
//			MsgType:   mavlink.MiniGunHitBegin,
//		},
//		Data: &client.BladerHitItem{
//			Sn:        sn,
//			HitStatus: op,
//		},
//	}
//	msg, err := proto.Marshal(dataInfo)
//	if err != nil {
//		logger.Error("marshal dataInfo err:", err)
//		return
//	}
//	report := &client.ClientReport{
//		MsgType: common.ClientMsgMiniGunHitStatus,
//		Data:    msg,
//	}
//	out, err := proto.Marshal(report)
//	if err != nil {
//		logger.Error("marshal report err:", err)
//		return
//	}
//	mq.MiniGunHitReportBroker.Publish(mq.MiniGunHitTopic, broker.NewMessage(out))
//	logger.Infof("blader report hit status, sn:%v, op: %v,  reported: %v", sn, op, report)
//}
//
//// SendHitStart mini gun 开始打击时 发送命令
//func (d *MiniGun) SendHitStart(strikeMode uint8) {
//	var (
//		sendStartSpooferRet int32 = 0
//		sendStartTracerRet  int32 = 0
//	)
//	GetBladerHitStatusObj().BeginHit()
//
//	wgWrap := threading.NewRoutineGroupWrap()
//
//	wgWrap.Run(func() {
//		if strikeMode != GunStatusSpoof {
//			logger.Infof("blader not spoofer mode, need not to send start to spoofer device, mode: %v", strikeMode)
//			return
//		}
//
//		logger.Info("begin to send start hit cmd to spoofer.")
//		SendStopHitToSpoofer()
//		sendStartSpooferRet = SendStartHitToSpoofer()
//	})
//	wgWrap.Run(func() {
//		sendStartTracerRet = SendStartHitToTracers()
//	})
//	wgWrap.Wait()
//
//	if strikeMode == GunStatusSpoof {
//		logger.Infof("end send start hit cmd to spoofer.")
//	}
//
//	threading.GoSafe(func() {
//		lon, lat, _ := d.GetLongLat()
//		item := &bean.NavyGunSpooferLog{
//			Sn:               d.Sn, //
//			DevDescription:   "Blader",
//			EventId:          MinGunHitStartEventId,
//			EventDescription: eventIdDes[MinGunHitStartEventId],
//			Longitude:        lon,
//			Latitude:         lat,
//			CreateTime:       time.Now().UnixMilli(),
//		}
//
//		if strikeMode == GunStatusSpoof {
//			item.InterferenceSignalStart = time.Now().UnixMilli()
//			item.EventDescription += ", and induce begin."
//		}
//		NewNavySpooferUnionActionLog(1).PubLog(item)
//	})
//
//	threading.GoSafe(func() {
//		ReportHitStatus(d.Sn, BladerHitBegin)
//	})
//
//	if sendStartSpooferRet != 0 {
//		logger.Errorf("send to spoofer start fail, code: %v", sendStartSpooferRet)
//	}
//	if sendStartTracerRet != 0 {
//		logger.Errorf("send to tracer start fail, code: %v", sendStartTracerRet)
//	}
//}
//
//// SendHitStop mini gun结束打击 发送命令
//func (d *MiniGun) SendHitStop(strikeMode uint8) {
//	var (
//		sendStopSpooferRet int32 = 0
//		sendStopTracerRet  int32 = 0
//	)
//	GetBladerHitStatusObj().EndHit()
//
//	wgWrap := threading.NewRoutineGroupWrap()
//
//	wgWrap.Run(func() {
//		if strikeMode != GunStatusSpoof {
//			logger.Infof("blader not spoofer mode, need not to send end to spoofer device, mode: %v", strikeMode)
//			return
//		}
//		logger.Infof("begin to send stop hit cmd to spoofer")
//		sendStopSpooferRet = SendStopHitToSpoofer()
//	})
//	wgWrap.Run(func() {
//		sendStopTracerRet = SendStopHitToTracers()
//	})
//	wgWrap.Wait()
//
//	if strikeMode == GunStatusSpoof {
//		logger.Infof("end send stop hit cmd to spoofer.")
//	}
//
//	threading.GoSafe(func() {
//		lon, lat, _ := d.GetLongLat()
//		item := &bean.NavyGunSpooferLog{
//			Sn:               d.Sn,
//			DevDescription:   "Blader",
//			EventId:          MinGunHitEndEventId,
//			EventDescription: eventIdDes[MinGunHitEndEventId],
//			Longitude:        lon,
//			Latitude:         lat,
//			CreateTime:       time.Now().UnixMilli(),
//		}
//
//		if strikeMode == GunStatusSpoof {
//			item.EventDescription += ", induce end."
//		}
//		NewNavySpooferUnionActionLog(1).PubLog(item)
//	})
//
//	threading.GoSafe(func() {
//		ReportHitStatus(d.Sn, BladerHitEnd)
//	})
//
//	if sendStopSpooferRet != 0 {
//		logger.Errorf("send to spoofer stop fail, code: %v", sendStopSpooferRet)
//	}
//	if sendStopTracerRet != 0 {
//		logger.Errorf("send to tracer stop fail, code: %v", sendStopTracerRet)
//	}
//}
//
//// QueryDevSn 对外提供 调用接口。主动查询设备 sn; 使用和上位机一样的机制和 mini gun 通信
//func (d *MiniGun) QueryDevSn() string {
//	request := &mavlink.MiniGunFetchSnReq{}
//	buff := request.Create()
//
//	logger.Debugf("mini gun get sn req buff: % x", buff)
//	if _, err := d.Conn.Write(buff); err != nil {
//		logger.Error("mini gun get sn 信息失败: ", err)
//		return ""
//	}
//
//	// 先创建接受返回结果的任务
//	waitTime := time.Millisecond * 100
//	manager, ok := d.WaitTaskMap[mavlink.MiniGunGetSn]
//	if !ok {
//		manager = NewWaitTaskManager(mavlink.MiniGunGetSn, true, waitTime)
//		d.WaitTaskMap[mavlink.MiniGunGetSn] = manager
//		logger.Infof("not find task for cmd: %x, register it", mavlink.MiniGunGetSn)
//	}
//	resp, err := manager.Wait()
//	if err != nil {
//		logger.Infof("wait get sn fail, wait time: %v millisecond, e: %v", waitTime/time.Millisecond, err)
//		return ""
//	}
//	result := resp.(*mavlink.MiniGunFetchSnResp)
//	if result == nil {
//		logger.Errorf("get sn fail, ret is nil")
//		return ""
//	}
//
//	sn := ByteToString(result.Sn[:])
//	if len(sn) <= 0 {
//		logger.Infof("get gun sn is empty")
//		return ""
//	}
//	logger.Infof("get sn: %v", sn)
//	return sn
//}
//
//var (
//	tmpInvalilid atomic.Int32
//)
//
//// SendHeartBeat 发送心跳包，需要回报
//func (d *MiniGun) SendHeartBeat(wtm int32) int32 {
//	request := &mavlink.MiniGunHeartBeatReq{}
//	buff := request.Create()
//
//	beginTime := time.Now()
//	defer func() {
//		logger.Infof("cost time: %v, index begin: %v", time.Now().Sub(beginTime), tmpInvalilid.Load())
//		tmpInvalilid.Add(1)
//	}()
//
//	logger.Debugf("index begin: %v, mini gun send heart beat req buff: % x", tmpInvalilid.Load(), buff)
//
//	if _, err := d.Conn.Write(buff); err != nil {
//		logger.Error("mini gun get sn 信息失败: ", err)
//		return -1
//	}
//	// 先创建接受返回结果的任务
//	waitTime := time.Duration(wtm) * time.Millisecond
//	//
//	manager, ok := d.WaitTaskMap[mavlink.MiniGunHeartBeat]
//	if !ok {
//		manager = NewWaitTaskManager(mavlink.MiniGunHeartBeat, true, waitTime)
//		d.WaitTaskMap[mavlink.MiniGunHeartBeat] = manager
//		logger.Infof("not find task for cmd: %x, register it", mavlink.MiniGunHeartBeat)
//	}
//	resp, err := manager.Wait()
//	if err != nil {
//		logger.Infof("wait heartbeat response fail, wait time1: %v millisecond, e: %v", waitTime, err)
//		return -1
//	}
//	//
//	result := resp.(*mavlink.MiniGunHeartBeatResp)
//	if result == nil {
//		logger.Errorf("get heartbeat, ret is nil")
//		return -1
//	}
//	logger.Infof("heartBeat ret: %+v", result)
//
//	GetBladerTimerRetDataObj().SetStrikeMode(int8(result.StrikeMode))
//	return 0
//}
//
//// GetStatus 获取设备状态
//func (d *MiniGun) GetStatus(sn string) int32 {
//	statusRes := &client.GetStatusRes{}
//	err := NewEquipList().GetStatus(context.Background(), &client.GetStatusReq{Sn: sn, EType: "Blader"}, statusRes)
//	if err != nil {
//		logger.Errorf("GetStatus err: %v", err.Error())
//		return 0
//	}
//	return statusRes.IsEnable
//}
//
//// GetDevVersion 获取固件版本号
//func (d *MiniGun) GetDevVersion() string {
//	request := &mavlink.MiniGunVersionReq{}
//	buff := request.Create()
//
//	logger.Debugf("mini gun get version req buff: % x", buff)
//	if _, err := d.Conn.Write(buff); err != nil {
//		logger.Error("mini gun get version 信息失败: ", err)
//		return ""
//	}
//
//	// 先创建接受返回结果的任务
//	waitTime := time.Millisecond * 100
//	manager, ok := d.WaitTaskMap[mavlink.MiniGunGetVersion]
//	if !ok {
//		manager = NewWaitTaskManager(mavlink.MiniGunGetVersion, true, waitTime)
//		d.WaitTaskMap[mavlink.MiniGunGetVersion] = manager
//		logger.Infof("not find task for cmd: %x, register it", mavlink.MiniGunGetVersion)
//	}
//	resp, err := manager.Wait()
//	if err != nil {
//		logger.Infof("wait get sn fail, wait time: %v millisecond, e: %v", waitTime/time.Millisecond, err)
//		return ""
//	}
//	result := resp.(*mavlink.MiniGunVersionResp)
//	if result == nil {
//		logger.Errorf("get version fail, ret is nil")
//		return ""
//	}
//
//	version := ByteToString(result.Version[:])
//	if len(version) <= 0 {
//		logger.Infof("get gun version is empty")
//		return ""
//	}
//	logger.Infof("get version: %v", version)
//	return version
//}
//
//// GetBatteryCapacity 电池电量百分比
//func (d *MiniGun) GetBatteryCapacity() int8 {
//	request := &mavlink.MiniGunBatteryCapReq{}
//	buff := request.Create()
//
//	logger.Debugf("mini gun get battery cap req buff: % x", buff)
//	if _, err := d.Conn.Write(buff); err != nil {
//		logger.Error("mini gun get battery cap 信息失败: ", err)
//		return MiniGunBatteryCapInvalidVal
//	}
//
//	// 先创建接受返回结果的任务
//	waitTime := time.Millisecond * 100
//	manager, ok := d.WaitTaskMap[mavlink.MiniGunGetBatteryCap]
//	if !ok {
//		manager = NewWaitTaskManager(mavlink.MiniGunGetBatteryCap, true, waitTime)
//		d.WaitTaskMap[mavlink.MiniGunGetBatteryCap] = manager
//		logger.Infof("not find task for cmd: %x, register it", mavlink.MiniGunGetBatteryCap)
//	}
//	resp, err := manager.Wait()
//	if err != nil {
//		logger.Infof("wait get battery cap fail, wait time: %v millisecond, e: %v", waitTime, err)
//		return MiniGunBatteryCapInvalidVal
//	}
//	result := resp.(*mavlink.MiniGunBatteryCapResp)
//	if result == nil {
//		logger.Errorf("get battery cap fail, ret is nil")
//		return MiniGunBatteryCapInvalidVal
//	}
//
//	logger.Infof("get battery cap: %v", result.BatteryCap)
//	return int8(result.BatteryCap)
//}

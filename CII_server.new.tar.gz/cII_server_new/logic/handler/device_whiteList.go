package handler

import (
	"context"
	"fmt"
	"strconv"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"github.com/360EntSecGroup-Skylar/excelize"
	"github.com/tealeg/xlsx"

	"adasgitlab.autel.com/tools/cuav_server/proto/client"
)

const (
	DataRowNumBeginInExcel = 2
)

// 导出白名单
func (e *DeviceCenter) ExportWhiteList(ctx context.Context, req *client.ExportWhiteListRequest, rsp *client.ExportWhiteListResponse) error {
	logger.Info("-->Into Export White List")
	file := excelize.NewFile()

	sheetName := file.GetSheetName(1) // 获取第一个表格的名称
	if sheetName != "white_list" {
		file.SetSheetName(sheetName, "white_list") // 将表格名称修改为 white_list
	}

	file.SetCellValue("white_list", "A1", "Sn")
	file.SetCellValue("white_list", "B1", "Vendor")
	file.SetCellValue("white_list", "C1", "Model")
	file.SetCellValue("white_list", "D1", "Frequency")
	//
	file.SetCellValue("white_list", "E1", "UseName")
	file.SetCellValue("white_list", "F1", "Usage")
	file.SetCellValue("white_list", "G1", "UsageDesc")
	file.SetCellValue("white_list", "H1", "Remarks")

	listinfo := &client.WhiteListRes{}
	err := NewWhiteList().List(ctx, &client.WhiteListReq{}, listinfo)
	if err != nil {
		logger.Error("-->get whitelist err:", err)
		rsp.Result = false
		return nil
	}

	for i, list := range listinfo.WhiteList {
		rowNum := i + DataRowNumBeginInExcel
		file.SetCellValue("white_list", fmt.Sprintf("A%d", rowNum), list.Sn)
		file.SetCellValue("white_list", fmt.Sprintf("B%d", rowNum), list.Vendor)
		file.SetCellValue("white_list", fmt.Sprintf("C%d", rowNum), list.Model)
		file.SetCellValue("white_list", fmt.Sprintf("D%d", rowNum), list.Frequency)
		//
		file.SetCellValue("white_list", fmt.Sprintf("E%d", rowNum), list.UserName)
		file.SetCellValue("white_list", fmt.Sprintf("F%d", rowNum), list.Usage)
		file.SetCellValue("white_list", fmt.Sprintf("G%d", rowNum), list.UsageDesc)
		file.SetCellValue("white_list", fmt.Sprintf("H%d", rowNum), list.Remarks)
	}

	if err = file.SaveAs(req.Path); err != nil {
		logger.Error("-->SaveAs whitelist err:", err)
		rsp.Result = false
		return nil
	}
	logger.Info("-->End Export White List")
	rsp.Result = true
	return nil
}

type WhiteListRecord struct {
	Sn        string
	Vendor    string
	Model     string
	Frequency string
	UseName   string
	Usage     int32
	UsageDesc string
	Remarks   string
}

// 导入白名单
func (e *DeviceCenter) ImportWhiteList(ctx context.Context, req *client.ImportWhiteListRequest, rsp *client.ImportWhiteListResponse) error {
	logger.Info("-->Into Import White List")
	// 打开 excel 文件
	file, err := xlsx.OpenFile(req.Path)
	if err != nil {
		logger.Error("Error opening file:", err)
		rsp.Result = false
		return nil
	}
	// 读取工作表
	sheet := file.Sheets[0]

	success := 0
	fail := 0
	rsp.Result = true
	// 遍历行并解析数据
	var record []WhiteListRecord
	for i, row := range sheet.Rows {
		// 跳过标题行
		if i == 0 {
			continue
		}
		// 解析数据
		recordTemp := WhiteListRecord{
			Sn:        row.Cells[0].Value,
			Vendor:    row.Cells[1].Value,
			Model:     row.Cells[2].Value,
			Frequency: row.Cells[3].Value,
			//
			UseName:   row.Cells[4].Value,
			UsageDesc: row.Cells[6].Value,
			Remarks:   row.Cells[7].Value,
		}
		usage, _ := strconv.Atoi(row.Cells[5].Value)
		recordTemp.Usage = int32(usage)

		if row.Cells[0].Value == "" {
			fail++
		} else {
			success++
			record = append(record, recordTemp)
		}

	}
	for _, recordInfo := range record {
		err = NewWhiteList().Insert(ctx, &client.WhiteCrudReq{
			Vendor:    recordInfo.Vendor,
			Model:     recordInfo.Model,
			Frequency: recordInfo.Frequency,
			Sn:        recordInfo.Sn,
			Role:      2, // 无人机角色： 1-敌军 2-友军 3-未知 4-中立     批量导入为2友军
			UserName:  recordInfo.UseName,
			Usage:     recordInfo.Usage,
			UsageDesc: recordInfo.UsageDesc,
			Remarks:   recordInfo.Remarks,
		}, &client.WhiteCrudRes{})
		if err != nil {
			logger.Error("-->get Insert err:", err)
			rsp.Result = false
			return nil
		}
	}
	rsp.Fail = int32(fail)
	rsp.Success = int32(success)
	logger.Info("-->End Import White List:", record)

	logger.Info("-->End Import White List")
	return nil
}

package handler

import (
	"bytes"
	"context"
	"crypto/rand"
	"encoding/binary"
	"errors"
	"fmt"
	"math/big"
	"sync"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/server"
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/ip"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/proto/mavlink"
	"adasgitlab.autel.com/tools/slink_proto/slinkv1"
)

var (
	spooferMonitorResOnce sync.Once
	spooferMonitorResItem *SpooferMonitorResManager = nil

	spooferMonitorSum          uint8 = 0
	SpooferMonitorTcpServerMap sync.Map
)

const (
	spooferMonitorTcpPort      = 17000
	spooferMonitorMaxCount     = 500
	spooferMonitorReducedValue = 64 //2的6次方,Agx上报数值扩大值
)

// GetSpooferMonitorRes 获取监控状态句柄（单例）
func GetSpooferMonitorRes() *SpooferMonitorResManager {
	spooferMonitorResOnce.Do(func() {
		spooferMonitorResItem = NewSpooferMonitorResManagerr()
	})
	return spooferMonitorResItem
}

type SpooferMonitorResManager struct {
	batteryCap int8 // 电量百分比
	lk         sync.RWMutex
}

func NewSpooferMonitorResManagerr() *SpooferMonitorResManager {
	return &SpooferMonitorResManager{
		batteryCap: 0,
	}
}

func (p *SpooferMonitorResManager) SetBatteryCap(v int32) bool {
	if p == nil {
		return false
	}
	//
	if v < 0 || v > 100 {
		return false
	}
	p.lk.Lock()
	defer p.lk.Unlock()

	p.batteryCap = int8(v)
	return true
}
func (p *SpooferMonitorResManager) GetBatteryCap() int8 {
	if p == nil {
		return 0
	}

	p.lk.RLock()
	defer p.lk.RUnlock()
	return p.batteryCap
}

// HandleBroadCast 处理广播消息
func (d *SpooferMonitor) HandleBroadCast(_ context.Context, req *slinkv1.UdpBroadcastConfirmRequest) (*slinkv1.UdpBroadcastConfirmResponse, error) {
	if req.GetSn() == "" {
		logger.Info("device sn empty")
		return nil, errors.New("device sn empty")
	}
	d.GetStatus(req.GetSn())

	localIP := make([]string, 0)
	localIps, broadIps, err := ip.GetBroadcastAddress()
	if err != nil {
		logger.Error("Get IP error :%v", err)
	}
	for i, ip := range localIps {
		if i >= len(broadIps) {
			continue
		}
		localIP = append(localIP, ip)
	}
	logger.Debugf("[SpooferMonitor] localIP:%v,", localIP)

	tcpServer := d.TcpServerCheck(req.GetSn(), localIP)
	DevSnMap.Store(tcpServer.Port, req.GetSn())
	d.ServerPort = tcpServer.Port

	//响应
	rsp := &slinkv1.UdpBroadcastConfirmResponse{
		Sn:       req.Sn,
		Addr:     ip.IPV4(tcpServer.Ip),
		Port:     uint16(tcpServer.Port),
		ConnType: 1,
	}
	return rsp, nil
}

func (d *SpooferMonitor) getRandPort(min, max int64) int {
	maxBigInt := big.NewInt(max)
	i, _ := rand.Int(rand.Reader, maxBigInt)
	_, ok := deviceUsedPorts.Load(i.Int64())
	port := i.Int64()
	//缓存不存在或者符合范围
	if !ok && (port > min && port < max) {
		deviceUsedPorts.Store(port, port)
		return int(port)
	}
	return d.getRandPort(min, max)
}

func (d *SpooferMonitor) TcpServerCheck(devSn string, localIP []string) *server.TcpServer {
	var tcpServer *server.TcpServer
	if s, ok := SpooferMonitorTcpServerMap.Load(devSn); ok {
		tcpServer = s.(*server.TcpServer)
		isAlike := false
		for _, ip := range localIP {
			if ip == tcpServer.Ip {
				isAlike = true
			}
		}
		if isAlike == false { //查找的本地IP没有与之前相同的
			if tcpServer != nil {
				tcpServer.Stop()
			}
			deviceUsedPorts.Delete(tcpServer.Port)
			SpooferMonitorTcpServerMap.Delete(devSn)
			DevSnMap.Delete(tcpServer.Port)
			tcpServer = nil
		}
	}

	//注册tcp服务
	if tcpServer == nil {
		port, err := ip.GetFreeTcpPort()
		if err != nil {
			logger.Error("Sfl tcp 获取可用端口失败：", err)
			port = d.getRandPort(spooferMonitorTcpPort, spooferMonitorTcpPort+spooferMonitorMaxCount)
		}
		tcpServer = server.NewTcpServer(port, Handle)
		SpooferMonitorTcpServerMap.Store(devSn, tcpServer)
		tcpServer.ServerType = uint8(common.DEV_SPOOFER_MONITOR)
		tcpServer.ServerName = devSn
		localAddr, _ := ip.GetLocalIp(d.UdpIp)
		tcpServer.Ip = localAddr
		go tcpServer.Start()
	}
	return tcpServer
}

type SpooferMonitor struct {
	*Device
	dt common.DeviceType
}

func NewSpooferMonitor(conn Connection, d []byte, dataLen int, remoteIp string, remotePort int, localIp string, serverPort int,
	mailBox map[int]*WaitTaskManager, dlimit *devLimit) DeviceInterface {

	spooferMonitor := &SpooferMonitor{
		Device: &Device{
			Conn:        conn,
			Msg:         d,
			MsgLen:      dataLen,
			SourceId:    d[mavlink.SenderLoc],
			RemoteIp:    remoteIp,
			RemotePort:  remotePort,
			LocalIp:     localIp,
			ServerPort:  serverPort,
			WaitTaskMap: mailBox,
		},
	}
	return spooferMonitor
}

// Deal spoofer 属性采集器消息处理汇总
func (d *SpooferMonitor) Deal() {
	defer func() {
		if err := recover(); err != nil {
			logger.Error("SpooferMonitor deal 接收到panic:", err)
		}
	}()

	if d.MsgLen <= 0 {
		logger.Error("SpooferMonitor 数据为null,不作处理:", d.Device.RemoteIp)
		return
	}
	d.MsgId = int(d.Msg[mavlink.MsgIdLoc])
	switch d.MsgId {
	case mavlink.HeartBeatFromDevToC2:
		d.HeartBeat()

	case mavlink.PropertyReport:
		d.PropertyReport()
	default:
		logger.Errorf("unknown cmd: 0x%x", d.MsgId)
	}
}

func (d *SpooferMonitor) GetStatus(sn string) int32 {
	statusRes := &client.GetStatusRes{}
	err := NewEquipList().GetStatus(context.Background(), &client.GetStatusReq{Sn: sn, EType: "SpooferMonitor"}, statusRes)
	if err != nil {
		logger.Errorf("GetStatus err: %v", err.Error())
		return 0
	}

	return statusRes.IsEnable
}

// updateStatus 更新状态
func (d *SpooferMonitor) updateStatus(sn string) int32 {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_SPOOFER_MONITOR, sn)
	if cache, ok := DevStatusMap.Load(cacheKey); ok {
		dev := cache.(*Device)
		dev.Status = common.DevOnline
		dev.Conn = d.Conn
		dev.WaitTaskMap = d.WaitTaskMap
		dev.RemoteIp = d.RemoteIp
		dev.LastHeartTime = time.Now()
		dev.GetStatusInterval = time.Now()
		return common.DeviceEnable
	} else {
		dev := &Device{
			Sn:                sn,
			Conn:              d.Conn,
			Status:            common.DevOnline,
			RemoteIp:          d.RemoteIp,
			RemotePort:        d.RemotePort,
			LocalIp:           d.LocalIp,
			ServerPort:        d.ServerPort,
			DevType:           common.DEV_SPOOFER_MONITOR,
			FirstHeartTime:    time.Now(),
			LastHeartTime:     time.Now(),
			SourceId:          d.SourceId,
			IsEnable:          d.GetStatus(sn),
			GetStatusInterval: time.Now(),
			WaitTaskMap:       d.WaitTaskMap,
		}
		DevStatusMap.Store(cacheKey, dev)

		logger.Infof("heartbeat spoofer monitor data: %v", dev)
		return dev.IsEnable
	}
}

// SendSpooferMonitorHeart c2主动向发送给spoofer属性采集器心跳
func SendSpooferMonitorHeart() {
	t2 := time.NewTicker(time.Second)
	defer t2.Stop()
	for range t2.C {
		DevStatusMap.Range(func(key, value interface{}) bool {
			dev := value.(*Device)
			if dev.DevType == common.DEV_SPOOFER_MONITOR && dev.Status == common.DevOnline {
				reqMode := &SpooferMonitor{
					Device: dev,
					dt:     common.DEV_SPOOFER_MONITOR,
				}
				reqMode.SendExtHeartbeat()
			}
			return true
		})
	}
}

func (d *SpooferMonitor) UnmarshalPayload(data *mavlink.SMHeartBeat) error {
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("SpooferMonitor UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, data); err != nil {
		return fmt.Errorf("SpooferMonitor UnmarshalPayload read data err: %v", err)
	}
	return nil
}

// HeartBeat spoofer属性采集器的心跳包处理函数
func (d *SpooferMonitor) HeartBeat() {
	heart := &mavlink.SMHeartBeat{}
	if err := d.UnmarshalPayload(heart); err != nil {
		logger.Errorf(err.Error())
		return
	}

	devSn := ByteToString(heart.Sn[:])
	if len(devSn) <= 0 {
		return
	}
	d.updateStatus(devSn)
}

func (d *SpooferMonitor) SendExtHeartbeat() {
	req := &mavlink.SMHeartBeatExtRequest{}
	req.Sum = spooferMonitorSum
	spooferMonitorSum++

	reqBuff := req.CreateSMHeartBeatExt()
	if d != nil && d.Conn != nil {
		_, err := d.Conn.Write(reqBuff)
		logger.Infof("SpooferMonitor c2发送心跳结果：%X", reqBuff)

		if err != nil {
			cacheKey := fmt.Sprintf("%d_%s", common.DEV_SPOOFER_MONITOR, d.Sn)
			logger.Errorf("offline, send heart to spoofer monitor, sn: %v, fail, err: %v", cacheKey, err)
			DevStatusMap.Delete(cacheKey)
		}
	}
}

func (d *SpooferMonitor) GetPacket(message mavlink.Message) *mavlink.MavPacket {
	logger.Infof("SpooferMonitor  GetPacket is [% x]", d.Msg)
	req := mavlink.NewNullPacket(message)
	buff := &bytes.Buffer{}
	if err := binary.Write(buff, binary.LittleEndian, d.Msg); err != nil {
		logger.Error("SpooferMonitor GetPacket write buff err:", err)
		return nil

	}
	if err := binary.Read(buff, binary.LittleEndian, &req.Header); err != nil {
		logger.Error("SpooferMonitor GetPacket read header err:", err)
		return nil
	}
	if err := binary.Read(buff, binary.LittleEndian, req.Msg); err != nil {
		logger.Error("SpooferMonitor GetPacket read msg err:", err)
		return nil
	}
	return req
}
func (d *SpooferMonitor) PropertyReport() {
	res := &mavlink.PropertyReportRequest{}
	d.GetPacket(res)
	logger.Debugf("SpooferMonitor get property report 信息：%#v", res)

	if res == nil {
		logger.Errorf("parse property report msg is nil")
		return
	}
	if uint8(GetSpooferMonitorRes().GetBatteryCap()) == res.BatteryCap {
		// 因为电量不是每秒都发生变化的，尽量减少写锁加持; 多个协程间读操作减少阻塞。
		return
	}
	GetSpooferMonitorRes().SetBatteryCap(int32(res.BatteryCap))
}

func SpooferMonitorOffLine(sn string) {
	var tcpServer *server.TcpServer
	if s, ok := SpooferMonitorTcpServerMap.Load(sn); ok {
		tcpServer = s.(*server.TcpServer)
		if tcpServer != nil {
			tcpServer.Stop()
		}
		deviceUsedPorts.Delete(tcpServer.Port)
		SpooferMonitorTcpServerMap.Delete(sn)
		DevSnMap.Delete(tcpServer.Port)
		cachekeyDroneid := fmt.Sprintf("%d_%s", common.DEV_SPOOFER_MONITOR, sn)
		DevStatusMap.Delete(cachekeyDroneid)
		tcpServer = nil
	}
	logger.Info("SpooferMonitorOffLine  report:")
}

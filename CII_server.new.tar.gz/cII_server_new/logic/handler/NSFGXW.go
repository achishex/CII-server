package handler

import (
	"context"
	"encoding/json"
	"fmt"
	"math"
	"net"
	"strconv"
	"time"

	"adasgitlab.autel.com/tools/cuav_plugin/broker"
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"

	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/config"
	"adasgitlab.autel.com/tools/cuav_server/entity/server"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
)

type checkSetMsg struct {
	IsDbFixAltOk bool //第一次就够了
	IsVClock     bool //实时
}

type ControllerNSFGXW struct {
	*Device
	ucoon     *net.UDPConn
	isworking int
	//TODO need update status ??
	setPlayFlag bool
	checkSetMsg
	Version string
	NFSIP   string
}

var gIsWorking int
var glon float64
var gla float64
var gheight float64

const (
	header = "FF"
)

// 主动防御----
// 发射功率
type update603 struct {
	SKey      string `json:"sKey"`
	IType     int    `json:"iType"`
	FAttenGPS int    `json:"fAttenGPS"`
	FAttenBDS int    `json:"fAttenBDS"`
	FAttenGLO int    `json:"fAttenGLO"`
	FAttenGAL int    `json:"fAttenGAL"`
}

// 设置半径和周期
type update610 struct {
	SKey       string  `json:"sKey"`
	FCirRadius float32 `json:"fCirRadius"`
	FCirCycle  float32 `json:"fCirCycle"`
	ICirRotDir int     `json:"iCirRotDir"`
}

// 设置通道延时
type update604 struct {
	SKey      string `json:"sKey"`
	IType     int    `json:"iType"`
	FDelayGPS int    `json:"fDelayGPS"`
	FDelayBDS int    `json:"fDelayBDS"`
	FDelayGLO int    `json:"fDelayGLO"`
	FDelayGAL int    `json:"fDelayGAL"`
}

// 发射开关
type update602 struct {
	SKey       string `json:"sKey"`
	ISwitchGPS int    `json:"iSwitchGPS"`
	ISwitchBDS int    `json:"iSwitchBDS"`
	ISwitchGLO int    `json:"iSwitchGLO"`
	ISwitchGAL int    `json:"iSwitchGAL"`
}

// 发射开关
type update628 struct {
	SKey           string  `json:"sKey"`
	FVerticalSpeed float32 `json:"fVerticalSpeed"`
	IVerticalDir   int     `json:"iVerticalDir"`
}

func (u *ControllerNSFGXW) update628Fun(speed float32, dir int) string {

	body := &update628{
		SKey:           "a57502fcdc4e7412",
		FVerticalSpeed: speed,
		IVerticalDir:   dir,
	}
	return u.formPkg(body, "628")
}

// 主动防御----

// 区域禁止 ---
// 设置初始位置
type update601 struct {
	SKey string `json:"sKey"`
	// DbLon float32 `json:"dbLon"`
	// DbLat float32 `json:"dbLat"`
	DbLon float64 `json:"dbLon"`
	DbLat float64 `json:"dbLat"`
	DbAlt float64 `json:"dbAlt"`
}

// 设置速度
type update608 struct {
	SKey           string  `json:"sKey"`
	FInitSpeedVal  float32 `json:"fInitSpeedVal"`
	FInitSpeedHead float32 `json:"fInitSpeedHead"`
}

func (u *ControllerNSFGXW) update608Fun(v, h float32) string {

	body := &update608{
		SKey:           "a57502fcdc4e7412",
		FInitSpeedVal:  v,
		FInitSpeedHead: h,
	}
	return u.formPkg(body, "608")
}
func (u *ControllerNSFGXW) update601Fun(lo, la float64, al float64) string {

	body := &update601{
		SKey: "a57502fcdc4e7412",
		// DbLon: float32(lo),
		// DbLat: float32(la),
		DbLon: lo,
		DbLat: la,
		DbAlt: al,
	}
	return u.formPkg(body, "601")
}

//区域禁止 ===

func (u *ControllerNSFGXW) update610Fun(fCirRadius, fCirCycle float32) string {

	body := &update610{
		SKey:       "a57502fcdc4e7412",
		FCirRadius: fCirRadius,
		FCirCycle:  fCirCycle,
	}
	return u.formPkg(body, "610")
}

func (u *ControllerNSFGXW) update603Fun(num int) string {

	body := &update603{
		SKey: "a57502fcdc4e7412",
		// IType:     0,
		FAttenGPS: num,
		FAttenBDS: num,
		FAttenGLO: num,
		FAttenGAL: num,
	}
	return u.formPkg(body, "603")
}

func (u *ControllerNSFGXW) update604Fun() string {

	body := &update604{
		SKey:      "a57502fcdc4e7412",
		FDelayGPS: -1000,
		FDelayBDS: -1000,
		FDelayGLO: -1000,
		FDelayGAL: -1000,
	}
	return u.formPkg(body, "604")
}

func (u *ControllerNSFGXW) update602Fun(enable int) string {
	// var enable int
	// if b {
	// 	enable = 1
	// }
	body := &update602{
		SKey:       "a57502fcdc4e7412",
		ISwitchGPS: enable,
		ISwitchBDS: enable,
		ISwitchGLO: enable,
		ISwitchGAL: enable,
	}
	return u.formPkg(body, "602")
}

func (u *ControllerNSFGXW) formPkg(v any, c string) string {
	data, err := json.Marshal(v)
	if err != nil {
		logger.Debug("data")
	}

	pkgLen := fmt.Sprintf("%04d", len(data))

	logger.Debug("pkgLen", pkgLen)
	pkg := header + pkgLen + c + string(data)
	logger.Debug("pkg = ", pkg)
	return pkg
}

// 东、西、南、北分别对应270、90、0、180
// NORTH Angle = 360
//
//	EAST  Angle = 90
//	SOUTH Angle = 180
//	WEST  Angle = 270
//	UP    Angle = 1
//	DOWN  Angle = -1
func (c *ControllerNSFGXW) adaptDirection(in int32) float32 {
	if in == 360 {
		return 180
	} else if in == 90 {
		return 270
	} else if in == 180 {
		return 0
	} else if in == 270 {
		return 90
	} else if in == 1 {
		return 1
	} else if in == -1 {
		return 0
	}

	return float32(in)
}

const powerBasic = 0
const powerGap = 6

func (c *ControllerNSFGXW) SetPlay(req *client.InduceRequest) int {
	var pkg string
	var err error
	var n int
	// c.ucoon.SetDeadline(time.Now().Add(300 * time.Millisecond))
	readbuf := make([]byte, 4*1024)

	if req.Enable {
		if req.WorkMode == int32(config.ACTIVEDEFENSE) { //主动防御
			var power int
			if req.Radius == 500 {
				power = powerBasic + powerGap + powerGap
			} else if req.Radius == 1000 {
				power = powerBasic + powerGap
			} else if req.Radius == 2000 {
				power = powerBasic
			}
			pkg = c.update603Fun(power)

			logger.Debug("pkg = ", pkg)
			c.ucoon.Write([]byte(pkg))
			n, _, err = c.ucoon.ReadFromUDP(readbuf)
			if err != nil {
				logger.Debug("err = ", err)
				return -1
			}
			logger.Debug("recv , len = ", n)
			logger.Debug("read buf = ", string(readbuf[:n]))
			//
			llh := make([]float64, 3)
			enu := make([]float64, 3)
			var rllh [3]float64
			enu[0] = 0
			enu[1] = -300
			enu[2] = 0
			// rllh[0] = glon * math.Pi / 180
			// rllh[1] = gla * math.Pi / 180
			// rllh[2] = gheight
			rllh[0] = req.DefenseLongitude * math.Pi / 180
			rllh[1] = req.DefenseLatitude * math.Pi / 180
			rllh[2] = float64(req.Height)
			_, ret_llh := config.Enu2llh(enu, rllh, llh)

			pkg = c.update601Fun(ret_llh[0]*180/math.Pi, ret_llh[1]*180/math.Pi, ret_llh[2])
			logger.Debug("pkg = ", pkg)
			c.ucoon.Write([]byte(pkg))
			n, _, err = c.ucoon.ReadFromUDP(readbuf)
			if err != nil {
				logger.Debug("err = ", err)
				return -1
			}
			logger.Debug("recv , len = ", n)
			logger.Debug("read buf = ", string(readbuf[:n]))

			//
			speed := float32(req.DefenseLevelSpeed)
			tradius := 300
			pkg = c.update610Fun(float32(tradius), float32(tradius)*2*math.Pi/speed)
			logger.Debug("pkg = ", pkg)
			c.ucoon.Write([]byte(pkg))
			n, _, err = c.ucoon.ReadFromUDP(readbuf)
			if err != nil {
				logger.Debug("err = ", err)
				return -1
			}
			logger.Debug("recv , len = ", n)
			logger.Debug("read buf = ", string(readbuf[:n]))

			pkg = c.update604Fun()
			logger.Debug("pkg = ", pkg)
			c.ucoon.Write([]byte(pkg))
			n, _, err = c.ucoon.ReadFromUDP(readbuf)
			if err != nil {
				logger.Debug("err = ", err)
				return -1
			}
			logger.Debug("recv , len = ", n)
			logger.Debug("read buf = ", string(readbuf[:n]))

			pkg = c.update602Fun(1)
			logger.Debug("pkg = ", pkg)
			c.ucoon.Write([]byte(pkg))
			n, _, err = c.ucoon.ReadFromUDP(readbuf)
			if err != nil {
				logger.Debug("err = ", err)
				return -1
			}
			logger.Debug("recv , len = ", n)
			logger.Debug("read buf = ", string(readbuf[:n]))
		} else if req.WorkMode == int32(config.AREADENIAL) { //
			var power int
			if req.Radius == 500 {
				power = powerBasic + powerGap + powerGap
			} else if req.Radius == 1000 {
				power = powerBasic + powerGap
			} else if req.Radius == 2000 {
				power = powerBasic
			}
			pkg = c.update603Fun(power)
			logger.Debug("pkg = ", pkg)
			c.ucoon.Write([]byte(pkg))
			n, _, err = c.ucoon.ReadFromUDP(readbuf)
			if err != nil {
				logger.Debug("err = ", err)
				return -1
			}
			logger.Debug("recv , len = ", n)
			logger.Debug("read buf = ", string(readbuf[:n]))

			//TODO
			pkg = c.update601Fun(req.AreaStopLongitude, req.AreaStopLatitude, 200)
			logger.Debug("pkg = ", pkg)
			c.ucoon.Write([]byte(pkg))
			n, _, err = c.ucoon.ReadFromUDP(readbuf)
			if err != nil {
				logger.Debug("err = ", err)
				return -1
			}
			logger.Debug("recv , len = ", n)
			logger.Debug("read buf = ", string(readbuf[:n]))
			pkg = c.update604Fun()
			logger.Debug("pkg = ", pkg)
			c.ucoon.Write([]byte(pkg))
			n, _, err = c.ucoon.ReadFromUDP(readbuf)
			if err != nil {
				logger.Debug("err = ", err)
				return -1
			}
			logger.Debug("recv , len = ", n)
			logger.Debug("read buf = ", string(readbuf[:n]))

			// pkg = c.update608Fun(float32(req.DefenseLevelSpeed), float32(req.DefenseVerticalSpeed))
			pkg = c.update608Fun(0, 0)
			logger.Debug("pkg = ", pkg)
			c.ucoon.Write([]byte(pkg))
			n, _, err = c.ucoon.ReadFromUDP(readbuf)
			if err != nil {
				logger.Debug("err = ", err)
				return -1
			}
			logger.Debug("recv , len = ", n)
			logger.Debug("read buf = ", string(readbuf[:n]))
			pkg = c.update602Fun(1)
			logger.Debug("pkg = ", pkg)
			c.ucoon.Write([]byte(pkg))
			n, _, err = c.ucoon.ReadFromUDP(readbuf)
			if err != nil {
				logger.Debug("err = ", err)
				return -1
			}
			logger.Debug("recv , len = ", n)
			logger.Debug("read buf = ", string(readbuf[:n]))

		} else if req.WorkMode == int32(config.DIRECTIONALDRIVE) { //定向驱离
			pkg = c.update603Fun(powerBasic)
			logger.Debug("pkg = ", pkg)
			c.ucoon.Write([]byte(pkg))
			n, _, err = c.ucoon.ReadFromUDP(readbuf)
			if err != nil {
				logger.Debug("err = ", err)
				return -1
			}
			logger.Debug("recv , len = ", n)
			logger.Debug("read buf = ", string(readbuf[:n]))

			//TODO
			// pkg = c.update601Fun(req.Longitude, req.Latitude, 200)
			var al float64
			if gheight == 0 {
				al = 200
			} else {
				al = gheight + 200
			}
			// if glon == 0 || gla == 0 {
			// 	logger.Error("glon = ", glon, "; gla = ", gla)
			// 	return -1
			// }
			t7glon, _ := strconv.ParseFloat(strconv.FormatFloat(glon, 'f', 7, 64), 64)
			t7gla, _ := strconv.ParseFloat(strconv.FormatFloat(gla, 'f', 7, 64), 64)
			tal, _ := strconv.ParseFloat(strconv.FormatFloat(al, 'f', 0, 64), 64)
			logger.Debug("al = ", al, " gheight = ", gheight, " t7glon = ", t7glon, " t7gla = ", t7gla)
			pkg = c.update601Fun(t7glon, t7gla, tal)
			// pkg = c.update601Fun(glon, gla, al)
			// pkg = c.update601Fun(glon, gla, al)
			// FF0078601{"sKey":"a57502fcdc4e7412","dbLon":113.9980830,"dbLat":22.5972905,"dbAlt":229}
			// tlon := float64(113.9980831)
			// tla := float64(22.5972905)
			// tal := 229
			// pkg = c.update601Fun(tlon, tla, tal)
			logger.Debug("pkg = ", pkg)
			c.ucoon.Write([]byte(pkg))
			n, _, err = c.ucoon.ReadFromUDP(readbuf)
			if err != nil {
				logger.Debug("err = ", err)
				return -1
			}
			logger.Debug("recv , len = ", n)
			logger.Debug("read buf = ", string(readbuf[:n]))
			pkg = c.update604Fun()
			logger.Debug("pkg = ", pkg)
			c.ucoon.Write([]byte(pkg))
			n, _, err = c.ucoon.ReadFromUDP(readbuf)
			if err != nil {
				logger.Debug("err = ", err)
				return -1
			}
			logger.Debug("recv , len = ", n)
			logger.Debug("read buf = ", string(readbuf[:n]))

			if req.Angle == -1 || req.Angle == 1 {
				// float32(req.DefenseLevelSpeed)//DefenseLevelSpeed需要适配前端 TODO，这里先写死 5
				// pkg = c.update628Fun(float32(5), int(c.adaptDirection(req.Angle)))
				pkg = c.update628Fun(float32(req.DriveVerticalSpeed), int(c.adaptDirection(req.Angle)))
				logger.Debug("pkg = ", pkg)
				c.ucoon.Write([]byte(pkg))
				n, _, err = c.ucoon.ReadFromUDP(readbuf)
				if err != nil {
					logger.Debug("err = ", err)
					return -1
				}
				logger.Debug("recv , len = ", n)
				logger.Debug("read buf = ", string(readbuf[:n]))
			} else {
				// req.DefenseLevelSpeed //update608Fun 和前端适配前端  TODO
				pkg = c.update608Fun(float32(req.DriveLevelSpeed), c.adaptDirection(req.Angle))
				logger.Debug("pkg = ", pkg)
				c.ucoon.Write([]byte(pkg))
				n, _, err = c.ucoon.ReadFromUDP(readbuf)
				if err != nil {
					logger.Debug("err = ", err)
					return -1
				}
				logger.Debug("recv , len = ", n)
				logger.Debug("read buf = ", string(readbuf[:n]))
			}

			pkg = c.update602Fun(1)
			logger.Debug("pkg = ", pkg)
			c.ucoon.Write([]byte(pkg))
			n, _, err = c.ucoon.ReadFromUDP(readbuf)
			if err != nil {
				logger.Debug("err = ", err)
				return -1
			}
			logger.Debug("recv , len = ", n)
			logger.Debug("read buf = ", string(readbuf[:n]))
		}
		// c.isworking = 1
		gIsWorking = 1
	} else {
		pkg = c.update602Fun(0)
		logger.Debug("pkg = ", pkg)
		c.ucoon.Write([]byte(pkg))
		n, _, err = c.ucoon.ReadFromUDP(readbuf)
		if err != nil {
			logger.Debug("err = ", err)
			return -1
		}
		logger.Debug("recv , len = ", n)
		logger.Debug("read buf = ", string(readbuf[:n]))
		// c.isworking = 0
		gIsWorking = 0
	}
	logger.Debug("gIsWorking=  ", gIsWorking)
	return 0
}

type nsfGXWHeart struct {
	ISysSta     int     `json:"iSysSta"`     // 1. 系统工作状态
	STime       string  `json:"sTime"`       // 2. 时间
	SDevNum     string  `json:"sDevNum"`     // 3. 设备编号
	IDevType    int     `json:"iDevType"`    // 4. 设备类型
	ISysRunTime int     `json:"iSysRunTime"` // 5. 系统运行时长
	FEnvTemp    float32 `json:"fEnvTemp"`    // 6. 环境温度
	STsSyncSta  string  `json:"sTsSyncSta"`  // 7. 授时同步状态字
	DbFixLon    float64 `json:"dbFixLon"`    // 8. 当前定位位置经度
	DbFixLat    float64 `json:"dbFixLat"`    // 9. 当前定位位置纬度
	DbFixAlt    float64 `json:"dbFixAlt"`    // 10. 当前定位位置高度
	IOcxoSta    int     `json:"iOcxoSta"`    // 11. 晶振状态
	FTimeAccur  float32 `json:"fTimeAccur"`  // 12. 时间精度
	SWorkStaGPS string  `json:"sWorkStaGPS"` // 13. GPS工作状态字
	SWorkStaBDS string  `json:"sWorkStaBDS"` // 14. BDS工作状态字
	SWorkStaGLO string  `json:"sWorkStaGLO"` // 15. GLONASS工作状态字
	SWorkStaGAL string  `json:"sWorkStaGAL"` // 16. GALILEO工作状态字
	ISatNumGPS  int     `json:"iSatNumGPS"`  // 17. GPS转发卫星颗数
	ISatNumBDS  int     `json:"iSatNumBDS"`  // 18. BDS转发卫星颗数
	ISatNumGLO  int     `json:"iSatNumGLO"`  // 19. GLONASS转发卫星颗数
	ISatNumGAL  int     `json:"iSatNumGAL"`  // 20. GALILEO转发卫星颗数

	IRcvSatNumGPS int `json:"iRcvSatNumGPS"` // 21. 可用 GPS 卫星颗数
	IRcvSatNumBDS int `json:"iRcvSatNumBDS"` // 22. 可用 BDS 卫星颗数
	IRcvSatNumGLO int `json:"iRcvSatNumGLO"` // 23. 可用 GLONASS 卫星颗数
	IRcvSatNumGAL int `json:"iRcvSatNumGAL"` // 24. 可用 GALILEO 卫星颗数

	ISwitchGPS     int     `json:"iSwitchGPS"`     // 25. GPS发射开关
	ISwitchBDS     int     `json:"iSwitchBDS"`     // 26. BDS发射开关
	ISwitchGLO     int     `json:"iSwitchGLO"`     // 27. GLONASS发射开关
	ISwitchGAL     int     `json:"iSwitchGAL"`     // 28. GALILEO发射开关
	IPASwitch      int     `json:"iPASwitch"`      // 29. 功放开关
	DbSimuLon      float64 `json:"dbSimuLon"`      // 30. 当前诱骗位置经度
	DbSimuLat      float64 `json:"dbSimuLat"`      // 31. 当前诱骗位置高度
	DbSimuAlt      float64 `json:"dbSimuAlt"`      // 32. 当前诱骗位置高度
	FAttenGPS      float32 `json:"fAttenGPS"`      // 33. GPS功率衰减值
	FAttenBDS      float32 `json:"fAttenBDS"`      // 34. BDS功率衰减值
	FAttenGLO      float32 `json:"fAttenGLO"`      // 35. GLONASS功率衰减值
	FAttenGAL      float32 `json:"fAttenGAL"`      // 36. GALILEO功率衰减值
	FDelayGPS      float32 `json:"fDelayGPS"`      // 37. GPS通道时延
	FDelayBDS      float32 `json:"fDelayBDS"`      // 38. BDS通道时延
	FDelayGLO      float32 `json:"fDelayGLO"`      // 39. GLONASS通道时延
	FDelayGAL      float32 `json:"fDelayGAL"`      // 40. GALILEO通道时延
	IAutoTimingSw  int     `json:"iAutoTimingSw"`  // 41. 整点授时开关
	FInitSpeedVal  float32 `json:"fInitSpeedVal"`  // 42. 模拟初速度大小
	FInitSpeedHead float32 `json:"fInitSpeedHead"` // 43. 模拟初速度方向
	FAccSpeedVal   float32 `json:"fAccSpeedVal"`   // 44. 模拟加速度大小
	FAccSpeedHead  float32 `json:"fAccSpeedHead"`  // 45. 模拟加速度方向
	FCirRadius     float32 `json:"fCirRadius"`     // 46. 模拟圆周运动半径
	FCirCycle      float32 `json:"fCirCycle"`      // 47. 模拟圆周运动周期
	ICirRotDir     int     `json:"iCirRotDir"`     // 48. 模拟圆周运动方向

	FVerticalSpeed float32 `json:"fVerticalSpeed"` // 49. 模拟垂直速度
	IVerticalDir   int     `json:"iVerticalDir"`   // 50. 模拟垂直方向

	IAutoTranSw int   `json:"iAutoTranSw"` // 51. 上电自动发射开关
	IFirstTim   int   `json:"iFirstTim"`   // 52. 上电首次校时标志
	AGPSPRN     []int `json:"aGPSPRN"`     // 53. GPS转发卫星PRN号
	ABDSPRN     []int `json:"aBDSPRN"`     // 54. BDS转发卫星PRN号
	AGLOPRN     []int `json:"aGLOPRN"`     // 55. GLONASS转发卫星PRN号
	AGALPRN     []int `json:"aGALPRN"`     // 56. GALILEO转发卫星PRN号

	ARcvGPSPRN []int `json:"aRcvGPSPRN"` // 57. 可用 GPS 卫星 PRN 号
	ARcvBDSPRN []int `json:"aRcvBDSPRN"` // 58. 可用 BDS 卫星 PRN 号
	ARcvGLOPRN []int `json:"aRcvGLOPRN"` // 59. 可用 GLONASS 卫星 PRN 号
	ARcvGALPRN []int `json:"aRcvGALPRN"` // 60. 可用 GLONASS 卫星 PRN 号

	FMaxSpeed      float32 `json:"fMaxSpeed"`      // 61. 模拟最大速度值
	ITranCtrlMode  int     `json:"iTranCtrlMode"`  // 62. 发射控制模式
	IAntSup        int     `json:"iAntSup"`        // 63. 天线馈电控制开关
	IGnssScreenSw  int     `json:"iGnssScreenSw"`  // 64. GNSS屏蔽功能开关
	IPinLevel      int     `json:"iPinLevel"`      // 65. 外部引脚输出电平
	IGalUsedNum    int     `json:"iGalUsedNum"`    // 66. 伽利略可用卫星数
	ISwitchToneGPS int     `json:"iSwitchToneGPS"` // 67. GPS单载波模式开关
	ISwitchToneGLO int     `json:"iSwitchToneGLO"` // 68. GLO单载波模式开关
	IToneGLOChan   int     `json:"iToneGLOChan"`   // 69. GLO单载波通道号
}

func NewControllerNSFGXW() *ControllerNSFGXW {
	return &ControllerNSFGXW{
		Device: &Device{},
	}
}
func (ctrl *ControllerNSFGXW) cacheConn(conn net.Conn, uconn *net.UDPConn, ver, showIp string) {
	ctrl.Conn = conn
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_NSF4000, ctrl.Sn)
	dev := &Device{
		Sn:   ctrl.Sn,
		Conn: ctrl.Conn,
	}
	reqMode := &ControllerNSFGXW{
		Device:  dev,
		ucoon:   uconn,
		Version: ver,
		NFSIP:   showIp,
	}
	if ctrl.Sn == "" {
		logger.Error("NSF4000 sn is nil")
		return
	}
	DevStatusNfsMap.Store(cacheKey, reqMode)
}

func (c *ControllerNSFGXW) isCanSetPlay() bool {
	if !c.IsDbFixAltOk {
		return false
	}
	if !c.IsVClock {
		return false
	}
	return true
}

func (c *ControllerNSFGXW) Handle(dConn, pConn *net.UDPConn, ver, showIp string) {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	logger.Debug("sconn = ", dConn)
	logger.Debug("rconn = ", pConn)
	if dConn == nil || pConn == nil {
		logger.Debug(" dConn or pConn is nil")
		return
	}
	c.Version = ver
	logger.Debug("c.Version = ", c.Version)
	c.NFSIP = showIp
	logger.Debug("c.NFSIP  = ", c.NFSIP)
	logger.Debug("ip local = ", dConn.LocalAddr().String())
	logger.Debug("ip remote = ", dConn.RemoteAddr().String())

	readbuf := make([]byte, 1024*1024)

	heartData := nsfGXWHeart{}
	for {
		pConn.SetDeadline(time.Now().Add(3 * time.Second))
		n, addr, err := pConn.ReadFromUDP(readbuf)
		if err != nil {
			logger.Debug("err = ", err)
			pConn.SetDeadline(time.Time{})
			server.GnsfHeart = false
			logger.Debug(" revice heart,time out", server.GnsfHeart)

			var s NSF4000Msg
			s.IsOnline = 2
			equipModel, err := GetEquipBySn(c.Sn)
			name := c.Sn
			if equipModel != nil && equipModel.Name != "" {
				name = equipModel.Name
			}
			msg := common.EquipmentMessageBoxEntity{
				Name:      name,
				Sn:        c.Sn,
				MsgType:   config.NSF4000TypeOnline,
				EquipType: int(common.DEV_NSF4000),
				Info:      s,
			}
			if err == nil {
				msg.ParentType = equipModel.ParentType
				msg.ParentSn = equipModel.ParentSn
				msg.IsIntegrated = equipModel.IsIntegrated
			}
			_ = mq.NSF4000BrokerLLH.Publish(mq.NSF4000TopicLLH, broker.NewMessage(msg))
			reportNSF4000Event(c.Sn, &s)
			return
		}

		logger.Debug("addr = ", addr)
		logger.Debug("recv , len = ", n)
		logger.Debug("heartbeat_msg read buf = ", string(readbuf[:n]))
		dataLen, _ := strconv.Atoi(string(readbuf[2:6]))

		logger.Debug("data buf = ", string(readbuf[9:dataLen+9]))
		logger.Debug("dataLen = ", dataLen)
		err = json.Unmarshal(readbuf[9:dataLen+9], &heartData)
		if err != nil {
			logger.Error("err umar json = ", err)
			continue
		}
		// logger.Debug("heart data = ", heartData)
		var s NSF4000Msg
		// s.GpsStatus = 2
		// s.Ephemeris = 2
		s.IsOnline = 1
		// s.IsWorking = c.isworking
		s.IsWorking = gIsWorking
		logger.Debug(" gIsWorking= ", gIsWorking)
		// s.IsWorking = 1
		if heartData.IOcxoSta == 3 {
			// s.GpsStatus = 1
			// s.Ephemeris = 1
			s.TimeSync = 1
			c.IsVClock = true
			logger.Debug("heartData.IOcxoSta  = ", heartData.IOcxoSta, " 时钟定位 ok -- >")
		} else {
			c.IsVClock = false
		}
		// tmp1 := string([]byte(heartData.STsSyncSta)[1:2])

		if heartData.DbFixAlt != 0 {
			c.IsDbFixAltOk = true
			logger.Debug("IsDbFixAltOk = is ok")
		}
		//搞反了 TODO
		if getByteNum(heartData.STsSyncSta, 1) == 0 || getByteNum(heartData.STsSyncSta, 4) == 0 {
			s.GpsStatus = 1
			if heartData.DbFixLon != 0 && heartData.DbFixLat != 0 {
				glon = heartData.DbFixLon
				//TODO 和上位机有差别？？ DbFixAlt = heartData.DbFixAlt * PI/180
				gla = heartData.DbFixLat
				gheight = heartData.DbFixAlt
			}

			logger.Debug("STsSyncSta = ", s.GpsStatus, " -- > 定位状态 ok,")
		} else {
			logger.Debug("STsSyncSta = ", s.GpsStatus, " -- > 定位状态 ")
			s.Longititude = -1
			s.Latitude = -1
		}
		logger.Debug("eartData.SWorkStaGPS = ", heartData.SWorkStaGPS)
		logger.Debug("eartData.SWorkStaBDS = ", heartData.SWorkStaBDS)
		logger.Debug("eartData.SWorkStaGLO = ", heartData.SWorkStaGLO)
		logger.Debug("eartData.SWorkStaGAL = ", heartData.SWorkStaGAL)

		logger.Debug("eartData.IRcvSatNumGPS = ", heartData.IRcvSatNumGPS)
		logger.Debug("eartData.IRcvSatNumBDS = ", heartData.IRcvSatNumBDS)
		logger.Debug("eartData.IRcvSatNumGLO = ", heartData.IRcvSatNumGLO)
		logger.Debug("eartData.IRcvSatNumGAL = ", heartData.IRcvSatNumGAL)

		//TODO 21,22,23,24
		// if (getByteNum(heartData.SWorkStaGPS, 2) +
		// 	getByteNum(heartData.SWorkStaBDS, 2) +
		// 	getByteNum(heartData.SWorkStaGLO, 2) +
		// 	getByteNum(heartData.SWorkStaGAL, 2)) == 0 {
		// 	s.Ephemeris = 1
		// 	logger.Debug("Ephemeris = ", s.Ephemeris, " -- >星历状态 ok,")
		// } else {
		// 	logger.Debug("Ephemeris = ", s.Ephemeris, " -- >星历状态 ")
		// }
		if heartData.IRcvSatNumGPS >= 1 && heartData.IRcvSatNumBDS >= 1 && heartData.IRcvSatNumGLO >= 1 && heartData.IRcvSatNumGAL >= 1 &&
			(heartData.IRcvSatNumGPS+heartData.IRcvSatNumBDS+heartData.IRcvSatNumGLO+heartData.IRcvSatNumGAL) >= 8 {
			s.Ephemeris = 1
			logger.Debug("Ephemeris = ", s.Ephemeris, " -- >星历状态 ok,")
		} else {
			logger.Debug("Ephemeris = ", s.Ephemeris, " -- >星历状态 ")
		}
		//=============

		s.Longititude = glon
		s.Latitude = gla
		s.Height = gheight
		// if s.Longititude == 0 {
		// 	s.Longititude = -1
		// }
		// if s.Latitude == 0 {
		// 	s.Latitude = -1
		// }

		logger.Debug("NSF4000Msg = ", s)
		logger.Debug("STsSyncSta = ", s.GpsStatus)
		logger.Debug("Ephemeris = ", s.Ephemeris)

		status := &client.GetStatusRes{}
		err = NewEquipList().GetStatus(context.Background(), &client.GetStatusReq{
			Sn:         heartData.SDevNum,
			EType:      "Spoofer",
			SubDevType: 2,
		}, status)
		if err != nil {
			logger.Error("NSF 4000 GetStatus err:", err)
			continue
		}
		if status.IsEnable == common.DeviceDisenable {
			continue
		}
		c.Sn = heartData.SDevNum
		c.cacheConn(pConn, dConn, ver, showIp)

		s.BatteryCap = uint8(GetSpooferMonitorRes().GetBatteryCap())
		time.Sleep(100 * time.Millisecond)
		// config.NSF4000TypeTimeSync

		var (
			parentType   int
			parentSn     string
			isIntegrated int32
		)
		equipModel, err := GetEquipBySn(heartData.SDevNum)
		name := heartData.SDevNum
		if equipModel != nil && equipModel.Name != "" {
			name = equipModel.Name
		}
		if err == nil {
			parentType = equipModel.ParentType
			parentSn = equipModel.ParentSn
			isIntegrated = equipModel.IsIntegrated
		}
		msg := common.EquipmentMessageBoxEntity{
			Name:         name,
			Sn:           heartData.SDevNum,
			Info:         s,
			EquipType:    int(common.DEV_NSF4000),
			MsgType:      config.NSF4000TypeOnline,
			ParentType:   parentType,
			ParentSn:     parentSn,
			IsIntegrated: isIntegrated,
		}

		_ = mq.NSF4000BrokerLLH.Publish(mq.NSF4000TopicLLH, broker.NewMessage(msg))

		msg2 := common.EquipmentMessageBoxEntity{
			Name:         name,
			Sn:           heartData.SDevNum,
			Info:         s,
			EquipType:    int(common.DEV_NSF4000),
			MsgType:      config.NSF4000TypeWorking,
			ParentType:   parentType,
			ParentSn:     parentSn,
			IsIntegrated: isIntegrated,
		}

		time.Sleep(100 * time.Millisecond)
		_ = mq.NSF4000BrokerLLH.Publish(mq.NSF4000TopicLLH, broker.NewMessage(msg2))

		msg3 := common.EquipmentMessageBoxEntity{
			Name:         name,
			Sn:           heartData.SDevNum,
			Info:         s,
			EquipType:    int(common.DEV_NSF4000),
			MsgType:      config.NSF4000TypeLLH,
			ParentType:   parentType,
			ParentSn:     parentSn,
			IsIntegrated: isIntegrated,
		}

		time.Sleep(100 * time.Millisecond)
		_ = mq.NSF4000BrokerLLH.Publish(mq.NSF4000TopicLLH, broker.NewMessage(msg3))

		if s.TimeSync == 1 {
			msg := common.EquipmentMessageBoxEntity{
				Name:         name,
				Sn:           heartData.SDevNum,
				Info:         s,
				EquipType:    int(common.DEV_NSF4000),
				MsgType:      config.NSF4000TypeTimeSync,
				ParentType:   parentType,
				ParentSn:     parentSn,
				IsIntegrated: isIntegrated,
			}
			time.Sleep(100 * time.Millisecond)
			_ = mq.NSF4000BrokerLLH.Publish(mq.NSF4000TopicLLH, broker.NewMessage(msg))
		}
		if s.GpsStatus == 1 {
			msg := common.EquipmentMessageBoxEntity{
				Name:         name,
				Sn:           heartData.SDevNum,
				Info:         s,
				EquipType:    int(common.DEV_NSF4000),
				MsgType:      config.NSF4000TypeGpsStatus,
				ParentType:   parentType,
				ParentSn:     parentSn,
				IsIntegrated: isIntegrated,
			}
			time.Sleep(100 * time.Millisecond)
			_ = mq.NSF4000BrokerLLH.Publish(mq.NSF4000TopicLLH, broker.NewMessage(msg))
		}
		if s.Ephemeris == 1 {
			msg := common.EquipmentMessageBoxEntity{
				Name:         name,
				Sn:           heartData.SDevNum,
				Info:         s,
				EquipType:    int(common.DEV_NSF4000),
				MsgType:      config.NSF4000TypeEphemeris,
				ParentType:   parentType,
				ParentSn:     parentSn,
				IsIntegrated: isIntegrated,
			}
			time.Sleep(100 * time.Millisecond)
			_ = mq.NSF4000BrokerLLH.Publish(mq.NSF4000TopicLLH, broker.NewMessage(msg))
		}

		//上报NSFGXW事件通知
		go reportNSF4000Event(c.Sn, &s)

		pConn.SetDeadline(time.Time{})
	}
}

func getByteNum(s string, siteIn int) int {
	site := 7 - siteIn
	num, err := strconv.Atoi(string([]byte(s)[site : site+1]))
	if err == nil {
		return num
	}
	logger.Debug("err = ", err)
	return 1
}

package handler

import (
	"bytes"
	"context"
	"crypto/rand"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"math/big"
	"strconv"
	"strings"
	"sync"
	"time"

	"adasgitlab.autel.com/tools/slink_proto/slinkv2"
	"adasgitlab.autel.com/tools/slink_proto/slinkv2/generatecode/golang/bizproto"
	"adasgitlab.autel.com/tools/slink_proto/slinkv2/msgid"
	jsoniter "github.com/json-iterator/go"
	"github.com/samber/lo"
	"golang.org/x/time/rate"

	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/helper"
	"adasgitlab.autel.com/tools/cuav_server/repo/utils"
	"adasgitlab.autel.com/tools/cuav_server/rpc/codec"
	"adasgitlab.autel.com/tools/cuav_server/rpc/idgenerator"

	"adasgitlab.autel.com/tools/cuav_plugin/broker"
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"google.golang.org/protobuf/proto"

	"adasgitlab.autel.com/tools/slink_proto/slinkv1"

	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/server"
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/ip"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/proto/mavlink"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
)

const (
	AgxTcpPort        = 16000
	AgxServerMaxCount = 500
	AgxReducedValue   = 64 //2的6次方,Agx上报数值扩大值
)

const (
	agxburst            = 1 //perf me with better value @fzw
	agxDetectRate       = 5 //5Hz
	agxPerceptionRate   = 5 //5Hz
	agxHeartRate        = 5 //5Hz
	agxDeviceStatusRate = 5 //5Hz
	agxPTZStatusRate    = 5 //5Hz
)

var (
	//用于更新一体化字段
	isIntegratedMap sync.Map
	//key:sn value:device ip
	SnToIpMap sync.Map
)

type agxLimit struct {
	detectLimit       *rate.Limiter
	perceptionLimit   *rate.Limiter
	heartLimit        *rate.Limiter
	deviceStatusLimit *rate.Limiter
	pTZStatusLimit    *rate.Limiter
}
type Agx struct {
	*Device
	dt common.DeviceType
	*agxLimit
	LaserSn string
}

var _ DeviceIfer = (*Agx)(nil)

// SetDevice 要使用GetOnLineDev 接口，必须要给该设备实现 DeviceIfer 接口
func (tg *Agx) SetDevice(d *Device) {
	tg.Device = d
}

var (
	AgxTcpServerLock   sync.Mutex
	AgxTcpServerMap    sync.Map
	AgxHeartSum        uint8
	agxSnToLocationMap sync.Map
	GagxDeviceType     = common.DEV_AGX //固定式，便携式 agx

	//激光
	States         = map[string]*mavlink.States{} // key:laser sn
	count          = 0                            //记录第一次收到激光状态消息，用于记录照明时长
	LightStartTime time.Time                      //激光照明开始时间
	LaserSn        string
)

// NewAgx近程雷视
func NewAgx(conn Connection, d []byte, dataLen int, remoteIp string, remotePort int, localIp string, serverPort int,
	mailBox map[int]*WaitTaskManager, dlimit *devLimit) DeviceInterface {

	agx := &Agx{
		Device: &Device{
			Conn:        conn,
			Msg:         d,
			MsgLen:      dataLen,
			SourceId:    d[mavlink.SenderLoc],
			RemoteIp:    remoteIp,
			RemotePort:  remotePort,
			LocalIp:     localIp,
			ServerPort:  serverPort,
			WaitTaskMap: mailBox,
			DevType:     common.DEV_AGX,
		},
		agxLimit: &agxLimit{
			detectLimit:       dlimit.agx.detectLimit,
			perceptionLimit:   dlimit.agx.perceptionLimit,
			heartLimit:        dlimit.agx.heartLimit,
			deviceStatusLimit: dlimit.agx.deviceStatusLimit,
			pTZStatusLimit:    dlimit.agx.pTZStatusLimit,
		},
	}
	logger.Debug("NewAgx ,agx type = ", agx.Device.DevType)
	return agx
}

// NewAgxOfSRP150 便携式雷视
func NewAgxOfSRP150(conn Connection, d []byte, dataLen int, remoteIp string, remotePort int, localIp string, serverPort int,
	mailBox map[int]*WaitTaskManager, dlimit *devLimit) DeviceInterface {

	agx := &Agx{
		Device: &Device{
			Conn:        conn,
			Msg:         d,
			MsgLen:      dataLen,
			SourceId:    d[mavlink.SenderLoc],
			RemoteIp:    remoteIp,
			RemotePort:  remotePort,
			LocalIp:     localIp,
			ServerPort:  serverPort,
			WaitTaskMap: mailBox,
			DevType:     common.DEV_SRP150,
		},
		agxLimit: &agxLimit{
			detectLimit:       dlimit.agx.detectLimit,
			perceptionLimit:   dlimit.agx.perceptionLimit,
			heartLimit:        dlimit.agx.heartLimit,
			deviceStatusLimit: dlimit.agx.deviceStatusLimit,
			pTZStatusLimit:    dlimit.agx.pTZStatusLimit,
		},
	}
	logger.Debug("NewAgxOfSRP150 ,agx type = ", agx.Device.DevType)
	return agx
}

// srp200 中程雷视
func NewSrp200(conn Connection, d []byte, dataLen int, remoteIp string, remotePort int, localIp string, serverPort int,
	mailBox map[int]*WaitTaskManager, dlimit *devLimit) DeviceInterface {

	agx := &Agx{
		Device: &Device{
			Conn:        conn,
			Msg:         d,
			MsgLen:      dataLen,
			SourceId:    d[mavlink.SenderLoc],
			RemoteIp:    remoteIp,
			RemotePort:  remotePort,
			LocalIp:     localIp,
			ServerPort:  serverPort,
			WaitTaskMap: mailBox,
			DevType:     common.DEV_SRP200,
		},
		agxLimit: &agxLimit{
			detectLimit:       dlimit.agx.detectLimit,
			perceptionLimit:   dlimit.agx.perceptionLimit,
			heartLimit:        dlimit.agx.heartLimit,
			deviceStatusLimit: dlimit.agx.deviceStatusLimit,
			pTZStatusLimit:    dlimit.agx.pTZStatusLimit,
		},
	}
	logger.Debug("NewSrp200 device type = ", agx.Device.DevType)
	return agx
}

// Sbp100 激光雷视
func NewSbp100(conn Connection, d []byte, dataLen int, remoteIp string, remotePort int, localIp string, serverPort int,
	mailBox map[int]*WaitTaskManager, dlimit *devLimit) DeviceInterface {

	agx := &Agx{
		Device: &Device{
			Conn:        conn,
			Msg:         d,
			MsgLen:      dataLen,
			SourceId:    d[mavlink.SenderLoc],
			RemoteIp:    remoteIp,
			RemotePort:  remotePort,
			LocalIp:     localIp,
			ServerPort:  serverPort,
			WaitTaskMap: mailBox,
			DevType:     common.DEV_SBP100,
		},
		agxLimit: &agxLimit{
			detectLimit:       dlimit.agx.detectLimit,
			perceptionLimit:   dlimit.agx.perceptionLimit,
			heartLimit:        dlimit.agx.heartLimit,
			deviceStatusLimit: dlimit.agx.deviceStatusLimit,
			pTZStatusLimit:    dlimit.agx.pTZStatusLimit,
		},
	}
	logger.Debug("NewSbp100 ,sbp100 type = ", agx.Device.DevType)
	return agx
}

func (d *Agx) Deal() {
	defer func() {
		if err := recover(); err != nil {
			logger.Error("Agx deal 接收到panic:", err)
		}
	}()

	if d.MsgLen <= 0 {
		logger.Error("Agx 数据为null,不作处理:", d.Device.RemoteIp)
		return
	}
	d.MsgId = int(d.Msg[mavlink.MsgIdLoc])
	switch d.MsgId {
	case mavlink.AgxMsgHeartBeat:
		if d.agxLimit.heartLimit.Allow() {
			d.ReceiveAgxHeartBeat()
		} else {
			logger.Error("speed of agx heart is quite fast,msgid:", d.MsgId, " Sn: ", string(d.Sn))
			heart := &mavlink.AgxHeart{}
			d.GetPacket(heart)
			logger.Info("msg : ", heart)
		}
	case mavlink.AgxMsgDetect:
		if d.agxLimit.detectLimit.Allow() {
			d.ReceiveAgxDetectRes()
		} else {
			logger.Error("speed of agx detect is quite fast,msgid:", d.MsgId, " Sn: ", string(d.Sn))
			result := &mavlink.AgxDetectResult{}
			if err := d.UnmarshalAgxDetect(result); err != nil {
				logger.Errorf(err.Error())
			}
			logger.Info("msg : ", result)
		}
	case mavlink.AgxMsgPerception:
		if d.agxLimit.perceptionLimit.Allow() {
			d.ReceiveAgxPerceptionRes()
		} else {
			logger.Error("speed of agx perception is quite fast,msgid:", d.MsgId, " Sn: ", string(d.Sn))
			result := &mavlink.AgxPerceptionResult{}
			if err := d.UnmarshalAgxPerception(result); err != nil {
				logger.Errorf(err.Error())
			}
			logger.Info("msg : ", result)
		}

	case mavlink.AgxMsgPerceptionPlus: //适配雷视和sfl200
		if d.agxLimit.perceptionLimit.Allow() {
			d.ReceiveAgxPerceptionE0Res()

		} else {
			logger.Error("speed of agx perception E0 is quite fast,msgid:", d.MsgId, " Sn: ", string(d.Sn))

			result := &mavlink.AgxPerceptionE0Result{}
			d.GetPacket(result)

			devSn := d.getSn()
			if devSn != "" {
				d.updateStatus(devSn)
			}
		}

	case mavlink.AgxMsgDeviceStatus:
		if d.agxLimit.deviceStatusLimit.Allow() {
			d.ReceiveAgxDeviceStatusRes()
		} else {
			logger.Error("speed of agx deviceStatus is quite fast,msgid:", d.MsgId, " Sn: ", string(d.Sn))
			result := &mavlink.AgxDevStateResult{}
			if err := d.UnmarshalAgxDevState(result); err != nil {
				logger.Errorf(err.Error())
			}
			logger.Info("msg : ", result)
		}
	case mavlink.AgxMsgPTZStatus:
		if d.agxLimit.pTZStatusLimit.Allow() {
			d.ReceiveAgxPTZStatusRes()
		} else {
			logger.Error("speed of agx ptzStatus is quite fast,msgid:", d.MsgId, " Sn: ", string(d.Sn))
			result := &mavlink.AgxPTZStateResultData{}
			if err := d.UnmarshalAgxPTZState(result); err != nil {
				logger.Errorf(err.Error())
			}
			logger.Info("msg : ", result)
		}
	case mavlink.AgxCalibrationResult:
		d.ReceiveAgxCalibrationResultRes()
	case mavlink.AgxTransferDevMsg:
		d.ReceiveAgxTransferDevMsg()
	//已废弃
	//case mavlink.AgxSendMsgSfl:
	//d.ReceiveAgxSelectSflUav()

	case mavlink.AgxMsgTrackStatus:
		d.ReceiveAgxTrackStateRes()
	case mavlink.AgxIdUpgradeF1:
		d.ReceiveAgxUpdateF1()
	case mavlink.AgxIdUpgradeF2:
		d.ReceiveAgxUpdateF2()
	case mavlink.AgxIdUpgradeF3:
		d.ReceiveAgxUpdateF3()
	case mavlink.AgxGetTime:
		d.ReceiveGetTime()
	case mavlink.AgxSetCalibrationPara:
		d.ReceiveAgxSetCalibrationResultRes()
	case mavlink.AgxGetCalibrationPara:
		d.ReceiveAgxGetCalibrationResultRes()
	case mavlink.AgxGetPTZDeviceMsg:
		d.ReceiveAgxPTZGetMessageResultRes()
	case mavlink.AgxPTZControlReq:
		d.ReceiveAgxPTZControlRequestResultRes()
	case mavlink.AgxPTZZoomReq:
		d.ReceivePTZZoomRequestResultRes()
	case mavlink.AgxUserStatusSetReq:
		d.ReceiveAgxUserStatusSetReqResultRes()
	case mavlink.AgxGetVersion:
		d.ReceiveAgxGetVersionRes()

	//中程雷视一体化
	//融合目标上报
	case mavlink.AgxMsgFusionDetectV2:
		d.ReceiveFusionDetectV2()
	//伺服角度上报（中程雷达特有）
	case mavlink.AgxMsgDphServoStatus:
		d.ReceiveServoStateInfo()
	//一体化心跳包
	case mavlink.AgxMsgIdHeartbeatWithDeviceList:
		d.ReceiveProxyHeartbeat()
	//雷视基本信息（经纬度修改，C2重启，嵌入式重启都会上报）
	case mavlink.AgxMsgLocationInfo:
		d.ReceiveAgxLocationInfoRes()
	//消息转发0xfd
	case mavlink.AgxMsgInfoForward:
		d.ReceiveAgxInfoForward()

	//手动标定
	//srp100开始、退出标定
	case mavlink.Srp100MsgCalibration:
		d.ReceiveSrp100Calibration()
	//srp100获取标定状态，或者标定完成，agx主动上报
	case mavlink.Srp100MsgGetCalibrationStatus:
		d.ReceiveSrp100GetCalibrationStatus()
	//srp100用户下发手点像素目标值
	case mavlink.Srp100MsgHandTargetPoint:
		d.ReceiveSrp100UserHandTarget()
	//srp100主动上报标定数据
	case mavlink.Srp100MsgReportCalibrationData:
		d.ReceiveSrp100CalibrationData()
	//srp100查询标定结果或上报
	case mavlink.Srp100MsgGetCalibrationResult:
		d.ReceiveSrp100GetCalibrationResult()
	//标定确认
	case mavlink.Srp100MsgConfirmCalibration:
		d.ReceiveSrp100ConfirmCalibration()

	//激光->激光雷视->C2
	case mavlink.AgxProxySbp100:
		d.ReceiveSbp100Proxy()
	default:
		logger.Error("Agx 未知Agx消息id:", d.MsgId)
		break
	}
}
func SendAgxHeart() {
	ticker := time.NewTicker(time.Second * 1)
	defer ticker.Stop()
	for range ticker.C {
		DevStatusMap.Range(func(key, value interface{}) bool {
			dev := value.(*Device)
			if dev.Status == common.DevOnline && (dev.DevType == common.DEV_AGX || dev.DevType == common.DEV_SRP150 || dev.DevType == common.DEV_SRP200) {
				reqMode := &Agx{
					Device: dev,
					dt:     dev.DevType,
				}
				reqMode.SendExtHeartbeat()
				//发送0x92 请求标定状态
				if dev.DevType == common.DEV_AGX {
					reqMode.SendCalibrationStatus()
				}
			}
			return true
		})
	}
}
func (d *Agx) SendExtHeartbeat() error {
	AgxHeartSum++
	if AgxHeartSum > 255 {
		AgxHeartSum = 0
	}
	req := &mavlink.AgxHeartbeatExtRequest{
		Sum: AgxHeartSum,
	}
	var devType int32
	if d != nil {
		devType = int32(d.DevType)
	}
	if devType == 0 {
		return errors.New("device type err")
	}
	reqBuff := req.CreateAgxHeartbeatExt(devType)
	if d != nil && d.Conn != nil {
		_, err := d.Conn.Write(reqBuff)
		logger.Infof("Agx c2发送心跳结果：%X", reqBuff)
		if err != nil {
			if d.Sn != "" {
				equipModel, err := GetEquipBySn(d.Sn)
				name := d.Sn
				if equipModel != nil && equipModel.Name != "" {
					name = equipModel.Name
				}

				if d.DevType == common.DEV_SRP200 {
					err1 := NewEquipList().DeleteSubDevices(context.Background(), d.Sn)
					if err1 != nil {
						logger.Errorf("SendExtHeartbeat DeleteSubDevices err", err1)
					}
				}
				dataInfo := &client.AgxHeartBeatInfo{
					Header: &client.EquipmentMessageBoxEntity{
						Name:      name,
						Sn:        d.Sn,
						EquipType: int32(d.DevType),
						MsgType:   mavlink.AgxMsgHeartBeat,
					},
					Data: &client.AgxHeartBeatReport{
						Sn:       d.Sn,
						IsOnline: common.DevOffline,
					},
				}
				if err == nil {
					dataInfo.Header.ParentSn = equipModel.ParentSn
					dataInfo.Header.ParentType = int32(equipModel.ParentType)
					dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
				}
				msg, err := proto.Marshal(dataInfo)
				if err != nil {
					logger.Error("marshal dataInfo err:", err)
					return err
				}
				report := &client.ClientReport{
					MsgType: common.ClientMsgIdAgxHeartData,
					Data:    msg,
				}
				out, err := proto.Marshal(report)
				if err != nil {
					logger.Error("marshal report err:", err)
					return err
				}
				_ = mq.AgxMsgBroker.Publish(mq.AgxTopic, broker.NewMessage(out))
				logger.Info("agx Offline report:", dataInfo)
			}
		}
		return err
	}
	return nil
}

func (d *Agx) SendCalibrationStatus() error {
	req := &mavlink.Srp100GetCalibrationStatusRequest{
		State: 0,
	}
	reqBuff := req.Create(int32(req.State))
	if d != nil && d.Conn != nil {
		_, err := d.Conn.Write(reqBuff)
		logger.Infof("Agx c2发送请求标定状态：%X， err: %v", reqBuff, err)
		return err
	}
	return nil
}

// AgxOfflineReport Agx设备离线处理
func AgxOfflineReport(sn string, dev_type common.DeviceType) {
	var tcpServer *server.TcpServer
	if s, ok := AgxTcpServerMap.Load(sn); ok {
		tcpServer = s.(*server.TcpServer)

		if tcpServer != nil {
			tcpServer.Stop()
		}
		deviceUsedPorts.Delete(tcpServer.Port)
		AgxTcpServerMap.Delete(sn)
		DevSnMap.Delete(tcpServer.Port)
		cachekeyDroneid := fmt.Sprintf("%d_%s", dev_type, sn)
		DevStatusMap.Delete(cachekeyDroneid)
		if LaserSn != "" {
			cacheKey := fmt.Sprintf("%d_%s", common.DEV_LASER, LaserSn)
			DevStatusMap.Delete(cacheKey)
		}
		tcpServer = nil
	}

	equipModel, err := GetEquipBySn(sn)
	name := sn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	//一体化设备不能变成非一体化，一体化下的子设备会发生变化
	if dev_type == common.DEV_SRP200 {
		if err := NewEquipList().DeleteSubDevices(context.Background(), sn); err != nil {
			logger.Error("delete sub devices err:", err)
		}
	}
	dataInfo := &client.AgxHeartBeatInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        sn,
			EquipType: int32(dev_type),
			MsgType:   mavlink.AgxMsgHeartBeat,
		},
		Data: &client.AgxHeartBeatReport{
			Sn:       sn,
			IsOnline: common.DevOffline,
		},
	}
	if err == nil {
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIdAgxHeartData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.AgxMsgBroker.Publish(mq.AgxTopic, broker.NewMessage(out))
	logger.Info("Agx Offline report:", dataInfo)
	err = NewEquipList().UpdateSfl200ParentSn(context.Background(), &client.UpdateSfl200ParentSnReq{Sfl200Sn: sn}, &client.UpdateSfl200ParentSnRes{})
	if err != nil {
		logger.Error("Update Sfl200 Status err: ", err)
	}
	AgxOffLineEventReport(sn, dev_type)
}

// HandleBroadCast 处理广播消息
func (d *Agx) HandleBroadCast(ctx context.Context, req *slinkv1.UdpBroadcastConfirmRequest) (*slinkv1.UdpBroadcastConfirmResponse, error) {

	if req.GetSn() == "" {
		logger.Info("device sn empty")
		return nil, errors.New("device sn empty")
	}
	d.GetStatus(req.GetSn(), req.DeviceType)
	logger.Debug("req.DeviceType = ", req.DeviceType)
	// GagxDeviceType = common.DeviceType(req.DeviceType)
	//if status := d.GetStatus(req.GetSn()); status == common.DeviceDisenable {
	//	logger.Infof("device %v disable", req.GetSn())
	//	return nil, nil
	//}

	localIP := make([]string, 0)
	localIps, broadIps, err := ip.GetBroadcastAddress()
	if err != nil {
		logger.Error("Get IP error :%v", err)
	}
	for i, ip := range localIps {
		if i >= len(broadIps) {
			continue
		}
		localIP = append(localIP, ip)
	}
	logger.Debugf("[Fpv] localIP:%v,", localIP)

	tcpServer := d.TcpServerCheck(req.GetSn(), localIP, uint8(req.DeviceType))
	DevSnMap.Store(tcpServer.Port, req.GetSn())
	d.ServerPort = tcpServer.Port
	var tempSn [32]byte
	for i, v := range []byte(req.GetSn()) {
		tempSn[i] = v
	}
	//响应
	rsp := &slinkv1.UdpBroadcastConfirmResponse{
		Sn:       tempSn,
		Addr:     ip.IPV4(tcpServer.Ip),
		Port:     uint16(tcpServer.Port),
		ConnType: 1,
	}
	return rsp, nil
}

func (d *Agx) GetStatus(sn string, dev_type uint16) int32 {
	statusRes := &client.GetStatusRes{}
	etype := common.Agx
	switch dev_type {
	case uint16(common.DEV_AGX):
		etype = common.Agx
	case uint16(common.DEV_SRP150):
		etype = common.SRP150
	case uint16(common.DEV_SRP200):
		etype = common.SRP200
	case uint16(common.DEV_SBP100):
		etype = common.SBP100
	}
	err := NewEquipList().GetStatus(context.Background(), &client.GetStatusReq{Sn: sn, EType: etype}, statusRes)
	if err != nil {
		logger.Errorf("GetStatus err: %v", err.Error())
		return 0
	}

	return statusRes.IsEnable
}

func (d *Agx) TcpServerCheck(devSn string, localIP []string, devType uint8) *server.TcpServer {
	var tcpServer *server.TcpServer
	if s, ok := AgxTcpServerMap.Load(devSn); ok {
		tcpServer = s.(*server.TcpServer)
		isAlike := false
		for _, ip := range localIP {
			if ip == tcpServer.Ip {
				isAlike = true
			}
		}
		if isAlike == false { //查找的本地IP没有与之前相同的
			if tcpServer != nil {
				tcpServer.Stop()
			}
			deviceUsedPorts.Delete(tcpServer.Port)
			AgxTcpServerMap.Delete(devSn)
			DevSnMap.Delete(tcpServer.Port)
			tcpServer = nil
		}
	}

	//注册tcp服务
	if tcpServer == nil {
		port, err := ip.GetFreeTcpPort()
		if err != nil {
			logger.Error("Agx tcp 获取可用端口失败：", err)
			port = d.getRandPort(AgxTcpPort, AgxTcpPort+AgxServerMaxCount)
		}
		tcpServer = server.NewTcpServer(port, Handle)
		AgxTcpServerMap.Store(devSn, tcpServer)
		logger.Debug("devType = ", devType)
		tcpServer.ServerType = devType
		tcpServer.ServerName = devSn
		localAddr, _ := ip.GetLocalIp(d.UdpIp)
		tcpServer.Ip = localAddr
		go tcpServer.Start()
	}
	return tcpServer
}
func (d *Agx) getRandPort(min, max int64) int {
	maxBigInt := big.NewInt(max)
	i, _ := rand.Int(rand.Reader, maxBigInt)
	_, ok := deviceUsedPorts.Load(i.Int64())
	port := i.Int64()
	//缓存不存在或者符合范围
	if !ok && (port > min && port < max) {
		deviceUsedPorts.Store(port, port)
		return int(port)
	}
	return d.getRandPort(min, max)
}

func (d *Agx) ReceiveGetChannelReq() {
	AgxTcpServerLock.Lock()
	defer AgxTcpServerLock.Unlock()

	devSn := d.UnMarshalGetChannelReq()
	if devSn == "" {
		logger.Info("Agx device sn empty")
		return
	}

	//if isContinue := d.deviceDiscover(devSn); !isContinue {
	//	logger.Error("droneID等待设备确认：", devSn)
	//	return
	//}
	d.GetStatus(devSn, uint16(d.DevType))
	//if status := d.GetStatus(devSn); status == common.DeviceDisenable {
	//	logger.Infof("Agx device %v disable", devSn)
	//	return
	//}

	localIP := make([]string, 0)

	localIps, broadIps, err := ip.GetBroadcastAddress()
	if err != nil {
		logger.Error("Agx Get IP error :%v", err)
	}
	for i, ip := range localIps {
		if i >= len(broadIps) {
			continue
		}
		localIP = append(localIP, ip)
	}
	logger.Debugf("[Agx] localIP:%v,", localIP)

	tcpServer := d.TcpServerCheck(devSn, localIP, uint8(d.DevType))
	DevSnMap.Store(tcpServer.Port, devSn)
	d.ServerPort = tcpServer.Port

	//响应
	switch d.MsgId {
	case mavlink.AgxUdpBroadcastResponse:
		logger.Info("[Agx] receive Broadcast BB Msg")
		UdpBroadcastSendChannel(devSn, d.UdpIp, d.SourceId, tcpServer)
		err := NewEquipList().Update(context.Background(), &client.EquipCrudReq{
			Sn: devSn,
			Ip: d.UdpIp,
		}, &client.EquipCrudRes{})
		if err != nil {
			logger.Error("Update EquipList err: ", err)
			return
		}
		break
	default:
		break
	}

	return
}
func (d *Agx) UnMarshalGetChannelReq() string {
	devSn := ""
	switch d.MsgId {
	case mavlink.AgxUdpBroadcastResponse:
		req := &mavlink.UdpBroadcastConfirmRequest{}
		d.GetPacket(req)
		devSn = strings.TrimRight(string(req.Sn[:]), string(rune(0)))
		break
	default:
		break
	}
	return devSn
}

func (d *Agx) GetPacket(message mavlink.Message) *mavlink.MavPacket {
	defer func() {
		if err := recover(); err != nil {
			logger.Error("Agx GetPacket panic:", err)
		}
	}()
	logger.Infof("Agx GetPacket is [% x]", d.Msg)
	req := mavlink.NewNullPacket(message)
	buff := &bytes.Buffer{}
	if err := binary.Write(buff, binary.LittleEndian, d.Msg); err != nil {
		logger.Error("Agx GetPacket write buff err:", err)
		return nil

	}
	if err := binary.Read(buff, binary.LittleEndian, &req.Header); err != nil {
		logger.Error("Agx GetPacket read header err:", err)
		return nil
	}
	if err := binary.Read(buff, binary.LittleEndian, req.Msg); err != nil {
		logger.Error("Agx GetPacket read msg err:", err)
		return nil
	}
	return req
}
func (d *Agx) getSn() string {
	if sn, ok := DevSnMap.Load(d.ServerPort); ok {
		return sn.(string)
	}
	return ""
}
func (d *Agx) updateStatus(sn string) int32 {
	if d.DevType == common.DEV_SBP100 && d.LaserSn != "" {
		d.updateLaserStatus(d.LaserSn)
	}
	logger.Debug(" d.DevType = ", d.DevType)
	cacheKey := fmt.Sprintf("%d_%s", d.DevType, sn)
	if cache, ok := DevStatusMap.Load(cacheKey); ok {
		dev := cache.(*Device)
		//if dev.IsEnable == common.DeviceDisenable {
		//	return common.DeviceDisenable
		//}
		dev.Status = common.DevOnline
		dev.Conn = d.Conn
		dev.WaitTaskMap = d.WaitTaskMap
		dev.RemoteIp = d.RemoteIp
		dev.LastHeartTime = time.Now()
		dev.GetStatusInterval = time.Now()
		//if dev.IsEnable != common.DeviceDisenable && dev.IsEnable != common.DeviceEnable {
		//	dev.IsEnable = d.GetStatus(sn)
		//}
		return common.DeviceEnable
	} else {
		dev := &Device{
			Sn:                sn,
			Conn:              d.Conn,
			Status:            common.DevOnline,
			RemoteIp:          d.RemoteIp,
			RemotePort:        d.RemotePort,
			LocalIp:           d.LocalIp,
			ServerPort:        d.ServerPort,
			DevType:           d.DevType,
			FirstHeartTime:    time.Now(),
			LastHeartTime:     time.Now(),
			SourceId:          d.SourceId,
			IsEnable:          common.DeviceEnable,
			GetStatusInterval: time.Now(),
			WaitTaskMap:       d.WaitTaskMap,
		}
		DevStatusMap.Store(cacheKey, dev)
		go func() {
			deviceReq := &client.AgxGetCalibrationParaRequest{}
			deviceRsp := &client.AgxGetCalibrationParaRespone{}
			deviceReq.Sn = sn
			err := NewDeviceCenter().AgxGetCalibrationPara(context.Background(), deviceReq, deviceRsp)
			if err != nil {
				logger.Error("Get Agx Calibration Para err: ", err)
			}

			//获取设备版本号
			getAgxVersion(sn, int32(d.DevType))
		}()

		return common.DeviceEnable
	}
}

func getAgxVersion(sn string, devType int32) {
	getVersionReq := &client.AgxGetVersionRequest{
		Sn:        sn,
		EquipType: devType,
	}
	getVersionRsp := &client.AgxGetVersionResponse{}
	err := NewDeviceCenter().AgxGetVersion(context.Background(), getVersionReq, getVersionRsp)
	if err != nil {
		logger.Error("Get Agx Version err: ", err)
	} else {
		if getVersionRsp.AppVersion != "" {
			//更新设备版本号
			if err := NewEquipList().Update(context.Background(), &client.EquipCrudReq{
				Sn:         sn,
				DevVersion: getVersionRsp.AppVersion,
				IsOnline:   true,
			}, &client.EquipCrudRes{}); err != nil {
				logger.Error("Update Agx Version err: ", err)
			}
		}
	}
}

func (d *Agx) updateLaserStatus(sn string) int32 {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_LASER, sn)
	if cache, ok := DevStatusMap.Load(cacheKey); ok {
		dev := cache.(*Device)
		dev.Status = common.DevOnline
		dev.LastHeartTime = time.Now()
		dev.GetStatusInterval = time.Now()
		return common.DeviceEnable
	} else {
		dev := &Device{
			Sn:                sn,
			Status:            common.DevOnline,
			DevType:           common.DEV_LASER,
			FirstHeartTime:    time.Now(),
			LastHeartTime:     time.Now(),
			IsEnable:          common.DeviceEnable,
			GetStatusInterval: time.Now(),
		}
		DevStatusMap.Store(cacheKey, dev)
		return common.DeviceEnable
	}
}
func (d *Agx) updateStatusOnLine(sn string) {
	cacheKey := fmt.Sprintf("%d_%s", d.DevType, sn)
	if cache, ok := DevStatusMapOnEvent.Load(cacheKey); ok {
		dev := cache.(*Device)
		dev.LastHeartTime = time.Now()
		dev.GetStatusInterval = time.Now()
		DevStatusMapOnEvent.Store(cacheKey, cache)

		return
	}
	dev := &Device{
		Sn:                sn,
		Status:            common.DevOnline,
		RemoteIp:          d.RemoteIp,
		RemotePort:        d.RemotePort,
		LocalIp:           d.LocalIp,
		ServerPort:        d.ServerPort,
		DevType:           d.DevType,
		FirstHeartTime:    time.Now(),
		LastHeartTime:     time.Now(),
		SourceId:          d.SourceId,
		IsEnable:          d.GetStatus(sn, uint16(d.DevType)), //Notice...
		GetStatusInterval: time.Now(),
		SessionId:         GetGlobalSessionId(),
		WorkMode:          d.WorkMode,
	}
	DevStatusMapOnEvent.Store(cacheKey, dev)

	go func() {
		equipModel, err := GetEquipBySn(sn)
		name := sn
		if equipModel != nil && equipModel.Name != "" {
			name = equipModel.Name
		}
		dataInfo := &client.AgxHeartBeatInfo{
			Header: &client.EquipmentMessageBoxEntity{
				Name:      name,
				Sn:        sn,
				EquipType: int32(d.DevType),
				MsgType:   mavlink.AgxEventOnLine,
			},
			Data: &client.AgxHeartBeatReport{
				Sn:       sn,
				IsOnline: common.DevOnline,
				EventId:  utils.GetEventId(dev.SessionId),
				//需要查询下表：因为tracer不携带经纬度信息。由c2获取
				//GunLatitude:  float64(heartInfo.Info.GunLatitude) / GunLatitudeTion,
				//GunLongitude: float64(heartInfo.Info.GunLongitude) / GunLongitudeTion,
			},
		}
		if err == nil {
			dataInfo.Header.ParentType = int32(equipModel.ParentType)
			dataInfo.Header.ParentSn = equipModel.ParentSn
			dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
		}
		msg, err := proto.Marshal(dataInfo)
		if err != nil {
			logger.Error("marshal dataInfo err:", err)
			return
		}

		report := &client.ClientReport{
			MsgType: common.ClientMsgAgxStatusEventData,
			Data:    msg,
		}
		out, err := proto.Marshal(report)
		if err != nil {
			logger.Error("marshal report err:", err)
			return
		}
		_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
		logger.Infof("agx heartbeat event has reported, devSn: %v,report:%v", sn, dataInfo.Data)
	}()
	return
}
func (d *Agx) ReceiveAgxHeartBeat() {
	heart := &mavlink.AgxHeart{}
	d.GetPacket(heart)
	devSn := d.getSn()
	d.updateStatus(devSn)
	//if isEnable := d.updateStatus(devSn); isEnable == common.DeviceDisenable {
	//	logger.Infof("Agx device %v disable", devSn)
	//	return
	//}
	logger.Info("Receive Agx Heart:", heart, devSn)
	logger.Debug(" d.DevType = %v", d.DevType)
	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	//设备会同时上报一体化心跳e5 和心跳包ea，只上报非一体化设备的心跳
	if equipModel.IsIntegrated == 1 {
		logger.Debugf("Agx device %v integrated: %v", devSn, equipModel.IsIntegrated)
		return
	}
	dataInfo := &client.AgxHeartBeatInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        devSn,
			EquipType: int32(d.DevType),
			MsgType:   mavlink.AgxMsgHeartBeat,
		},
		Data: &client.AgxHeartBeatReport{
			Electricity: int32(heart.Electricity),
			Status:      int32(heart.Status),
			IsOnline:    common.DevOnline,
			Ip:          d.RemoteIp,
			Sn:          devSn,
		},
	}
	if err == nil {
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	if dataInfo.Data.Ip == "" {
		if equipModel != nil {
			dataInfo.Data.Ip = equipModel.Ip
		}
		//dbequips := &client.EquipListRes{}
		//err := NewEquipList().List(context.Background(), &client.EquipListReq{}, dbequips)
		//if err != nil {
		//	logger.Info("Get EquipList err: ", err)
		//}
		//for _, equip := range dbequips.Equips {
		//	if equip.Sn == dataInfo.Data.Sn {
		//		dataInfo.Data.Ip = equip.Ip
		//	}
		//}
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIdAgxHeartData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}
	d.updateStatusOnLine(devSn)

	_ = mq.AgxMsgBroker.Publish(mq.AgxTopic, broker.NewMessage(out))
	logger.Info("Agx heart report:", dataInfo)
}

// ReceiveAgxPerceptionRes 收到Agx感知信息上报
func (d *Agx) ReceiveAgxPerceptionRes() {
	logger.Info("--->Into Receive Agx Perception")
	devSn := d.getSn()
	result := &mavlink.AgxPerceptionResult{}
	if err := d.UnmarshalAgxPerception(result); err != nil {
		logger.Errorf(err.Error())
		return
	}
	if devSn != "" {
		d.updateStatus(devSn)
		//if isEnable := d.updateStatus(devSn); isEnable == common.DeviceDisenable {
		//	logger.Infof("Agx device %v disable", devSn)
		//	return
		//}
		d.agxPerceptionReport(devSn, result)
	}
	logger.Info("--->End Receive Agx Perception")
}
func (d *Agx) ReceiveAgxPerceptionE0Res() {
	logger.Info("--->Into Receive Agx Perception E0")
	devSn := d.getSn()
	result := &mavlink.AgxPerceptionE0Result{}
	d.GetPacket(result)
	if devSn != "" {
		d.updateStatus(devSn)
		d.agxPerceptionE0Report(devSn, result)
	}
	logger.Info("--->End Receive Agx PerceptionE0")
}

func (d *Agx) agxPerceptionReport(devSn string, agxInfo *mavlink.AgxPerceptionResult) {
	logger.Info("--->Into Receive agx  Perception Report")
	agxResult := make([]*client.AgxPerceptionReportInfo, 0)

	for _, agx := range agxInfo.Description {
		r := &client.AgxPerceptionReportInfo{
			Id:             int32(agx.Id),
			Classification: int32(agx.Classification),
			RectX:          int32(agx.RectX),
			RectY:          int32(agx.RectY),
			RectW:          int32(agx.RectW),
			RectH:          int32(agx.RectH),
			RectXV:         int32(agx.RectXV),
			RectYV:         int32(agx.RectYV),
			ClassFyProb:    agx.ClassFvProb,
			Type:           int32(agx.Type),
			TypeProb:       agx.TypeProb,
			LoadLever:      int32(agx.LoadLever),
			DangerLever:    int32(agx.DangerLever),
			Azimuth:        agx.Azimuth,
			Elevation:      agx.Elevation,
			Range:          agx.Range,
			MotionType:     int32(agx.MotionType),
			BTracked:       int32(agx.BTracked),
			NewOldVersion:  1,
		}
		logger.Infof("agx Info data: %+v", agx)
		agxResult = append(agxResult, r)
	}
	logger.Debug("d.DevType = ", d.DevType)
	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	dataInfo := &client.AgxPerceptionInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        devSn,
			EquipType: int32(d.DevType),
			MsgType:   mavlink.AgxMsgPerception,
		},
		Data: &client.AgxPerceptionReport{
			Sn:        devSn,
			TimeStamp: int32(agxInfo.Info.TimeStamp),
			ObjId:     int32(agxInfo.Info.ObjNum),
			TargetId:  int32(agxInfo.Info.TargetId),
			Zoom:      agxInfo.Info.Zoom,
			HFov:      agxInfo.Info.HFov,
			VFov:      agxInfo.Info.VFov,
			List:      agxResult,
		},
	}
	if err == nil {
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIdAgxPerceptionData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}
	_ = mq.AgxMsgBroker.Publish(mq.AgxTopic, broker.NewMessage(out))
	logger.Infof("Agx has perception reported, devSn: %v, data info %v", devSn, dataInfo)
}
func (d *Agx) agxPerceptionE0Report(devSn string, agxInfo *mavlink.AgxPerceptionE0Result) {
	logger.Info("--->Into Receive agx  PerceptionE0 Report")
	agxResult := &client.AgxPerceptionReportE0{
		TimeStamp: agxInfo.TimeStamp,
		// 设备ID号
		DevId: agxInfo.DevId,
		// 设备序列号
		Sn: ByteToString(agxInfo.Sn[:]),
		// 引导帧序号
		GuidanceCount: agxInfo.GuidanceCount,
		// 空闲：0;
		// 引导转动：1
		// 搜索目标：2
		// 锁定：3
		WorkingStatus: uint32(agxInfo.WorkingStatus),
		// 视觉目标ID
		VisionTargetId: agxInfo.VisionTargetId,
		// 视觉目标宽度方向像素坐标
		VisionTargetU: agxInfo.VisionTargetU,
		// 视觉目标高度方向像素坐标
		VisionTargetV: agxInfo.VisionTargetV,
		// 视觉目标宽度方向像素速度
		VisionTargetVelocityU: agxInfo.VisionTargetVelocityU,
		// 视觉目标高度方向像素速度
		VisionTargetVelocityV: agxInfo.VisionTargetVelocityV,
		// 融合目标ID
		FusionTargetId: agxInfo.FusionTargetId,
		// 融合目标的相对径向距离
		TargetLocalRange: agxInfo.TargetLocalRange,
		// 融合目标的相对水平面距离
		TargetLocalHorizontalRange: agxInfo.TargetLocalHorizontalRange,
		// 融合目标的对地高度
		Height: agxInfo.Height,
		// PTZ水平角度
		GuidingLocalAzimuth: agxInfo.GuidingLocalAzimuth,
		// PTZ俯仰角度
		GuidingLocalElevation: agxInfo.GuidingLocalElevation,
		Longitude:             agxInfo.Longitude,
		Latitude:              agxInfo.Latitude,
		Altitude:              agxInfo.Altitude,
		// 未知类别：0
		// 无人机：1
		// 行人：2
		// 车辆：3
		// 鸟：4
		// 客机：5
		// 其他：100
		// 分类无效：127
		FusionTargetClassification: uint32(agxInfo.FusionTargetClassification),
		// 画中画: 0开启了，1未开启
		PipValid: uint32(agxInfo.PipValid),
		// 备用
	}
	for _, v := range agxInfo.Reserve {
		agxResult.Reserve = append(agxResult.Reserve, uint32(v))
	}

	dataInfo := &client.AgxPerceptionE0Info{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      devSn,
			Sn:        devSn,
			EquipType: int32(d.DevType),
			MsgType:   mavlink.AgxMsgPerceptionPlus,
		},
		Data: agxResult,
	}

	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIdPtzTrackTargetData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}
	_ = mq.AgxMsgBroker.Publish(mq.AgxTopic, broker.NewMessage(out))
	logger.Infof("Agx has perception Eo reported, devSn: %v, data info %v", devSn, dataInfo)

}
func (d *Agx) agxPerceptionPlusReport(devSn string, agxInfo *mavlink.AgxPerceptionPlusResult) {
	logger.Info("--->Into Receive agx  Perception Report")
	agxResult := make([]*client.AgxPerceptionReportInfo, 0)

	for _, agx := range agxInfo.Description {
		r := &client.AgxPerceptionReportInfo{
			Id:             int32(agx.Id),
			Classification: int32(agx.Classification),
			ClassFyProb:    agx.ClassFvProb,
			Type:           int32(agx.Type),
			TypeProb:       agx.TypeProb,
			LoadLever:      int32(agx.LoadLever),
			DangerLever:    int32(agx.DangerLever),
			Azimuth:        agx.Azimuth,
			Elevation:      agx.Elevation,
			Range:          agx.Range,
			MotionType:     int32(agx.MotionType),
			BTracked:       int32(agx.BTracked),
			NewOldVersion:  2,                  //1： old, 2: new version
			VisFlag:        int32(agx.VisFlag), //可见光
			VisX:           agx.VisX,
			VisY:           agx.VisY,
			VisW:           agx.VisW,
			VisH:           agx.VisH,
			VisXV:          agx.VistXV,
			VisYV:          agx.VisYV,
			InfFlag:        int32(agx.InfFlag), //红外
			InfX:           agx.InfX,
			InfY:           agx.InfY,
			InfW:           agx.InfW,
			InfH:           agx.InfH,
			InfXV:          agx.InfXV,
			InfYV:          agx.InfYV,
		}
		logger.Infof("agx Info data: %+v", agx)
		agxResult = append(agxResult, r)
	}
	logger.Debug("d.DevType = ", d.DevType)
	dataInfo := &client.AgxPerceptionInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      devSn,
			Sn:        devSn,
			EquipType: int32(d.DevType),
			MsgType:   mavlink.AgxMsgPerceptionPlus,
		},
		Data: &client.AgxPerceptionReport{
			Sn:        devSn,
			TimeStamp: int32(agxInfo.Info.TimeStamp),
			ObjId:     int32(agxInfo.Info.ObjNum),
			TargetId:  int32(agxInfo.Info.TargetId),
			Zoom:      agxInfo.Info.Zoom,
			HFov:      agxInfo.Info.HFov,
			VFov:      agxInfo.Info.VFov,
			List:      agxResult,
		},
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIdAgxPerceptionData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}
	_ = mq.AgxMsgBroker.Publish(mq.AgxTopic, broker.NewMessage(out))
	logger.Infof("Agx has perception reported, devSn: %v, data info %v", devSn, dataInfo)
}

func (d *Agx) UnmarshalAgxPerception(data *mavlink.AgxPerceptionResult) error {
	deviceInfoLen := binary.Size(mavlink.AgxPerceptionInfo{})
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}

	start := mavlink.HeaderLen + deviceInfoLen
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializeDrone(d.Msg[start:end]); err != nil {
		return err
	}

	return nil
}

func (d *Agx) UnmarshalAgxPerceptionPlus(data *mavlink.AgxPerceptionPlusResult) error {
	deviceInfoLen := binary.Size(mavlink.AgxPerceptionPlusInfo{})
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}

	start := mavlink.HeaderLen + deviceInfoLen
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializeDrone(d.Msg[start:end]); err != nil {
		return err
	}

	return nil
}

// ReceiveAgxDetectRes 收到Agx无人机信息上报
func (d *Agx) ReceiveAgxDetectRes() {
	logger.Info("--->Into Receive Agx Detect")
	devSn := d.getSn()
	result := &mavlink.AgxDetectResult{}
	if err := d.UnmarshalAgxDetect(result); err != nil {
		logger.Errorf(err.Error())
		return
	}
	if devSn != "" {
		d.updateStatus(devSn)
		//if isEnable := d.updateStatus(devSn); isEnable == common.DeviceDisenable {
		//	logger.Infof("Agx device %v disable", devSn)
		//	return
		//}
		d.agxDetectReport(devSn, result)
	}
	logger.Info("--->End Receive Agx Detect")
}
func CheckUavLocked(history []*DetectUavItem, objId uint32) bool {
	if history == nil || len(history) <= 0 {
		return false
	}
	for _, item := range history {
		if item == nil {
			continue
		}
		if item.ObjectId == objId {
			return true
		}
	}
	return false
}
func (d *Agx) updateAgxDetectEvent(sn string, detectInfo []*client.AgxDetectInfoList) string {
	cacheKey := fmt.Sprintf("%d_%s", d.DevType, sn)

	if cache, ok := DevDetectMapOnEvent.Load(cacheKey); ok {
		detect := cache.(*DetectEvent)
		detect.LastReceiveTime = time.Now()

		for _, uav := range detectInfo {
			if uav == nil {
				continue
			}
			//
			var isLockedByPtz uint32 = uav.AssocBit1
			if isLockedByPtz == 0 {
				continue
			}
			//只记录 当前有被锁定且之前未被锁定但的无人机。
			if !CheckUavLocked(detect.Items, uav.ObjId) {
				logger.Infof("uav not been locked previously, this time is locked by ptz, uav: %v", uav.ObjId)
				detect.Items = append(detect.Items, &DetectUavItem{
					ObjectId:    uav.ObjId,
					LockedUavIs: int8(isLockedByPtz),
					LockedTime:  time.Now(),
				})
			}
		}

		DevDetectMapOnEvent.Store(cacheKey, cache)
		return detect.EventID
	}

	if len(detectInfo) <= 0 {
		logger.Infof("detect uav info is empty")
		return ""
	}

	detect := &DetectEvent{
		Sn:               sn,
		LastReceiveTime:  time.Now(),
		DevType:          d.DevType,
		SessionId:        GetGlobalSessionId(),
		LockPtzSessionId: GetGlobalSessionId(),
	}
	// 记录无人机是否被锁定
	genEventID := utils.GetEventId(detect.SessionId)
	for _, uav := range detectInfo {
		if uav == nil {
			continue
		}

		var lockedByPtz uint32 = uav.AssocBit1
		if lockedByPtz == 0 {
			continue
		}
		//记录被锁定的无人机
		logger.Infof("uav locked by ptz firstly, uav: %v", uav.ObjId)
		detect.Items = append(detect.Items, &DetectUavItem{
			ObjectId:    uav.ObjId,
			LockedUavIs: int8(lockedByPtz),
			LockedTime:  time.Now(),
		})
		detect.EventID = genEventID
	}

	DevDetectMapOnEvent.Store(cacheKey, detect)
	equipModel, err := GetEquipBySn(sn)
	name := sn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	eventDetectInfo := &client.AgxDetectInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        sn,
			EquipType: int32(d.DevType),
			MsgType:   mavlink.AgxEventDetectAppear,
		},
		Data:    detectInfo,
		EventId: genEventID,
	}
	if err == nil {
		eventDetectInfo.Header.ParentType = int32(equipModel.ParentType)
		eventDetectInfo.Header.ParentSn = equipModel.ParentSn
		eventDetectInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}

	buBuff, err := proto.Marshal(eventDetectInfo)
	if err != nil {
		logger.Errorf("Marshal TracerDetectInfo err %v", err)
		return ""
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgAgxDetectEventData,
		Data:    buBuff,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return ""
	}
	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Infof("agx detect uav event has reported, devSn: %v,report:%v", sn, detectInfo)
	return genEventID
}

// getAgxLngLatAverage 获取雷视经纬度
func getAgxLngLatAverage(agxSn string) (float64, float64, error) {
	var (
		lngAvg, latAvg float64
		lngSum, latSum float64
	)
	equipList, err := NewEquipList().FindByParentSn(agxSn)
	if err != nil {
		logger.Errorf("getAgxLngLatAverage find equipList failed, err: %v", err)
		return lngAvg, latAvg, err
	}
	for _, equip := range equipList {
		req := &client.RadarGetConfigRequest{
			Sn: equip.Sn,
		}
		rsp := &client.RadarGetConfigResponse{}
		err = NewDeviceCenter().RadarGetConfig(context.Background(), req, rsp)
		if err != nil {
			logger.Errorf("getAgxLngLatAverage RadarGetConfig failed, sn: %v, err: %v", equip.Sn, err)
			return lngAvg, latAvg, err
		}
		lngSum += rsp.GetLongitude()
		latSum += rsp.GetLatitude()
	}
	if err == nil {
		lngAvg = lngSum / float64(len(equipList))
		latAvg = latSum / float64(len(equipList))
	}
	return lngAvg, latAvg, nil
}

func (d *Agx) agxDetectReport(devSn string, agxInfo *mavlink.AgxDetectResult) {
	logger.Info("--->Into Receive agx  Detect Report")
	agxResult := make([]*client.AgxDetectInfoList, 0)
	agxEventResult := make([]*client.AgxDetectInfoList, 0)
	var (
		agxLongitude float64
		agxLatitude  float64
	)
	//if value, ok := agxSnToLocationMap.Load(devSn); ok {
	//	if val, ok := value.(*mavlink.AgxSendGetCalibrationResponse); ok {
	//		agxLongitude = val.Longitude
	//		agxLatitude = val.Latitude
	//	} else {
	//		logger.Errorf("agxDetectReport agxSnToLocationMap value type err, got %+v", reflect.TypeOf(value))
	//	}
	//} else {
	//	logger.Errorf("agxDetectReport agxSnToLocationMap sn %v not exist", devSn)
	//}

	//雷视非一体化，雷视经纬度=雷视下雷达经纬度的平均值
	lngAvg, latAvg, err := getAgxLngLatAverage(devSn)
	if err != nil {
		logger.Errorf("agxDetectReport getAgxLngLatAverage err: %v", err)
	}
	agxLongitude = lngAvg
	agxLatitude = latAvg

	if agxLongitude == 0 && agxLatitude == 0 {
		// 如果设备的经纬度同时为0时，使用C2的经纬度计算无人机的经纬度
		configRes := &client.ConfigRes{}
		if err := NewSystemConfig().GetSystemConfig(context.Background(), &client.ConfigReq{}, configRes); err != nil {
			logger.Errorf("ReceiveTrackInfo failed to get system config: %v", err)
		} else {
			agxLongitude = configRes.C2Longitude
			agxLatitude = configRes.C2Latitude
		}
	}

	//激光雷视
	//判断下发的指定目标，是否在侦测消息中存在
	laser, exist := status[devSn]
	if !exist {
		logger.Errorf("agxDetectReport laser status not exist, sn: %v", devSn)
	}
	foundFlag := false
	sbp100 := Sbp100{
		Agx: d,
	}
	for _, agx := range agxInfo.Description {
		if exist {
			laserSn, ok := laser[int32(agx.Id)]
			if ok {
				//目标存在，转发目标给激光设备
				foundFlag = true
				req := &mavlink.CommandControl{
					Control: &mavlink.Control{
						Radar: &mavlink.Radar{
							GuideMode: lo.ToPtr(1),
							Azimuth:   lo.ToPtr(float64(agx.Azimuth) / 64.0),
							Pitch:     lo.ToPtr(float64(agx.Elevation) / 64.0),
						},
					},
				}
				if err := sbp100.sendControl(laserSn, req); err != nil {
					logger.Errorf("agxDetectReport sendControl err: %v", err)
				}

				laserSn := modeChangeFlag[devSn]
				if laserSn != "" {
					//启动执勤模式
					//1：开始执勤
					//2：结束执勤
					//3：待机
					go func() {
						sbp100.quitAutoLock(&client.SelectUavToLaserDeviceReq{
							AgxSn:   devSn,
							LaserSn: laserSn,
							UavId:   int32(agx.Id),
						}, 1)
						delete(modeChangeFlag, devSn)
					}()
				}
			}
		}

		x, y, z := float64(agx.X)/float64(AgxReducedValue), float64(agx.Y)/float64(AgxReducedValue), float64(agx.Z)/float64(AgxReducedValue)

		//if !AgxSmoothQueue.Contains(agx.Id) {
		//	AgxSmoothQueue.AddQueue(agx.Id, 10)
		//	AgxSmoothQueue.Enqueue(agx.Id, x, y, z)
		//} else {
		//	AgxSmoothQueue.Enqueue(agx.Id, x, y, z)
		//}
		//
		//if AgxSmoothQueue.Length(agx.Id) == 10 {
		//	x, y, z = AgxSmoothQueue.CalculateAverage(agx.Id)
		//}

		//point := common.Coord3D{
		//	X: x,
		//	Y: y,
		//	Z: z,
		//}

		var droneLongitude, droneLatitude float64
		//droneLongitude, droneLatitude = common.ConvertToLatLon(agxLongitude, agxLatitude, point)
		//distance := common.CuaDistance(droneLatitude, droneLongitude, radarLatitudeV1, radarLongitudeV1)

		latLng, err := common.GetLatLngByXY(common.LatLng{
			Latitude:  agxLatitude,
			Longitude: agxLongitude,
		}, -y, x)
		if err != nil {
			logger.Errorf("agxDetectReport GetLatLngByXY err: %v", err)
		} else {
			droneLongitude, droneLatitude = latLng.Longitude, latLng.Latitude
		}

		r := &client.AgxDetectInfoList{
			ObjId:            uint32(agx.Id),
			Azimuth:          float64(agx.Azimuth) / float64(AgxReducedValue),
			Elevation:        float64(agx.Elevation) / float64(AgxReducedValue),
			Velocity:         float64(agx.Velocity) / float64(AgxReducedValue),
			DopplerChn:       int32(agx.DopplerChn),
			Mag:              float64(agx.Mag) / float64(AgxReducedValue),
			Ambiguous:        int32(agx.Ambiguous),
			Classification:   int32(agx.Classification),
			ClassfyProb:      float64(agx.ClassifyProb),
			ExistingProb:     float32(agx.ExistingProb),
			AbsVel:           float64(agx.AbsVel) / float64(AgxReducedValue),
			OrientationAngle: float64(agx.OrientationAngle) / float64(AgxReducedValue),
			Alive:            uint32(agx.Alive),
			TwsTasFlag:       uint32(agx.TwsTasFlag),
			X:                x,
			Y:                y,
			Z:                z,
			Vx:               float64(agx.Vx) / float64(AgxReducedValue),
			Vy:               float64(agx.Vy) / float64(AgxReducedValue),
			Vz:               float64(agx.Vz) / float64(AgxReducedValue),
			Ax:               float64(agx.Ax) / float64(AgxReducedValue),
			Ay:               float64(agx.Ay) / float64(AgxReducedValue),
			Az:               float64(agx.Az) / float64(AgxReducedValue),
			XVariance:        float64(agx.XVariance) / float64(AgxReducedValue),
			YVariance:        float64(agx.YVariance) / float64(AgxReducedValue),
			ZVariance:        float64(agx.ZVariance) / float64(AgxReducedValue),
			VxVariance:       float64(agx.VxVariance) / float64(AgxReducedValue),
			VyVariance:       float64(agx.VyVariance) / float64(AgxReducedValue),
			VzVariance:       float64(agx.VzVariance) / float64(AgxReducedValue),
			AxVariance:       float64(agx.AxVariance) / float64(AgxReducedValue),
			AyVariance:       float64(agx.AyVariance) / float64(AgxReducedValue),
			AzVariance:       float64(agx.AzVariance) / float64(AgxReducedValue),
			StateType:        int32(agx.StateType),
			MotionType:       int32(agx.MotionType),
			ForcastFrameNum:  int32(agx.ForcastFrameNum),
			AssociationNum:   int32(agx.AssociationNum),
			AssocBit0:        agx.AssocBit0,
			AssocBit1:        agx.AssocBit1, // 0: 就代表没有被PTZ锁定过，1就是有被锁定过; (temp definition)
			Longitude:        droneLongitude,
			Latitude:         droneLatitude,
		}

		r.DroneName = fmt.Sprintf("%s%d", GenerateNamePrefix(int(r.Classification)), r.ObjId)
		logger.Infof("agx Info data: %+v", agx)
		if agx.StateType == 0 {
			logger.Info("Agx State Type is 0")
			continue
		}
		//计算无人机威胁等级
		// 事件只过滤无人机和直升机
		if r.Classification == 0x01 || r.Classification == 0x05 {
			//告警过滤
			fd, err := NewAlarmControl().GetDroneThreatLevel(&GetThreatLevelReq{
				DroneSn:        "",
				DroneObjId:     int64(r.ObjId),
				DroneLongitude: droneLongitude,
				DroneLatitude:  droneLatitude,
				DevSn:          devSn,
			})
			if err != nil {
				logger.Errorf("agxDetectReport GetDroneThreatLevel err: %v", err)
			} else {
				r.AlarmId = fd.AlarmId
				r.EventId = fd.EventId
				r.ThreatLevel = fd.ThreatLevel
				r.ScenesId = fd.ScenesId
			}

			agxEventResult = append(agxEventResult, r)
		}
		agxResult = append(agxResult, r)
	}
	if !foundFlag {
		//目标消失
		delete(status, devSn)
	}

	CloudEventID := d.updateAgxDetectEvent(devSn, agxEventResult)

	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	dataInfo := &client.AgxDetectInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        devSn,
			EquipType: int32(d.DevType),
			MsgType:   mavlink.AgxMsgDetect,
		},
		Data:    agxResult,
		EventId: CloudEventID,
	}
	if err == nil {
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIdAgxDetectData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}
	_ = mq.AgxMsgBroker.Publish(mq.AgxTopic, broker.NewMessage(out))

	// d.updateAgxDetectEvent(devSn, agxEventResult)

	logger.Infof("Agx has Detect reported, devSn: %v, data info %v", devSn, dataInfo)
}

func (d *Agx) UnmarshalAgxDetect(data *mavlink.AgxDetectResult) error {
	deviceInfoLen := binary.Size(mavlink.AgxDetectInfo{})
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}

	start := mavlink.HeaderLen + deviceInfoLen
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializeDrone(d.Msg[start:end]); err != nil {
		return err
	}

	return nil
}

// ReceiveAgxTransferDevMsg 收到Agx 上报转发设备的消息
func (d *Agx) ReceiveAgxTransferDevMsg() {
	logger.Info("--->Into Receive Agx Transfer DevMsg")
	devSn := d.getSn()
	result := &mavlink.AgxTransferMsg{}
	if err := d.UnmarshalAgxTransferDevMsg(result, devSn); err != nil {
		logger.Errorf(err.Error())
		return
	}
	logger.Info("--->End Receive Agx Transfer DevMsg")
}
func (d *Agx) UnmarshalAgxTransferDevMsg(data *mavlink.AgxTransferMsg, devSn string) error {
	begin := mavlink.HeaderLen
	msgLen := 1
	readLen := begin + msgLen
	err := mavlink.Read(bytes.NewReader(d.Msg[begin:readLen]), binary.LittleEndian, &data.SlaveDevId, msgLen)
	logger.Debug("slave DevId : ", data.SlaveDevId)

	begin = readLen
	msgLen = mavlink.DevSNLen
	readLen = begin + msgLen

	err = mavlink.Read(bytes.NewReader(d.Msg[begin:readLen]), binary.LittleEndian, &data.Sn, msgLen)
	logger.Debug("dev sn is  : ", string(data.Sn[:]))

	begin = readLen
	msgLen = 1
	readLen = begin + msgLen

	err = mavlink.Read(bytes.NewReader(d.Msg[begin:readLen]), binary.LittleEndian, &data.TransferCmd, msgLen)
	logger.Debug("transfer cmd is  : ", data.TransferCmd)
	begin = readLen
	msgLen = 4
	readLen = begin + msgLen

	err = mavlink.Read(bytes.NewReader(d.Msg[begin:readLen]), binary.LittleEndian, &data.CmdLen, msgLen)
	logger.Debug("cmd len is  : ", data.CmdLen)
	begin = readLen
	msgLen = int(data.CmdLen)
	readLen = begin + msgLen
	if data.SlaveDevId == uint8(common.DEV_SFL) {
		if data.TransferCmd == mavlink.SflDetectMsg {
			result := &mavlink.SflDetect{}
			deviceInfoLen := binary.Size(mavlink.SflDetectInfo{})
			buff := &bytes.Buffer{}
			if err := binary.Write(buff, binary.LittleEndian, d.Msg[begin:]); err != nil {
				return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
			}
			if err := binary.Read(buff, binary.LittleEndian, &result.Info); err != nil {
				return fmt.Errorf("UnmarshalPayload read data err: %v", err)
			}
			start := begin + deviceInfoLen
			end := d.MsgLen - mavlink.CrcLen
			if err = result.DeserializeDrone(d.Msg[start:end]); err != nil {
				return err
			}
			if devSn != "" {
				d.agxReportSflDetectMsg(devSn, result)
			}
		}
		if data.TransferCmd == mavlink.SflHeartMsg {
			result := &mavlink.SflHeart{}
			buff := &bytes.Buffer{}
			if err := binary.Write(buff, binary.LittleEndian, d.Msg[begin:readLen]); err != nil {
				return fmt.Errorf("AGX_Sfl UnmarshalPayload write buff err: %v", err)
			}
			if err = binary.Read(buff, binary.LittleEndian, &result.Info); err != nil {
				return fmt.Errorf("AGX_Sfl UnmarshalPayload read data err: %v", err)
			}
			d.agxReportSflHeartMsg(devSn, result)
		}

	}

	return nil
}
func (d *Agx) agxReportSflHeartMsg(devSn string, heartInfo *mavlink.SflHeart) {

	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	dataInfo := &client.SflHeartInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        devSn,
			EquipType: int32(d.DevType),
			MsgType:   mavlink.AgxTransferDevMsg,
		},
		Data: &client.GimbalCounterHeartInfo{
			Sn:              ByteToString(heartInfo.Info.Sn[:]),
			TimeStamp:       int32(heartInfo.Info.TimeStamp),
			WorkStatus:      int32(heartInfo.Info.WorkStatus),
			IsOnline:        common.DevOnline,
			HitFreq:         int32(heartInfo.Info.HitFreq),
			DetectFreq:      float64(heartInfo.Info.DetectFreq) / DetectFreqTion,
			Elevation:       float64(heartInfo.Info.Elevation) / ElevationTion,
			GunDirection:    float64(heartInfo.Info.GunDirection) / GunDirectTion,
			GunLongitude:    float64(heartInfo.Info.GunLongitude) / GunLongitudeTion,
			GunLatitude:     float64(heartInfo.Info.GunLatitude) / GunLatitudeTion,
			GunAltitude:     float64(heartInfo.Info.GunAltitude),
			SatellitesNum:   int32(heartInfo.Info.SatellitesNum),
			FaultLevel:      int32(heartInfo.Info.FaultLevel),
			CtrlFault:       int32(heartInfo.Info.CtrlFault),
			AeagFault:       int32(heartInfo.Info.AeagFault),
			TracerFault:     int32(heartInfo.Info.TracerFault),
			WorkStatusParam: int32(heartInfo.Info.WorkStatusParam),
		},
	}
	if err == nil {
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgIdAgxTransferSflHeartMsg,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.AgxMsgBroker.Publish(mq.AgxTopic, broker.NewMessage(out))

	logger.Infof("Agx Transfer Sfl heartbeat has reported, devSn: %v,report:%v", devSn, dataInfo.Data)
}
func (d *Agx) agxReportSflDetectMsg(devSn string, detectInfo *mavlink.SflDetect) {
	dataInfo := &client.GimbalCounterDetectSocketInfo{}
	dataInfo.List = make([]*client.GimbalCounterDetectDroneInfo, 0, len(detectInfo.Description))
	dataInfo.Sn = ByteToString(detectInfo.Info.SN[:]) //sflSn
	dataInfo.DetectionNum = int32(detectInfo.Info.DetectionNum)
	//查白名单中的无人机，在Tracer侦测结果中添加无人机角色
	whiteList := &client.ListResAll{}
	err := NewWhiteList().ListAll(context.Background(), &client.ListReqAll{}, whiteList)
	if err != nil {
		logger.Error("Get whiteList err: ", err)
		return
	}
	logger.Debug("detect Info Description:", len(detectInfo.Description))
	for _, drone := range detectInfo.Description {
		if drone.Source == 0 {
			drone = DetectCheckInputNum(drone)
			//1-敌军 2-友军 3-未知 4-中立     批量导入为2友军
			var role int32
			for _, info := range whiteList.WhiteList {
				if info.Sn == ByteToString(drone.SerialNum[:]) {
					role = info.Role
				}
			}
			if role == ERRTYPE {
				role = ENEMY
			}
			r := &client.GimbalCounterDetectDroneInfo{
				ProductType:        int32(drone.ProductType),
				DroneName:          ByteToString(drone.DroneName[:]),
				SerialNum:          ByteToString(drone.SerialNum[:]),
				DroneLongitude:     float64(drone.DroneLongitude) / DroneTion,
				DroneLatitude:      float64(drone.DroneLatitude) / DroneTion,
				DroneHeight:        float64(drone.DroneHeight) / DroneHeightTion,
				DroneYawAngle:      float64(drone.DroneYawAngle) / DroneYawTion,
				DroneSpeed:         float64(drone.DroneSpeed) / DroneSpeedTion,
				DroneVerticalSpeed: float64(drone.DroneVerticalSpeed) / DroneVerticalSpeedTion,
				SpeedDirection:     int32(drone.SpeedDerection) / DroneSpeedTion,
				DroneSailLongitude: float64(drone.DroneSailLongitude) / DroneSailLongitudeTion,
				DroneSailLatitude:  float64(drone.DroneSailLatitude) / DroneSailLatitudeTion,
				PilotLongitude:     float64(drone.PilotLongitude) / DroneTion,
				PilotLatitude:      float64(drone.PilotLatitude) / DroneTion,
				DroneHorizon:       float64(drone.DroneHorizon) / DroneHorizonTion,
				DronePitch:         float64(drone.DronePitch) / DronePitch,
				UFreq:              float64(drone.UFreq) / DetectFreqTion,
				UDistance:          int32(drone.UDistance),
				UDangerLevels:      int32(drone.UDangerLevels),
				Role:               role,
				UZC:                int32(drone.Uzc),
				GpsClocks:          drone.GpsClocks,
				TimeStampRid:       drone.TimestampRid,
				IdType:             uint32(drone.IdType),
			}
			logger.Debugf("GimbalCounterDetectDroneInfo  r = ", r)
			//计算无人机威胁等级
			if role != FRIEND {
				fd, err := NewAlarmControl().GetDroneThreatLevel(&GetThreatLevelReq{
					DroneSn:        r.SerialNum,
					DroneObjId:     0,
					DroneLongitude: r.DroneLongitude,
					DroneLatitude:  r.DroneLatitude,
					DevSn:          devSn,
				})
				if err != nil {
					logger.Errorf("agxReportSflDetectMsg GetDroneThreatLevel error: %v", err)
				} else {
					r.AlarmId = fd.AlarmId
					r.EventId = fd.EventId
					r.ThreatLevel = fd.ThreatLevel
					r.ScenesId = fd.ScenesId
				}
			}
			logger.Infof("agx Detect data: %v", r)
			dataInfo.List = append(dataInfo.List, r)
		}
	}

	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}

	msg := &client.SflDetectInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,  //agxSn
			Sn:        devSn, //agxSn
			EquipType: int32(d.DevType),
			MsgType:   mavlink.AgxTransferDevMsg,
		},
		Data: dataInfo,
	}
	if err == nil {
		msg.Header.ParentSn = equipModel.ParentSn
		msg.Header.ParentType = int32(equipModel.ParentType)
		msg.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msgOut, err := proto.Marshal(msg)
	if err != nil {
		logger.Error("marshal msg err:", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIdAgxTransferSflDetectMsg,
		Data:    msgOut,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	_ = mq.AgxMsgBroker.Publish(mq.AgxTopic, broker.NewMessage(out))

	logger.Infof("agx Transfer SFL Detect has reported, devSn: %v, Drone size: %v", devSn, msg.Data)
}

// AgxSelectUav 发送选中无人机Agx
func (d *Agx) AgxSelectUav(req *client.AgxSelectUavRequest) (int32, error) {

	request := &mavlink.AgxSendSelectUavRequest{}

	buff := request.Create(req)

	logger.Debugf("Agx Select Uav buff:", buff)
	logger.Debugf("Agx Select Uav buff: %x\n", buff)

	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("Agx Select Uav err: ", err)
		return Fail, err
	}
	logger.Debug("Agx Send Agx Select Uav Suc")
	return Success, nil
}

// AgxTrackClassification 发送分类跟踪目标类别
func (d *Agx) AgxTrackClassification(req *client.AgxTrackClassificationRequest) (int32, error) {

	request := &mavlink.AgxTrackClassificationRequest{}

	buff := request.Create(req)

	logger.Debugf("Agx Track Classification buff:", buff)
	logger.Debugf("Agx Track Classification buff: %x\n", buff)

	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("Agx Track Classification err: ", err)
		return Fail, err
	}
	logger.Debug("Agx Send Agx Track Classification Suc")
	return Success, nil
}

// AgxSelectSflUav Agx 发送选中Sfl探测到的无人机 废弃
func (d *Agx) AgxSelectSflUav(req *client.AgxSelectSflUavRequest) (int32, error) {

	request := &mavlink.AgxSendSelectSflUavRequest{}

	buff := request.Create(req)

	logger.Debugf("Agx Select Sfl Uav buff:", buff)

	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("Agx Select Uav err: ", err)
		return Fail, err
	}
	manager, ok := d.WaitTaskMap[mavlink.AgxSendMsgSfl]
	if !ok {
		manager = NewWaitTaskManager(mavlink.AgxSendMsgSfl, true, 0)
		d.WaitTaskMap[mavlink.AgxSendMsgSfl] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Agx to Sfl Send Hit Uav info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.AgxSendSelectSflUavResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}

	logger.Debug("Agx Send Sfl Select Uav Suc")
	return int32(res.Status), nil
}

//func (d *Agx) ReceiveAgxSelectSflUav() {
//	logger.Info("-->into Receive Agx Select Sfl Uav ")
//	res := &mavlink.AgxSendSelectSflUavResponse{}
//	d.GetPacket(res)
//	logger.Debugf("ReceiveAgxSelectSflUav  接收到Sfl信息：%#v", res)
//	manager, ok := d.WaitTaskMap[mavlink.AgxSendMsgSfl]
//	if ok {
//		manager.CompletedTask(res, nil)
//	}
//	return
//}

// AgxCalibration Agx发送标定
func (d *Agx) AgxCalibration(req *client.AgxCalibrationRequest) (int32, error) {

	request := &mavlink.AgxSendCalibrationRequest{}

	buff := request.Create(req)

	logger.Debugf("Agx Calibration buff:", buff)
	logger.Debugf("Agx Calibration buff: %x\n", buff)

	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("Agx Calibration err: ", err)
		return Fail, err
	}
	logger.Debug("Agx Send Agx Calibration Suc")
	return Success, nil
}

// AgxCalibration Agx发送标定
func (d *Agx) AgxSetCalibrationPara(req *client.AgxSetCalibrationParaRequest) (int32, error) {
	TempHeading = req.Heading
	request := &mavlink.AgxSendSetCalibrationRequest{}

	buff := request.Create(req)

	logger.Debugf("Agx AgxSetCalibrationPara buff:", buff)
	logger.Debugf("Agx AgxSetCalibrationPara buff: %x\n", buff)

	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("Agx AgxSetCalibrationPara err: ", err)
		return Fail, err
	}

	logger.Debug("Agx Send Agx AgxSetCalibrationPara Suc")
	manager, ok := d.WaitTaskMap[mavlink.AgxSetCalibrationPara]
	if !ok {
		manager = NewWaitTaskManager(mavlink.AgxSetCalibrationPara, true, 0)
		d.WaitTaskMap[mavlink.AgxSetCalibrationPara] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl  Hit Mode err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.AgxSendSetCalibrationResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response AgxSetCalibrationPara result:%+v", *res)

	return int32(res.Result), nil
}

// AgxCalibration Agx发送标定
func (d *Agx) AgxGetCalibrationPara(req *client.AgxGetCalibrationParaRequest, rsp *client.AgxGetCalibrationParaRespone) (int32, error) {

	request := &mavlink.AgxSendGetCalibrationRequest{}

	buff := request.Create(req)

	logger.Debugf("Agx AgxSendGetCalibrationRequest buff:", buff)
	logger.Debugf("Agx AgxSendGetCalibrationRequest buff: %x\n", buff)

	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("Agx AgxSendGetCalibrationRequest err: ", err)
		return Fail, err
	}
	logger.Debug("Agx Send Agx AgxSendGetCalibrationRequest Suc")
	manager, ok := d.WaitTaskMap[mavlink.AgxGetCalibrationPara]
	if !ok {
		manager = NewWaitTaskManager(mavlink.AgxGetCalibrationPara, true, 0)
		d.WaitTaskMap[mavlink.AgxGetCalibrationPara] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request AgxGetCalibrationPara err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.AgxSendGetCalibrationResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response AgxGetCalibrationPara result:%+v", *res)
	rsp.Altitude = res.Altitude
	rsp.Heading = res.Heading
	rsp.Latitude = res.Latitude
	rsp.Longitude = res.Longitude
	TempHeading = res.Heading

	return Success, nil
}

func (d *Agx) ReceiveAgxDeviceStatusRes() {
	logger.Info("-->Into Receive Agx Dev Status,devtype =", d.DevType)
	devSn := d.getSn()
	result := &mavlink.AgxDevStateResult{}
	if err := d.UnmarshalAgxDevState(result); err != nil {
		logger.Errorf(err.Error())
		return
	}
	if devSn != "" {
		d.updateStatus(devSn)
		//if isEnable := d.updateStatus(devSn); isEnable == common.DeviceDisenable {
		//	logger.Infof("Agx device %v disable", devSn)
		//	return
		//}
		d.agxDevStateReport(devSn, result)
	}
	logger.Info("--->End Receive Agx Detect")
}

func (d *Agx) UnmarshalAgxDevState(data *mavlink.AgxDevStateResult) error {
	deviceInfoLen := binary.Size(mavlink.AgxDevStateInfo{})
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}

	start := mavlink.HeaderLen + deviceInfoLen
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializeDrone(d.Msg[start:end]); err != nil {
		return err
	}

	return nil
}

func (d *Agx) agxDevStateReport(devSn string, result *mavlink.AgxDevStateResult) {
	logger.Info("--->Into Receive agx  Dev State Report,dev type = ", d.DevType)
	agxResult := make([]*client.AgxDeviceSn, 0)

	for _, agx := range result.Description {
		r := &client.AgxDeviceSn{
			DevType: int32(agx.DevType),
			DevSn:   ByteToString(agx.DevSn[:]),
		}
		logger.Infof("agx Dev sn Info data: %+v", r)
		agxResult = append(agxResult, r)
	}
	//更新父设备sn
	err := NewEquipList().UpdateParentSn(context.Background(), devSn, int(d.DevType), agxResult)
	if err != nil {
		logger.Error("update parent sn err:", err)
	}

	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}

	dataInfo := &client.AgxDevStateInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        devSn,
			EquipType: int32(d.DevType),
			MsgType:   mavlink.AgxMsgDeviceStatus,
		},
		Data: &client.AgxDevStateList{
			Sn:   devSn,
			List: agxResult,
		},
	}
	if err == nil {
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIdAgxDevStatusData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}
	_ = mq.AgxMsgBroker.Publish(mq.AgxTopic, broker.NewMessage(out))

	radarList := make([]*client.RadarDevList, 0)
	for _, radar := range agxResult {
		radarList = append(radarList, &client.RadarDevList{Sn: radar.DevSn, AgxSn: devSn})
	}
	//err = NewEquipList().UpdateRadarStatus(context.Background(), &client.UpdateRadarStatusReq{List: radarList}, &client.UpdateRadarStatusRes{})
	//if err != nil {
	//	logger.Error("Update Radar Status err: ", err)
	//	return
	//}

	logger.Infof("Agx has dev sn reported, devSn: %v, data info %v", devSn, dataInfo)
}

func (d *Agx) ReceiveAgxPTZStatusRes() {
	logger.Info("-->Into Receive Agx PTZ Status")
	devSn := d.getSn()
	result := &mavlink.AgxPTZStateResultData{}
	if err := d.UnmarshalAgxPTZState(result); err != nil {
		logger.Errorf(err.Error())
		return
	}
	d.updateStatus(devSn)
	//if isEnable := d.updateStatus(devSn); isEnable == common.DeviceDisenable {
	//	logger.Infof("Agx device %v disable", devSn)
	//	return
	//}
	d.agxPTZStateReport(devSn, result)
	logger.Info("--->End Receive Agx PTZ data")
}

func (d *Agx) ReceiveAgxCalibrationResultRes() {
	logger.Info("-->Into Receive Agx Calibration Result")
	devSn := d.getSn()
	result := &mavlink.ReceiveAgxCalibrationResultData{}
	if err := d.UnmarshalAgxCalibration(result); err != nil {
		logger.Errorf(err.Error())
		return
	}
	d.updateStatus(devSn)
	//if isEnable := d.updateStatus(devSn); isEnable == common.DeviceDisenable {
	//	logger.Infof("Agx device %v disable", devSn)
	//	return
	//}
	d.agxCalibrationReport(devSn, result)
	logger.Info("--->End Receive Agx PTZ data")
}

// ReceiveAgxSetCalibrationResultRes...
func (d *Agx) ReceiveAgxSetCalibrationResultRes() {
	logger.Info("-->Into ReceiveAgxSetCalibrationResultRes Result")
	res := &mavlink.AgxSendSetCalibrationResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveAgxSetCalibrationResultRes 获取请求固件升级响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.AgxSetCalibrationPara]
	if ok {
		manager.CompletedTask(res, nil)
	}
	logger.Info("--->End Receive ReceiveAgxSetCalibrationResultRes data")
}

// ReceiveAgxGetCalibrationResultRes...
func (d *Agx) ReceiveAgxGetCalibrationResultRes() {
	logger.Info("-->Into ReceiveAgxGetCalibrationResultRes Result")
	res := &mavlink.AgxSendGetCalibrationResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveAgxGetCalibrationResultRes : %#v", res)
	if d.getSn() != "" {
		agxSnToLocationMap.Store(d.getSn(), res)
	}
	manager, ok := d.WaitTaskMap[mavlink.AgxGetCalibrationPara]
	if ok {
		manager.CompletedTask(res, nil)
	}
	logger.Info("--->End Receive ReceiveAgxGetCalibrationResultRes data")
}

func (d *Agx) UnmarshalAgxPTZState(data *mavlink.AgxPTZStateResultData) error {
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("Agx UnmarshalAgxPTZState write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("Sfl UnmarshalAgxPTZState read data err: %v", err)
	}

	return nil
}

func (d *Agx) UnmarshalAgxCalibration(data *mavlink.ReceiveAgxCalibrationResultData) error {
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("Agx UnmarshalAgxPTZState write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("Sfl UnmarshalAgxPTZState read data err: %v", err)
	}

	return nil
}

func (d *Agx) UnmarshalSetAgxCalibration(data *mavlink.AgxSendSetCalibrationResponse) error {
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("Agx UnmarshalSetAgxCalibration write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data); err != nil {
		return fmt.Errorf("Sfl UnmarshalSetAgxCalibration read data err: %v", err)
	}

	return nil
}

func (d *Agx) agxPTZStateReport(devSn string, result *mavlink.AgxPTZStateResultData) {
	logger.Info("--->Into Receive agx  PTZ State Report")
	//ptz 未入库
	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	dataInfo := &client.AgxPTZStateInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        devSn,
			EquipType: int32(d.DevType),
			MsgType:   mavlink.AgxMsgPTZStatus,
		},
		Data: &client.AgxPTZStateList{
			Sn:           ByteToString(result.Info.SnName[:]),
			TimeStamp:    int64(result.Info.TimeStamp),
			PtzLongitude: result.Info.PtzLongitude,
			PtzLatitude:  result.Info.PtzLatitude,
			PtzHeight:    result.Info.PtzHeight,
			Elevation:    result.Info.Elevation,
			OmegaAz:      result.Info.OmegaAz,
			OmegaEl:      result.Info.OmegaEl,
			Zoom:         result.Info.Zoom,
		},
	}
	if err == nil {
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	//一体化设备不需要补偿
	temp := result.Info.Azimuth + TempHeading
	if dataInfo.Header.IsIntegrated == 1 {
		temp = result.Info.Azimuth
	}
	dataInfo.Data.Azimuth = temp

	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		logger.Error("agxPTZStateReport dataInfo = ", dataInfo)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIdAgxPTZStatusData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}
	_ = mq.AgxMsgBroker.Publish(mq.AgxTopic, broker.NewMessage(out))

	logger.Infof("Agx PTZ has dev sn reported, data info %v", dataInfo)
}

func (d *Agx) agxCalibrationReport(devSn string, result *mavlink.ReceiveAgxCalibrationResultData) {
	logger.Info(" agxCalibrationReport result.Info ,", result.Info)
	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	dataInfo := &client.AgxPTZCalibrationInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        devSn,
			EquipType: int32(d.DevType),
			MsgType:   mavlink.AgxCalibrationResult,
		},
		Data: &client.AgxCalibration{
			Flag:         result.Info.Flag,
			AzimuthOff:   result.Info.AzimuthOff,
			ElevationOff: result.Info.ElevationOff,
		},
	}
	if err == nil {
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	logger.Debug("dataInfo: ", dataInfo)
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIdAgxCalibrationData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}
	_ = mq.AgxMsgBroker.Publish(mq.AgxTopic, broker.NewMessage(out))

	logger.Infof("Agx PTZ has dev sn reported, data info %v", dataInfo)
}

func AgxOffLineEventReport(sn string, dev_type common.DeviceType) {
	cacheKey := fmt.Sprintf("%d_%s", dev_type, sn)
	eventId := ""

	if cache, ok := DevStatusMapOnEvent.Load(cacheKey); ok {
		dev := cache.(*Device)
		eventId = utils.GetEventId(dev.SessionId)

	} else {
		logger.Infof("not exist on event status context, sn: %v", sn)
		return
	}
	DevStatusMapOnEvent.Delete(cacheKey)

	equipModel, err := GetEquipBySn(sn)
	name := sn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	dataInfo := &client.AgxHeartBeatInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        sn,
			EquipType: int32(dev_type),
			MsgType:   mavlink.AgxEventOffOnLine,
		},
		Data: &client.AgxHeartBeatReport{
			Sn:       sn,
			IsOnline: common.DevOffline,
			EventId:  eventId,
		},
	}
	if err == nil {
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgAgxStatusEventData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Infof("agx Offline event report: %v", report)
}

func AgxPtzLockEventReport(detectInfo *DetectEvent, eventId string, sn string) {
	if detectInfo == nil {
		return
	}

	var lockUavByPtz uint8 = 0
	var msgType = int32(mavlink.AgxEventPtzLockUavFail)

	if detectInfo.Items != nil && len(detectInfo.Items) > 0 {
		lockUavByPtz = 1
		logger.Infof("ptz lock uav succ, sn: %v", sn)
	}

	lockedItem := []*client.AgxPtzLockedItem{}
	if lockUavByPtz == 1 {
		msgType = mavlink.AgxEventPtzLockUavSucc

		for _, uav := range detectInfo.Items {
			if uav == nil {
				continue
			}
			lockedItem = append(lockedItem, &client.AgxPtzLockedItem{
				DroneName:  uav.DroneName,
				SerialNum:  strconv.FormatInt(int64(uav.ObjectId), 10),
				Longitude:  uav.Longitude,
				Latitude:   uav.Latitude,
				LockedTime: uav.LockedTime.UnixMilli(),
			})
		}
	}

	equipModel, err := GetEquipBySn(sn)
	name := sn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	dataInfo := &client.AgxPtzLockInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        sn,
			EquipType: int32(common.DEV_AGX),
			MsgType:   msgType,
		},
		Data:    lockedItem,
		EventId: eventId,
	}
	if err == nil {
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}

	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgAgzPtzLockEventData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}
	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Infof("agx ptz lock event status: %v,  report: %v", lockUavByPtz, dataInfo)

}
func AgxDetectDisappearEventReport(sn string, dev_type common.DeviceType) {
	cacheKey := fmt.Sprintf("%d_%s", dev_type, sn)
	eventId := ""
	cache, ok := DevDetectMapOnEvent.Load(cacheKey)
	if !ok {
		return
	}

	dev, exist := cache.(*DetectEvent)
	if dev == nil || !exist {
		logger.Errorf("not exist agx DetectEvent, cache key: %v", cacheKey)
		return
	}

	eventId = utils.GetEventId(dev.SessionId)
	// agx锁定事件不上报
	// AgxPtzLockEventReport(dev, utils.GetEventId(dev.LockPtzSessionId), sn)

	DevDetectMapOnEvent.Delete(cacheKey)
	var detectInfo []*client.AgxDetectInfoList

	equipModel, err := GetEquipBySn(sn)
	name := sn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	dataInfo := &client.AgxDetectInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        sn,
			EquipType: int32(dev_type),
			MsgType:   mavlink.AgxEventDetectDisappear,
		},
		Data:    detectInfo,
		EventId: eventId,
	}
	if err == nil {
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgAgxDetectEventData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}
	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Infof("agx detect disappear event report: %v", dataInfo)
}

// ReceiveAgxTrackStateRes 收到Agx上报跟踪状态
func (d *Agx) ReceiveAgxTrackStateRes() {
	logger.Info("--->Into Receive Agx Track State")
	agxTrack := &mavlink.AgxTrackState{}
	d.GetPacket(agxTrack)
	logger.Infof("ReceiveAgxTrackStateRes result: %v", agxTrack)
	devSn := d.getSn()
	d.updateStatus(devSn)
	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	dataInfo := &client.AgxTrackStateInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        devSn,
			EquipType: int32(d.DevType),
			MsgType:   mavlink.AgxMsgTrackStatus,
		},
		Data: &client.AgxTrackStateReport{
			Type:   int32(agxTrack.Type),
			ObjId:  agxTrack.ObjId,
			Sn:     ByteToString(agxTrack.Sn[:]),
			Status: int32(agxTrack.Status),
		},
	}
	if err == nil {
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}

	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIdAgxTrackStateData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}
	d.updateStatusOnLine(devSn)

	_ = mq.AgxMsgBroker.Publish(mq.AgxTopic, broker.NewMessage(out))
	logger.Infof("Agx Track State has reported, report: %v", dataInfo)
}

// AgxSendUpgradeF1
func (d *Agx) AgxSendUpgradeF1(fileName string, c2Ip string) (int32, error) {
	logger.Info("AgxSendUpgradeF1 Start")

	req := &mavlink.AgxUpdateF1Request{}
	buff := req.Create(fileName, c2Ip)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.AgxIdUpgradeF1]
	if !ok {
		manager = NewWaitTaskManager(mavlink.AgxIdUpgradeF1, true, 0)
		d.WaitTaskMap[mavlink.AgxIdUpgradeF1] = manager
	}
	task := manager.AddTask(nil, nil)
	logger.Debugf("AgxSendUpgradeF1 buff: %02X \n", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("AgxSendUpgradeF1 发送写入固件数据信息失败: ", err)
		return 1, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("AgxSendUpgradeF1 WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 1, checkNetConnErr
		}
		return 1, err
	}
	res := result.(*mavlink.AgxUpdateF1Response)
	logger.Debugf("AgxUpdateF1Response 获取写入固件数据信息结果：%+v", res)
	logger.Info("AgxUpdateF1Response End")
	return int32(res.Status), nil
}

// ReceiveAgxUpdateF1 获取请求固件升级响应
func (d *Agx) ReceiveAgxUpdateF1() {
	res := &mavlink.AgxUpdateF1Response{}
	d.GetPacket(res)
	logger.Debugf("ReceiveAgxUpdateF1 获取请求固件升级响应信息：%+v", res)
	manager, ok := d.WaitTaskMap[mavlink.AgxIdUpgradeF1]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// AgxSendUpgradeF2
func (d *Agx) AgxSendUpgradeF2() (int32, error) {
	logger.Info("AgxSendUpgradeF2 Start")
	req := &mavlink.AgxUpdateF2Request{}
	buff := req.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.AgxIdUpgradeF2]
	if !ok {
		manager = NewWaitTaskManager(mavlink.AgxIdUpgradeF2, true, time.Second*30)
		d.WaitTaskMap[mavlink.AgxIdUpgradeF2] = manager
	}
	task := manager.AddTask(nil, nil)
	logger.Debugf("AgxSendUpgradeF2 buff: %02X \n", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("AgxSendUpgradeF2 发送写入固件数据信息失败: ", err)
		return 1, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("AgxSendUpgradeF2 WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 1, checkNetConnErr
		}
		return 1, err
	}
	res := result.(*mavlink.AgxUpdateF2Response)
	logger.Debugf("AgxUpdateF2Response 获取写入固件数据信息结果：%+v", res)
	logger.Info("AgxUpdateF2Response End")
	return int32(res.Progress), nil
}

// ReceiveAgxUpdateF2 获取请求固件升级响应
func (d *Agx) ReceiveAgxUpdateF2() {
	res := &mavlink.AgxUpdateF2Response{}
	d.GetPacket(res)
	logger.Debugf("ReceiveAgxUpdateF2 获取请求固件升级响应信息：%+v", res)
	manager, ok := d.WaitTaskMap[mavlink.AgxIdUpgradeF2]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// AgxSendUpgradeF3
func (d *Agx) AgxSendUpgradeF3() (int32, error) {
	logger.Info("AgxSendUpgradeF3 Start")

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.AgxIdUpgradeF3]
	if !ok {
		manager = NewWaitTaskManager(mavlink.AgxIdUpgradeF3, true, time.Second*60)
		d.WaitTaskMap[mavlink.AgxIdUpgradeF3] = manager
	}
	task := manager.AddTask(nil, nil)

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("AgxSendUpgradeF3 WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 1, checkNetConnErr
		}
		return 1, err
	}
	res := result.(*mavlink.AgxUpdateF3Response)
	logger.Debugf("AgxUpdateF3Response 获取写入固件数据信息结果：%#v", res)
	logger.Info("AgxUpdateF3Response End")
	return int32(res.UpgradeResult), nil
}

// ReceiveAgxUpdateF3 获取请求固件升级响应
func (d *Agx) ReceiveAgxUpdateF3() {
	res := &mavlink.AgxUpdateF3Response{}
	d.GetPacket(res)
	logger.Debugf("ReceiveAgxUpdateF3 获取请求固件升级响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.AgxIdUpgradeF3]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// ReceiveGetTime 接收Agx获取时间消息
func (d *Agx) ReceiveGetTime() {
	logger.Info("-->into Send Time To Agx")
	res := &mavlink.AgxGetTimeResponse{}
	time1 := time.Now().UTC()
	resTime := time1.Format("20060102150405.000")
	logger.Info("resTime:", resTime)
	var byteArr [20]byte

	for k := range resTime {
		byteArr[k] = resTime[k]
	}

	rspBuf := res.CreateGetTimeMessage(byteArr)
	logger.Debugf("Send Time To Agx Data:%v", rspBuf)

	n, err := d.Conn.Write(rspBuf)
	logger.Debugf("Send Time To Agx：%v,%+v", n, res)
	if err != nil {
		logger.Error("Send Time To Agx err:", err)
		return
	}
	logger.Info("--->End Send Time To Agx")
	return
}

func (d *Agx) TracerPToAGXSend(request *mavlink.TracerPSendToAGX) (int32, error) {

	req := &mavlink.TracerPSendToAGXAll{}

	buff := req.CreateMessage(request)
	if buff == nil {
		logger.Info("send to agx failed,form pkg failed")
		return 0, errors.New("send to agx failed,form pkg failed")
	}
	logger.Debugf("Agx Calibration buff:", buff)

	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("Agx Calibration err: ", err)
		return Fail, err
	}
	logger.Debug("Agx Send Agx Calibration Suc")
	return Success, nil
}

// AgxPTZGetMessage Agx获取rtsp推流地址
func (d *Agx) AgxPTZGetMessage(req *client.AgxPTZMsgRequest, rsp *client.AgxPTZMsgResponse) (int32, error) {
	logger.Debug("-->Into AgxPTZGetMessage")
	request := &mavlink.SRP150GetPTZRequest{}
	buff := request.Create(req)

	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("Agx AgxPTZGetMessage err: ", err)
		return Fail, err
	}
	manager, ok := d.WaitTaskMap[mavlink.AgxGetPTZDeviceMsg]
	if !ok {
		manager = NewWaitTaskManager(mavlink.AgxGetPTZDeviceMsg, true, 0)
		d.WaitTaskMap[mavlink.AgxGetPTZDeviceMsg] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request AgxGetCalibrationPara err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
		return Fail, err
	}
	res, ok := result.(*mavlink.SRP150GetPTZResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response AgxSetCalibrationPara result:%+v", res)

	rsp.Ip = fmt.Sprintf("%d.%d.%d.%d", res.IP[0], res.IP[1], res.IP[2], res.IP[3])
	rsp.Status = res.Status
	rsp.Port = res.Port
	rsp.SzSerialNumber = ByteToString(res.SN[:])
	rsp.Streams = make([]*client.PTZStream, 0)
	if res.StreamCount > 0 {
		for i := 0; i < int(res.StreamCount); i++ {
			tmp := &client.PTZStream{
				CameraId:   uint32(res.Streams[i].CameraId),
				Url:        ByteToString(res.Streams[i].URL[:]),
				StreamType: int32(res.Streams[i].StreamType),
			}
			rsp.Streams = append(rsp.Streams, tmp)
		}
	} else {
		equipModel, err := GetEquipBySn(req.Sn)
		if err != nil || equipModel == nil {
			return Fail, fmt.Errorf("GetEquipBySn err or result is null:%v,%v", err, equipModel)
		}
		//激光雷视
		if equipModel.Etype == common.SBP100 {
			//跟踪rtsp://192.168.2.184:9554/agx/track/1
			track := &client.PTZStream{
				CameraId:   uint32(GetGlobalSessionId()),
				Url:        "rtsp://192.168.2.184:9554/agx/track/1",
				StreamType: int32(common.TrackingLens),
			}
			//捕获rtsp://192.168.2.184:9554/agx/scale/1
			scale := &client.PTZStream{
				CameraId:   uint32(GetGlobalSessionId()),
				Url:        "rtsp://192.168.2.184:9554/agx/scale/1",
				StreamType: int32(common.ScaleLens),
			}
			//抠图rtsp://192.168.2.184:9554/agx/block/1
			block := &client.PTZStream{
				CameraId:   uint32(GetGlobalSessionId()),
				Url:        "rtsp://192.168.2.184:9554/agx/block/1",
				StreamType: int32(common.BlockLens),
			}
			rsp.Streams = append(rsp.Streams, track, scale, block)
		} else if equipModel.IsIntegrated == 0 {
			visibleLight := &client.PTZStream{
				CameraId:   uint32(GetGlobalSessionId()),
				Url:        "rtsp://192.168.2.4:554/channel=0,stream=0",
				StreamType: int32(common.VisibleLight),
			}
			infrared := &client.PTZStream{
				CameraId:   uint32(GetGlobalSessionId()),
				Url:        "rtsp://192.168.2.4:554/channel=1,stream=0",
				StreamType: int32(common.Infrared),
			}
			//非一体化
			rsp.Streams = append(rsp.Streams, visibleLight, infrared)
		}
	}
	logger.Debugf("response = %+v", rsp)
	return Success, nil
}

// ReceiveAgxGetCalibrationResultRes...
func (d *Agx) ReceiveAgxPTZGetMessageResultRes() {
	logger.Info("-->Into ReceiveAgxPTZGetMessageResultRes Result")
	res := &mavlink.SRP150GetPTZResponse{}
	if err := d.UnmarshalAgxPTZResponse(res); err != nil {
		logger.Error("ReceiveAgxPTZGetMessageResultRes UnmarshalAgxPTZResponse err", err)
	}
	if d.getSn() != "" {
		agxSnToLocationMap.Store(d.getSn(), res)
	}
	manager, ok := d.WaitTaskMap[mavlink.AgxGetPTZDeviceMsg]
	if ok {
		manager.CompletedTask(res, nil)
	}
	logger.Info("--->End Receive ReceiveAgxPTZGetMessageResultRes data : %+v", res)
}

func (d *Agx) UnmarshalAgxPTZResponse(data *mavlink.SRP150GetPTZResponse) error {
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalAgxPTZResponse write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Status); err != nil {
		return fmt.Errorf("UnmarshalAgxPTZResponse read status err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.IP); err != nil {
		return fmt.Errorf("UnmarshalAgxPTZResponse read ip err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Port); err != nil {
		return fmt.Errorf("UnmarshalAgxPTZResponse read port err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.SN); err != nil {
		return fmt.Errorf("UnmarshalAgxPTZResponse read sn err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Reserve); err != nil {
		return fmt.Errorf("UnmarshalAgxPTZResponse read reserve err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.StreamCount); err != nil {
		return fmt.Errorf("UnmarshalAgxPTZResponse read streamCount err: %v", err)
	}

	start := mavlink.HeaderLen + 46
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializeStream(d.Msg[start:end]); err != nil {
		return err
	}

	return nil
}

// ReceiveAgxPTZControlRequestResultRes ...
func (d *Agx) ReceiveAgxPTZControlRequestResultRes() {
	logger.Info("-->Into ReceiveAgxPTZControlRequestResultRes Result")
	res := &mavlink.SRP150PTZControlResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveAgxPTZControlRequestResultRes : %+v", res)
	if d.getSn() != "" {
		agxSnToLocationMap.Store(d.getSn(), res)
	}
	manager, ok := d.WaitTaskMap[mavlink.AgxPTZControlReq]
	if ok {
		manager.CompletedTask(res, nil)
	}
	logger.Info("--->End Receive AgxPTZControlReq data")
}

// ReceivePTZZoomRequestResultRes ...
func (d *Agx) ReceivePTZZoomRequestResultRes() {
	logger.Info("-->Into ReceivePTZZoomRequestResultRes Result")
	res := &mavlink.SRP150PTZZoomResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceivePTZZoomRequestResultRes : %+v", res)
	if d.getSn() != "" {
		agxSnToLocationMap.Store(d.getSn(), res)
	}
	manager, ok := d.WaitTaskMap[mavlink.AgxPTZZoomReq]
	if ok {
		manager.CompletedTask(res, nil)
	}
	logger.Info("--->End Receive ReceivePTZZoomRequestResultRes data")
}

// AgxPTZControlReq Agx控制PTZ转向请求
func (d *Agx) AgxPTZControlReq(req *client.AgxPTZControlRequest, rsp *client.AgxPTZControlResponse) (int32, error) {

	request := &mavlink.SRP150PTZControlRequest{}

	buff := request.Create(req)

	logger.Debugf("Agx AgxPTZControlReq buff: %+v\n", buff)
	logger.Debugf("Agx AgxPTZControlReq buff: %x\n", buff)

	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("Agx AgxPTZControlReq err: ", err)
		return Fail, err
	}
	logger.Debug("Agx Send Agx AgxPTZGetMessage Suc")
	manager, ok := d.WaitTaskMap[mavlink.AgxPTZControlReq]
	if !ok {
		manager = NewWaitTaskManager(mavlink.AgxPTZControlReq, true, 0)
		d.WaitTaskMap[mavlink.AgxPTZControlReq] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request AgxGetCalibrationPara err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.SRP150PTZControlResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response AgxPTZControlReq result:%+v", res)
	rsp.Result = res.Result

	return Success, nil
}

// AgxControlPTZZoom 控制PTZ缩放请求
func (d *Agx) AgxControlPTZZoom(req *client.AgxZoomControlRequest, rsp *client.AgxZoomControlResponse) (int32, error) {

	request := &mavlink.SRP150ControlPTZZoomRequest{}

	buff := request.Create(req)

	logger.Debugf("Agx AgxControlPTZZoom buff: %+v\n", buff)

	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("Agx AgxControlPTZZoom err: ", err)
		return Fail, err
	}
	logger.Debug("Agx Send Agx AgxControlPTZZoom Suc")
	manager, ok := d.WaitTaskMap[mavlink.AgxPTZZoomReq]
	if !ok {
		manager = NewWaitTaskManager(mavlink.AgxPTZZoomReq, true, 0)
		d.WaitTaskMap[mavlink.AgxPTZZoomReq] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request AgxControlPTZZoom err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
		return Fail, err
	}
	res, ok := result.(*mavlink.SRP150PTZZoomResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response AgxControlPTZZoom result:%+v", res)
	rsp.Result = res.Result

	return Success, nil
}

// AgxUserStatusSetting	...
func (d *Agx) AgxUserStatusSetting(req *client.AgxUserStatuSetRequest, rsp *client.AgxUserStatuSetResponse) (int32, error) {

	request := &mavlink.SRP150UserStatusSettingRequest{}

	buff := request.Create(req)

	logger.Debugf("Agx AgxUserStatusSetting buff: %+v\n", buff)

	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("Agx AgxUserStatusSetting err: ", err)
		return Fail, err
	}
	logger.Debug("Agx Send Agx AgxUserStatusSetting Suc")
	manager, ok := d.WaitTaskMap[mavlink.AgxUserStatusSetReq]
	if !ok {
		manager = NewWaitTaskManager(mavlink.AgxUserStatusSetReq, true, 0)
		d.WaitTaskMap[mavlink.AgxUserStatusSetReq] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request AgxUserStatusSetting err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.SRP150UserStatusSettingResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response AgxUserStatusSetting result:%+v", res)
	rsp.Result = res.Result

	return Success, nil
}

// ReceiveAgxUserStatusSetReqResultRes  ...
func (d *Agx) ReceiveAgxUserStatusSetReqResultRes() {
	logger.Info("-->Into ReceiveAgxUserStatusSetReqResultRes Result")
	res := &mavlink.SRP150UserStatusSettingResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveAgxUserStatusSetReqResultRes : %+v", res)
	if d.getSn() != "" {
		agxSnToLocationMap.Store(d.getSn(), res)
	}
	manager, ok := d.WaitTaskMap[mavlink.AgxUserStatusSetReq]
	if ok {
		manager.CompletedTask(res, nil)
	}
	logger.Info("--->End Receive ReceiveAgxUserStatusSetReqResultRes data")
}

// AgxGetVersion	...
func (d *Agx) AgxGetVersion(req *client.AgxGetVersionRequest, rsp *client.AgxGetVersionResponse) (*client.AgxGetVersionResponse, error) {

	request := &mavlink.AgxGetVersionRequest{}

	buff := request.Create(req.EquipType)

	logger.Debugf("Agx AgxGetVersion buff: %+v\n", buff)

	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("Agx AgxGetVersion err: ", err)
		return nil, err
	}
	logger.Debug("Agx Send  AgxGetVersion Suc")
	manager, ok := d.WaitTaskMap[mavlink.AgxGetVersion]
	if !ok {
		manager = NewWaitTaskManager(mavlink.AgxGetVersion, true, 0)
		d.WaitTaskMap[mavlink.AgxGetVersion] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request AgxGetVersion err: %v", checkNetConnErr)
			return nil, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.AgxGetVersionResponse)
	if !ok {
		return nil, errors.New("response err type")
	}
	logger.Debug("response AgxGetVersion result:%+v", res)
	r := &client.AgxGetVersionResponse{}
	r.Sn = req.Sn
	r.AppVersion = ByteToString(res.AppVersion[:])
	r.FusionVersion = ByteToString(res.FusionVersion[:])
	r.AiVersion = ByteToString(res.AiVersion[:])
	r.BootVersion = ByteToString(res.BootVersion[:])
	r.HwVersion = ByteToString(res.HwVersion[:])
	r.KernelVersion = ByteToString(res.KernelVersion[:])

	return r, nil
}

// ReceiveAgxGetVersionRes  ...
func (d *Agx) ReceiveAgxGetVersionRes() {
	logger.Info("-->Into AgxGetVersionResponse Result")
	res := &mavlink.AgxGetVersionResponse{}
	d.GetPacket(res)
	logger.Debugf("AgxGetVersionResponse : %+v", res)
	manager, ok := d.WaitTaskMap[mavlink.AgxGetVersion]
	if ok {
		manager.CompletedTask(res, nil)
	}
	logger.Info("--->End Receive AgxGetVersionResponse data")
}

// ReceiveFusionDetectV2 收到融合目标上报
func (d *Agx) ReceiveFusionDetectV2() {
	logger.Info("--->Into Receive Fusion Detect")
	devSn := d.getSn()
	result := &mavlink.AgxFusionDetectV2{}
	if err := d.UnmarshalFusionDetect(result); err != nil {
		logger.Error("ReceiveFusionDetectV2 UnmarshalFusionDetect err: ", err)
		return
	}
	//logger.Debugf("ReceiveFusionDetectV2 result: %v", result)
	d.updateStatus(devSn)
	if result.FusionTracerNum == 0 {
		logger.Debug("no uav report")
		return
	}
	if devSn != "" {
		d.agxFusionDetectReport(devSn, result)
	}
	logger.Info("--->End Receive Fusion Detect, devSn: ", devSn)
}

func (d *Agx) UnmarshalFusionDetect(data *mavlink.AgxFusionDetectV2) error {
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalFusionDetect write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Timestamp); err != nil {
		return fmt.Errorf("UnmarshalFusionDetect read Timestamp err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.FusionTracerNum); err != nil {
		return fmt.Errorf("UnmarshalFusionDetect read FusionTracerNum err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Reserve); err != nil {
		return fmt.Errorf("UnmarshalFusionDetect read Reserve err: %v", err)
	}

	start := mavlink.HeaderLen + 18
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializeDrone(d.Msg[start:end]); err != nil {
		return err
	}

	return nil
}

func (d *Agx) agxFusionDetectReport(devSn string, detects *mavlink.AgxFusionDetectV2) {
	logger.Debugf("--->Into Report FusionDetect: %+v", detects)
	fusionDetectList := make([]*client.AgxFusionDetectV2, 0)
	for _, detect := range detects.FusionObjItemList {
		//融合目标状态，0：暂态目标，1：稳态目标
		if detect.StateType == 0 {
			continue
		}
		role := ENEMY
		if detect.Friendly == 1 {
			role = FRIEND
		}
		tmp := client.AgxFusionDetectV2{
			Id:                 detect.Id,
			DroneName:          ByteToString(detect.DroneName[:]),
			Source:             detect.Source,
			StateType:          int32(detect.StateType),
			ExistingProb:       int32(detect.ExistingProb),
			LifeTime:           detect.LifeTime,
			ForecastTime:       detect.ForecastTime,
			Classification:     int32(detect.Classification),
			ClassificationProb: int32(detect.ClassificationProb),
			GeoValid:           int32(detect.GeoValid),
			Longitude:          float32(detect.Longitude),
			Latitude:           float32(detect.Latitude),
			Height:             float32(detect.Height),
			OrientationAngle:   detect.OrientationAngle,
			AbsoluteSpeed:      detect.AbsoluteSpeed,
			VerticalSpeed:      detect.VerticalSpeed,
			MotionType:         int32(detect.MotionType),
			LoadLevel:          int32(detect.LoadLevel),
			DangerLevel:        int32(detect.DangerLevel),
			Priority:           int32(detect.Priority),
			TargetRange:        detect.TargetRange,
			TargetAzimuth:      detect.TargetAzimuth,
			TargetElevation:    detect.TargetElevation,
			TargetArrivalTime:  detect.TargetArrivalTime,
			TargetTimestamp:    detect.TargetTimestamp,
			Altitude:           detect.Altitude,
			Role:               int32(role),
		}
		if detect.Classification == 0x01 || detect.Classification == 0x05 {
			fd, err := NewAlarmControl().GetDroneThreatLevel(&GetThreatLevelReq{
				DroneSn:        "",
				DroneObjId:     int64(tmp.Id),
				DroneLongitude: detect.Longitude,
				DroneLatitude:  detect.Latitude,
				DevSn:          devSn,
			})

			if err != nil {
				logger.Error("agxFusionDetectReport GetDroneThreatLevel err", err)
			} else {
				tmp.AlarmId = fd.AlarmId
				tmp.EventId = fd.EventId
				tmp.ThreatLevel = fd.ThreatLevel
				tmp.ScenesId = fd.ScenesId
			}
		}
		fusionDetectList = append(fusionDetectList, &tmp)
	}

	equipData, err := GetEquipBySn(devSn)
	name := devSn
	if equipData != nil && equipData.Name != "" {
		name = equipData.Name
	}
	dataInfo := &client.AgxFusionDetectV2Info{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        devSn,
			EquipType: int32(d.DevType),
			MsgType:   mavlink.AgxMsgFusionDetectV2,
		},
		Data: fusionDetectList,
	}
	if err == nil {
		dataInfo.Header.ParentType = int32(equipData.ParentType)
		dataInfo.Header.ParentSn = equipData.ParentSn
		dataInfo.Header.IsIntegrated = equipData.IsIntegrated
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("agxFusionDetectReport proto.Marshal dataInfo err", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIDAgxFusionDetect,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("agxFusionDetectReport proto.Marshal report err", err)
		return
	}
	_ = mq.AgxMsgBroker.Publish(mq.AgxTopic, broker.NewMessage(out))
	logger.Infof("agx Fusion has reported, report: %v", dataInfo)
}

// ReceiveLocationInfo 收到雷视基本信息上报
func (d *Agx) ReceiveLocationInfo(result *mavlink.AgxLocationInfoRsp) {
	logger.Info("-->Into Receive Agx Location info")
	devSn := d.getSn()
	d.updateStatus(devSn)
	if devSn != "" {
		d.agxLocationInfoReport(devSn, result)
	}
	logger.Info("--->End Receive Agx Location info, devSn: ", devSn)
}

func (d *Agx) UnmarshalAgxLocationInfo(data *mavlink.AgxLocationInfoRsp) error {
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalAgxLocationInfo write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data); err != nil {
		return fmt.Errorf("UnmarshalAgxLocationInfo read data err: %v", err)
	}
	return nil
}

func (d *Agx) agxLocationInfoReport(devSn string, info *mavlink.AgxLocationInfoRsp) {
	equipData, err := GetEquipBySn(devSn)
	name := devSn
	if equipData != nil && equipData.Name != "" {
		name = equipData.Name
	}
	dataInfo := &client.AgxLocationStateInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        devSn,
			EquipType: int32(d.DevType),
			MsgType:   mavlink.AgxMsgLocationInfo,
		},
		Data: &client.AgxGetLocationResponse{
			Longitude:   float32(info.Longitude),
			Latitude:    float32(info.Latitude),
			Declination: float32(info.Declination),
			Ip1:         fmt.Sprintf("%d.%d.%d.%d", info.Ip1[0], info.Ip1[1], info.Ip1[2], info.Ip1[3]),
			Ip2:         fmt.Sprintf("%d.%d.%d.%d", info.Ip2[0], info.Ip2[1], info.Ip2[2], info.Ip2[3]),
		},
	}
	if err == nil {
		dataInfo.Header.ParentSn = equipData.ParentSn
		dataInfo.Header.ParentType = int32(equipData.ParentType)
		dataInfo.Header.IsIntegrated = equipData.IsIntegrated
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("agxLocationInfoReport proto.Marshal dataInfo err", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIDAgxLocationInfo,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("agxLocationInfoReport proto.Marshal report err", err)
		return
	}
	_ = mq.AgxMsgBroker.Publish(mq.AgxTopic, broker.NewMessage(out))
	logger.Info("agx Location has reported, report: %v", dataInfo)
}

// ReceiveServoStateInfo DPH中程雷达转台伺服角度
func (d *Agx) ReceiveServoStateInfo() {
	logger.Info("-->Into Receive Agx Servo StateInfo")
	devSn := d.getSn()
	result := &mavlink.AgxDphServoStatus{}
	if err := d.UnmarshalAgxServoStateInfo(result); err != nil {
		logger.Errorf("ReceiveServoStateInfo UnmarshalAgxServoStateInfo err: %v", err)
		return
	}
	d.updateStatus(devSn)
	if devSn != "" {
		d.agxServoStateInfoReport(devSn, result)
	}
	logger.Info("--->End Receive Agx Servo StateInfo, devSn: ", devSn)
}

func (d *Agx) UnmarshalAgxServoStateInfo(data *mavlink.AgxDphServoStatus) error {
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalAgxServoStateInfo write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, data); err != nil {
		return fmt.Errorf("UnmarshalAgxServoStateInfo read data err: %v", err)
	}
	return nil
}

func (d *Agx) agxServoStateInfoReport(devSn string, info *mavlink.AgxDphServoStatus) {
	dph110Sn := ByteToString(info.SN[:])
	equipData, err := GetEquipBySn(dph110Sn)
	name := dph110Sn
	if equipData != nil && equipData.Name != "" {
		name = equipData.Name
	}
	dataInfo := &client.AgxServoStateInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        dph110Sn,
			EquipType: int32(common.DEV_DPH110), //int32(d.DevType)
			MsgType:   mavlink.AgxMsgDphServoStatus,
		},
		Data: &client.AgxServoState{
			Sn:              ByteToString(info.SN[:]),
			TurntableAngle:  info.TurntableAngle * 0.01,
			AngularVelocity: info.AngularVelocity,
		},
	}
	if err == nil {
		dataInfo.Header.ParentSn = equipData.ParentSn
		dataInfo.Header.ParentType = int32(equipData.ParentType)
		dataInfo.Header.IsIntegrated = equipData.IsIntegrated
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("agxServoStateInfoReport proto.Marshal dataInfo err", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIDAgxDphServoStatus,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("agxServoStateInfoReport proto.Marshal report err", err)
		return
	}
	_ = mq.AgxMsgBroker.Publish(mq.AgxTopic, broker.NewMessage(out))
	logger.Info("agx Servo has reported, report: %v", dataInfo)
}

// ReceiveProxyHeartbeat 一体化设备心跳包
// 上报一体化心跳包，代表设备是一体化设备
func (d *Agx) ReceiveProxyHeartbeat() {
	logger.Info("--->Into Receive proxy heart info")
	devSn := d.getSn()
	result := &mavlink.AgxHeartbeatWithDeviceList{}
	if err := d.UnmarshalProxyHeartbeat(result); err != nil {
		logger.Errorf("ReceiveProxyHeartbeat UnmarshalProxyHeartbeat err", err.Error())
		return
	}
	if devSn != "" {
		d.updateStatus(devSn)
		d.updateEquip(devSn)
		d.agxProxyHeartbeatReport(devSn, result)
	}
	logger.Info("--->End Receive proxy heart info: ", devSn)
}

func (d *Agx) updateEquip(sn string) {
	//更新设备表isIntegrated字段
	//是否是一体化设备 0：非一体化 1：一体化
	var isIntegrated int32 = 1
	cacheKey := fmt.Sprintf("%d_%d_%s", d.DevType, isIntegrated, sn)
	if _, ok := isIntegratedMap.Load(cacheKey); !ok {
		field := map[string]interface{}{
			"is_integrated": isIntegrated,
		}
		if err := NewEquipList().UpdateBySn(sn, field); err != nil {
			logger.Error("updateStatus UpdateBySn err:", err)
		} else {
			isIntegratedMap.Store(cacheKey, true)
		}
	}
}

func (d *Agx) UnmarshalProxyHeartbeat(data *mavlink.AgxHeartbeatWithDeviceList) error {
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalFusionDetect write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.SubDeviceNum); err != nil {
		return fmt.Errorf("UnmarshalFusionDetect read Timestamp err: %v", err)
	}

	start := mavlink.HeaderLen + 1
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DecodeProxyHeartbeat(d.Msg[start:end]); err != nil {
		return err
	}

	return nil
}

func (d *Agx) agxProxyHeartbeatReport(devSn string, info *mavlink.AgxHeartbeatWithDeviceList) {
	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	//嵌入式一体化心跳包e5 和 心跳包ea都会上报，如果是一体化设备，只上报一体化心跳
	if equipModel.IsIntegrated == 0 {
		logger.Debug("embedded device heartbeat, ignore", equipModel.IsIntegrated)
		return
	}

	//插入子设备列表
	err = NewEquipList().InsertSubDevices(context.Background(), devSn, int(d.DevType), info)
	if err != nil {
		logger.Errorf("agxProxyHeartbeatReport InsertSubDevices err", err)
	}

	dataInfo := &client.AgxHeartBeatInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        devSn,
			EquipType: int32(d.DevType),
			MsgType:   mavlink.AgxMsgIdHeartbeatWithDeviceList,
		},
		Data: &client.AgxHeartBeatReport{
			IsOnline: common.DevOnline,
			Ip:       d.RemoteIp,
			Sn:       devSn,
		},
	}
	if err == nil {
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	if dataInfo.Data.Ip == "" {
		valI, ok := SnToIpMap.Load(devSn)
		if !ok {
			dbequips := &client.EquipListRes{}
			err := NewEquipList().List(context.Background(), &client.EquipListReq{}, dbequips)
			if err != nil {
				logger.Info("agxProxyHeartbeatReport EquipList err: ", err)
			}
			for _, equip := range dbequips.Equips {
				if equip.Sn == dataInfo.Data.Sn {
					dataInfo.Data.Ip = equip.Ip
					SnToIpMap.Store(devSn, equip.Ip)
				}
			}
		} else {
			dataInfo.Data.Ip = valI.(string)
		}
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("agxProxyHeartbeatReport marshal dataInfo err:", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIdAgxHeartData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("agxProxyHeartbeatReport marshal report err:", err)
		return
	}
	//d.updateStatusOnLine(devSn)

	_ = mq.AgxMsgBroker.Publish(mq.AgxTopic, broker.NewMessage(out))
	logger.Info("agx proxy heart report:", dataInfo)
}

// AgxGetInfo 获取雷视设备信息
func (d *Agx) AgxGetInfo(req *client.AgxGetInfoRequest) (*client.AgxGetInfoResponse, error) {
	logger.Debug("---->Into send AgxGetInfo")
	//1. 获取雷视设备信息
	request := &mavlink.AgxLocationInfoReq{}
	buff := request.Create(req.EquipType)

	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("AgxGetInfo Conn.Write err: ", err)
		return nil, err
	}
	manager, ok := d.WaitTaskMap[mavlink.AgxMsgLocationInfo]
	if !ok {
		manager = NewWaitTaskManager(mavlink.AgxMsgLocationInfo, true, 0)
		d.WaitTaskMap[mavlink.AgxMsgLocationInfo] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		logger.Error("AgxGetInfo manager.Wait err", err)
		return nil, err
	}
	res, ok := result.(*mavlink.AgxLocationInfoRsp)
	if !ok {
		return nil, errors.New("response err type")
	}
	//2. 获取版本号
	getVersionReq := &mavlink.AgxGetVersionRequest{}
	getVersionBuff := getVersionReq.Create(req.EquipType)

	if _, err := d.Conn.Write(getVersionBuff); err != nil {
		logger.Error("Agx AgxGetVersion err: ", err)
		return nil, err
	}
	manager1, ok := d.WaitTaskMap[mavlink.AgxGetVersion]
	if !ok {
		manager1 = NewWaitTaskManager(mavlink.AgxGetVersion, true, 0)
		d.WaitTaskMap[mavlink.AgxGetVersion] = manager1
	}

	getVersionResult, err := manager1.Wait()
	if err != nil {
		logger.Error("AgxGetInfo manager1.Wait err", err)
		//return nil, err
	}
	getVersionRes, ok := getVersionResult.(*mavlink.AgxGetVersionResponse)
	if !ok {
		return nil, errors.New("response err type")
	}

	r := &client.AgxGetInfoResponse{}
	r.Sn = req.Sn
	if getVersionRes != nil {
		r.AppVersion = ByteToString(getVersionRes.AppVersion[:])
	}
	r.Longitude = res.Longitude
	r.Latitude = res.Latitude
	r.Declination = res.Declination
	r.Ip1 = fmt.Sprintf("%d.%d.%d.%d", res.Ip1[0], res.Ip1[1], res.Ip1[2], res.Ip1[3])
	r.Ip2 = fmt.Sprintf("%d.%d.%d.%d", res.Ip2[0], res.Ip2[1], res.Ip2[2], res.Ip2[3])
	logger.Debugf("---->Into send AgxGetInfo result:%+v", r)
	return r, nil
}

// ReceiveAgxLocationInfoRes 获取雷视设备信息
func (d *Agx) ReceiveAgxLocationInfoRes() {
	logger.Debug("-->Into AgxLocationInfo Result")
	res := &mavlink.AgxLocationInfoRsp{}
	d.GetPacket(res)
	manager, ok := d.WaitTaskMap[mavlink.AgxMsgLocationInfo]
	logger.Debugf("--->End Receive AgxLocationInfo exist: %v, data： %+v", ok, res)
	if ok {
		manager.CompletedTask(res, nil)
	}
	d.ReceiveLocationInfo(res)
}

// SendSrp100Calibration srp100开始、退出标定
func (d *Agx) SendSrp100Calibration(req *client.Srp100CalibrationRequest, rsp *client.Srp100CalibrationResponse) error {
	request := &mavlink.Srp100CalibrationRequest{}
	buff := request.Create(req.RadarSn, req.Operate)

	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("SendSrp100Calibration Write err: ", err)
		return err
	}
	manager, ok := d.WaitTaskMap[mavlink.Srp100MsgCalibration]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Srp100MsgCalibration, true, 0)
		d.WaitTaskMap[mavlink.Srp100MsgCalibration] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		logger.Errorf("SendSrp100Calibration Wait err", err)
		return err
	}
	res, ok := result.(*mavlink.Srp100CalibrationResponse)
	if !ok {
		logger.Error("SendSrp100Calibration response type err")
		return errors.New("SendSrp100Calibration response err type")
	}
	logger.Debugf("SendSrp100Calibration result:%+v", res)
	rsp.Status = int32(res.Status)
	return nil
}

// ReceiveSrp100Calibration 收到srp100开始、中断标定结果
func (d *Agx) ReceiveSrp100Calibration() {
	res := &mavlink.Srp100CalibrationResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveSrp100CalibrationRes result： %+v", res)
	manager, ok := d.WaitTaskMap[mavlink.Srp100MsgCalibration]
	if ok {
		manager.CompletedTask(res, nil)
	}
}

// Srp100GetCalibrationStatus srp100获取标定状态
func (d *Agx) Srp100GetCalibrationStatus(req *client.Srp100GetCalibrationStatusRequest, rsp *client.Srp100GetCalibrationStatusResponse) error {
	request := &mavlink.Srp100GetCalibrationStatusRequest{}
	buff := request.Create(req.State)

	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("Srp100GetCalibrationStatus Write err: ", err)
		return err
	}
	manager, ok := d.WaitTaskMap[mavlink.Srp100MsgGetCalibrationStatus]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Srp100MsgGetCalibrationStatus, true, 0)
		d.WaitTaskMap[mavlink.Srp100MsgGetCalibrationStatus] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		logger.Errorf("Srp100GetCalibrationStatus Wait err", err)
		return err
	}
	res, ok := result.(*mavlink.Srp100GetCalibrationStatusResponse)
	if !ok {
		return errors.New("Srp100GetCalibrationStatus response err type")
	}
	logger.Debugf("Srp100GetCalibrationStatus result:%v", res)
	timestamp := strconv.Itoa(int(res.Timestamp))
	rsp.Timestamp = timestamp
	rsp.RadarSn = ByteToString(res.RadarSn[:])
	rsp.CalibOngoingState = int32(res.CalibOngoingState)
	rsp.CalibState = int32(res.CalibState)
	rsp.RecommendUavHeight = res.RecommendUavHeight
	rsp.RecommendUavFlyDirection = res.RecommendUavFlyDirection
	rsp.CalibProgressBar = int32(res.CalibProgressBar)
	rsp.YawValidFlag = int32(res.YawValidFlag)
	rsp.YawMean = res.YawMean
	rsp.YawVariance = res.YawVariance
	rsp.YawMaxFiff = res.YawMaxFiff
	rsp.PitchValidFlag = int32(res.PitchValidFlag)
	rsp.PitchMean = res.PitchMean
	rsp.PitchVariance = res.PitchVariance
	rsp.PitchMaxFiff = res.PitchMaxFiff
	rsp.YawOffset = res.YawOffset
	rsp.PitchOffset = res.PitchOffset
	rsp.RollOffset = res.RollOffset
	rsp.HeightOffset = res.HeightOffset
	rsp.ValidFlag = int32(res.ValidFlag)
	return nil
}

// ReceiveSrp100GetCalibrationStatus 收到srp100获取标定状态结果
func (d *Agx) ReceiveSrp100GetCalibrationStatus() {
	res := &mavlink.Srp100GetCalibrationStatusResponse{}
	d.GetPacket(res)
	//manager, ok := d.WaitTaskMap[mavlink.Srp100MsgGetCalibrationStatus]
	logger.Debugf("ReceiveSrp100GetCalibrationStatus result： %+v", res)
	//if ok {
	//	manager.CompletedTask(res, nil)
	//}
	//标定完成，agx主动上报
	if err := d.reportSrp100GetCalibrationStatus(res); err != nil {
		logger.Error("ReceiveSrp100GetCalibrationStatus reportSrp100GetCalibrationStatus err", err)
	}
}

// reportSrp100GetCalibrationStatus 标定完成，agx主动上报
func (d *Agx) reportSrp100GetCalibrationStatus(res *mavlink.Srp100GetCalibrationStatusResponse) error {
	timestamp := strconv.Itoa(int(res.Timestamp))
	sn := d.getSn()
	d.updateStatus(sn)
	equipModel, err := GetEquipBySn(sn)
	name := sn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	dataInfo := &client.Srp100CalibrationStatus{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        sn,
			EquipType: int32(common.DEV_AGX),
			MsgType:   mavlink.Srp100MsgGetCalibrationStatus,
		},
		Data: &client.CalibrationStatus{
			Timestamp:                timestamp,
			RadarSn:                  ByteToString(res.RadarSn[:]),
			CalibOngoingState:        int32(res.CalibOngoingState),
			CalibState:               int32(res.CalibState),
			RecommendUavHeight:       res.RecommendUavHeight,
			RecommendUavFlyDirection: res.RecommendUavFlyDirection,
			CalibProgressBar:         int32(res.CalibProgressBar),
			YawValidFlag:             int32(res.YawValidFlag),
			YawMean:                  res.YawMean,
			YawVariance:              res.YawVariance,
			YawMaxFiff:               res.YawMaxFiff,
			PitchValidFlag:           int32(res.PitchValidFlag),
			PitchMean:                res.PitchMean,
			PitchVariance:            res.PitchVariance,
			PitchMaxFiff:             res.PitchMaxFiff,
			YawOffset:                res.YawOffset,
			PitchOffset:              res.PitchOffset,
			RollOffset:               res.RollOffset,
			HeightOffset:             res.HeightOffset,
			ValidFlag:                int32(res.ValidFlag),
		},
	}
	if err == nil {
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("reportSrp100GetCalibrationStatus Marshal dataInfo err", err)
		return err
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIDSrp100CalibrationStatus,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("reportSrp100GetCalibrationStatus Marshal report err: ", err)
		return err
	}
	_ = mq.AgxMsgBroker.Publish(mq.AgxTopic, broker.NewMessage(out))
	logger.Debugf("srp100 calibration status has reported, report: %+v", dataInfo)
	return nil
}

// Srp100UserHandTarget srp100用户下发手点像素目标值
func (d *Agx) Srp100UserHandTarget(req *client.Srp100UserHandTargetPointRequest, rsp *client.Srp100UserHandTargetPointResponse) error {
	request := &mavlink.Srp100UserHandTargetPointRequest{}
	buff := request.Create(req)

	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("Srp100UserHandTarget Write err: ", err)
		return err
	}
	manager, ok := d.WaitTaskMap[mavlink.Srp100MsgHandTargetPoint]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Srp100MsgHandTargetPoint, true, 0)
		d.WaitTaskMap[mavlink.Srp100MsgHandTargetPoint] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		logger.Errorf("Srp100UserHandTarget Wait err", err)
		return err
	}
	res, ok := result.(*mavlink.Srp100UserHandTargetPointResponse)
	if !ok {
		return errors.New("Srp100UserHandTarget response err type")
	}
	logger.Debugf("Srp100UserHandTarget result:%+v", res)
	rsp.Status = int32(res.Status)
	return nil
}

// ReceiveSrp100UserHandTarget 收到srp100用户下发手点像素目标值结果
func (d *Agx) ReceiveSrp100UserHandTarget() {
	res := &mavlink.Srp100UserHandTargetPointResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveSrp100UserHandTarget result： %+v", res)
	manager, ok := d.WaitTaskMap[mavlink.Srp100MsgHandTargetPoint]
	if ok {
		manager.CompletedTask(res, nil)
	}
}

// Srp100ConfirmCalibration 目标已锁定，是否确认当前锁定
func (d *Agx) Srp100ConfirmCalibration(req *client.Srp100ConfirmCalibrationRequest, rsp *client.Srp100ConfirmCalibrationResponse) error {
	request := &mavlink.Srp100ConfirmCalibrationRequest{}
	buff := request.Create(req.Confirm)

	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("Srp100ConfirmCalibration Write err: ", err)
		return err
	}
	manager, ok := d.WaitTaskMap[mavlink.Srp100MsgConfirmCalibration]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Srp100MsgConfirmCalibration, true, 0)
		d.WaitTaskMap[mavlink.Srp100MsgConfirmCalibration] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		logger.Errorf("Srp100ConfirmCalibration Wait err", err)
		return err
	}
	res, ok := result.(*mavlink.Srp100ConfirmCalibrationResponse)
	if !ok {
		return errors.New("Srp100ConfirmCalibration response err type")
	}
	logger.Debugf("Srp100ConfirmCalibration result:%+v", res)
	rsp.Status = int32(res.Status)
	return nil
}

// ReceiveSrp100ConfirmCalibration 收到srp100标定确认响应
func (d *Agx) ReceiveSrp100ConfirmCalibration() {
	res := &mavlink.Srp100ConfirmCalibrationResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveSrp100ConfirmCalibration result： %+v", res)
	manager, ok := d.WaitTaskMap[mavlink.Srp100MsgConfirmCalibration]
	if ok {
		manager.CompletedTask(res, nil)
	}
}

// ReceiveSrp100CalibrationData agx主动上报标定数据
func (d *Agx) ReceiveSrp100CalibrationData() {
	devSn := d.getSn()
	d.updateStatus(devSn)
	res := &mavlink.Srp100CalibrationData{}
	err := d.UnmarshalCalibrationData(res)
	if err != nil {
		logger.Error("ReceiveSrp100CalibrationData UnmarshalCalibrationData err: %v", err)
		return
	}
	logger.Debugf("ReceiveSrp100CalibrationData result： %+v", res)
	if devSn != "" {
		if err := reportSrp100CalibrationData(devSn, res); err != nil {
			logger.Errorf("ReceiveSrp100CalibrationData report err: %v", err)
			return
		}
	}
	logger.Debugf("--> End ReceiveSrp100CalibrationData sn： %v", devSn)
}

func (d *Agx) UnmarshalCalibrationData(data *mavlink.Srp100CalibrationData) error {
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalCalibrationData write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Timestamp); err != nil {
		return fmt.Errorf("UnmarshalCalibrationData read Timestamp err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Number); err != nil {
		return fmt.Errorf("UnmarshalCalibrationData read Number err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.SrpSn); err != nil {
		return fmt.Errorf("UnmarshalCalibrationData read SrpSn err: %v", err)
	}

	start := mavlink.HeaderLen + 35
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DecodeCalibrationData(d.Msg[start:end]); err != nil {
		return err
	}
	return nil
}

func reportSrp100CalibrationData(sn string, data *mavlink.Srp100CalibrationData) error {
	timestamp := strconv.Itoa(int(data.Timestamp))
	calibrationData := &client.Srp100CalibrationData{
		Timestamp: timestamp,
		Number:    int32(data.Number),
		RadarSn:   ByteToString(data.SrpSn[:]),
		Data:      make([]*client.CalibrationData, 0),
	}
	for i := 0; i < int(data.Number); i++ {
		radarTimestamp := strconv.Itoa(int(data.CalibrationList[i].Timestamp))
		tmp := &client.CalibrationData{
			PtzPitch:   data.CalibrationList[i].PtzPitch,
			PtzYaw:     data.CalibrationList[i].PtzYaw,
			RadarYaw:   data.CalibrationList[i].RadarYaw,
			RadarPitch: data.CalibrationList[i].RadarPitch,
			Timestamp:  radarTimestamp,
		}
		calibrationData.Data = append(calibrationData.Data, tmp)
	}
	equipModel, err := GetEquipBySn(sn)
	name := sn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	dataInfo := &client.Srp100CalibrationInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        sn,
			EquipType: int32(common.DEV_AGX),
			MsgType:   mavlink.Srp100MsgReportCalibrationData,
		},
		Data: calibrationData,
	}
	if err == nil {
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("reportSrp100CalibrationData Marshal dataInfo err", err)
		return err
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIDSrp100CalibrationData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("reportSrp100CalibrationData Marshal report err", err)
		return err
	}
	_ = mq.AgxMsgBroker.Publish(mq.AgxTopic, broker.NewMessage(out))
	logger.Debugf("srp100 calibration data has reported, report: %+v", dataInfo)
	return nil
}

// Srp100GetCalibrationResult 查询标定结果
func (d *Agx) Srp100GetCalibrationResult(req *client.Srp100GetCalibrationResultRequest, rsp *client.Srp100GetCalibrationResultResponse) error {
	request := &mavlink.Srp100GetCalibrationResultRequest{}
	buff := request.Create(req.RadarSn, req.Spec)

	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("Srp100GetCalibrationResult Write err: ", err)
		return err
	}
	manager, ok := d.WaitTaskMap[mavlink.Srp100MsgGetCalibrationResult]
	if !ok {
		manager = NewWaitTaskManager(mavlink.Srp100MsgGetCalibrationResult, true, 0)
		d.WaitTaskMap[mavlink.Srp100MsgGetCalibrationResult] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		logger.Errorf("Srp100GetCalibrationResult Wait err", err)
		return err
	}
	res, ok := result.(*mavlink.Srp100GetCalibrationResultResponse)
	if !ok {
		return errors.New("Srp100GetCalibrationResult response err type")
	}
	logger.Debugf("Srp100GetCalibrationResult result:%+v", res)
	timestamp := strconv.Itoa(int(res.Timestamp))
	rsp.Timestamp = timestamp
	rsp.SrpSn = ByteToString(res.SrpSn[:])
	rsp.Longitude = res.Longitude
	rsp.Latitude = res.Latitude
	rsp.Altitude = res.Altitude
	rsp.Yaw = res.Yaw
	rsp.Pitch = res.Pitch
	rsp.Roll = res.Roll
	rsp.StateFlag = int32(res.StateFlag)
	rsp.RadarNum = int32(res.RadarNum)
	rsp.RadarList = make([]*client.Srp100RadarInfo, 0)
	for i := 0; i < int(res.RadarNum); i++ {
		radarTimestamp := strconv.Itoa(int(res.RadarList[i].RadarTimestamp))
		tmp := &client.Srp100RadarInfo{
			RadarSn:          ByteToString(res.RadarList[i].RadarSn[:]),
			Longitude:        res.RadarList[i].Longitude,
			Latitude:         res.RadarList[i].Latitude,
			Altitude:         res.RadarList[i].Altitude,
			LocalTx:          res.RadarList[i].LocalTx,
			LocalTy:          res.RadarList[i].LocalTy,
			LocalTz:          res.RadarList[i].LocalTz,
			LocalRoll:        res.RadarList[i].LocalRoll,
			LocalPitch:       res.RadarList[i].LocalPitch,
			LocalYaw:         res.RadarList[i].LocalYaw,
			LocalDeltaTx:     res.RadarList[i].LocalDeltaTx,
			LocalDeltaTy:     res.RadarList[i].LocalDeltaTy,
			LocalDeltaTz:     res.RadarList[i].LocalDeltaTz,
			LocalDeltaTRoll:  res.RadarList[i].LocalDeltaTRoll,
			LocalDeltaTPitch: res.RadarList[i].LocalDeltaTPitch,
			LocalDeltaTYaw:   res.RadarList[i].LocalDeltaTYaw,
			RadarStateFlag:   int32(res.RadarList[i].RadarStateFlag),
			RadarTimestamp:   radarTimestamp,
		}
		rsp.RadarList = append(rsp.RadarList, tmp)
	}

	return nil
}

// ReceiveSrp100GetCalibrationResult 标定结果查询和同步
func (d *Agx) ReceiveSrp100GetCalibrationResult() {
	res := &mavlink.Srp100GetCalibrationResultResponse{}
	err := d.UnmarshalCalibrationResult(res)
	if err != nil {
		logger.Error("ReceiveSrp100GetCalibrationResult UnmarshalCalibrationResult err", err)
		return
	}
	manager, ok := d.WaitTaskMap[mavlink.Srp100MsgGetCalibrationResult]
	logger.Debugf("ReceiveSrp100GetCalibrationResult ok: %v, result: %+v", ok, res)
	if ok {
		manager.CompletedTask(res, nil)
	}
	//标定完成，agx主动上报
	if err := d.reportSrp100GetCalibrationResult(res); err != nil {
		logger.Error("ReceiveSrp100GetCalibrationResult reportSrp100GetCalibrationResult err", err)
	}
}

func (d *Agx) UnmarshalCalibrationResult(data *mavlink.Srp100GetCalibrationResultResponse) error {
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalCalibrationResult write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Timestamp); err != nil {
		return fmt.Errorf("UnmarshalCalibrationResult read Timestamp err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.SrpSn); err != nil {
		return fmt.Errorf("UnmarshalCalibrationResult read SrpSn err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Longitude); err != nil {
		return fmt.Errorf("UnmarshalCalibrationResult read Longitude err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Latitude); err != nil {
		return fmt.Errorf("UnmarshalCalibrationResult read Latitude err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Altitude); err != nil {
		return fmt.Errorf("UnmarshalCalibrationResult read Altitude err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Yaw); err != nil {
		return fmt.Errorf("UnmarshalCalibrationResult read Yaw err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Pitch); err != nil {
		return fmt.Errorf("UnmarshalCalibrationResult read Pitch err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Roll); err != nil {
		return fmt.Errorf("UnmarshalCalibrationResult read Roll err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.StateFlag); err != nil {
		return fmt.Errorf("UnmarshalCalibrationResult read StateFlag err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.RadarNum); err != nil {
		return fmt.Errorf("UnmarshalCalibrationResult read RadarNum err: %v", err)
	}

	start := mavlink.HeaderLen + 79
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DecodeCalibrationResult(d.Msg[start:end]); err != nil {
		return err
	}
	return nil
}

// 上报标定结果
func (d *Agx) reportSrp100GetCalibrationResult(res *mavlink.Srp100GetCalibrationResultResponse) error {
	sn := d.getSn()
	d.updateStatus(sn)
	equipModel, err := GetEquipBySn(sn)
	name := sn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	timestamp := strconv.Itoa(int(res.Timestamp))
	calibrationResult := &client.CalibrationResult{
		Timestamp: timestamp,
		SrpSn:     ByteToString(res.SrpSn[:]),
		Longitude: res.Longitude,
		Latitude:  res.Latitude,
		Altitude:  res.Altitude,
		Yaw:       res.Yaw,
		Pitch:     res.Pitch,
		Roll:      res.Roll,
		StateFlag: int32(res.StateFlag),
		RadarNum:  int32(res.RadarNum),
		RadarList: make([]*client.Srp100RadarData, 0),
	}

	for i := 0; i < int(res.RadarNum); i++ {
		radarTimestamp := strconv.Itoa(int(res.RadarList[i].RadarTimestamp))
		tmp := &client.Srp100RadarData{
			RadarSn:          ByteToString(res.RadarList[i].RadarSn[:]),
			Longitude:        res.RadarList[i].Longitude,
			Latitude:         res.RadarList[i].Latitude,
			Altitude:         res.RadarList[i].Altitude,
			LocalTx:          res.RadarList[i].LocalTx,
			LocalTy:          res.RadarList[i].LocalTy,
			LocalTz:          res.RadarList[i].LocalTz,
			LocalRoll:        res.RadarList[i].LocalRoll,
			LocalPitch:       res.RadarList[i].LocalPitch,
			LocalYaw:         res.RadarList[i].LocalYaw,
			LocalDeltaTx:     res.RadarList[i].LocalDeltaTx,
			LocalDeltaTy:     res.RadarList[i].LocalDeltaTy,
			LocalDeltaTz:     res.RadarList[i].LocalDeltaTz,
			LocalDeltaTRoll:  res.RadarList[i].LocalDeltaTRoll,
			LocalDeltaTPitch: res.RadarList[i].LocalDeltaTPitch,
			LocalDeltaTYaw:   res.RadarList[i].LocalDeltaTYaw,
			RadarStateFlag:   int32(res.RadarList[i].RadarStateFlag),
			RadarTimestamp:   radarTimestamp,
		}
		calibrationResult.RadarList = append(calibrationResult.RadarList, tmp)
	}

	dataInfo := &client.Srp100CalibrationResult{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        sn,
			EquipType: int32(common.DEV_AGX),
			MsgType:   mavlink.Srp100MsgGetCalibrationResult,
		},
		Data: calibrationResult,
	}
	if err == nil {
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("reportSrp100GetCalibrationResult Marshal dataInfo err", err)
		return err
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIDSrp100CalibrationResult,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("reportSrp100GetCalibrationResult Marshal report err: ", err)
		return err
	}
	_ = mq.AgxMsgBroker.Publish(mq.AgxTopic, broker.NewMessage(out))
	logger.Debugf("srp100 calibration result has reported, report: %+v", dataInfo)
	return nil
}

var WaitTaskMap = make(map[int]map[int]*WaitTaskManager)

func (d *Agx) ForwardRadarSetMask(req *client.RadarSetMaskRequest, rsp *client.RadarSetMaskResponse) error {
	logger.Infof("ForwardRadarSetMask req: %v", req)
	result := &bizproto.RadarC2SetMaskRsp{}
	radarSetMaskReq := &bizproto.RadarC2Mask{
		Sn:        &(req.Sn),
		AllDelete: req.AllDeleteValue,
		ItemMask:  make([]*bizproto.RadarMaskZoneInfo, 0),
	}
	for _, item := range req.GetItemMasks() {
		if item.GetOrder() < 0 || item.GetOrder() > 2 {
			return errors.New("ForwardRadarSetMask param order must be 0-2")
		}
		if len(item.GetName()) > 128 {
			return errors.New("ForwardRadarSetMask param name length must be less than 128")
		}

		for _, val := range item.GetClassification() {
			if _, ok := bitMapping[val]; !ok {
				return errors.New("ForwardRadarSetMask param classification must be 0-6")
			}
		}
		//数组转换成uint32
		classification := int32ArrayToUint32(item.GetClassification())
		tmp := &bizproto.RadarMaskZoneInfo{
			Order:          item.Order,
			RangStart:      item.RangeStart,
			RangEnd:        item.RangeEnd,
			AzimuthStart:   item.AzimuthStart,
			AzimuthEng:     item.AzimuthEnd,
			ElevationStart: item.ElevationStart,
			ElevationEnd:   item.ElevationEnd,
			VelocityStart:  item.VelocityStart,
			VelocityEnd:    item.VelocityEnd,
			RcsStart:       item.RcsStart,
			RcsEnd:         item.RcsEnd,
			HighStart:      item.HeightStart,
			HighEnd:        item.HeightEnd,
			TargetType:     &classification,
			Name:           item.Name,
			Number:         item.Number,
			Used:           item.InvalidTag,
		}
		radarSetMaskReq.ItemMask = append(radarSetMaskReq.ItemMask, tmp)
	}

	cmdLen, reqBuff, err := encodeSlinkV2(req.GetSn(), msgid.RadarIdV2SetMask, radarSetMaskReq)
	if err != nil {
		logger.Errorf("ForwardRadarSetMask encodeSlinkV2 err", err)
		return err
	}

	var fdResp mavlink.AgxProxyCmdResponse
	//2: 塞防slink-V2协议
	buff := fdResp.Create(req.GetSn(), 2, req.GetParentType(), cmdLen, reqBuff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("ForwardRadarSetMask err: ", err)
		return err
	}

	_, ok := WaitTaskMap[msgid.RadarIdV2SetMask]
	if !ok {
		WaitTaskMap[msgid.RadarIdV2SetMask] = make(map[int]*WaitTaskManager)
	}
	manager := WaitTaskMap[msgid.RadarIdV2SetMask][mavlink.AgxMsgInfoForward]
	if !ok {
		manager = NewWaitTaskManager(mavlink.AgxMsgInfoForward, true, 0)
		WaitTaskMap[msgid.RadarIdV2SetMask][mavlink.AgxMsgInfoForward] = manager
	}
	resp, err := manager.Wait()
	if err != nil {
		logger.Error("ForwardRadarMask manager1.Wait err", err)
		return err
	}
	result, ok = resp.(*bizproto.RadarC2SetMaskRsp)
	if !ok {
		return errors.New("ForwardRadarMask response err type")
	}

	logger.Debugf("ForwardRadarMask result: %+v", result)
	rsp.AllDeleteResult = result.AllResult
	rsp.ItemResults = make([]*client.RadarMaskResult, 0)
	for _, info := range result.ItemResult {
		tmp := &client.RadarMaskResult{
			Order:  info.Order,
			Name:   info.Name,
			Result: info.Result,
			Number: info.Number,
		}
		rsp.ItemResults = append(rsp.ItemResults, tmp)
	}
	logger.Debugf("-->Into ForwardRadarMask resp: %+v", rsp)
	return nil
}

func (d *Agx) ForwardRadarGetMask(req *client.RadarGetMaskRequest, rsp *client.RadarGetMaskResponse) error {
	logger.Infof("ForwardRadarGetMask req: %v", req)
	result := &bizproto.RadarC2Mask{}
	cmdLen, reqBuff, err := encodeSlinkV2(req.GetSn(), msgid.RadarIdV2GetMask, nil)
	if err != nil {
		logger.Errorf("ForwardRadarGetMask encodeSlinkV2 err", err)
		return err
	}

	var fdResp mavlink.AgxProxyCmdResponse
	//2: 塞防slink-V2协议
	buff := fdResp.Create(req.GetSn(), 2, req.GetParentType(), cmdLen, reqBuff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("ForwardRadarGetMask err: ", err)
		return err
	}

	_, ok := WaitTaskMap[msgid.RadarIdV2GetMask]
	if !ok {
		WaitTaskMap[msgid.RadarIdV2GetMask] = make(map[int]*WaitTaskManager)
	}
	manager := WaitTaskMap[msgid.RadarIdV2GetMask][mavlink.AgxMsgInfoForward]
	if !ok {
		manager = NewWaitTaskManager(mavlink.AgxMsgInfoForward, true, 0)
		WaitTaskMap[msgid.RadarIdV2GetMask][mavlink.AgxMsgInfoForward] = manager
	}
	resp, err := manager.Wait()
	if err != nil {
		logger.Error("ForwardRadarGetMask manager1.Wait err", err)
		return err
	}
	result, ok = resp.(*bizproto.RadarC2Mask)
	if !ok {
		return errors.New("ForwardRadarGetMask response err type")
	}

	logger.Debugf("ForwardRadarGetMask result: %+v", result)
	invalidTag := result.GetAllDelete()
	if invalidTag == 2 {
		invalidTag = 0
	} else if invalidTag == 3 {
		invalidTag = 1
	}
	rsp.InvalidTag = &invalidTag
	rsp.ItemMasks = make([]*client.RadarMaskInfo, 0)
	for _, info := range result.ItemMask {
		tmp := &client.RadarMaskInfo{
			Order:          info.Order,
			RangeStart:     info.RangStart,
			RangeEnd:       info.RangEnd,
			AzimuthStart:   info.AzimuthStart,
			AzimuthEnd:     info.AzimuthEng,
			ElevationStart: info.ElevationStart,
			ElevationEnd:   info.ElevationEnd,
			VelocityStart:  info.VelocityStart,
			VelocityEnd:    info.VelocityEnd,
			RcsStart:       info.RcsStart,
			RcsEnd:         info.RcsEnd,
			Name:           info.Name,
			Classification: Uint32ToIntArray(info.GetTargetType()),
			HeightStart:    info.HighStart,
			HeightEnd:      info.HighEnd,
			Number:         info.Number,
			InvalidTag:     info.Used,
		}
		rsp.ItemMasks = append(rsp.ItemMasks, tmp)
	}

	logger.Debugf("-->Into ForwardRadarGetMask resp: %+v", rsp)
	return nil
}

func (d *Agx) ForwardRadarSetConfig(req *client.RadarSetConfigRequest, rsp *client.RadarSetConfigResponse) error {
	switch req.GetVersionType() {
	case 1:
		err := d.ForwardRadarV1Set(req, rsp)
		if err != nil {
			logger.Errorf("ForwardRadarSetConfig ForwardRadarV1Set err", err)
			return err
		}
		return nil
	case 2:
		result, err := d.ForwardRadarV2Set(req)
		if err != nil {
			logger.Errorf("ForwardRadarSetConfig ForwardRadarV2Set err", err)
			return err
		}
		rsp.Status = result.Status
		rsp.ErrCode = make([]*client.RadarC2ErrCode, 0)
		for _, info := range result.ErrCode {
			tmp := &client.RadarC2ErrCode{
				Name: info.Name,
				Code: info.Code,
			}
			rsp.ErrCode = append(rsp.ErrCode, tmp)
		}
		return nil
	default:
		return fmt.Errorf("ForwardRadarSetConfig not support version type: %d", req.GetVersionType())
	}
}

func (d *Agx) ForwardRadarV1Set(req *client.RadarSetConfigRequest, rsp *client.RadarSetConfigResponse) error {
	logger.Debugf("-->Into ForwardRadarV1Set req: %v", req)

	//手动标定姿态
	setPostureCalibrationManualRsp, err := d.sendSetPostureCalibrationManual(req)
	if err != nil {
		logger.Errorf("ForwardRadarV1Set setPostureCalibrationManual err", err)
		return err
	}
	if setPostureCalibrationManualRsp.Status != 0 {
		rsp.Status = uint32(setPostureCalibrationManualRsp.Status)
		return nil
	}
	rsp.Status = uint32(setPostureCalibrationManualRsp.Status)
	//设置波束范围
	setBeamSizeRsp, err := d.sendSetBeamConfig(req)
	if err != nil {
		logger.Errorf("ForwardRadarV1Set setBeamConfig err", err)
		return err
	}
	if setBeamSizeRsp.Status != 0 {
		rsp.Status = uint32(setBeamSizeRsp.Status)
		return nil
	}
	rsp.Status = uint32(setBeamSizeRsp.Status)
	//设置滤波等级
	setClutterSuppressionRsp, err := d.sendSetClutterSuppression(req)
	if err != nil {
		logger.Errorf("ForwardRadarV1Set setClutterSuppression err", err)
		return err
	}
	if setClutterSuppressionRsp.Status != 0 {
		rsp.Status = uint32(setClutterSuppressionRsp.Status)
		return nil
	}
	rsp.Status = uint32(setClutterSuppressionRsp.Status)

	switch req.GetMode() {
	//自动标定
	case uint32(common.AUTOPOSTURECALIBRATION):
		postureCalibrationRsp, err := d.sendPostureCalibration(req)
		if err != nil {
			logger.Errorf("ForwardRadarV1Set postureCalibration err", err)
			return err
		}
		if postureCalibrationRsp.Status != 0 {
			rsp.Status = uint32(postureCalibrationRsp.Status)
			return nil
		}
		rsp.Status = uint32(postureCalibrationRsp.Status)
		// 雷达开始侦测
	case uint32(common.STARTDETECT):
		startDetectRsp, err := d.sendStartDetect(req)
		if err != nil {
			logger.Errorf("ForwardRadarV1Set startDetect err", err)
			return err
		}
		if startDetectRsp.Status != 0 {
			rsp.Status = uint32(startDetectRsp.Status)
			return nil
		}
		rsp.Status = uint32(startDetectRsp.Status)
		// 雷达结束侦测
	case uint32(common.ENDDETECT):
		sendEndDetectRsp, err := d.sendEndDetect(req)
		if err != nil {
			logger.Errorf("ForwardRadarV1Set sendEndDetect err", err)
			return err
		}
		if sendEndDetectRsp.Status != 0 {
			rsp.Status = uint32(sendEndDetectRsp.Status)
			return nil
		}
		rsp.Status = uint32(sendEndDetectRsp.Status)
	}
	return nil

}

// 转发雷达T6设置配置参数
func (d *Agx) ForwardRadarV2Set(req *client.RadarSetConfigRequest) (*bizproto.RadarC2SetConfigRsp, error) {
	logger.Debugf("-->Into ForwardRadarV2Set req: %v", req)
	radarC2SetConfigRsp := &bizproto.RadarC2SetConfigRsp{}
	var result mavlink.AgxProxyCmdResponse
	sn := req.GetSn()

	radarSetConfigReq := &bizproto.RadarC2Config{
		//Sn:              &sn,
		Version:         req.Version,
		Longitude:       req.Longitude,
		Latitude:        req.Latitude,
		Altitude:        req.Altitude,
		Heading:         req.Heading,
		Pitching:        req.Pitching,
		Rolling:         req.Rolling,
		EleScanCenter:   req.EleScanCenter,
		EleScanScope:    req.EleScanScope,
		AziScanCenter:   req.AziScanCenter,
		AziScanScope:    req.AziScanScope,
		RadarScanRadius: req.RadarScanRadius,
		FilterLevel:     req.FilterLevel,
		Electricity:     req.Electricity,
		Status:          req.Status,
		SysStatus:       req.SysStatus,
		FChannel:        req.FChannel,
		TChannel:        req.TChannel,
		Mode:            req.Mode,
		ClutterMode:     req.ClutterMode,
	}
	cmdLen, reqBuff, err := encodeSlinkV2(sn, msgid.RadarV2SetConfig, radarSetConfigReq)
	if err != nil {
		logger.Errorf("ForwardRadarV2Set encodeSlinkV2 err", err)
		return nil, err
	}

	buff := result.Create(sn, req.GetVersionType(), req.GetParentType(), cmdLen, reqBuff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("ForwardRadarV2Set err: ", err)
		return nil, err
	}

	_, ok := WaitTaskMap[msgid.RadarV2SetConfig]
	if !ok {
		WaitTaskMap[msgid.RadarV2SetConfig] = make(map[int]*WaitTaskManager)
	}
	manager := WaitTaskMap[msgid.RadarV2SetConfig][mavlink.AgxMsgInfoForward]
	if !ok {
		manager = NewWaitTaskManager(mavlink.AgxMsgInfoForward, true, 0)
		WaitTaskMap[msgid.RadarV2SetConfig][mavlink.AgxMsgInfoForward] = manager
	}
	resp, err := manager.Wait()
	if err != nil {
		logger.Error("ForwardRadarV2Set manager1.Wait err", err)
		return nil, err
	}
	radarC2SetConfigRsp, ok = resp.(*bizproto.RadarC2SetConfigRsp)
	if !ok {
		return nil, errors.New("response err type")
	}
	logger.Debugf("-->Into ForwardRadarV2Set resp: %+v", radarC2SetConfigRsp)
	return radarC2SetConfigRsp, nil

}

func (d *Agx) ForwardRadarGetConfig(req *client.RadarGetConfigRequest, rsp *client.RadarGetConfigResponse) error {
	switch req.GetVersionType() {
	case 1:
		err := d.ForwardRadarV1Get(req, rsp)
		if err != nil {
			logger.Errorf("ForwardRadarGetConfig ForwardRadarV1Get err", err)
			return err
		}
	case 2:
		result, err := d.ForwardRadarV2Get(req)
		if err != nil {
			logger.Errorf("ForwardRadarGetConfig ForwardRadarV2Get err", err)
			return err
		}
		rsp.Sn = result.Sn
		rsp.Version = result.Version
		rsp.Longitude = result.Longitude
		rsp.Latitude = result.Latitude
		rsp.Altitude = result.Altitude
		rsp.Heading = result.Heading
		rsp.Pitching = result.Pitching
		rsp.Rolling = result.Rolling
		rsp.EleScanCenter = result.EleScanCenter
		rsp.EleScanScope = result.EleScanScope
		rsp.AziScanCenter = result.AziScanCenter
		rsp.AziScanScope = result.AziScanScope
		rsp.RadarScanRadius = result.RadarScanRadius
		rsp.FilterLevel = result.FilterLevel
		rsp.Electricity = result.Electricity
		rsp.Status = result.Status
		rsp.SysStatus = result.SysStatus
		rsp.FChannel = result.FChannel
		rsp.TChannel = result.TChannel
		rsp.VersionType = codec.VersionTypeV2Str
		rsp.ClutterMode = result.ClutterMode
		return nil
	default:
		return fmt.Errorf("ForwardRadarGetConfig not support version type: %d", req.GetVersionType())
	}
	return nil
}

func (d *Agx) ForwardRadarV1Get(req *client.RadarGetConfigRequest, rsp *client.RadarGetConfigResponse) error {
	logger.Debugf("-->Into ForwardRadarV1Get req: %v", req)
	sn := req.GetSn()
	//获取版本号
	getVersionRsp, err := d.getVersionInfo(sn, req.GetParentSn(), req.GetVersionType(), req.GetParentType())
	if err != nil {
		logger.Errorf("ForwardRadarV1Get getVersionInfo err", err)
		return err
	}
	//获取波束范围
	getBeamSteerResp, err := d.getBeamSteerConfig(sn, req.GetParentSn(), req.GetVersionType(), req.GetParentType())
	if err != nil {
		logger.Errorf("ForwardRadarV1Get getBeamSteerConfig err", err)
		return err
	}
	//获取杂波抑制
	getClutterSuppressionResp, err := d.getClutterSuppression(sn, req.GetParentSn(), req.GetVersionType(), req.GetParentType())
	if err != nil {
		logger.Errorf("ForwardRadarV1Get getClutterSuppression err", err)
		return err
	}
	// 4. 姿态信息从表 radar_tcp_posture_info 获取最新一条
	postureInfo, err := NewRadarTcpDataCache().GetLastPosture(context.Background(), sn)
	if err != nil {
		logger.Errorf("ForwardRadarV1Get GetLastPosture err: %v", err)
		return err
	}
	logger.Debugf("ForwardRadarV1Get GetLastPosture result: %v", postureInfo)
	//组装返回结果
	aziScanCenter := helper.TranBaseType[float32, int8](getBeamSteerResp.AziScanCenter)
	aziScanScope := helper.TranBaseType[float32, uint8](getBeamSteerResp.AziScanScope)
	eleScanScope := helper.TranBaseType[float32, uint8](getBeamSteerResp.EleScanScope)
	eleScanCenter := helper.TranBaseType[float32, int8](getBeamSteerResp.EleScanCenter)
	fChannel := helper.TranBaseType[uint32, uint8](getBeamSteerResp.WaveFrequencyChannel)

	appVersion := trimStringSpace(getVersionRsp.AppVersion[:])
	if appVersion != "" {
		err = NewEquipList().Update(context.Background(), &client.EquipCrudReq{
			Sn:         sn,
			DevVersion: appVersion,
		}, &client.EquipCrudRes{})
		if err != nil {
			logger.Error("ForwardRadarV1Get Update EquipList err: ", err)
		}
	}

	rsp.Sn = &sn
	rsp.Version = &appVersion
	rsp.AziScanCenter = &aziScanCenter
	rsp.AziScanScope = &aziScanScope
	rsp.EleScanScope = &eleScanScope
	rsp.EleScanCenter = &eleScanCenter
	rsp.FChannel = &fChannel
	rsp.RadarScanRadius = &(getClutterSuppressionResp.Distance)
	rsp.FilterLevel = &(getClutterSuppressionResp.Param)
	rsp.Longitude = &(postureInfo.Longitude)
	rsp.Latitude = &(postureInfo.Latitude)
	rsp.Altitude = &(postureInfo.Altitude)
	rsp.Heading = &(postureInfo.Heading)
	rsp.Pitching = &(postureInfo.Pitching)
	rsp.Rolling = &(postureInfo.Rolling)
	rsp.VersionType = codec.VersionTypeV1Str
	return nil
}

func (d *Agx) ForwardRadarV2Get(req *client.RadarGetConfigRequest) (*bizproto.RadarC2Config, error) {
	logger.Debugf("-->Into ForwardRadarV2Get req: %v", req)
	radarV2GetConfigRsp := &bizproto.RadarC2Config{}
	sn := req.GetSn()
	var result mavlink.AgxProxyCmdResponse
	cmdLen, reqBuff, err := encodeSlinkV2(sn, msgid.RadarV2GetConfig, nil)
	if err != nil {
		logger.Errorf("ForwardRadarV2Get encodeSlinkV2 err", err)
		return nil, err
	}
	buff := result.Create(sn, req.GetVersionType(), req.GetParentType(), cmdLen, reqBuff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("ForwardRadarV2Get err: ", err)
		return nil, err
	}

	_, ok := WaitTaskMap[msgid.RadarV2GetConfig]
	if !ok {
		WaitTaskMap[msgid.RadarV2GetConfig] = make(map[int]*WaitTaskManager)
	}
	manager := WaitTaskMap[msgid.RadarV2GetConfig][mavlink.AgxMsgInfoForward]
	if !ok {
		manager = NewWaitTaskManager(mavlink.AgxMsgInfoForward, true, 0)
		WaitTaskMap[msgid.RadarV2GetConfig][mavlink.AgxMsgInfoForward] = manager
	}
	resp, err := manager.Wait()
	if err != nil {
		logger.Error("ForwardRadarV2Get manager1.Wait err", err)
		return nil, err
	}
	radarV2GetConfigRsp, ok = resp.(*bizproto.RadarC2Config)
	if !ok {
		return nil, errors.New("ForwardRadarV2Get response err type")
	}
	logger.Debugf("-->Into ForwardRadarV2Get resp: %+v", radarV2GetConfigRsp)
	return radarV2GetConfigRsp, nil
}

func (d *Agx) sendEndDetect(req *client.RadarSetConfigRequest) (*mavlink.RadarEndDetectResponse, error) {
	rsp := &mavlink.RadarEndDetectResponse{}
	endDetectReq := &mavlink.RadarEndDetectRequest{}
	reqBuff := endDetectReq.Create(uint8(common.DEV_RADAR))

	var result mavlink.AgxProxyCmdResponse
	buff := result.Create(req.GetSn(), req.GetVersionType(), req.GetParentType(), uint32(endDetectReq.Size()), reqBuff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("sendEndDetect err: ", err)
		return nil, err
	}

	_, ok := WaitTaskMap[mavlink.RadarIdEndDetect]
	if !ok {
		WaitTaskMap[mavlink.RadarIdEndDetect] = make(map[int]*WaitTaskManager)
	}
	manager := WaitTaskMap[mavlink.RadarIdEndDetect][mavlink.AgxMsgInfoForward]
	if !ok {
		manager = NewWaitTaskManager(mavlink.AgxMsgInfoForward, true, 0)
		WaitTaskMap[mavlink.RadarIdEndDetect][mavlink.AgxMsgInfoForward] = manager
	}
	resp, err := manager.Wait()
	if err != nil {
		logger.Error("sendEndDetect manager.Wait err", err)
		return nil, err
	}
	rsp, ok = resp.(*mavlink.RadarEndDetectResponse)
	if !ok {
		return nil, errors.New("sendEndDetect response err type")
	}
	logger.Debugf("-->Into sendEndDetect resp: %+v", rsp)
	return rsp, nil
}

func (d *Agx) sendStartDetect(req *client.RadarSetConfigRequest) (*mavlink.RadarStartDetectResponse, error) {
	rsp := &mavlink.RadarStartDetectResponse{}
	startDetectReq := &mavlink.RadarStartDetectRequest{}
	reqBuff := startDetectReq.Create(uint8(common.DEV_RADAR))

	var result mavlink.AgxProxyCmdResponse
	buff := result.Create(req.GetSn(), req.GetVersionType(), req.GetParentType(), uint32(startDetectReq.Size()), reqBuff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("sendStartDetect err: ", err)
		return nil, err
	}

	_, ok := WaitTaskMap[mavlink.RadarIdStartDetect]
	if !ok {
		WaitTaskMap[mavlink.RadarIdStartDetect] = make(map[int]*WaitTaskManager)
	}
	manager := WaitTaskMap[mavlink.RadarIdStartDetect][mavlink.AgxMsgInfoForward]
	if !ok {
		manager = NewWaitTaskManager(mavlink.AgxMsgInfoForward, true, 0)
		WaitTaskMap[mavlink.RadarIdStartDetect][mavlink.AgxMsgInfoForward] = manager
	}
	resp, err := manager.Wait()
	if err != nil {
		logger.Error("sendStartDetect manager.Wait err", err)
		return nil, err
	}
	rsp, ok = resp.(*mavlink.RadarStartDetectResponse)
	if !ok {
		return nil, errors.New("sendStartDetect response err type")
	}
	logger.Debugf("-->Into sendStartDetect resp: %+v", rsp)
	return rsp, nil
}

func (d *Agx) sendPostureCalibration(req *client.RadarSetConfigRequest) (*mavlink.PostureCalibrationResponse, error) {
	rsp := &mavlink.PostureCalibrationResponse{}
	postureCalibrationReq := &mavlink.PostureCalibrationRequest{}
	reqBuff := postureCalibrationReq.Create()
	var result mavlink.AgxProxyCmdResponse
	buff := result.Create(req.GetSn(), req.GetVersionType(), req.GetParentType(), uint32(postureCalibrationReq.Size()), reqBuff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("sendPostureCalibration err: ", err)
		return nil, err
	}

	_, ok := WaitTaskMap[mavlink.RadarIdPostureCalibration]
	if !ok {
		WaitTaskMap[mavlink.RadarIdPostureCalibration] = make(map[int]*WaitTaskManager)
	}
	manager := WaitTaskMap[mavlink.RadarIdPostureCalibration][mavlink.AgxMsgInfoForward]
	if !ok {
		manager = NewWaitTaskManager(mavlink.AgxMsgInfoForward, true, 0)
		WaitTaskMap[mavlink.RadarIdPostureCalibration][mavlink.AgxMsgInfoForward] = manager
	}
	resp, err := manager.Wait()
	if err != nil {
		logger.Error("sendPostureCalibration manager.Wait err", err)
		return nil, err
	}
	rsp, ok = resp.(*mavlink.PostureCalibrationResponse)
	if !ok {
		return nil, errors.New("sendPostureCalibration response err type")
	}
	logger.Debugf("-->Into sendPostureCalibration resp: %+v", rsp)
	return rsp, nil
}

func (d *Agx) sendSetClutterSuppression(req *client.RadarSetConfigRequest) (*mavlink.RadarSetClutterSuppressionResponse, error) {
	rsp := &mavlink.RadarSetClutterSuppressionResponse{}
	setClutterSuppressionReq := &mavlink.RadarSetClutterSuppressionRequest{}
	reqBuff := setClutterSuppressionReq.Create(uint8(common.DEV_RADAR), req.GetRadarScanRadius(), req.GetFilterLevel(), 1)

	var result mavlink.AgxProxyCmdResponse
	buff := result.Create(req.GetSn(), req.GetVersionType(), req.GetParentType(), uint32(setClutterSuppressionReq.Size()), reqBuff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("sendSetClutterSuppression err: ", err)
		return nil, err
	}

	_, ok := WaitTaskMap[mavlink.RadarIdSetClutterSuppression]
	if !ok {
		WaitTaskMap[mavlink.RadarIdSetClutterSuppression] = make(map[int]*WaitTaskManager)
	}
	manager := WaitTaskMap[mavlink.RadarIdSetClutterSuppression][mavlink.AgxMsgInfoForward]
	if !ok {
		manager = NewWaitTaskManager(mavlink.AgxMsgInfoForward, true, 0)
		WaitTaskMap[mavlink.RadarIdSetClutterSuppression][mavlink.AgxMsgInfoForward] = manager
	}
	resp, err := manager.Wait()
	if err != nil {
		logger.Error("sendSetClutterSuppression manager.Wait err", err)
		return nil, err
	}
	rsp, ok = resp.(*mavlink.RadarSetClutterSuppressionResponse)
	if !ok {
		return nil, errors.New("sendSetClutterSuppression response err type")
	}
	logger.Debugf("-->Into sendSetClutterSuppression resp: %+v", rsp)
	return rsp, nil
}

func (d *Agx) sendSetBeamConfig(req *client.RadarSetConfigRequest) (*mavlink.RadarSetBeamPosResponse, error) {
	rsp := &mavlink.RadarSetBeamPosResponse{}
	setBeamSizeReq := &mavlink.RadarSetBeamSizeRequest{}
	reqBuff := setBeamSizeReq.Create(uint8(common.DEV_RADAR), int8(req.GetEleScanCenter()), int8(req.GetAziScanCenter()), uint8(req.GetEleScanScope()), uint8(req.GetAziScanScope()), uint8(req.GetFChannel()))

	var result mavlink.AgxProxyCmdResponse
	buff := result.Create(req.GetSn(), req.GetVersionType(), req.GetParentType(), uint32(setBeamSizeReq.Size()), reqBuff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("sendSetBeamConfig err: ", err)
		return nil, err
	}

	_, ok := WaitTaskMap[mavlink.RadarIdSetBeamSize]
	if !ok {
		WaitTaskMap[mavlink.RadarIdSetBeamSize] = make(map[int]*WaitTaskManager)
	}
	manager := WaitTaskMap[mavlink.RadarIdSetBeamSize][mavlink.AgxMsgInfoForward]
	if !ok {
		manager = NewWaitTaskManager(mavlink.AgxMsgInfoForward, true, 0)
		WaitTaskMap[mavlink.RadarIdSetBeamSize][mavlink.AgxMsgInfoForward] = manager
	}
	resp, err := manager.Wait()
	if err != nil {
		logger.Error("sendSetBeamConfig manager.Wait err", err)
		return nil, err
	}
	rsp, ok = resp.(*mavlink.RadarSetBeamPosResponse)
	if !ok {
		return nil, errors.New("sendSetBeamConfig response err type")
	}
	logger.Debugf("-->Into sendSetBeamConfig resp: %+v", rsp)
	return rsp, nil

}

func (d *Agx) sendSetPostureCalibrationManual(req *client.RadarSetConfigRequest) (*mavlink.PostureCalibrationManualResponse, error) {
	rsp := &mavlink.PostureCalibrationManualResponse{}
	//手动标定姿态
	//正反转换
	heading := RotateSizeTransfer(req.Heading)
	logger.Infof("sendSetPostureCalibrationManual RotateSizeTransfer heading before: %v, after: %v", req.Heading, heading)
	postureCalibrationManualReq := &mavlink.PostureCalibrationManualRequest{
		ULongitude: int32(req.GetLongitude() * RadarPostureReduce20),
		ULatitude:  int32(req.GetLatitude() * RadarPostureReduce20),
		UAltitude:  int32(req.GetAltitude() * RadarPostureReduce),
		UHeading:   int32((*heading) * RadarPostureReduce),
		UPitching:  int32(req.GetPitching() * RadarPostureReduce),
		URolling:   int32(req.GetRolling() * RadarPostureReduce),
	}
	reqBuff := postureCalibrationManualReq.Create()
	var result mavlink.AgxProxyCmdResponse
	buff := result.Create(req.GetSn(), req.GetVersionType(), req.GetParentType(), uint32(postureCalibrationManualReq.Size()), reqBuff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("sendSetPostureCalibrationManual err: ", err)
		return nil, err
	}

	_, ok := WaitTaskMap[mavlink.RadarIdPostureCalibrationManual]
	if !ok {
		WaitTaskMap[mavlink.RadarIdPostureCalibrationManual] = make(map[int]*WaitTaskManager)
	}
	manager := WaitTaskMap[mavlink.RadarIdPostureCalibrationManual][mavlink.AgxMsgInfoForward]
	if !ok {
		manager = NewWaitTaskManager(mavlink.AgxMsgInfoForward, true, 0)
		WaitTaskMap[mavlink.RadarIdPostureCalibrationManual][mavlink.AgxMsgInfoForward] = manager
	}
	resp, err := manager.Wait()
	if err != nil {
		logger.Error("sendSetPostureCalibrationManual manager.Wait err", err)
		return nil, err
	}
	rsp, ok = resp.(*mavlink.PostureCalibrationManualResponse)
	if !ok {
		return nil, errors.New("sendSetPostureCalibrationManual response err type")
	}
	logger.Debugf("-->Into sendSetPostureCalibrationManual resp: %+v", rsp)
	return rsp, nil
}

// 构造mavlink包
func encodeSlinkV2(sn string, msgId uint16, req interface{}) (uint32, []byte, error) {
	// 编码请求
	reqBodyBuff, err := codec.Marshal(codec.SerializationTypePB, req)
	if err != nil {
		logger.Errorf("encodeSlinkV2 req encode err %v", err)
		return 0, nil, err
	}
	// 构造mavlink包
	seq := idgenerator.SeqInstance().GetSeq(sn)
	header := slinkv2.NewMavHeader(
		slinkv2.WithSn(sn),
		slinkv2.WithProtoType(uint8(common.ProtoTypeProto)),
		slinkv2.WithSourceID(uint8(common.DEV_C2_WIFI)),
		slinkv2.WithSeq(uint32(seq)),
		slinkv2.WithMsgID(msgId),
		slinkv2.WithDestID(uint8(common.DEV_RADAR)),
		slinkv2.WithLen(uint16(len(reqBodyBuff))))
	packet := &slinkv2.PacketV2{
		Header:  *header,
		PayLoad: reqBodyBuff,
	}
	cmdLen := packet.Len()
	slinkBuff, err := slinkv2.Encode(packet)
	return cmdLen, slinkBuff, err
}

// ReceiveAgxInfoForward 消息转发命令，agx转发C2和子设备之间的协议帧包
func (d *Agx) ReceiveAgxInfoForward() {
	logger.Debug("-->Into AgxInfoForward")
	devSn := d.getSn()
	d.updateStatus(devSn)
	res := &mavlink.AgxProxyCmdResponse{}
	if err := res.DecodeProxyCmdResponse(d.Msg[mavlink.HeaderLen:]); err != nil {
		logger.Error("ReceiveAgxInfoForward DecodeProxyCmdResponse err: ", err)
		return
	}
	sn := ByteToString(res.Sn[:])
	logger.Debug("ReceiveAgxInfoForward sn: ", sn)
	if res.Protocol != 1 && res.Protocol != 2 && res.Protocol != 3 {
		logger.Error("ReceiveAgxInfoForward Protocol err: ", res.Protocol)
		return
	}

	var (
		ip           string
		parentSn     string
		parentType   int
		isIntegrated int32
	)
	equipModel, err := GetEquipBySn(sn)
	name := sn
	if equipModel != nil {
		if equipModel.Name != "" {
			name = equipModel.Name
		}
		if equipModel.Ip != "" {
			ip = equipModel.Ip
		}
	}
	if err == nil {
		parentSn = equipModel.ParentSn
		parentType = equipModel.ParentType
		isIntegrated = equipModel.IsIntegrated
	}

	if res.Protocol == 1 || res.Protocol == 2 {
		field := map[string]interface{}{
			"version_type": res.Protocol,
		}
		if err := NewEquipList().UpdateBySn(sn, field); err != nil {
			logger.Error("ReceiveAgxInfoForward UpdateBySn err: ", err)
		}
	}
	//目前agx转发小雷达和中程雷达消息
	switch res.Protocol {
	case 1:
		//1: 塞防slink-V1协议
		if err := d.handlerSlinkV1(sn, name, ip, parentSn, parentType, isIntegrated, res.Content); err != nil {
			logger.Error("ReceiveAgxInfoForward handlerSlinkV1 err: ", err)
		}
	case 2:
		//2: 塞防slink-V2协议
		if err := d.handleSlinkV2(sn, name, ip, parentSn, parentType, isIntegrated, res.Content); err != nil {
			logger.Error("ReceiveAgxInfoForward handleSlinkV2 err: ", err)
		}
	case 3:
		//3: 中程雷达zlink协议
		//转发中程雷达状态消息
		if err := sendDPH110StateInfo(sn, name, ip, parentSn, parentType, isIntegrated, res.Content); err != nil {
			logger.Error("ReceiveAgxInfoForward sendDPH110StateInfo err: ", err)
			return
		}
	default:
		logger.Error("ReceiveAgxInfoForward not support protocol: ", res.Protocol)
		return
	}
}

func (d *Agx) handlerSlinkV1(sn, name, ip, parentSn string, parentType int, isIntegrated int32, buff []byte) error {
	if slinkv1.IsSlinkV1(buff) {
		packets, _, err := slinkv1.ParseMavlinkBuff(buff)
		if err != nil {
			logger.Error("handlerSlinkV1 ParseMavlinkBuff err", err)
			return err
		}
		for _, packet := range packets {
			switch packet.GetMsgID() {
			// 雷达心跳包
			case mavlink.RadarIdHeartbeat:
				heart := &mavlink.RadarHeartbeat{}
				err := codec.Unmarshal(codec.SerializationTypeSlink, packet.PayLoad, heart)
				if err != nil {
					logger.Error("handlerSlinkV1 Unmarshal RadarHeartbeat err", err)
					continue
				}
				reportRadarState(sn, name, ip, parentSn, parentType, isIntegrated, heart)
				//雷达姿态
			case mavlink.RadarIdUploadPosture:
				res := &mavlink.RadarUploadPostureInfo{}
				err := codec.Unmarshal(codec.SerializationTypeSlink, packet.PayLoad, res)
				if err != nil {
					logger.Error("handlerSlinkV1 Unmarshal RadarUploadPostureInfo err", err)
					continue
				}
				d.reportRadarPosture(sn, name, parentSn, parentType, isIntegrated, res)
				//手动标定
			case mavlink.RadarIdPostureCalibrationManual:
				res := &mavlink.PostureCalibrationManualResponse{}
				err := codec.Unmarshal(codec.SerializationTypeSlink, packet.PayLoad, res)
				if err != nil {
					logger.Error("handlerSlinkV1 Unmarshal PostureCalibrationManualResponse err", err)
					continue
				}
				manager, ok := WaitTaskMap[mavlink.RadarIdPostureCalibrationManual][mavlink.AgxMsgInfoForward]
				if ok {
					manager.CompletedTask(res, nil)
				}
			case mavlink.RadarIdPostureCalibration:
				res := &mavlink.PostureCalibrationResponse{}
				err := codec.Unmarshal(codec.SerializationTypeSlink, packet.PayLoad, res)
				if err != nil {
					logger.Error("handlerSlinkV1 Unmarshal PostureCalibrationResponse err", err)
					continue
				}
				manager, ok := WaitTaskMap[mavlink.RadarIdPostureCalibration][mavlink.AgxMsgInfoForward]
				if ok {
					manager.CompletedTask(res, nil)
				}
			case mavlink.RadarIdPostureCalibrationResult:
				upload := &mavlink.PostureCalibrationResultResponse{}
				err := codec.Unmarshal(codec.SerializationTypeSlink, packet.PayLoad, upload)
				if err != nil {
					logger.Error("handlerSlinkV1 Unmarshal PostureCalibrationResultResponse err", err)
					continue
				}
				reportPostureCalibrationResult(sn, name, parentSn, parentType, isIntegrated, upload)
			case mavlink.RadarIdStartDetect:
				upload := &mavlink.RadarStartDetectResponse{}
				err := codec.Unmarshal(codec.SerializationTypeSlink, packet.PayLoad, upload)
				if err != nil {
					logger.Error("handlerSlinkV1 Unmarshal RadarStartDetectResponse err", err)
					continue
				}
				manager, ok := WaitTaskMap[mavlink.RadarIdStartDetect][mavlink.AgxMsgInfoForward]
				if ok {
					manager.CompletedTask(upload, nil)
				}
			case mavlink.RadarIdEndDetect:
				upload := &mavlink.RadarEndDetectResponse{}
				err := codec.Unmarshal(codec.SerializationTypeSlink, packet.PayLoad, upload)
				if err != nil {
					logger.Error("handlerSlinkV1 Unmarshal RadarEndDetectResponse err", err)
					continue
				}
				manager, ok := WaitTaskMap[mavlink.RadarIdEndDetect][mavlink.AgxMsgInfoForward]
				if ok {
					manager.CompletedTask(upload, nil)
				}
			case mavlink.RadarIdGetVersionInfo:
				res := &mavlink.GetVersionInfoResponse{}
				err := codec.Unmarshal(codec.SerializationTypeSlink, packet.PayLoad, res)
				if err != nil {
					logger.Error("handlerSlinkV1 Unmarshal GetVersionInfoResponse err", err)
					continue
				}
				manager, ok := WaitTaskMap[mavlink.RadarIdGetVersionInfo][mavlink.AgxMsgInfoForward]
				if ok {
					manager.CompletedTask(res, nil)
				}
			case mavlink.RadarIdGetBeamSteerInfo:
				upload := &mavlink.RadarGetBeamSteerResponse{}
				err := codec.Unmarshal(codec.SerializationTypeSlink, packet.PayLoad, upload)
				if err != nil {
					logger.Error("handlerSlinkV1 Unmarshal RadarGetBeamSteerResponse err", err)
					continue
				}
				manager, ok := WaitTaskMap[mavlink.RadarIdGetBeamSteerInfo][mavlink.AgxMsgInfoForward]
				if ok {
					manager.CompletedTask(upload, nil)
				}
			case mavlink.RadarIdGetClutterSuppression:
				upload := &mavlink.RadarGetClutterSuppressionResponse{}
				err := codec.Unmarshal(codec.SerializationTypeSlink, packet.PayLoad, upload)
				if err != nil {
					logger.Error("handlerSlinkV1 Unmarshal RadarGetClutterSuppressionResponse err", err)
					continue
				}
				manager, ok := WaitTaskMap[mavlink.RadarIdGetClutterSuppression][mavlink.AgxMsgInfoForward]
				if ok {
					manager.CompletedTask(upload, nil)
				}
			case mavlink.RadarIdSetClutterSuppression:
				upload := &mavlink.RadarSetClutterSuppressionResponse{}
				err := codec.Unmarshal(codec.SerializationTypeSlink, packet.PayLoad, upload)
				if err != nil {
					logger.Error("handlerSlinkV1 Unmarshal RadarSetClutterSuppressionResponse err", err)
					continue
				}
				manager, ok := WaitTaskMap[mavlink.RadarIdSetClutterSuppression][mavlink.AgxMsgInfoForward]
				if ok {
					manager.CompletedTask(upload, nil)
				}
			}
		}
	}
	return nil
}

func (d *Agx) handleSlinkV2(sn, name, ip, parentSn string, parentType int, isIntegrated int32, buff []byte) error {
	if slinkv2.IsSlinkV2(buff) {
		packets, _, err := slinkv2.ParseMavlinkBuff(buff)
		if err != nil {
			logger.Error("handleSlinkV2 ParseMavlinkBuff err", err)
			return err
		}
		for _, packet := range packets {
			switch packet.GetMsgID() {
			//雷达状态上报
			case msgid.RadarIdV2State:
				var radarState bizproto.RadarState
				err = codec.Unmarshal(codec.SerializationTypePB, packet.PayLoad, &radarState)
				if err != nil {
					logger.Error("handleSlinkV2 Unmarshal RadarState err", err)
					continue
				}

				reportRadarState(sn, name, ip, parentSn, parentType, isIntegrated, &radarState)
				reportRadarBeamSteer(sn, name, parentSn, parentType, isIntegrated, 0, &radarState)
				d.reportRadarPosture(sn, name, parentSn, parentType, isIntegrated, &radarState)
				//雷达mask上报
			case msgid.RadarIdV2Mask:
				var radarMask bizproto.RadarC2Mask
				err := codec.Unmarshal(codec.SerializationTypePB, packet.PayLoad, &radarMask)
				if err != nil {
					logger.Error("handleSlinkV2 Unmarshal RadarMask err", err)
					continue
				}
				if err = handlerRadarMask(&radarMask); err != nil {
					logger.Errorf("handlerRadarMask handlerRadarMask err: %v", err)
					continue
				}
				//获取雷达配置参数
			case msgid.RadarV2GetConfig:
				var radarGetConfig bizproto.RadarC2Config
				if err := codec.Unmarshal(codec.SerializationTypePB, packet.PayLoad, &radarGetConfig); err != nil {
					logger.Error("handleSlinkV2 Unmarshal RadarC2Config err", err)
					continue
				}

				manager, ok := WaitTaskMap[msgid.RadarV2GetConfig][mavlink.AgxMsgInfoForward]
				if ok {
					manager.CompletedTask(&radarGetConfig, nil)
				}

				//设置雷达配置参数
			case msgid.RadarV2SetConfig:
				var radarSetConfig = &bizproto.RadarC2SetConfigRsp{}
				if err := codec.Unmarshal(codec.SerializationTypePB, packet.PayLoad, radarSetConfig); err != nil {
					logger.Error("handleSlinkV2 Unmarshal RadarC2Config err", err)
					continue
				}
				manager, ok := WaitTaskMap[msgid.RadarV2SetConfig][mavlink.AgxMsgInfoForward]
				if ok {
					manager.CompletedTask(radarSetConfig, nil)
				}

			case msgid.RadarIdV2SetMask:
				var radarSetMask = &bizproto.RadarC2SetMaskRsp{}
				if err := codec.Unmarshal(codec.SerializationTypePB, packet.PayLoad, radarSetMask); err != nil {
					logger.Error("handleSlinkV2 Unmarshal RadarC2Config err", err)
					continue
				}
				manager, ok := WaitTaskMap[msgid.RadarIdV2SetMask][mavlink.AgxMsgInfoForward]
				if ok {
					manager.CompletedTask(radarSetMask, nil)
				}
			case msgid.RadarIdV2GetMask:
				var radarGetMask = &bizproto.RadarC2Mask{}
				if err := codec.Unmarshal(codec.SerializationTypePB, packet.PayLoad, radarGetMask); err != nil {
					logger.Error("handleSlinkV2 Unmarshal RadarC2Config err", err)
					continue
				}
				manager, ok := WaitTaskMap[msgid.RadarIdV2GetMask][mavlink.AgxMsgInfoForward]
				if ok {
					manager.CompletedTask(radarGetMask, nil)
				}
			}
		}
	}
	return nil
}

func reportRadarState(sn, name, ip, parentSn string, parentType int, isIntegrated int32, info interface{}) {
	var (
		electricity int32
		status      int
		sysStatus   int32
		versionType int32
	)
	switch info.(type) {
	case *bizproto.RadarState:
		radarState := info.(*bizproto.RadarState)
		electricity = int32(radarState.GetElectricity())
		status = int(radarState.GetStatus())
		sysStatus = int32(radarState.GetSysStatus())
		versionType = int32(codec.VersionTypeV2)
	case *mavlink.RadarHeartbeat:
		heart := info.(*mavlink.RadarHeartbeat)
		electricity = int32(heart.Electricity)
		status = int(heart.Status)
		// 兼容雷达v2侦测中
		if status == common.RadarV1Detecting {
			sysStatus = common.RadarV2Detecting
		}
		versionType = int32(codec.VersionTypeV1)
	}
	radarHeart := &common.RadarStatusEntity{
		Electricity: electricity,
		Status:      status,
		IsOnline:    common.DevOnline,
		SerialNum:   sn,
		SysStatus:   sysStatus,
		Ip:          ip,
		VersionType: versionType,
	}

	radarHeartMsg := &common.EquipmentMessageBoxEntity{
		Name:         name,
		Sn:           sn,
		EquipType:    int(common.DEV_RADAR),
		MsgType:      mavlink.RadarIdHeartbeat,
		Info:         radarHeart,
		ParentSn:     parentSn,
		ParentType:   parentType,
		IsIntegrated: isIntegrated,
	}

	_ = mq.EquipmentStatusBroker.Publish(mq.EquipmentStatusTopic, broker.NewMessage(radarHeartMsg))
	logger.Infof("radar state has reported, radarHeartMsg: %v", radarHeartMsg)
	return

}

func handlerRadarMask(radarMaskInfo *bizproto.RadarC2Mask) error {
	itemMaskByte, err := jsoniter.Marshal(radarMaskInfo.ItemMask)
	if err != nil {
		logger.Errorf("handlerRadarMask jsoniter.Marshal err: %v", err)
		return err
	}
	isDel := radarMaskInfo.GetAllDelete() == 1
	allDelVal := radarMaskInfo.GetAllDelete()
	if allDelVal == 2 {
		allDelVal = 0
	} else if allDelVal == 3 {
		allDelVal = 1
	}
	//保存数据库
	if err = NewRadarMaskModel().Insert(radarMaskInfo.GetSn(), string(itemMaskByte), isDel, int32(allDelVal)); err != nil {
		logger.Errorf("handlerRadarMask insert radar mask err: %v", err)
		return err
	}
	return nil
}

func (d *Agx) reportRadarPosture(sn, name, parentSn string, parentType int, isIntegrated int32, info interface{}) {
	var (
		heading             float64
		pitching            float64
		rolling             float64
		longitude           float64
		latitude            float64
		altitude            float64
		velocityNavi        float64
		sigProcRelativeTime float64
	)
	switch info.(type) {
	case *bizproto.RadarState:
		radarStateResp := info.(*bizproto.RadarState)
		if radarStateResp.GetAttitude().GetHeading() > HeadingRan {
			logger.Errorf("reportRadarPosture Heading err", radarStateResp)
			return
		}
		// 雷达上报姿态信息
		heading = radarStateResp.GetAttitude().GetHeading()
		pitching = radarStateResp.GetAttitude().GetPitching()
		rolling = radarStateResp.GetAttitude().GetRolling()
		longitude = radarStateResp.GetRadarLLA().GetLongitude()
		latitude = radarStateResp.GetRadarLLA().GetLatitude()
		altitude = radarStateResp.GetRadarLLA().GetAltitude()

	case *mavlink.RadarUploadPostureInfo:
		res := info.(*mavlink.RadarUploadPostureInfo)
		if float64(res.Heading)/RadarPostureReduce > HeadingRan {
			logger.Errorf("reportRadarPosture RadarUploadPostureInfo Heading err: %+v", res)
			return
		}

		head := float64(res.Heading) / RadarPostureReduce
		headingVal := RotateSizeTransfer(&head)
		heading = *headingVal
		pitching = float64(res.Pitching) / RadarPostureReduce
		rolling = float64(res.Rolling) / RadarPostureReduce
		longitude = float64(res.Longitude) / RadarPostureReduce20
		latitude = float64(res.Latitude) / RadarPostureReduce20
		altitude = float64(res.Altitude) / 128.00              //2的7次方
		velocityNavi = float64(res.VelocityNavi) / 128.00      //2的7次方
		sigProcRelativeTime = float64(res.SigProcRelativeTime) // 128.00
	}

	radarPostureMsg := &common.EquipmentMessageBoxEntity{
		Name:         name,
		Sn:           sn,
		EquipType:    int(common.DEV_RADAR),
		MsgType:      mavlink.RadarIdUploadPosture,
		ParentType:   parentType,
		ParentSn:     parentSn,
		IsIntegrated: isIntegrated,
		Info: common.RadarUploadPostureEntity{
			Heading:             heading,
			Pitching:            pitching,
			Rolling:             rolling,
			Longitude:           longitude,
			Latitude:            latitude,
			Altitude:            altitude,
			VelocityNavi:        velocityNavi,
			SigProcRelativeTime: sigProcRelativeTime,
		},
	}

	_ = mq.RadarPostureBroker.Publish(mq.RadarPostureTopic, broker.NewMessage(radarPostureMsg))
	logger.Infof("reportRadarPosture has reported, report:%+v", radarPostureMsg)

	//雷达T5不会主动上报 beamSteer配置，第一次上报姿态信息时，上报波束角度配置
	_, ok := firstReportBeamSteerMap.Load(sn)
	if !ok {
		firstReportBeamSteerMap.Store(sn, true)
		//1: 塞防alink-V1协议
		d.getBeamSteerConfig(sn, parentSn, 1, int32(parentType))
	}
}

func reportRadarBeamSteer(sn, name, parentSn string, parentType int, isIntegrated, radarScanRadius int32, info interface{}) {
	var (
		aziScanCenter float32
		aziScanScope  float32
		eleScanCenter float32
		eleScanScope  float32
		scanRadius    int32
	)
	switch info.(type) {
	case *bizproto.RadarState:
		radarStateResp := info.(*bizproto.RadarState)
		aziScanCenter = radarStateResp.GetAziScanCenter()
		aziScanScope = radarStateResp.GetAziScanScope()
		eleScanScope = radarStateResp.GetEleScanScope()
		eleScanCenter = radarStateResp.GetEleScanCenter()
		scanRadius = helper.TranBaseType[int32, uint32](radarStateResp.GetRadarScanRadius())
	case *mavlink.RadarGetBeamSteerResponse:
		config := info.(*mavlink.RadarGetBeamSteerResponse)
		if config == nil {
			if radarBeamCfg, err := NewRadarBeamCfg().First(); err == nil {
				aziScanCenter = float32(radarBeamCfg.AziScanCenter)
				aziScanScope = float32(radarBeamCfg.AziScanScope)
				eleScanCenter = float32(radarBeamCfg.EleScanCenter)
				eleScanScope = float32(radarBeamCfg.EleScanScope)
			}
		} else {
			aziScanCenter = helper.TranBaseType[float32, int8](config.AziScanCenter)
			aziScanScope = helper.TranBaseType[float32, uint8](config.AziScanScope)
			eleScanCenter = helper.TranBaseType[float32, int8](config.EleScanCenter)
			eleScanScope = helper.TranBaseType[float32, uint8](config.EleScanScope)
		}
		if aziScanScope == 0 {
			aziScanScope = 88
		}
		if eleScanScope == 0 {
			eleScanScope = 40
		}
		scanRadius = radarScanRadius
	}

	radarBeamSteerCfg := &client.RadarBeamSteerConfig{
		Header: &client.EquipmentMessageBoxEntity{
			Name:         name,
			Sn:           sn,
			EquipType:    int32(common.DEV_RADAR),
			MsgType:      mavlink.RadarIdGetBeamSteerInfo,
			ParentSn:     parentSn,
			ParentType:   int32(parentType),
			IsIntegrated: isIntegrated,
		},
		Data: &client.RadarUploadBeamConfigEntity{
			AziScanCenter:   &aziScanCenter,
			AziScanScope:    &aziScanScope,
			EleScanCenter:   &eleScanCenter,
			EleScanScope:    &eleScanScope,
			RadarScanRadius: &scanRadius,
		},
	}

	radarBeamSteerMsg, err := proto.Marshal(radarBeamSteerCfg)
	if err != nil {
		logger.Errorf("reportRadarBeamSteer marshal radarBeamSteerCfg err: %v", err)
	} else {
		radarBeamSteerReport := &client.ClientReport{
			MsgType: common.ClientMsgIDRadarBeamConfigData,
			Data:    radarBeamSteerMsg,
		}
		out, err := proto.Marshal(radarBeamSteerReport)
		if err != nil {
			logger.Errorf("reportRadarBeamSteer marshal radarBeamSteerReport err: %v", err)
		} else {
			_ = mq.RadarBeamConfigBroker.Publish(mq.RadarBeamConfigTopic, broker.NewMessage(out))
			logger.Infof("reportRadarBeamSteer has reported, report:%+v", radarBeamSteerCfg)
		}
	}
}

func reportPostureCalibrationResult(sn, name, parentSn string, parentType int, isIntegrated int32, upload *mavlink.PostureCalibrationResultResponse) {
	entity := common.EquipmentMessageBoxEntity{
		Name:         name,
		Sn:           sn,
		MsgType:      mavlink.RadarIdPostureCalibrationResult,
		EquipType:    int(common.DEV_RADAR),
		ParentSn:     parentSn,
		ParentType:   parentType,
		IsIntegrated: isIntegrated,
		Info: common.RadarUploadPostureEntity{
			Heading:   float64(upload.UHeading) / RadarPostureReduce,
			Pitching:  float64(upload.UPitching) / RadarPostureReduce,
			Rolling:   float64(upload.URolling) / RadarPostureReduce,
			Longitude: float64(upload.ULongitude) / RadarPostureReduce,
			Latitude:  float64(upload.ULatitude) / RadarPostureReduce,
			Altitude:  float64(upload.UAltitude) / RadarPostureReduce,
		},
	}
	_ = mq.EquipMessageBoxBroker.Publish(mq.EquipMessageBoxTopic, broker.NewMessage(entity))
	logger.Infof("PostureCalibration result has reported, entity: %+v", entity)
}

func trimStringSpace(strArr []byte) string {
	tmp := make([]byte, 0)
	for _, v := range strArr {
		if v == 0x00 {
			break
		}
		tmp = append(tmp, v)
	}
	return string(tmp)
}
func (d *Agx) getBeamSteerConfig(sn, parentSn string, protocol, devType int32) (*mavlink.RadarGetBeamSteerResponse, error) {
	var (
		parentType   int
		isIntegrated int32
	)
	equipModel, err := GetEquipBySn(sn)
	name := sn
	if equipModel != nil {
		if equipModel.Name != "" {
			name = equipModel.Name
		}
	}
	if err == nil {
		parentSn = equipModel.ParentSn
		parentType = equipModel.ParentType
		isIntegrated = equipModel.IsIntegrated
	}
	req := &mavlink.RadarGetBeamSteerRequest{}
	reqBuff := req.CreateGetBeamSteer(uint8(common.DEV_RADAR))
	var result mavlink.AgxProxyCmdResponse
	buff := result.Create(sn, protocol, devType, uint32(req.Size()), reqBuff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("getBeamSteerConfig err: ", err)
		return nil, err
	}

	_, ok := WaitTaskMap[mavlink.RadarIdGetBeamSteerInfo]
	if !ok {
		WaitTaskMap[mavlink.RadarIdGetBeamSteerInfo] = make(map[int]*WaitTaskManager)
	}
	manager := WaitTaskMap[mavlink.RadarIdGetBeamSteerInfo][mavlink.AgxMsgInfoForward]
	if !ok {
		manager = NewWaitTaskManager(mavlink.AgxMsgInfoForward, true, 0)
		WaitTaskMap[mavlink.RadarIdGetBeamSteerInfo][mavlink.AgxMsgInfoForward] = manager
	}
	resp, err := manager.Wait()
	if err != nil {
		logger.Error("getBeamSteerConfig manager.Wait err", err)
	}
	//添加重试机制
	retry := 0
	if err != nil {
		for retry < 3 {
			resp, err = d.getBeamSteerConfig(sn, parentSn, protocol, devType)
			if err == nil {
				break
			} else {
				retry++
			}
		}
	}

	if err != nil {
		logger.Error("GetBeamSteerConfig err：", err)
		return nil, err
	}
	var radarScanRadius int32
	getClutterResp, err := d.getClutterSuppression(sn, parentSn, protocol, devType)
	if err == nil {
		radarScanRadius = int32(getClutterResp.Distance)
	}
	if radarScanRadius == 0 {
		radarScanRadius = 1500
	}

	var beerConfig *mavlink.RadarGetBeamSteerResponse
	defer reportRadarBeamSteer(sn, name, parentSn, parentType, isIntegrated, radarScanRadius, beerConfig)

	beerConfig, ok = resp.(*mavlink.RadarGetBeamSteerResponse)
	if ok && beerConfig != nil {
		//更新 radar_beam_config 表
		radarBeamCfg := &bean.RadarBeamConfig{
			AziScanScope:  helper.TranBaseType[float64, uint8](beerConfig.AziScanScope),
			AziScanCenter: helper.TranBaseType[float64, int8](beerConfig.AziScanCenter),
			EleScanCenter: helper.TranBaseType[float64, int8](beerConfig.EleScanCenter),
			EleScanScope:  helper.TranBaseType[float64, uint8](beerConfig.EleScanScope),
			ScanRadius:    radarScanRadius,
		}
		if err := NewRadarBeamCfg().Update(radarBeamCfg); err != nil {
			logger.Error("getBeamSteerConfig Update err：", err)
		}
	}
	logger.Debugf("-->Into getBeamSteerConfig resp: %+v", beerConfig)
	return beerConfig, nil
}

func (d *Agx) getClutterSuppression(sn, parentSn string, protocol, devType int32) (*mavlink.RadarGetClutterSuppressionResponse, error) {
	req := &mavlink.RadarGetClutterSuppressionRequest{}
	reqBuff := req.Create(uint8(common.DEV_RADAR))
	var result mavlink.AgxProxyCmdResponse
	buff := result.Create(sn, protocol, devType, uint32(req.Size()), reqBuff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("getClutterSuppression err: ", err)
		return nil, err
	}

	_, ok := WaitTaskMap[mavlink.RadarIdGetClutterSuppression]
	if !ok {
		WaitTaskMap[mavlink.RadarIdGetClutterSuppression] = make(map[int]*WaitTaskManager)
	}
	manager := WaitTaskMap[mavlink.RadarIdGetClutterSuppression][mavlink.AgxMsgInfoForward]
	if !ok {
		manager = NewWaitTaskManager(mavlink.AgxMsgInfoForward, true, 0)
		WaitTaskMap[mavlink.RadarIdGetClutterSuppression][mavlink.AgxMsgInfoForward] = manager
	}
	resp, err := manager.Wait()
	if err != nil {
		logger.Error("getClutterSuppression manager.Wait err", err)
	}
	//添加重试机制
	retry := 0
	if err != nil {
		for retry < 3 {
			resp, err = d.getClutterSuppression(sn, parentSn, protocol, devType)
			if err == nil {
				break
			} else {
				retry++
			}
		}
	}
	if err != nil {
		logger.Error("getClutterSuppression err：", err)
		return nil, err
	}
	res, ok := resp.(*mavlink.RadarGetClutterSuppressionResponse)
	if !ok {
		return nil, errors.New("getClutterSuppression RadarGetClutterSuppressionResponse err type")
	}
	logger.Infof("---End Send Get ClutterSuppression: %+v", res)
	return res, nil
}

func (d *Agx) getVersionInfo(sn, parentSn string, protocol, devType int32) (*mavlink.GetVersionInfoResponse, error) {
	getVersionReq := &mavlink.GetVersionInfoRequest{}
	versionBuff := getVersionReq.Create()
	var result mavlink.AgxProxyCmdResponse
	buff := result.Create(sn, protocol, devType, uint32(getVersionReq.Size()), versionBuff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("getVersionInfo err: ", err)
		return nil, err
	}

	_, ok := WaitTaskMap[mavlink.RadarIdGetVersionInfo]
	if !ok {
		WaitTaskMap[mavlink.RadarIdGetVersionInfo] = make(map[int]*WaitTaskManager)
	}
	manager := WaitTaskMap[mavlink.RadarIdGetVersionInfo][mavlink.AgxMsgInfoForward]
	if !ok {
		manager = NewWaitTaskManager(mavlink.AgxMsgInfoForward, true, 0)
		WaitTaskMap[mavlink.RadarIdGetVersionInfo][mavlink.AgxMsgInfoForward] = manager
	}
	resp, err := manager.Wait()
	if err != nil {
		logger.Error("getVersionInfo manager.Wait err", err)
		return nil, err
	}
	getVersionRsp, ok := resp.(*mavlink.GetVersionInfoResponse)
	if !ok {
		return nil, errors.New("getVersionInfo GetVersionInfoResponse err type")
	}
	logger.Debugf("-->Into getVersionInfo resp: %+v", getVersionRsp)
	return getVersionRsp, nil
}

//func sendDPH110StateInfo(msg []byte) error {
//	addr, err := net.ResolveUDPAddr("udp", fmt.Sprintf("%s:%d", config.GetGlobalConfig().Server.C2110Ip, config.GetGlobalConfig().Server.C2110Port))
//	if err != nil {
//		logger.Error("sendDPH110StateInfo ResolveUDPAddr err: ", err)
//		return err
//	}
//	conn, err := net.DialUDP("udp", nil, addr)
//	if err != nil {
//		logger.Error("sendDPH110StateInfo DialUDP err: ", err)
//		return err
//	}
//	defer conn.Close()
//	n, err := conn.Write(msg)
//	logger.Debugf("sendDPH110StateInfo Write %d bytes success", n)
//	return err
//}

// 直接往udp连接中写消息，会出现与雷视地址冲突的问题
func sendDPH110StateInfo(sn, name, ip, parentSn string, parentType int, isIntegrated int32, msg []byte) error {
	data, err := Decode(msg)
	if err != nil {
		logger.Errorf("sendDPH110StateInfo Decode error: %v", err)
		return err
	}
	logger.Debugf("sendDPH110StateInfo receive data: %+v", data)
	buffer := &bytes.Buffer{}
	if err = binary.Write(buffer, binary.LittleEndian, data.payload); err != nil {
		logger.Errorf("sendDPH110StateInfo binary.Write error: %v", err)
		return err
	}

	switch data.MsgId {
	case mavlink.StatusMsgType:
		stateInfo := DPHStateInfo{}

		if err = binary.Read(buffer, binary.LittleEndian, &stateInfo); err != nil {
			logger.Errorf("sendDPH110StateInfo binary.Read error: %v", err)
			return err
		}
		logger.Debugf("sendDPH110StateInfo: %+v", stateInfo)
		err = reportDph110StateInfo(sn, name, ip, parentSn, parentType, isIntegrated, &stateInfo)
		if err != nil {
			logger.Error("sendDPH110StateInfo reportDph110StateInfo err: %v", err)
			return err
		}
	}
	return nil
}

// 中程雷达状态上报
func reportDph110StateInfo(sn, name, ip, parentSn string, parentType int, isIntegrated int32, stateInfo *DPHStateInfo) error {
	isOnline := helper.TranBaseType[int32, int](common.DevOnline)
	heartInfo := &client.RadarStatusInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:         name,
			Sn:           sn,
			EquipType:    int32(common.DEV_DPH110),
			MsgType:      mavlink.StatusMsgType,
			ParentSn:     parentSn,
			ParentType:   int32(parentType),
			IsIntegrated: isIntegrated,
		},
		Data: &client.RadarStatusEntity{
			IsOnline:   &isOnline,
			SerialNum:  sn,
			SysStatus:  int32(stateInfo.SysStatus[0]),
			DphVersion: string(stateInfo.Version[:]),
			Ip:         ip,
		},
	}
	buData, err := proto.Marshal(heartInfo)
	if err != nil {
		logger.Error("reportDph110StateInfo Marshal err %v", err)
		return err
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIDDPH110HeartBeat,
		Data:    buData,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Errorf("reportDph110StateInfo ClientReport Marshal err %v", err)
		return err
	}
	_ = mq.DPH110Broker.Publish(mq.DPH110Topic, broker.NewMessage(out))
	logger.Debugf("reportDph110StateInfo DPH110 status report: %+v", heartInfo)
	//雷达姿态信息上报
	go reportDPHPosture(sn, name, parentSn, parentType, isIntegrated)
	return nil
}

// 中程雷视姿态上报
func reportDPHPosture(sn, name, parentSn string, parentType int, isIntegrated int32) error {
	dphConfigModel, err := dphGetConfig(sn)
	if err != nil || dphConfigModel == nil {
		logger.Errorf("reportDPHPosture dphGetConfig error: %v", err)
		return err
	}
	postureInfo := &client.RadarPosture{
		Header: &client.EquipmentMessageBoxEntity{
			Name:         name,
			Sn:           sn,
			EquipType:    int32(common.DEV_DPH110),
			MsgType:      common.ClientMsgIDDPH110Posture,
			ParentSn:     parentSn,
			ParentType:   int32(parentType),
			IsIntegrated: isIntegrated,
		},
		Data: &client.RadarUploadPostureEntity{
			Heading:   &(dphConfigModel.Heading),
			Pitching:  &(dphConfigModel.Pitching),
			Rolling:   &(dphConfigModel.Rolling),
			Longitude: &(dphConfigModel.Longitude),
			Latitude:  &(dphConfigModel.Latitude),
			Altitude:  &(dphConfigModel.Altitude),
		},
	}

	buData, err := proto.Marshal(postureInfo)
	if err != nil {
		logger.Error("reportDPHPosture postureInfo Marshal err %v", err)
		return err
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIDDPH110Posture,
		Data:    buData,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Errorf("reportDPHPosture ClientReport Marshal err %v", err)
		return err
	}
	_ = mq.DPH110Broker.Publish(mq.DPH110Topic, broker.NewMessage(out))
	logger.Infof("reportDPHPosture posture has reported, devSn: %+v,report:%+v", sn, postureInfo)
	return nil
}

func (d *Agx) setDevice(sn string) {
	equipModel, err := GetEquipBySn(sn)
	d.Name = sn
	if err == nil {
		if equipModel != nil && equipModel.Name != "" {
			d.Name = equipModel.Name
		}
		d.IsIntegrated = equipModel.IsIntegrated
		if equipModel.ParentSn != "" {
			d.ParentSn = equipModel.ParentSn
			d.ParentType = int32(equipModel.ParentType)
		}
	}
}

// 激光->激光雷视->C2
func (d *Agx) ReceiveSbp100Proxy() {
	data := &mavlink.ProxySbp100{}
	err := data.Decode(d.Msg[mavlink.HeaderLen : len(d.Msg)-mavlink.CrcLen])
	if err != nil {
		logger.Error("ReceiveSbp100Proxy Decode err: ", err)
		return
	}
	laserSn := fmt.Sprintf("%d_%d_%d_%d", data.IP[0], data.IP[1], data.IP[2], data.IP[3])
	d.LaserSn = laserSn
	LaserSn = laserSn
	d.updateStatus(d.getSn())
	d.DecodeBph110Frame(laserSn, data.LaserData)
}

func (d *Agx) DecodeBph110Frame(laserSn string, data []byte) {
	logger.Debugf("DecodeBph110Frame laserSn: %s, data: %v", laserSn, string(data))
	if len(data) == 0 {
		logger.Error("DecodeBph110Frame data is empty", laserSn)
		return
	}
	msg := make(map[string]any)
	err := json.Unmarshal(data, &msg)
	if err != nil {
		logger.Error("DecodeBph110Frame Unmarshal err: ", err)
		return
	}
	for key, _ := range msg {
		switch key {
		case "Online":
		//BroadcastOnline 设备上电后广播消息
		case "DevInfo":
		//BroadcastDevInfo
		case "InitParams":
		//HandShake
		case "CatchResult":
			//激光捕获跟瞄结果上报
			d.ReceiveCatchResult(laserSn, data)
		case "TrackResult":
			//激光跟踪跟瞄结果上报
			d.ReceiveTrackResult(laserSn, data)
		case "Rotary":
			//激光转台角度信息
			d.ReceiveRotary(laserSn, data)
		case "States":
			//激光系统状态信息上报
			d.ReceiveSbp100States(laserSn, data)
		case "SetOperationParams":
		//CommandSetOperationParams
		case "Control":
			//C2下发操控指令
		}
	}
}

// ReceiveSbp100States 激光系统状态信息上报
func (d *Agx) ReceiveSbp100States(laserSn string, data []byte) {
	logger.Info("--->Into Receive Sbp100 States")
	reportStates := mavlink.ReportStates{}
	err := reportStates.Decode(data)
	if err != nil {
		logger.Error("ReceiveSbp100States Decode err: ", err)
		return
	}
	sbp100Sn := d.getSn()
	if sbp100Sn != "" && reportStates.States != nil {
		States[laserSn] = reportStates.States
		d.reportSbp100States(sbp100Sn, laserSn, reportStates.States)
	}
	logger.Infof("--->End Receive Sbp100 States sn: %s, reportStates: %+v", sbp100Sn, reportStates)
}

func (d *Agx) reportSbp100States(sbp100Sn, laserSn string, info *mavlink.States) {
	data := slink2WebSbp100HeartInfo(info)
	if data.LightStatus != nil {
		if data.LightStatus.LightIndicatorStatus == 4 {
			count++
		} else {
			count = 0
			LightStartTime = time.Time{}
		}
	}

	if count == 1 {
		LightStartTime = time.Now()
	}
	if LightStartTime.Second() > 0 && data.SwitchLight == 1 {
		data.LightDuration = int32(time.Now().Sub(LightStartTime).Milliseconds())
	}

	dataInfo := &client.Sbp100InfoReport{
		Header: &client.EquipmentMessageBoxEntity{
			Name:         laserSn,
			Sn:           laserSn,
			EquipType:    int32(common.DEV_LASER),
			MsgType:      mavlink.Sbp100ReportStates,
			ParentSn:     sbp100Sn,
			ParentType:   int32(common.DEV_SBP100),
			IsIntegrated: 0,
		},
		Indicator: data,
	}

	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("reportSbp100States marshal dataInfo err:", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIDSBP100Heart,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("reportSbp100States marshal report err:", err)
		return
	}
	_ = mq.Sbp100Broker.Publish(mq.Sbp100Topic, broker.NewMessage(out))
	logger.Infof("Sbp100 State has reported, report: %v", dataInfo)
}

func checkBit(n uint32, pos uint) bool {
	return (n & (1 << pos)) != 0
}

func slink2WebSbp100HeartInfo(info *mavlink.States) *client.IndicatorStatus {
	status := &client.IndicatorStatus{
		LightStatus:    &client.IndicatorLight{},
		TargetDistance: 0,
		SwitchRange:    0,
		SwitchStatus:   0,
		SwitchLight:    0,
		LightDuration:  0,
		Online:         0, //收到激光上报状态，代表设备在线
	}

	var laserFlag bool
	//主光继电器开关状态
	if info.LaserPowerFlag != nil && *info.LaserPowerFlag == true {
		status.LightStatus.LaserPowerStatus = 1
		laserFlag = true
	}

	if info.ATPPowerFlag != nil && *info.ATPPowerFlag == true {
		// ATP 继电器开关状态
		status.LightStatus.ATPPowerStatus = 1
		if laserFlag {
			// 对应UI一键开关状态
			status.SwitchStatus = 1
		}
		if info.SystemInitFlag != nil && info.SystemDevOnline != nil {
			systemInitFlag := uint32(*info.SystemInitFlag)
			systemDevOnline := uint32(*info.SystemDevOnline)
			laserState := uint32(*info.LaserState)

			// 激光状态判断
			{
				if checkBit(systemDevOnline, 2) {
					status.LightStatus.MainLaserStatus = 2
				} else {
					status.LightStatus.MainLaserStatus = 3
				}

				if checkBit(systemInitFlag, 2) && checkBit(systemDevOnline, 2) {
					status.LightStatus.MainLaserStatus = 1
				} else {
					status.LightStatus.MainLaserStatus = 3
				}

				if checkBit(laserState, 0) {
					status.LightStatus.MainLaserStatus = 4
				}

				if checkBit(laserState, 1) {
					status.LightStatus.MainLaserStatus = 3
				}
			}

			// 照明状态判断
			{
				if checkBit(systemDevOnline, 3) {
					status.LightStatus.LaserIlluminatorStatus = 2
				} else {
					status.LightStatus.LaserIlluminatorStatus = 3
				}

				if checkBit(systemInitFlag, 3) && checkBit(systemDevOnline, 3) {
					status.LightStatus.LaserIlluminatorStatus = 1
				} else {
					status.LightStatus.LaserIlluminatorStatus = 3
				}

				if checkBit(laserState, 4) {
					status.LightStatus.LaserIlluminatorStatus = 4
				}

				if checkBit(laserState, 5) {
					status.LightStatus.LaserIlluminatorStatus = 3
				}
			}

			// 转台状态
			{
				if checkBit(systemInitFlag, 4) {
					status.LightStatus.TurntableStatus = 1
				} else {
					status.LightStatus.TurntableStatus = 3
				}
			}

			// 捕获状态
			{
				if checkBit(systemDevOnline, 1) {
					status.LightStatus.CatchStatus = 2
				} else {
					status.LightStatus.CatchStatus = 3
				}

				if checkBit(systemInitFlag, 1) && checkBit(systemDevOnline, 1) {
					status.LightStatus.CatchStatus = 1
				} else {
					status.LightStatus.CatchStatus = 3
				}
			}

			// 跟踪状态
			{
				if checkBit(systemInitFlag, 0) {
					status.LightStatus.TrackStatus = 1
				} else {
					status.LightStatus.TrackStatus = 3
				}
			}

			// 出光状态判断
			// 1-系统初始化正常（橙色）2-通信正常（黄色） 3-异常（红色） 4-运行中（绿色，主激光器：黄色）
			{
				if checkBit(systemDevOnline, 2) {
					status.LightStatus.LightIndicatorStatus = 2
				} else {
					status.LightStatus.LightIndicatorStatus = 3
				}

				if checkBit(systemInitFlag, 2) && checkBit(systemDevOnline, 2) {
					status.LightStatus.LightIndicatorStatus = 1
				} else {
					status.LightStatus.LightIndicatorStatus = 3
				}

				if checkBit(laserState, 0) {
					status.LightStatus.LightIndicatorStatus = 4
				}

				if checkBit(laserState, 1) {
					status.LightStatus.LightIndicatorStatus = 3
				}
			}
		}
	}

	// 功率大于零 && 照明标志位为1
	if info.LightPower != nil && *info.LightPower > 0 && info.LaserState != nil && checkBit(uint32(*info.LaserState), 4) {
		status.SwitchLight = 1
	} else {
		status.SwitchLight = 2
	}

	if info.TargetDistance != nil && *info.TargetDistance > 0 {
		status.SwitchRange = 1
		status.TargetDistance = int32(*info.TargetDistance)
	} else {
		status.SwitchRange = 2
	}
	return status
}

// ReceiveCatchResult 激光捕获跟瞄结果上报
func (d *Agx) ReceiveCatchResult(laserSn string, data []byte) {
	res := mavlink.ReportCatchResult{}
	err := res.Decode(data)
	if err != nil {
		logger.Error("ReceiveCatchResult Decode err: ", err)
		return
	}
	sbp100Sn := d.getSn()
	logger.Debugf("ReceiveCatchResult result: %+v, Sbp100Sn: %s", res, sbp100Sn)
	if sbp100Sn != "" {
		d.reportCatchResult(sbp100Sn, laserSn, res)
	}
}

func (d *Agx) reportCatchResult(sbp100Sn, laserSn string, res mavlink.ReportCatchResult) {
	data := &client.Sbp100CatchResult{
		PosX:   intPointerToInt32(res.CatchResult.PosX),
		PosY:   intPointerToInt32(res.CatchResult.PosY),
		Width:  intPointerToInt32(res.CatchResult.Width),
		Height: intPointerToInt32(res.CatchResult.Height),
		MissX:  intPointerToInt32(res.CatchResult.MissX),
		MissY:  intPointerToInt32(res.CatchResult.MissY),
		ZeroX:  intPointerToInt32(res.CatchResult.ZeroX),
		ZeroY:  intPointerToInt32(res.CatchResult.ZeroY),
	}

	dataInfo := &client.Sbp100CatchResultInfoReport{
		Header: &client.EquipmentMessageBoxEntity{
			Name:         laserSn,
			Sn:           laserSn,
			EquipType:    int32(common.DEV_LASER),
			MsgType:      mavlink.Sbp100ReportCatchResult,
			ParentSn:     sbp100Sn,
			ParentType:   int32(common.DEV_SBP100),
			IsIntegrated: 0,
		},
		Sbp100CatchResult: data,
	}

	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("reportCatchResult Marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgIDSBP100CatchResult,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("reportCatchResult Marshal report err:", err)
		return
	}
	_ = mq.Sbp100Broker.Publish(mq.Sbp100Topic, broker.NewMessage(out))
	logger.Infof("Sbp100 catch result has reported, report:%v", dataInfo)
}

// ReceiveTrackResult 激光跟踪跟瞄结果上报
func (d *Agx) ReceiveTrackResult(laserSn string, data []byte) {
	res := mavlink.ReportTrackResult{}
	err := res.Decode(data)
	if err != nil {
		logger.Error("ReceiveTrackResult Decode err: ", err)
		return
	}
	sbp100Sn := d.getSn()
	logger.Debugf("ReceiveTrackResult result: %+v, devSn: %s", res, sbp100Sn)
	if sbp100Sn != "" {
		d.reportTrackResult(sbp100Sn, laserSn, res)
	}
}

func (d *Agx) reportTrackResult(sbp100Sn, laserSn string, res mavlink.ReportTrackResult) {
	data := &client.Sbp100TrackResult{
		PosX:    intPointerToInt32(res.TrackResult.PosX),
		PosY:    intPointerToInt32(res.TrackResult.PosY),
		Width:   intPointerToInt32(res.TrackResult.Width),
		Height:  intPointerToInt32(res.TrackResult.Height),
		MissX:   intPointerToInt32(res.TrackResult.MissX),
		MissY:   intPointerToInt32(res.TrackResult.MissY),
		ZeroX:   intPointerToInt32(res.TrackResult.ZeroX),
		ZeroY:   intPointerToInt32(res.TrackResult.ZeroY),
		CenterX: intPointerToInt32(res.TrackResult.CenterX),
		CenterY: intPointerToInt32(res.TrackResult.CenterY),
	}

	dataInfo := &client.Sbp100TrackResultInfoReport{
		Header: &client.EquipmentMessageBoxEntity{
			Name:         laserSn,
			Sn:           laserSn,
			EquipType:    int32(common.DEV_LASER),
			MsgType:      mavlink.Sbp100ReportTrackResult,
			ParentSn:     sbp100Sn,
			ParentType:   int32(common.DEV_SBP100),
			IsIntegrated: 0,
		},
		Sbp100TrackResult: data,
	}

	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("reportTrackResult Marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgIDSBP100TrackResult,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("reportTrackResult Marshal report err:", err)
		return
	}

	_ = mq.Sbp100Broker.Publish(mq.Sbp100Topic, broker.NewMessage(out))
	logger.Infof("Sbp100 track result has reported, report:%v", dataInfo)
}

// ReceiveRotary 激光转台角度信息
func (d *Agx) ReceiveRotary(laserSn string, data []byte) {
	res := mavlink.ReportRotary{}
	err := res.Decode(data)
	if err != nil {
		logger.Error("ReceiveRotary Decode err: ", err)
		return
	}
	sbp100Sn := d.getSn()
	logger.Debugf("ReceiveRotary result: %+v, devSn: %s", res, sbp100Sn)
	if sbp100Sn != "" {
		d.reportRotary(sbp100Sn, laserSn, res)
	}
}

func (d *Agx) reportRotary(sbp100Sn, laserSn string, res mavlink.ReportRotary) {
	data := &client.Sbp100Rotary{
		Azimuth: FloatPointerToDouble(res.Rotary.Azimuth),
		Pitch:   FloatPointerToDouble(res.Rotary.Pitch),
	}
	dataInfo := &client.Sbp100RotaryInfoReport{
		Header: &client.EquipmentMessageBoxEntity{
			Name:         laserSn,
			Sn:           laserSn,
			EquipType:    int32(common.DEV_LASER),
			MsgType:      mavlink.Sbp100ReportRotary,
			ParentSn:     sbp100Sn,
			ParentType:   int32(common.DEV_SBP100),
			IsIntegrated: 0,
		},
		Sbp100Rotary: data,
	}

	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("reportRotary Marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgIDSBP100Rotary,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("reportRotary Marshal report err:", err)
		return
	}

	_ = mq.Sbp100Broker.Publish(mq.Sbp100Topic, broker.NewMessage(out))
	logger.Infof("Sbp100 rotary has reported, report:%v", dataInfo)
}

func GetEquipBySn(sn string) (*bean.EquipList, error) {
	//是否是一体化设备，是在心跳消息更新的
	//如果心跳上报晚于其他消息，比如eb，保存缓存会有问题
	equipModel, err := NewEquipList().First(sn)
	if err != nil {
		logger.Error("GetEquipBySn First err", err)
		return nil, err
	}
	return equipModel, nil
}

func intPointerToInt32(i *int) int32 {
	if i == nil {
		return 0
	}
	return int32(*i)
}

func FloatPointerToDouble(i *float64) float64 {
	if i == nil {
		return 0
	}
	return *i
}

// GenerateNamePrefix 根据类别生成无人机名称前缀
func GenerateNamePrefix(classification int) string {
	//0：未识别 Unk，1：无人机 UAV，2：单兵 Human，3：车辆 Vehicle，4：鸟类 Bird，5：直升机 Little Aircraft
	namePrefix := "Unk"
	switch classification {
	case 0:
		namePrefix = "Unk"
	case 1:
		namePrefix = "UAV"
	case 2:
		namePrefix = "Human"
	case 3:
		namePrefix = "Vehicle"
	case 4:
		namePrefix = "Bird"
	case 5:
		namePrefix = "Little Aircraft"
	default:
		logger.Error("Invalid classification:", classification)
	}
	return namePrefix
}

package handler

import (
	"math"
	"sync/atomic"

	"adasgitlab.autel.com/tools/cuav_server/entity/config"

	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"

	"adasgitlab.autel.com/tools/cuav_server/repo/utils"
)

// DroneDistanceProcess 无人机距离处理 对象
type DroneDistanceProcess struct {
	SceneType int32 // 1: Fence Region lon, lat, 2: detect device, 3: c2
}

var GetDroneDistanceProcHandler = utils.SingletonFactory(func(v *DroneDistanceProcess) {
	v.SceneType = 3
})

// WriteToCache 协议数据并写入到本地cache
func (d *DroneDistanceProcess) WriteToCache(sceneType int32) {
	logger.Infof("write scene type: %v", sceneType)
	atomic.StoreInt32(&d.SceneType, sceneType)
}

const (
	EarthRadius = 6371
)

func DegreeToRadian(val float64) float64 {
	return val * math.Pi / 180
}

// CalculateDistance 返回的是 m
func CalculateDistance(lat1, lng1, lat2, lng2 float64) float64 {
	dLat := DegreeToRadian(lat2 - lat1)
	dLng := DegreeToRadian(lng2 - lng1)
	lat1Radian := DegreeToRadian(lat1)
	lat2Radian := DegreeToRadian(lat2)

	a := math.Pow(math.Sin(dLat/2), 2) + math.Pow(math.Sin(dLng/2), 2)*math.Cos(lat1Radian)*math.Cos(lat2Radian)
	c := 2 * math.Atan2(math.Sqrt(a), math.Sqrt(1-a))

	distance := EarthRadius * c
	return distance * 1000
}

// CalcDistance 从本地缓存获取数据, 成功后销毁
func (d *DroneDistanceProcess) CalcDistance(lon, lat float64) (distance float64, err error) {
	cfg, exist := C2Config.Get("c2config")
	if !exist || cfg.C2Longitude <= 0 || cfg.C2Latitude <= 0 {
		logger.Errorf("not exist c2config cache, load from db")

		var model bean.SystemConfig
		err := db.GetDB().Model(&bean.SystemConfig{}).First(&model).Error
		if err != nil {
			logger.Errorf("query system config failed,err:%v", err)
			return 0.0, err
		}
		cfg = config.C2ConfigStr{
			Id:            int64(model.Id),
			Longitude:     model.Longitude, //围栏区经度
			Latitude:      model.Latitude,  //围栏区纬度
			Heading:       int64(model.Heading),
			WarningRadius: model.WarningRadius,
			CounterRadius: model.CounterRadius,
			FenceRadius:   model.FenceRadius,
			ScannerRadius: model.ScannerRadius,
			Height:        model.Height,
			C2Longitude:   model.C2Longitude,
			C2Latitude:    model.C2Latitude,
		}
	}

	if lon == 0 {
		lon = cfg.C2Longitude
	}
	if lat == 0 {
		lat = cfg.C2Latitude
	}
	sceneType := atomic.LoadInt32(&d.SceneType)
	referenceLon, referenceLat := float64(0.0), float64(0.0)

	if sceneType == 1 {
		referenceLon, referenceLat = cfg.Longitude, cfg.Latitude
	} else {
		referenceLon, referenceLat = cfg.C2Longitude, cfg.C2Latitude
	}

	ret := CalculateDistance(referenceLat, referenceLon, lat, lon)
	logger.Infof("sceneType: %v, calc distance: %v, lat1: %v, lon1: %v, lat2: %v, lon2: %v",
		sceneType, ret, referenceLat, referenceLon, lat, lon)
	return ret, nil
}

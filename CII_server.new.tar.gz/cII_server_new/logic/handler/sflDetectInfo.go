package handler

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"context"
	"errors"
	"fmt"

	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
)

type SflDetectInfo struct {
}

func NewSflDetectInfo() *SflDetectInfo {
	return &SflDetectInfo{}
}
func (w *SflDetectInfo) Insert(ctx context.Context, req *client.SflDetectInfoInsertReq, res *client.SflDetectInfoInsertRes) error {
	var model bean.SflDetectInfo
	model.Sn = req.Sn
	model.Vendor = req.Vendor
	model.Direction = req.Direction
	model.CounterTime = req.CounterTime
	model.HitTime = req.HitTime
	model.Freq = float64(req.Freq)
	model.DetectTime = req.DetectTime
	model.PilotLongLat = req.PilotLongLat
	model.DroneHeight = req.DroneHeight
	model.UDirStatus = req.UDirStatus
	model.DevType = req.DevType

	logger.Info("Into Insert Sfl Detect Info")
	if err := db.GetDB().Model(&bean.SflDetectInfo{}).Create(&model).Error; err != nil {
		logger.Errorf("create Sfl Detect Info error: %v", err)
		return err
	}
	return nil
}
func (w *SflDetectInfo) UpdateHitTime(ctx context.Context, req *client.SflDetectInfoUpdateReq, rsp *client.SflDetectInfoUpdateRes) error {
	var model bean.SflDetectInfo
	model.HitTime = req.HitTime

	r := db.GetDB().Debug().Model(&bean.SflDetectInfo{}).Where("id=(?)",
		db.GetDB().Model(&bean.SflDetectInfo{}).Select("id").Where("sn=?", req.Sn).Order("detect_time DESC").Limit(1)).
		Update("hit_time", model.HitTime).RowsAffected

	if r == 0 {
		return fmt.Errorf("update Sfl Detect Info error: sn=%v not found", req.Sn)
	}

	return nil
}
func (w *SflDetectInfo) UpdateCountTime(ctx context.Context, req *client.SflDetectInfoUpdateReq, rsp *client.SflDetectInfoUpdateRes) error {
	var model bean.SflDetectInfo
	model.CounterTime = req.CounterTime

	r := db.GetDB().Model(&bean.SflDetectInfo{}).Where("sn=?", req.Sn).
		Order("detect_time DESC").Limit(1).
		Updates(&model).RowsAffected

	if r == 0 {
		return fmt.Errorf("update Sfl Detect Info error: sn=%v not found", req.Sn)
	}

	return nil
}

func (w *SflDetectInfo) Delete(ctx context.Context, req *client.SflDetectInfoDeleteReq, rsp *client.SflDetectInfoDeleteRes) error {
	//var model bean.DateMarkers
	//
	//err := db.GetDB().Model(&bean.DateMarkers{}).Where("time_stamp = ?", req.Timestamp).Delete(&model).Error
	//if err != nil {
	//	logger.Errorf("delete Date Markers error: %v", err)
	//}

	return nil
}

func (w *SflDetectInfo) List(ctx context.Context, req *client.SflDetectInfoListReq, rsp *client.SflDetectInfoListRes) error {
	var list []*bean.SflDetectInfo
	err := db.GetDB().Model(&bean.SflDetectInfo{}).Where("detect_time >= ? and detect_time <= ?", req.StartTime, req.StopTime).Find(&list).Error
	if err != nil {
		return errors.New("query list failed")
	}
	for _, v := range list {
		var model client.SflDetectInfoList
		w.generateRes(&model, *v)
		rsp.Sfllist = append(rsp.Sfllist, &model)
	}
	return nil
}
func (w *SflDetectInfo) generateRes(model *client.SflDetectInfoList, list bean.SflDetectInfo) {
	model.Id = list.Id
	model.Vendor = list.Vendor
	model.PilotLongLat = list.PilotLongLat
	model.Sn = list.Sn
	model.Freq = float32(list.Freq)
	model.DetectTime = list.DetectTime
	model.HitTime = list.HitTime
	model.CounterTime = list.CounterTime
	model.Direction = list.Direction
	model.DroneHeight = list.DroneHeight
	model.UDirStatus = list.UDirStatus
	model.DevType = list.DevType
}

func (w *SflDetectInfo) ListLike(ctx context.Context, req *client.SflDetectInfoListLikeReq, rsp *client.SflDetectInfoListLikeRes) error {
	var list []*bean.SflDetectInfo
	err := db.GetDB().Model(&bean.SflDetectInfo{}).
		Where("detect_time >= ? AND detect_time <= ?", req.StartTime, req.StopTime).
		Where("sn LIKE ? OR vendor LIKE ? OR pilot_long_lat LIKE ?", "%"+req.FindKey+"%", "%"+req.FindKey+"%", "%"+req.FindKey+"%").
		Find(&list).Error
	if err != nil {
		return errors.New("query list failed")
	}
	for _, v := range list {
		var model client.SflDetectInfoList
		w.generateRes(&model, *v)
		rsp.Sfllist = append(rsp.Sfllist, &model)
	}
	return nil
}

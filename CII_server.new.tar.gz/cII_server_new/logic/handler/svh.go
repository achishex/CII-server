package handler

import (
	"adasgitlab.autel.com/tools/cuav_plugin/broker"
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/server"
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/ip"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/proto/mavlink"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
	"adasgitlab.autel.com/tools/slink_proto/slinkv1"
	"bytes"
	"context"
	"crypto/rand"
	"encoding/binary"
	"errors"
	"fmt"
	"google.golang.org/protobuf/proto"
	"math/big"
	"sync"
	"time"
)

type Svh struct {
	*Device
	dt common.DeviceType
}

const (
	SvhTcpPort        = 30500
	SvhServerMaxCount = 500
)

var (
	SvhTcpServerLock sync.Mutex
	SvhTcpServerMap  sync.Map
	SvhHeartSum      uint8
)

func (d *Svh) Deal() {
	defer func() {
		if err := recover(); err != nil {
			logger.Error("Svh deal 接收到panic:", err)
		}
	}()

	if d.MsgLen <= 0 {
		logger.Error("Svh 数据为null,不作处理:", d.Device.RemoteIp)
		return
	}
	d.MsgId = int(d.Msg[mavlink.MsgIdLoc])
	switch d.MsgId {
	case mavlink.SVHHeartMsg:
		d.Heart()
	case mavlink.SVHGetFreqConfig:
		d.ReceiveSvhGetFreqConfig()
	case mavlink.SVHSetFreqConfig:
		d.ReceiveSvhSetFreqConfig()
	case mavlink.SVHStartStopHit:
		d.ReceiveSvhStartStopHit()
	case mavlink.SVHAddDelFreqConfig:
		d.ReceiveSvhAddDelFreqConfig()
	case mavlink.SVHResetFreqConfig:
		d.ReceiveSvhResetFreqConfig()
	case mavlink.SVHGetVersion:
		d.ReceiveSvhGetVersion()
	default:
		logger.Error("Svh 未知Svh消息id:", d.MsgId)
		break
	}
}
func (d *Svh) getSn(sourceId uint8) string {
	if sn, ok := DevSnMap.Load(d.ServerPort); ok {
		return sn.(string)
	}
	return ""
}

// Heart 处理Svh心跳消息
func (d *Svh) Heart() {
	heart := &mavlink.SvhHeart{}
	if err := d.UnmarshalPayloadSvhHeart(heart); err != nil {
		logger.Errorf(err.Error())
		return
	}

	devSn := d.getSn(d.Msg[mavlink.SenderLoc])
	if devSn != "" {
		// update device status
		//d.updateOnLineStatus(devSn, heart)
		d.updateStatus(devSn, 0)
		//if isEnable := d.updateStatus(devSn); isEnable == common.DeviceDisenable {
		//	logger.Infof("Svh device %v disable", devSn)
		//	return
		//}
		// report heartbeat
		d.HeartReport(devSn, heart)
	}
}

func (d *Svh) UnmarshalPayloadSvhHeart(data *mavlink.SvhHeart) error {
	deviceInfoLen := binary.Size(mavlink.SvhHeartInfo{})
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}

	start := mavlink.HeaderLen + deviceInfoLen
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializeDrone(d.Msg[start:end]); err != nil {
		return err
	}

	return nil
}
func (d *Svh) HeartReport(devSn string, heartInfo *mavlink.SvhHeart) {

	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	heartList := make([]*client.SvhHeartList, 0)
	for _, description := range heartInfo.Description {
		heartList = append(heartList, &client.SvhHeartList{
			PaNo:      description.PaNo,
			ErrorCode: description.ErrorCode,
			Current:   description.Current,
			Watt:      description.Watt,
		})
	}
	dataInfo := &client.SvhHeartInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        devSn,
			EquipType: int32(common.DEV_SVH),
			MsgType:   mavlink.SVHHeartMsg,
		},
		Data: &client.SvhHeartInfoData{
			Sn:            devSn,
			ConnectStatus: heartInfo.Info.ConnectStatus,
			HitStatus:     heartInfo.Info.HitStatus,
			FaultStatus:   heartInfo.Info.FaultStatus,
			Electricity:   heartInfo.Info.Electricity,
			Temperature:   heartInfo.Info.Temperature,
			FanSpeed:      heartInfo.Info.FanSpeed,
			Electricity2:  heartInfo.Info.Electricity2,
			PaNum:         heartInfo.Info.PaNum,
			IsOnline:      common.DevOnline,
			HeartList:     heartList,
			IPaFlag:       heartInfo.Info.IPaFlag,
		},
	}
	if err == nil {
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgId_SVHHeartBeat,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.SvhMsgBroker.Publish(mq.SvhTopic, broker.NewMessage(out))

	logger.Infof("Svh heartbeat has reported, devSn:%v,report:%v", devSn, dataInfo.Data)
}

// HandleBroadCast 处理广播消息
func (d *Svh) HandleBroadCast(ctx context.Context, req *slinkv1.UdpBroadcastConfirmRequest) (*slinkv1.UdpBroadcastConfirmResponse, error) {

	if req.GetSn() == "" {
		logger.Info("device sn empty")
		return nil, errors.New("device sn empty")
	}
	d.GetStatus(req.GetSn(), int(req.DeviceType))
	logger.Debug("req.DeviceType = ", req.DeviceType)

	localIP := make([]string, 0)
	localIps, broadIps, err := ip.GetBroadcastAddress()
	if err != nil {
		logger.Error("Get IP error :%v", err)
	}
	for i, ip := range localIps {
		if i >= len(broadIps) {
			continue
		}
		localIP = append(localIP, ip)
	}
	logger.Debugf("[Svh] localIP:%v,", localIP)

	tcpServer := d.TcpServerCheck(req.GetSn(), localIP, uint8(req.DeviceType))
	DevSnMap.Store(tcpServer.Port, req.GetSn())
	d.ServerPort = tcpServer.Port
	var tempSn [32]byte
	for i, v := range []byte(req.GetSn()) {
		tempSn[i] = v
	}
	//响应
	rsp := &slinkv1.UdpBroadcastConfirmResponse{
		Sn:       tempSn,
		Addr:     ip.IPV4(tcpServer.Ip),
		Port:     uint16(tcpServer.Port),
		ConnType: 1,
	}
	return rsp, nil
}

func (d *Svh) TcpServerCheck(devSn string, localIP []string, devType uint8) *server.TcpServer {
	var tcpServer *server.TcpServer
	if s, ok := SvhTcpServerMap.Load(devSn); ok {
		tcpServer = s.(*server.TcpServer)
		isAlike := false
		for _, ip := range localIP {
			if ip == tcpServer.Ip {
				isAlike = true
			}
		}
		if isAlike == false { //查找的本地IP没有与之前相同的
			if tcpServer != nil {
				tcpServer.Stop()
			}
			deviceUsedPorts.Delete(tcpServer.Port)
			SvhTcpServerMap.Delete(devSn)
			DevSnMap.Delete(tcpServer.Port)
			tcpServer = nil
		}
	}

	//注册tcp服务
	if tcpServer == nil {
		port, err := ip.GetFreeTcpPort()
		if err != nil {
			logger.Error("Svh tcp 获取可用端口失败：", err)
			port = d.getRandPort(SvhTcpPort, SvhTcpPort+SvhServerMaxCount)
		}
		tcpServer = server.NewTcpServer(port, Handle)
		SvhTcpServerMap.Store(devSn, tcpServer)
		tcpServer.ServerType = uint8(common.DEV_SVH)
		tcpServer.ServerType = devType
		tcpServer.ServerName = devSn
		localAddr, _ := ip.GetLocalIp(d.UdpIp)
		tcpServer.Ip = localAddr
		go tcpServer.Start()
	}
	return tcpServer
}

func (d *Svh) getRandPort(min, max int64) int {
	maxBigInt := big.NewInt(max)
	i, _ := rand.Int(rand.Reader, maxBigInt)
	_, ok := deviceUsedPorts.Load(i.Int64())
	port := i.Int64()
	//缓存不存在或者符合范围
	if !ok && (port > min && port < max) {
		deviceUsedPorts.Store(port, port)
		return int(port)
	}
	return d.getRandPort(min, max)
}
func NewSvh(conn Connection, d []byte, dataLen int, remoteIp string, remotePort int, localIp string, serverPort int,
	mailBox map[int]*WaitTaskManager, dlimit *devLimit) DeviceInterface {
	svh := &Svh{
		Device: &Device{
			Conn:        conn,
			Msg:         d,
			MsgLen:      dataLen,
			SourceId:    d[mavlink.SenderLoc],
			RemoteIp:    remoteIp,
			RemotePort:  remotePort,
			LocalIp:     localIp,
			ServerPort:  serverPort,
			WaitTaskMap: mailBox,
		},
	}
	return svh
}

func SendSvhHeart() {
	ticker := time.NewTicker(time.Second * 1)
	defer ticker.Stop()
	for range ticker.C {
		DevStatusMap.Range(func(key, value interface{}) bool {
			dev := value.(*Device)
			if dev.DevType == common.DEV_SVH && dev.Status == common.DevOnline {
				reqMode := &Svh{
					Device: dev,
					dt:     common.DEV_SVH,
				}
				reqMode.SendExtHeartbeat()
			}
			return true
		})
	}
}
func (d *Svh) SendExtHeartbeat() error {
	SvhHeartSum++
	if SvhHeartSum > 255 {
		SvhHeartSum = 0
	}
	req := &mavlink.SvhHeartbeatExtRequest{
		SvhHeartSum,
	}
	reqBuff := req.CreateSvhHeartbeatExt()
	if d != nil && d.Conn != nil {
		_, err := d.Conn.Write(reqBuff)
		logger.Infof("Svh c2发送心跳结果：%X", reqBuff)
		if err != nil {
			equipModel, err := GetEquipBySn(d.Sn)
			name := d.Sn
			if equipModel != nil && equipModel.Name != "" {
				name = equipModel.Name
			}
			dataInfo := &client.SvhHeartInfo{
				Header: &client.EquipmentMessageBoxEntity{
					Name:      name,
					Sn:        d.Sn,
					EquipType: int32(common.DEV_SVH),
					MsgType:   mavlink.SVHHeartMsg,
				},
				Data: &client.SvhHeartInfoData{
					Sn:       d.Sn,
					IsOnline: common.DevOffline,
				},
			}
			if err == nil {
				dataInfo.Header.ParentType = int32(equipModel.ParentType)
				dataInfo.Header.ParentSn = equipModel.ParentSn
				dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
			}
			msg, err := proto.Marshal(dataInfo)
			if err != nil {
				logger.Error("marshal dataInfo err:", err)
				return err
			}
			report := &client.ClientReport{
				MsgType: common.ClientMsgId_SVHHeartBeat,
				Data:    msg,
			}
			out, err := proto.Marshal(report)
			if err != nil {
				logger.Error("marshal report err:", err)
				return err
			}
			_ = mq.SvhMsgBroker.Publish(mq.SvhTopic, broker.NewMessage(out))
			logger.Info("Svh Offline report:", report)
		}
		return err
	}
	return nil
}
func (d *Svh) updateStatus(sn string, subDevType int) int32 {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_SVH, sn)
	if cache, ok := DevStatusMap.Load(cacheKey); ok {
		dev := cache.(*Device)
		dev.Status = common.DevOnline
		dev.Conn = d.Conn
		dev.WaitTaskMap = d.WaitTaskMap
		dev.RemoteIp = d.RemoteIp
		dev.LastHeartTime = time.Now()
		dev.GetStatusInterval = time.Now()
		d.GetStatus(sn, subDevType)
		return common.DeviceEnable
	} else {
		dev := &Device{
			Sn:                sn,
			Conn:              d.Conn,
			Status:            common.DevOnline,
			RemoteIp:          d.RemoteIp,
			RemotePort:        d.RemotePort,
			LocalIp:           d.LocalIp,
			ServerPort:        d.ServerPort,
			DevType:           common.DEV_SVH,
			FirstHeartTime:    time.Now(),
			LastHeartTime:     time.Now(),
			SourceId:          d.SourceId,
			IsEnable:          d.GetStatus(sn, subDevType),
			GetStatusInterval: time.Now(),
			WaitTaskMap:       d.WaitTaskMap,
		}
		DevStatusMap.Store(cacheKey, dev)
		go func() {
			time.Sleep(time.Second * 2)
			e := NewEquipList().Update(context.Background(), &client.EquipCrudReq{
				Sn: sn,
				Ip: d.RemoteIp,
			}, &client.EquipCrudRes{})
			logger.Infof("update dev ip: %v, e: %v", d.RemoteIp, e)
		}()
		return dev.IsEnable
	}
}

func (d *Svh) GetStatus(sn string, subDevType int) int32 {
	statusRes := &client.GetStatusRes{}
	err := NewEquipList().GetStatus(context.Background(), &client.GetStatusReq{Sn: sn, EType: "SVH", SubDevType: int64(subDevType)}, statusRes)
	if err != nil {
		logger.Errorf("GetStatus err: %v", err.Error())
		return 0
	}

	return statusRes.IsEnable
}
func (d *Svh) updateOnLineStatus(sn string, heartInfo *mavlink.SvhHeart) int32 {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_SVH, sn)
	if cache, ok := DevStatusMapOnEvent.Load(cacheKey); ok {
		dev := cache.(*Device)
		//if dev.IsEnable == common.DeviceDisenable {
		//	return common.DeviceDisenable
		//}
		dev.Status = common.DevOnline
		dev.LastHeartTime = time.Now()
		dev.GetStatusInterval = time.Now()
		return common.DeviceEnable
	}

	dev := &Device{
		Sn:                sn,
		Status:            common.DevOnline,
		RemoteIp:          d.RemoteIp,
		RemotePort:        d.RemotePort,
		LocalIp:           d.LocalIp,
		ServerPort:        d.ServerPort,
		DevType:           common.DEV_SVH,
		FirstHeartTime:    time.Now(),
		LastHeartTime:     time.Now(),
		SourceId:          d.SourceId,
		IsEnable:          common.DeviceEnable,
		GetStatusInterval: time.Now(),
		SessionId:         GetGlobalSessionId(),
	}
	DevStatusMapOnEvent.Store(cacheKey, dev)
	return common.DeviceEnable

}

// SvhOfflineReport Svh离线处理
func SvhOfflineReport(sn string) {
	var tcpServer *server.TcpServer
	if s, ok := SvhTcpServerMap.Load(sn); ok {
		tcpServer = s.(*server.TcpServer)

		if tcpServer != nil {
			tcpServer.Stop()
		}
		deviceUsedPorts.Delete(tcpServer.Port)
		SvhTcpServerMap.Delete(sn)
		DevSnMap.Delete(tcpServer.Port)
		cachekeyDroneid := fmt.Sprintf("%d_%s", common.DEV_SVH, sn)
		DevStatusMap.Delete(cachekeyDroneid)
		tcpServer = nil
	}

	equipModel, err := GetEquipBySn(sn)
	name := sn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	dataInfo := &client.SvhHeartInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        sn,
			EquipType: int32(common.DEV_SVH),
			MsgType:   mavlink.SVHHeartMsg,
		},
		Data: &client.SvhHeartInfoData{
			Sn:       sn,
			IsOnline: common.DevOffline,
		},
	}
	if err == nil {
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgId_SVHHeartBeat,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}
	_ = mq.SvhMsgBroker.Publish(mq.SvhTopic, broker.NewMessage(out))
	logger.Info("svh Offline report:", report)

}
func (d *Svh) SvhStartStopHit(request *client.StartStopHitRequest, hit, stop int) (int, error) {
	req := mavlink.SvhSetHitFreqRequestAll{}
	freqlist1 := make([]mavlink.SvhHitFreqInfo, 0)
	for _, s1 := range request.ReqData1 {
		freqlist1 = append(freqlist1, mavlink.SvhHitFreqInfo{
			IModulStyle: s1.IModeStyle,
			IScanType:   s1.IScanType,
			IFreqStart:  s1.IFreqStart,
			IFreqStop:   s1.IFreqStop,
			IBwData:     s1.IBwData,
			IFreqStep:   s1.IFreqStep,
			IDelayTime:  s1.IDelayTime,
			IRndPhiDeg:  s1.IRndPhiDeg,
		})
	}
	freqlist2 := make([]mavlink.SvhHitFreqInfo, 0)
	for _, s2 := range request.ReqData2 {
		freqlist1 = append(freqlist2, mavlink.SvhHitFreqInfo{
			IModulStyle: s2.IModeStyle,
			IScanType:   s2.IScanType,
			IFreqStart:  s2.IFreqStart,
			IFreqStop:   s2.IFreqStop,
			IBwData:     s2.IBwData,
			IFreqStep:   s2.IFreqStep,
			IDelayTime:  s2.IDelayTime,
			IRndPhiDeg:  s2.IRndPhiDeg,
		})
	}

	reqInfo := &mavlink.SvhSetHitFreqRequest{
		IStartSw:     uint32(hit),
		IStopSw:      uint32(stop),
		IPAFlag:      request.IPAFlag,
		GroupNum1:    uint32(request.GroupNum1),
		HitFreqList1: freqlist1,
		GroupNum2:    uint32(request.GroupNum2),
		HitFreqList2: freqlist2,
	}
	buff := req.Create(reqInfo)
	logger.Debug("-->Set Hit Auto is :", buff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Svh Hit Auto err: %v", err)
		return Fail, fmt.Errorf("request Svh Hit Auto err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SVHStartStopHit]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SVHStartStopHit, true, 0)
		d.WaitTaskMap[mavlink.SVHStartStopHit] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Svh  Hit Mode err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.SvhSetHitFreqResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Svh Hit Auto result:%+v", *res)

	return int(res.Status), nil
}
func (d *Svh) ReceiveSvhStartStopHit() {
	logger.Info("-->into Receive Svh Start Stop Hit")
	res := &mavlink.SvhSetHitFreqResponse{}
	d.GetPacket(res)
	logger.Debugf("Set Start Stop Hit：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SVHStartStopHit]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Svh) SendSvhGetFreqConfig(request *client.SvhGetFreqConfigRequest) (*client.SvhGetFreqConfigResponse, error) {
	logger.Info("-->into Send Svh SvhGetFreqList msg")
	req := &mavlink.SvhGetFreqConfigRequest{}
	rsp := &client.SvhGetFreqConfigResponse{}
	buff := req.Create()
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("write Svh GetFreqList info err: %v", err)
		return rsp, fmt.Errorf("write Svh GetFreqList info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SVHGetFreqConfig]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SVHGetFreqConfig, true, 0)
		d.WaitTaskMap[mavlink.SVHGetFreqConfig] = manager
	}
	task := manager.AddTask(nil, nil)

	result, err := manager.WaitTask(task)
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Svh GetFreqList info err: %v", checkNetConnErr)
			return rsp, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.SvhGetFreqConfigResponse)
	if !ok {
		return rsp, errors.New("response err type")
	}

	for _, list := range res.FreqList0 {
		rsp.FreqList1 = append(rsp.FreqList1, &client.SvhFreqList{
			IFreqStart:   list.IFreqStart,
			IFreqStop:    list.IFreqStop,
			GroupEnabled: list.GroupEnabled,
		})
	}
	for _, list := range res.FreqList1 {
		rsp.FreqList2 = append(rsp.FreqList2, &client.SvhFreqList{
			IFreqStart:   list.IFreqStart,
			IFreqStop:    list.IFreqStop,
			GroupEnabled: list.GroupEnabled,
		})
	}
	rsp.GroupNum = res.GroupNum0
	rsp.GroupNum2 = res.GroupNum1
	logger.Debug("response Svh GetFreqList result:%+v", rsp)
	return rsp, nil
}

func (d *Svh) UnmarshalPayloadSvhFreqList(data *mavlink.SvhGetFreqConfigResponse) error {
	groupNum0Len := binary.Size(data.GroupNum0)
	buff := &bytes.Buffer{}
	start := mavlink.HeaderLen // begin of index  ch0
	if err := binary.Write(buff, binary.LittleEndian, d.Msg[start:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.GroupNum0); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}

	start += groupNum0Len //begin of index 0 list
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializeFreqList0(d.Msg[start:end]); err != nil {
		return err
	}

	buff = &bytes.Buffer{}
	start += int(data.GroupNum0) * binary.Size(mavlink.GroupFreqList{}) // begin of index ch1
	if err := binary.Write(buff, binary.LittleEndian, d.Msg[start:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.GroupNum1); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}

	groupNum1Len := binary.Size(data.GroupNum1)
	start += groupNum1Len // begin of index 1 list
	if err := data.DeserializeFreqList1(d.Msg[start:end]); err != nil {
		return err
	}
	return nil
}

func (d *Svh) ReceiveSvhGetFreqConfig() {
	logger.Info("-->into Receive Get GetFreqList")
	res := &mavlink.SvhGetFreqConfigResponse{}
	if err := d.UnmarshalPayloadSvhFreqList(res); err != nil {
		logger.Errorf(err.Error())
		return
	}
	logger.Debugf("Svh GetFreqList 接收到Svh信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SVHGetFreqConfig]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Svh) SendSvhSetFreqConfig(request *client.SvhSetFreqConfigRequest) (int32, error) {
	req := mavlink.SvhSetFreqConfigRequest{}
	buff := req.Create(request)
	logger.Debug("-->Svh Set Freq Config :", buff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Svh Set Freq Config err: %v", err)
		return Fail, fmt.Errorf("request Svh Set Freq Config err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SVHSetFreqConfig]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SVHSetFreqConfig, true, 0)
		d.WaitTaskMap[mavlink.SVHSetFreqConfig] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Svh Set Freq Config err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.SvhSetFreqConfigResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Svh Set Freq Config result:%+v", *res)

	return int32(res.Status), nil
}
func (d *Svh) ReceiveSvhSetFreqConfig() {
	logger.Info("-->into Receive Svh Set Freq Config")
	res := &mavlink.SvhSetFreqConfigResponse{}
	d.GetPacket(res)
	logger.Debugf("Set Angle 接收到Svh 信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SVHSetFreqConfig]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Svh) GetPacket(message mavlink.Message) *mavlink.MavPacket {
	logger.Infof("Svh GetPacket is [% x]", d.Msg)
	req := mavlink.NewNullPacket(message)
	buff := &bytes.Buffer{}
	if err := binary.Write(buff, binary.LittleEndian, d.Msg); err != nil {
		logger.Error("Svh GetPacket write buff err:", err)
		return nil

	}
	if err := binary.Read(buff, binary.LittleEndian, &req.Header); err != nil {
		logger.Error("Svh GetPacket read header err:", err)
		return nil
	}
	if err := binary.Read(buff, binary.LittleEndian, req.Msg); err != nil {
		logger.Error("Svh GetPacket read msg err:", err)
		return nil
	}
	return req
}

func (d *Svh) SendSvhAddDelFreqConfig(request *client.SvhAddDelFreqConfigRequest) (int32, error) {
	logger.Info("Send SvhAddDelFreqConfig request is :%v", request)
	req := mavlink.SvhAddDelFreqConfigRequest{}
	buff := req.Create(request)
	logger.Debug("-->Svh AddDel Freq Config :", buff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Svh AddDel Freq Config err: %v", err)
		return Fail, fmt.Errorf("request Svh AddDel Freq Config err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SVHAddDelFreqConfig]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SVHAddDelFreqConfig, true, 0)
		d.WaitTaskMap[mavlink.SVHAddDelFreqConfig] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Svh AddDel Freq Config err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.SvhAddDelFreqConfigResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Svh AddDel Freq Config result:%+v", *res)

	return int32(res.Status), nil
}
func (d *Svh) ReceiveSvhAddDelFreqConfig() {
	logger.Info("-->into Receive Svh AddDel Freq Config")
	res := &mavlink.SvhAddDelFreqConfigResponse{}
	d.GetPacket(res)
	logger.Debugf("Set Angle 接收到Svh 信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SVHAddDelFreqConfig]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Svh) SendSvhResetFreqConfig(request *client.SvhResetFreqConfigRequest) (int32, error) {
	req := mavlink.SvhResetFreqConfigRequest{}
	buff := req.Create(request)
	logger.Debug("-->Svh Reset Freq Config :", buff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Svh Reset Freq Config err: %v", err)
		return Fail, fmt.Errorf("request Svh Reset Freq Config err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SVHResetFreqConfig]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SVHResetFreqConfig, true, 0)
		d.WaitTaskMap[mavlink.SVHResetFreqConfig] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Svh Reset Freq Config err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.SvhResetFreqConfigResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Svh Reset Freq Config result:%+v", *res)

	return int32(res.Status), nil
}
func (d *Svh) ReceiveSvhResetFreqConfig() {
	logger.Info("-->into Receive Svh Reset Freq Config")
	res := &mavlink.SvhResetFreqConfigResponse{}
	d.GetPacket(res)
	logger.Debugf(" Reset 接收到Svh 信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SVHResetFreqConfig]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// SvhSendUpgradeF1
func (d *Svh) SvhSendUpgradeF1(fileName string, c2Ip string) (int32, error) {
	logger.Info("SvhSendUpgradeF1 Start")

	req := &mavlink.SvhUpdateF1Request{}
	buff := req.Create(fileName, c2Ip)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.SvhIdUpgradeF1]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SvhIdUpgradeF1, true, 0)
		d.WaitTaskMap[mavlink.SvhIdUpgradeF1] = manager
	}
	task := manager.AddTask(nil, nil)
	logger.Debugf("SvhSendUpgradeF1 buff: %02X \n", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("SvhSendUpgradeF1 发送写入固件数据信息失败: ", err)
		return 1, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("SvhSendUpgradeF1 WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 1, checkNetConnErr
		}
		return 1, err
	}
	res := result.(*mavlink.SvhUpdateF1Response)
	logger.Debugf("SvhUpdateF1Response 获取写入固件数据信息结果：%#v", res)
	logger.Info("SvhUpdateF1Response End")
	return int32(res.Status), nil
}

// ReceiveSvhUpdateF1 获取请求固件升级响应
func (d *Svh) ReceiveSvhUpdateF1() {
	res := &mavlink.SvhUpdateF1Response{}
	d.GetPacket(res)
	logger.Debugf("ReceiveSvhUpdateF1 获取请求固件升级响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SvhIdUpgradeF1]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// SvhSendUpgradeF2
func (d *Svh) SvhSendUpgradeF2() (int32, error) {
	logger.Info("SvhSendUpgradeF2 Start")
	req := &mavlink.SvhUpdateF2Request{}
	buff := req.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.SvhIdUpgradeF2]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SvhIdUpgradeF2, true, time.Second*15)
		d.WaitTaskMap[mavlink.SvhIdUpgradeF2] = manager
	}
	task := manager.AddTask(nil, nil)
	logger.Debugf("SvhSendUpgradeF2 buff: %02X \n", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("SvhSendUpgradeF2 发送写入固件数据信息失败: ", err)
		return -1, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("SvhSendUpgradeF2 WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return -1, checkNetConnErr
		}
		return -1, err
	}
	res := result.(*mavlink.SvhUpdateF2Response)
	logger.Debugf("SvhUpdateF2Response 获取写入固件数据信息结果：%#v", res)
	logger.Info("SvhUpdateF2Response End")
	return int32(res.Progress), nil
}

// ReceiveSvhUpdateF2 获取请求固件升级响应
func (d *Svh) ReceiveSvhUpdateF2() {
	res := &mavlink.SvhUpdateF2Response{}
	d.GetPacket(res)
	logger.Debugf("ReceiveSvhUpdateF2 获取请求固件升级响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SvhIdUpgradeF2]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// SvhSendUpgradeF3
func (d *Svh) SvhSendUpgradeF3() (int32, error) {
	logger.Info("SvhSendUpgradeF3 Start")

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.SvhIdUpgradeF3]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SvhIdUpgradeF3, true, time.Second*60)
		d.WaitTaskMap[mavlink.SvhIdUpgradeF3] = manager
	}
	task := manager.AddTask(nil, nil)

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("SvhSendUpgradeF3 WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 1, checkNetConnErr
		}
		return 1, err
	}
	res := result.(*mavlink.SvhUpdateF3Response)
	logger.Debugf("SvhUpdateF3Response 获取写入固件数据信息结果：%#v", res)
	logger.Info("SvhUpdateF3Response End")
	return int32(res.UpgradeResult), nil
}

// ReceiveSvhUpdateF3 获取请求固件升级响应
func (d *Svh) ReceiveSvhUpdateF3() {
	res := &mavlink.SvhUpdateF3Response{}
	d.GetPacket(res)
	logger.Debugf("ReceiveSvhUpdateF3 获取请求固件升级响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SvhIdUpgradeF3]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Svh) SendSvhGetVersionInfo(request *client.SvhGetVersionRequest) (*client.SvhGetVersionResponse, error) {
	req := mavlink.SvhGetVersionRequest{}
	buff := req.Create()
	logger.Debug("-->Svh Get Version Config :", buff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Svh Get Version err: %v", err)
		return nil, fmt.Errorf("request Svh Get Version err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SVHGetVersion]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SVHGetVersion, true, 0)
		d.WaitTaskMap[mavlink.SVHGetVersion] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Svh Get Version  err: %v", checkNetConnErr)
			return nil, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.SvhGetVersionResponse)
	if !ok {
		return nil, errors.New("response err type")
	}
	logger.Debug("response Svh Get Version result:%+v", *res)
	r := &client.SvhGetVersionResponse{}
	r.Company = ByteToString(res.CompanyName[:])
	r.Sn = request.Sn
	r.PsVersion = ByteToString(res.PsVersion[:])
	r.PlVersion = ByteToString(res.PlVersion[:])
	r.Ip = ByteToString(res.DeviceIp[:])
	r.DeviceName = ByteToString(res.DeviceName[:])
	if r.PsVersion != "" {
		err = NewEquipList().Update(context.Background(), &client.EquipCrudReq{
			Sn:         request.Sn,
			DevVersion: r.PsVersion,
		}, &client.EquipCrudRes{})
		if err != nil {
			logger.Error("Update EquipList err: ", err)
		}
	}
	return r, nil
}
func (d *Svh) ReceiveSvhGetVersion() {
	logger.Info("-->into Receive Svh Get Version")
	res := &mavlink.SvhGetVersionResponse{}
	d.GetPacket(res)
	logger.Debugf(" Reset 接收到Svh 信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SVHGetVersion]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

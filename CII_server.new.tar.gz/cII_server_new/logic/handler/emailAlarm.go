package handler

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/config"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
	"context"
	"crypto/tls"
	"encoding/json"
	"errors"
	"fmt"
	"net/smtp"
	"strconv"
	"time"
)

type EmailAlarm struct {
}

func NewEmailAlarm() *EmailAlarm {
	return &EmailAlarm{}
}

type AlarmType struct {
	AlarmSfl100 bool
	AlarmSfl200 bool
	AlarmTracer bool
	AlarmRadar  bool
	AlarmSrp150 bool
	AlarmSrp100 bool
}

const (
	EmailAlarmEnglish = 0
	EmailAlarmChinese = 1
	EmailAlarmRussian = 2
)

func (c *EmailAlarm) UpdateEmailAlarm(ctx context.Context, req *client.EmailAlarmDeviceReq, res *client.EmailAlarmDeviceRes) error {
	logger.Info("update email alarm device,request:", req)
	var alarmType AlarmType
	for _, deviceType := range req.AlarmDevices {
		if common.DeviceType(deviceType.DeviceType) == common.DEV_SFL {
			alarmType.AlarmSfl100 = deviceType.IsSelect
		} else if common.DeviceType(deviceType.DeviceType) == common.DEV_SFL200 {
			alarmType.AlarmSfl200 = deviceType.IsSelect
		} else if common.DeviceType(deviceType.DeviceType) == common.DEV_V2DRONEID {
			alarmType.AlarmTracer = deviceType.IsSelect
		} else if common.DeviceType(deviceType.DeviceType) == common.DEV_RADAR {
			alarmType.AlarmRadar = deviceType.IsSelect
		} else if common.DeviceType(deviceType.DeviceType) == common.DEV_SRP150 {
			alarmType.AlarmSrp150 = deviceType.IsSelect
		} else if common.DeviceType(deviceType.DeviceType) == common.DEV_AGX {
			alarmType.AlarmSrp100 = deviceType.IsSelect
		}
	}
	err := db.GetDB().Model(&bean.EmailAlarm{}).Where("id = 1").
		Updates(map[string]interface{}{
			"is_alarm":     req.IsAlarm,
			"email_switch": req.EmailSwitch,
			"sfl100":       alarmType.AlarmSfl100,
			"language":     req.Language,
			"sfl200":       alarmType.AlarmSfl200,
			"tracer":       alarmType.AlarmTracer,
			"radar":        alarmType.AlarmRadar,
			"srp150":       alarmType.AlarmSrp100,
			"srp100":       alarmType.AlarmSrp150}).Error
	if err != nil {
		logger.Errorf("update failed,error:%v", err)
		return err
	}
	return nil
}

func (c *EmailAlarm) GetEmailAlarmSetting(ctx context.Context, req *client.GetEmailAlarmSettingReq, res *client.GetEmailAlarmSettingRes) error {
	logger.Info("Get email alarm Setting,request:", req)

	var alarmList *bean.EmailAlarm
	err := db.GetDB().Model(&bean.EmailAlarm{}).Find(&alarmList).Error
	if err != nil {
		logger.Error("query alarm email failed,error:", err)
		return errors.New("query alarm email failed")
	}

	list := []*client.AlarmDeviceList{
		{
			IsSelect:   alarmList.Sfl100,
			DeviceType: int32(common.DEV_SFL),
		},
		{
			IsSelect:   alarmList.Sfl200,
			DeviceType: int32(common.DEV_SFL200),
		},
		{
			IsSelect:   alarmList.Tracer,
			DeviceType: int32(common.DEV_V2DRONEID),
		},
		{
			IsSelect:   alarmList.Radar,
			DeviceType: int32(common.DEV_RADAR),
		},
		{
			IsSelect:   alarmList.Srp150,
			DeviceType: int32(common.DEV_SRP150),
		},
		{
			IsSelect:   alarmList.Srp100,
			DeviceType: int32(common.DEV_AGX),
		},
	}
	res.Email = alarmList.Email
	res.IsAlarm = alarmList.IsAlarm
	res.EmailSwitch = alarmList.EmailSwitch
	res.AlarmDevices = list
	logger.Info("Get email alarm Setting,response:", alarmList)
	return nil
}

func (c *EmailAlarm) UpdateEmail(ctx context.Context, req *client.EmailAlarmReq, res *client.EmailAlarmRes) error {
	logger.Info("update email,request:", req)

	err := db.GetDB().Model(&bean.EmailAlarm{}).
		Where("id = 1").Updates(map[string]interface{}{
		"email":    req.Email,
		"language": req.Language,
	}).Error
	if err != nil {
		logger.Errorf("update failed,error:%v", err)
		return err
	}
	return nil
}

type DroneInfo struct {
	Time                 string `json:"Time"`
	DroneModel           string `json:"DroneModel"`
	Distance             string `json:"Distance"`
	DroneLocation        string `json:"DroneLocation"`
	DronePositionMapLink string `json:"DronePositionMapLink"`
	DroneHeight          string `json:"DroneHeight"`
	DroneSpeed           string `json:"DroneSpeed"`
	DroneSn              string `json:"DroneSn"`
	Freq                 string `json:"Freq"`
	PilotLocation        string `json:"PilotLocation"`
	PilotPositionMapLink string `json:"PilotPositionMapLink"`
	DroneSailLocation    string `json:"DroneSailLocation"`
	DetectDeviceName     string `json:"DetectDeviceName"`
}

func SendAlarmEmail(detectInfo *client.GimbalCounterDetectSocketInfo) {
	var alarmList *bean.EmailAlarm
	err := db.GetDB().Model(&bean.EmailAlarm{}).Find(&alarmList).Error
	if err != nil {
		logger.Error("query alarm email failed,error:", err)
		return
	}
	if alarmList.IsAlarm == false || alarmList.EmailSwitch == false || alarmList.Sfl100 == false {
		logger.Info("Alarm email switch is off,isAlarm:", alarmList.IsAlarm, "email switch:", alarmList.EmailSwitch, "sfl100:", alarmList.Sfl100)
		return
	}
	if alarmList.Email == "" {
		logger.Error("alarm email is empty")
		return
	}
	to := alarmList.Email

	logger.Info("Sending Email Alarm")
	// 设置SMTP服务器和端口
	emailConf := config.Global.Email
	host := emailConf.SmtpHost
	port := "465"
	//host := "smtpdm.aliyun.com"
	//port := "465"

	auth := smtp.PlainAuth("", emailConf.Sender, emailConf.Password, host)

	from := emailConf.Sender

	deviceName := detectInfo.Sn
	detectTime := time.Now().Format("2006-01-02 15:04:05")

	info := make([]*DroneInfo, 0)
	for _, droneInfo := range detectInfo.List {
		droneLocation := strconv.FormatFloat(droneInfo.DroneLongitude, 'f', 6, 64) + "," + strconv.FormatFloat(droneInfo.DroneLatitude, 'f', 6, 64)
		pilotLocation := strconv.FormatFloat(droneInfo.PilotLongitude, 'f', 6, 64) + "," + strconv.FormatFloat(droneInfo.PilotLatitude, 'f', 6, 64)
		droneSailLocation := strconv.FormatFloat(droneInfo.DroneSailLongitude, 'f', 6, 64) + "," + strconv.FormatFloat(droneInfo.DroneSailLatitude, 'f', 6, 64)

		droneLocationLink := strconv.FormatFloat(droneInfo.DroneLatitude, 'f', 6, 64) + "," + strconv.FormatFloat(droneInfo.DroneLongitude, 'f', 6, 64)
		pilotLocationLink := strconv.FormatFloat(droneInfo.PilotLatitude, 'f', 6, 64) + "," + strconv.FormatFloat(droneInfo.PilotLongitude, 'f', 6, 64)
		distance := ""
		if droneInfo.UDistance != InvalidValueInt16 {
			distance = strconv.Itoa(int(droneInfo.UDistance)) + "m"
		}
		//https://maps.google.com/?q=LATITUDE-VALUE,LONGITUDE-VALUE
		info = append(info, &DroneInfo{
			Time:                 detectTime,
			DroneModel:           droneInfo.DroneName,
			Distance:             distance,
			DroneLocation:        droneLocation,
			DronePositionMapLink: "https://maps.google.com/?q=" + droneLocationLink,
			DroneHeight:          strconv.FormatFloat(droneInfo.DroneHeight, 'f', 2, 64) + "m",
			DroneSpeed:           strconv.FormatFloat(droneInfo.DroneSpeed, 'f', 2, 64) + "m/s",
			DroneSn:              droneInfo.SerialNum,
			Freq:                 strconv.FormatFloat(droneInfo.UFreq, 'f', 2, 64) + "G",
			PilotLocation:        pilotLocation,
			PilotPositionMapLink: "https://maps.google.com/?q=" + pilotLocationLink,
			DroneSailLocation:    droneSailLocation,
			DetectDeviceName:     deviceName,
		})
	}
	jsonData, err := json.MarshalIndent(info, "", "    ")
	if err != nil {
		logger.Error("Error marshalling to JSON:", err)
		return
	}
	subject := ""
	body := ""
	droneName := detectInfo.List[0].DroneName
	switch alarmList.Language {
	case EmailAlarmEnglish:
		subject = "SkyFendAlert-SFL100-[" + droneName + "]-[" + detectTime + "]"
		body = "Detected drone intrusion alarm, drone information is as follows:\r\n"
	case EmailAlarmChinese:
		subject = "黑飞通知-SFL100-[" + droneName + "]-[" + detectTime + "]"
		body = "侦测到黑飞目标,信息如下:\r\n"
	case EmailAlarmRussian:
		subject = "Тревога--SFL100-[" + droneName + "]-[" + detectTime + "]"
		body = "Вторжение дрона, информация следующая:\r\n"
	}

	// 邮件格式
	message := []byte(fmt.Sprintf("From: %s\r\nTo: %s\r\nSubject: %s\r\n\r\n%s", from, to, subject, jsonData))
	jsonData = []byte(body + "\n" + string(jsonData))

	config := &tls.Config{
		InsecureSkipVerify: true,
	}
	conn, err := tls.Dial("tcp", host+":"+port, config)
	if err != nil {
		logger.Error("Email Alarm Error dialing:", err)
		return
	}

	c, err := smtp.NewClient(conn, host)
	if err != nil {
		logger.Error("Email Alarm Error connecting:", err)
		return
	}
	defer c.Close()

	if err = c.Auth(auth); err != nil {
		logger.Error("Email Alarm Error authenticating:", err)
		return
	}

	if err = c.Mail(from); err != nil {
		logger.Error("Email Alarm Error setting sender:", err)
		return
	}

	if err = c.Rcpt(to); err != nil {
		logger.Error("Email Alarm Error setting recipient:", err)
		return
	}

	w, err := c.Data()
	if err != nil {
		logger.Error("Email Alarm Error getting data:", err)
		return
	}
	if _, err = w.Write(message); err != nil {
		logger.Error("Email Alarm Error writing message:", err)
		return
	}
	if err = w.Close(); err != nil {
		logger.Error("Email Alarm Error closing writer:", err)
		return
	}

	if err = c.Quit(); err != nil {
		logger.Error("Email Alarm Error quitting:", err)
		return
	}
	logger.Info("Email Alarm sent successfully")

}

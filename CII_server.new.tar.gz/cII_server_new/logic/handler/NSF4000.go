package handler

import (
	"bytes"
	"context"
	"fmt"
	"io"
	"net"
	"strconv"
	"strings"
	"time"

	"adasgitlab.autel.com/tools/cuav_plugin/broker"
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"google.golang.org/protobuf/proto"

	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/config"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
	"adasgitlab.autel.com/tools/cuav_server/repo/utils"
)

type selfStatus struct {
	OldVol       int
	OldCurr      int
	NewVol       int
	NewCurr      int
	Status       int //获取到手动自检信息
	OldNewStatus int //是新还是旧状态 2:旧
}

type ControllerNSF4000 struct {
	*Device
	CC                    CheatConfig
	AreaDenial            string
	ActiveDefense         string
	Version               string
	NFSIP                 string
	CurrentBattery        float64 // 电池1当前电量
	IsSupportSelfCheck    bool
	IsFixed               bool
	Name                  string
	StatusTrace           selfStatus
	NFSStartCmd           int64
	Timer                 *time.Timer
	TimerWork             *time.Timer
	PosTempStatus         string
	PosUploadTime         int
	GselfStatus           selfStatus
	NsfCacheQueue         *common.ReportEntity
	NsfTimeSyncCacheQueue *common.ReportEntity
}

var (
	limitRate    int64 = 1000 * 60 * 55 //55分钟
	PosTemp      string
	nsflimitRate int64 = 1000
	NsfPwr       int64 = 0
)

type CheatConfig struct {
	Longititude string
	Latitude    string
	Height      string
}
type NSF4000SendCmdRes struct {
	Status int
}

type NSF4000Msg struct {
	IsOnline           int     `json:"isOnline"`    //1:在线
	IsWorking          int     `json:"isWorking"`   //工作状态： 1：工作中，2：未工作
	GpsStatus          int     `json:"gpsStatus"`   //定位状态 1:已定位  2：未定位
	Ephemeris          int     `json:"ephemeris"`   //星历    1:以获取  2:未获取
	TimeSync           int     `json:"timeSync"`    //时间同步状态  1:已同步  2:未同步
	Longititude        float64 `json:"longititude"` //经度
	Latitude           float64 `json:"latitude"`    //纬度
	Height             float64 `json:"height"`
	Enable             bool    `json:"enable"`         //功能开关 true:开启   false:关闭 默认值false
	WorkMode           int32   `json:"workMode"`       //工作模式 1：主动防御 2：区域拒止 3：定向驱离 默认值1
	Radius             int32   `json:"radius"`         //防御区半径 默认值500
	Angle              int32   `json:"angle"`          //诱导角度  0/90/180/270   0正北，90正东  1  向上  -1向下  默认值0
	OpsTime            int64   `json:"opsTime"`        //记录操作时长，时间单位为秒(enable_true_time - enable_false_time ) 默认值0
	BatteryCap         uint8   `json:"batteryCap"`     //电量百分占比
	B3OrL1             uint8   `json:"b3OrL1"`         //1: B3   2: L1
	CurrentBattery     float64 `json:"currentBattery"` //电池1当前电量
	SubDevType         int64   `json:"subDevType"`
	IsSupportSelfCheck bool    `json:"isSupportSelfCheck"`
	SeflCheckCode      int32   `json:"SeflCheckCode"` //模拟器错误类型码
}

func NewControllerNSF4000(ip string) *ControllerNSF4000 {
	return &ControllerNSF4000{
		Device:        &Device{},
		AreaDenial:    config.AreaDenial,
		ActiveDefense: config.ActiveDefense,
		NFSIP:         ip,
	}
}

func (ctrl *ControllerNSF4000) Handle(conn net.Conn) {
	ctrl.NsfCacheQueue = &common.ReportEntity{ReportTime: time.Now(), LimitRate: nsflimitRate}
	ctrl.NsfTimeSyncCacheQueue = &common.ReportEntity{ReportTime: time.Time{}, LimitRate: limitRate}
	ctx, cancel := context.WithCancel(context.Background())
	defer conn.Close()
	defer cancel()
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	ctrl.Sn = ""
	ctrl.Version = ""

	go ctrl.GetDevSn(ctx)
	sendTime := 0

	go ctrl.GetDevVer()
	go ctrl.SendHeart(ctx)
	go ctrl.GetDevPowerInfo(ctx)
	go ctrl.SendL1B3Mode(ctx)

	go ctrl.GetDevSelfCheckMsg(ctx)

	cache := make([]byte, 0)
	for {
		buf := make([]byte, 1024)
		status := &client.GetStatusRes{}
		subDevType := 0
		if ctrl.NFSIP == "192.168.2.84" {
			subDevType = 1
		}
		if ctrl.NFSIP == "192.168.2.94" {
			subDevType = 2
		}
		err := NewEquipList().GetStatus(context.Background(), &client.GetStatusReq{
			Sn:         ctrl.Sn,
			EType:      "Spoofer",
			SubDevType: int64(subDevType),
		}, status)
		if err != nil {
			logger.Error("NSF 4000 GetStatus err:", err)
			return
		}
		//if status.IsEnable == common.DeviceDisenable {
		//	return
		//}
		// 设置读取操作的截止时间为 6秒后
		err = conn.SetReadDeadline(time.Now().Add(6 * time.Second))
		if err != nil {
			logger.Error(err)
			conn.Close()
			return
		}
		n, err := conn.Read(buf)

		if err != nil {
			// 通常遇到的错误是连接中断或被关闭，用io.EOF表示
			if err == io.EOF {
				logger.Info("conn receive close:", conn.RemoteAddr())
			} else {
				logger.Info("conn receive err:", err)
			}
			//ctrl.ReportStatus(1, 2, 0, 0, 2, config.NSF4000TypeWorking, "", "", "") //给前端发离线消息
			return
		}
		if n <= 0 {
			continue
		}
		if len(PosTemp) != 0 && len(ctrl.PosTempStatus) == 0 {
			ctrl.PosTempStatus = PosTemp
			logger.Debug("first init PosTempStatus = ", ctrl.PosTempStatus)
		}

		// update connection
		ctrl.cacheConn(conn)
		// 将读取到的数据追加到消息缓冲区
		cache = append(cache, buf[:n]...)
		for {
			msgIndex := bytes.IndexByte(cache, '$')
			if msgIndex == -1 {
				// 没有找到消息分隔符，跳出内循环等待更多数据
				break
			}

			if msgIndex > 0 {
				// 处理消息
				msg := string(cache[:msgIndex])
				ms := strings.Split(msg, "\r\n")
				var TimeSync int
				var IsWorking int
				var StarReport int
				var GpsStat int
				for _, e := range ms {
					sg := strings.Split(e, ",")

					if len(sg) <= 1 {
						continue
					}
					logger.Debug("NSF4000 receive msg is :", sg)
					if sg[0] == "RPT" && sg[1] == "ClkDoSta" { //设备上报时钟状态
						strength, err := strconv.Atoi(sg[len(sg)-1])
						logger.Debug("strength = ", strength)

						if ctrl.PosTempStatus != PosTemp {
							ctrl.PosUploadTime++
							logger.Debug("nsf4000,  report,PosTemp = ", PosTemp)
						} else if time.Since(ctrl.NsfTimeSyncCacheQueue.ReportTime).Milliseconds() < ctrl.NsfTimeSyncCacheQueue.LimitRate {
							if err == nil && strength > 11 {
								logger.Debug("nsf4000,clkdo is ok, upload to c2 client", PosTemp, "  strength = ", strength)
							} else {
								logger.Debug("nsf4000, ignore clkdo sta report,PosTemp = ", PosTemp)
								continue
							}

						}

						if err == nil && strength > 11 {
							TimeSync = 1
							//上报设备状态消息
							if ctrl.Sn == "" {
								continue
							} else {
								ctrl.ReportStatus(1, GpsStat, TimeSync, StarReport, IsWorking, config.NSF4000TypeTimeSync, "", "", "", int64(subDevType), ctrl.IsSupportSelfCheck, 1)
								sendTime++
								if sendTime >= 5 {
									ctrl.NsfTimeSyncCacheQueue.ReportTime = time.Now()
									sendTime = 0
								}
								ctrl.PosTempStatus = PosTemp
							}
						} else {
							TimeSync = 2
							//上报设备状态消息
							ctrl.ReportStatus(1, GpsStat, TimeSync, StarReport, IsWorking, config.NSF4000TypeTimeSync, "", "", "", int64(subDevType), ctrl.IsSupportSelfCheck, 1)
						}
					} else if sg[0] == "RPT" && sg[1] == "UbxSynTmInfo" { //设备上报星历状态
						//$RPT UbxSynTmInfo 2023-10-09 17:52:17[|11|9|5|6] 0 0     判断星历后4个数都不为0并且相加大于等于7
						if len(sg) < 5 {
							continue
						}
						tempStr := sg[2]
						index := strings.Index(tempStr, "[")
						lastIndex := strings.Index(tempStr, "]")
						targetStr := tempStr[index+1 : lastIndex]
						targetNum := strings.Split(targetStr, "|")
						start1, _ := strconv.Atoi(targetNum[1])
						start2, _ := strconv.Atoi(targetNum[2])
						start3, _ := strconv.Atoi(targetNum[3])
						start4, _ := strconv.Atoi(targetNum[4])
						if start1 > 0 && start2 > 0 && start3 > 0 && start4 > 0 && start1+start2+start3+start4 >= 7 {
							StarReport = 1
							ctrl.ReportStatus(1, GpsStat, TimeSync, StarReport, IsWorking, config.NSF4000TypeEphemeris, "", "", "", int64(subDevType), ctrl.IsSupportSelfCheck, 1)
						} else {
							StarReport = 2
							ctrl.ReportStatus(1, GpsStat, TimeSync, StarReport, IsWorking, config.NSF4000TypeEphemeris, "", "", "", int64(subDevType), ctrl.IsSupportSelfCheck, 1)
						}

					} else if sg[0] == "RPT" && sg[1] == "FuconPosInfo" { //设备返回的经纬高	//B3	//默认B3
						//$RPT FuconPosInfo 201858 22.5971437 113.9982126 25.909 0.004 0.013 -0.001 0.000 0.000
						GpsStat = 1
						ctrl.CC.Longititude = sg[4]
						ctrl.CC.Latitude = sg[3]
						ctrl.CC.Height = sg[5]
						if PosTemp == "FuconPosInfo" {
							ctrl.ReportStatus(1, GpsStat, TimeSync, StarReport, IsWorking, config.NSF4000TypeLLH, sg[4], sg[3], sg[5], int64(subDevType), ctrl.IsSupportSelfCheck, 1)
							ctrl.ReportStatus(1, GpsStat, TimeSync, StarReport, IsWorking, config.NSF4000TypeGpsStatus, sg[4], sg[3], sg[5], int64(subDevType), ctrl.IsSupportSelfCheck, 1)
						}

					} else if sg[0] == "RPT" && sg[1] == "UbxPosInfo" { //设备返回的经纬高		//L1
						//$RPT UbxPosInfo 201858 22.5971437 113.9982126 25.909 0.004 0.013 -0.001 0.000 0.000
						GpsStat = 1
						ctrl.CC.Longititude = sg[4]
						ctrl.CC.Latitude = sg[3]
						ctrl.CC.Height = sg[5]
						if PosTemp == "UbxPosInfo" {
							ctrl.ReportStatus(1, GpsStat, TimeSync, StarReport, IsWorking, config.NSF4000TypeLLH, sg[4], sg[3], sg[5], int64(subDevType), ctrl.IsSupportSelfCheck, 1)
							ctrl.ReportStatus(1, GpsStat, TimeSync, StarReport, IsWorking, config.NSF4000TypeGpsStatus, sg[4], sg[3], sg[5], int64(subDevType), ctrl.IsSupportSelfCheck, 1)
						}
					} else if sg[0] == "RPT" && sg[1] == "JinweiPosInfo" { //设备返回的经纬高
						//$RPT UbxPosInfo 201858 22.5971437 113.9982126 25.909 0.004 0.013 -0.001 0.000 0.000
						GpsStat = 1
						ctrl.CC.Longititude = sg[4]
						ctrl.CC.Latitude = sg[3]
						ctrl.CC.Height = sg[5]
						// if PosTemp == "UbxPosInfo" {
						ctrl.ReportStatus(1, GpsStat, TimeSync, StarReport, IsWorking, config.NSF4000TypeLLH, sg[4], sg[3], sg[5], int64(subDevType), ctrl.IsSupportSelfCheck, 1)
						ctrl.ReportStatus(1, GpsStat, TimeSync, StarReport, IsWorking, config.NSF4000TypeGpsStatus, sg[4], sg[3], sg[5], int64(subDevType), ctrl.IsSupportSelfCheck, 1)
						// }
					} else if (sg[0] == "RPT" && sg[1] == "GpsSimSat") ||
						(sg[0] == "RPT" && sg[1] == "BdsSimSat") ||
						(sg[0] == "RPT" && sg[1] == "GloSimSat") ||
						(sg[0] == "RPT" && sg[1] == "GalSimSat") { //设备是否在工作模式

						if time.Since(ctrl.NsfCacheQueue.ReportTime).Milliseconds() < ctrl.NsfCacheQueue.LimitRate {
							continue
						}
						ctrl.NsfCacheQueue.ReportTime = time.Now()
						IsWorking = 1
						ctrl.ReportStatus(1, GpsStat, TimeSync, StarReport, IsWorking, config.NSF4000TypeWorking, "", "", "", int64(subDevType), ctrl.IsSupportSelfCheck, 1)
						DeviceNSF4000Map.Set(ctrl.Sn, 1)
						// 重置计时器
						if ctrl.TimerWork != nil {
							ctrl.TimerWork.Stop()
						}
						ctrl.TimerWork = time.AfterFunc(5*time.Second, func() {
							ctrl.ReportStatus(1, 2, 0, 0, 2, config.NSF4000TypeWorking, "", "", "", int64(subDevType), ctrl.IsSupportSelfCheck, 1) //给前端发离线消息
						})

					} else if sg[0] == "RACK" && sg[1] == "PkgVer" { //设备版本信息
						ctrl.Version = sg[2]
						logger.Info("NSF4000 version is :", ctrl.Version)
					} else if sg[0] == "RACK" && sg[1] == "PatchVer" { //设备版本信息
						logger.Info("NSF4000 main version is :", ctrl.Version, "version of patch is :", sg[2])
						if len(ctrl.Version) != 0 {
							ctrl.Version = fmt.Sprintf("%s_%s", ctrl.Version, sg[2])
							if ctrl.NFSIP == "192.168.2.84" {
								logger.Debug("It's fixed spoofer,not support one key selfcheck func. ignore it. ")
								ctrl.IsFixed = true
							} else {
								ctrl.IsSupportSelfCheck = true
							}

							logger.Info("NSF4000 version with patch is OK :", ctrl.Version)
						} else {
							logger.Errorf("patch version is nil.")
						}
						// }

					} else if sg[0] == "RACK" && sg[1] == "PwrConsum" { //电流信息
						logger.Info("sg = ", sg)
						getReturnValue := func(s string) int {
							num, err := strconv.Atoi(s)
							if err != nil {
								return 0
							}
							return num
						}

						nsf := common.Nsf4000GselfStatusMapInfo{}
						if NsfPwr != 0 {
							nsf.Sn = ctrl.Sn
							nsf.NewVol = getReturnValue(sg[3])
							nsf.NewCurr = getReturnValue(sg[4])
							NsfPwr = 0
						} else {
							NsfPwr = 1
							nsf.Sn = ctrl.Sn
							nsf.OldVol = getReturnValue(sg[3])
							nsf.OldCurr = getReturnValue(sg[4])
						}
						Nsf4000GselfStatus.Set(ctrl.Sn, nsf)
						logger.Debugf("Nsf4000GselfStatus = %+v", nsf)
					} else if sg[0] == "RACK" && sg[1] == "DevReady" { //设备自检信息
						logger.Debug("sg = ", sg)
						getReturnCode := func(s string) int {
							// num, err := strconv.Atoi(s[2 : len(s)-1])
							num, err := strconv.Atoi(s)
							if err != nil {
								logger.Error(" err = ", err)
								return 0
							}
							if num != 0 && num != -3 && num != -4 && num != -1 && num != -2 {
								return 1
							}
							return num
						}
						a := getReturnCode(sg[2])
						logger.Debug("a = ", a)
						if ctrl.IsSupportSelfCheck || ctrl.IsFixed {
							ctrl.ReportStatus(1, GpsStat, TimeSync, StarReport, IsWorking, config.NSF4000TypeSelfCheck, "", "", "", int64(subDevType), ctrl.IsSupportSelfCheck, a)
							ctrl.StatusTrace.Status = 4
							nsf := common.Nsf4000GselfStatusMapInfo{}
							nsf.Status = 4
							Nsf4000GselfStatus.Set(ctrl.Sn, nsf)
						} else {
							logger.Error("not send $REQ,DevReady to query device status,unexpected device error.device ip = ", ctrl.NFSIP, " device version = ", ctrl.Version)
						}

					} else if sg[0] == "RPT" && sg[1] == "PlyHeartBeat" { //设备发过来的心跳
						if ctrl.Sn != "" {
							// 重置计时器
							if ctrl.Timer != nil {
								ctrl.Timer.Stop()
							}
							ctrl.Timer = time.AfterFunc(6*time.Second, func() {
								logger.Error("nsf400 device offline sn:", ctrl.Sn)
								ctrl.ReportStatus(2, 2, 2, 2, 2, config.NSF4000TypeOnline, "", "", "", int64(subDevType), ctrl.IsSupportSelfCheck, 1) //给前端发离线消息
							})
							ctrl.ReportStatus(1, GpsStat, TimeSync, StarReport, IsWorking, config.NSF4000TypeOnline, "", "", "", int64(subDevType), ctrl.IsSupportSelfCheck, 1)
						}
					} else if sg[0] == "RACK" && sg[1] == "JamDeviceNo" { //获取设备唯一标识
						ctrl.Sn = sg[2]
						PosTemp = GetNsf4000PosTemp(ctrl.Sn)

					} else if sg[0] == "RACK" && sg[1] == "PowerInfo" {

						nowCurrentBattery := parseFloat(sg[5])
						if nowCurrentBattery != 0 {
							ctrl.CurrentBattery = nowCurrentBattery * 100 / 6.555
						} else {
							logger.Errorf("read power error, NSF4000 power is :", nowCurrentBattery)
						}

						logger.Info("NSF4000 power is: ", ctrl.CurrentBattery)
						ctrl.ReportStatus(1, GpsStat, TimeSync, StarReport, IsWorking, config.NSF4000TypeOnline, "", "", "", int64(subDevType), ctrl.IsSupportSelfCheck, 1)
					}
				}
			}
			cache = cache[msgIndex+1:]
		}
	}
}

// GetDevSn 获取设备Sn号
func (ctrl *ControllerNSF4000) GetDevSn(ctx context.Context) {
	timer1 := time.NewTicker(1 * time.Second)
	for {
		select {
		case <-timer1.C:
			if ctrl.Conn == nil || ctrl.Sn != "" {
				continue
			}
			if ctrl.Sn == "" || len(ctrl.Sn) < 10 {
				cmdTemp := "$REQ,JamDeviceNo" + "\r\n"
				ctrl.SendMsg([]byte(cmdTemp))
			}
		case <-ctx.Done():
			return
		}
	}
}

// GetDevSelfCheckMsg ...
func (ctrl *ControllerNSF4000) GetDevSelfCheckMsg(ctx context.Context) {
	tryTimes := 0
	timer1 := time.NewTicker(1 * time.Second)
	for {
		select {
		case <-timer1.C:
			if ctrl.Conn == nil {
				logger.Error("ctrl.Conn is nil")
				continue
			}
			logger.Debug(" IsSupportSelfCheck = ", ctrl.IsSupportSelfCheck, "  IsFixed = ", ctrl.IsFixed)
			if ctrl.IsSupportSelfCheck || ctrl.IsFixed {
				cmdTemp := "$REQ,DevReady" + "\r\n"
				ret := ctrl.SendMsg([]byte(cmdTemp))
				// timer1.Reset(3 * time.Second)
				if ctrl.IsFixed {
					logger.Debug("times = ", tryTimes, " res = ", ret)
					logger.Debug("fixed spoofer ticker send selfcheck msg: ", cmdTemp)
				} else {
					logger.Debug("times = ", tryTimes, " res = ", ret)
					logger.Debug(" spoofer ticker send selfcheck msg: ", cmdTemp)
				}

				tryTimes++
				if tryTimes > 3 {
					nsf, isExist := Nsf4000GselfStatus.Get(ctrl.Sn)
					if isExist && nsf != nil {
						ctrl.StatusTrace.Status = nsf.Status
					}
					if ctrl.StatusTrace.Status == 4 {
						subDevType := 0
						if ctrl.NFSIP == "192.168.2.84" {
							subDevType = 1
						}
						if ctrl.NFSIP == "192.168.2.94" {
							subDevType = 2
						}
						ctrl.ReportStatus(0, 0, 0, 0, 0, config.NSF4000TypeSelfCheck, "", "", "", int64(subDevType), ctrl.IsSupportSelfCheck, 1)
						logger.Debug("spoofer system selfcheck ok ")
						timer1.Reset(60 * time.Second)
						tryTimes = 5
					} else {
						subDevType := 0
						if ctrl.NFSIP == "192.168.2.84" {
							subDevType = 1
						}
						if ctrl.NFSIP == "192.168.2.94" {
							subDevType = 2
						}
						ctrl.ReportStatus(0, 0, 0, 0, 0, config.NSF4000TypeSelfCheck, "", "", "", int64(subDevType), ctrl.IsSupportSelfCheck, -5)
						logger.Error("sim firmware error")
						break
					}

				}

			}
		// if ctrl.Version != "" {
		// 	logger.Error("ctrl version is nil")
		// 	return
		// }
		case <-ctx.Done():
			return
		}
	}
}

// GetDevVer 获取设备版本信息
func (ctrl *ControllerNSF4000) GetDevVer() {
	timer1 := time.NewTicker(1 * time.Second)
	for {
		select {
		case <-timer1.C:
			if ctrl.Conn == nil {
				continue
			}
			if ctrl.Version == "" {
				cmdTemp := "$REQ,PkgVer" + "\r\n"
				ctrl.SendMsg([]byte(cmdTemp))
				logger.Debug("send msg :", cmdTemp)
				time.Sleep(time.Millisecond * 20)
				cmdTemp2 := "$REQ,PatchVer" + "\r\n"
				ctrl.SendMsg([]byte(cmdTemp2))
				logger.Debug("send msg :", cmdTemp)
			}
			if ctrl.Version != "" {
				return
			}
		}
	}
}

// SendHeart 定时给设备发送心跳
func (ctrl *ControllerNSF4000) SendHeart(ctx context.Context) {
	timer1 := time.NewTicker(1 * time.Second)
	for {
		select {
		case <-timer1.C:
			if ctrl.Conn == nil {
				continue
			}
			cmdTemp := "$SET,PlyHeartBeat,5" + "\r\n"
			ctrl.SendMsg([]byte(cmdTemp))
			logger.Info("Send Heart to NSF4000")
		case <-ctx.Done():
			return
		}
	}
}

// SendL1B3Mode 开机发送L3 or B3 模式设置
func (ctrl *ControllerNSF4000) SendL1B3Mode(ctx context.Context) {
	ticker := time.NewTicker(1 * time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-ticker.C:
			//1:B3 	2:L1
			if PosTemp == "FuconPosInfo" {
				// m.B3OrL1 = 1
				B3Cmd1 := "$SET,PpsSynSrc,1" + "\r\n"
				B3Cmd2 := "$SET,SynUppsMode,3" + "\r\n"
				ctrl.SendMsg([]byte(B3Cmd1))
				ctrl.SendMsg([]byte(B3Cmd2))
				logger.Info("Send L1 or B3 mode to NSF4000 B3Cmd1: ", B3Cmd1)
				logger.Info("Send L1 or B3 mode to NSF4000 B3Cmd1: ", B3Cmd2)
				return
			} else if PosTemp == "UbxPosInfo" {
				// m.B3OrL1 = 2
				L1Cmd1 := "$SET,PpsSynSrc,0" + "\r\n"
				L1Cmd2 := "$SET,SynUppsMode,0" + "\r\n"
				ctrl.SendMsg([]byte(L1Cmd1))
				ctrl.SendMsg([]byte(L1Cmd2))
				logger.Info("Send L1 or B3 mode to NSF4000 L1Cmd1: ", L1Cmd1)
				logger.Info("Send L1 or B3 mode to NSF4000 L1Cmd2: ", L1Cmd2)
				return
			} else {
				logger.Info("NSF4000 PosTemp is not set", PosTemp)
			}
		case <-ctx.Done():
			return
		}
	}
}

// GetDevPowerInfo 获取设备供电信息
func (ctrl *ControllerNSF4000) GetDevPowerInfo(ctx context.Context) {
	timer1 := time.NewTicker(1 * time.Second)
	for {
		select {
		case <-timer1.C:
			if ctrl.Conn == nil {
				continue
			}
			cmdTemp := "$REQ,PowerInfo" + "\r\n"
			ctrl.SendMsg([]byte(cmdTemp))
			logger.Info("Send PowerInfo to NSF4000")
			timer1.Reset(1 * time.Minute)
		case <-ctx.Done():
			return
		}
	}
}

func (ctrl *ControllerNSF4000) cacheConn(conn net.Conn) {
	ctrl.Conn = conn
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_NSF4000, ctrl.Sn)
	dev := &Device{
		Sn:       ctrl.Sn,
		Conn:     ctrl.Conn,
		RemoteIp: conn.RemoteAddr().String(),
	}
	reqMode := &ControllerNSF4000{
		Device:  dev,
		Version: ctrl.Version,
		NFSIP:   ctrl.NFSIP,
		CC:      ctrl.CC,
	}
	if ctrl.Sn == "" {
		logger.Error("NSF4000 sn is nil")
		return
	}
	DevStatusNfsMap.Store(cacheKey, reqMode)
}

func (ctrl *ControllerNSF4000) SendMsg(data []byte) int {
	defer func() {
		if err := recover(); err != nil {
			logger.Error("SendMsg 接收到panic:", err)
		}
	}()
	if ctrl.Conn == nil {
		logger.Error("NSF conn is nil")
		return -1
	}
	res, err := ctrl.Conn.Write(data)
	if err != nil {
		logger.Error("NSF Write err:", err)
		ctrl.Conn.Close()
		ctrl.Conn = nil
		return -1
	}
	return res
}
func (ctrl *ControllerNSF4000) SelfCheckCom(req *client.SelfCheckRequest) int {
	reqdo := &client.InduceRequest{}
	reqdo.Enable = false
	ret := ctrl.SetPlay(reqdo)
	logger.Debug("do disable nsf4000, ret = ", ret)
	time.Sleep(2 * time.Second)

	cmdTemp := "$REQ,PwrConsum,13" + "\r\n"
	ctrl.SendMsg([]byte(cmdTemp))
	time.Sleep(1 * time.Second)

	reqdo.Enable = true
	reqdo.IsMixed = true
	reqdo.WorkMode = int32(config.DIRECTIONALDRIVE)
	reqdo.Power = 0
	reqdo.Angle = int32(config.NORTH)
	ret = ctrl.SetPlay(reqdo)
	logger.Debug("do start noth nsf4000 spoof, ret = ", ret)
	time.Sleep(6 * time.Second)

	cmdTemp = "$REQ,PwrConsum,13" + "\r\n"
	ctrl.SendMsg([]byte(cmdTemp))
	time.Sleep(1 * time.Second)

	reqdo.Enable = false
	ret = ctrl.SetPlay(reqdo)
	logger.Debug("do disable nsf4000, ret = ", ret)

	nsf, isExist := Nsf4000GselfStatus.Get(ctrl.Sn)
	if isExist && nsf != nil {
		ctrl.GselfStatus.NewCurr = nsf.NewCurr
		ctrl.GselfStatus.OldCurr = nsf.OldCurr
		ctrl.GselfStatus.NewVol = nsf.NewVol
		ctrl.GselfStatus.OldVol = nsf.OldVol
	}

	dI := ctrl.GselfStatus.NewCurr - ctrl.GselfStatus.OldCurr
	logger.Debug("ctr.StatusTrace = ", ctrl.GselfStatus)
	logger.Debug("dI = ", dI)

	CurrentGapVaule := 350
	if ctrl.NFSIP == "192.168.2.94" {
		logger.Debug("ctrl.NFSIP = ", ctrl.NFSIP)
		CurrentGapVaule = 1000
	}
	if ctrl.GselfStatus.NewVol < 2000 || ctrl.GselfStatus.OldVol < 2000 || dI < CurrentGapVaule {
		logger.Debug("selfcheck fail,device error")
		return -6
	}
	logger.Debug("selfcheck Ok.")
	return 1
}

// SetPlay 发起主动防御、区域拒止、定向驱离
func (ctrl *ControllerNSF4000) SetPlay(req *client.InduceRequest) int {
	var res int
	subDevType := 0
	if ctrl.NFSIP == "192.168.2.84" {
		subDevType = 1
	}
	if ctrl.NFSIP == "192.168.2.94" {
		subDevType = 2
	}
	nsfWorking, isExist := Nsf4000Working.Get(req.Sn)
	if isExist && nsfWorking != nil {
		if nsfWorking.NsfIsWorking {
			logger.Debug("NFSStartCmd is false")
			nsf := common.Nsf4000WorkingInfo{}
			nsf.NsfIsWorking = false
			Nsf4000Working.Set(req.Sn, nsf)
			if ctrl.NFSIP == "192.168.2.84" {
				StopMsg84 <- true
			} else if ctrl.NFSIP == "192.168.2.94" {
				StopMsg94 <- true
			} else {
				StopMsg74 <- true
			}

			config.M_tgtHeading = 0
		}
	}
	if req.Enable {
		if req.WorkMode == int32(config.ACTIVEDEFENSE) { //主动防御
			res = ctrl.SendActiveDefenseCommand(req.Power, req.DefenseLongitude, req.DefenseLatitude, req.Height, req.IsMixed)
			if res == -1 {
				logger.Error("SendMsg To NSF Active defense err")
				return res
			}
			// req.Radius = 300 //诱导需求 发起时半径写死300
			constRadius := int32(300) //诱导需求 发起时半径写死300
			pos, vel, err := ctrl.CalculatePosAndVel(req.DefenseLevelSpeed, constRadius, req.DefenseVerticalSpeed, req.DefenseLongitude, req.DefenseLatitude)
			if err != nil {
				logger.Error("CalculatePosAndVel error:", err)
				return -1
			}
			cmdTemp := "$SET,SimPos,1," + pos + "," + vel + "\r\n"
			cmdTemp1 := "$SET,SimMov,0," + vel + "\r\n"
			logger.Debug("Active defense cmdTemp SimPos is :", cmdTemp)
			logger.Debug("Active defense cmdTemp1 SimMov is :", cmdTemp1)
			logger.Debug("CalculatePosAndVel  :", ctrl.CC)

			time.Sleep(time.Second * 2)

			res = ctrl.SendMsg([]byte(cmdTemp))
			if res == -1 {
				logger.Error("SendMsg To NSF $SET,SimPos,1 err")
				return res
			}

			res = ctrl.SendMsg([]byte(cmdTemp1))
			if res == -1 {
				logger.Error("SendMsg To NSF $SET,SimMov,1 err")
				return res
			}

			if ctrl.NFSIP == "192.168.2.84" {
				go func() {
					nsf := common.Nsf4000WorkingInfo{}
					nsf.Sn = req.Sn
					nsf.NsfIsWorking = true
					Nsf4000Working.Set(req.Sn, nsf)
					logger.Debug("Nsf4000Working is true")
					tickerSend := time.NewTicker(time.Second * 1)
					for {
						select {
						case <-tickerSend.C:
							pos, vel, err = ctrl.CalculatePosAndVel(req.DefenseLevelSpeed, constRadius, req.DefenseVerticalSpeed, req.DefenseLongitude, req.DefenseLatitude)
							if err != nil {
								logger.Error("CalculatePosAndVel error:", err)
							}
							cmdTemp2 := "$SET,SimMov,0," + vel + "\r\n"
							logger.Debug("CalculatePosAndVel  :", ctrl.CC)
							logger.Debug("Active defense cmdTemp2 SimMov is :", cmdTemp2)
							ctrl.SendMsg([]byte(cmdTemp2))
						case <-StopMsg84:
							logger.Debug("Active defense cmdTemp2 stop")
							return

						}
					}
				}()
			} else if ctrl.NFSIP == "192.168.2.94" {
				go func() {
					nsf := common.Nsf4000WorkingInfo{}
					nsf.Sn = req.Sn
					nsf.NsfIsWorking = true
					Nsf4000Working.Set(req.Sn, nsf)
					logger.Debug("Nsf4000Working is true")
					tickerSend := time.NewTicker(time.Second * 1)
					for {
						select {
						case <-tickerSend.C:
							pos, vel, err = ctrl.CalculatePosAndVel(req.DefenseLevelSpeed, constRadius, req.DefenseVerticalSpeed, req.DefenseLongitude, req.DefenseLatitude)
							if err != nil {
								logger.Error("CalculatePosAndVel error:", err)
							}
							cmdTemp2 := "$SET,SimMov,0," + vel + "\r\n"
							logger.Debug("CalculatePosAndVel  :", ctrl.CC)
							logger.Debug("Active defense cmdTemp2 SimMov is :", cmdTemp2)
							ctrl.SendMsg([]byte(cmdTemp2))
						case <-StopMsg94:
							logger.Debug("Active defense cmdTemp2 stop")
							return

						}
					}
				}()
			} else {
				go func() {
					nsf := common.Nsf4000WorkingInfo{}
					nsf.Sn = req.Sn
					nsf.NsfIsWorking = true
					Nsf4000Working.Set(req.Sn, nsf)
					logger.Debug("Nsf4000Working is true")
					tickerSend := time.NewTicker(time.Second * 1)
					for {
						select {
						case <-tickerSend.C:
							pos, vel, err = ctrl.CalculatePosAndVel(req.DefenseLevelSpeed, constRadius, req.DefenseVerticalSpeed, req.DefenseLongitude, req.DefenseLatitude)
							if err != nil {
								logger.Error("CalculatePosAndVel error:", err)
							}
							cmdTemp2 := "$SET,SimMov,0," + vel + "\r\n"
							logger.Debug("CalculatePosAndVel  :", ctrl.CC)
							logger.Debug("Active defense cmdTemp2 SimMov is :", cmdTemp2)
							ctrl.SendMsg([]byte(cmdTemp2))
						case <-StopMsg74:
							logger.Debug("Active defense cmdTemp2 stop")
							return

						}
					}
				}()
			}

			ticker := time.NewTicker(time.Millisecond * 100)
			stop := time.NewTicker(time.Second * 10)

			defer ticker.Stop()
			defer stop.Stop()
			DeviceNSF4000Map.Set(ctrl.Sn, 0)
			for {
				select {
				case <-ticker.C:
					statusMap, isexist := DeviceNSF4000Map.Get(ctrl.Sn)
					if isexist == true {
						if statusMap.Status == 1 || statusMap.Status == -1 {
							DeviceNSF4000Map.Set(ctrl.Sn, 0)
							return statusMap.Status
						}
					}
				case <-stop.C:
					return -1
				}
			}

		} else if req.WorkMode == int32(config.AREADENIAL) { //区域拒止
			logger.Debug("Start AreaDenial Cmd is :", config.AreaDenial)
			startCmd := ""
			sendMsg := config.AreaDenial
			if req.IsMixed {
				sendMsg = config.MixedAreaDenial
				if req.AreaStopLongitude == 0 {
					req.AreaStopLongitude = 113.98183850
				}
				if req.AreaStopLatitude == 0 {
					req.AreaStopLatitude = 22.63690183
				}
				if req.Height == 0 {
					req.Height = 400
				}
			}
			if req.Power == 0 {
				startCmd = strings.ReplaceAll(sendMsg, "$Power", "0")
				startCmd = strings.ReplaceAll(startCmd, "$Add10", "10")
			} else {
				startCmd = strings.ReplaceAll(sendMsg, "$Power", strconv.Itoa(int(req.Power)))
				startCmd = strings.ReplaceAll(startCmd, "$Add10", strconv.Itoa(int(req.Power+10)))
			}

			longitudeStr := strconv.FormatFloat(req.AreaStopLongitude, 'f', -1, 64)
			latitudeStr := strconv.FormatFloat(req.AreaStopLatitude, 'f', -1, 64)
			startCmd = strings.Replace(startCmd, "$Longititude", longitudeStr, -1)
			startCmd = strings.Replace(startCmd, "$Latitude", latitudeStr, -1)
			startCmd = strings.Replace(startCmd, "$Height", strconv.Itoa(int(req.Height)), -1)
			res = ctrl.SendMsg([]byte(startCmd))

			logger.Info("AREADENIAL  startCmd is :", startCmd)
			if res == -1 {
				logger.Error("SendMsg To NSF Area Denial err")
				return res
			}
			ticker := time.NewTicker(time.Millisecond * 100)
			stop := time.NewTicker(time.Second * 10)

			defer ticker.Stop()
			defer stop.Stop()
			DeviceNSF4000Map.Set(ctrl.Sn, 0)
			for {
				select {
				case <-ticker.C:
					statusMap, isexist := DeviceNSF4000Map.Get(ctrl.Sn)
					if isexist == true {
						if statusMap.Status == 1 || statusMap.Status == -1 {
							DeviceNSF4000Map.Set(ctrl.Sn, 0)
							return statusMap.Status
						}
					}
				case <-stop.C:
					return -1
				}

			}
		} else if req.WorkMode == int32(config.DIRECTIONALDRIVE) || req.WorkMode == int32(config.UavToExplode) { //定向驱离
			if req.WorkMode == int32(config.DIRECTIONALDRIVE) {
				logger.Debug("Start DIRECTIONALDRIVE Cmd is :", config.DIRECTIONALDRIVE)
			}
			if req.WorkMode == int32(config.UavToExplode) {
				logger.Debug("Start UavToExplode Cmd is :", config.UavToExplode)
			}
			logger.Info("cc is ", ctrl.CC)
			tempSendMsg := config.ActiveDefense
			tempLongit := ctrl.CC.Longititude
			tempLatit := ctrl.CC.Latitude
			tempHeight := ctrl.CC.Height
			if req.IsMixed {
				tempSendMsg = config.MixedActiveDefense
				if tempLongit == "" {
					tempLongit = "113.98183850"
				}
				if tempLatit == "" {
					tempLatit = "22.63690183"
				}
				if tempHeight == "" {
					tempHeight = "400"
				}
			}
			startCmd := strings.Replace(tempSendMsg, "$Longititude", tempLongit, -1)
			startCmd = strings.Replace(startCmd, "$Latitude", tempLatit, -1)
			heightStr := tempHeight
			heightInt, err := strconv.Atoi(heightStr)
			if err != nil {
				logger.Error("Atoi err :", err)
			}
			startCmd = strings.Replace(startCmd, "$Height", strconv.Itoa(heightInt+200), -1)

			if req.Power == 0 {
				startCmd = strings.ReplaceAll(startCmd, "$Power", "0")
				startCmd = strings.ReplaceAll(startCmd, "$Add10", "10")
			} else {
				startCmd = strings.ReplaceAll(startCmd, "$Power", strconv.Itoa(int(req.Power)))
				startCmd = strings.ReplaceAll(startCmd, "$Add10", strconv.Itoa(int(req.Power+10)))
			}

			logger.Info("Start  is Directional Drive startCmd is :", startCmd)

			ctrl.SendMsg([]byte(startCmd))

			sendMsg := ""
			if req.Angle == int32(config.NORTH) {
				sendMsg = "$SET,SimMov,0,0,-" + strconv.Itoa(int(req.DriveLevelSpeed)) + ",0\r\n" //向北驱离
				if req.Vertical == int32(config.UP) {
					sendMsg = "$SET,SimMov,0,0,-" + strconv.Itoa(int(req.DriveLevelSpeed)) + ",-" + strconv.Itoa(int(req.DriveVerticalSpeed)) + "\r\n" //向北上驱离
				}
				if req.Vertical == int32(config.DOWN) {
					sendMsg = "$SET,SimMov,0,0,-" + strconv.Itoa(int(req.DriveLevelSpeed)) + "," + strconv.Itoa(int(req.DriveVerticalSpeed)) + "\r\n" //向北下驱离
				}
			} else if req.Angle == int32(config.EAST) {
				sendMsg = "$SET,SimMov,0,-" + strconv.Itoa(int(req.DriveLevelSpeed)) + ",0,0\r\n" //向东驱离
				if req.Vertical == int32(config.UP) {
					sendMsg = "$SET,SimMov,0,-" + strconv.Itoa(int(req.DriveLevelSpeed)) + ",0,-" + strconv.Itoa(int(req.DriveVerticalSpeed)) + "\r\n" //向东上驱离
				}
				if req.Vertical == int32(config.DOWN) {
					sendMsg = "$SET,SimMov,0,-" + strconv.Itoa(int(req.DriveLevelSpeed)) + ",0," + strconv.Itoa(int(req.DriveVerticalSpeed)) + "\r\n" //向东下驱离
				}
			} else if req.Angle == int32(config.SOUTH) {
				sendMsg = "$SET,SimMov,0,0," + strconv.Itoa(int(req.DriveLevelSpeed)) + ",0\r\n" //向南驱离
				if req.Vertical == int32(config.UP) {
					sendMsg = "$SET,SimMov,0,0," + strconv.Itoa(int(req.DriveLevelSpeed)) + ",-" + strconv.Itoa(int(req.DriveVerticalSpeed)) + "\r\n" //向南上驱离
				}
				if req.Vertical == int32(config.DOWN) {
					sendMsg = "$SET,SimMov,0,0," + strconv.Itoa(int(req.DriveLevelSpeed)) + "," + strconv.Itoa(int(req.DriveVerticalSpeed)) + "\r\n" //向南下驱离
				}
			} else if req.Angle == int32(config.WEST) {
				sendMsg = "$SET,SimMov,0," + strconv.Itoa(int(req.DriveLevelSpeed)) + ",0,0\r\n" //向西驱离
				if req.Vertical == int32(config.UP) {
					sendMsg = "$SET,SimMov,0," + strconv.Itoa(int(req.DriveLevelSpeed)) + ",0,-" + strconv.Itoa(int(req.DriveVerticalSpeed)) + "\r\n" //向西上驱离
				}
				if req.Vertical == int32(config.DOWN) {
					sendMsg = "$SET,SimMov,0," + strconv.Itoa(int(req.DriveLevelSpeed)) + ",0," + strconv.Itoa(int(req.DriveVerticalSpeed)) + "\r\n" //向西下驱离
				}
			} else if req.Angle == int32(config.UP) {
				sendMsg = "$SET,SimMov,0,0,0,-" + strconv.Itoa(int(req.DriveVerticalSpeed)) + "\r\n" //向上驱离
			} else if req.Angle == int32(config.DOWN) {
				sendMsg = "$SET,SimMov,0,0,0," + strconv.Itoa(int(req.DriveVerticalSpeed)) + "\r\n" //向下驱离
			} else if req.Angle == 0 && req.Vertical == 0 {
				res = ctrl.SendMsg([]byte(config.NFSCLOSE))
				logger.Info("send close:", config.NFSCLOSE)
				if res != -1 {
					time.Sleep(time.Second * 1)
					ctrl.ReportStatus(1, 0, 0, 0, 2, config.NSF4000TypeWorking, "", "", "", int64(subDevType), ctrl.IsSupportSelfCheck, 1)
				}
				return res
			}

			logger.Info("send driver msg:", sendMsg)
			ctrl.SendMsg([]byte(sendMsg))
			time.Sleep(1 * time.Second)
		}
	} else {
		res = ctrl.SendMsg([]byte(config.NFSCLOSE))
		logger.Info("send close:", config.NFSCLOSE)

		if res != -1 {
			time.Sleep(time.Second * 1)
			ctrl.ReportStatus(1, 0, 0, 0, 2, config.NSF4000TypeWorking, "", "", "", int64(subDevType), ctrl.IsSupportSelfCheck, 1)
		}
	}
	return res
}

func (ctrl *ControllerNSF4000) SetClose() {
	subDevType := 0
	if ctrl.NFSIP == "192.168.2.84" {
		subDevType = 1
	}
	if ctrl.NFSIP == "192.168.2.94" {
		subDevType = 2
	}
	ctrl.SendMsg([]byte(config.NFSCLOSE))
	ctrl.SendMsg([]byte(config.NFSCLOSE))
	ctrl.ReportStatus(1, 0, 0, 0, 2, config.NSF4000TypeWorking, "", "", "", int64(subDevType), ctrl.IsSupportSelfCheck, 1)
	ctrl.ReportStatus(2, 2, 2, 2, 2, config.NSF4000TypeOnline, "", "", "", int64(subDevType), ctrl.IsSupportSelfCheck, 1)
	go func() {
		time.Sleep(time.Millisecond * 10)
		ctrl.ReportStatus(2, 2, 2, 2, 2, config.NSF4000TypeOnline, "", "", "", int64(subDevType), ctrl.IsSupportSelfCheck, 1)
	}()
}

// func FindCacheDeviceNSF(sn string, deviceType common.DeviceType) *ControllerNSF4000 {
func FindCacheDeviceNSF(sn string, deviceType common.DeviceType) any {
	cacheKey := fmt.Sprintf("%d_%s", deviceType, sn)
	if dev, ok := DevStatusNfsMap.Load(cacheKey); ok {
		// nsfdev, ok := dev.(*ControllerNSF4000)
		// if !ok {
		// 	// return dev.(*ControllerNSF4000)
		// 	return nsfdev
		// }

		// return dev.(*ControllerNSF4000)
		return dev
	}
	return nil
}

// SendActiveDefenseCommand 发送主动防御命令
func (ctrl *ControllerNSF4000) SendActiveDefenseCommand(power int32, longititude, latitude float64, height int32, isMixed bool) int {
	logger.Info("ActiveDefense  req is: ", power, longititude, latitude, height)
	longititudeStr := ""
	latitudeStr := ""

	if longititude == 0 {
		longititudeStr = ctrl.CC.Longititude
	} else {
		longititudeStr = strconv.FormatFloat(longititude, 'f', -1, 64)
	}

	if latitude == 0 {
		latitudeStr = ctrl.CC.Latitude
	} else {
		latitudeStr = strconv.FormatFloat(latitude, 'f', -1, 64)
	}
	sendMsg := config.ActiveDefense
	if isMixed {
		sendMsg = config.MixedActiveDefense
		if longititudeStr == "" {
			longititudeStr = "113.98183850"
		}
		if latitudeStr == "" {
			latitudeStr = "22.63690183"
		}
		if height == 0 {
			height = 400
		}
	}
	startCmd := strings.Replace(sendMsg, "$Longititude", longititudeStr, -1)
	startCmd = strings.Replace(startCmd, "$Latitude", latitudeStr, -1)
	startCmd = strings.Replace(startCmd, "$Height", strconv.Itoa(int(height)), -1)
	if power == 0 {
		startCmd = strings.ReplaceAll(startCmd, "$Power", "0")
		startCmd = strings.ReplaceAll(startCmd, "$Add10", "10")
	} else {
		startCmd = strings.ReplaceAll(startCmd, "$Power", strconv.Itoa(int(power)))
		startCmd = strings.ReplaceAll(startCmd, "$Add10", strconv.Itoa(int(power+10)))
	}

	logger.Debug("ActiveDefense cmd is :", startCmd)
	res := ctrl.SendMsg([]byte(startCmd))
	return res
}

func (ctrl *ControllerNSF4000) CalculatePosAndVel(speed int32, radius int32, vspeed int32, longit, latit float64) (string, string, error) {
	//longitude, err := strconv.ParseFloat(ctrl.CC.Longititude, 64)
	//if err != nil {
	//	logger.Error("longitude Parse Float err:", err)
	//	return "", "", err
	//}
	//latitude, err := strconv.ParseFloat(ctrl.CC.Latitude, 64)
	//if err != nil {
	//	logger.Error("latitude Parse Float err:", err)
	//	return "", "", err
	//}

	if ctrl.CC.Height == "" {
		ctrl.CC.Height = "0"
	}
	height, err := strconv.ParseFloat(ctrl.CC.Height, 64)
	if err != nil {
		logger.Error("height Parse Float err:", err)
		return "", "", err
	}
	pos, vel := config.CalculatellhToposAndvel(speed, radius, vspeed, longit, latit, height)

	return pos, vel, nil
}

// ReportStatus 给前端上报消息
func (ctrl *ControllerNSF4000) ReportStatus(stat int, gpsstat int, timeSync int, starReport int, isWorking int, msgType int, longitude string, latitude string, height string, subDevType int64, isSupportSelfCheck bool, selfCheckCode int) {
	if ctrl.Sn == "" {
		return
	}
	var m NSF4000Msg
	nsf, isExist := Nsf4000Statue.Get(ctrl.Sn)
	if isExist && nsf != nil {
		m.Enable = nsf.Enable
		m.WorkMode = nsf.WorkMode
		m.Radius = nsf.Radius
		m.Angle = nsf.Angle
		nowTime := time.Now().UnixMilli()
		if nsf.Angle != 0 {
			m.OpsTime = (nowTime - nsf.EnableStartTime) / 1000
		}
	}
	m.IsOnline = stat
	m.TimeSync = timeSync
	m.IsWorking = isWorking
	m.Ephemeris = starReport
	m.GpsStatus = gpsstat
	m.CurrentBattery = ctrl.CurrentBattery
	m.SubDevType = subDevType
	m.IsSupportSelfCheck = isSupportSelfCheck
	m.SeflCheckCode = int32(selfCheckCode)

	if (m.Radius == 500 || m.Radius == 0) && ctrl.NFSIP == "192.168.2.84" {
		m.Radius = 1000
	}
	if (m.Radius == 500 || m.Radius == 0) && ctrl.NFSIP == "192.168.2.94" {
		m.Radius = 2000
	}
	if (m.Radius == 500 || m.Radius == 0) && ctrl.NFSIP == "192.168.2.64" {
		m.Radius = 2000
	}
	if m.Radius == 0 && ctrl.NFSIP == "192.168.2.74" {
		m.Radius = 500
	}
	if longitude != "" {
		longitude1, err := strconv.ParseFloat(longitude, 64)
		if err != nil {
			logger.Error("longitude Parse Float err:", err)
			return
		}
		m.Longititude = longitude1

		ctrl.CC.Longititude = longitude
	} else {
		m.Longititude = -1
	}

	if latitude != "" {
		latitude1, err := strconv.ParseFloat(latitude, 64)
		if err != nil {
			logger.Error("latitude Parse Float err:", err)
			return
		}
		m.Latitude = latitude1
		ctrl.CC.Latitude = latitude
	} else {
		m.Latitude = -1
	}
	if longitude == "0.00000000" && latitude == "0.00000000" {
		m.Longititude = -1
		m.Latitude = -1
	}
	if height != "" {
		height1, err := strconv.ParseFloat(height, 64)
		if err != nil {
			logger.Error("height Parse Float err:", err)
			return
		}
		m.Height = height1
		ctrl.CC.Height = height
	}

	if PosTemp == "FuconPosInfo" {
		m.B3OrL1 = 1
	} else if PosTemp == "UbxPosInfo" {
		m.B3OrL1 = 2
	}

	equipModel, err := GetEquipBySn(ctrl.Sn)
	name := ctrl.Name
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	msg := common.EquipmentMessageBoxEntity{
		Name:      name,
		Sn:        ctrl.Sn,
		Info:      m,
		EquipType: int(common.DEV_NSF4000),
		MsgType:   msgType,
	}
	if err == nil {
		msg.ParentType = equipModel.ParentType
		msg.ParentSn = equipModel.ParentSn
		msg.IsIntegrated = equipModel.IsIntegrated
	}
	if m.IsOnline == 2 {
		logger.Infof("Send NSF 4000 msg Offline: %v", msg)
	} else {
		status := &client.GetStatusRes{}
		subDev := 0
		if ctrl.NFSIP == "192.168.2.84" {
			subDev = 1
		}
		if ctrl.NFSIP == "192.168.2.94" {
			subDev = 2
		}
		err := NewEquipList().GetStatus(context.Background(), &client.GetStatusReq{
			Sn:         ctrl.Sn,
			EType:      "Spoofer",
			SubDevType: int64(subDev),
		}, status)
		ctrl.Name = status.Name
		if err != nil {
			logger.Error("NSF 4000 GetStatus err:", err)
			return
		}
	}
	logger.Infof("Send NSF 4000 msg is: %v", msg)
	if msgType == config.NSF4000TypeLLH {
		_ = mq.NSF4000BrokerLLH.Publish(mq.NSF4000TopicLLH, broker.NewMessage(msg))
	} else {
		_ = mq.NSF4000Broker.Publish(mq.NSF4000Topic, broker.NewMessage(msg))
	}

	go reportNSF4000Event(ctrl.Sn, &m)
}

func reportNSF4000Event(sn string, msg *NSF4000Msg) {
	if msg.IsOnline == 1 {
		cacheKey := fmt.Sprintf("%d_%s", common.DEV_NSF4000, sn)
		if cache, ok := DevStatusMapOnEvent.Load(cacheKey); ok {
			dev := cache.(*Device)
			dev.Status = common.DevOnline
			dev.LastHeartTime = time.Now()
			dev.GetStatusInterval = time.Now()
			return
		}
		dev := &Device{
			Sn:                sn,
			Status:            common.DevOnline,
			DevType:           common.DEV_NSF4000,
			FirstHeartTime:    time.Now(),
			LastHeartTime:     time.Now(),
			IsEnable:          common.DeviceEnable,
			GetStatusInterval: time.Now(),
			SessionId:         GetGlobalSessionId(),
		}
		DevStatusMapOnEvent.Store(cacheKey, dev)

		//上线事件上报
		reportStatusEvent(sn, utils.GetEventId(dev.SessionId), msg)
	} else if msg.IsOnline == 2 {
		//下线事件上报
		cacheKey := fmt.Sprintf("%d_%s", common.DEV_NSF4000, sn)
		eventId := ""

		if cache, ok := DevStatusMapOnEvent.Load(cacheKey); ok {
			dev := cache.(*Device)
			eventId = utils.GetEventId(dev.SessionId)
		} else {
			logger.Errorf("can't find NSF4000:%s in DevStatusMapOnEvent", sn)
			return
		}
		DevStatusMapOnEvent.Delete(cacheKey)

		reportStatusEvent(sn, eventId, msg)
	}
}

// reportStatusEvent 上下线事件上报
func reportStatusEvent(sn, eventId string, msg *NSF4000Msg) {
	equipModel, err := GetEquipBySn(sn)
	name := sn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	heartInfo := &client.SpooferStatusInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        sn,
			EquipType: int32(common.DEV_NSF4000),
			//MsgType:   0,
		},
		Data: &client.SpooferStatus{
			IsOnline:    int32(msg.IsOnline),
			Longititude: msg.Longititude,
			Latitude:    msg.Latitude,
			EventId:     eventId,
		},
	}
	if err != nil {
		heartInfo.Header.ParentType = int32(equipModel.ParentType)
		heartInfo.Header.ParentSn = equipModel.ParentSn
		heartInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	heartData, err := proto.Marshal(heartInfo)
	if err != nil {
		logger.Errorf("reportNSF4000Event marshal heartInfo err: %v", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgSpooferStatusEventData,
		Data:    heartData,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Infof("NSF4000 status event has reported, devSn: %v,report: %v", sn, heartInfo)
}

func GetNsf4000PosTemp(sn string) string {
	posTemp := 0
	result := "FuconPosInfo"
	listInfo := &client.Nsf4000B3L1ListRsp{}
	err := NewNsf4000().ListB3L1(context.Background(), &client.Nsf4000B3L1ListReq{}, listInfo)
	if err != nil {
		logger.Error("Get Induce config err:", err)
		return result
	}
	for _, info := range listInfo.ConfigB3L1List {
		if info.Sn == sn {
			posTemp = int(info.PosTemp)
		}
	}
	if posTemp == 1 {
		result = "FuconPosInfo"
	} else if posTemp == 2 {
		result = "UbxPosInfo"
	}
	logger.Info("Get Induce B3L1 Config is :", result)
	return result
}

func parseFloat(str string) float64 {
	f, err := strconv.ParseFloat(str, 64)
	if err != nil {
		logger.Errorf("parseFloat err: %v", err)
		return 0.000
	}
	return f
}

package handler

import (
	"context"
	"fmt"
	"strconv"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
)

// GetReplayDataSchedule 获取设备是否有无人机数据
func (e *DeviceCenter) GetReplayDataSchedule(ctx context.Context, req *client.GetReplayDataScheduleRequest, rsp *client.GetReplayDataScheduleResponse) error {
	logger.Infof("---->Into Get Replay Data Schedule,req:%v ", req.ListDeviceSchedule)
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()

	reqGetTime := make([]*client.Device, 0)
	rspData := make([]*client.ListDeviceScheduleRsp, 0)

	for _, listDevice := range req.ListDeviceSchedule {
		startTime, err := strconv.ParseFloat(listDevice.StartTime, 64)
		if err == nil {
			logger.Error("Parse Float64 err: ", err)
		}
		entTime, err := strconv.ParseFloat(listDevice.EndTime, 64)
		if err == nil {
			logger.Error("Parse Float64 err: ", err)
		}
		reqGetTime = append(reqGetTime, &client.Device{
			Sn:        listDevice.Sn,
			DevType:   listDevice.DevType,
			StartTime: startTime,
			EndTime:   entTime,
		})
	}
	dateRes := &client.DataReplayGetTimeRes{}
	_ = NewDataReplay().DataReplayGetTime(context.Background(), &client.DataReplayGetTimeReq{
		ListDevice: reqGetTime,
	}, dateRes)
	if dateRes == nil {
		rsp.Status = 1
		return nil
	}
	for _, list := range dateRes.ListDevice {
		rspData = append(rspData, &client.ListDeviceScheduleRsp{
			Sn:        list.Sn,
			DevType:   list.DevType,
			StartTime: strconv.FormatFloat(list.StartTime, 'f', -1, 64),
			StopTime:  strconv.FormatFloat(list.EndTime, 'f', -1, 64),
			MsgType:   list.MsgType,
		})
	}

	rsp.Status = 1
	rsp.ListDeviceScheduleRsp = rspData
	logger.Info("---->End Get Replay Data Schedule")
	return nil
}

// GetReplayData 获取设备一段时间内的无人机数据
func (e *DeviceCenter) GetReplayData(ctx context.Context, req *client.GetReplayDataRequest, rsp *client.GetReplayDataResponse) error {
	logger.Infof("---->Into Get Replay Data,  playtime:%v  TimeStamp:%v ", req.ReplayTime, req.TimeStamp)
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	for _, list_device := range req.ListDevice {
		data := &client.DataReplayRes{}
		timeStamp, _ := strconv.Atoi(req.TimeStamp)
		_ = NewDataReplay().DataReplay(context.Background(), &client.DataReplayReq{
			Sn:         list_device.Sn,
			TimeStamp:  int64(timeStamp),
			ReplayTime: req.ReplayTime,
			DevType:    list_device.DevType,
		}, data)
		rsp.Status = 1
		if data == nil {
			logger.Info("Get data is nil")
		} else {
			if list_device.DevType == 1 { //雷达
				//探测数据
				if data.ListDetect != nil {
					tempListDetect := make([]*client.ListDetect, 0)
					for _, detect := range data.ListDetect {
						tempList := make([]*client.ListDetectRadar, 0)
						for _, radarInfo := range detect.ListDetectRadar {
							tempList = append(tempList, &client.ListDetectRadar{
								X:            radarInfo.X,
								Y:            radarInfo.Y,
								Z:            radarInfo.X,
								Velocity:     radarInfo.Velocity,
								Azimuth:      radarInfo.Azimuth,
								Alive:        radarInfo.Alive,
								ExistingProb: radarInfo.ExistingProb,
								ObjId:        radarInfo.ObjId,
								StateType:    radarInfo.StateType,
								Sn:           list_device.Sn,
							})
						}

						tempListDetect = append(tempListDetect, &client.ListDetect{
							Timestamp:       strconv.Itoa(int(detect.Timestamp)),
							Sn:              list_device.Sn,
							ListDetectRadar: tempList,
						})
					}
					rsp.ListDeviceInfo = append(rsp.ListDeviceInfo, &client.ListDeviceInfo{
						Sn:         list_device.Sn,
						DevType:    list_device.DevType,
						ListDetect: tempListDetect,
					})
				}
				//心跳
				if data.ListHeart != nil {
					tempListHeart := make([]*client.ListHeart, 0)
					for _, heart := range data.ListHeart {

						tempListHeart = append(tempListHeart, &client.ListHeart{
							Timestamp:   strconv.Itoa(int(heart.Timestamp)),
							Sn:          list_device.Sn,
							IsOnline:    heart.IsOnline,
							Electricity: heart.Electricity,
						})

					}
					rsp.ListDeviceInfo = append(rsp.ListDeviceInfo, &client.ListDeviceInfo{
						Sn:        list_device.Sn,
						DevType:   list_device.DevType,
						ListHeart: tempListHeart,
					})
				}
				//姿态数据
				if data.ListPosture != nil {
					tempListPosture := make([]*client.ListPosture, 0)
					for _, posture := range data.ListPosture {
						tempListPosture = append(tempListPosture, &client.ListPosture{
							Timestamp: strconv.Itoa(int(posture.Timestamp)),
							Sn:        list_device.Sn,
							Heading:   posture.Heading,
							Pitching:  posture.Pitching,
							Rolling:   posture.Rolling,
							Longitude: posture.Longitude,
							Latitude:  posture.Latitude,
						})
					}
					rsp.ListDeviceInfo = append(rsp.ListDeviceInfo, &client.ListDeviceInfo{
						Sn:          list_device.Sn,
						DevType:     list_device.DevType,
						ListPosture: tempListPosture,
					})
				}
			} else if list_device.DevType == 2 { //Tracer
				if data.ListDetect != nil {

					tempListDetect := make([]*client.ListDetect, 0)
					for _, detect := range data.ListDetect {
						tempList := make([]*client.ListDetectTracer, 0)
						for _, tracerInfo := range detect.ListDetectTracer {
							tempList = append(tempList, &client.ListDetectTracer{
								OperatorLongitude: tracerInfo.OperatorLongitude,
								OperatorLatitude:  tracerInfo.OperatorLatitude,
								Freq:              tracerInfo.Freq,
								Distance:          tracerInfo.Distance,
								DangerLevels:      tracerInfo.DangerLevels,
								Role:              tracerInfo.Role,
								DroneName:         tracerInfo.DroneName,
								SerialNum:         tracerInfo.SerialNum,
								DroneLongitude:    tracerInfo.DroneLongitude,
								DroneLatitude:     tracerInfo.DroneLatitude,
								DroneHeight:       tracerInfo.DroneHeight,
								DroneSpeed:        tracerInfo.DroneSpeed,
								DroneYawAngle:     tracerInfo.DroneYawAngle,
							})
							tempListDetect = append(tempListDetect, &client.ListDetect{
								Timestamp:        strconv.Itoa(int(detect.Timestamp)),
								Sn:               list_device.Sn,
								ListDetectTracer: tempList,
							})
						}

					}
					rsp.ListDeviceInfo = append(rsp.ListDeviceInfo, &client.ListDeviceInfo{
						Sn:         list_device.Sn,
						DevType:    list_device.DevType,
						ListDetect: tempListDetect,
					})
				}
				//心跳
				if data.ListHeart != nil {
					tempListHeart := make([]*client.ListHeart, 0)
					for _, heart := range data.ListHeart {
						tempListHeart = append(tempListHeart, &client.ListHeart{
							Timestamp:   strconv.Itoa(int(heart.Timestamp)),
							IsOnline:    heart.IsOnline,
							Electricity: heart.Electricity,
							WorkMode:    heart.WorkMode,
							WorkStatus:  heart.WorkStatus,
							AlarmLevel:  heart.AlarmLevel,
						})

					}
					rsp.ListDeviceInfo = append(rsp.ListDeviceInfo, &client.ListDeviceInfo{
						Sn:        list_device.Sn,
						DevType:   list_device.DevType,
						ListHeart: tempListHeart,
					})

				}

			}
		}

	}
	logger.Info("---->End Get Replay Data")
	return nil
}

// DataMarkers 时间标记
func (e *DeviceCenter) DataMarkers(ctx context.Context, req *client.DataMarkersRequest, rsp *client.DataMarkersResponse) error {
	logger.Infof("---->Into Data Markers: timeStamp:[%v],level:[%v],opt[%v],interval[%v],tips[%v]",
		req.Timestamp, req.Level, req.Operation, req.Interval, req.Tips)
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	rsp.Status = 2
	layout := "2006-01-02 15:04:05" //时间格式

	if req.Operation == ADD { //添加时间标记
		t, err := time.Parse(layout, req.Timestamp)
		if err != nil {
			logger.Error("Parse time error:", err)
			return nil
		}
		timeFormat := t.Unix() // 将时间对象转换为时间戳（秒级）
		err = NewDateMarkers().Insert(context.Background(), &client.DateMarkersInsertReq{
			Timestamp: req.Timestamp,
			Level:     req.Level,
			Tips:      req.Tips,
			CreatTime: timeFormat,
		}, &client.DateMarkersInsertRsp{})
		if err != nil {
			logger.Error("Date Markers Insert err:", err)
			return nil
		}
		rsp.Operation = req.Operation
		rsp.Status = 1
		return nil
	} else if req.Operation == DEL { //删除时间标记
		err := NewDateMarkers().Deletes(context.Background(), &client.DateMarkersDeletesReq{
			Timestamp: req.Timestamp,
			Level:     req.Level,
			Tips:      req.Tips,
		}, &client.DateMarkersDeletesRsp{})
		if err != nil {
			logger.Error("Date Markers Deletes err:", err)
			return nil
		}
		rsp.Operation = req.Operation
		rsp.Status = 1
		return nil
	} else if req.Operation == FIND { //查找时间标记
		tmpStart, err := time.Parse(layout, req.Timestamp)
		if err != nil {
			logger.Error("Parse time error:", err)
			return nil
		}
		startTime := tmpStart.Unix()

		tmpStop := tmpStart.Add(time.Duration(-req.Interval) * time.Hour) //向前推几个小时
		tmp := tmpStop.UTC().Format(layout)

		tmpStop1, err := time.Parse(layout, tmp)
		if err != nil {
			logger.Error("Parse time error:", err)
			return nil
		}
		stopTime := tmpStop1.Unix()
		markList := &client.DateMarkersListRsp{}
		err = NewDateMarkers().List(context.Background(), &client.DateMarkersListReq{
			StartTime: stopTime,
			StopTime:  startTime,
		}, markList)
		if err != nil {
			logger.Error("Date Markers List err:", err)
			return nil
		}
		for _, info := range markList.Markerslist {
			rsp.ListData = append(rsp.ListData, &client.ListData{
				Date:  info.Timestamp,
				Level: info.Level,
				Tips:  info.Tips,
			})
		}
		rsp.Operation = req.Operation
		rsp.Status = 1
		return nil

	}
	logger.Info("---->End Data Markers")
	return nil
}
func (e *DeviceCenter) QueryDateMarkersAllTime(_ context.Context, rsp *client.DateMarkerAllResponse) error {
	rsp.Status = SUCC

	var qdata client.DateMarkersDateTimeRsp
	err := NewDateMarkers().QueryAllDateTime(context.Background(), &client.DateMarkersDateTimeReq{}, &qdata)
	if err != nil {
		rsp.Status = Fail
		return nil
	}

	for _, v := range qdata.DateTimeItem {
		if len(v) <= 0 {
			continue
		}
		rsp.DateMarkerTime = append(rsp.DateMarkerTime, v)
	}

	logger.Infof("call query date marker all items done, resp: %+v", rsp)
	return nil
}

const (
	SUCC = 1
)

func (de *DeviceCenter) GetDeviceTypeList(ctx context.Context, req *client.ReplayDeviceListRequest, rsp *client.ReplayDeviceListResponse) error {
	rsp.Status = SUCC

	logger.Infof("get deviceList Type, req msg: %v", req.String())
	if len(req.BeginTime) == 0 || len(req.EndTime) <= 0 {
		logger.Errorf("input param time str is empty")
		rsp.Status = Fail
		return nil
	}
	beginTime, e := strconv.ParseInt(req.BeginTime, 10, 64)
	if e != nil {
		logger.Errorf("parse begin time from str fail, e: %v, beginTm: %v", e, req.BeginTime)
		rsp.Status = Fail
		return nil
	}
	endTime, e := strconv.ParseInt(req.EndTime, 10, 64)
	if e != nil {
		logger.Errorf("parse end time from str fail, e: %v, beginTm: %v", e, req.BeginTime)
		rsp.Status = Fail
		return nil
	}
	if beginTime <= 0 || endTime <= 0 {
		logger.Errorf("input param time is invalid, req: %v", req.String())
		rsp.Status = Fail
		return nil
	}
	//通过rpc 获取
	dataReplayReq := &client.DeviceTimeScope{
		BeginTime: beginTime,
		EndTime:   endTime,
	}

	data := &client.DeviceTypeList{}
	err := NewDataReplay().DataReplayDevList(ctx, dataReplayReq, data)
	if err != nil {
		logger.Errorf("call DataReplay service fail, e: %v", err)
		rsp.Status = Fail
		return nil
	}

	for i := 0; i < len(data.DevList); i++ {
		rsp.List = append(rsp.List, &client.ReplayDeviceListItem{
			Sn:         data.DevList[i].SN,
			DeviceType: data.DevList[i].DevType,
		})
	}

	logger.Infof("call GetDeviceTypeList() ret: %v", rsp.String())
	return nil
}

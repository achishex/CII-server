package handler

import (
	"bytes"
	"context"
	"crypto/rand"
	"encoding/binary"
	"errors"
	"fmt"
	"math/big"
	"strconv"
	"strings"
	"sync"
	"time"

	"adasgitlab.autel.com/tools/cuav_plugin/broker"
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/slink_proto/slinkv1"

	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/server"
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/ip"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/proto/mavlink"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"

	"google.golang.org/protobuf/proto"
)

const (
	GunsPlatformTcpPort        = 15000
	GunsPlatformServerMaxCount = 500
)

type GunsPlatform struct {
	*Device
	dt common.DeviceType
}

var _ DeviceIfer = (*GunsPlatform)(nil)

// SetDevice 要使用GetOnLineDev 接口，必须要给该设备实现 DeviceIfer 接口
func (tg *GunsPlatform) SetDevice(d *Device) {
	tg.Device = d
}

var (
	GunsPlatformTcpServerLock sync.Mutex
	GunsPlatformTcpServerMap  sync.Map
	GunsPlatformHeartSum      uint8 = 0
)

func NewGunsPlatform(conn Connection, d []byte, dataLen int, remoteIp string, remotePort int, localIp string, serverPort int,
	mailBox map[int]*WaitTaskManager, dlimit *devLimit) DeviceInterface {
	gunsPlatform := &GunsPlatform{
		Device: &Device{
			Conn:        conn,
			Msg:         d,
			MsgLen:      dataLen,
			SourceId:    d[mavlink.SenderLoc],
			RemoteIp:    remoteIp,
			RemotePort:  remotePort,
			LocalIp:     localIp,
			ServerPort:  serverPort,
			WaitTaskMap: mailBox,
		},
	}

	//if len(d) <= mavlink.MsgIdLoc+1 {
	//	return GunsPlatform
	//}
	//monitoring.DevCounterMetricHandle.Inc(int(common.DEV_HUNTER_PLATFORM),
	//	GetSnByPort(GunsPlatform.ServerPort), TranIntToHex(int(d[mavlink.MsgIdLoc])))
	return gunsPlatform
}
func (d *GunsPlatform) Deal() {
	defer func() {
		if err := recover(); err != nil {
			logger.Error("GunsPlatform deal 接收到panic:", err)
		}
	}()

	if d.MsgLen <= 0 {
		logger.Error("GunsPlatform 数据为null,不作处理:", d.Device.RemoteIp)
		return
	}
	d.MsgId = int(d.Msg[mavlink.MsgIdLoc])
	switch d.MsgId {
	case mavlink.GunsPlatformHeartMsg:
		d.Heart()
	case mavlink.GunsPlatformDetectMsg:
		d.ReceiveGunsPlatformDetectMsg()
	case mavlink.GunsPlatformHitStatusMsg:
		d.ReceiveGunsPlatformHitStatusMsg()
	case mavlink.GunsPlatformGetVersion:
		d.ReceiveGunsPlatformGetVersion()
	case mavlink.GunsPlatformGetGNSS:
		d.ReceiveGunsPlatformGetGNNS()
	case mavlink.GunsPlatformSetGNSS:
		d.ReceiveGunsPlatformSetGNNS()
	case mavlink.GunsPlatformGetHitPith:
		d.ReceiveGunsPlatformGetHitPith()
	case mavlink.GunsPlatformGetHitAngle:
		d.ReceiveGunsPlatformGetHitAngle()
	case mavlink.GunsPlatformGetHitMode:
		d.ReceiveGunsPlatformGetHitMode()
	case mavlink.GunsPlatformReset:
		d.ReceiveGunsPlatformReset()
	case mavlink.GunsPlatformSendHitUav:
		d.ReceiveGunsPlatformGetHitUav()

	case mavlink.GunsPlatformSetOnOff:
		d.ReceiveGunsPlatformSetOnOff()

	case mavlink.GunsPlatformGetOnOff:
		d.ReceiveGunsPlatformGetOnOff()
	case mavlink.GunsPlatformSetPith:
		d.ReceiveGunsPlatformSetPith()
	case mavlink.GunsPlatformSetAngle:
		d.ReceiveGunsPlatformSetAngle()
	case mavlink.GunsPlatformStopHit:
		d.ReceiveGunsPlatformStopHit()
	case mavlink.GunsPlatformSetHitMode:
		d.ReceiveGunsPlatformSetHitMode()
	case mavlink.GunsPlatformSetAutoHitMode:
		d.ReceiveGunsPlatformSetAutoHitMode()
	case mavlink.GunsPlatformGetAutoHitMode:
		d.ReceiveGunsPlatformGetAutoHitMode()
	case mavlink.GunsPlatformHitTurn:
		d.ReceiveGunsPlatformTurnHit()
	case mavlink.GunsPlatformHorizontalTurn:
		d.ReceiveGunsPlatformHorizontalTurn()
	case mavlink.GunsPlatformVerticalTurn:
		d.ReceiveGunsPlatformVerticalTurn()
	case mavlink.GunsPlatformCrashStop:
		d.ReceiveGunsPlatformCrashStop()
	case mavlink.GunsPlatformIdUpgradeF1:
		d.ReceiveGunCloudUpdateF1()
	case mavlink.GunsPlatformIdUpgradeF2:
		d.ReceiveGunCloudUpdateF2()
	case mavlink.GunsPlatformIdUpgradeF3:
		d.ReceiveGunCloudUpdateF3()
	case mavlink.GunsPlatformSetPreciseHit:
		d.ReceiveSetPreciseHit()
	case mavlink.GunsPlatformGetPreciseHit:
		d.ReceiveGetPreciseHit()
	case mavlink.GunsPlatformGetFreqList:
		d.ReceiveGetFreqList()
	case mavlink.GunsPlatformGetFreqCmd:
		d.ReceiveGetFreqCmd()
	case mavlink.GunsPlatformSendFreqData:
		d.ReceiveSendFreqData()
	case mavlink.GunsPlatformSetNoise:
		d.ReceiveSetNoise()
	case mavlink.GunsPlatformSendTimeFreq:
		d.ReceiveGunsPlatformSendTimeFreq()
	case mavlink.GunsPlatformRadarChartMsg:
		d.ReceiveGunsPlatformRadarChartMsg()
	case mavlink.GunsPlatformSendNoiseDataD6:
		d.ReceiveGunsPlatformSendTimeFreqD6()
	case mavlink.GunsPlatformSendNoiseData:
		d.ReceiveGunsPlatformSendNoiseData()
	case mavlink.GunsPlatformSetInvalidFreqList:
		d.ReceiveSetInvalid()
	case mavlink.GunsPlatformGetInvalidFreqList:
		d.ReceiveGetInvalidList()
	case mavlink.GunsPlatformSetAutoRadius:
		d.ReceiveGunsPlatformSetAutoRadius()
	case mavlink.GunsPlatformGetAutoRadius:
		d.ReceiveGunsPlatformGetAutoRadius()
	case mavlink.GunsPlatformSetSwitchParam:
		d.ReceiveGunsPlatformSetSwitchParameter()
	case mavlink.GunsPlatformGetSwitchParam:
		d.ReceiveGunsPlatformGetSwitchParameter()
	default:
		logger.Error("GunsPlatform 未知GunsPlatform消息id:", d.MsgId)
		break
	}
}

// HandleBroadCast 处理广播消息
func (d *GunsPlatform) HandleBroadCast(ctx context.Context, req *slinkv1.UdpBroadcastConfirmRequest) (*slinkv1.UdpBroadcastConfirmResponse, error) {
	if req.GetSn() == "" {
		logger.Info("device sn empty")
		return nil, errors.New("device sn empty")
	}
	//d.GetStatus(req.GetSn())
	//if status := d.GetStatus(req.GetSn()); status == common.DeviceDisenable {
	//	logger.Infof("device %v disable", req.GetSn())
	//	return nil, nil
	//}

	localIP := make([]string, 0)
	localIps, broadIps, err := ip.GetBroadcastAddress()
	if err != nil {
		logger.Error("Get IP error :%v", err)
	}
	for i, ip := range localIps {
		if i >= len(broadIps) {
			continue
		}
		localIP = append(localIP, ip)
	}
	logger.Debugf("[GunsPlatform] localIP:%v,", localIP)

	tcpServer := d.TcpServerCheck(req.GetSn(), localIP)
	DevSnMap.Store(tcpServer.Port, req.GetSn())
	d.ServerPort = tcpServer.Port

	//响应
	rsp := &slinkv1.UdpBroadcastConfirmResponse{
		Sn:       req.Sn,
		Addr:     ip.IPV4(tcpServer.Ip),
		Port:     uint16(tcpServer.Port),
		ConnType: 1,
	}
	return rsp, nil
}

func (d *GunsPlatform) ReceiveGunsPlatformRadarChartMsg() {
	hit := &mavlink.GunsPlatformRadarChart{}
	if err := d.UnmarshalPayloadGunsPlatformRadarChart(hit); err != nil {
		logger.Errorf(err.Error())
		return
	}

	devSn := ByteToString(hit.Info.Sn[:])
	if devSn != "" {
		d.GunsPlatformRadarChartReport(devSn, hit)
	}
	logger.Info("--->End Receive GunsPlatform Radar Chart")
}
func (d *GunsPlatform) UnmarshalPayloadGunsPlatformRadarChart(data *mavlink.GunsPlatformRadarChart) error {
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("sfl UnmarshalPayloadGunsPlatformRadarChart write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("sfl UnmarshalPayloadGunsPlatformRadarChart read data err: %v", err)
	}

	return nil
}
func (d *GunsPlatform) GunsPlatformRadarChartReport(devSn string, chartInfo *mavlink.GunsPlatformRadarChart) {

	dataInfo := &client.GunsPlatformRadarChartInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      devSn,
			Sn:        devSn,
			EquipType: int32(common.DEV_HUNTER_PLATFORM),
			MsgType:   mavlink.GunsPlatformRadarChartMsg,
		},
		Data: &client.GunsPlatformRadarChartSocketInfo{
			Sn:           devSn,
			TimeStamp:    int64(chartInfo.Info.TimeStamp),
			StartAngle:   float64(chartInfo.Info.StartAngle) / SflChartTion,
			EndAngle:     float64(chartInfo.Info.EndAngle) / SflChartTion,
			AmpMean:      float64(chartInfo.Info.DxPower),
			GunDirection: float64(chartInfo.Info.DirectionAngle) / SflChartTion,
			Status:       uint32(chartInfo.Info.Status),
			TargetAngle:  float64(chartInfo.Info.TargetAngle) / SflChartTion,
		},
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIdGunsPlatformRadarChart,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}
	_ = mq.GunsPlatformMsgBroker.Publish(mq.GunsPlatformTopic, broker.NewMessage(out))
	logger.Infof("GunsPlatform RadarChart has reported, devSn: %v report:%v", devSn, report)
}
func (d *GunsPlatform) ReceiveGunsPlatformSendTimeFreqD6() {
	timeFreq := &mavlink.GunsPlatformTimeFreqDataD6{}
	err := timeFreq.Deserialize(d.Msg)
	if err != nil {
		logger.Error("timeFreq deserialize D6 got err: %v", err)
		return
	}
	sn := ""
	idx := bytes.IndexByte(timeFreq.SnName[:], 0)
	if idx == -1 {
		idx = len(timeFreq.SnName)
	}
	sn = string(timeFreq.SnName[:idx])
	if timeFreq.FrameIdx == 0 {
		timeFreqMap.Reset(sn)
	}
	timeFreqMap.Write(sn, timeFreq.Data)
	logger.Infof("receive GunsPlatform TimeFreqDataD6, sn: %v, frameIdx: %v, frameNum: %v", sn, timeFreq.FrameIdx, timeFreq.FrameNum)
	if timeFreq.FrameIdx == timeFreq.FrameNum-1 {
		content := timeFreqMap.ReadAll(sn)
		logger.Infof("GunsPlatform TimeFreqDataD6 content length: %v, sn: %v", len(content), sn)
		if len(content) != 76800 {
			logger.Errorf("GunsPlatform TimeFreqDataD6 content length is not 77312, sn: %v", sn)
			return
		}
		arr := make([]int32, 0)
		for i, _ := range content {
			if i%2 == 0 {
				tmp := binary.LittleEndian.Uint16(content[i : i+2])
				arr = append(arr, int32(int16(tmp)))
			}
		}
		data := &client.GunsPlatformTimeFreqDataD6{
			Sn:       sn,
			Freq:     timeFreq.Freq,
			TrackBws: timeFreq.TrackBws,
			TrackBwe: timeFreq.TrackBwe,
			Data:     arr,
		}
		payload, _ := proto.Marshal(data)
		report := &client.ClientReport{
			MsgType: common.ClientMsgIDGunsPlatformFreqDataD6,
			Data:    payload,
		}
		out, err := proto.Marshal(report)
		if err != nil {
			logger.Error("GunsPlatformTimeFreqDataD6 marshal client report got error: %v", err)
			return
		}
		_ = mq.GunsPlatformMsgBroker.Publish(mq.GunsPlatformTopic, broker.NewMessage(out))
		logger.Infof("send GunsPlatformTimeFreqDataD6 to client, sn: %v", sn)
	}
}
func (d *GunsPlatform) ReceiveGunsPlatformSendNoiseData() {
	timeFreq := &mavlink.GunsPlatformTimeFreqData{}
	err := timeFreq.Deserialize(d.Msg)
	if err != nil {
		logger.Error("timeFreq deserialize got err: %v", err)
		return
	}
	sn := ""
	idx := bytes.IndexByte(timeFreq.SnName[:], 0)
	if idx == -1 {
		idx = len(timeFreq.SnName)
	}
	sn = string(timeFreq.SnName[:idx])
	if timeFreq.FrameIdx == 0 {
		timeFreqMap.Reset(sn)
	}
	timeFreqMap.Write(sn, timeFreq.Data)
	logger.Infof("receive GunsPlatformTimeFreqData, sn: %v, frameIdx: %v, frameNum: %v", sn, timeFreq.FrameIdx, timeFreq.FrameNum)
	if timeFreq.FrameIdx == timeFreq.FrameNum-1 {
		content := timeFreqMap.ReadAll(sn)
		logger.Infof("GunsPlatformTimeFreqData content length: %v, sn: %v", len(content), sn)
		if len(content) != 768512 {
			logger.Errorf("GunsPlatformTimeFreqData content length is not 768512, sn: %v", sn)
			return
		}
		arr := make([]int32, 0)
		for i, _ := range content {
			if i%2 == 0 {
				tmp := binary.LittleEndian.Uint16(content[i : i+2])
				arr = append(arr, int32(int16(tmp)))
			}
		}
		data := &client.GunsPlatformTimeFreqData{
			Sn:   sn,
			Data: arr,
		}
		payload, _ := proto.Marshal(data)
		report := &client.ClientReport{
			MsgType: common.ClientMsgIDGunsPlatformFreqData,
			Data:    payload,
		}
		out, err := proto.Marshal(report)
		if err != nil {
			logger.Error("GunsPlatformTimeFreqData marshal client report got error: %v", err)
			return
		}
		_ = mq.GunsPlatformMsgBroker.Publish(mq.GunsPlatformTopic, broker.NewMessage(out))
		logger.Infof("send GunsPlatformTimeFreqData to client, sn: %v", sn)
	}
}

func (d *GunsPlatform) ReceiveSendFreqData() {
	logger.Infof("receive GunsPlatform collect data")
	collectStatus := &mavlink.GunsPlatformTimeFreqCollectReport{}

	// dev sn; 25 bytes
	readBegin := mavlink.HeaderLen
	offset := mavlink.DevSNLen
	readEnd := readBegin + offset
	err := mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, &collectStatus.SN, offset)
	devSn := ByteToString(collectStatus.SN[:])
	if devSn == "" {
		logger.Errorf("collect report dev sn is empty")
		return
	}
	d.updateStatus(devSn, 0)
	// status; 26 bytes
	readBegin = readEnd
	offset = 1
	readEnd = readBegin + offset
	err = mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, &collectStatus.Status, offset)
	logger.Debugf("sn: %v, status: %v", devSn, collectStatus.Status)

	if !sessionCollMng.IsBegin(devSn) {
		logger.Errorf("sn: %v not been triggered by client cmd; send stop cmd to history collect data.", devSn)
		d.closeCollect(devSn)
		return
	}

	sessionCollMng.UpdateTime(devSn)

	if collectStatus.Status == DEV_COLLECT_STATUS_ERR {

		var paramOne uint32 = 0
		readBegin = readEnd
		offset = 4
		readEnd = readBegin + offset
		err = mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, &paramOne, offset)

		logger.Infof("receive fail status, sn: %v, err code: %v", devSn, paramOne)

		d.procCollectErrStatus(devSn, paramOne)
		return
	}

	if !sessionCollMng.CheckCurrentReceiveStatus(devSn, int32(collectStatus.Status)) {
		logger.Errorf("sn: %v, receive status: %v not fit for cur status.", devSn, collectStatus.Status)
		return
	}

	if collectStatus.Status <= DEV_COLLECT_STATUS_GZIPING {
		procStatus := ReportCollectStatusIng
		if collectStatus.Status == DEV_COLLECT_STATUS_GZIPING {
			procStatus = ReportCollectGzip
		}
		fileSz, receivedSz, fileName := sessionCollMng.GetFileParameters(devSn)
		logger.Infof("filesz: %v, receivesz: %v, sn: %v", fileSz, receivedSz, devSn)
		d.reportCollectStatus(devSn, procStatus, fileName, receivedSz, fileSz, 0)
		return
	}

	// 开始上传，上传中，上传完成， 30 bytes
	var paramOne uint32 = 0
	readBegin = readEnd
	offset = 4
	readEnd = readBegin + offset
	err = mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, &paramOne, offset)

	//文件大小
	if collectStatus.Status == DEV_COLLECT_STATUS_UPLOAD_BEGIN {
		collectStatus.ParamOne = paramOne
		logger.Debugf("sn: %v, file size: %v", devSn, paramOne)
		sessionCollMng.UpdateFileSize(devSn, paramOne) // 记录文件大小

		fileSz, receivedSz, fileName := sessionCollMng.GetFileParameters(devSn)
		logger.Infof("filesz: %v, receivesz: %v, sn: %v", fileSz, receivedSz, devSn)
		d.reportCollectStatus(devSn, ReportCollectTraning, fileName, receivedSz, fileSz, 0)
		return
	}

	if collectStatus.Status == DEV_COLLECT_STATUS_UPLOAD_ING {
		// 最大分包数
		collectStatus.ParamOne = paramOne
		logger.Debugf("sn: %v, max package nums: %v", devSn, paramOne)

		// 分包序列号
		readBegin = readEnd
		offset = 4
		readEnd = readBegin + offset
		err = mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, &collectStatus.PkgIndex, offset)
		logger.Debugf("sn: %v, pkg index: %v", devSn, collectStatus.PkgIndex)

		// 发送数据长度
		readBegin = readEnd
		offset = 4
		readEnd = readBegin + offset
		err = mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, &collectStatus.DataLen, offset)
		logger.Debugf("sn: %v, pkg data len: %v", devSn, collectStatus.DataLen)
		sessionCollMng.UpdateReceiveFileSz(devSn, collectStatus.DataLen)

		// 数据内容
		readBegin = readEnd
		offset = int(collectStatus.DataLen)
		readEnd = readBegin + offset
		collectStatus.Data = make([]byte, offset)

		err = mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, collectStatus.Data, offset)
		if err != nil {
			logger.Errorf("msg decode data pkg fail,sn: %v,e: %v", devSn, err)
			return
		}

		fileSz, receivedSz, fileName := sessionCollMng.GetFileParameters(devSn)
		logger.Infof("filesz: %v, receivesz: %v, sn: %v", fileSz, receivedSz, devSn)
		d.reportCollectStatus(devSn, ReportCollectTraning, fileName, receivedSz, fileSz, 0)
		err := sessionCollMng.WriteBuffToFile(devSn, collectStatus.Data)
		if err != nil {
			logger.Errorf("write data to buf fail, sn: %v, pkgIndex: %v, maxPkgNums: %v",
				devSn, collectStatus.PkgIndex, collectStatus.ParamOne)
			return
		}

		if collectStatus.PkgIndex < collectStatus.ParamOne-1 {
			logger.Debugf("is not full pkg, sn: %v, maxPkgNums: %v, curPkgIndex: %v, cur pkg len: %v",
				devSn, collectStatus.ParamOne, collectStatus.PkgIndex, collectStatus.DataLen)
			return
		}
		logger.Infof("receive complete package, sn: %v, cur pkgIndex: %v, maxPkgNums: %v",
			devSn, collectStatus.PkgIndex, collectStatus.ParamOne)
		return
	}

	if collectStatus.Status == DEV_COLLECT_STATUS_UPLOAD_END {
		logger.Infof("receive collect done : %v, sn: %v", DEV_COLLECT_STATUS_UPLOAD_END, devSn)
		d.receiveDonePkgProc(devSn)
	}
}

// procCollectErrStatus 注销设备sn collection session, 上报错误
func (d *GunsPlatform) procCollectErrStatus(sn string, errCode uint32) {
	if sn == "" {
		return
	}
	fileSz, receivedSz, fileName := sessionCollMng.GetFileParameters(sn)
	logger.Infof("filesz: %v, receivesz: %v, sn: %v", fileSz, receivedSz, sn)
	sessionCollMng.UnRegister(sn)
	d.reportCollectStatus(sn, ReportCollectStatusFail, fileName, receivedSz, fileSz, errCode)
}

// receiveDonePkgProc 完整包后逻辑处理： 写文件，删除状态机
func (d *GunsPlatform) receiveDonePkgProc(devSn string) {
	fileSz, receivedSz, fileName := sessionCollMng.GetFileParameters(devSn)
	logger.Infof("filesz: %v, receivesz: %v, sn: %v", fileSz, receivedSz, devSn)
	sessionCollMng.UnRegister(devSn)
	d.reportCollectStatus(devSn, ReportCollectStatusDone, fileName, receivedSz, fileSz, 0)
	logger.Info("--->End Receive tracer collection data")
}
func (d *GunsPlatform) ReceiveGetFreqCmd() {
	logger.Info("-->into Receive GunsPlatform SetFreqCmd")
	res := &mavlink.GunsPlatformSetFreqCmdResponse{}
	d.GetPacket(res)
	logger.Debugf("GunsPlatform Set FreqCmd Get ：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformGetFreqCmd]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}
func (d *GunsPlatform) UnmarshalFreqDetectNodeList(data *mavlink.GunsPlatformFreqDetectNodeListResponse) error {
	buf := new(bytes.Buffer)
	if e := binary.Write(buf, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); e != nil {
		return fmt.Errorf("parse GunsPlatformFreqDetectNodeListResponse fail, e: %v", e)
	}

	if e := binary.Read(buf, binary.LittleEndian, &data.FreqNums); e != nil {
		return fmt.Errorf("parse GunsPlatformFreqDetectNodeListResponse.freqNums fail, e: %v", e)
	}

	if data.FreqNums <= 0 {
		return nil
	}

	start := mavlink.HeaderLen + binary.Size(data.FreqNums)
	end := d.MsgLen - mavlink.CrcLen
	buffer2 := new(bytes.Buffer)
	if e := binary.Write(buffer2, binary.LittleEndian, d.Msg[start:end]); e != nil {
		return fmt.Errorf("parse GunsPlatformFreqDetectNodeListResponse fail, e: %v", e)
	}
	for i := 0; i < int(data.FreqNums); i++ {
		var freqValue uint32 = 0
		if err := binary.Read(buffer2, binary.LittleEndian, &freqValue); err != nil {
			return fmt.Errorf("parse freq node list value fail, e: %v", err)
		}
		data.FreqList = append(data.FreqList, freqValue)
	}
	return nil
}
func (d *GunsPlatform) ReceiveGetFreqList() {
	res := &mavlink.GunsPlatformFreqDetectNodeListResponse{}
	if err := d.UnmarshalFreqDetectNodeList(res); err != nil {
		logger.Errorf("parse freq detect node list response fail, e: %v", err)
		return
	}
	logger.Debugf("receive Send FreqDetectNodeList：%+v", *res)
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformGetFreqList]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}
func (d *GunsPlatform) ReceiveSetNoise() {
	logger.Info("-->into Receive GunsPlatform SetNoise")
	res := &mavlink.GunsPlatformSetNoiseResponse{}
	d.GetPacket(res)
	logger.Debugf("GunsPlatform Set Noise Get ：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformSetNoise]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *GunsPlatform) ReceiveGunsPlatformSendTimeFreq() {
	timeFreq := &mavlink.GunsPlatformTimeFreqData{}
	err := timeFreq.Deserialize(d.Msg)
	if err != nil {
		logger.Error("timeFreq deserialize got err: %v", err)
		return
	}
	sn := ""
	idx := bytes.IndexByte(timeFreq.SnName[:], 0)
	if idx == -1 {
		idx = len(timeFreq.SnName)
	}
	sn = string(timeFreq.SnName[:idx])
	if timeFreq.FrameIdx == 0 {
		timeFreqMap.Reset(sn)
	}
	timeFreqMap.Write(sn, timeFreq.Data)
	logger.Infof("receive GunsPlatformTimeFreqData, sn: %v, frameIdx: %v, frameNum: %v", sn, timeFreq.FrameIdx, timeFreq.FrameNum)
	if timeFreq.FrameIdx == timeFreq.FrameNum-1 {
		content := timeFreqMap.ReadAll(sn)
		logger.Infof("GunsPlatformTimeFreqData content length: %v, sn: %v", len(content), sn)
		if len(content) != 76800 {
			logger.Errorf("GunsPlatformTimeFreqData content length is not 768512, sn: %v", sn)
			return
		}
		arr := make([]int32, 0)
		for i, _ := range content {
			if i%2 == 0 {
				tmp := binary.LittleEndian.Uint16(content[i : i+2])
				arr = append(arr, int32(int16(tmp)))
			}
		}
		data := &client.GunsPlatformTimeFreqData{
			Sn:   sn,
			Data: arr,
		}
		payload, _ := proto.Marshal(data)
		report := &client.ClientReport{
			MsgType: common.ClientMsgIDGunsPlatformTimeFreqData,
			Data:    payload,
		}
		out, err := proto.Marshal(report)
		if err != nil {
			logger.Error("GunsPlatformTimeFreqData marshal client report got error: %v", err)
			return
		}
		_ = mq.GunsPlatformMsgBroker.Publish(mq.GunsPlatformTopic, broker.NewMessage(out))
		logger.Infof("send GunsPlatformTimeFreqData to client, sn: %v", sn)
	}
}

// closeCollect 发送关闭收集收集
func (d *GunsPlatform) closeCollect(sn string) (int32, error) {
	logger.Info("---> Send closeCollect: ", CollectDataToDevEnd)

	req := &mavlink.GunsPlatformSetFreqCmdRequest{}
	buff := req.Create(CollectDataToDevEnd)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformGetFreqCmd]
	if !ok {
		manager = NewWaitTaskManager(mavlink.GunsPlatformGetFreqCmd, true, 0)
		d.WaitTaskMap[mavlink.GunsPlatformGetFreqCmd] = manager
	}
	task := manager.AddTask(nil, nil)
	logger.Debugf("Send GunsPlatform closeCollect is :[% x]", buff)

	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send GunsPlatform closeCollect err:[%v].Buff is [%v]", err, buff)
		manager.DeleteTask(task.TaskId)
		return 0, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send GunsPlatform closeCollect err %s", err.Error())
		return 0, err
	}
	defer func() {
		sessionCollMng.UnRegister(sn)
	}()

	res := result.(*mavlink.GunsPlatformSetFreqCmdResponse)

	logger.Info("-->End closeCollect")
	return int32(res.Status), nil
}

// reportCollectStatus 上报数据收集状态
func (d *GunsPlatform) reportCollectStatus(devSn string, status uint32, fName string, receiveFileSz uint32, totalFileSz uint32, errCode uint32) {
	if status != ReportCollectStatusFail {
		errCode = 0
	}
	msgProto := &client.GunsPlatformCollectDataReport{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      devSn,
			Sn:        devSn,
			MsgType:   mavlink.GunsPlatformSendFreqData,
			EquipType: int32(common.DEV_HUNTER_PLATFORM),
		},

		Data: &client.GunsPlatformCollectInfo{
			Status:          status,
			FileName:        fName,
			ReceiveFileSize: receiveFileSz,
			FileTotalSize:   totalFileSz,
			ErrCode:         errCode,
		},
	}
	msgProtoBin, e := proto.Marshal(msgProto)
	if e != nil {
		logger.Errorf("marshal collection status  fail, e: %v", e)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgIDGunsPlatformCollectData,
		Data:    msgProtoBin,
	}
	out, e := proto.Marshal(report)
	if e != nil {
		logger.Errorf("marshal report data fail, e: %v", e)
		return
	}

	e = mq.GunsPlatformMsgBroker.Publish(mq.GunsPlatformTopic, broker.NewMessage(out))
	if e != nil {
		logger.Errorf("push msg on topic: %v fail", mq.GunsPlatformTopic)
		return
	}
	logger.Infof("send report, value: +%v", msgProto)
}

// collectTaskTimeoutCB 检测定时器检测到已经开始的数据收集任务超时
func (d *GunsPlatform) collectTaskTimeoutCB(sn string) {
	fileSz, receivedSz, fileName := sessionCollMng.GetFileParameters(sn)
	logger.Infof("filesz: %v, receivesz: %v, sn: %v", fileSz, receivedSz, sn)
	logger.Infof("collect task time out callback proc, sn: %v, send stop to dev", sn)
	d.closeCollect(sn)
	sessionCollMng.UnRegister(sn)
	d.reportCollectStatus(sn, ReportCollectStatusFail, fileName, receivedSz, fileSz, 11)
}

// openCollect 发送打开数据收集
func (d *GunsPlatform) openCollect(sn string, fileName string) (int32, error) {
	sessionCollMng.UnRegister(sn)

	s := &ClientCollectSession{}
	sessionCollMng.Register(sn, fileName, d.collectTaskTimeoutCB, s.InitSession, CollectDataToDevEnd)

	logger.Info("---> Send openCollect: ", CollectDataToDevBegin)
	req := &mavlink.GunsPlatformSetFreqCmdRequest{}
	buff := req.Create(CollectDataToDevBegin)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformGetFreqCmd]
	if !ok {
		manager = NewWaitTaskManager(mavlink.GunsPlatformGetFreqCmd, true, 0)
		d.WaitTaskMap[mavlink.GunsPlatformGetFreqCmd] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Send GunPlatform setOpenCollect is :[% x]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send GunPlatform setOpenCollect err:[%v].Buff is [%v]", err, buff)
		sessionCollMng.UnRegister(sn)
		return 0, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send GunPlatform setOpenCollect err %s", err.Error())
		sessionCollMng.UnRegister(sn)
		return 0, err
	}

	// 只有等设备有响应才进行后续的动作。
	sessionCollMng.StartSession(sn)

	res := result.(*mavlink.GunsPlatformSetFreqCmdResponse)

	logger.Info("-->End openCollect")
	return int32(res.Status), nil
}

// SendSetFreqCmd 发送设置频点
func (d *GunsPlatform) SendSetFreqCmd(sn string, op int32, fileName string) (int32, error) {
	logger.Info("-->into Send GunsPlatform Set Freq Cmd  msg,req:", sn, op, fileName)
	var (
		status int32 = 0
		err    error
	)

	if op == CollectDataTracerOpen {
		if len(fileName) == 0 {
			return 0, errors.New("file name is empty on open")
		}
		status, err = d.openCollect(sn, fileName)

	} else if op == CollectDataTracerEnd {
		status, err = d.closeCollect(sn)

	} else {
		return 0, errors.New("not support op")
	}
	return status, err
}
func (d *GunsPlatform) SendGetFreqNodeList() ([]uint32, error) {
	logger.Info("---> Send SendGetFreqNodeList")
	req := &mavlink.GunsPlatformFreqDetectNodeListRequest{}
	buff := req.Create(0)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformGetFreqList]
	if !ok {
		manager = NewWaitTaskManager(mavlink.GunsPlatformGetFreqList, true, 0)
		d.WaitTaskMap[mavlink.GunsPlatformGetFreqList] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Send SendGetFreqNodeList is :[% x]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send SendGetFreqNodeList err:[%v].Buff is [% x]", err, buff)
		return nil, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send SendGetFreqNodeList err %s", err.Error())
		return nil, err
	}
	res := result.(*mavlink.GunsPlatformFreqDetectNodeListResponse)

	logger.Info("-->End SendGetFreqNodeList")
	return res.FreqList, nil
}
func (d *GunsPlatform) SendSetNoise(request *client.GunsPlatformSetNoiseRequest) (int, error) {
	logger.Info("-->into Send Send GunsPlatform Set Noise  msg")
	//获取开关机状态
	req := &mavlink.GunsPlatformSetNoiseRequest{}
	buff := req.Create(uint32(request.Mode), uint32(request.Freq))
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Send gun platform Set Noise info err: %v", err)
		return Fail, fmt.Errorf("request Send gun platform Set Noise info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformSetNoise]
	if !ok {
		manager = NewWaitTaskManager(mavlink.GunsPlatformSetNoise, true, 0)
		d.WaitTaskMap[mavlink.GunsPlatformSetNoise] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("requestSend gun platform Set Noise info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.GunsPlatformSetNoiseResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Send gun platform Set Noise result:%+v", *res)

	return int(res.Status), nil
}
func (d *GunsPlatform) ReceiveGetChannelReq() {
	GunsPlatformTcpServerLock.Lock()
	defer GunsPlatformTcpServerLock.Unlock()

	devSn := d.UnMarshalGetChannelReq()
	if devSn == "" {
		logger.Info("GunsPlatform device sn empty")
		return
	}

	//if isContinue := d.deviceDiscover(devSn); !isContinue {
	//	logger.Error("droneID等待设备确认：", devSn)
	//	return
	//}
	//d.GetStatus(devSn)
	//if status := d.GetStatus(devSn); status == common.DeviceDisenable {
	//	logger.Infof("GunsPlatform device %v disable", devSn)
	//	return
	//}

	localIP := make([]string, 0)

	localIps, broadIps, err := ip.GetBroadcastAddress()
	if err != nil {
		logger.Error("GunsPlatform Get IP error :%v", err)
	}
	for i, ip := range localIps {
		if i >= len(broadIps) {
			continue
		}
		localIP = append(localIP, ip)
	}
	logger.Debugf("[GunsPlatform] localIP:%v,", localIP)

	tcpServer := d.TcpServerCheck(devSn, localIP)
	DevSnMap.Store(tcpServer.Port, devSn)
	d.ServerPort = tcpServer.Port

	//响应
	switch d.MsgId {
	case mavlink.GunsPlatformUdpBroadcastResponse:
		logger.Info("[GunsPlatform] receive Broadcast BB Msg")
		UdpBroadcastSendChannel(devSn, d.UdpIp, d.SourceId, tcpServer)
		break
	default:
		break
	}

	return
}

func (d *GunsPlatform) TcpServerCheck(devSn string, localIP []string) *server.TcpServer {
	var tcpServer *server.TcpServer
	if s, ok := GunsPlatformTcpServerMap.Load(devSn); ok {
		tcpServer = s.(*server.TcpServer)
		isAlike := false
		for _, ip := range localIP {
			if ip == tcpServer.Ip {
				isAlike = true
			}
		}
		if isAlike == false { //查找的本地IP没有与之前相同的
			if tcpServer != nil {
				tcpServer.Stop()
			}
			deviceUsedPorts.Delete(tcpServer.Port)
			GunsPlatformTcpServerMap.Delete(devSn)
			DevSnMap.Delete(tcpServer.Port)
			tcpServer = nil
		}
	}

	//注册tcp服务
	if tcpServer == nil {
		port, err := ip.GetFreeTcpPort()
		if err != nil {
			logger.Error("GunsPlatform tcp 获取可用端口失败：", err)
			port = d.getRandPort(GunsPlatformTcpPort, GunsPlatformTcpPort+GunsPlatformServerMaxCount)
		}
		tcpServer = server.NewTcpServer(port, Handle)
		GunsPlatformTcpServerMap.Store(devSn, tcpServer)
		tcpServer.ServerType = uint8(common.DEV_HUNTER_PLATFORM)
		tcpServer.ServerName = devSn
		localAddr, _ := ip.GetLocalIp(d.UdpIp)
		tcpServer.Ip = localAddr
		go tcpServer.Start()
	}
	return tcpServer
}

func (d *GunsPlatform) getRandPort(min, max int64) int {
	maxBigInt := big.NewInt(max)
	i, _ := rand.Int(rand.Reader, maxBigInt)
	_, ok := deviceUsedPorts.Load(i.Int64())
	port := i.Int64()
	//缓存不存在或者符合范围
	if !ok && (port > min && port < max) {
		deviceUsedPorts.Store(port, port)
		return int(port)
	}
	return d.getRandPort(min, max)
}
func (d *GunsPlatform) GetStatus(sn string, subDevType int) int32 {
	statusRes := &client.GetStatusRes{}
	err := NewEquipList().GetStatus(context.Background(), &client.GetStatusReq{Sn: sn, EType: "GunPlatform", SubDevType: int64(subDevType)}, statusRes)
	if err != nil {
		logger.Errorf("GetStatus err: %v", err.Error())
		return 0
	}

	return statusRes.IsEnable
}

func (d *GunsPlatform) UnMarshalGetChannelReq() string {
	devSn := ""
	switch d.MsgId {
	case mavlink.GunsPlatformUdpBroadcastResponse:
		req := &mavlink.UdpBroadcastConfirmRequest{}
		d.GetPacket(req)
		devSn = strings.TrimRight(string(req.Sn[:]), string(rune(0)))
		break
	default:
		break
	}
	return devSn
}
func (d *GunsPlatform) ReceiveGunsPlatformHitStatusMsg() {
	hit := &mavlink.GunsPlatformHit{}
	if err := d.UnmarshalPayloadHitInfo(hit); err != nil {
		logger.Errorf(err.Error())
		return
	}

	devSn := ByteToString(hit.Info.SN[:])
	if devSn != "" {
		// report Hit
		d.updateStatusDetect(devSn)
		//if isEnable := d.updateStatus(devSn); isEnable == common.DeviceDisenable {
		//	logger.Infof("GunsPlatform device %v disable", devSn)
		//	return
		//}
		d.HitInfoReport(devSn, hit)
	}
	logger.Info("--->End Receive GunsPlatform HitStat")
}

func (d *GunsPlatform) UnmarshalPayloadHitInfo(data *mavlink.GunsPlatformHit) error {
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("GunsPlatform UnmarshalPayloadHitInfo write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("GunsPlatform UnmarshalPayloadHitInfo read data err: %v", err)
	}

	return nil
}

func (d *GunsPlatform) HitInfoReport(devSn string, hitInfo *mavlink.GunsPlatformHit) {
	//查白名单中的无人机，在Tracer侦测结果中添加无人机角色
	whiteList := &client.ListResAll{}
	err := NewWhiteList().ListAll(context.Background(), &client.ListReqAll{}, whiteList)
	if err != nil {
		logger.Error("Get whiteList err: ", err)
		return
	}
	//1-敌军 2-友军 3-未知 4-中立     批量导入为2友军
	var role int32
	for _, info := range whiteList.WhiteList {
		if info.Sn == ByteToString(hitInfo.Info.SerialNum[:]) {
			role = info.Role
		}
	}
	if role == ERRTYPE {
		role = ENEMY
	}

	//检查无效值
	hitInfo = CheckGunInputNum(hitInfo)

	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	dataInfo := &client.GunsPlatformHitStateInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        devSn,
			EquipType: int32(common.DEV_HUNTER_PLATFORM),
			MsgType:   mavlink.GunsPlatformHitStatusMsgReport,
		},
		Data: &client.GunsPlatformHitSocketInfo{
			Sn:                 devSn,
			HitState:           int32(hitInfo.Info.HitState),
			ProductType:        int32(hitInfo.Info.ProductType),
			DroneName:          ByteToString(hitInfo.Info.DroneName[:]),
			SerialNum:          ByteToString(hitInfo.Info.SerialNum[:]),
			DroneLongitude:     float64(hitInfo.Info.DroneLongitude) / DroneTion,
			DroneLatitude:      float64(hitInfo.Info.DroneLatitude) / DroneTion,
			DroneHeight:        float64(hitInfo.Info.DroneHeight) / DroneHeightTion,
			DroneYawAngle:      float64(hitInfo.Info.DroneYawAngle) / DroneYawTion,
			DroneSpeed:         float64(hitInfo.Info.DroneSpeed) / DroneSpeedTion,
			DroneVerticalSpeed: float64(hitInfo.Info.DroneVerticalSpeed) / DroneVerticalSpeedTion,
			SpeedDirection:     int32(hitInfo.Info.SpeedDerection) / DroneSpeedTion,
			DroneSailLongitude: float64(hitInfo.Info.DroneSailLongitude) / DroneSailLongitudeTion,
			DroneSailLatitude:  float64(hitInfo.Info.DroneSailLatitude) / DroneSailLatitudeTion,
			PilotLongitude:     float64(hitInfo.Info.PilotLongitude) / DroneTion,
			PilotLatitude:      float64(hitInfo.Info.PilotLatitude) / DroneTion,
			DroneHorizon:       float64(hitInfo.Info.DroneHorizon) / DroneHorizonTion,
			DronePitch:         float64(hitInfo.Info.DronePitch) / DronePitch,
			UFreq:              float64(hitInfo.Info.UFreq) / DetectFreqTion,
			UDistance:          int32(hitInfo.Info.UDistance),
			UDangerLevels:      int32(hitInfo.Info.UDangerLevels),
			Role:               role,
		},
	}
	if err == nil {
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIDGunsPlatformHitStatus,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}
	_ = mq.GunsPlatformMsgBroker.Publish(mq.GunsPlatformTopic, broker.NewMessage(out))
	logger.Infof("GunsPlatform HitInfo has reported, devSn: %v report:%v", devSn, report)
	//统计打击时间、打击时长
	RecordGuncloudHitStatus(dataInfo.Data)
}
func RecordGuncloudHitStatus(report *client.GunsPlatformHitSocketInfo) *common.SflHitEventInfo {
	var observeHitOverUav *common.SflHitEventInfo = nil

	droneInfo, isExist := SflDetectInfoMap.Get(report.SerialNum)
	tempTime := time.Now().UnixMilli()
	if isExist && (report.HitState == HITING || report.HitState == HITOVER) {
		if report.HitState == HITING && droneInfo.HitTime == 0 { //更新打击时间
			SflDetectInfoMap.UpdateHitTime(report.SerialNum, tempTime)
			//更新数据库
			err := NewSflDetectInfo().UpdateHitTime(context.Background(), &client.SflDetectInfoUpdateReq{Sn: report.SerialNum, HitTime: tempTime}, &client.SflDetectInfoUpdateRes{})
			if err != nil {
				logger.Error("Update Sfl Detect Info err:", err)
			}
		}
		if report.HitState == HITOVER {
			//更新数据库
			counterDur := (tempTime - droneInfo.HitTime) / 1000
			err := NewSflDetectInfo().UpdateCountTime(context.Background(), &client.SflDetectInfoUpdateReq{Sn: report.SerialNum, CounterTime: counterDur}, &client.SflDetectInfoUpdateRes{})
			if err != nil {
				logger.Error("Update Sfl Detect Info hit over err:", err)
			}

			// 判断10s内无人机的状态信息
			nowTime := time.Now()
			droneInfo.CounterTime = counterDur
			observeHitOverUav = &common.SflHitEventInfo{
				UavSn:            report.SerialNum,
				Sn:               report.Sn,
				HitOverTime:      nowTime,
				DetectReportTime: nowTime,
				ProductType:      report.ProductType,
				SessionId:        GetGlobalSessionId(),
				DroneName:        report.DroneName,
				DroneLongitude:   report.DroneLongitude,
				DroneLatitude:    report.DroneLatitude,
				DroneHeight:      report.DroneHeight,
				DroneYawAngle:    report.DroneYawAngle,
			}
			logger.Infof("sfl hit over, sfl sn: %v, uav serialNum: %v, productType: %v, droneName: %v",
				report.Sn, report.SerialNum, report.ProductType, report.DroneName)

			//清空map
			SflDetectInfoMap.Clear()
		}
	}

	return observeHitOverUav
}

func (d *GunsPlatform) ReceiveGunsPlatformDetectMsg() {
	result := &mavlink.GunsPlatformDetect{}
	if err := d.UnmarshalPayloadGunsPlatformDetect(result); err != nil {
		logger.Errorf(err.Error())
		return
	}

	devSn := ByteToString(result.Info.SN[:])
	if devSn != "" {
		d.updateStatusDetect(devSn)
		//if isEnable := d.updateStatus(devSn); isEnable == common.DeviceDisenable {
		//	logger.Infof("GunsPlatform device %v disable", devSn)
		//	return
		//}
		d.GunsPlatformDetectReport(devSn, result)
	}
	logger.Info("--->End Receive GunsPlatform Detect")
}
func (d *GunsPlatform) GunsPlatformDetectReport(devSn string, detectInfo *mavlink.GunsPlatformDetect) {
	dataInfo := &client.GunsPlatformDetectSocketInfo{}
	dataInfo.List = make([]*client.GunsPlatformDetectDroneInfo, 0, len(detectInfo.Description))
	dataInfo.Sn = devSn
	dataInfo.DetectionNum = int32(detectInfo.Info.DetectionNum)
	//查白名单中的无人机，在Tracer侦测结果中添加无人机角色
	whiteList := &client.ListResAll{}
	err := NewWhiteList().ListAll(context.Background(), &client.ListReqAll{}, whiteList)
	if err != nil {
		logger.Error("Get whiteList err: ", err)
		return
	}
	//检查无效值
	for _, drone := range detectInfo.Description {
		if drone.Source == 0 {
			drone = DetectGunCheckInputNum(drone)
			//1-敌军 2-友军 3-未知 4-中立     批量导入为2友军
			var role int32
			for _, info := range whiteList.WhiteList {
				if info.Sn == ByteToString(drone.SerialNum[:]) {
					role = info.Role
				}
			}
			if role == ERRTYPE {
				role = ENEMY
			}

			var wifiMac [6]uint8
			wifiMac = drone.WifiMac
			wifiMacBytes := make([]byte, len(wifiMac))
			for i, v := range wifiMac {
				wifiMacBytes[i] = v
			}
			r := &client.GunsPlatformDetectDroneInfo{
				ProductType:        int32(drone.ProductType),
				DroneName:          ByteToString(drone.DroneName[:]),
				SerialNum:          ByteToString(drone.SerialNum[:]),
				DroneLongitude:     float64(drone.DroneLongitude) / DroneTion,
				DroneLatitude:      float64(drone.DroneLatitude) / DroneTion,
				DroneHeight:        float64(drone.DroneHeight) / DroneHeightTion,
				DroneYawAngle:      float64(drone.DroneYawAngle) / DroneYawTion,
				DroneSpeed:         float64(drone.DroneSpeed) / DroneSpeedTion,
				DroneVerticalSpeed: float64(drone.DroneVerticalSpeed) / DroneVerticalSpeedTion,
				SpeedDirection:     int32(drone.SpeedDerection) / DroneSpeedTion,
				DroneSailLongitude: float64(drone.DroneSailLongitude) / DroneSailLongitudeTion,
				DroneSailLatitude:  float64(drone.DroneSailLatitude) / DroneSailLatitudeTion,
				PilotLongitude:     float64(drone.PilotLongitude) / DroneTion,
				PilotLatitude:      float64(drone.PilotLatitude) / DroneTion,
				DroneHorizon:       float64(drone.DroneHorizon) / DroneHorizonTion,
				DronePitch:         float64(drone.DronePitch) / DronePitch,
				UFreq:              float64(drone.UFreq) / DetectFreqTion,
				UDistance:          int32(drone.UDistance),
				UDangerLevels:      int32(drone.UDangerLevels),
				Role:               role,
				UZC:                int32(drone.Uzc),
				UDirStatus:         int32(drone.UDirStatus),
				UNumber:            uint32(drone.UNumber),
				WifiMac:            wifiMacBytes,
			}
			logger.Infof("GunsPlatform Detect data: %v", r)
			dataInfo.List = append(dataInfo.List, r)
			RecordGunCloudInfo(r)
		}
	}
	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	msg := &client.GunsPlatformDetectInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        devSn,
			EquipType: int32(common.DEV_HUNTER_PLATFORM),
			MsgType:   mavlink.GunsPlatformDetectMsgReport,
		},
		Data: dataInfo,
	}
	if err == nil {
		msg.Header.ParentType = int32(equipModel.ParentType)
		msg.Header.ParentSn = equipModel.ParentSn
		msg.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msgOut, err := proto.Marshal(msg)
	if err != nil {
		logger.Error("marshal msg err:", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIDGunsPlatformDetect,
		Data:    msgOut,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	_ = mq.GunsPlatformMsgBroker.Publish(mq.GunsPlatformTopic, broker.NewMessage(out))
	logger.Infof("GunsPlatform Detect has reported, devSn: %v, Drone size: %v", devSn, msg.Data)
}
func CheckGunInputNum(info *mavlink.GunsPlatformHit) *mavlink.GunsPlatformHit {
	if info.Info.DroneLongitude == InvalidValueInt32 {
		info.Info.DroneLongitude = 0
	}
	if info.Info.DroneLatitude == InvalidValueInt32 {
		info.Info.DroneLatitude = 0
	}
	if info.Info.DroneHeight == InvalidValueInt16 {
		info.Info.DroneHeight = 0
	}
	if info.Info.DroneYawAngle == InvalidValueInt16 {
		info.Info.DroneYawAngle = 0
	}
	if info.Info.DroneSpeed == InvalidValueInt16 {
		info.Info.DroneSpeed = 0
	}
	if info.Info.DroneVerticalSpeed == InvalidValueInt16 {
		info.Info.DroneVerticalSpeed = 0
	}
	if info.Info.DroneSailLongitude == InvalidValueInt32 {
		info.Info.DroneSailLongitude = 0
	}
	if info.Info.DroneSailLatitude == InvalidValueInt32 {
		info.Info.DroneSailLatitude = 0
	}
	if info.Info.PilotLongitude == InvalidValueInt32 {
		info.Info.PilotLongitude = 0
	}
	if info.Info.PilotLatitude == InvalidValueInt32 {
		info.Info.PilotLatitude = 0
	}
	if info.Info.DroneHorizon == InvalidValueInt32 {
		info.Info.DroneHorizon = -1
	}
	if info.Info.DronePitch == InvalidValueInt32 {
		info.Info.DronePitch = -1
	}

	if info.Info.UDistance == InvalidValueUInt16 {
		info.Info.UDistance = 0
	}
	if info.Info.UDangerLevels == InvalidValueInt16 {
		info.Info.UDangerLevels = 0
	}
	if info.Info.UFreq == InvalidValueInt32 {
		info.Info.UFreq = 0
	}

	return info
}
func DetectGunCheckInputNum(drone *mavlink.GunsPlatformDetectDescription) *mavlink.GunsPlatformDetectDescription {
	if drone.DroneLongitude == InvalidValueInt32 {
		drone.DroneLongitude = 0
	}
	if drone.DroneLatitude == InvalidValueInt32 {
		drone.DroneLatitude = 0
	}
	if drone.DroneHeight == InvalidValueInt16 {
		drone.DroneHeight = 0
	}
	if drone.DroneYawAngle == InvalidValueInt16 {
		drone.DroneYawAngle = 0
	}
	if drone.DroneSpeed == InvalidValueInt16 {
		drone.DroneSpeed = 0
	}
	if drone.DroneVerticalSpeed == InvalidValueInt16 {
		drone.DroneVerticalSpeed = 0
	}
	if drone.DroneSailLongitude == InvalidValueInt32 {
		drone.DroneSailLongitude = 0
	}
	if drone.DroneSailLatitude == InvalidValueInt32 {
		drone.DroneSailLatitude = 0
	}
	if drone.PilotLongitude == InvalidValueInt32 {
		drone.PilotLongitude = 0
	}
	if drone.PilotLatitude == InvalidValueInt32 {
		drone.PilotLatitude = 0
	}
	if drone.DroneHorizon == InvalidValueInt32 {
		drone.DroneHorizon = -1
	}
	if drone.DronePitch == InvalidValueInt32 {
		drone.DronePitch = -1
	}
	if drone.UDistance == InvalidValueUInt16 {
		drone.UDistance = 0
	}
	if drone.UDangerLevels == InvalidValueInt16 {
		drone.UDangerLevels = 0
	}
	if drone.UFreq == InvalidValueInt32 {
		drone.UFreq = 0
	}
	return drone
}
func (d *GunsPlatform) updateStatusDetect(sn string) int32 {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_HUNTER_PLATFORM, sn)
	if cache, ok := DevStatusMap.Load(cacheKey); ok {
		dev := cache.(*Device)
		//if dev.IsEnable == common.DeviceDisenable {
		//	return common.DeviceDisenable
		//}
		dev.Status = common.DevOnline
		dev.Conn = d.Conn
		dev.WaitTaskMap = d.WaitTaskMap
		dev.RemoteIp = d.RemoteIp
		dev.LastHeartTime = time.Now()
		dev.GetStatusInterval = time.Now()
		//if dev.IsEnable != common.DeviceDisenable && dev.IsEnable != common.DeviceEnable {
		//dev.IsEnable = d.GetStatus(sn)
		//}
		return common.DeviceEnable
	} else {
		dev := &Device{
			Sn:                sn,
			Conn:              d.Conn,
			Status:            common.DevOnline,
			RemoteIp:          d.RemoteIp,
			RemotePort:        d.RemotePort,
			LocalIp:           d.LocalIp,
			ServerPort:        d.ServerPort,
			DevType:           common.DEV_HUNTER_PLATFORM,
			FirstHeartTime:    time.Now(),
			LastHeartTime:     time.Now(),
			SourceId:          d.SourceId,
			IsEnable:          common.DeviceEnable,
			GetStatusInterval: time.Now(),
			WaitTaskMap:       d.WaitTaskMap,
		}
		DevStatusMap.Store(cacheKey, dev)
		go func() {
			time.Sleep(time.Second * 2)
			e := NewEquipList().Update(context.Background(), &client.EquipCrudReq{
				Sn: sn,
				Ip: d.RemoteIp,
			}, &client.EquipCrudRes{})
			logger.Infof("update dev ip: %v, e: %v", d.RemoteIp, e)
			appVer, err := d.SendGetVersionInfo(sn)
			logger.Infof("GunsPlatform get  Ver: %v", appVer)
			if err != nil {
				logger.Infof("GunsPlatform get  Ver runVer: %v err: %v \n", appVer, err)
				return
			}
			if appVer != "" {
				err = NewEquipList().Update(context.Background(), &client.EquipCrudReq{
					Sn:         sn,
					DevVersion: appVer,
				}, &client.EquipCrudRes{})
				if err != nil {
					logger.Error("Update EquipList err: ", err)
				}
			}
		}()

		return dev.IsEnable
	}
}
func (d *GunsPlatform) UnmarshalPayloadGunsPlatformDetect(data *mavlink.GunsPlatformDetect) error {
	deviceInfoLen := binary.Size(mavlink.GunsPlatformDetectInfo{})
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}

	start := mavlink.HeaderLen + deviceInfoLen
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializeDrone(d.Msg[start:end]); err != nil {
		return err
	}

	return nil
}

// Heart 处理GunsPlatform心跳消息
func (d *GunsPlatform) Heart() {
	heart := &mavlink.GunsPlatformHeart{}
	if err := d.UnmarshalPayload(heart); err != nil {
		logger.Errorf(err.Error())
		return
	}

	devSn := ByteToString(heart.Info.Sn[:])
	if devSn != "" {
		d.updateStatus(devSn, int(heart.Info.DevSubId))
		d.HeartReport(devSn, heart)
	}
}
func (d *GunsPlatform) HeartReport(devSn string, heartInfo *mavlink.GunsPlatformHeart) {

	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	dataInfo := &client.GunsPlatformHeartInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        devSn,
			EquipType: int32(common.DEV_HUNTER_PLATFORM),
			MsgType:   mavlink.GunsPlatformHeartMsgReport,
		},
		Data: &client.GunsPlatformHeart{
			Sn:              devSn,
			TimeStamp:       int32(heartInfo.Info.TimeStamp),
			WorkStatus:      int32(heartInfo.Info.WorkStatus),
			IsOnline:        common.DevOnline,
			HitFreq:         int32(heartInfo.Info.HitFreq),
			DetectFreq:      float64(heartInfo.Info.DetectFreq) / DetectFreqTion,
			Elevation:       float64(heartInfo.Info.Elevation) / ElevationTion,
			GunDirection:    float64(heartInfo.Info.GunDirection) / GunDirectTion,
			GunLongitude:    float64(heartInfo.Info.GunLongitude) / GunLongitudeTion,
			GunLatitude:     float64(heartInfo.Info.GunLatitude) / GunLatitudeTion,
			GunAltitude:     float64(heartInfo.Info.GunAltitude),
			SatellitesNum:   int32(heartInfo.Info.SatellitesNum),
			FaultLevel:      int32(heartInfo.Info.FaultLevel),
			CtrlFault:       int32(heartInfo.Info.CtrlFault),
			AeagFault:       int32(heartInfo.Info.AeagFault),
			TracerFault:     int32(heartInfo.Info.TracerFault),
			WorkStatusParam: int32(heartInfo.Info.WorkStatusParam),
			DevSubId:        int32(heartInfo.Info.DevSubId),
		},
	}
	if err == nil {
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgIDGunsPlatformHeartBeat,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.GunsPlatformMsgBroker.Publish(mq.GunsPlatformTopic, broker.NewMessage(out))

	logger.Infof("GunsPlatform heartbeat has reported, devSn: %v,report:%v", devSn, dataInfo.Data)
}
func (d *GunsPlatform) UnmarshalPayload(data *mavlink.GunsPlatformHeart) error {
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("GunsPlatform UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("GunsPlatform UnmarshalPayload read data err: %v", err)
	}

	return nil
}
func (d *GunsPlatform) updateStatus(sn string, subDevType int) int32 {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_HUNTER_PLATFORM, sn)
	if cache, ok := DevStatusMap.Load(cacheKey); ok {
		dev := cache.(*Device)
		//if dev.IsEnable == common.DeviceDisenable {
		//	return common.DeviceDisenable
		//}
		dev.Status = common.DevOnline
		dev.Conn = d.Conn
		dev.WaitTaskMap = d.WaitTaskMap
		dev.RemoteIp = d.RemoteIp
		dev.LastHeartTime = time.Now()
		dev.GetStatusInterval = time.Now()
		//if dev.IsEnable != common.DeviceDisenable && dev.IsEnable != common.DeviceEnable {
		//dev.IsEnable = d.GetStatus(sn)
		//}
		d.GetStatus(sn, subDevType)
		return common.DeviceEnable
	} else {
		dev := &Device{
			Sn:                sn,
			Conn:              d.Conn,
			Status:            common.DevOnline,
			RemoteIp:          d.RemoteIp,
			RemotePort:        d.RemotePort,
			LocalIp:           d.LocalIp,
			ServerPort:        d.ServerPort,
			DevType:           common.DEV_HUNTER_PLATFORM,
			FirstHeartTime:    time.Now(),
			LastHeartTime:     time.Now(),
			SourceId:          d.SourceId,
			IsEnable:          d.GetStatus(sn, subDevType),
			GetStatusInterval: time.Now(),
			WaitTaskMap:       d.WaitTaskMap,
		}
		DevStatusMap.Store(cacheKey, dev)
		go func() {
			time.Sleep(time.Second * 2)
			e := NewEquipList().Update(context.Background(), &client.EquipCrudReq{
				Sn: sn,
				Ip: d.RemoteIp,
			}, &client.EquipCrudRes{})
			logger.Infof("update dev ip: %v, e: %v", d.RemoteIp, e)
			if d.Conn == nil {
				return
			}

			appVer, err := d.SendGetVersionInfo(sn)
			logger.Infof("GunsPlatform get  Ver: %v", appVer)
			if err != nil {
				logger.Infof("GunsPlatform get  Ver runVer: %v err: %v \n", appVer, err)
				return
			}
			if appVer != "" {
				err = NewEquipList().Update(context.Background(), &client.EquipCrudReq{
					Sn:         sn,
					DevVersion: appVer,
					IsOnline:   true,
				}, &client.EquipCrudRes{})
				if err != nil {
					logger.Error("Update EquipList err: ", err)
				}
			}
		}()

		return dev.IsEnable
	}
}
func SendGunPlantFormHeart() {
	ticker := time.NewTicker(time.Second * 1)
	defer ticker.Stop()
	for range ticker.C {
		logger.Info("SendGunPlantFormHeart")

		DevStatusMap.Range(func(key, value interface{}) bool {
			logger.Info("SendGunPlantFormHeart key:", key)
			dev := value.(*Device)
			if dev.DevType == common.DEV_HUNTER_PLATFORM && dev.Status == common.DevOnline {
				reqMode := &GunsPlatform{
					Device: dev,
					dt:     common.DEV_HUNTER_PLATFORM,
				}
				reqMode.SendExtHeartbeat()
			}
			return true
		})
	}
}
func (d *GunsPlatform) SendExtHeartbeat() error {
	GunsPlatformHeartSum++
	if GunsPlatformHeartSum > 255 {
		GunsPlatformHeartSum = 0
	}
	req := &mavlink.GunsPlatformHeartbeatExtRequest{
		Sum: GunsPlatformHeartSum,
	}

	reqBuff := req.CreateGunsPlatformHeartbeatExt()
	if d.Conn != nil {
		_, err := d.Conn.Write(reqBuff)
		logger.Infof("GunsPlatform c2发送心跳结果：%X", reqBuff)
		if err != nil {
			logger.Error("SendExtHeartbeat to GunsPlatform,sn:", d.Sn)
			return errors.New("SendExtHeartbeat to GunsPlatform,sn:" + d.Sn)
		}
	}
	logger.Debug("SendExtHeartbeat to GunsPlatform,sn:", d.Sn, "reqBuff:", reqBuff)
	return nil
}
func GunsPlatformOfflineReport(sn, remoteIp string) {
	dataInfo := &client.GunsPlatformHeart{
		Sn:       sn,
		IsOnline: 1,
	}

	equipModel, err := GetEquipBySn(sn)
	name := sn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	msg := &client.GunsPlatformHeartInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        sn,
			EquipType: int32(common.DEV_HUNTER_PLATFORM),
			MsgType:   mavlink.GunsPlatformHeartMsgReport,
		},
		Data: dataInfo,
	}
	if err == nil {
		msg.Header.ParentType = int32(equipModel.ParentType)
		msg.Header.ParentSn = equipModel.ParentSn
		msg.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msgOut, err := proto.Marshal(msg)
	if err != nil {
		logger.Error("marshal msg err:", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIDGunsPlatformHeartBeat,
		Data:    msgOut,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}
	logger.Debug("GunsPlatform is offline,sn:", sn, msg)
	_ = mq.GunsPlatformMsgBroker.Publish(mq.GunsPlatformTopic, broker.NewMessage(out))
}

func (d *GunsPlatform) ReceiveGunsPlatformSetHitMode() {
	logger.Info("-->into Receive Set Hit Mode")
	res := &mavlink.GunsPlatformSetHitModeResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveGunsPlatformSet Hit Mode 接收到GunsPlatform信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformSetHitMode]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *GunsPlatform) SendGunsPlatformOnOffSet(request *client.GunsPlatformOnOffRequest) (int, error) {
	logger.Info("-->into Send On Off  msg")
	req := &mavlink.GunsPlatformSetOnOffRequest{}
	buff := req.Create(request)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request GunsPlatform On Off info err: %v", err)
		return Fail, fmt.Errorf("request GunsPlatform On Off info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformSetOnOff]
	if !ok {
		manager = NewWaitTaskManager(mavlink.GunsPlatformSetOnOff, true, 0)
		d.WaitTaskMap[mavlink.GunsPlatformSetOnOff] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request GunsPlatform On Off info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.GunsPlatformSetOnOffResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response GunsPlatform On Off result:%+v", *res)
	return int(res.Status), nil
}
func (d *GunsPlatform) ReceiveGunsPlatformSetOnOff() {
	logger.Info("-->into Receive GunsPlatformSetOnOff")
	res := &mavlink.GunsPlatformSetOnOffResponse{}
	d.GetPacket(res)
	logger.Debugf("GunsPlatform Set OnOff  接收到GunsPlatform信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformSetOnOff]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *GunsPlatform) SendGunsPlatformReset() (int, error) {
	logger.Info("-->into Send Reset  msg")
	req := &mavlink.GunsPlatformResetRequest{}
	buff := req.Create()
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request GunsPlatform Reset info err: %v", err)
		return Fail, fmt.Errorf("request GunsPlatform Reset info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformReset]
	if !ok {
		manager = NewWaitTaskManager(mavlink.GunsPlatformReset, true, 0)
		d.WaitTaskMap[mavlink.GunsPlatformReset] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request GunsPlatform Reset info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.GunsPlatformResetResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response GunsPlatform Reset result:%+v", *res)
	return int(res.Status), nil
}
func (d *GunsPlatform) ReceiveGunsPlatformReset() {
	logger.Info("-->into Receive Reset")
	res := &mavlink.GunsPlatformResetResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveGunsPlatformGet Reset 接收到GunsPlatform信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformReset]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}
func (d *GunsPlatform) SendGunsPlatformHitUav(request *client.GunsPlatformSendHitUavRequest) (int, error) {
	logger.Info("-->into Send Hit Uav msg,req is:", request)
	req := &mavlink.GunsPlatformSendHitUavRequest{}
	buff := req.Create(request)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request GunsPlatform Send Hit Uav info err: %v", err)
		return Fail, fmt.Errorf("request GunsPlatform Send Hit Uav info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformSendHitUav]
	if !ok {
		manager = NewWaitTaskManager(mavlink.GunsPlatformSendHitUav, true, 0)
		d.WaitTaskMap[mavlink.GunsPlatformSendHitUav] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request GunsPlatform Send Hit Uav info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.GunsPlatformSendHitUavResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response GunsPlatform Send Hit Uav result:%+v", *res)
	return int(res.Status), nil
}

func (d *GunsPlatform) ReceiveGunsPlatformGetHitUav() {
	logger.Info("-->into Receive Get Hit Uav")
	res := &mavlink.GunsPlatformSendHitUavResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveGunsPlatformGetHitUav  接收到GunsPlatform信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformSendHitUav]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}
func (d *GunsPlatform) SendGunsPlatformGetStatus() (*client.GunsPlatformGetStatusResponse, error) {
	logger.Info("-->into Send Reset  msg")
	rsp := &client.GunsPlatformGetStatusResponse{}

	//1.获取角度、打击时长信息
	req := &mavlink.GunsPlatformGetPitchRequest{}
	buff := req.Create()
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request GunsPlatform GetPitch info err: %v", err)
		return rsp, fmt.Errorf("request GunsPlatform GetPitch info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformGetHitPith]
	if !ok {
		manager = NewWaitTaskManager(mavlink.GunsPlatformGetHitPith, true, 0)
		d.WaitTaskMap[mavlink.GunsPlatformGetHitPith] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request GunsPlatform GetPitch info err: %v", checkNetConnErr)
			return rsp, checkNetConnErr
		}
	}
	resPitch, ok := result.(*mavlink.GunsPlatformGetPitchResponse)
	if !ok {
		return rsp, errors.New("response err type")
	}
	logger.Debug("response GunsPlatform GetPitch result:%+v", *resPitch)

	for i := 0; i < int(resPitch.HitCnt); i++ {
		rsp.HitTime = int32(resPitch.HitDescription[0].HitTime)
		rsp.HitPitch1 = int32(resPitch.HitDescription[0].HitPitch)
		rsp.HitPitch2 = int32(resPitch.HitDescription[i].HitPitch)
	}

	//2.获取打击范围信息
	reqAngle := &mavlink.GunsPlatformGetAngleRequest{}
	buffAngle := reqAngle.Create()
	if _, err := d.Conn.Write(buffAngle); err != nil {
		logger.Errorf("request GunsPlatform GetAngle info err: %v", err)
		return rsp, fmt.Errorf("request GunsPlatform GetAngle info err: %v", err)
	}
	managerAngle, ok := d.WaitTaskMap[mavlink.GunsPlatformGetHitAngle]
	if !ok {
		managerAngle = NewWaitTaskManager(mavlink.GunsPlatformGetHitAngle, true, 0)
		d.WaitTaskMap[mavlink.GunsPlatformGetHitAngle] = managerAngle
	}

	resultAngle, err := managerAngle.Wait()
	if err != nil {
		if checkNetConnErr := managerAngle.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request GunsPlatform GetAngle info err: %v", checkNetConnErr)
			return rsp, checkNetConnErr
		}
	}
	resAngle, ok := resultAngle.(*mavlink.GunsPlatformGetAngleResponse)
	if !ok {
		return rsp, errors.New("response err type")
	}
	logger.Debug("response GunsPlatform GetAngle result:%+v", *resAngle)
	rsp.HitAngleBegin = int32(resAngle.HitAngleBegin)
	rsp.HitAngleEnd = int32(resAngle.HitAngleEnd)

	//3.获取工作模式
	reqMode := &mavlink.GunsPlatformGetHitModeRequest{}
	buffMode := reqMode.Create()
	if _, err := d.Conn.Write(buffMode); err != nil {
		logger.Errorf("request GunsPlatform GetMode info err: %v", err)
		return rsp, fmt.Errorf("request GunsPlatform GetMode info err: %v", err)
	}
	managerreqMode, ok := d.WaitTaskMap[mavlink.GunsPlatformGetHitMode]
	if !ok {
		managerreqMode = NewWaitTaskManager(mavlink.GunsPlatformGetHitMode, true, 0)
		d.WaitTaskMap[mavlink.GunsPlatformGetHitMode] = managerreqMode
	}

	resultMode, err := managerreqMode.Wait()
	if err != nil {
		if checkNetConnErr := managerreqMode.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request GunsPlatform GetMode info err: %v", checkNetConnErr)
			return rsp, checkNetConnErr
		}
	}
	resMode, ok := resultMode.(*mavlink.GunsPlatformGetHitModeResponse)
	if !ok {
		return rsp, errors.New("response err type")
	}
	logger.Debug("response GunsPlatform GetMode result:%+v", *resMode)
	rsp.HitMode = int32(resMode.ModeStatus)

	return rsp, nil
}

func (d *GunsPlatform) SendGunsPlatformSetHitMode(hitMode int32) (int, error) {
	//设置打击模式  0 不自动打击    1 自动打击
	req := &mavlink.GunsPlatformSetAutoModeRequest{}
	buff := req.Create(hitMode)
	logger.Debug("-->Set Hit Auto is :", buff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request GunsPlatform Hit Auto err: %v", err)
		return Fail, fmt.Errorf("request GunsPlatform Hit Auto err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformSetAutoHitMode]
	if !ok {
		manager = NewWaitTaskManager(mavlink.GunsPlatformSetAutoHitMode, true, 0)
		d.WaitTaskMap[mavlink.GunsPlatformSetAutoHitMode] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request GunsPlatform  Hit Mode err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.GunsPlatformSetAutoModeResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response GunsPlatform Hit Auto result:%+v", *res)

	return int(res.Status), nil
}
func (d *GunsPlatform) ReceiveGunsPlatformSetAutoHitMode() {
	logger.Info("-->into ReceiveGunsPlatform Set Auto Hit Mode")
	res := &mavlink.GunsPlatformSetAutoModeResponse{}
	d.GetPacket(res)
	logger.Debugf("Set Auto Hit Mode  接收到GunsPlatform信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformSetAutoHitMode]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}
func (d *GunsPlatform) SendGunsPlatformGetHitMode() (int, error) {
	//获取打击模式  0 不自动打击    1 自动打击
	req := &mavlink.GunsPlatformGetAutoModeRequest{}
	buff := req.Create()
	logger.Debug("-->Get Hit Auto is :", buff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Get GunsPlatform Hit Auto err: %v", err)
		return Fail, fmt.Errorf("request Get GunsPlatform Hit Auto err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformGetAutoHitMode]
	if !ok {
		manager = NewWaitTaskManager(mavlink.GunsPlatformGetAutoHitMode, true, 0)
		d.WaitTaskMap[mavlink.GunsPlatformGetAutoHitMode] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request GunsPlatform Get Hit Mode err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.GunsPlatformGetAutoModeResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response GunsPlatform Get Hit Auto result:%+v", *res)

	return int(res.AutoStatus), nil
}
func (d *GunsPlatform) ReceiveGunsPlatformGetAutoHitMode() {
	logger.Info("-->into ReceiveGunsPlatform Get Auto Hit Mode")
	res := &mavlink.GunsPlatformGetAutoModeResponse{}
	d.GetPacket(res)
	logger.Debugf("Get Auto Hit Mode  接收到GunsPlatform信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformGetAutoHitMode]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *GunsPlatform) SendGunsPlatformGetPower() (int, int, error) {
	logger.Info("-->into Send Get Power  msg")
	//获取开关机状态
	req := &mavlink.GunsPlatformGetPowerRequest{}
	buff := req.Create()
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request GunsPlatform Get Power info err: %v", err)
		return Fail, Fail, fmt.Errorf("request GunsPlatform Get Power info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformGetOnOff]
	if !ok {
		manager = NewWaitTaskManager(mavlink.GunsPlatformGetOnOff, true, 0)
		d.WaitTaskMap[mavlink.GunsPlatformGetOnOff] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request GunsPlatform Get Power info err: %v", checkNetConnErr)
			return Fail, Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.GunsPlatformGetPowerResponse)
	if !ok {
		return Fail, Fail, errors.New("response err type")
	}
	logger.Debug("response GunsPlatform Get Power result:%+v", *res)

	return int(res.PowerStatus), int(res.Status), nil
}
func (d *GunsPlatform) ReceiveGunsPlatformGetOnOff() {
	logger.Info("-->into Receive GunsPlatformGetOnOff")
	res := &mavlink.GunsPlatformGetPowerResponse{}
	d.GetPacket(res)
	logger.Debugf("GunsPlatformGetOnOff Get 接收到GunsPlatform信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformGetOnOff]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *GunsPlatform) SendGunsPlatformTurnHit(startStop int32) (int, error) {
	logger.Info("-->into Send Turn Hit  msg")
	//获取开关机状态
	req := &mavlink.GunsPlatformTurnHitRequest{}
	buff := req.Create(uint8(startStop))
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request GunsPlatform Send Turn Hit info err: %v", err)
		return Fail, fmt.Errorf("request GunsPlatform Send Turn Hit info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformHitTurn]
	if !ok {
		manager = NewWaitTaskManager(mavlink.GunsPlatformHitTurn, true, 0)
		d.WaitTaskMap[mavlink.GunsPlatformHitTurn] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request GunsPlatform Turn Hit info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.GunsPlatformTurnHitResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response GunsPlatform Turn Hit result:%+v", *res)

	return int(res.Status), nil
}
func (d *GunsPlatform) ReceiveGunsPlatformTurnHit() {
	logger.Info("-->into Receive GunsPlatformTurnHit")
	res := &mavlink.GunsPlatformTurnHitResponse{}
	d.GetPacket(res)
	logger.Debugf("GunsPlatformTurnHit Get 接收到GunsPlatform信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformHitTurn]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *GunsPlatform) SendGunsPlatformHorizontalTurn(request *client.GunsPlatformHorizontalTurnRequest) (int, error) {
	logger.Info("-->into Send Horizontal Turn  msg")
	//获取开关机状态
	req := &mavlink.GunsPlatformHorizontalTurnRequest{}
	buff := req.Create(request)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request GunsPlatform Send Horizontal Turn info err: %v", err)
		return Fail, fmt.Errorf("request GunsPlatform Send Horizontal Turn info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformHorizontalTurn]
	if !ok {
		manager = NewWaitTaskManager(mavlink.GunsPlatformHorizontalTurn, true, 0)
		d.WaitTaskMap[mavlink.GunsPlatformHorizontalTurn] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request GunsPlatform Horizontal Turn info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.GunsPlatformHorizontalTurnResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response GunsPlatform Horizontal Turn result:%+v", *res)

	return int(res.Status), nil
}
func (d *GunsPlatform) ReceiveGunsPlatformHorizontalTurn() {
	logger.Info("-->into Receive GunsPlatform Horizontal Turn")
	res := &mavlink.GunsPlatformHorizontalTurnResponse{}
	d.GetPacket(res)
	logger.Debugf("GunsPlatform Horizontal Turn Get 接收到GunsPlatform信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformHorizontalTurn]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *GunsPlatform) SendGunsPlatformVerticalTurn(request *client.GunsPlatformVerticalTurnRequest) (int, error) {
	logger.Info("-->into Send Vertical Turn  msg")
	//获取开关机状态
	req := &mavlink.GunsPlatformVerticalTurnRequest{}
	buff := req.Create(request)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request GunsPlatform Send Vertical Turn info err: %v", err)
		return Fail, fmt.Errorf("request GunsPlatform Send Vertical Turn info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformVerticalTurn]
	if !ok {
		manager = NewWaitTaskManager(mavlink.GunsPlatformVerticalTurn, true, 0)
		d.WaitTaskMap[mavlink.GunsPlatformVerticalTurn] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request GunsPlatform Vertical Turn info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.GunsPlatformVerticalTurnResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response GunsPlatform Vertical Turn result:%+v", *res)

	return int(res.Status), nil
}
func (d *GunsPlatform) ReceiveGunsPlatformVerticalTurn() {
	logger.Info("-->into Receive GunsPlatform Vertical Turn")
	res := &mavlink.GunsPlatformVerticalTurnResponse{}
	d.GetPacket(res)
	logger.Debugf("GunsPlatform Vertical Turn Get 接收到GunsPlatform信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformVerticalTurn]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *GunsPlatform) SendGunsPlatformCrashStop() (int, error) {
	logger.Info("-->into Send GunsPlatform Crash Stop  msg")
	//获取开关机状态
	req := &mavlink.GunsPlatformCrashStopRequest{}
	buff := req.Create()
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Send GunsPlatform Crash Stop info err: %v", err)
		return Fail, fmt.Errorf("request Send GunsPlatform Crash Stop info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformCrashStop]
	if !ok {
		manager = NewWaitTaskManager(mavlink.GunsPlatformCrashStop, true, 0)
		d.WaitTaskMap[mavlink.GunsPlatformCrashStop] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request GunsPlatform Crash Stop info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.GunsPlatformCrashStopResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response GunsPlatform Crash Stop result:%+v", *res)

	return int(res.Status), nil
}
func (d *GunsPlatform) ReceiveGunsPlatformCrashStop() {
	logger.Info("-->into Receive GunsPlatformCrash Stop")
	res := &mavlink.GunsPlatformCrashStopResponse{}
	d.GetPacket(res)
	logger.Debugf("GunsPlatform Crash Stop Get 接收到GunsPlatform信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformCrashStop]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}
func (d *GunsPlatform) ReceiveGunsPlatformGetGNNS() {
	logger.Info("-->into Receive GunsPlatform Get GNNS")

	res := &mavlink.GunsPlatformGNSSGetResponse{}
	ret := d.UnmarshalPayloadGunsPlatformGetGNSS(res)
	if ret != nil {
		logger.Debug("Receive GunsPlatform Get GNNS ret = ", ret)
	}
	// res.AppVersion = d.Msg[mavlink.HeaderLen : len(d.Msg)-2]
	// res.Type = d.Msg[mavlink.HeaderLen : len(d.Msg)-2]
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformGetGNSS]
	if ok {
		manager.CompletedTask(res, nil)
	}
	logger.Info("-->End ReceiveGunsPlatformGetGNNS GunsPlatform :", res)
	return
}

func (d *GunsPlatform) ReceiveGunsPlatformSetGNNS() {
	logger.Info("-->into ReceiveGunsPlatformSetGNNS GunsPlatform Set GNNS")

	res := &mavlink.GunsPlatformGNSSSetResponse{}
	ret := d.UnmarshalPayloadGunsPlatformSetGNSS(res)
	if ret != nil {
		logger.Debug("Receive ReceiveGunsPlatformSetGNNSret = ", ret)
	}
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformSetGNSS]
	if ok {
		manager.CompletedTask(res, nil)
	}
	logger.Info("-->End ReceiveGunsPlatformSetGNNS GunsPlatform :", res)
	return
}
func (d *GunsPlatform) UnmarshalPayloadGunsPlatformGetGNSS(data *mavlink.GunsPlatformGNSSGetResponse) error {
	buff := &bytes.Buffer{}
	start := mavlink.HeaderLen
	end := start + int(data.Size())
	logger.Debug("start: , end: ", start, end)
	logger.Debug("d.Msg[start:end] = ", d.Msg[start:end])
	if err := binary.Write(buff, binary.LittleEndian, d.Msg[start:end]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, data); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}
	logger.Debugf("ReceiveGunsPlatform UnmarshalPayloadGunsPlatformGetGNSS 接收到GunsPlatform信息：%#v", data)
	// if err := data.DeserializeDrone(d.Msg[start:end]); err != nil {
	// 	return err
	// }

	return nil
}

func (d *GunsPlatform) UnmarshalPayloadGunsPlatformSetGNSS(data *mavlink.GunsPlatformGNSSSetResponse) error {
	buff := &bytes.Buffer{}
	start := mavlink.HeaderLen
	end := start + int(data.Size())
	logger.Debug("start: , end: ", start, end)
	logger.Debug("d.Msg[start:end] = ", d.Msg[start:end])
	if err := binary.Write(buff, binary.LittleEndian, d.Msg[start:end]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, data); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}
	logger.Debugf("ReceiveGunsPlatform UnmarshalPayloadGunsPlatformSetGNSS 接收到GunsPlatform信息：%#v", data)
	// if err := data.DeserializeDrone(d.Msg[start:end]); err != nil {
	// 	return err
	// }

	return nil
}
func (d *GunsPlatform) ReceiveGunsPlatformSetPith() {
	logger.Info("-->into Receive GunsPlatform Set Pith")
	res := &mavlink.GunsPlatformSetHitInfoResponse{}
	d.GetPacket(res)
	logger.Debugf("Set Pith 接收到GunsPlatform 信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformSetPith]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *GunsPlatform) ReceiveGunsPlatformSetAngle() {
	logger.Info("-->into Receive GunsPlatform Set Angle")
	res := &mavlink.GunsPlatformSetHitAngleResponse{}
	d.GetPacket(res)
	logger.Debugf("Set Angle 接收到GunsPlatform 信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformSetAngle]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *GunsPlatform) SendGunsPlatformHitAngleSet(request *client.GunsPlatformHitAngleRequest) (int, error) {
	logger.Info("-->into Send Hit Angle msg,req is %v", request)
	//1、设置打击俯仰角度
	req := &mavlink.GunsPlatformSetHitInfoRequest{}
	buff := req.Create(request)
	logger.Debug("-->Set Hit Info is :", buff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request GunsPlatform Hit Angle  err: %v", err)
		return Fail, fmt.Errorf("request GunsPlatform Hit Info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformSetPith]
	if !ok {
		manager = NewWaitTaskManager(mavlink.GunsPlatformSetPith, true, 0)
		d.WaitTaskMap[mavlink.GunsPlatformSetPith] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request GunsPlatform Hit Info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.GunsPlatformSetHitInfoResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response GunsPlatform Hit Info result:%+v", *res)

	//2、设置有效角度范围
	reqAngle := &mavlink.GunsPlatformSetHitAngleRequest{}
	buffAngle := reqAngle.Create(request)
	logger.Debug("-->Set Hit Angle is :", buffAngle)
	if _, err := d.Conn.Write(buffAngle); err != nil {
		logger.Errorf("request GunsPlatform Hit Angle err: %v", err)
		return Fail, fmt.Errorf("request GunsPlatform Hit Angle err: %v", err)
	}
	managerAngle, ok := d.WaitTaskMap[mavlink.GunsPlatformSetAngle]
	if !ok {
		managerAngle = NewWaitTaskManager(mavlink.GunsPlatformSetAngle, true, 0)
		d.WaitTaskMap[mavlink.GunsPlatformSetAngle] = managerAngle
	}

	resultAngle, err := managerAngle.Wait()
	if err != nil {
		if checkNetConnErr := managerAngle.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request GunsPlatform  Hit Angle err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	resAngle, ok := resultAngle.(*mavlink.GunsPlatformSetHitAngleResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response GunsPlatform Hit Angle result:%+v", *resAngle)

	//3.设置打击模式   反制模式：1、Normal 2、GNSS。打击模式拆分成单独的接口
	return int(resAngle.Status), nil
}
func RecordGunCloudInfo(r *client.GunsPlatformDetectDroneInfo) {
	_, isExist := SflDetectInfoMap.Get(r.SerialNum)
	tempTime := time.Now().UnixMilli()
	if !isExist { //不存在添加
		logger.Info("Sfl add drone event,", r.SerialNum)
		piltlong := strconv.FormatFloat(r.PilotLongitude, 'f', 4, 64)
		piltlat := strconv.FormatFloat(r.PilotLatitude, 'f', 4, 64)
		SflDetectInfoMap.Set(r.SerialNum, r.DroneName, tempTime, 0, 0, r.UFreq,
			int64(r.DroneYawAngle), piltlong+","+piltlat, tempTime, r.UDirStatus)
		//写数据库
		err := NewSflDetectInfo().Insert(context.Background(), &client.SflDetectInfoInsertReq{
			Sn:           r.SerialNum,
			Vendor:       r.DroneName,
			DetectTime:   tempTime,
			HitTime:      0,
			CounterTime:  0,
			Freq:         float32(r.UFreq),
			Direction:    int64(r.DroneHorizon),
			PilotLongLat: piltlong + " , " + piltlat,
			DroneHeight:  r.DroneHeight,
			UDirStatus:   r.UDirStatus,
			DevType:      int32(DevType(common.DEV_HUNTER_PLATFORM)),
		}, &client.SflDetectInfoInsertRes{})
		if err != nil {
			logger.Error("Sfl Detect Info Insert err:", err)
		}
	}
}
func (d *GunsPlatform) SendGunsPlatformHitModeSet(request *client.GunsPlatformHitModeRequest) (int, error) {
	logger.Info("-->into Send Hit Mode msg,req is %v", request)
	//3.设置打击模式   反制模式：1、Normal 2、GNSS
	reqMode := &mavlink.GunsPlatformSetHitModeRequest{}
	buffMode := reqMode.Create(request)
	logger.Debug("-->Set Hit Mode is :", buffMode)
	if _, err := d.Conn.Write(buffMode); err != nil {
		logger.Errorf("request GunsPlatform Hit Mode err: %v", err)
		return Fail, fmt.Errorf("request GunsPlatform Hit Mode err: %v", err)
	}
	managerMode, ok := d.WaitTaskMap[mavlink.GunsPlatformSetHitMode]
	if !ok {
		managerMode = NewWaitTaskManager(mavlink.GunsPlatformSetHitMode, true, 0)
		d.WaitTaskMap[mavlink.GunsPlatformSetHitMode] = managerMode
	}

	resultMode, err := managerMode.Wait()
	if err != nil {
		if checkNetConnErr := managerMode.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request GunsPlatform  Hit Mode err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	resMode, ok := resultMode.(*mavlink.GunsPlatformSetHitModeResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response GunsPlatform Hit Mode result:%+v", *resMode)

	return int(resMode.Status), nil
}

func (d *GunsPlatform) ReceiveGunsPlatformStopHit() {
	logger.Info("-->into Receive GunsPlatform Stop Hit")
	res := &mavlink.GunsPlatformStopHitResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveGunsPlatformStopHit 接收到信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformStopHit]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *GunsPlatform) SendGunsPlatformStopHitReq() (int, error) {
	logger.Info("-->into Send GunsPlatform stop hit msg")
	req := &mavlink.GunsPlatformStopHitRequest{}
	buff := req.Create()
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request GunsPlatform Stop Hit info err: %v", err)
		return Fail, fmt.Errorf("request GunsPlatform Stop Hit info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformStopHit]
	if !ok {
		manager = NewWaitTaskManager(mavlink.GunsPlatformStopHit, true, 0)
		d.WaitTaskMap[mavlink.GunsPlatformStopHit] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request GunsPlatform Stop Hit info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.GunsPlatformStopHitResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response GunsPlatform Stop Hit result:%+v", *res)
	return int(res.Status), nil
}

// GunsPlatformGNSSSetReq
func (d *GunsPlatform) GunsPlatformGNSSSetReq(request *client.GunsPlatformSetGNSSRequest) (int, error) {
	logger.Info("-->into GunsPlatformGNSSSetReq stop hit msg")
	req := &mavlink.GunsPlatformGNSSSetRequest{}
	buff := req.Create(request)
	logger.Debug("buff = ", buff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request GunsPlatform SGunsPlatformGNSSSetReqerr: %v", err)
		return Fail, fmt.Errorf("request GunsPlatformGNSSSetReq  info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformSetGNSS]
	if !ok {
		manager = NewWaitTaskManager(mavlink.GunsPlatformSetGNSS, true, 0)
		d.WaitTaskMap[mavlink.GunsPlatformSetGNSS] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request GunsPlatformGNSSSetReq info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.GunsPlatformGNSSSetResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response GunsPlatform GunsPlatformGNSSSetReqresult:%+v", *res)
	return int(res.Status), nil
}

// GunsPlatformGNSSSetReq
func (d *GunsPlatform) GunsPlatformGNSSGetReq() (*mavlink.GunsPlatformGNSSGetResponse, error) {
	logger.Info("-->into Send GunsPlatform GunsPlatformGNSSGetReq hit msg")
	req := &mavlink.GunsPlatformGNSSGetRequest{}
	buff := req.Create()
	logger.Debug("buff = ", buff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("GunsPlatformGNSSGetReqHit info err: %v", err)
		return nil, fmt.Errorf("GunsPlatformGNSSGetReq info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformGetGNSS]
	if !ok {
		manager = NewWaitTaskManager(mavlink.GunsPlatformGetGNSS, true, 0)
		d.WaitTaskMap[mavlink.GunsPlatformGetGNSS] = manager
	}

	result, err := manager.Wait()
	logger.Debug("result = ", result)
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request GunsPlatformGunsPlatformGNSSGetReq err: %v", checkNetConnErr)
			return nil, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.GunsPlatformGNSSGetResponse)
	if !ok {
		return nil, errors.New("response err type")
	}
	logger.Debug("response GunsPlatformGNSSGetReq result:%+v", *res)

	return res, nil
}
func (d *GunsPlatform) ReceiveGunsPlatformGetVersion() {
	logger.Info("-->into Receive GunsPlatform Get Version")

	res := &mavlink.GunsPlatformGetVersionResponse{}

	res.AppVersion = d.Msg[mavlink.HeaderLen : len(d.Msg)-2]
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformGetVersion]
	if ok {
		manager.CompletedTask(res, nil)
	}
	logger.Info("-->End Receive GunsPlatform Version:", string(res.AppVersion))
	return
}

func (d *GunsPlatform) SendGetVersionInfo(sn string) (string, error) {
	logger.Info("-->into Send Get Version msg")
	req := &mavlink.GunsPlatformGetVersionRequest{}
	buff := req.Create()
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request GunsPlatform version info err: %v", err)
		return "", fmt.Errorf("request GunsPlatform version info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformGetVersion]
	if !ok {
		manager = NewWaitTaskManager(mavlink.GunsPlatformGetVersion, true, 0)
		d.WaitTaskMap[mavlink.GunsPlatformGetVersion] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request GunsPlatform version info err: %v", checkNetConnErr)
			return "", checkNetConnErr
		}
	}
	logger.Debug("SendGetVersionInfo result = ", result)
	res, ok := result.(*mavlink.GunsPlatformGetVersionResponse)
	if !ok {
		return "", errors.New("response err type")
	}
	logger.Debug("response GunsPlatform version result:%+v", *res)
	if string(res.AppVersion) != "" {
		err = NewEquipList().Update(context.Background(), &client.EquipCrudReq{
			Sn:         sn,
			DevVersion: string(res.AppVersion),
		}, &client.EquipCrudRes{})
		if err != nil {
			logger.Error("Update EquipList err: ", err)
		}
	}
	return string(res.AppVersion), nil
}
func (d *GunsPlatform) GetPacket(message mavlink.Message) *mavlink.MavPacket {
	logger.Infof("GunsPlatform GetPacket is [% x]", d.Msg)
	req := mavlink.NewNullPacket(message)
	buff := &bytes.Buffer{}
	if err := binary.Write(buff, binary.LittleEndian, d.Msg); err != nil {
		logger.Error("GunsPlatform GetPacket write buff err:", err)
		return nil

	}
	if err := binary.Read(buff, binary.LittleEndian, &req.Header); err != nil {
		logger.Error("GunsPlatform GetPacket read header err:", err)
		return nil
	}
	if err := binary.Read(buff, binary.LittleEndian, req.Msg); err != nil {
		logger.Error("GunsPlatform GetPacket read msg err:", err)
		return nil
	}
	return req
}

func (d *GunsPlatform) ReceiveGunsPlatformGetHitPith() {
	logger.Info("-->into Receive Get Hit Pith")
	res := &mavlink.GunsPlatformGetPitchResponse{}
	if err := d.UnmarshalPayloadGunsPlatformHitPith(res); err != nil {
		logger.Errorf(err.Error())
		return
	}
	logger.Debugf("ReceiveGunsPlatformGet Hit Pith 接收到GunsPlatform信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformGetHitPith]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *GunsPlatform) UnmarshalPayloadGunsPlatformHitPith(data *mavlink.GunsPlatformGetPitchResponse) error {
	deviceInfoLen := binary.Size(data.HitCnt)
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.HitCnt); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}

	start := mavlink.HeaderLen + deviceInfoLen
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializeDrone(d.Msg[start:end]); err != nil {
		return err
	}

	return nil
}

func (d *GunsPlatform) ReceiveGunsPlatformGetHitAngle() {
	logger.Info("-->into Receive Get Hit Angle")
	res := &mavlink.GunsPlatformGetAngleResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveGunsPlatform Get Hit Angle 接收到GunsPlatform信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformGetHitAngle]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *GunsPlatform) ReceiveGunsPlatformGetHitMode() {
	logger.Info("-->into Receive Get Hit Mode")
	res := &mavlink.GunsPlatformGetHitModeResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveGunsPlatformGet Hit Mode 接收到GunsPlatform信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformGetHitMode]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// GunCloudSendUpgradeF1 发送固件升级请求
func (d *GunsPlatform) GunCloudSendUpgradeF1(fileName string, c2Ip string) (int32, error) {
	logger.Info("GunCloudSendUpgradeF1 Start")

	req := &mavlink.GunCloudUpdateF1Request{}
	buff := req.Create(fileName, c2Ip)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformIdUpgradeF1]
	if !ok {
		manager = NewWaitTaskManager(mavlink.GunsPlatformIdUpgradeF1, true, 0)
		d.WaitTaskMap[mavlink.GunsPlatformIdUpgradeF1] = manager
	}
	task := manager.AddTask(nil, nil)
	logger.Debugf("GunCloudSendUpgradeF1 buff: %02X \n", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("GunCloudSendUpgradeF1 发送写入固件数据信息失败: ", err)
		return 1, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("GunCloudSendUpgradeF1 WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 1, checkNetConnErr
		}
		return 1, err
	}
	res := result.(*mavlink.GunCloudUpdateF1Response)
	logger.Debugf("GunCloudUpdateF1Response 获取写入固件数据信息结果：%#v", res)
	logger.Info("GunCloudUpdateF1Response End")
	return int32(res.Status), nil
}

// ReceiveGunCloudUpdateF1 获取请求固件升级响应
func (d *GunsPlatform) ReceiveGunCloudUpdateF1() {
	res := &mavlink.GunCloudUpdateF1Response{}
	d.GetPacket(res)
	logger.Debugf("ReceiveGunCloudUpdateF1 获取请求固件升级响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformIdUpgradeF1]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// GunCloudSendUpgradeF2 发送固件升级请求
func (d *GunsPlatform) GunCloudSendUpgradeF2() (int32, error) {
	logger.Info("GunCloudSendUpgradeF2 Start")
	req := &mavlink.GunCloudUpdateF2Request{}
	buff := req.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformIdUpgradeF2]
	if !ok {
		manager = NewWaitTaskManager(mavlink.GunsPlatformIdUpgradeF2, true, time.Second*30)
		d.WaitTaskMap[mavlink.GunsPlatformIdUpgradeF2] = manager
	}
	task := manager.AddTask(nil, nil)
	logger.Debugf("GunCloudSendUpgradeF2 buff: %02X \n", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("GunCloudSendUpgradeF2 发送写入固件数据信息失败: ", err)
		return 1, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("GunCloudSendUpgradeF2 WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 1, checkNetConnErr
		}
		return 1, err
	}
	res := result.(*mavlink.GunCloudUpdateF2Response)
	logger.Debugf("GunCloudUpdateF2 Response 获取写入固件数据信息结果：%#v", res)
	logger.Info("GunCloudUpdateF2 Response End")
	return int32(res.Progress), nil
}

// ReceiveGunCloudUpdateF2 获取请求固件升级响应
func (d *GunsPlatform) ReceiveGunCloudUpdateF2() {
	res := &mavlink.GunCloudUpdateF2Response{}
	d.GetPacket(res)
	logger.Debugf("ReceiveGunCloudUpdateF2 获取请求固件升级响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformIdUpgradeF2]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// GunCloudSendUpgradeF3 发送固件升级请求
func (d *GunsPlatform) GunCloudSendUpgradeF3() (int32, error) {
	logger.Info("GunCloudSendUpgradeF3 Start")

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformIdUpgradeF3]
	if !ok {
		manager = NewWaitTaskManager(mavlink.GunsPlatformIdUpgradeF3, true, time.Second*60)
		d.WaitTaskMap[mavlink.GunsPlatformIdUpgradeF3] = manager
	}
	task := manager.AddTask(nil, nil)

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("GunCloudSendUpgradeF3 WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 1, checkNetConnErr
		}
		return 1, err
	}
	res := result.(*mavlink.GunCloudUpdateF3Response)
	logger.Debugf("GunCloudUpdateF3 Response 获取写入固件数据信息结果：%#v", res)
	logger.Info("GunCloudUpdateF Response End")
	return int32(res.UpgradeResult), nil
}

// ReceiveGunCloudUpdateF3 获取请求固件升级响应
func (d *GunsPlatform) ReceiveGunCloudUpdateF3() {
	res := &mavlink.GunCloudUpdateF3Response{}
	d.GetPacket(res)
	logger.Debugf("ReceiveGunCloudUpdateF3 获取请求固件升级响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformIdUpgradeF3]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}
func (d *GunsPlatform) GunsPlatformSetPreciseHit(request *client.GunsPlatformSetPreciseHitRequest) (int, error) {
	logger.Info("-->into Send GunsPlatform SetPreciseHit  msg")
	//获取开关机状态
	req := &mavlink.GunsPlatformSetPreciseHitRequest{}
	buff := req.Create(request)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Send GunsPlatform Set PreciseHit info err: %v", err)
		return Fail, fmt.Errorf("request Send GunsPlatform Set PreciseHit info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformSetPreciseHit]
	if !ok {
		manager = NewWaitTaskManager(mavlink.GunsPlatformSetPreciseHit, true, 0)
		d.WaitTaskMap[mavlink.GunsPlatformSetPreciseHit] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request GunsPlatform SetPreciseHit info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.GunsPlatformSetPreciseHitResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response GunsPlatform SetPreciseHit result:%+v", *res)

	return int(res.Status), nil
}
func (d *GunsPlatform) ReceiveSetPreciseHit() {
	logger.Info("-->into Receive Set PreciseHit")
	res := &mavlink.GunsPlatformSetPreciseHitResponse{}
	d.GetPacket(res)
	logger.Debugf("GunsPlatform SetPreciseHit Get 接收到GunsPlatform信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformSetPreciseHit]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}
func (d *GunsPlatform) GunsPlatformGetPreciseHit() (int, error) {
	logger.Info("-->into Send GunsPlatform GetPreciseHit  msg")
	//获取开关机状态
	req := &mavlink.GunsPlatformGetPreciseHitRequest{}
	buff := req.Create()
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Send GunsPlatform Get PreciseHit info err: %v", err)
		return Fail, fmt.Errorf("request Send GunsPlatform Get PreciseHit info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformGetPreciseHit]
	if !ok {
		manager = NewWaitTaskManager(mavlink.GunsPlatformGetPreciseHit, true, 0)
		d.WaitTaskMap[mavlink.GunsPlatformGetPreciseHit] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request GunsPlatform GetPreciseHit info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.GunsPlatformGetPreciseHitResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response GunsPlatform GetPreciseHit result:%+v", *res)

	return int(res.Enable), nil
}
func (d *GunsPlatform) ReceiveGetPreciseHit() {
	logger.Info("-->into Receive Get PreciseHit")
	res := &mavlink.GunsPlatformGetPreciseHitResponse{}
	d.GetPacket(res)
	logger.Debugf("GunsPlatform GetPreciseHit Get 接收到GunsPlatform信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformGetPreciseHit]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *GunsPlatform) GunsPlatformSetInvalidFreq(request *client.GunsPlatformSetInvalidFreqRequest) (int, error) {
	logger.Info("---> Send GunsPlatform Set Invalid")
	defer func() {
		if r := recover(); r != nil {
			logger.Error("GunsPlatform Set Invalid occurred:", r)
			return
		}
	}()
	req := mavlink.GunsPlatformSetInvalidRequestAll{}
	invalidlist := make([]mavlink.GunsPlatformSetInvalidInfo, 0)
	for _, s := range request.FreqList {
		invalidlist = append(invalidlist, mavlink.GunsPlatformSetInvalidInfo{
			StartFreq: uint16(s.StartFreq),
			EndFreq:   uint16(s.EndFreq),
		})
	}
	reqInfo := &mavlink.GunsPlatformSetInvalidRequest{
		SetInvalidNum:  uint8(len(invalidlist)),
		SetInvalidList: invalidlist,
	}

	buff := req.Create(reqInfo)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformSetInvalidFreqList]
	if !ok {
		manager = NewWaitTaskManager(mavlink.GunsPlatformSetInvalidFreqList, true, time.Millisecond*300)
		d.WaitTaskMap[mavlink.GunsPlatformSetInvalidFreqList] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Send GunsPlatform Set Invalid is :[%v]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send GunsPlatform Set Invalid  err:[%v].Buff is [%v]", err, buff)
		return Fail, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send GunsPlatform Set Invalid  err %s", err.Error())
		return Fail, err
	}
	res := result.(*mavlink.GunsPlatformSetInvalidResponse)

	logger.Info("-->End Set GunsPlatform Set Invalid")
	return int(res.Status), nil
}
func (d *GunsPlatform) ReceiveSetInvalid() {
	logger.Info("-->into Receive Set Invalid")
	res := &mavlink.GunsPlatformSetInvalidResponse{}
	d.GetPacket(res)
	logger.Debugf("GunsPlatform Set Invalid 接收到GunsPlatformSfl信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformSetInvalidFreqList]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}
func (d *GunsPlatform) GunsPlatformGetInvalidFreq() ([]*client.FreqList, error) {
	logger.Info("---> Send GunsPlatformGetInvalidFreq")
	var rsp []*client.FreqList
	req := &mavlink.GunsPlatformGetInvalidListRequest{}
	buff := req.Create(0)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformGetInvalidFreqList]
	if !ok {
		manager = NewWaitTaskManager(mavlink.GunsPlatformGetInvalidFreqList, true, 0)
		d.WaitTaskMap[mavlink.GunsPlatformGetInvalidFreqList] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Send GunsPlatformGetInvalidFreqList is :[% x]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send GunsPlatformGetInvalidFreqList err:[%v].Buff is [% x]", err, buff)
		return rsp, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send GunsPlatformGetInvalidFreqList err %s", err.Error())
		return rsp, err
	}
	res := result.(*mavlink.GunsPlatformGetInvalidListResponse)
	for _, des := range res.Description {
		rsp = append(rsp, &client.FreqList{
			StartFreq: int32(des.StartFreqList),
			EndFreq:   int32(des.EndFreqList),
		})
	}
	logger.Info("-->End GunsPlatformGetInvalidFreqList")
	return rsp, nil
}

// ReceiveGetInvalidList 接收 freq无效列表
func (d *GunsPlatform) ReceiveGetInvalidList() {
	res := &mavlink.GunsPlatformGetInvalidListResponse{}
	if err := d.UnmarshalFreqInvalidList(res); err != nil {
		logger.Errorf("parse freq Get Invalid  list response fail, e: %v", err)
		return
	}
	logger.Debugf("receive Send GunsPlatformGetInvalidListResponse：%+v", *res)
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformGetInvalidFreqList]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}
func (d *GunsPlatform) UnmarshalFreqInvalidList(data *mavlink.GunsPlatformGetInvalidListResponse) error {
	deviceInfoLen := binary.Size(mavlink.GunsPlatformFreqInfo{})
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}

	start := mavlink.HeaderLen + deviceInfoLen
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializeDrone(d.Msg[start:end]); err != nil {
		return err
	}
	return nil
}

func (d *GunsPlatform) GunsPlatformSetSwitchParameter(request *client.GunsPlatformSetSwitchParameterRequest) (int, error) {
	logger.Info("-->into Send GunsPlatformSetSwitchParameter  msg,req:", request)
	//获取开关机状态
	req := &mavlink.GunsPlatformSetSwitchParameterRequest{}
	buff := req.Create(request)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Send GunsPlatformSetSwitchParameter info err: %v", err)
		return Fail, fmt.Errorf("request Send GunsPlatformSetSwitchParameter info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformSetSwitchParam]
	if !ok {
		manager = NewWaitTaskManager(mavlink.GunsPlatformSetSwitchParam, true, 0)
		d.WaitTaskMap[mavlink.GunsPlatformSetSwitchParam] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("requestSend GunsPlatformSetSwitchParameter info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.GunsPlatformSetSwitchParameterResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Send GunsPlatformSetSwitchParameter result:%+v", *res)

	return int(res.Status), nil
}
func (d *GunsPlatform) ReceiveGunsPlatformSetSwitchParameter() {
	logger.Info("-->into Receive GunsPlatform SetSwitchParameter")
	res := &mavlink.GunsPlatformSetSwitchParameterResponse{}
	d.GetPacket(res)
	logger.Debugf("GunsPlatform SetSwitchParameter Get ：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformSetSwitchParam]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *GunsPlatform) GunsPlatformGetSwitchParameter(request *client.GunsPlatformGetSwitchParameterRequest) ([]*client.GunsPlatformSwitchParameter, error) {
	logger.Info("-->into Send GunsPlatformSetSwitchParameter  msg,req:", request)
	//获取开关机状态
	req := &mavlink.GunsPlatformGetSwitchParameterRequest{}
	buff := req.Create(request)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Send GunsPlatformGetSwitchParameter info err: %v", err)
		return nil, fmt.Errorf("request Send GunsPlatformGetSwitchParameter info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformGetSwitchParam]
	if !ok {
		manager = NewWaitTaskManager(mavlink.GunsPlatformGetSwitchParam, true, 0)
		d.WaitTaskMap[mavlink.GunsPlatformGetSwitchParam] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("requestSend GunsPlatformGetSwitchParameter info err: %v", checkNetConnErr)
			return nil, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.GunsPlatformGetSwitchParameterResponse)
	if !ok {
		return nil, errors.New("response err type")
	}
	logger.Debug("response Send GunsPlatformGetSwitchParameter result:%+v", *res)
	response := make([]*client.GunsPlatformSwitchParameter, 0)
	response = append(response, &client.GunsPlatformSwitchParameter{Type: int32(res.Type1), Enable: int32(res.Enable1)})
	response = append(response, &client.GunsPlatformSwitchParameter{Type: int32(res.Type2), Enable: int32(res.Enable2)})
	return response, nil
}
func (d *GunsPlatform) ReceiveGunsPlatformGetSwitchParameter() {
	logger.Info("-->into Receive GunsPlatform GetSwitchParameter")
	res := &mavlink.GunsPlatformGetSwitchParameterResponse{}
	d.GetPacket(res)
	logger.Debugf("GunsPlatform GetSwitchParameter Get ：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformGetSwitchParam]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *GunsPlatform) SendGunsPlatformSetHitRadius(request *client.GunsPlatformSetAutoHitRadiusRequest) (int, error) {
	logger.Info("-->into Send GunsPlatform SetAutoHitRadius  msg,req:", request)
	//获取开关机状态
	req := &mavlink.GunsPlatformSetAutoHitRadiusRequest{}
	buff := req.Create(uint32(request.Radius))
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Send GunsPlatform SetAutoHitRadius info err: %v", err)
		return Fail, fmt.Errorf("request Send GunsPlatform SetAutoHitRadius info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformSetAutoRadius]
	if !ok {
		manager = NewWaitTaskManager(mavlink.GunsPlatformSetAutoRadius, true, 0)
		d.WaitTaskMap[mavlink.GunsPlatformSetAutoRadius] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("requestSend GunsPlatform SetAutoHitRadius info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.GunsPlatformSetAutoHitRadiusResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Send GunsPlatform SetAutoHitRadius result:%+v", *res)

	return int(res.Status), nil
}
func (d *GunsPlatform) ReceiveGunsPlatformSetAutoRadius() {
	logger.Info("-->into Receive GunsPlatform SetAutoRadius")
	res := &mavlink.GunsPlatformSetAutoHitRadiusResponse{}
	d.GetPacket(res)
	logger.Debugf("GunsPlatform SetAutoRadius Get ：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformSetAutoRadius]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *GunsPlatform) SendGunsPlatformGetHitRadius(request *client.GunsPlatformGetAutoHitRadiusRequest) (int, error) {
	logger.Info("-->into Send GunsPlatform GetAutoHitRadius  msg,req:", request)
	//获取开关机状态
	req := &mavlink.GunsPlatformGetAutoHitRadiusRequest{}
	buff := req.Create()
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Send GunsPlatform GetAutoHitRadius info err: %v", err)
		return Fail, fmt.Errorf("request Send GunsPlatform GetAutoHitRadius info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformGetAutoRadius]
	if !ok {
		manager = NewWaitTaskManager(mavlink.GunsPlatformGetAutoRadius, true, 0)
		d.WaitTaskMap[mavlink.GunsPlatformGetAutoRadius] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("requestSend GunsPlatform GetAutoHitRadius info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.GunsPlatformGetAutoHitRadiusResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Send GunsPlatform GetAutoHitRadius result:%+v", *res)

	return int(res.Radius), nil
}
func (d *GunsPlatform) ReceiveGunsPlatformGetAutoRadius() {
	logger.Info("-->into Receive GunsPlatform GetAutoRadius")
	res := &mavlink.GunsPlatformGetAutoHitRadiusResponse{}
	d.GetPacket(res)
	logger.Debugf("GunsPlatform GetAutoRadius Get ：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.GunsPlatformGetAutoRadius]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

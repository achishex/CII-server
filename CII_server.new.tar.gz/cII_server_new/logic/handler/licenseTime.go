package handler

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
	"context"
)

type LicenseTime struct {
}

func NewLicenseTime() *LicenseTime {
	return &LicenseTime{}
}

func (w *LicenseTime) UpdateLicenseTime(ctx context.Context, nowTime string, field map[string]interface{}) error {
	var model bean.LicenseTime
	err := db.GetDB().Model(&bean.LicenseTime{}).Where("id=?", 1).First(&model).Error
	if err != nil {
		logger.Errorf("UpdateLicenseTime First err: %v", err)
		return err
	}
	if err = db.GetDB().Model(&bean.LicenseTime{}).Where("id=?", 1).Updates(field).Error; err != nil {
		logger.Errorf("UpdateLicenseTime Updates err: %v", err)
		return err
	}
	return nil
}

func (u *LicenseTime) QueryLicenseTime(ctx context.Context) (error, string) {
	var model bean.LicenseTime
	err := db.GetDB().Model(&bean.LicenseTime{}).Where("id = ?", 1).First(&model).Error
	if err != nil {
		logger.Errorf("query domain by name err:%v", err)
		return err, ""
	}
	return nil, model.LicenseNowTime
}

package handler

import (
	"fmt"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/slink_proto/slinkv2/generatecode/golang/bizproto"
	"adasgitlab.autel.com/tools/slink_proto/slinkv2/msgid"

	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/rpc/devicerpc"
)

// RadarSetConfig 设置雷达配置参数
func (d *Radar) RadarSetConfig(sn string, req *bizproto.RadarC2Config) (*bizproto.RadarC2SetConfigRsp, error) {
	logger.Debugf("RadarSetConfig request: %+v", req)
	deviceResp, err := devicerpc.CallV2(sn, common.DEV_RADAR, msgid.RadarV2SetConfig, req)
	if err != nil {
		logger.Errorf("RadarSetConfig rpc callV2 error: %v", err)
		return nil, err
	}
	result, ok := deviceResp.(*bizproto.RadarC2SetConfigRsp)
	if !ok {
		logger.Errorf("RadarSetConfig convert RadarC2SetConfigRsp error")
		return nil, fmt.Errorf("RadarSetConfig convert RadarC2SetConfigRsp error")
	}
	logger.Debugf("RadarSetConfig response: %+v", result)
	return result, nil
}

// RadarGetConfig 获取雷达配置参数回复
func (d *Radar) RadarGetConfig(sn string) (*bizproto.RadarC2Config, error) {
	deviceResp, err := devicerpc.CallV2(sn, common.DEV_RADAR, msgid.RadarV2GetConfig, nil)
	if err != nil {
		logger.Errorf("RadarGetConfig rpc callV2 error: %v", err)
		return nil, err
	}
	result, ok := deviceResp.(*bizproto.RadarC2Config)
	if !ok {
		logger.Errorf("RadarGetConfig convert RadarC2Config error")
		return nil, fmt.Errorf("RadarGetConfig convert RadarC2Config error")
	}
	logger.Debugf("RadarGetConfig response: %+v", result)
	return result, nil
}

// RadarSetMask 设置雷达Mask
func (d *Radar) RadarSetMask(sn string, req *bizproto.RadarC2Mask) (*bizproto.RadarC2SetMaskRsp, error) {
	logger.Debugf("RadarSetMask request: %+v", req)
	deviceResp, err := devicerpc.CallV2(sn, common.DEV_RADAR, msgid.RadarIdV2SetMask, req)
	if err != nil {
		logger.Errorf("RadarSetMask rpc callV2 error: %v", err)
		return nil, err
	}
	result, ok := deviceResp.(*bizproto.RadarC2SetMaskRsp)
	if !ok {
		logger.Errorf("RadarSetMask convert RadarC2SetMaskRsp error")
		return nil, fmt.Errorf("RadarSetMask convert RadarC2SetMaskRsp error")
	}
	logger.Debugf("RadarSetMask response: %+v", result)
	return result, nil
}

// RadarGetMask 获取雷达Mask
func (d *Radar) RadarGetMask(sn string) (*bizproto.RadarC2Mask, error) {
	deviceResp, err := devicerpc.CallV2(sn, common.DEV_RADAR, msgid.RadarIdV2GetMask, nil)
	if err != nil {
		logger.Errorf("RadarGetMask rpc callV2 error: %v", err)
		return nil, err
	}
	result, ok := deviceResp.(*bizproto.RadarC2Mask)
	if !ok {
		logger.Errorf("RadarGetMask convert RadarC2Mask error")
		return nil, fmt.Errorf("RadarGetMask convert RadarC2Mask error")
	}
	logger.Debugf("RadarGetMask response: %+v", result)
	return result, nil
}

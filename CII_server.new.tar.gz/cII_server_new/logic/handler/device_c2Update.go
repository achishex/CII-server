package handler

import (
	"context"
	"regexp"
	"strings"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/awsS3"
)

func FilterC2ApkVersion(req *client.DownC2ApkRequest) bool {
	if req == nil {
		return false
	}
	//
	if strings.Contains(req.GetVersion(), "_HJ") {
		logger.Infof("is hj version, omit ota update, req: %+v", req)
		return true
	}
	//过滤不符合1.0.0.1这种格式的版本号
	match, _ := regexp.MatchString(`^\d+\.\d+\.\d+\.\d+$`, req.GetVersion())
	if !match {
		logger.Infof("str is omit,req:", req.Version)
		return true
	}
	return false
}

// 下载C2升级包
func (e *DeviceCenter) DownC2Apk(ctx context.Context, req *client.DownC2ApkRequest, rsp *client.DownC2ApkResponse) error {
	logger.Infof("-->Into Down C2 Apk req:%+v", req)
	if FilterC2ApkVersion(req) {
		rsp.Update = false
		rsp.Version = req.Version
		return nil
	}

	if req.TestFlag == 1 {
		updata := false
		var strArr []string
		//获取S3上全部的apk名称
		if req.Platform == "windows" {
			strArr = awsS3.TestWindowsGetBucketObject(req.IsHaveLogo, req.IsHome, req.PkgType)
		} else {
			strArr = awsS3.TestGetBucketObject(req.IsHaveLogo, req.IsHome, req.PkgType)
		}

		latest := GetLatestVersion(strArr)
		logger.Info("-->test Get BucketEnd Latest Version is :", latest)
		if latest == "" {
			rsp.Update = updata
			return nil
		}
		var fileName string
		for _, s := range strArr {
			if strings.Contains(s, latest) {
				fileName = s
			}
		}
		//请求最新版本
		c2DownUrl, errs := awsS3.TestPresigningDownLoadApk(fileName, req.IsHaveLogo, req.IsHome, req.PkgType, req.Platform)
		if errs != nil {
			logger.Error("test Presigning DownLoad C2 APK err:%v", errs)
			rsp.Version = req.Version
			rsp.Update = false
			return errs
		}
		//获取"c2os_v1.0.0.4.dev.apk"  中 1.0.0.4
		re := regexp.MustCompile(`(\d+\.\d+\.\d+\.\d+)`)
		version := re.FindString(latest)
		//获取最大的版本号
		versions := []string{
			version,
			req.Version,
		}
		max := MaxVersion(versions)

		if max == req.Version {
			updata = false
			rsp.Version = req.Version
		} else {
			updata = true
			rsp.Version = version
			rsp.Download = c2DownUrl
		}
		rsp.Update = updata
		upgradeDes, isForceUp, upgradeChinese, upgradeEnglish, upgradeRussian := awsS3.TestGetC2UpgradeDes(rsp.Version, req.IsHome, req.IsHaveLogo, req.PkgType, req.Platform)
		rsp.UpgradeDes = upgradeDes
		rsp.IsForceUpgrade = isForceUp
		rsp.UpgradeDesChinese = upgradeChinese
		rsp.UpgradeDesEnglish = upgradeEnglish
		rsp.UpgradeDesRussian = upgradeRussian
		logger.Info("test rsp UpgradeDes is: ", rsp.UpgradeDes)
		logger.Info("test rsp IsForceUpgrade is: ", rsp.IsForceUpgrade)
		logger.Info("test rsp version is: ", rsp.Version)
		logger.Info("test rsp Update is: ", rsp.Update)
		logger.Info("rsp upgradeChinese is: ", rsp.UpgradeDesChinese)
		logger.Info("rsp upgradeEnglish is: ", rsp.UpgradeDesEnglish)
		logger.Info("rsp upgradeRussian is: ", rsp.UpgradeDesRussian)
		logger.Info("-->test End Down C2 Apk")
	} else {
		updata := false
		var strArr []string
		//获取S3上全部的apk名称
		if req.Platform == "windows" {
			strArr = awsS3.GetBucketObjectWindows(req.IsHaveLogo, req.IsHome, req.PkgType)
		} else {
			strArr = awsS3.GetBucketObject(req.IsHaveLogo, req.IsHome, req.PkgType)
		}

		latest := GetLatestVersion(strArr)

		logger.Info("-->Get BucketEnd Latest Version is :", latest)
		if latest == "" {
			rsp.Update = updata
			return nil
		}
		var fileName string
		for _, s := range strArr {
			if strings.Contains(s, latest) {
				fileName = s
			}
		}
		//请求最新版本
		c2DownUrl, errs := awsS3.PresigningDownLoadApk(fileName, req.IsHaveLogo, req.IsHome, req.PkgType, req.Platform)
		if errs != nil {
			logger.Error("Presigning DownLoad C2 APK err:%v", errs)
			rsp.Version = req.Version
			rsp.Update = false
			return errs
		}
		//获取"c2os_v1.0.0.4.dev.apk"  中 1.0.0.4
		re := regexp.MustCompile(`(\d+\.\d+\.\d+\.\d+)`)
		version := re.FindString(latest)
		//获取最大的版本号
		versions := []string{
			version,
			req.Version,
		}
		max := MaxVersion(versions)

		if max == req.Version {
			updata = false
			rsp.Version = req.Version
		} else {
			updata = true
			rsp.Version = version
			rsp.Download = c2DownUrl
		}

		rsp.Update = updata
		upgradeDes, isForceUp, upgradeChinese, upgradeEnglish, upgradeRussian := awsS3.GetC2UpgradeDes(rsp.Version, req.IsHome, req.IsHaveLogo, req.PkgType, req.Platform)
		rsp.UpgradeDes = upgradeDes
		rsp.IsForceUpgrade = isForceUp
		rsp.UpgradeDesChinese = upgradeChinese
		rsp.UpgradeDesEnglish = upgradeEnglish
		rsp.UpgradeDesRussian = upgradeRussian
		logger.Info("rsp UpgradeDes is: ", rsp.UpgradeDes)
		logger.Info("rsp.IsForceUpgrade is: ", rsp.IsForceUpgrade)
		logger.Info("rsp version is: ", rsp.Version)
		logger.Info("rsp Update is: ", rsp.Update)
		logger.Info("rsp upgradeChinese is: ", rsp.UpgradeDesChinese)
		logger.Info("rsp upgradeEnglish is: ", rsp.UpgradeDesEnglish)
		logger.Info("rsp upgradeRussian is: ", rsp.UpgradeDesRussian)
		logger.Info("-->End Down C2 Apk")
	}
	return nil
}

// DownC2System 下载C2系统升级包
func (e *DeviceCenter) DownC2System(ctx context.Context, req *client.DownC2SystemRequest, rsp *client.DownC2SystemResponse) error {
	logger.Infof("-->Into Down C2 System req:%+v", req)

	if req.TestFlag == 1 {
		updata := false
		var strArr []string
		//获取S3上全部的apk名称

		strArr = awsS3.TestGetC2SystemBucketObject(req.IsHome)

		latest := GetLatestVersion(strArr)
		logger.Info("-->test Get BucketEnd Latest Version is :", latest)
		if latest == "" {
			rsp.Update = updata
			return nil
		}
		var fileName string
		for _, s := range strArr {
			if strings.Contains(s, latest) {
				fileName = s
			}
		}
		//请求最新版本
		c2DownUrl, errs := awsS3.TestPresigningDownLoadSystem(fileName, req.IsHome)
		if errs != nil {
			logger.Error("test Presigning DownLoad C2 System err:%v", errs)
			rsp.Version = req.Version
			rsp.Update = false
			return errs
		}
		//获取"c2os_v1.0.0.4.dev.apk"  中 1.0.0.4
		re := regexp.MustCompile(`(\d+\.\d+\.\d+\.\d+)`)
		version := re.FindString(latest)
		//获取最大的版本号
		versions := []string{
			version,
			req.Version,
		}
		max := MaxVersion(versions)

		if max == req.Version {
			updata = false
			rsp.Version = req.Version
		} else {
			updata = true
			rsp.Version = version
			rsp.Download = c2DownUrl
		}
		rsp.Update = updata
		upgradeChinese, upgradeEnglish, upgradeRussian := awsS3.GetC2SystemUpgradeDes(rsp.Version, req.IsHome)
		rsp.UpgradeDesChinese = upgradeChinese
		rsp.UpgradeDesEnglish = upgradeEnglish
		rsp.UpgradeDesRussian = upgradeRussian
		logger.Info("test rsp version is: ", rsp.Version)
		logger.Info("test rsp Update is: ", rsp.Update)
		logger.Info("rsp upgradeChinese is: ", rsp.UpgradeDesChinese)
		logger.Info("rsp upgradeEnglish is: ", rsp.UpgradeDesEnglish)
		logger.Info("rsp upgradeRussian is: ", rsp.UpgradeDesRussian)
		logger.Info("-->test End Down C2 System")
	} else {
		updata := false
		var strArr []string
		//获取S3上全部的apk名称

		strArr = awsS3.GetC2SystemBucketObject(req.IsHome)

		latest := GetLatestVersion(strArr)

		logger.Info("-->Get BucketEnd Latest Version is :", latest)
		if latest == "" {
			rsp.Update = updata
			return nil
		}
		var fileName string
		for _, s := range strArr {
			if strings.Contains(s, latest) {
				fileName = s
			}
		}
		//请求最新版本
		c2DownUrl, errs := awsS3.PresigningDownLoadSystem(fileName, req.IsHome)
		if errs != nil {
			logger.Error("Presigning DownLoad C2 APK err:%v", errs)
			rsp.Version = req.Version
			rsp.Update = false
			return errs
		}
		//获取"c2os_v1.0.0.4.dev.apk"  中 1.0.0.4
		re := regexp.MustCompile(`(\d+\.\d+\.\d+\.\d+)`)
		version := re.FindString(latest)
		//获取最大的版本号
		versions := []string{
			version,
			req.Version,
		}
		max := MaxVersion(versions)

		if max == req.Version {
			updata = false
			rsp.Version = req.Version
		} else {
			updata = true
			rsp.Version = version
			rsp.Download = c2DownUrl
		}

		rsp.Update = updata
		upgradeChinese, upgradeEnglish, upgradeRussian := awsS3.GetC2SystemUpgradeDes(rsp.Version, req.IsHome)
		rsp.UpgradeDesChinese = upgradeChinese
		rsp.UpgradeDesEnglish = upgradeEnglish
		rsp.UpgradeDesRussian = upgradeRussian
		logger.Info("rsp version is: ", rsp.Version)
		logger.Info("rsp Update is: ", rsp.Update)
		logger.Info("rsp upgradeChinese is: ", rsp.UpgradeDesChinese)
		logger.Info("rsp upgradeEnglish is: ", rsp.UpgradeDesEnglish)
		logger.Info("rsp upgradeRussian is: ", rsp.UpgradeDesRussian)
		logger.Info("-->End Down C2 Apk")
	}
	return nil
}

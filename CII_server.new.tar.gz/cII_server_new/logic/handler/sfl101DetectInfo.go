package handler

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"context"
	"errors"
	"fmt"

	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
)

type Sfl101DetectInfo struct {
}

func NewSfl101DetectInfo() *Sfl101DetectInfo {
	return &Sfl101DetectInfo{}
}
func (w *Sfl101DetectInfo) Insert(ctx context.Context, req *client.Sfl101DetectInfoInsertReq, res *client.Sfl101DetectInfoInsertRes) error {
	var model bean.Sfl101DetectInfo
	model.Sn = req.Sn
	model.Vendor = req.Vendor
	model.Direction = req.Direction
	model.CounterTime = req.CounterTime
	model.HitTime = req.HitTime
	model.Freq = float64(req.Freq)
	model.DetectTime = req.DetectTime
	model.PilotLongLat = req.PilotLongLat
	model.DroneHeight = req.DroneHeight
	model.UDirStatus = req.UDirStatus
	model.DevType = req.DevType

	logger.Info("Into Insert Sfl101 Detect Info")
	if err := db.GetDB().Model(&bean.Sfl101DetectInfo{}).Create(&model).Error; err != nil {
		logger.Errorf("create Sfl101 Detect Info error: %v", err)
		return err
	}
	return nil
}
func (w *Sfl101DetectInfo) UpdateHitTime(ctx context.Context, req *client.Sfl101DetectInfoUpdateReq, rsp *client.Sfl101DetectInfoUpdateRes) error {
	var model bean.Sfl101DetectInfo
	model.HitTime = req.HitTime

	r := db.GetDB().Debug().Model(&bean.Sfl101DetectInfo{}).Where("id=(?)",
		db.GetDB().Model(&bean.Sfl101DetectInfo{}).Select("id").Where("sn=?", req.Sn).Order("detect_time DESC").Limit(1)).
		Update("hit_time", model.HitTime).RowsAffected

	if r == 0 {
		return fmt.Errorf("update Sfl101 Detect Info error: sn=%v not found", req.Sn)
	}

	return nil
}
func (w *Sfl101DetectInfo) UpdateCountTime(ctx context.Context, req *client.Sfl101DetectInfoUpdateReq, rsp *client.Sfl101DetectInfoUpdateRes) error {
	var model bean.Sfl101DetectInfo
	model.CounterTime = req.CounterTime

	r := db.GetDB().Model(&bean.Sfl101DetectInfo{}).Where("sn=?", req.Sn).
		Order("detect_time DESC").Limit(1).
		Updates(&model).RowsAffected

	if r == 0 {
		return fmt.Errorf("update Sfl101 Detect Info error: sn=%v not found", req.Sn)
	}

	return nil
}

func (w *Sfl101DetectInfo) Delete(ctx context.Context, req *client.Sfl101DetectInfoDeleteReq, rsp *client.Sfl101DetectInfoDeleteRes) error {
	//var model bean.DateMarkers
	//
	//err := db.GetDB().Model(&bean.DateMarkers{}).Where("time_stamp = ?", req.Timestamp).Delete(&model).Error
	//if err != nil {
	//	logger.Errorf("delete Date Markers error: %v", err)
	//}

	return nil
}

func (w *Sfl101DetectInfo) List(ctx context.Context, req *client.Sfl101DetectInfoListReq, rsp *client.Sfl101DetectInfoListRes) error {
	var list []*bean.Sfl101DetectInfo
	err := db.GetDB().Model(&bean.Sfl101DetectInfo{}).Where("detect_time >= ? and detect_time <= ?", req.StartTime, req.StopTime).Find(&list).Error
	if err != nil {
		return errors.New("query list failed")
	}
	for _, v := range list {
		var model client.Sfl101DetectInfoList
		w.generateRes(&model, *v)
		rsp.Sfl101List = append(rsp.Sfl101List, &model)
	}
	return nil
}
func (w *Sfl101DetectInfo) generateRes(model *client.Sfl101DetectInfoList, list bean.Sfl101DetectInfo) {
	model.Id = list.Id
	model.Vendor = list.Vendor
	model.PilotLongLat = list.PilotLongLat
	model.Sn = list.Sn
	model.Freq = float32(list.Freq)
	model.DetectTime = list.DetectTime
	model.HitTime = list.HitTime
	model.CounterTime = list.CounterTime
	model.Direction = list.Direction
	model.DroneHeight = list.DroneHeight
	model.UDirStatus = list.UDirStatus
	model.DevType = list.DevType
}

func (w *Sfl101DetectInfo) ListLike(ctx context.Context, req *client.Sfl101DetectInfoListLikeReq, rsp *client.Sfl101DetectInfoListLikeRes) error {
	var list []*bean.Sfl101DetectInfo
	err := db.GetDB().Model(&bean.Sfl101DetectInfo{}).
		Where("detect_time >= ? AND detect_time <= ?", req.StartTime, req.StopTime).
		Where("sn LIKE ? OR vendor LIKE ? OR pilot_long_lat LIKE ?", "%"+req.FindKey+"%", "%"+req.FindKey+"%", "%"+req.FindKey+"%").
		Find(&list).Error
	if err != nil {
		return errors.New("query list failed")
	}
	for _, v := range list {
		var model client.Sfl101DetectInfoList
		w.generateRes(&model, *v)
		rsp.Sfl101List = append(rsp.Sfl101List, &model)
	}
	return nil
}

package handler

import (
	"bytes"
	"context"
	"encoding/binary"
	"log"
	"net"
	"testing"

	"adasgitlab.autel.com/tools/cuav_server/repo/utils"
)

/*
func TestDPH110SetConfig(t *testing.T) {
	var ctx = context.Background()
	convey.Convey("DPH110SetConfig", t, func() {
		convey.Convey("insert", func() {
			var rsp = &client.RadarSetConfigResponse{}
			version := "v1.0.0.1"
			longitude := 113.95204
			latitude := 22.54296
			altitude := 20.0
			req := &client.RadarSetConfigRequest{
				Sn:        "DHP100O00R011001",
				Version:   &version,
				Longitude: &longitude,
				Latitude:  &latitude,
				Altitude:  &altitude,
			}
			err := NewDeviceCenter().DPH110SetConfig(ctx, req, rsp)
			if err != nil {
				t.Errorf("DPH110SetConfig error: %v", err)
			}
			convey.So(err, convey.ShouldBeNil)
			convey.So(rsp.Status, convey.ShouldEqual, 0)
		})

		convey.Convey("update", func() {
			var rsp = &client.RadarSetConfigResponse{}
			version := "v1.0.0.2"
			heading := 0.00
			pitching := 0.00
			rolling := 0.00
			req := &client.RadarSetConfigRequest{
				Sn:       "DHP100O00R011001",
				Version:  &version,
				Heading:  &heading,
				Pitching: &pitching,
				Rolling:  &rolling,
			}
			err := NewDeviceCenter().DPH110SetConfig(ctx, req, rsp)
			if err != nil {
				t.Errorf("DPH110SetConfig error: %v", err)
			}
			convey.So(err, convey.ShouldBeNil)
			convey.So(rsp.Status, convey.ShouldEqual, 0)
		})
	})
}

func TestDPH110GetConfig(t *testing.T) {
	convey.Convey("DPH110GetConfig", t, func() {
		convey.Convey("DPH110GetConfig", func() {
			var (
				ctx = context.Background()
				rsp = &client.RadarGetConfigResponse{}
			)
			req := &client.RadarGetConfigRequest{
				Sn: "DHP100O00R011001",
			}
			err := NewDeviceCenter().DPH110GetConfig(ctx, req, rsp)
			if err != nil {
				t.Errorf("DPH110GetConfig error: %v", err)
			}
			convey.So(err, convey.ShouldBeNil)
			t.Logf("DPH110GetConfig response: %v", rsp)
		})
	})
}
*/

func TestDPH110State(t *testing.T) {
	var controllerDPH110 = NewControllerDPH110()
	addr, err := net.ResolveUDPAddr("udp", ":80")
	if err != nil {
		t.Errorf("ResolveUDPAddr error: %v", err)
		return
	}
	pConn, err := net.ListenUDP("udp", addr)
	if err != nil {
		t.Errorf("ListenUDP error: %v", err)
		return
	}
	t.Logf("UDP server listen on %v", addr)

	go func() {
		addr, err := net.ResolveUDPAddr("udp", ":80")
		if err != nil {
			log.Printf("ResolveUDPAddr error: %v", err)
			return
		}
		dConn, err := net.DialUDP("udp", nil, addr)
		if err != nil {
			log.Printf("DialUDP error: %v", err)
			return
		}
		//err = sendStateInfo(dConn)
		err = sendTargetInfo(dConn)
		//err = sendTrackInfo(dConn)
	}()
	if err != nil {
		t.Errorf("sendStateInfo error: %v", err)
		return
	}
	controllerDPH110.Handle(context.Background(), "127.0.0.1", pConn)
}

func sendStateInfo(dConn *net.UDPConn) error {
	dphState := &DPHStateInfo{
		SysStatus:             [1]uint8{0x00},
		WorkStatus:            [1]uint8{0x22},
		CommandExecStatus:     [1]uint8{0x11},
		FaultType:             [1]uint8{0x00},
		ReceiveCheckResult:    0,
		OfficeCheckResult:     0,
		FiberLinkStatus:       [1]uint8{1},
		GPUCheckResult:        [1]uint8{1},
		PCIeCheckResult:       [1]uint8{1},
		CuringParamReadStatus: [1]uint8{1},
		StandbyCounter:        23391,
		ClutterSLStatus:       [1]uint8{0x00},
		CPUCoreCnt:            [1]uint8{0},
		CPUTemperature:        [12]uint8{0},
		GPUTemperature:        [1]uint8{0},
	}
	copy(dphState.Sn[:], []byte("DHP100O00R011001"))
	copy(dphState.RadarType[:], []byte("DPH110"))
	copy(dphState.Version[:], []byte("v1.0.0.1"))

	var buf bytes.Buffer
	if err := utils.WriteBinary(&buf, binary.LittleEndian, dphState, 415); err != nil {
		log.Printf("WriteBinary dphState error: %v", err)
		return err
	}
	dphData := DPHData{
		Magic:           uint16(0x55AA),
		MsgId:           uint16(0xFF01),
		Seq:             0,
		SourceId:        [1]uint8{0x32},
		DestId:          [1]uint8{0x30},
		Length:          uint32(len(buf.Bytes())),
		payload:         buf.Bytes(),
		ProtocolId:      [1]uint8{1},
		ProtocolVersion: [1]uint8{200},
		Reserved:        [1]uint8{0},
		CheckSum:        [1]uint8{125},
	}

	buf.Reset()
	if err := utils.WriteBinary(&buf, binary.LittleEndian, dphData, 415+16); err != nil {
		log.Printf("WriteBinary error: %v", err)
		return err
	}
	n, err := dConn.Write(buf.Bytes())
	if err != nil {
		log.Printf("Write error: %v", err)
		return err
	}
	log.Printf("DPHStateInfo Write %d bytes", n)
	return nil
}

func sendTargetInfo(dConn *net.UDPConn) error {
	var j uint16 = 0
	var jj uint16 = 0
	var i uint32
	//删除数据
	if j == 10 {
		dphTargetList := &DPHTargetData{
			CurrentServoAngle:   11190 + i,
			ServoScanCycleCount: 3570,
			FrameID:             1806337,
			TrackObjNum:         1,
			ItemList:            make([]TargetItem, 0),
		}
		item := TargetItem{
			TargetTrackDeleteFlag:       0x01,
			Id:                          1 + jj,
			ForCastFrameNum:             0,
			TargetLossReason:            0,
			TargetUpdateTime:            1896319,
			TargetMeasuredDoppler:       4,
			TargetMeasuredDistance:      87,
			Mag:                         59.57065,
			Snr:                         15.129239,
			Velocity:                    -5.9210525,
			Range:                       810,
			Azimuth:                     100.752686,
			Elevation:                   6.08,
			Height:                      85.79275,
			AzimuthDeviation:            2.1599998,
			ElevationDeviation:          0.08,
			PredictedSpeed:              -5.9210525,
			PredictedDistance:           826.0263,
			PredictedAzimuth:            101.74104,
			PredictedElevation:          5.961605,
			PredictedHeight:             85.79275,
			FilterSpeed:                 -5.9210525,
			FilteredDistance:            807.0789,
			FilteredAzimuth:             100.17153,
			FilteredElevation:           6.08,
			FilteredHeight:              85.79275,
			FilteredAverageSpeed:        16.741072,
			FilteredAverageAcceleration: 0,
			EnvelopePoints:              3,
			TrackPriority:               3,
			AssociationNum:              2,
			Classification:              [1]uint8{0x01},
			PitchBeamNumber:             1,
			NormalizedEnergy:            67.95125,
			Reserved1:                   [8]float32{},
			Reserved2:                   [25]uint8{},
		}
		dphTargetList.ItemList = append(dphTargetList.ItemList, item)

		var buf bytes.Buffer
		if err := utils.WriteBinary(&buf, binary.LittleEndian, dphTargetList, 188); err != nil {
			log.Printf("WriteBinary Sn error: %v", err)
			return err
		}
		dphData := DPHData{
			Magic:           uint16(0x55AA),
			MsgId:           uint16(0xFF03),
			Seq:             0,
			SourceId:        [1]uint8{0x32},
			DestId:          [1]uint8{0x30},
			Length:          uint32(len(buf.Bytes())),
			payload:         buf.Bytes(),
			ProtocolId:      [1]uint8{1},
			ProtocolVersion: [1]uint8{200},
			Reserved:        [1]uint8{0},
			CheckSum:        [1]uint8{252},
		}

		buf.Reset()
		if err := utils.WriteBinary(&buf, binary.LittleEndian, dphData, 188+16); err != nil {
			log.Printf("WriteBinary error: %v", err)
			return err
		}
		n, err := dConn.Write(buf.Bytes())
		if err != nil {
			log.Printf("Write error: %v", err)
			return err
		}
		log.Printf("DPHTargetData Write %d bytes", n)
		jj++
	}

	//当前扫描周期计数值-最后更新的扫描周期计数值>3
	/*if j == 10 {
		var k uint32 = 0
		dphTargetList := &DPHTargetData{
			CurrentServoAngle:   11190 + i,
			ServoScanCycleCount: 3570+k,
			FrameID:             1806337,
			TrackObjNum:         1,
			ItemList:            make([]TargetItem, 0),
		}
		item := TargetItem{
			TargetTrackDeleteFlag:       0x00,
			Id:                          1 + jj,
			ForCastFrameNum:             0,
			TargetLossReason:            0,
			TargetUpdateTime:            1896319,
			TargetMeasuredDoppler:       4,
			TargetMeasuredDistance:      87,
			Mag:                         59.57065,
			Snr:                         15.129239,
			Velocity:                    -5.9210525,
			Range:                       810,
			Azimuth:                     100.752686,
			Elevation:                   6.08,
			Height:                      85.79275,
			AzimuthDeviation:            2.1599998,
			ElevationDeviation:          0.08,
			PredictedSpeed:              -5.9210525,
			PredictedDistance:           826.0263,
			PredictedAzimuth:            101.74104,
			PredictedElevation:          5.961605,
			PredictedHeight:             85.79275,
			FilterSpeed:                 -5.9210525,
			FilteredDistance:            807.0789,
			FilteredAzimuth:             100.17153,
			FilteredElevation:           6.08,
			FilteredHeight:              85.79275,
			FilteredAverageSpeed:        16.741072,
			FilteredAverageAcceleration: 0,
			EnvelopePoints:              3,
			TrackPriority:               3,
			AssociationNum:              2,
			Classification:              [1]uint8{0x01},
			PitchBeamNumber:             1,
			NormalizedEnergy:            67.95125,
			Reserved1:                   [8]float32{},
			Reserved2:                   [25]uint8{},
		}
		dphTargetList.ItemList = append(dphTargetList.ItemList, item)

		var buf bytes.Buffer
		if err = utils.WriteBinary(&buf, binary.LittleEndian, dphTargetList, 188); err != nil {
			log.Printf("WriteBinary Sn error: %v", err)
			return err
		}
		dphData := DPHData{
			Magic:           uint16(0x55AA),
			MsgId:           uint16(0xFF03),
			Seq:             0,
			SourceId:        [1]uint8{0x32},
			DestId:          [1]uint8{0x30},
			Length:          uint32(len(buf.Bytes())),
			payload:         buf.Bytes(),
			ProtocolId:      [1]uint8{1},
			ProtocolVersion: [1]uint8{200},
			Reserved:        [1]uint8{0},
			CheckSum:        [1]uint8{252},
		}

		buf.Reset()
		if err = utils.WriteBinary(&buf, binary.LittleEndian, dphData, 188+16); err != nil {
			log.Printf("WriteBinary error: %v", err)
			return err
		}
		n, err := dConn.Write(buf.Bytes())
		if err != nil {
			log.Printf("Write error: %v", err)
			return err
		}
		log.Printf("DPHTargetData Write %d bytes", n)
		jj ++
		k = k + 4
	}*/

	if j == 10 {
		j = 0
	}
	dphTargetList := &DPHTargetData{
		CurrentServoAngle:   11190 + i,
		ServoScanCycleCount: 3570,
		FrameID:             1806337,
		TrackObjNum:         1,
		ItemList:            make([]TargetItem, 0),
	}
	item := TargetItem{
		TargetTrackDeleteFlag:       0x00,
		Id:                          1 + j,
		ForCastFrameNum:             0,
		TargetLossReason:            0,
		TargetUpdateTime:            1896319,
		TargetMeasuredDoppler:       4,
		TargetMeasuredDistance:      87,
		Mag:                         59.57065,
		Snr:                         15.129239,
		Velocity:                    -5.9210525,
		Range:                       810,
		Azimuth:                     100.752686,
		Elevation:                   6.08,
		Height:                      85.79275,
		AzimuthDeviation:            2.1599998,
		ElevationDeviation:          0.08,
		PredictedSpeed:              -5.9210525,
		PredictedDistance:           826.0263,
		PredictedAzimuth:            101.74104,
		PredictedElevation:          5.961605,
		PredictedHeight:             85.79275,
		FilterSpeed:                 -5.9210525,
		FilteredDistance:            807.0789,
		FilteredAzimuth:             100.17153,
		FilteredElevation:           6.08,
		FilteredHeight:              85.79275,
		FilteredAverageSpeed:        16.741072,
		FilteredAverageAcceleration: 0,
		EnvelopePoints:              3,
		TrackPriority:               3,
		AssociationNum:              2,
		Classification:              [1]uint8{0x01},
		PitchBeamNumber:             1,
		NormalizedEnergy:            67.95125,
		Reserved1:                   [8]float32{},
		Reserved2:                   [25]uint8{},
	}
	dphTargetList.ItemList = append(dphTargetList.ItemList, item)

	var buf bytes.Buffer
	if err := utils.WriteBinary(&buf, binary.LittleEndian, dphTargetList, 188); err != nil {
		log.Printf("WriteBinary Sn error: %v", err)
		return err
	}
	dphData := DPHData{
		Magic:           uint16(0x55AA),
		MsgId:           uint16(0xFF03),
		Seq:             0,
		SourceId:        [1]uint8{0x32},
		DestId:          [1]uint8{0x30},
		Length:          uint32(len(buf.Bytes())),
		payload:         buf.Bytes(),
		ProtocolId:      [1]uint8{1},
		ProtocolVersion: [1]uint8{200},
		Reserved:        [1]uint8{0},
		CheckSum:        [1]uint8{227},
	}

	buf.Reset()
	if err := utils.WriteBinary(&buf, binary.LittleEndian, dphData, 188+16); err != nil {
		log.Printf("WriteBinary error: %v", err)
		return err
	}
	n, err := dConn.Write(buf.Bytes())
	if err != nil {
		log.Printf("Write error: %v", err)
		return err
	}
	log.Printf("DPHTargetData Write %d bytes", n)
	j++
	i = i + 100

	return nil
}

func sendTrackInfo(dConn *net.UDPConn) error {
	dphTrackData := &DPHTracerData{
		ServoAngle:                  320,
		FilterSpeed:                 23.68,
		FilteredDistance:            1000,
		FilteredAzimuth:             45,
		FilteredElevation:           45,
		FilteredHeight:              114.97,
		FilteredAverageSpeed:        12.46,
		FilteredAverageAcceleration: 0.37,
		Classification:              [1]uint8{0x01},
	}

	var buf bytes.Buffer
	if err := utils.WriteBinary(&buf, binary.LittleEndian, dphTrackData, 241); err != nil {
		log.Printf("WriteBinary Sn error: %v", err)
		return err
	}
	dphData := DPHData{
		Magic:           uint16(0x55AA),
		MsgId:           uint16(0xFF04),
		Seq:             0,
		SourceId:        [1]uint8{0x32},
		DestId:          [1]uint8{0x30},
		Length:          uint32(len(buf.Bytes())),
		payload:         buf.Bytes(),
		ProtocolId:      [1]uint8{1},
		ProtocolVersion: [1]uint8{200},
		Reserved:        [1]uint8{0},
		CheckSum:        [1]uint8{244},
	}

	buf.Reset()
	if err := utils.WriteBinary(&buf, binary.LittleEndian, dphData, 241+16); err != nil {
		log.Printf("WriteBinary error: %v", err)
		return err
	}
	n, err := dConn.Write(buf.Bytes())
	if err != nil {
		log.Printf("Write error: %v", err)
		return err
	}
	log.Printf("Write %d bytes", n)
	return nil
}

/*func TestCalculateCoordinates(t *testing.T) {
	convey.Convey("CalculateCoordinates", t, func() {
		convey.Convey("CalculateCoordinates", func() {
			var controllerDPH110 = NewControllerDPH110()
			controllerDPH110.Sn = "DHP110O00R011001"
			dph110Model, dronePoint, err := controllerDPH110.calculateCoordinates(1000, 30, 30)
			convey.So(err, convey.ShouldBeNil)
			convey.So(dph110Model, convey.ShouldNotBeNil)
			convey.So(dronePoint, convey.ShouldNotBeNil)
			log.Printf("dph110Model: %+v, dronePoint: %+v", dph110Model, dronePoint)
			X := dronePoint.X
			Y := dronePoint.Y
			Z := dronePoint.Z
			R := math.Sqrt(X*X + Y*Y + Z*Z)
			t.Logf("R: %f", R)
			convey.So(R, convey.ShouldAlmostEqual, 1000, 0.01)
		})
	})
}*/

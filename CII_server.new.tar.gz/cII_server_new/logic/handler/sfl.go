package handler

import (
	"bytes"
	"context"
	"crypto/rand"
	"encoding/binary"
	"encoding/csv"
	"errors"
	"fmt"
	"math/big"
	"os"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"adasgitlab.autel.com/tools/slink_proto/slinkv1"
	"golang.org/x/time/rate"

	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
	"adasgitlab.autel.com/tools/cuav_server/repo/monitoring"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
	"adasgitlab.autel.com/tools/cuav_server/repo/utils"

	"adasgitlab.autel.com/tools/cuav_plugin/broker"
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"github.com/360EntSecGroup-Skylar/excelize"
	"google.golang.org/protobuf/proto"

	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/server"
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/ip"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/proto/mavlink"
)

const (
	SflTcpPort        = 14000
	SflServerMaxCount = 500
	SflUpdateTime     = 60000 //60秒

	DetectFreqTion         = 1000
	ElevationTion          = 100
	GunDirectTion          = 100
	GunLongitudeTion       = 1e7
	GunLatitudeTion        = 1e7
	DroneHeightTion        = 10
	DroneYawTion           = 100
	DroneSpeedTion         = 100
	DroneVerticalSpeedTion = 100
	DroneHorizonTion       = 100
	DronePitch             = 100
	DroneTion              = 1e7
	DroneSailLongitudeTion = 1e7
	DroneSailLatitudeTion  = 1e7
	SflChartTion           = 100

	InvalidValueInt8   = 0xFF
	InvalidValueInt16  = 0x7FFF
	InvalidValueInt32  = 0x7FFFFFFF
	InvalidValueUInt16 = 0xFFFF
	InvalidValue       = -999
)

const (
	HITING  = 1
	HITOVER = 2
)

// Ref: SFL100通信协议V1.0.1 docx
const (
	sflburst      = 1  //perf me with better value @fzw
	sflDetectRate = 10 //10Hz
	sflHitRate    = 2  //2Hz
	sflHeartRate  = 10 //10Hz
)

type sflLimit struct {
	detectLimit *rate.Limiter
	hitLimit    *rate.Limiter
	heartLimit  *rate.Limiter
}
type Sfl struct {
	*Device
	dt common.DeviceType
	*sflLimit
}

var _ DeviceIfer = (*Sfl)(nil)

// SetDevice 要使用GetOnLineDev 接口，必须要给该设备实现 DeviceIfer 接口
func (tg *Sfl) SetDevice(d *Device) {
	tg.Device = d
}

var (
	SflTcpServerLock sync.Mutex
	SflTcpServerMap  sync.Map
	SflHeartSum      uint8
	SflDetectInfoMap = common.NewSflDetectInfoMap()
)

func InitSflCounter() {
	dbMetric := monitoring.NewMetricDbOpsInst(nil,
		monitoring.WithDBOnMetricDBOPS(db.GetMonitorDB()),
		monitoring.WithTabNameOnMetricDBOPS("Counter_SflID"), // 本地文件存储数据库表名，需要自定义
		monitoring.WithIsDebugOnMetricDBOPS(true))

	droneCounter := &monitoring.DeviceCounter{}
	droneCounter.Counter = monitoring.NewMetricCounterDecorator(
		monitoring.CreatePromPusherClientOnBackend(),
		dbMetric, "", monitoring.VectorOpts, "")

	monitoring.DevCounterMetricHandle.RegisterCounterMetric(int(common.DEV_SFL), droneCounter, GetDevGuid)
}

func NewSfl(conn Connection, d []byte, dataLen int, remoteIp string, remotePort int, localIp string, serverPort int,
	mailBox map[int]*WaitTaskManager, dlimit *devLimit) DeviceInterface {
	sfl := &Sfl{
		Device: &Device{
			Conn:        conn,
			Msg:         d,
			MsgLen:      dataLen,
			SourceId:    d[mavlink.SenderLoc],
			RemoteIp:    remoteIp,
			RemotePort:  remotePort,
			LocalIp:     localIp,
			ServerPort:  serverPort,
			WaitTaskMap: mailBox,
		},
		sflLimit: &sflLimit{
			detectLimit: dlimit.sfl.detectLimit,
			hitLimit:    dlimit.sfl.hitLimit,
			heartLimit:  dlimit.sfl.heartLimit,
		},
	}

	//if len(d) <= mavlink.MsgIdLoc+1 {
	//	return sfl
	//}
	//monitoring.DevCounterMetricHandle.Inc(int(common.DEV_SFL),
	//	GetSnByPort(sfl.ServerPort), TranIntToHex(int(d[mavlink.MsgIdLoc])))
	return sfl
}
func (d *Sfl) Deal() {
	defer func() {
		if err := recover(); err != nil {
			logger.Error("Sfl deal 接收到panic:", err)
		}
	}()

	if d.MsgLen <= 0 {
		logger.Error("Sfl 数据为null,不作处理:", d.Device.RemoteIp)
		return
	}
	d.MsgId = int(d.Msg[mavlink.MsgIdLoc])
	switch d.MsgId {
	case mavlink.SflHeartMsg:
		if d.heartLimit.Allow() {
			d.Heart()
		} else {
			logger.Error("speed of sfl heartbeat is quite fast,msgid:", d.MsgId)
			heart := &mavlink.SflHeart{}
			if err := d.UnmarshalPayload(heart); err != nil {
				logger.Errorf(err.Error())
			}
			logger.Debug("heart = ", heart)
		}
	case mavlink.SflDevStateMsg:
		d.ReceiveSflDevStateMsg()
	case mavlink.SflSendNotifyIdMsg:
		d.SflNotifyIdMsg()
	case mavlink.SflDetectMsg:
		if d.detectLimit.Allow() {
			d.ReceiveSflDetectMsg()
		} else {
			logger.Error("speed of sfl detect is quite fast,msgid:", d.MsgId)
			result := &mavlink.SflDetect{}
			if err := d.UnmarshalPayloadSflDetect(result); err != nil {
				logger.Errorf(err.Error())
			}
			logger.Debug("result = ", result)
		}
	case mavlink.SflHitStatusMsg:
		if d.hitLimit.Allow() {
			d.ReceiveSflHitStatusMsg()
		} else {
			logger.Error("speed of sfl hit is quite fast,msgid:", d.MsgId)
			hit := &mavlink.SflHit{}
			if err := d.UnmarshalPayloadHitInfo(hit); err != nil {
				logger.Errorf(err.Error())
			}
			logger.Debug("hit = ", hit)
		}
	case mavlink.SflRadarChartMsg:
		d.ReceiveSflRadarChartMsg()
	case mavlink.SflSendFreqData:
		d.ReceiveSflCollectData()
	case mavlink.SflGetFreqCmd:
		d.ReceiveSflSetFreqCmd()
	case mavlink.SflSendTimeFreq:
		d.ReceiveSflSendTimeFreq()
	case mavlink.SflSendNoiseDataD6:
		d.ReceiveSflSendTimeFreqD6()
	case mavlink.SflGetVersion:
		d.ReceiveSflGetVersion()
	case mavlink.SflGetTime:
		d.ReceiveGetTime()
	case mavlink.SFLGetGNSS:
		d.ReceiveSflGetGNNS()
	case mavlink.SFLSetGNSS:
		d.ReceiveSflSetGNNS()
	case mavlink.SflGetHitPith:
		d.ReceiveSflGetHitPith()
	case mavlink.SflGetHitAngle:
		d.ReceiveSflGetHitAngle()
	case mavlink.SflGetHitMode:
		d.ReceiveSflGetHitMode()
	case mavlink.SflReset:
		d.ReceiveSflReset()
	case mavlink.SflSendHitUav:
		d.ReceiveSflGetHitUav()

	case mavlink.SflSetOnOff:
		d.ReceiveSflSetOnOff()

	case mavlink.SflGetOnOff:
		d.ReceiveSflGetOnOff()
	case mavlink.SflSetPith:
		d.ReceiveSflSetPith()
	case mavlink.SflSetAngle:
		d.ReceiveSflSetAngle()
	case mavlink.SflStopHit:
		d.ReceiveSflStopHit()
	case mavlink.SflSetHitMode:
		d.ReceiveSflSetHitMode()
	case mavlink.SflSetAutoHitMode:
		d.ReceiveSflSetAutoHitMode()
	case mavlink.SflGetAutoHitMode:
		d.ReceiveSflGetAutoHitMode()
	case mavlink.SflIdUpgradeF1:
		d.ReceiveSflUpdateF1()
	case mavlink.SflIdUpgradeF2:
		d.ReceiveSflUpdateF2()
	case mavlink.SflIdUpgradeF3:
		d.ReceiveSflUpdateF3()
	case mavlink.SflHitTurn:
		d.ReceiveSflTurnHit()
	case mavlink.SflHorizontalTurn:
		d.ReceiveSflHorizontalTurn()
	case mavlink.SflVerticalTurn:
		d.ReceiveSflVerticalTurn()
	case mavlink.SflCrashStop:
		d.ReceiveSflCrashStop()
	case mavlink.SflSetNoise:
		d.ReceiveSflSetNoise()
	case mavlink.SflSendNoiseData:
		d.ReceiveSflSendNoiseData()
	case mavlink.SflGetFreqList:
		d.ReceiveSflGetFreqList()
	case mavlink.SflSetPreciseHit:
		d.ReceiveSetPreciseHit()
	case mavlink.SflGetPreciseHit:
		d.ReceiveGetPreciseHit()
	case mavlink.SflSetInvalidFreqList:
		d.ReceiveSetInvalid()
	case mavlink.SflGetInvalidFreqList:
		d.ReceiveGetInvalidList()
	case mavlink.SflSetAutoRadius:
		d.ReceiveSflSetAutoRadius()
	case mavlink.SflGetAutoRadius:
		d.ReceiveSflGetAutoRadius()
	case mavlink.SflSetSwitchParam:
		d.ReceiveSflSetSwitchParameter()
	case mavlink.SflGetSwitchParam:
		d.ReceiveSflGetSwitchParameter()
	case mavlink.SflSetDevPosture:
		d.ReceiveSflSetPosture()
	case mavlink.SflGetDevPosture:
		d.ReceiveSflGetPosture()
	case mavlink.SflDroneIdDataEncrypt:
		d.ReciveEncryptDataSteam()
	case mavlink.SflDroneIdResultDecrytp:
		d.ReceiveDecryptDataResult()
	case mavlink.SflIsDecryptMsg:
		d.ReceiveSflIsDecryptMsg()
	case mavlink.SflSendPerformanceEvaluateStart:
		d.ReceivePerformanceEvaluate()
	case mavlink.SflPerformanceEvaluateReport:
		d.ReceivePerformanceEvaReport()
	case mavlink.SflPerformanceEvaluateRefStart:
		d.ReceivePerformanceEvaluateRef()

	default:
		logger.Error("Sfl 未知Sfl消息id:", d.MsgId)
		break
	}
}

func SendSflHeart() {
	ticker := time.NewTicker(time.Second * 1)
	defer ticker.Stop()
	for range ticker.C {
		DevStatusMap.Range(func(key, value interface{}) bool {
			dev := value.(*Device)
			if dev.DevType == common.DEV_SFL && dev.Status == common.DevOnline {
				reqMode := &Sfl{
					Device: dev,
					dt:     common.DEV_SFL,
				}
				reqMode.SendExtHeartbeat()
			}
			return true
		})
	}
}
func (d *Sfl) SendExtHeartbeat() error {
	SflHeartSum++
	if SflHeartSum > 255 {
		SflHeartSum = 0
	}
	req := &mavlink.SflHeartbeatExtRequest{
		SflHeartSum,
	}
	reqBuff := req.CreateSflHeartbeatExt()
	if d != nil && d.Conn != nil {
		_, err := d.Conn.Write(reqBuff)
		logger.Infof("Sfl c2发送心跳结果：%X", reqBuff)
		if err != nil {
			equipModel, err := GetEquipBySn(d.Sn)
			name := d.Sn
			if equipModel != nil && equipModel.Name != "" {
				name = equipModel.Name
			}
			dataInfo := &client.SflHeartInfo{
				Header: &client.EquipmentMessageBoxEntity{
					Name:      name,
					Sn:        d.Sn,
					EquipType: int32(common.DEV_SFL),
					MsgType:   mavlink.SflHeartMsgReport,
				},
				Data: &client.GimbalCounterHeartInfo{
					Sn:       d.Sn,
					IsOnline: common.DevOffline,
				},
			}
			if err == nil {
				dataInfo.Header.ParentType = int32(equipModel.ParentType)
				dataInfo.Header.ParentSn = equipModel.ParentSn
				dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
			}
			msg, err := proto.Marshal(dataInfo)
			if err != nil {
				logger.Error("marshal dataInfo err:", err)
				return err
			}
			report := &client.ClientReport{
				MsgType: common.ClientMsgIDSFLHeartBeat,
				Data:    msg,
			}
			out, err := proto.Marshal(report)
			if err != nil {
				logger.Error("marshal report err:", err)
				return err
			}
			_ = mq.SflMsgBroker.Publish(mq.SflTopic, broker.NewMessage(out))
			logger.Info("sfl Offline report:", report)
		}
		return err
	}
	return nil
}

// SflOfflineReport SFL离线处理
func SflOfflineReport(sn string) {
	var tcpServer *server.TcpServer
	if s, ok := SflTcpServerMap.Load(sn); ok {
		tcpServer = s.(*server.TcpServer)

		if tcpServer != nil {
			tcpServer.Stop()
		}
		deviceUsedPorts.Delete(tcpServer.Port)
		SflTcpServerMap.Delete(sn)
		DevSnMap.Delete(tcpServer.Port)
		cachekeyDroneid := fmt.Sprintf("%d_%s", common.DEV_SFL, sn)
		DevStatusMap.Delete(cachekeyDroneid)
		SflDetectInfoMap.Clear()
		tcpServer = nil
	}

	equipModel, err := GetEquipBySn(sn)
	name := sn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	dataInfo := &client.SflHeartInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        sn,
			EquipType: int32(common.DEV_SFL),
			MsgType:   mavlink.SflHeartMsgReport,
		},
		Data: &client.GimbalCounterHeartInfo{
			Sn:       sn,
			IsOnline: common.DevOffline,
		},
	}
	if err == nil {
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgIDSFLHeartBeat,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}
	dev := FindCacheDevice(sn, common.DEV_SFL)
	if dev != nil {
		d := &Sfl{Device: dev}
		d.collectTaskOffline(sn)
	}
	_ = mq.SflMsgBroker.Publish(mq.SflTopic, broker.NewMessage(out))
	logger.Info("sfl Offline report:", report)
	SflOffLineEventReport(sn)
}

func SflDetectDisappearEventReport(sn string) {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_SFL, sn)
	eventId := ""

	if cache, ok := DevDetectMapOnEvent.Load(cacheKey); ok {
		detect := cache.(*DetectEvent)
		eventId = utils.GetEventId(detect.SessionId)
		logger.Infof("eventId: %v, sessionId: %v", eventId, detect.SessionId)
	} else {
		logger.Infof("has not eventId for sfl detect disappear event report, sn: %v", sn)
	}
	DevDetectMapOnEvent.Delete(cacheKey)

	equipModel, err := GetEquipBySn(sn)
	name := sn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	dataInfo := &client.SflDetectInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        sn,
			EquipType: int32(common.DEV_SFL),
			MsgType:   mavlink.SflEventDetectDisappear,
		},
		Data: &client.GimbalCounterDetectSocketInfo{
			Sn:      sn,
			EventId: eventId,
		},
	}
	if err == nil {
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgSFlDetectEventData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Info("sfl detect disappear event report:", report)
}
func SflHitOverEventReport(hitNode *common.SflHitEventInfo) {
	var (
		eventID                         = ""
		hitSucc                         = false
		hitOver *common.SflHitEventInfo = nil
	)

	cacheKey := GetSflHitCacheKey(hitNode.UavSn, hitNode.DroneName, hitNode.ProductType)
	if cache, ok := SflHitOverMapOnEvent.Load(cacheKey); ok {
		hitOver, ok = cache.(*common.SflHitEventInfo)
		if !ok {
			return
		}

		eventID = utils.GetEventId(hitOver.SessionId)
		if time.Since(hitOver.DetectReportTime) > 3*time.Second {
			hitSucc = true //disappear at begin, or recently disappear
		}
	} else {
		return
	}
	SflHitOverMapOnEvent.Delete(cacheKey)

	equipModel, err := GetEquipBySn(hitNode.Sn)
	name := hitNode.Sn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	dataInfo := &client.SflHitStateInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        hitNode.Sn, // sfl sn
			EquipType: int32(common.DEV_SFL),
		},
		Data: &client.GimbalCounterHitSocketInfo{
			SerialNum:      hitNode.UavSn,
			DroneName:      hitOver.DroneName,
			DroneLongitude: hitOver.DroneLongitude,
			DroneLatitude:  hitOver.DroneLatitude,
			DroneHeight:    hitOver.DroneHeight,
			DroneYawAngle:  hitOver.DroneYawAngle,
			EventId:        eventID,
		},
	}
	if err == nil {
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	if hitSucc == false {
		dataInfo.Header.MsgType = mavlink.SflEventHitFail
	} else {
		dataInfo.Header.MsgType = mavlink.SflEventHitSucc
	}

	logger.Infof("sfl hit over report: %v", dataInfo)
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgSflHitEventData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Infof("sfl hit status: %v, event report: %v", hitSucc, report)
}

func SflOffLineEventReport(sn string) {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_SFL, sn)
	eventId := ""

	if cache, ok := DevStatusMapOnEvent.Load(cacheKey); ok {
		dev := cache.(*Device)
		eventId = utils.GetEventId(dev.SessionId)
	}
	DevStatusMapOnEvent.Delete(cacheKey)

	equipModel, err := GetEquipBySn(sn)
	name := sn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	dataInfo := &client.SflHeartInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        sn,
			EquipType: int32(common.DEV_SFL),
			MsgType:   mavlink.SflEventMsgOffLine,
		},
		Data: &client.GimbalCounterHeartInfo{
			Sn:       sn,
			IsOnline: common.DevOffline,
			EventId:  eventId,
		},
	}
	if err == nil {
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgSFlStatusEventData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Info("sfl Offline event report:", report)
}

// Heart 处理SFL心跳消息
func (d *Sfl) Heart() {
	heart := &mavlink.SflHeart{}
	if err := d.UnmarshalPayload(heart); err != nil {
		logger.Errorf(err.Error())
		return
	}

	devSn := ByteToString(heart.Info.Sn[:])
	if devSn != "" {
		// update device status
		d.updateOnLineStatus(devSn, heart)
		d.updateStatus(devSn, int(heart.Info.DevSubId))
		//if isEnable := d.updateStatus(devSn); isEnable == common.DeviceDisenable {
		//	logger.Infof("Sfl device %v disable", devSn)
		//	return
		//}
		// report heartbeat
		d.HeartReport(devSn, heart)
	}
}
func (d *Sfl) HeartReport(devSn string, heartInfo *mavlink.SflHeart) {

	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	dataInfo := &client.SflHeartInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        devSn,
			EquipType: int32(common.DEV_SFL),
			MsgType:   mavlink.SflHeartMsgReport,
		},
		Data: &client.GimbalCounterHeartInfo{
			Sn:              devSn,
			TimeStamp:       int32(heartInfo.Info.TimeStamp),
			WorkStatus:      int32(heartInfo.Info.WorkStatus),
			IsOnline:        common.DevOnline,
			HitFreq:         int32(heartInfo.Info.HitFreq),
			DetectFreq:      float64(heartInfo.Info.DetectFreq) / DetectFreqTion,
			Elevation:       float64(heartInfo.Info.Elevation) / ElevationTion,
			GunDirection:    float64(heartInfo.Info.GunDirection) / GunDirectTion,
			GunLongitude:    float64(heartInfo.Info.GunLongitude) / GunLongitudeTion,
			GunLatitude:     float64(heartInfo.Info.GunLatitude) / GunLatitudeTion,
			GunAltitude:     float64(heartInfo.Info.GunAltitude),
			SatellitesNum:   int32(heartInfo.Info.SatellitesNum),
			FaultLevel:      int32(heartInfo.Info.FaultLevel),
			CtrlFault:       int32(heartInfo.Info.CtrlFault),
			AeagFault:       int32(heartInfo.Info.AeagFault),
			TracerFault:     int32(heartInfo.Info.TracerFault),
			WorkStatusParam: int32(heartInfo.Info.WorkStatusParam),
			DevSubId:        int32(heartInfo.Info.DevSubId),
		},
	}
	if err == nil {
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgIDSFLHeartBeat,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.SflMsgBroker.Publish(mq.SflTopic, broker.NewMessage(out))

	logger.Infof("Sfl heartbeat has reported, devSn:%v,report:%v", devSn, dataInfo.Data)
}

// Heart 处理SFL心跳消息
func (d *Sfl) SflNotifyIdMsg() {
	notifyId := &mavlink.SflSendNotifyId{}
	if err := d.UnmarshalPayloadNotifyId(notifyId); err != nil {
		logger.Errorf(err.Error())
		return
	}

	devSn := ByteToString(notifyId.Info.Sn[:])
	if devSn != "" {
		d.updateStatus(devSn, 0)

		d.NotifyIdReport(devSn, notifyId)
	}
}
func (d *Sfl) NotifyIdReport(devSn string, notifyIdInfo *mavlink.SflSendNotifyId) {

	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	dataInfo := &client.SflNotifyIdInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        devSn,
			EquipType: int32(common.DEV_SFL),
			MsgType:   mavlink.SflSendNotifyIdMsg,
		},
		Data: &client.SflNotifyIdInfoData{
			Sn:        devSn,
			TimeStamp: int64(notifyIdInfo.Info.TimeStamp),
			NotifyId:  int32(notifyIdInfo.Info.NotifyId),
		},
	}
	if err == nil {
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgIDSFLNotifyId,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.SflMsgBroker.Publish(mq.SflTopic, broker.NewMessage(out))

	logger.Infof("Sfl NotifyId has reported, devSn:%v,report:%v", devSn, dataInfo.Data)
}

// Heart 处理SFL设备信息
func (d *Sfl) ReceiveSflDevStateMsg() {
	devState := &mavlink.SflDevState{}
	if err := d.UnmarshalPayloadDevStateMsg(devState); err != nil {
		logger.Errorf(err.Error())
		return
	}

	devSn := ByteToString(devState.Info.Sn[:])
	if devSn != "" {
		// update device status
		d.updateStatus(devSn, 0)
		d.DevStateReport(devSn, devState)
	}
}
func (d *Sfl) UnmarshalPayloadDevStateMsg(data *mavlink.SflDevState) error {
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("Sfl UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("Sfl UnmarshalPayload read data err: %v", err)
	}

	return nil
}
func (d *Sfl) DevStateReport(devSn string, devStateInfo *mavlink.SflDevState) {

	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	dataInfo := &client.SflDevStateInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        devSn,
			EquipType: int32(common.DEV_SFL),
			MsgType:   mavlink.SflDevStateMsg,
		},
		Data: &client.SflDevStateInfoData{
			Sn:              devSn,
			TimeStamp:       int64(devStateInfo.Info.TimeStamp),
			SportState:      int32(devStateInfo.Info.SportState),
			GpsState:        int32(devStateInfo.Info.GPSState),
			GpsSateliteNum:  int32(devStateInfo.Info.GPSSateliteNum),
			DGpsState:       int32(devStateInfo.Info.DGPSState),
			DGpsSateliteNum: int32(devStateInfo.Info.DGPSSateliteNum),
			DGpsRaw:         devStateInfo.Info.DGPSRaw,
			CpuTemperature:  devStateInfo.Info.CPUTemperature,
			CoreTemperature: devStateInfo.Info.CoreTemperature,
			Amp1Temperature: devStateInfo.Info.Amp1Temperature,
			Amp2Temperature: devStateInfo.Info.Amp2Temperature,
		},
	}
	if err == nil {
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgIdSFLDevStateE0,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.SflMsgBroker.Publish(mq.SflTopic, broker.NewMessage(out))

	logger.Infof("Sfl devState Info has reported, devSn:%v,report:%v", devSn, dataInfo.Data)
}

var GlobalSessionId int64 = time.Now().UnixMilli()

func GetGlobalSessionId() int64 {
	return atomic.AddInt64(&GlobalSessionId, 1)
}

func (d *Sfl) updateOnLineStatus(sn string, heartInfo *mavlink.SflHeart) int32 {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_SFL, sn)
	if cache, ok := DevStatusMapOnEvent.Load(cacheKey); ok {
		dev := cache.(*Device)
		//if dev.IsEnable == common.DeviceDisenable {
		//	return common.DeviceDisenable
		//}
		dev.Status = common.DevOnline
		dev.LastHeartTime = time.Now()
		dev.GetStatusInterval = time.Now()
		return common.DeviceEnable
	}

	dev := &Device{
		Sn:                sn,
		Status:            common.DevOnline,
		RemoteIp:          d.RemoteIp,
		RemotePort:        d.RemotePort,
		LocalIp:           d.LocalIp,
		ServerPort:        d.ServerPort,
		DevType:           common.DEV_SFL,
		FirstHeartTime:    time.Now(),
		LastHeartTime:     time.Now(),
		SourceId:          d.SourceId,
		IsEnable:          common.DeviceEnable,
		GetStatusInterval: time.Now(),
		SessionId:         GetGlobalSessionId(),
	}
	DevStatusMapOnEvent.Store(cacheKey, dev)
	//SendNotify

	go func() {
		equipModel, err := GetEquipBySn(sn)
		name := sn
		if equipModel != nil && equipModel.Name != "" {
			name = equipModel.Name
		}
		dataInfo := &client.SflHeartInfo{
			Header: &client.EquipmentMessageBoxEntity{
				Name:      name,
				Sn:        sn,
				EquipType: int32(common.DEV_SFL),
				MsgType:   mavlink.SflEventMsgOnline,
			},
			Data: &client.GimbalCounterHeartInfo{
				Sn:           sn,
				EventId:      utils.GetEventId(dev.SessionId),
				GunLatitude:  float64(heartInfo.Info.GunLatitude) / GunLatitudeTion,
				GunLongitude: float64(heartInfo.Info.GunLongitude) / GunLongitudeTion,
			},
		}
		if err == nil {
			dataInfo.Header.ParentType = int32(equipModel.ParentType)
			dataInfo.Header.ParentSn = equipModel.ParentSn
			dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
		}
		msg, err := proto.Marshal(dataInfo)
		if err != nil {
			logger.Error("marshal dataInfo err:", err)
			return
		}

		report := &client.ClientReport{
			MsgType: common.ClientMsgSFlStatusEventData,
			Data:    msg,
		}
		out, err := proto.Marshal(report)
		if err != nil {
			logger.Error("marshal report err:", err)
			return
		}

		_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
		logger.Infof("Sfl heartbeat event has reported, devSn: %v,report:%v", sn, dataInfo.Data)
	}()
	return common.DeviceEnable

}
func (d *Sfl) updateStatus(sn string, subDevType int) int32 {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_SFL, sn)
	if cache, ok := DevStatusMap.Load(cacheKey); ok {
		dev := cache.(*Device)
		//if dev.IsEnable == common.DeviceDisenable {
		//	return common.DeviceDisenable
		//}
		dev.Status = common.DevOnline
		dev.Conn = d.Conn
		dev.WaitTaskMap = d.WaitTaskMap
		dev.RemoteIp = d.RemoteIp
		dev.LastHeartTime = time.Now()
		dev.GetStatusInterval = time.Now()
		//if dev.IsEnable != common.DeviceDisenable && dev.IsEnable != common.DeviceEnable {
		//dev.IsEnable = d.GetStatus(sn)
		//}
		d.GetStatus(sn, subDevType)
		return common.DeviceEnable
	} else {
		dev := &Device{
			Sn:                sn,
			Conn:              d.Conn,
			Status:            common.DevOnline,
			RemoteIp:          d.RemoteIp,
			RemotePort:        d.RemotePort,
			LocalIp:           d.LocalIp,
			ServerPort:        d.ServerPort,
			DevType:           common.DEV_SFL,
			FirstHeartTime:    time.Now(),
			LastHeartTime:     time.Now(),
			SourceId:          d.SourceId,
			IsEnable:          d.GetStatus(sn, subDevType),
			GetStatusInterval: time.Now(),
			WaitTaskMap:       d.WaitTaskMap,
		}
		DevStatusMap.Store(cacheKey, dev)
		go func() {
			time.Sleep(time.Second * 2)
			e := NewEquipList().Update(context.Background(), &client.EquipCrudReq{
				Sn: sn,
				Ip: d.RemoteIp,
			}, &client.EquipCrudRes{})
			logger.Infof("update dev ip: %v, e: %v", d.RemoteIp, e)

			//发送白名单给Sfl设备
			go SendDevWhiteListToSfl()
			if d.Conn == nil {
				return
			}
			appVer, err := d.SendGetVersionInfo(sn)
			logger.Infof("sfl get  Ver: %v", appVer)
			if err != nil {
				logger.Infof("sfl get  Ver runVer: %v err: %v \n", appVer, err)
				return
			}
			if appVer != "" {
				err = NewEquipList().Update(context.Background(), &client.EquipCrudReq{
					Sn:         sn,
					DevVersion: appVer,
					IsOnline:   true,
				}, &client.EquipCrudRes{})
				if err != nil {
					logger.Error("Update EquipList err: ", err)
				}
			}
		}()
		return dev.IsEnable
	}
}
func (d *Sfl) updateStatusDetect(sn string) int32 {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_SFL, sn)
	if cache, ok := DevStatusMap.Load(cacheKey); ok {
		dev := cache.(*Device)
		//if dev.IsEnable == common.DeviceDisenable {
		//	return common.DeviceDisenable
		//}
		dev.Status = common.DevOnline
		dev.Conn = d.Conn
		dev.WaitTaskMap = d.WaitTaskMap
		dev.RemoteIp = d.RemoteIp
		dev.LastHeartTime = time.Now()
		dev.GetStatusInterval = time.Now()
		//if dev.IsEnable != common.DeviceDisenable && dev.IsEnable != common.DeviceEnable {
		//dev.IsEnable = d.GetStatus(sn)
		//}
		return common.DeviceEnable
	} else {
		dev := &Device{
			Sn:                sn,
			Conn:              d.Conn,
			Status:            common.DevOnline,
			RemoteIp:          d.RemoteIp,
			RemotePort:        d.RemotePort,
			LocalIp:           d.LocalIp,
			ServerPort:        d.ServerPort,
			DevType:           common.DEV_SFL,
			FirstHeartTime:    time.Now(),
			LastHeartTime:     time.Now(),
			SourceId:          d.SourceId,
			IsEnable:          common.DeviceEnable,
			GetStatusInterval: time.Now(),
			WaitTaskMap:       d.WaitTaskMap,
		}
		DevStatusMap.Store(cacheKey, dev)
		go func() {
			time.Sleep(time.Second * 2)
			e := NewEquipList().Update(context.Background(), &client.EquipCrudReq{
				Sn: sn,
				Ip: d.RemoteIp,
			}, &client.EquipCrudRes{})
			logger.Infof("update dev ip: %v, e: %v", d.RemoteIp, e)

			//发送白名单给Sfl设备
			go SendDevWhiteListToSfl()
			if d.Conn == nil {
				return
			}
			appVer, err := d.SendGetVersionInfo(sn)
			logger.Infof("sfl get  Ver: %v", appVer)
			if err != nil {
				logger.Infof("sfl get  Ver runVer: %v err: %v \n", appVer, err)
				return
			}
			if appVer != "" {
				err = NewEquipList().Update(context.Background(), &client.EquipCrudReq{
					Sn:         sn,
					DevVersion: appVer,
				}, &client.EquipCrudRes{})
				if err != nil {
					logger.Error("Update EquipList err: ", err)
				}
			}
		}()
		return dev.IsEnable
	}
}
func (d *Sfl) UnmarshalPayload(data *mavlink.SflHeart) error {
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("Sfl UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("Sfl UnmarshalPayload read data err: %v", err)
	}

	return nil
}
func (d *Sfl) UnmarshalPayloadNotifyId(data *mavlink.SflSendNotifyId) error {
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("Sfl UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("Sfl UnmarshalPayload read data err: %v", err)
	}

	return nil
}

// HandleBroadCast 处理广播消息
func (d *Sfl) HandleBroadCast(ctx context.Context, req *slinkv1.UdpBroadcastConfirmRequest) (*slinkv1.UdpBroadcastConfirmResponse, error) {
	if req.GetSn() == "" {
		logger.Info("device sn empty")
		return nil, errors.New("device sn empty")
	}
	//d.GetStatus(req.GetSn())
	//if status := d.GetStatus(req.GetSn()); status == common.DeviceDisenable {
	//	logger.Infof("device %v disable", req.GetSn())
	//	return nil, nil
	//}

	localIP := make([]string, 0)
	localIps, broadIps, err := ip.GetBroadcastAddress()
	if err != nil {
		logger.Error("Get IP error :%v", err)
	}
	for i, ip := range localIps {
		if i >= len(broadIps) {
			continue
		}
		localIP = append(localIP, ip)
	}
	logger.Debugf("[Sfl] localIP:%v,", localIP)

	tcpServer := d.TcpServerCheck(req.GetSn(), localIP)
	DevSnMap.Store(tcpServer.Port, req.GetSn())
	d.ServerPort = tcpServer.Port

	//响应
	rsp := &slinkv1.UdpBroadcastConfirmResponse{
		Sn:       req.Sn,
		Addr:     ip.IPV4(tcpServer.Ip),
		Port:     uint16(tcpServer.Port),
		ConnType: 1,
	}
	return rsp, nil
}

func (d *Sfl) ReceiveGetChannelReq() {
	SflTcpServerLock.Lock()
	defer SflTcpServerLock.Unlock()

	devSn := d.UnMarshalGetChannelReq()
	if devSn == "" {
		logger.Info("Sfl device sn empty")
		return
	}

	//if isContinue := d.deviceDiscover(devSn); !isContinue {
	//	logger.Error("droneID等待设备确认：", devSn)
	//	return
	//}
	//d.GetStatus(devSn)
	//if status := d.GetStatus(devSn); status == common.DeviceDisenable {
	//	logger.Infof("Sfl device %v disable", devSn)
	//	return
	//}

	localIP := make([]string, 0)

	localIps, broadIps, err := ip.GetBroadcastAddress()
	if err != nil {
		logger.Error("Sfl Get IP error :%v", err)
	}
	for i, ip := range localIps {
		if i >= len(broadIps) {
			continue
		}
		localIP = append(localIP, ip)
	}
	logger.Debugf("[Sfl] localIP:%v,", localIP)

	tcpServer := d.TcpServerCheck(devSn, localIP)
	DevSnMap.Store(tcpServer.Port, devSn)
	d.ServerPort = tcpServer.Port

	//响应
	switch d.MsgId {
	case mavlink.SflUdpBroadcastResponse:
		logger.Info("[Sfl] receive Broadcast BB Msg")
		UdpBroadcastSendChannel(devSn, d.UdpIp, d.SourceId, tcpServer)
		break
	default:
		break
	}

	return
}

func (d *Sfl) TcpServerCheck(devSn string, localIP []string) *server.TcpServer {
	var tcpServer *server.TcpServer
	if s, ok := SflTcpServerMap.Load(devSn); ok {
		tcpServer = s.(*server.TcpServer)
		isAlike := false
		for _, ip := range localIP {
			if ip == tcpServer.Ip {
				isAlike = true
			}
		}
		if isAlike == false { //查找的本地IP没有与之前相同的
			if tcpServer != nil {
				tcpServer.Stop()
			}
			deviceUsedPorts.Delete(tcpServer.Port)
			SflTcpServerMap.Delete(devSn)
			DevSnMap.Delete(tcpServer.Port)
			tcpServer = nil
		}
	}

	//注册tcp服务
	if tcpServer == nil {
		port, err := ip.GetFreeTcpPort()
		if err != nil {
			logger.Error("Sfl tcp 获取可用端口失败：", err)
			port = d.getRandPort(SflTcpPort, SflTcpPort+SflServerMaxCount)
		}
		tcpServer = server.NewTcpServer(port, Handle)
		SflTcpServerMap.Store(devSn, tcpServer)
		tcpServer.ServerType = uint8(common.DEV_SFL)
		tcpServer.ServerName = devSn
		localAddr, _ := ip.GetLocalIp(d.UdpIp)
		tcpServer.Ip = localAddr
		go tcpServer.Start()
	}
	return tcpServer
}

func (d *Sfl) getRandPort(min, max int64) int {
	maxBigInt := big.NewInt(max)
	i, _ := rand.Int(rand.Reader, maxBigInt)
	_, ok := deviceUsedPorts.Load(i.Int64())
	port := i.Int64()
	//缓存不存在或者符合范围
	if !ok && (port > min && port < max) {
		deviceUsedPorts.Store(port, port)
		return int(port)
	}
	return d.getRandPort(min, max)
}
func (d *Sfl) GetStatus(sn string, subDevType int) int32 {
	statusRes := &client.GetStatusRes{}
	err := NewEquipList().GetStatus(context.Background(), &client.GetStatusReq{Sn: sn, EType: "Sfl", SubDevType: int64(subDevType)}, statusRes)
	if err != nil {
		logger.Errorf("GetStatus err: %v", err.Error())
		return 0
	}

	return statusRes.IsEnable
}

func (d *Sfl) UnMarshalGetChannelReq() string {
	devSn := ""
	switch d.MsgId {
	case mavlink.SflUdpBroadcastResponse:
		req := &mavlink.UdpBroadcastConfirmRequest{}
		d.GetPacket(req)
		devSn = strings.TrimRight(string(req.Sn[:]), string(rune(0)))
		break
	default:
		break
	}
	return devSn
}

func (d *Sfl) GetPacket(message mavlink.Message) *mavlink.MavPacket {
	logger.Infof("Sfl GetPacket is [% x]", d.Msg)
	req := mavlink.NewNullPacket(message)
	buff := &bytes.Buffer{}
	if err := binary.Write(buff, binary.LittleEndian, d.Msg); err != nil {
		logger.Error("Sfl GetPacket write buff err:", err)
		return nil

	}
	if err := binary.Read(buff, binary.LittleEndian, &req.Header); err != nil {
		logger.Error("Sfl GetPacket read header err:", err)
		return nil
	}
	if err := binary.Read(buff, binary.LittleEndian, req.Msg); err != nil {
		logger.Error("Sfl GetPacket read msg err:", err)
		return nil
	}
	return req
}

func (d *Sfl) ReceiveSflDetectMsg() {
	result := &mavlink.SflDetect{}
	if err := d.UnmarshalPayloadSflDetect(result); err != nil {
		logger.Errorf(err.Error())
		return
	}

	devSn := ByteToString(result.Info.SN[:])
	if devSn != "" {
		d.updateStatusDetect(devSn)
		d.SflDetectReport(devSn, result)
	}
	logger.Info("--->End Receive Sfl Detect")
}
func (d *Sfl) SflDetectAppearEvent(sn string, detectInfo *client.GimbalCounterDetectSocketInfo) {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_SFL, sn)
	if cache, ok := DevDetectMapOnEvent.Load(cacheKey); ok {
		detect := cache.(*DetectEvent)
		detect.LastReceiveTime = time.Now()
		return
	}

	if len(detectInfo.GetList()) <= 0 {
		logger.Infof("has not detect any uav")
		return
	}

	detect := &DetectEvent{
		Sn:              sn,
		LastReceiveTime: time.Now(),
		DevType:         common.DEV_SFL,
		SessionId:       GetGlobalSessionId(),
	}
	DevDetectMapOnEvent.Store(cacheKey, detect)
	detectInfo.EventId = utils.GetEventId(detect.SessionId)

	go func() {
		equipModel, err := GetEquipBySn(sn)
		name := sn
		if equipModel != nil && equipModel.Name != "" {
			name = equipModel.Name
		}
		msg := &client.SflDetectInfo{
			Header: &client.EquipmentMessageBoxEntity{
				Name:      name,
				Sn:        sn,
				EquipType: int32(common.DEV_SFL),
				MsgType:   mavlink.SflEventDetectAppear,
			},
			Data: detectInfo,
		}
		if err == nil {
			msg.Header.ParentType = int32(equipModel.ParentType)
			msg.Header.ParentSn = equipModel.ParentSn
			msg.Header.IsIntegrated = equipModel.IsIntegrated
		}
		msgOut, err := proto.Marshal(msg)
		if err != nil {
			logger.Error("marshal msg err:", err)
			return
		}
		report := &client.ClientReport{
			MsgType: common.ClientMsgSFlDetectEventData,
			Data:    msgOut,
		}
		out, err := proto.Marshal(report)
		if err != nil {
			logger.Error("marshal dataInfo err:", err)
			return
		}

		_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
		logger.Infof("Sfl detect uav event has reported, devSn: %v,report:%v", sn, detectInfo.GetList())
	}()
	go SendAlarmEmail(detectInfo)

}
func CalcHitOverStatus(droneHeight int16, droneDistance uint16) bool {
	if droneHeight < 10 {
		return true
	}
	if droneHeight >= 10 && droneDistance > 200 {
		return true
	}
	return false
}

// SflHitOverCheckEventReport 打击无人机时，无人机位置变动满足打击成功，上报打击成功事件。
func (d *Sfl) SflHitOverCheckEventReport(uav *mavlink.SflDetectDescription, devSn string) {
	if uav == nil {
		return
	}

	uavSn := ByteToString(uav.SerialNum[:])
	cacheKey := GetSflHitCacheKey(uavSn, ByteToString(uav.DroneName[:]), int32(uav.ProductType))
	cache, ok := SflHitOverMapOnEvent.Load(cacheKey)
	if !ok || cache == nil {
		return
	}
	hitOverNode, ok := cache.(*common.SflHitEventInfo)
	if !ok {
		return
	}

	hitSucc := CalcHitOverStatus(uav.DroneHeight, uav.UDistance)
	if !hitSucc {
		//如果不满足打击成功，则继续记录无人机上报信息。
		hitOverNode.DetectReportTime = time.Now()
		//
		hitOverNode.DroneName = ByteToString(uav.DroneName[:])
		hitOverNode.DroneLongitude = float64(uav.DroneLongitude) / DroneTion
		hitOverNode.DroneLatitude = float64(uav.DroneLatitude) / DroneTion
		hitOverNode.DroneHeight = float64(uav.DroneHeight) / DroneHeightTion
		hitOverNode.DroneYawAngle = float64(uav.DroneYawAngle) / DroneYawTion
		//
		SflHitOverMapOnEvent.Store(cacheKey, hitOverNode)
		logger.Infof("hit fail, uav: %v", cacheKey)
		return
	}

	// 打击满足成功，则上报打击成功事件
	eventId := utils.GetEventId(hitOverNode.SessionId)
	logger.Infof("hit succ, uav: %v, sn: %v", cacheKey, devSn)
	SflHitOverMapOnEvent.Delete(cacheKey)

	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	dataInfo := &client.SflHitStateInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        devSn,
			EquipType: int32(common.DEV_SFL),
			MsgType:   mavlink.SflEventHitSucc,
		},
		Data: &client.GimbalCounterHitSocketInfo{
			SerialNum:      uavSn,
			DroneName:      ByteToString(uav.DroneName[:]),
			DroneLongitude: float64(uav.DroneLongitude) / DroneTion,
			DroneLatitude:  float64(uav.DroneLatitude) / DroneTion,
			DroneHeight:    float64(uav.DroneHeight) / DroneHeightTion,
			DroneYawAngle:  float64(uav.DroneYawAngle) / DroneYawTion,
			EventId:        eventId,
		},
	}
	if err == nil {
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	logger.Infof("sfl hit succ report event: %v", dataInfo)

	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgSflHitEventData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Info("sfl hit succ event report:", report)
}

func (d *Sfl) SflDetectReport(devSn string, detectInfo *mavlink.SflDetect) {
	dataInfo := &client.GimbalCounterDetectSocketInfo{}
	dataInfo.List = make([]*client.GimbalCounterDetectDroneInfo, 0, len(detectInfo.Description))
	dataInfo.Sn = devSn
	dataInfo.DetectionNum = int32(detectInfo.Info.DetectionNum)
	//查白名单中的无人机，在Tracer侦测结果中添加无人机角色
	whiteList := &client.ListResAll{}
	err := NewWhiteList().ListAll(context.Background(), &client.ListReqAll{}, whiteList)
	if err != nil {
		logger.Error("Get whiteList err: ", err)
		return
	}

	var dstDetectItems []*client.GimbalCounterDetectDroneInfo
	//检查无效值
	for _, drone := range detectInfo.Description {
		if drone.Source == 0 {
			drone = DetectCheckInputNum(drone)
			//1-敌军 2-友军 3-未知 4-中立     批量导入为2友军
			var role int32
			for _, info := range whiteList.WhiteList {
				if info.Sn == ByteToString(drone.SerialNum[:]) && info.Sn != "" {
					role = info.Role
				}
			}
			if role == ERRTYPE {
				role = ENEMY
			}

			var wifiMac [6]uint8
			wifiMac = drone.WifiMac
			wifiMacBytes := make([]byte, len(wifiMac))
			for i, v := range wifiMac {
				wifiMacBytes[i] = v
			}

			r := &client.GimbalCounterDetectDroneInfo{
				ProductType:        int32(drone.ProductType),
				DroneName:          ByteToString(drone.DroneName[:]),
				SerialNum:          ByteToString(drone.SerialNum[:]),
				DroneLongitude:     float64(drone.DroneLongitude) / DroneTion,
				DroneLatitude:      float64(drone.DroneLatitude) / DroneTion,
				DroneHeight:        float64(drone.DroneHeight) / DroneHeightTion,
				DroneYawAngle:      float64(drone.DroneYawAngle) / DroneYawTion,
				DroneSpeed:         float64(drone.DroneSpeed) / DroneSpeedTion,
				DroneVerticalSpeed: float64(drone.DroneVerticalSpeed) / DroneVerticalSpeedTion,
				SpeedDirection:     int32(drone.SpeedDerection) / DroneSpeedTion,
				DroneSailLongitude: float64(drone.DroneSailLongitude) / DroneSailLongitudeTion,
				DroneSailLatitude:  float64(drone.DroneSailLatitude) / DroneSailLatitudeTion,
				PilotLongitude:     float64(drone.PilotLongitude) / DroneTion,
				PilotLatitude:      float64(drone.PilotLatitude) / DroneTion,
				DroneHorizon:       float64(drone.DroneHorizon) / DroneHorizonTion,
				DronePitch:         float64(drone.DronePitch) / DronePitch,
				UFreq:              float64(drone.UFreq) / DetectFreqTion,
				UDistance:          int32(drone.UDistance),
				UDangerLevels:      int32(drone.UDangerLevels),
				Role:               role,
				UZC:                int32(drone.Uzc),
				UDirStatus:         int32(drone.UDirStatus),
				UNumber:            uint32(drone.UNumber),
				GpsClocks:          drone.GpsClocks,
				TimeStampRid:       drone.TimestampRid,
				IdType:             uint32(drone.IdType),
				WifiMac:            wifiMacBytes,
				FlagTime:           drone.FlagTime,
			}

			r.DroneName = common.ConstructDroneName(r.DroneName, r.SerialNum, r.UNumber)
			logger.Debugf("GimbalCounterDetectDroneInfo : r = %+v", r)
			//过滤频谱数据
			if r.SerialNum != "" && role != FRIEND {
				//计算无人机威胁等级
				fd, err := NewAlarmControl().GetDroneThreatLevel(&GetThreatLevelReq{
					DroneSn:        r.SerialNum,
					DroneObjId:     0,
					DroneLongitude: r.DroneLongitude,
					DroneLatitude:  r.DroneLatitude,
					DevSn:          devSn,
				})
				if err != nil {
					logger.Errorf("SflDetectReport GetDroneThreatLevel err: %v", err)
				} else {
					r.AlarmId = fd.AlarmId
					r.EventId = fd.EventId
					r.ThreatLevel = fd.ThreatLevel
					r.ScenesId = fd.ScenesId
				}
			}

			logger.Infof("Sfl Detect data: %v", r)
			dataInfo.List = append(dataInfo.List, r)
			//记录探测信息
			RecordSflInfo(r)

			d.SflHitOverCheckEventReport(drone, devSn)
			dstDetectItems = append(dstDetectItems, r)
		}
	}
	// 处理打击后无人机消失时上报打击成功事件
	d.SflHitOverUavDisappearProc(dstDetectItems, devSn)

	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	msg := &client.SflDetectInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        devSn,
			EquipType: int32(common.DEV_SFL),
			MsgType:   mavlink.SflDetectMsgReport,
		},
		Data: dataInfo,
	}
	if err == nil {
		msg.Header.ParentType = int32(equipModel.ParentType)
		msg.Header.ParentSn = equipModel.ParentSn
		msg.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msgOut, err := proto.Marshal(msg)
	if err != nil {
		logger.Error("marshal msg err:", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIDSFLDetect,
		Data:    msgOut,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	_ = mq.SflMsgBroker.Publish(mq.SflTopic, broker.NewMessage(out))
	d.SflDetectAppearEvent(devSn, dataInfo)
	logger.Infof("Sfl Detect has reported, devSn: %v, Drone size: %v", devSn, msg.Data)
}

// SflHitOverUavDisappearProc 打击无人机后，无人机消失时 上报打击成功事件。
func (d *Sfl) SflHitOverUavDisappearProc(uavs []*client.GimbalCounterDetectDroneInfo, devSn string) {
	var disappearHitNode []*common.SflHitEventInfo

	SflHitOverMapOnEvent.Range(func(key, value interface{}) bool {
		hitNode := value.(*common.SflHitEventInfo)
		existNode := false

		for _, uav := range uavs {
			if uav == nil {
				continue
			}
			//
			if uav.ProductType == hitNode.ProductType &&
				uav.DroneName == hitNode.DroneName &&
				uav.SerialNum == hitNode.UavSn {
				existNode = true
			}
		}

		if !existNode {
			disappearHitNode = append(disappearHitNode, hitNode)
			logger.Infof("history hit node disappear, ProductType: %v, uavSn: %v, uavName: %v",
				hitNode.ProductType, hitNode.UavSn, hitNode.DroneName)
		}
		return true
	})

	for _, hitNode := range disappearHitNode {
		if hitNode == nil {
			continue
		}
		//
		eventId := utils.GetEventId(hitNode.SessionId)
		cacheKey := GetSflHitCacheKey(hitNode.UavSn, hitNode.DroneName, hitNode.ProductType)
		SflHitOverMapOnEvent.Delete(cacheKey)
		//
		equipModel, err := GetEquipBySn(devSn)
		name := devSn
		if equipModel != nil && equipModel.Name != "" {
			name = equipModel.Name
		}

		dataInfo := &client.SflHitStateInfo{
			Header: &client.EquipmentMessageBoxEntity{
				Name:      name,
				Sn:        devSn,
				EquipType: int32(common.DEV_SFL),
				MsgType:   mavlink.SflEventHitSucc,
			},
			Data: &client.GimbalCounterHitSocketInfo{
				SerialNum:      hitNode.UavSn,
				DroneName:      hitNode.DroneName,
				DroneLongitude: hitNode.DroneLongitude,
				DroneLatitude:  hitNode.DroneLatitude,
				DroneHeight:    hitNode.DroneHeight,
				DroneYawAngle:  hitNode.DroneYawAngle,
				EventId:        eventId,
			},
		}
		if err == nil {
			dataInfo.Header.ParentType = int32(equipModel.ParentType)
			dataInfo.Header.ParentSn = equipModel.ParentSn
			dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
		}
		logger.Infof("sfl hit succ report event: %v", dataInfo)

		msg, err := proto.Marshal(dataInfo)
		if err != nil {
			logger.Error("marshal dataInfo err:", err)
			return
		}

		report := &client.ClientReport{
			MsgType: common.ClientMsgSflHitEventData,
			Data:    msg,
		}
		out, err := proto.Marshal(report)
		if err != nil {
			logger.Error("marshal report err:", err)
			return
		}

		_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
		logger.Info("sfl hit succ event report:", report)
	}
}
func RecordSflInfo(r *client.GimbalCounterDetectDroneInfo) {
	_, isExist := SflDetectInfoMap.Get(r.SerialNum)
	tempTime := time.Now().UnixMilli()
	if !isExist { //不存在添加
		logger.Info("Sfl add drone event,", r.SerialNum)
		piltlong := strconv.FormatFloat(r.PilotLongitude, 'f', 4, 64)
		piltlat := strconv.FormatFloat(r.PilotLatitude, 'f', 4, 64)
		SflDetectInfoMap.Set(r.SerialNum, r.DroneName, tempTime, 0, 0, r.UFreq,
			int64(r.DroneYawAngle), piltlong+","+piltlat, tempTime, r.UDirStatus)
		//写数据库
		err := NewSflDetectInfo().Insert(context.Background(), &client.SflDetectInfoInsertReq{
			Sn:           r.SerialNum,
			Vendor:       r.DroneName,
			DetectTime:   tempTime,
			HitTime:      0,
			CounterTime:  0,
			Freq:         float32(r.UFreq),
			Direction:    int64(r.DroneHorizon),
			PilotLongLat: piltlong + " , " + piltlat,
			DroneHeight:  r.DroneHeight,
			UDirStatus:   r.UDirStatus,
			DevType:      int32(DevType(common.DEV_SFL)),
		}, &client.SflDetectInfoInsertRes{})
		if err != nil {
			logger.Error("Sfl Detect Info Insert err:", err)
		}
	}
}

func (d *Sfl) UnmarshalPayloadSflDetect(data *mavlink.SflDetect) error {
	deviceInfoLen := binary.Size(mavlink.SflDetectInfo{})
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}

	start := mavlink.HeaderLen + deviceInfoLen
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializeDrone(d.Msg[start:end]); err != nil {
		return err
	}

	return nil
}
func (d *Sfl) ReceiveSflRadarChartMsg() {
	hit := &mavlink.SflRadarChart{}
	if err := d.UnmarshalPayloadSflRadarChart(hit); err != nil {
		logger.Errorf(err.Error())
		return
	}

	devSn := ByteToString(hit.Info.Sn[:])
	if devSn != "" {
		d.SflRadarChartReport(devSn, hit)
	}
	logger.Info("--->End Receive SflRadar Chart")
}
func (d *Sfl) UnmarshalPayloadSflRadarChart(data *mavlink.SflRadarChart) error {
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("sfl UnmarshalPayloadSflRadarChart write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("sfl UnmarshalPayloadSflRadarChart read data err: %v", err)
	}

	return nil
}
func (d *Sfl) SflRadarChartReport(devSn string, chartInfo *mavlink.SflRadarChart) {

	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	dataInfo := &client.SflRadarChartInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        devSn,
			EquipType: int32(common.DEV_SFL),
			MsgType:   mavlink.SflRadarChartMsg,
		},
		Data: &client.GimbalCounterRadarChartInfo{
			Sn:           devSn,
			TimeStamp:    int64(chartInfo.Info.TimeStamp),
			StartAngle:   float64(chartInfo.Info.StartAngle) / SflChartTion,
			EndAngle:     float64(chartInfo.Info.EndAngle) / SflChartTion,
			AmpMean:      float64(chartInfo.Info.DxPower),
			GunDirection: float64(chartInfo.Info.DirectionAngle) / SflChartTion,
			Status:       uint32(chartInfo.Info.Status),
			TargetAngle:  float64(chartInfo.Info.TargetAngle) / SflChartTion,
		},
	}
	if err == nil {
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIdSFLRadarChart,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}
	_ = mq.SflMsgBroker.Publish(mq.SflTopic, broker.NewMessage(out))
	logger.Infof("Sfl RadarChart has reported, devSn: %v report:%v", devSn, report)
}

func (d *Sfl) ReceiveSflHitStatusMsg() {
	hit := &mavlink.SflHit{}
	if err := d.UnmarshalPayloadHitInfo(hit); err != nil {
		logger.Errorf(err.Error())
		return
	}

	devSn := ByteToString(hit.Info.SN[:])
	if devSn != "" {
		// report Hit
		d.updateStatusDetect(devSn)
		//if isEnable := d.updateStatus(devSn); isEnable == common.DeviceDisenable {
		//	logger.Infof("Sfl device %v disable", devSn)
		//	return
		//}
		d.HitInfoReport(devSn, hit)
	}
	logger.Info("--->End Receive Sfl HitStat")
}

func (d *Sfl) UnmarshalPayloadHitInfo(data *mavlink.SflHit) error {
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("Sfl UnmarshalPayloadHitInfo write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("Sfl UnmarshalPayloadHitInfo read data err: %v", err)
	}

	return nil
}

func (d *Sfl) HitInfoReport(devSn string, hitInfo *mavlink.SflHit) {
	//查白名单中的无人机，在Tracer侦测结果中添加无人机角色
	whiteList := &client.ListResAll{}
	err := NewWhiteList().ListAll(context.Background(), &client.ListReqAll{}, whiteList)
	if err != nil {
		logger.Error("Get whiteList err: ", err)
		return
	}
	//1-敌军 2-友军 3-未知 4-中立     批量导入为2友军
	var role int32
	for _, info := range whiteList.WhiteList {
		if info.Sn == ByteToString(hitInfo.Info.SerialNum[:]) {
			role = info.Role
		}
	}
	if role == ERRTYPE {
		role = ENEMY
	}

	//检查无效值
	hitInfo = CheckInputNum(hitInfo)

	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	dataInfo := &client.SflHitStateInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        devSn,
			EquipType: int32(common.DEV_SFL),
			MsgType:   mavlink.SflHitStatusMsgReport,
		},
		Data: &client.GimbalCounterHitSocketInfo{
			Sn:                 devSn,
			HitState:           int32(hitInfo.Info.HitState),
			ProductType:        int32(hitInfo.Info.ProductType),
			DroneName:          ByteToString(hitInfo.Info.DroneName[:]),
			SerialNum:          ByteToString(hitInfo.Info.SerialNum[:]),
			DroneLongitude:     float64(hitInfo.Info.DroneLongitude) / DroneTion,
			DroneLatitude:      float64(hitInfo.Info.DroneLatitude) / DroneTion,
			DroneHeight:        float64(hitInfo.Info.DroneHeight) / DroneHeightTion,
			DroneYawAngle:      float64(hitInfo.Info.DroneYawAngle) / DroneYawTion,
			DroneSpeed:         float64(hitInfo.Info.DroneSpeed) / DroneSpeedTion,
			DroneVerticalSpeed: float64(hitInfo.Info.DroneVerticalSpeed) / DroneVerticalSpeedTion,
			SpeedDirection:     int32(hitInfo.Info.SpeedDerection) / DroneSpeedTion,
			DroneSailLongitude: float64(hitInfo.Info.DroneSailLongitude) / DroneSailLongitudeTion,
			DroneSailLatitude:  float64(hitInfo.Info.DroneSailLatitude) / DroneSailLatitudeTion,
			PilotLongitude:     float64(hitInfo.Info.PilotLongitude) / DroneTion,
			PilotLatitude:      float64(hitInfo.Info.PilotLatitude) / DroneTion,
			DroneHorizon:       float64(hitInfo.Info.DroneHorizon) / DroneHorizonTion,
			DronePitch:         float64(hitInfo.Info.DronePitch) / DronePitch,
			UFreq:              float64(hitInfo.Info.UFreq) / DetectFreqTion,
			UDistance:          int32(hitInfo.Info.UDistance),
			UDangerLevels:      int32(hitInfo.Info.UDangerLevels),
			Role:               role,
		},
	}
	if err == nil {
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIDSFLHitStatus,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}
	_ = mq.SflMsgBroker.Publish(mq.SflTopic, broker.NewMessage(out))
	logger.Infof("Sfl HitInfo has reported, devSn: %v report:%v", devSn, report)

	//统计打击时间、打击时长
	uavNode := RecordSlfHitStatus(dataInfo.Data)
	if uavNode != nil {
		hitCacheKey := GetSflHitCacheKey(uavNode.UavSn, uavNode.DroneName, uavNode.ProductType)
		SflHitOverMapOnEvent.Store(hitCacheKey, uavNode)
	}
}

func GetSflHitCacheKey(serialNum string, droneName string, productType int32) string {
	hitCacheKey := fmt.Sprintf("%d_%d_%s_%s", common.DEV_SFL, productType, serialNum, droneName)
	logger.Infof("sfl hit cache key: %v", hitCacheKey)

	return hitCacheKey
}

func RecordSlfHitStatus(report *client.GimbalCounterHitSocketInfo) *common.SflHitEventInfo {
	var observeHitOverUav *common.SflHitEventInfo = nil

	droneInfo, isExist := SflDetectInfoMap.Get(report.SerialNum)
	tempTime := time.Now().UnixMilli()
	if isExist && (report.HitState == HITING || report.HitState == HITOVER) {
		if report.HitState == HITING && droneInfo.HitTime == 0 { //更新打击时间
			SflDetectInfoMap.UpdateHitTime(report.SerialNum, tempTime)
			//更新数据库
			err := NewSflDetectInfo().UpdateHitTime(context.Background(), &client.SflDetectInfoUpdateReq{Sn: report.SerialNum, HitTime: tempTime}, &client.SflDetectInfoUpdateRes{})
			if err != nil {
				logger.Error("Update Sfl Detect Info err:", err)
			}
		}
		if report.HitState == HITOVER {
			//更新数据库
			counterDur := (tempTime - droneInfo.HitTime) / 1000
			err := NewSflDetectInfo().UpdateCountTime(context.Background(), &client.SflDetectInfoUpdateReq{Sn: report.SerialNum, CounterTime: counterDur}, &client.SflDetectInfoUpdateRes{})
			if err != nil {
				logger.Error("Update Sfl Detect Info hit over err:", err)
			}

			// 判断10s内无人机的状态信息
			nowTime := time.Now()
			droneInfo.CounterTime = counterDur
			observeHitOverUav = &common.SflHitEventInfo{
				UavSn:            report.SerialNum,
				Sn:               report.Sn,
				HitOverTime:      nowTime,
				DetectReportTime: nowTime,
				ProductType:      report.ProductType,
				SessionId:        GetGlobalSessionId(),
				DroneName:        report.DroneName,
				DroneLongitude:   report.DroneLongitude,
				DroneLatitude:    report.DroneLatitude,
				DroneHeight:      report.DroneHeight,
				DroneYawAngle:    report.DroneYawAngle,
			}
			logger.Infof("sfl hit over, sfl sn: %v, uav serialNum: %v, productType: %v, droneName: %v",
				report.Sn, report.SerialNum, report.ProductType, report.DroneName)

			//清空map
			SflDetectInfoMap.Clear()
		}
	}

	return observeHitOverUav
}

func CheckInputNum(info *mavlink.SflHit) *mavlink.SflHit {
	if info.Info.DroneLongitude == InvalidValueInt32 {
		info.Info.DroneLongitude = 0
	}
	if info.Info.DroneLatitude == InvalidValueInt32 {
		info.Info.DroneLatitude = 0
	}
	if info.Info.DroneHeight == InvalidValueInt16 {
		info.Info.DroneHeight = 0
	}
	if info.Info.DroneYawAngle == InvalidValueInt16 {
		info.Info.DroneYawAngle = 0
	}
	if info.Info.DroneSpeed == InvalidValueInt16 {
		info.Info.DroneSpeed = 0
	}
	if info.Info.DroneVerticalSpeed == InvalidValueInt16 {
		info.Info.DroneVerticalSpeed = 0
	}
	if info.Info.DroneSailLongitude == InvalidValueInt32 {
		info.Info.DroneSailLongitude = 0
	}
	if info.Info.DroneSailLatitude == InvalidValueInt32 {
		info.Info.DroneSailLatitude = 0
	}
	if info.Info.PilotLongitude == InvalidValueInt32 {
		info.Info.PilotLongitude = 0
	}
	if info.Info.PilotLatitude == InvalidValueInt32 {
		info.Info.PilotLatitude = 0
	}
	if info.Info.DroneHorizon == InvalidValueInt32 {
		info.Info.DroneHorizon = -1
	}
	if info.Info.DronePitch == InvalidValueInt32 {
		info.Info.DronePitch = -1
	}

	if info.Info.UDistance == InvalidValueUInt16 {
		info.Info.UDistance = 0
	}
	if info.Info.UDangerLevels == InvalidValueInt16 {
		info.Info.UDangerLevels = 0
	}
	if info.Info.UFreq == InvalidValueInt32 {
		info.Info.UFreq = 0
	}

	return info
}
func DetectCheckInputNum(drone *mavlink.SflDetectDescription) *mavlink.SflDetectDescription {
	if drone.DroneLongitude == InvalidValueInt32 {
		drone.DroneLongitude = 0
	}
	if drone.DroneLatitude == InvalidValueInt32 {
		drone.DroneLatitude = 0
	}
	if drone.DroneHeight == InvalidValueInt16 {
		drone.DroneHeight = 0
	}
	if drone.DroneYawAngle == InvalidValueInt16 {
		drone.DroneYawAngle = 0
	}
	if drone.DroneSpeed == InvalidValueInt16 {
		drone.DroneSpeed = 0
	}
	if drone.DroneVerticalSpeed == InvalidValueInt16 {
		drone.DroneVerticalSpeed = 0
	}
	if drone.DroneSailLongitude == InvalidValueInt32 {
		drone.DroneSailLongitude = 0
	}
	if drone.DroneSailLatitude == InvalidValueInt32 {
		drone.DroneSailLatitude = 0
	}
	if drone.PilotLongitude == InvalidValueInt32 {
		drone.PilotLongitude = 0
	}
	if drone.PilotLatitude == InvalidValueInt32 {
		drone.PilotLatitude = 0
	}
	if drone.DroneHorizon == InvalidValueInt32 {
		drone.DroneHorizon = -1
	}
	if drone.DronePitch == InvalidValueInt32 {
		drone.DronePitch = -1
	}
	if drone.UDistance == InvalidValueInt16 {
		drone.UDistance = 0
	}
	if drone.UDangerLevels == InvalidValueInt16 {
		drone.UDangerLevels = 0
	}
	if drone.UFreq == InvalidValueInt32 {
		drone.UFreq = 0
	}
	return drone
}
func (d *Sfl) ReceiveSflGetVersion() {
	logger.Info("-->into Receive Sfl Get Version")

	res := &mavlink.SflGetVersionResponse{}

	res.AppVersion = d.Msg[mavlink.HeaderLen : len(d.Msg)-2]
	manager, ok := d.WaitTaskMap[mavlink.SflGetVersion]
	if ok {
		manager.CompletedTask(res, nil)
	}
	logger.Info("-->End Receive Sfl Version:", string(res.AppVersion))
	return
}

func (d *Sfl) SendGetVersionInfo(sn string) (string, error) {
	logger.Info("-->into Send Get Version msg")
	req := &mavlink.SflGetVersionRequest{}
	buff := req.Create()
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Sfl version info err: %v", err)
		return "", fmt.Errorf("request Sfl version info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SflGetVersion]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflGetVersion, true, 0)
		d.WaitTaskMap[mavlink.SflGetVersion] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl version info err: %v", checkNetConnErr)
			return "", checkNetConnErr
		}
	}
	logger.Debug("SendGetVersionInfo result = ", result)
	res, ok := result.(*mavlink.SflGetVersionResponse)
	if !ok {
		return "", errors.New("response err type")
	}
	logger.Debug("response Sfl version result:%+v", *res)
	if string(res.AppVersion) != "" {
		err = NewEquipList().Update(context.Background(), &client.EquipCrudReq{
			Sn:         sn,
			DevVersion: string(res.AppVersion),
		}, &client.EquipCrudRes{})
		if err != nil {
			logger.Error("Update EquipList err: ", err)
		}
	}
	return string(res.AppVersion), nil
}

// ReceiveGetTime 接收Sfl获取时间消息
func (d *Sfl) ReceiveGetTime() {
	logger.Info("-->into Send Time To Sfl")
	res := &mavlink.SflGetTimeResponse{}
	time1 := time.Now().UTC()
	resTime := time1.Format("20060102150405.000")
	logger.Info("resTime:", resTime)
	var byteArr [20]byte

	for k := range resTime {
		byteArr[k] = resTime[k]
	}

	rspBuf := res.CreateGetTimeMessage(byteArr)
	logger.Debugf("Send Time To Sfl Data:%v", rspBuf)

	n, err := d.Conn.Write(rspBuf)
	logger.Debugf("Send Time To Sfl：%v,%#v", n, res)
	if err != nil {
		logger.Error("Send Time To Sfl err:", err)
		return
	}
	logger.Info("--->End Send Time To Sfl")
	return
}

func (d *Sfl) PerformanceEvaluate(ctx context.Context, in *client.EnvBaseNoiseRequest) error {
	logger.Info("-->into PerformanceEvaluate on sfl")
	//复用sfl的协议
	req := &mavlink.Stp120PerformanceEvaluateRequest{}
	buff := req.Create(in)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.SflSendPerformanceEvaluateStart]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflSendPerformanceEvaluateStart, true, 0)
		d.WaitTaskMap[mavlink.SflSendPerformanceEvaluateStart] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Send PerformanceEvaluate is :[% x]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send PerformanceEvaluate err:[%v].Buff is [% x]", err, buff)
		return err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send PerformanceEvaluate err %s", err.Error())
		return err
	}

	//复用stp120协议
	res := result.(*mavlink.Stp120PerformanceEvaluateResponse)
	logger.Info("-->End PerformanceEvaluate: ", *res)

	if res.Status == 0 {
		return fmt.Errorf("res status fail: %v", res.Status)
	}
	return nil
}
func (d *Sfl) ReceivePerformanceEvaluate() {
	logger.Info("-->into Receive sfl PerformanceEvaluate")
	//复用stp120的协议
	res := &mavlink.Stp120PerformanceEvaluateResponse{}
	d.GetPacket(res)
	logger.Debugf("sfl PerformanceEvaluate：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflSendPerformanceEvaluateStart]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl) ReferencePerformanceEvaluate(ctx context.Context, in *client.PerformanceEvaluateReferenceRequest) error {
	logger.Info("-->into reference PerformanceEvaluate on sfl")
	//复用stp120
	req := &mavlink.Stp120ReferencePerformanceEvaluateRequest{}
	buff := req.Create(in)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.SflPerformanceEvaluateRefStart]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflPerformanceEvaluateRefStart, true, 0)
		d.WaitTaskMap[mavlink.SflPerformanceEvaluateRefStart] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Send reference PerformanceEvaluate is :[% x]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send reference PerformanceEvaluate err:[%v].Buff is [% x]", err, buff)
		return err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send reference PerformanceEvaluate err %s", err.Error())
		return err
	}
	//复用stp120
	res := result.(*mavlink.Stp120ReferencePerformanceEvaluateResponse)
	logger.Info("-->End reference PerformanceEvaluate: ", *res)

	if res.Status == 0 {
		return fmt.Errorf("res status fail: %v", res.Status)
	}
	return nil

}
func (d *Sfl) ReceivePerformanceEvaluateRef() {
	logger.Info("-->into Receive sfl reference PerformanceEvaluate")
	res := &mavlink.Stp120ReferencePerformanceEvaluateResponse{}
	d.GetPacket(res)
	logger.Debugf("sfl reference PerformanceEvaluate：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflPerformanceEvaluateRefStart]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}
func (d *Sfl) ReceivePerformanceEvaReport() {
	logger.Debugf("Sfl report performance evaluate result")
	evaluateResult := new(mavlink.Stp120PerformanceEvaluateReportData)
	if err := d.UnmarshalPayloadEnv(evaluateResult); err != nil {
		logger.Errorf("unmarshal env noise fail, err: %v", err)
		return
	}

	devSn := ByteToString(evaluateResult.Info.Sn[:])
	if len(devSn) > 0 {
		d.updateStatus(devSn, 0)
		d.NoiseEnvEvaluateReport(devSn, evaluateResult)
	}
}

func (d *Sfl) NoiseEnvEvaluateReport(devSn string, data *mavlink.Stp120PerformanceEvaluateReportData) {
	if data == nil {
		return
	}

	detectTypDetail := make(map[int32][]*client.EnvBaseNoiseItem)
	for i := 0; i < int(data.Info.NoiseDetailNums); i++ {
		noiseDetailItem := data.NoiseDetailItems[i]
		if noiseDetailItem == nil {
			continue
		}

		listNoiseItems := detectTypDetail[int32(noiseDetailItem.Freq)]
		listNoiseItems = append(listNoiseItems, &client.EnvBaseNoiseItem{
			Freq:        float32(noiseDetailItem.Freq),
			MinDistance: noiseDetailItem.MinDistance,
			MaxDistance: noiseDetailItem.MaxDistance,
		})
		detectTypDetail[int32(noiseDetailItem.Freq)] = listNoiseItems
	}

	var dataInfo *client.EnvBaseNoiseDetail = new(client.EnvBaseNoiseDetail)
	for devType, item := range detectTypDetail {
		var noiseDetectType *client.EnvBaseNoiseOnDetectType = new(client.EnvBaseNoiseOnDetectType)
		noiseDetectType.DetectType = devType
		noiseDetectType.NoiseList = item

		dataInfo.DetailList = append(dataInfo.DetailList, noiseDetectType)
	}

	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgIdSTP120PerformanceEvtReport,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.SflMsgBroker.Publish(mq.SflTopic, broker.NewMessage(out))

	logger.Infof("sfl100  noise env evaluate has reported, devSn: %v, report: %+v", devSn, dataInfo.DetailList)
}

func (d *Sfl) UnmarshalPayloadEnv(data *mavlink.Stp120PerformanceEvaluateReportData) error {
	evaInfoLen := binary.Size(mavlink.Stp120PerformanceEvaluateInfo{})
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}
	if data.Info.NoiseDetailNums <= 0 {
		logger.Debugf("noise detail nums is 0")
		return nil
	}

	// 解析： NoiseDetailItems, 类型： []*EnvBaseNoiseOnDetectType
	start := mavlink.HeaderLen + evaInfoLen
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializeNoiseDetailItems(d.Msg[start:end]); err != nil {
		return err
	}
	return nil
}

func (d *Sfl) ReceiveSflIsDecryptMsg() {
	logger.Info("-->into Send IsDecrypt To Sfl")
	res := &mavlink.SflIsDecryptResponse{}
	result := dialIncDomain()
	req := 1
	if !result {
		req = 2
	}

	rspBuf := res.CreateSflIsDecryptMessage(uint8(req))
	logger.Debugf("Send IsDecrypt To Sfl Data:%v", rspBuf)

	n, err := d.Conn.Write(rspBuf)
	logger.Debugf("Send IsDecrypt To Sfl：%v,%#v", n, res)
	if err != nil {
		logger.Error("Send IsDecrypt To Sfl err:", err)
		return
	}
	logger.Info("--->End Send IsDecrypt To Sfl")
	return
}
func dialIncDomain() bool {
	token, err := GetTracerCryptToken()
	if err != nil {
		logger.Error("get token err = ", err)
		return false
	} else {
		logger.Infof("decrypt_token: %v", token)
	}

	{
		a3Data := "a31343525950a8c19cf57ab83ea0295d3f97fb50157cd8ffe1e333faf1cfe4055f1b0dc029fe0994eb736704faf880abb8a8a963b40f34dcfa82b5a30c44850c7f5d6265fc54ebf5b6f1a96b52a8bfade8e5501ece9ec105a3011660ee3fb435154d7658bd3de7bda352c5b5c086c99282fd8206873406cad5b90fc9b965147bcfc22000120a5961de534382b32f653f8abd426d0c2de183c9ba2ed98bf61519788a3dc1d6220000000000000046b72d"
		_, err, errCode := GetTracerDecrypt(token, []byte(a3Data))

		if err != nil {
			logger.Error("err = ", err)
			logger.Error("errCode = ", errCode)

			return false
		} else {
			logger.Debug("SendTracerDecryptData OK...")
		}
	}

	{
		msg80 := "8010494e4650a8c19cf5a7f3ea787968eba56d00e34fb2080fe871a8fb420dc2c4a94bdf4ec78a116f69ef2cb6500805bc8f89bdbbddd4e918b250d634a38a60ebb15ed0cfb6eafce8d1095c17d10d60cd8fb8013cac105a1cd0b2e3d8dfef10468e5d4e4e34fab74f6e6957005a0ff1b9d277b62e11945280f352ec1095afff5c12c30000000000000000000000000000000000000000000000000000000000000000000000000000ac18bbd3270e73"
		_, err, errCode := GetTracerDecrypt(token, []byte(msg80))

		if err != nil {
			logger.Error("err = ", err)
			logger.Error("errCode = ", errCode)
			return false
		} else {
			logger.Debug("SendTracerDecryptData OK...")
		}
	}

	return true
}
func (d *Sfl) ReceiveSflGetGNNS() {
	logger.Info("-->into Receive Sfl Get GNNS")

	res := &mavlink.SflGNSSGetResponse{}
	ret := d.UnmarshalPayloadSflGetGNSS(res)
	if ret != nil {
		logger.Debug("Receive Sfl Get GNNS ret = ", ret)
	}
	// res.AppVersion = d.Msg[mavlink.HeaderLen : len(d.Msg)-2]
	// res.Type = d.Msg[mavlink.HeaderLen : len(d.Msg)-2]
	manager, ok := d.WaitTaskMap[mavlink.SFLGetGNSS]
	if ok {
		manager.CompletedTask(res, nil)
	}
	logger.Info("-->End ReceiveSflGetGNNS Sfl :", res)
	return
}

func (d *Sfl) ReceiveSflSetGNNS() {
	logger.Info("-->into ReceiveSflSetGNNS Sfl Set GNNS")

	res := &mavlink.SflGNSSSetResponse{}
	ret := d.UnmarshalPayloadSflSetGNSS(res)
	if ret != nil {
		logger.Debug("Receive ReceiveSflSetGNNSret = ", ret)
	}
	manager, ok := d.WaitTaskMap[mavlink.SFLSetGNSS]
	if ok {
		manager.CompletedTask(res, nil)
	}
	logger.Info("-->End ReceiveSflSetGNNS Sfl :", res)
	return
}

func (d *Sfl) ReceiveSflSetPith() {
	logger.Info("-->into Receive Sfl Set Pith")
	res := &mavlink.SflSetHitInfoResponse{}
	d.GetPacket(res)
	logger.Debugf("Set Pith 接收到Sfl 信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflSetPith]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl) ReceiveSflSetAngle() {
	logger.Info("-->into Receive Sfl Set Angle")
	res := &mavlink.SflSetHitAngleResponse{}
	d.GetPacket(res)
	logger.Debugf("Set Angle 接收到Sfl 信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflSetAngle]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl) SendSflHitAngleSet(request *client.SflHitAngleRequest) (int, error) {
	logger.Info("-->into Send Hit Angle msg,req is %v", request)
	//1、设置打击俯仰角度
	req := &mavlink.SflSetHitInfoRequest{}
	buff := req.Create(request)
	logger.Debug("-->Set Hit Info is :", buff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Sfl Hit Angle  err: %v", err)
		return Fail, fmt.Errorf("request Sfl Hit Info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SflSetPith]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflSetPith, true, 0)
		d.WaitTaskMap[mavlink.SflSetPith] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl Hit Info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.SflSetHitInfoResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl Hit Info result:%+v", *res)

	//2、设置有效角度范围
	reqAngle := &mavlink.SflSetHitAngleRequest{}
	buffAngle := reqAngle.Create(request)
	logger.Debug("-->Set Hit Angle is :", buffAngle)
	if _, err := d.Conn.Write(buffAngle); err != nil {
		logger.Errorf("request Sfl Hit Angle err: %v", err)
		return Fail, fmt.Errorf("request Sfl Hit Angle err: %v", err)
	}
	managerAngle, ok := d.WaitTaskMap[mavlink.SflSetAngle]
	if !ok {
		managerAngle = NewWaitTaskManager(mavlink.SflSetAngle, true, 0)
		d.WaitTaskMap[mavlink.SflSetAngle] = managerAngle
	}

	resultAngle, err := managerAngle.Wait()
	if err != nil {
		if checkNetConnErr := managerAngle.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl  Hit Angle err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	resAngle, ok := resultAngle.(*mavlink.SflSetHitAngleResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl Hit Angle result:%+v", *resAngle)

	//3.设置打击模式   反制模式：1、Normal 2、GNSS。打击模式拆分成单独的接口
	return int(resAngle.Status), nil
}

func (d *Sfl) SendSflHitModeSet(request *client.SflHitModeRequest) (int, error) {
	logger.Info("-->into Send Hit Mode msg,req is %v", request)
	//3.设置打击模式   反制模式：1、Normal 2、GNSS
	reqMode := &mavlink.SflSetHitModeRequest{}
	buffMode := reqMode.Create(request)
	logger.Debug("-->Set Hit Mode is :", buffMode)
	if _, err := d.Conn.Write(buffMode); err != nil {
		logger.Errorf("request Sfl Hit Mode err: %v", err)
		return Fail, fmt.Errorf("request Sfl Hit Mode err: %v", err)
	}
	managerMode, ok := d.WaitTaskMap[mavlink.SflSetHitMode]
	if !ok {
		managerMode = NewWaitTaskManager(mavlink.SflSetHitMode, true, 0)
		d.WaitTaskMap[mavlink.SflSetHitMode] = managerMode
	}

	resultMode, err := managerMode.Wait()
	if err != nil {
		if checkNetConnErr := managerMode.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl  Hit Mode err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	resMode, ok := resultMode.(*mavlink.SflSetHitModeResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl Hit Mode result:%+v", *resMode)

	return int(resMode.Status), nil
}

func (d *Sfl) ReceiveSflStopHit() {
	logger.Info("-->into Receive Sfl Stop Hit")
	res := &mavlink.SflStopHitResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveSflStopHit 接收到信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflStopHit]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl) SendSflStopHitReq() (int, error) {
	logger.Info("-->into Send Sfl stop hit msg")
	req := &mavlink.SflStopHitRequest{}
	buff := req.Create()
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Sfl Stop Hit info err: %v", err)
		return Fail, fmt.Errorf("request Sfl Stop Hit info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SflStopHit]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflStopHit, true, 0)
		d.WaitTaskMap[mavlink.SflStopHit] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl Stop Hit info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.SflStopHitResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl Stop Hit result:%+v", *res)
	//清空map
	SflDetectInfoMap.Clear()
	return int(res.Status), nil
}

// SflGNSSSetReq
func (d *Sfl) SflGNSSSetReq(request *client.SflSetGNSSRequest) (int, error) {
	logger.Info("-->into SflGNSSSetReq stop hit msg")
	req := &mavlink.SflGNSSSetRequest{}
	buff := req.Create(request)
	logger.Debug("buff = ", buff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Sfl SSflGNSSSetReqerr: %v", err)
		return Fail, fmt.Errorf("request SflGNSSSetReq  info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SFLSetGNSS]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SFLSetGNSS, true, 0)
		d.WaitTaskMap[mavlink.SFLSetGNSS] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request SflGNSSSetReq info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.SflGNSSSetResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl SflGNSSSetReqresult:%+v", *res)
	//清空map
	SflDetectInfoMap.Clear()
	return int(res.Status), nil
}

// SflGNSSSetReq
func (d *Sfl) SflGNSSGetReq() (*mavlink.SflGNSSGetResponse, error) {
	logger.Info("-->into Send Sfl SflGNSSGetReq hit msg")
	req := &mavlink.SflGNSSGetRequest{}
	buff := req.Create()
	logger.Debug("buff = ", buff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("SflGNSSGetReqHit info err: %v", err)
		return nil, fmt.Errorf("SflGNSSGetReq info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SFLGetGNSS]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SFLGetGNSS, true, 0)
		d.WaitTaskMap[mavlink.SFLGetGNSS] = manager
	}

	result, err := manager.Wait()
	logger.Debug("result = ", result)
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request SflSflGNSSGetReq err: %v", checkNetConnErr)
			return nil, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.SflGNSSGetResponse)
	if !ok {
		return nil, errors.New("response err type")
	}
	logger.Debug("response SflGNSSGetReq result:%+v", *res)
	//清空map
	SflDetectInfoMap.Clear()
	return res, nil
}

func FindSflDetectInfo(request *client.SflDetectInfoRequest) (*client.SflDetectInfoResponse, error) {
	logger.Info("-->into Find SflDetect Info,req is :", request)
	layout := "2006-01-02 15:04:05" // 输入时间的格式

	start, err := time.Parse(layout, request.StartTime)
	if err != nil {
		logger.Error("Parse  StartTime err:", err)
		return nil, err
	}
	end, err := time.Parse(layout, request.EndTime)
	if err != nil {
		logger.Error("Parse  EndTime err:", err)
		return nil, err
	}
	startTimeInt := start.UnixNano() / int64(time.Millisecond)
	endTimeInt := end.UnixNano() / int64(time.Millisecond)
	rspInfo := make([]*client.Event, 0)
	rsp := &client.SflDetectInfoResponse{}
	detectList := &client.SflDetectInfoListRes{}

	err = NewSflDetectInfo().List(context.Background(), &client.SflDetectInfoListReq{
		StartTime: startTimeInt,
		StopTime:  endTimeInt,
	}, detectList)
	if err != nil {
		logger.Error("List Sfl err:", err)
		return nil, err
	}
	detectNum := 0
	hitNum := 0
	for _, list := range detectList.Sfllist {
		hittime := ""
		if list.HitTime != 0 {
			hittime = time.Unix(0, list.HitTime*int64(time.Millisecond)).Format("2006-01-02 15:04:05")
		}
		devType := list.DevType
		if devType == 0 {
			devType = int32(DevType(common.DEV_SFL))
		}
		rspInfo = append(rspInfo, &client.Event{
			Id:            list.Id,
			BeginTime:     time.Unix(0, list.DetectTime*int64(time.Millisecond)).Format("2006-01-02 15:04:05"),
			Freq:          float64(list.Freq),
			DroneName:     list.Vendor,
			Protocol:      "TCP",
			SerialNum:     list.Sn,
			DevType:       devType,
			DroneYawAngle: float64(list.Direction),
			HitTime:       hittime,
			HitDev:        devType,
			PilotLongLat:  list.PilotLongLat,
			DroneHeight:   list.DroneHeight,
			UDirStatus:    list.UDirStatus,
		})
		detectNum++
		if list.HitTime != 0 {
			hitNum++
		}
	}
	rsp.List = rspInfo
	rsp.DetectNum = int32(detectNum)
	rsp.HitNum = int32(hitNum)
	logger.Info("Sfl rsp is :", rsp)
	return rsp, nil
}

// FindSflDetectExportInfo 导出侦测信息
func FindSflDetectExportInfo(ctx context.Context, request *client.SflDetectInfoExportRequest) (int, error) {
	logger.Info("-->into Find SflDetect Export Info,req is :", request)

	file := excelize.NewFile()

	sheetName := file.GetSheetName(1) // 获取第一个表格的名称
	if sheetName != "sfl_detect_list" {
		file.SetSheetName(sheetName, "sfl_detect_list") // 将表格名称修改为 sfl_detect_list
	}

	tranStrToInt64 := func(data string) int64 {
		ret, e := strconv.ParseInt(data, 10, 64)
		if e != nil {
			return 0
		}
		return ret
	}
	file.SetCellValue("sfl_detect_list", "A1", "Sn")
	file.SetCellValue("sfl_detect_list", "B1", "Vendor")
	file.SetCellValue("sfl_detect_list", "C1", "DetectTime")
	file.SetCellValue("sfl_detect_list", "D1", "HitTime")
	file.SetCellValue("sfl_detect_list", "E1", "CounterTime")
	file.SetCellValue("sfl_detect_list", "F1", "Freq")
	file.SetCellValue("sfl_detect_list", "G1", "Direction")
	file.SetCellValue("sfl_detect_list", "H1", "PilotLongLat")
	file.SetCellValue("sfl_detect_list", "Ii", "DroneHeight")
	file.SetCellValue("sfl_detect_list", "J1", "UDirStatus")
	listinfo := &client.SflDetectInfoListRes{}
	sflDetectInfo := NewSflDetectInfo()
	err := sflDetectInfo.List(ctx, &client.SflDetectInfoListReq{
		StartTime: tranStrToInt64(request.StartTime),
		StopTime:  tranStrToInt64(request.EndTime),
	}, listinfo)
	if err != nil {
		logger.Error("-->get sfl_detect_list err:", err)
		return Fail, err
	}
	start := 0
	for i, list := range listinfo.Sfllist {
		rowNum := i + 2
		file.SetCellValue("sfl_detect_list", fmt.Sprintf("A%d", rowNum), list.Sn)
		file.SetCellValue("sfl_detect_list", fmt.Sprintf("B%d", rowNum), list.Vendor)
		file.SetCellValue("sfl_detect_list", fmt.Sprintf("C%d", rowNum), list.DetectTime)
		file.SetCellValue("sfl_detect_list", fmt.Sprintf("D%d", rowNum), list.HitTime)
		file.SetCellValue("sfl_detect_list", fmt.Sprintf("E%d", rowNum), list.CounterTime)
		file.SetCellValue("sfl_detect_list", fmt.Sprintf("F%d", rowNum), list.Freq)
		file.SetCellValue("sfl_detect_list", fmt.Sprintf("G%d", rowNum), list.Direction)
		file.SetCellValue("sfl_detect_list", fmt.Sprintf("H%d", rowNum), list.PilotLongLat)
		file.SetCellValue("sfl_detect_list", fmt.Sprintf("I%d", rowNum), list.DroneHeight)
		file.SetCellValue("sfl_detect_list", fmt.Sprintf("J%d", rowNum), list.UDirStatus)
		start = i
	}
	if err = file.SaveAs(request.FilePath); err != nil {
		logger.Error("-->SaveAs sfl_detect_list err:", err)
		return Fail, err
	}

	//其他类型设备数据导出
	var flightEvents []bean.FlightList
	err = db.GetDB().Model(&bean.FlightList{}).
		Order("begin_time desc").
		Find(&flightEvents).Error
	if err != nil {
		logger.Errorf("outPut query event list error:%v", err)
		return Fail, err
	}
	for i, list := range flightEvents {
		rowNum := i + 2 + start
		file.SetCellValue("sfl_detect_list", fmt.Sprintf("A%d", rowNum), list.SerialNum)
		file.SetCellValue("sfl_detect_list", fmt.Sprintf("B%d", rowNum), list.Vendor)
		file.SetCellValue("sfl_detect_list", fmt.Sprintf("C%d", rowNum), list.BeginTime)
		file.SetCellValue("sfl_detect_list", fmt.Sprintf("D%d", rowNum), 0)
		file.SetCellValue("sfl_detect_list", fmt.Sprintf("E%d", rowNum), list.DurationTime)
		file.SetCellValue("sfl_detect_list", fmt.Sprintf("F%d", rowNum), list.Freq)
		file.SetCellValue("sfl_detect_list", fmt.Sprintf("G%d", rowNum), list.DroneYawAngle)
		file.SetCellValue("sfl_detect_list", fmt.Sprintf("H%d", rowNum), "")
		file.SetCellValue("sfl_detect_list", fmt.Sprintf("I%d", rowNum), "")
	}
	if err = file.SaveAs(request.FilePath); err != nil {
		logger.Error("-->SaveAs Other sfl_detect_list err:", err)
		return Fail, err
	}

	logger.Info("-->End Export sfl_detect_list List")
	return Success, nil
}

func FindSflDetectExportInfoV2(ctx context.Context, request *client.SflDetectInfoExportRequest) (int, error) {
	logger.Info("-->into Find SflDetect Export Info,req is :", request)

	// 创建CSV文件
	file, err := os.Create(request.FilePath)
	if err != nil {
		logger.Error("FindSflDetectExportInfoV2 os.Create err:", err)
		return Fail, err
	}
	defer file.Close()

	// 创建CSV writer
	writer := csv.NewWriter(file)

	//写入UTF-8 BOM头，避免使用excel软件打开.csv文件出现中文乱码
	//writer.Write([]string{"\xEF\xBB\xBF"})
	// 写入CSV文件的头部
	title := []string{"Sn", "Vendor", "DetectTime", "HitTime", "CounterTime", "Freq", "Direction", "PilotLongLat", "DroneHeight"}
	if err := writer.Write(title); err != nil {
		logger.Error("FindSflDetectExportInfoV2 writer.Write title err:", err)
		return Fail, err
	}
	// 写入CSV文件的数据行
	tranStrToInt64 := func(data string) int64 {
		ret, e := strconv.ParseInt(data, 10, 64)
		if e != nil {
			return 0
		}
		return ret
	}
	listinfo := &client.SflDetectInfoListRes{}
	sflDetectInfo := NewSflDetectInfo()
	err = sflDetectInfo.List(ctx, &client.SflDetectInfoListReq{
		StartTime: tranStrToInt64(request.StartTime),
		StopTime:  tranStrToInt64(request.EndTime),
	}, listinfo)
	if err != nil {
		logger.Error("-->get sfl_detect_list err:", err)
		return Fail, err
	}

	records := make([][]string, 0)
	for _, list := range listinfo.Sfllist {
		record := []string{
			list.Sn,
			list.Vendor,
			strconv.FormatInt(list.DetectTime, 10),
			strconv.FormatInt(list.HitTime, 10),
			strconv.FormatInt(list.CounterTime, 10),
			strconv.FormatFloat(float64(list.Freq), 'f', -1, 32),
			strconv.FormatInt(list.Direction, 10),
			list.PilotLongLat,
			strconv.FormatFloat(list.DroneHeight, 'f', -1, 32),
		}
		records = append(records, record)
	}

	if err := writer.WriteAll(records); err != nil {
		logger.Error("FindSflDetectExportInfoV2 writer.WriteAll err:", err)
		return Fail, err
	}
	logger.Info("-->End Export sfl_detect_list List")
	return Success, nil
}

// FindSflDetectInfoByKey 侦测信息查询
func FindSflDetectInfoByKey(request *client.SflDetectInfoRequest) (*client.SflDetectInfoResponse, error) {
	logger.Info("-->into Detect Find Info,req is :", request)
	layout := "2006-01-02 15:04:05" // 输入时间的格式

	start, err := time.Parse(layout, request.StartTime)
	if err != nil {
		logger.Error("Parse  StartTime err:", err)
		return nil, err
	}
	end, err := time.Parse(layout, request.EndTime)
	if err != nil {
		logger.Error("Parse  EndTime err:", err)
		return nil, err
	}
	startTimeInt := start.UnixNano() / int64(time.Millisecond)
	endTimeInt := end.UnixNano() / int64(time.Millisecond)
	rspInfo := make([]*client.Event, 0)
	rsp := &client.SflDetectInfoResponse{}
	detectList := &client.SflDetectInfoListLikeRes{}
	err = NewSflDetectInfo().ListLike(context.Background(), &client.SflDetectInfoListLikeReq{
		StartTime: startTimeInt,
		StopTime:  endTimeInt,
		FindKey:   request.FindKey,
	}, detectList)
	if err != nil {
		logger.Error("List Sfl err:", err)
		return nil, err
	}
	detectNum := 0
	hitNum := 0
	for _, list := range detectList.Sfllist {
		hittime := ""
		if list.HitTime != 0 {
			hittime = time.Unix(0, list.HitTime*int64(time.Millisecond)).Format("2006-01-02 15:04:05")
		}
		devType := list.DevType
		if devType == 0 {
			devType = int32(DevType(common.DEV_SFL))
		}
		rspInfo = append(rspInfo, &client.Event{
			Id:            list.Id,
			BeginTime:     time.Unix(0, list.DetectTime*int64(time.Millisecond)).Format("2006-01-02 15:04:05"),
			Freq:          float64(list.Freq),
			DroneName:     list.Vendor,
			Protocol:      "TCP",
			SerialNum:     list.Sn,
			DevType:       int32(devType),
			DroneYawAngle: float64(list.Direction),
			HitTime:       hittime,
			HitDev:        int32(devType),
			DroneHeight:   list.DroneHeight,
			PilotLongLat:  list.PilotLongLat,
			UDirStatus:    list.UDirStatus,
		})
		detectNum++
		if list.HitTime != 0 {
			hitNum++
		}
	}
	rsp.List = rspInfo
	rsp.DetectNum = int32(detectNum)
	rsp.HitNum = int32(hitNum)
	logger.Info("Sfl rsp is :", rsp)
	return rsp, nil
}

func (d *Sfl) ReceiveSflSetHitMode() {
	logger.Info("-->into Receive Set Hit Mode")
	res := &mavlink.SflSetHitModeResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveSflSet Hit Mode 接收到Sfl信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflSetHitMode]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl) SendSflOnOffSet(request *client.SflOnOffRequest) (int, error) {
	logger.Info("-->into Send On Off  msg:", request)
	req := &mavlink.SflSetOnOffRequest{}
	buff := req.Create(request)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Sfl On Off info err: %v", err)
		return Fail, fmt.Errorf("request Sfl On Off info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SflSetOnOff]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflSetOnOff, true, 0)
		d.WaitTaskMap[mavlink.SflSetOnOff] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl On Off info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.SflSetOnOffResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl On Off result:%+v", *res)
	return int(res.Status), nil
}
func (d *Sfl) ReceiveSflSetOnOff() {
	logger.Info("-->into Receive SflSetOnOff")
	res := &mavlink.SflSetOnOffResponse{}
	d.GetPacket(res)
	logger.Debugf("Sfl Set OnOff  接收到Sfl信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflSetOnOff]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl) SendSflReset() (int, error) {
	logger.Info("-->into Send Reset  msg")
	req := &mavlink.SflResetRequest{}
	buff := req.Create()
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Sfl Reset info err: %v", err)
		return Fail, fmt.Errorf("request Sfl Reset info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SflReset]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflReset, true, 0)
		d.WaitTaskMap[mavlink.SflReset] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl Reset info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.SflResetResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl Reset result:%+v", *res)
	return int(res.Status), nil
}
func (d *Sfl) ReceiveSflReset() {
	logger.Info("-->into Receive Reset")
	res := &mavlink.SflResetResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveSflGet Reset 接收到Sfl信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflReset]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}
func (d *Sfl) SendSflHitUav(request *client.SflSendHitUavRequest) (int, error) {
	logger.Info("-->into Send Hit Uav msg,req is:", request)
	req := &mavlink.SflSendHitUavRequest{}

	hitCmdDroneName := common.DeConstructDroneName(request.GetDroneName(), request.GetDroneSn())
	logger.Infof("drone Name: %v before hit cmd, drone name: %v after hit cmd", request.GetDroneName(), hitCmdDroneName)
	request.DroneName = hitCmdDroneName

	buff := req.Create(request)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Sfl Send Hit Uav info err: %v", err)
		return Fail, fmt.Errorf("request Sfl Send Hit Uav info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SflSendHitUav]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflSendHitUav, true, 0)
		d.WaitTaskMap[mavlink.SflSendHitUav] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl Send Hit Uav info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.SflSendHitUavResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl Send Hit Uav result:%+v", *res)
	return int(res.Status), nil
}

func (d *Sfl) ReceiveSflGetHitUav() {
	logger.Info("-->into Receive Get Hit Uav")
	res := &mavlink.SflSendHitUavResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveSflGetHitUav  接收到Sfl信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflSendHitUav]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}
func (d *Sfl) SendSflGetStatus() (*client.SflGetStatusResponse, error) {
	logger.Info("-->into Send Reset  msg")
	rsp := &client.SflGetStatusResponse{}

	//1.获取角度、打击时长信息
	req := &mavlink.SflGetPitchRequest{}
	buff := req.Create()
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Sfl GetPitch info err: %v", err)
		return rsp, fmt.Errorf("request Sfl GetPitch info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SflGetHitPith]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflGetHitPith, true, 0)
		d.WaitTaskMap[mavlink.SflGetHitPith] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl GetPitch info err: %v", checkNetConnErr)
			return rsp, checkNetConnErr
		}
	}
	resPitch, ok := result.(*mavlink.SflGetPitchResponse)
	if !ok {
		return rsp, errors.New("response err type")
	}
	logger.Debug("response Sfl GetPitch result:%+v", *resPitch)

	for i := 0; i < int(resPitch.HitCnt); i++ {
		rsp.HitTime = int32(resPitch.HitDescription[0].HitTime)
		rsp.HitPitch1 = int32(resPitch.HitDescription[0].HitPitch)
		rsp.HitPitch2 = int32(resPitch.HitDescription[i].HitPitch)
	}

	//2.获取打击范围信息
	reqAngle := &mavlink.SflGetAngleRequest{}
	buffAngle := reqAngle.Create()
	if _, err := d.Conn.Write(buffAngle); err != nil {
		logger.Errorf("request Sfl GetAngle info err: %v", err)
		return rsp, fmt.Errorf("request Sfl GetAngle info err: %v", err)
	}
	managerAngle, ok := d.WaitTaskMap[mavlink.SflGetHitAngle]
	if !ok {
		managerAngle = NewWaitTaskManager(mavlink.SflGetHitAngle, true, 0)
		d.WaitTaskMap[mavlink.SflGetHitAngle] = managerAngle
	}

	resultAngle, err := managerAngle.Wait()
	if err != nil {
		if checkNetConnErr := managerAngle.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl GetAngle info err: %v", checkNetConnErr)
			return rsp, checkNetConnErr
		}
	}
	resAngle, ok := resultAngle.(*mavlink.SflGetAngleResponse)
	if !ok {
		return rsp, errors.New("response err type")
	}
	logger.Debug("response Sfl GetAngle result:%+v", *resAngle)
	rsp.HitAngleBegin = int32(resAngle.HitAngleBegin)
	rsp.HitAngleEnd = int32(resAngle.HitAngleEnd)

	//3.获取工作模式
	reqMode := &mavlink.SflGetHitModeRequest{}
	buffMode := reqMode.Create()
	if _, err := d.Conn.Write(buffMode); err != nil {
		logger.Errorf("request Sfl GetMode info err: %v", err)
		return rsp, fmt.Errorf("request Sfl GetMode info err: %v", err)
	}
	managerreqMode, ok := d.WaitTaskMap[mavlink.SflGetHitMode]
	if !ok {
		managerreqMode = NewWaitTaskManager(mavlink.SflGetHitMode, true, 0)
		d.WaitTaskMap[mavlink.SflGetHitMode] = managerreqMode
	}

	resultMode, err := managerreqMode.Wait()
	if err != nil {
		if checkNetConnErr := managerreqMode.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl GetMode info err: %v", checkNetConnErr)
			return rsp, checkNetConnErr
		}
	}
	resMode, ok := resultMode.(*mavlink.SflGetHitModeResponse)
	if !ok {
		return rsp, errors.New("response err type")
	}
	logger.Debug("response Sfl GetMode result:%+v", *resMode)
	rsp.HitMode = int32(resMode.ModeStatus)

	return rsp, nil
}

func (d *Sfl) SendSflSetHitMode(hitMode int32) (int, error) {
	//设置打击模式  0 不自动打击    1 自动打击
	req := &mavlink.SflSetAutoModeRequest{}
	buff := req.Create(hitMode)
	logger.Debug("-->Set Hit Auto is :", buff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Sfl Hit Auto err: %v", err)
		return Fail, fmt.Errorf("request Sfl Hit Auto err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SflSetAutoHitMode]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflSetAutoHitMode, true, 0)
		d.WaitTaskMap[mavlink.SflSetAutoHitMode] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl  Hit Mode err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.SflSetAutoModeResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl Hit Auto result:%+v", *res)

	return int(res.Status), nil
}
func (d *Sfl) ReceiveSflSetAutoHitMode() {
	logger.Info("-->into ReceiveSfl Set Auto Hit Mode")
	res := &mavlink.SflSetAutoModeResponse{}
	d.GetPacket(res)
	logger.Debugf("Set Auto Hit Mode  接收到Sfl信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflSetAutoHitMode]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}
func (d *Sfl) SendSflGetHitMode() (int, error) {
	//获取打击模式  0 不自动打击    1 自动打击
	req := &mavlink.SflGetAutoModeRequest{}
	buff := req.Create()
	logger.Debug("-->Get Hit Auto is :", buff)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Get Sfl Hit Auto err: %v", err)
		return Fail, fmt.Errorf("request Get Sfl Hit Auto err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SflGetAutoHitMode]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflGetAutoHitMode, true, 0)
		d.WaitTaskMap[mavlink.SflGetAutoHitMode] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl Get Hit Mode err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.SflGetAutoModeResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl Get Hit Auto result:%+v", *res)

	return int(res.AutoStatus), nil
}
func (d *Sfl) ReceiveSflGetAutoHitMode() {
	logger.Info("-->into ReceiveSfl Get Auto Hit Mode")
	res := &mavlink.SflGetAutoModeResponse{}
	d.GetPacket(res)
	logger.Debugf("Get Auto Hit Mode  接收到Sfl信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflGetAutoHitMode]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl) SendSflGetPower() (int, int, error) {
	logger.Info("-->into Send Get Power  msg")
	//获取开关机状态
	req := &mavlink.SflGetPowerRequest{}
	buff := req.Create()
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Sfl Get Power info err: %v", err)
		return Fail, Fail, fmt.Errorf("request Sfl Get Power info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SflGetOnOff]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflGetOnOff, true, 0)
		d.WaitTaskMap[mavlink.SflGetOnOff] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl Get Power info err: %v", checkNetConnErr)
			return Fail, Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.SflGetPowerResponse)
	if !ok {
		return Fail, Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl Get Power result:%+v", *res)

	return int(res.PowerStatus), int(res.Status), nil
}
func (d *Sfl) ReceiveSflGetOnOff() {
	logger.Info("-->into Receive SflGetOnOff")
	res := &mavlink.SflGetPowerResponse{}
	d.GetPacket(res)
	logger.Debugf("SflGetOnOff Get 接收到Sfl信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflGetOnOff]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl) SendSflTurnHit(startStop int32) (int, error) {
	logger.Info("-->into Send Turn Hit  msg")
	//获取开关机状态
	req := &mavlink.SflTurnHitRequest{}
	buff := req.Create(uint8(startStop))
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Sfl Send Turn Hit info err: %v", err)
		return Fail, fmt.Errorf("request Sfl Send Turn Hit info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SflHitTurn]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflHitTurn, true, 0)
		d.WaitTaskMap[mavlink.SflHitTurn] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl Turn Hit info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.SflTurnHitResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl Turn Hit result:%+v", *res)

	return int(res.Status), nil
}
func (d *Sfl) ReceiveSflTurnHit() {
	logger.Info("-->into Receive SflTurnHit")
	res := &mavlink.SflTurnHitResponse{}
	d.GetPacket(res)
	logger.Debugf("SflTurnHit Get 接收到Sfl信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflHitTurn]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl) SendSflHorizontalTurn(request *client.SflHorizontalTurnRequest) (int, error) {
	logger.Info("-->into Send Horizontal Turn  msg")
	//获取开关机状态
	req := &mavlink.SflHorizontalTurnRequest{}
	buff := req.Create(request)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Sfl Send Horizontal Turn info err: %v", err)
		return Fail, fmt.Errorf("request Sfl Send Horizontal Turn info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SflHorizontalTurn]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflHorizontalTurn, true, 0)
		d.WaitTaskMap[mavlink.SflHorizontalTurn] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl Horizontal Turn info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.SflHorizontalTurnResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl Horizontal Turn result:%+v", *res)

	return int(res.Status), nil
}
func (d *Sfl) ReceiveSflHorizontalTurn() {
	logger.Info("-->into Receive Sfl Horizontal Turn")
	res := &mavlink.SflHorizontalTurnResponse{}
	d.GetPacket(res)
	logger.Debugf("Sfl Horizontal Turn Get 接收到Sfl信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflHorizontalTurn]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl) SendSflVerticalTurn(request *client.SflVerticalTurnRequest) (int, error) {
	logger.Info("-->into Send Vertical Turn  msg")
	//获取开关机状态
	req := &mavlink.SflVerticalTurnRequest{}
	buff := req.Create(request)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Sfl Send Vertical Turn info err: %v", err)
		return Fail, fmt.Errorf("request Sfl Send Vertical Turn info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SflVerticalTurn]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflVerticalTurn, true, 0)
		d.WaitTaskMap[mavlink.SflVerticalTurn] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl Vertical Turn info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.SflVerticalTurnResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl Vertical Turn result:%+v", *res)

	return int(res.Status), nil
}
func (d *Sfl) ReceiveSflVerticalTurn() {
	logger.Info("-->into Receive Sfl Vertical Turn")
	res := &mavlink.SflVerticalTurnResponse{}
	d.GetPacket(res)
	logger.Debugf("Sfl Vertical Turn Get 接收到Sfl信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflVerticalTurn]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl) SendSflCrashStop() (int, error) {
	logger.Info("-->into Send Sfl Crash Stop  msg")
	//获取开关机状态
	req := &mavlink.SflCrashStopRequest{}
	buff := req.Create()
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Send Sfl Crash Stop info err: %v", err)
		return Fail, fmt.Errorf("request Send Sfl Crash Stop info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SflCrashStop]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflCrashStop, true, 0)
		d.WaitTaskMap[mavlink.SflCrashStop] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl Crash Stop info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.SflCrashStopResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl Crash Stop result:%+v", *res)

	return int(res.Status), nil
}
func (d *Sfl) ReceiveSflCrashStop() {
	logger.Info("-->into Receive SflCrash Stop")
	res := &mavlink.SflCrashStopResponse{}
	d.GetPacket(res)
	logger.Debugf("Sfl Crash Stop Get 接收到Sfl信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflCrashStop]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl) SflSetPreciseHit(request *client.SflSetPreciseHitRequest) (int, error) {
	logger.Info("-->into Send Sfl SetPreciseHit  msg")
	//获取开关机状态
	req := &mavlink.SflSetPreciseHitRequest{}
	buff := req.Create(request)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Send Sfl Set PreciseHit info err: %v", err)
		return Fail, fmt.Errorf("request Send Sfl Set PreciseHit info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SflSetPreciseHit]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflSetPreciseHit, true, 0)
		d.WaitTaskMap[mavlink.SflSetPreciseHit] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl SetPreciseHit info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.SflSetPreciseHitResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl SetPreciseHit result:%+v", *res)

	return int(res.Status), nil
}
func (d *Sfl) ReceiveSetPreciseHit() {
	logger.Info("-->into Receive Set PreciseHit")
	res := &mavlink.SflSetPreciseHitResponse{}
	d.GetPacket(res)
	logger.Debugf("Sfl SetPreciseHit Get 接收到Sfl信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflSetPreciseHit]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}
func (d *Sfl) SflGetPreciseHit() (int, error) {
	logger.Info("-->into Send Sfl GetPreciseHit  msg")
	//获取开关机状态
	req := &mavlink.SflGetPreciseHitRequest{}
	buff := req.Create()
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Send Sfl Get PreciseHit info err: %v", err)
		return Fail, fmt.Errorf("request Send Sfl Get PreciseHit info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SflGetPreciseHit]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflGetPreciseHit, true, 0)
		d.WaitTaskMap[mavlink.SflGetPreciseHit] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("request Sfl GetPreciseHit info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.SflGetPreciseHitResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Sfl GetPreciseHit result:%+v", *res)

	return int(res.Enable), nil
}
func (d *Sfl) ReceiveGetPreciseHit() {
	logger.Info("-->into Receive Get PreciseHit")
	res := &mavlink.SflGetPreciseHitResponse{}
	d.GetPacket(res)
	logger.Debugf("Sfl GetPreciseHit Get 接收到Sfl信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflGetPreciseHit]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl) SflSetInvalidFreq(request *client.SflSetInvalidFreqRequest) (int, error) {
	logger.Info("---> Send Sfl Set Invalid")
	defer func() {
		if r := recover(); r != nil {
			logger.Error("Sfl Set Invalid occurred:", r)
			return
		}
	}()
	req := mavlink.SflSetInvalidRequestAll{}
	invalidlist := make([]mavlink.SflSetInvalidInfo, 0)
	for _, s := range request.FreqList {
		invalidlist = append(invalidlist, mavlink.SflSetInvalidInfo{
			StartFreq: uint16(s.StartFreq),
			EndFreq:   uint16(s.EndFreq),
		})
	}
	reqInfo := &mavlink.SflSetInvalidRequest{
		SetInvalidNum:  uint8(len(invalidlist)),
		SetInvalidList: invalidlist,
	}

	buff := req.Create(reqInfo)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.SflSetInvalidFreqList]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflSetInvalidFreqList, true, time.Millisecond*300)
		d.WaitTaskMap[mavlink.SflSetInvalidFreqList] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Send Sfl Set Invalid is :[%v]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send Sfl Set Invalid  err:[%v].Buff is [%v]", err, buff)
		return Fail, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send Sfl Set Invalid  err %s", err.Error())
		return Fail, err
	}
	res := result.(*mavlink.SflSetInvalidResponse)

	logger.Info("-->End Set Sfl Set Invalid")
	return int(res.Status), nil
}
func (d *Sfl) ReceiveSetInvalid() {
	logger.Info("-->into Receive Set Invalid")
	res := &mavlink.SflSetInvalidResponse{}
	d.GetPacket(res)
	logger.Debugf("Sfl Set Invalid 接收到Sfl信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflSetInvalidFreqList]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}
func (d *Sfl) SflGetInvalidFreq() ([]*client.FreqList, error) {
	logger.Info("---> Send SflGetInvalidFreq")
	var rsp []*client.FreqList
	req := &mavlink.SflGetInvalidListRequest{}
	buff := req.Create(0)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.SflGetInvalidFreqList]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflGetInvalidFreqList, true, 0)
		d.WaitTaskMap[mavlink.SflGetInvalidFreqList] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Send SflGetInvalidFreqList is :[% x]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send SflGetInvalidFreqList err:[%v].Buff is [% x]", err, buff)
		return rsp, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send SflGetInvalidFreqList err %s", err.Error())
		return rsp, err
	}
	res := result.(*mavlink.SflGetInvalidListResponse)
	for _, des := range res.Description {
		rsp = append(rsp, &client.FreqList{
			StartFreq: int32(des.StartFreqList),
			EndFreq:   int32(des.EndFreqList),
		})
	}
	logger.Info("-->End SflGetInvalidFreqList")
	return rsp, nil
}

// ReceiveGetInvalidList 接收 freq无效列表
func (d *Sfl) ReceiveGetInvalidList() {
	res := &mavlink.SflGetInvalidListResponse{}
	if err := d.UnmarshalFreqInvalidList(res); err != nil {
		logger.Errorf("parse freq Get Invalid  list response fail, e: %v", err)
		return
	}
	logger.Debugf("receive Send SflGetInvalidListResponse：%+v", *res)
	manager, ok := d.WaitTaskMap[mavlink.SflGetInvalidFreqList]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}
func (d *Sfl) UnmarshalFreqInvalidList(data *mavlink.SflGetInvalidListResponse) error {
	deviceInfoLen := binary.Size(mavlink.SflFreqInfo{})
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.Info); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}

	start := mavlink.HeaderLen + deviceInfoLen
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializeDrone(d.Msg[start:end]); err != nil {
		return err
	}
	return nil
}
func (d *Sfl) SendSflSetNoise(request *client.SflSetNoiseRequest) (int, error) {
	logger.Info("-->into Send Send Sfl Set Noise  msg")
	//获取开关机状态
	req := &mavlink.SflSetNoiseRequest{}
	buff := req.Create(uint32(request.Mode), uint32(request.Freq))
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Send Sfl Set Noise info err: %v", err)
		return Fail, fmt.Errorf("request Send Sfl Set Noise info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SflSetNoise]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflSetNoise, true, 0)
		d.WaitTaskMap[mavlink.SflSetNoise] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("requestSend Sfl Set Noise info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.SflSetNoiseResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Send Sfl Set Noise result:%+v", *res)

	return int(res.Status), nil
}

func (d *Sfl) ReceiveSflSetNoise() {
	logger.Info("-->into Receive Sfl SetNoise")
	res := &mavlink.SflSetNoiseResponse{}
	d.GetPacket(res)
	logger.Debugf("Sfl Set Noise Get ：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflSetNoise]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}
func (d *Sfl) SendSflSetHitRadius(request *client.SflSetAutoHitRadiusRequest) (int, error) {
	logger.Info("-->into Send Sfl SetAutoHitRadius  msg,req:", request)
	//获取开关机状态
	req := &mavlink.SflSetAutoHitRadiusRequest{}
	buff := req.Create(uint32(request.Radius))
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Send Sfl SetAutoHitRadius info err: %v", err)
		return Fail, fmt.Errorf("request Send Sfl SetAutoHitRadius info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SflSetAutoRadius]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflSetAutoRadius, true, 0)
		d.WaitTaskMap[mavlink.SflSetAutoRadius] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("requestSend Sfl SetAutoHitRadius info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.SflSetAutoHitRadiusResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Send Sfl SetAutoHitRadius result:%+v", *res)

	return int(res.Status), nil
}
func (d *Sfl) ReceiveSflSetAutoRadius() {
	logger.Info("-->into Receive Sfl SetAutoRadius")
	res := &mavlink.SflSetAutoHitRadiusResponse{}
	d.GetPacket(res)
	logger.Debugf("Sfl SetAutoRadius Get ：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflSetAutoRadius]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl) SendSflGetHitRadius(request *client.SflGetAutoHitRadiusRequest) (int, error) {
	logger.Info("-->into Send Sfl GetAutoHitRadius  msg,req:", request)
	//获取开关机状态
	req := &mavlink.SflGetAutoHitRadiusRequest{}
	buff := req.Create()
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Send Sfl GetAutoHitRadius info err: %v", err)
		return Fail, fmt.Errorf("request Send Sfl GetAutoHitRadius info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SflGetAutoRadius]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflGetAutoRadius, true, 0)
		d.WaitTaskMap[mavlink.SflGetAutoRadius] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("requestSend Sfl GetAutoHitRadius info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.SflGetAutoHitRadiusResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Send Sfl GetAutoHitRadius result:%+v", *res)

	return int(res.Radius), nil
}
func (d *Sfl) ReceiveSflGetAutoRadius() {
	logger.Info("-->into Receive Sfl GetAutoRadius")
	res := &mavlink.SflGetAutoHitRadiusResponse{}
	d.GetPacket(res)
	logger.Debugf("Sfl GetAutoRadius Get ：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflGetAutoRadius]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl) SflSetSwitchParameter(request *client.SflSetSwitchParameterRequest) (int, error) {
	logger.Info("-->into Send SflSetSwitchParameter  msg,req:", request)
	//获取开关机状态
	req := &mavlink.SflSetSwitchParameterRequest{}
	buff := req.Create(request)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Send SflSetSwitchParameter info err: %v", err)
		return Fail, fmt.Errorf("request Send SflSetSwitchParameter info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SflSetSwitchParam]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflSetSwitchParam, true, 0)
		d.WaitTaskMap[mavlink.SflSetSwitchParam] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("requestSend SflSetSwitchParameter info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.SflSetSwitchParameterResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Send SflSetSwitchParameter result:%+v", *res)

	return int(res.Status), nil
}
func (d *Sfl) ReceiveSflSetSwitchParameter() {
	logger.Info("-->into Receive Sfl SetSwitchParameter")
	res := &mavlink.SflSetSwitchParameterResponse{}
	d.GetPacket(res)
	logger.Debugf("Sfl SetSwitchParameter Get ：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflSetSwitchParam]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl) SflGetSwitchParameter(request *client.SflGetSwitchParameterRequest) ([]*client.SflSwitchParameter, error) {
	logger.Info("-->into Send SflSetSwitchParameter  msg,req:", request)
	//获取开关机状态
	req := &mavlink.SflGetSwitchParameterRequest{}
	buff := req.Create(request)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Send SflGetSwitchParameter info err: %v", err)
		return nil, fmt.Errorf("request Send SflGetSwitchParameter info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SflGetSwitchParam]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflGetSwitchParam, true, 0)
		d.WaitTaskMap[mavlink.SflGetSwitchParam] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("requestSend SflGetSwitchParameter info err: %v", checkNetConnErr)
			return nil, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.SflGetSwitchParameterResponse)
	if !ok {
		return nil, errors.New("response err type")
	}
	logger.Debug("response Send SflGetSwitchParameter result:%+v", *res)
	response := make([]*client.SflSwitchParameter, 0)
	response = append(response, &client.SflSwitchParameter{Type: int32(res.Type1), Enable: int32(res.Enable1)})
	response = append(response, &client.SflSwitchParameter{Type: int32(res.Type2), Enable: int32(res.Enable2)})
	response = append(response, &client.SflSwitchParameter{Type: int32(res.Type3), Enable: int32(res.Enable3)})
	response = append(response, &client.SflSwitchParameter{Type: int32(res.Type4), Enable: int32(res.Enable4)})
	return response, nil
}
func (d *Sfl) ReceiveSflGetSwitchParameter() {
	logger.Info("-->into Receive Sfl GetSwitchParameter")
	res := &mavlink.SflGetSwitchParameterResponse{}
	d.GetPacket(res)
	logger.Debugf("Sfl GetSwitchParameter Get ：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflGetSwitchParam]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}
func (d *Sfl) SendSflSetFreqCmd(sn string, op int32, fileName string) (int32, error) {
	logger.Info("-->into Send Sfl Set Freq Cmd  msg,req:", sn, op, fileName)
	var (
		status int32 = 0
		err    error
	)

	if op == CollectDataTracerOpen {
		if len(fileName) == 0 {
			return 0, errors.New("file name is empty on open")
		}
		status, err = d.openCollect(sn, fileName)

	} else if op == CollectDataTracerEnd {
		status, err = d.closeCollect(sn)

	} else {
		return 0, errors.New("not support op")
	}
	return status, err
}

// openCollect 发送打开数据收集
func (d *Sfl) openCollect(sn string, fileName string) (int32, error) {
	sessionCollMng.UnRegister(sn)

	s := &ClientCollectSession{}
	sessionCollMng.Register(sn, fileName, d.collectTaskTimeoutCB, s.InitSession, CollectDataToDevEnd)

	logger.Info("---> Send openCollect: ", CollectDataToDevBegin)
	req := &mavlink.SflSetFreqCmdRequest{}
	buff := req.Create(CollectDataToDevBegin)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.SflGetFreqCmd]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflGetFreqCmd, true, 0)
		d.WaitTaskMap[mavlink.SflGetFreqCmd] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Send Sfl setOpenCollect is :[% x]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send Sfl setOpenCollect err:[%v].Buff is [%v]", err, buff)
		sessionCollMng.UnRegister(sn)
		return 0, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send Sfl setOpenCollect err %s", err.Error())
		sessionCollMng.UnRegister(sn)
		return 0, err
	}

	// 只有等设备有响应才进行后续的动作。
	sessionCollMng.StartSession(sn)

	res := result.(*mavlink.SflSetFreqCmdResponse)

	logger.Info("-->End openCollect")
	return int32(res.Status), nil
}

// collectTaskTimeoutCB 检测定时器检测到已经开始的数据收集任务超时
func (d *Sfl) collectTaskTimeoutCB(sn string) {
	fileSz, receivedSz, fileName := sessionCollMng.GetFileParameters(sn)
	logger.Infof("filesz: %v, receivesz: %v, sn: %v", fileSz, receivedSz, sn)
	logger.Infof("collect task time out callback proc, sn: %v, send stop to dev", sn)
	d.closeCollect(sn)
	sessionCollMng.UnRegister(sn)
	d.reportCollectStatus(sn, ReportCollectStatusFail, fileName, receivedSz, fileSz, 11)
}

// collectTaskOffline 数据收集开始后，设备离线的处理
func (d *Sfl) collectTaskOffline(sn string) {
	fileSz, receivedSz, fileName := sessionCollMng.GetFileParameters(sn)
	logger.Infof("filesz: %v, receivesz: %v, sn: %v", fileSz, receivedSz, sn)
	logger.Infof("collect task on dev offline, sn: %v, send stop to dev", sn)
	d.closeCollect(sn)
	sessionCollMng.UnRegister(sn)
	d.reportCollectStatus(sn, ReportCollectStatusFail, fileName, receivedSz, fileSz, 11)
}
func (d *Sfl) ReceiveSflSetFreqCmd() {
	logger.Info("-->into Receive Sfl SetFreqCmd")
	res := &mavlink.SflSetFreqCmdResponse{}
	d.GetPacket(res)
	logger.Debugf("Sfl Set FreqCmd Get ：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflGetFreqCmd]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl) SendSflGetFreqNodeList() ([]uint32, error) {
	logger.Info("---> Send GetDetectFreqList")
	req := &mavlink.SflFreqDetectNodeListRequest{}
	buff := req.Create(0)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.SflGetFreqList]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflGetFreqList, true, 0)
		d.WaitTaskMap[mavlink.SflGetFreqList] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Send SendSflGetFreqNodeList is :[% x]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send SendSflGetFreqNodeList err:[%v].Buff is [% x]", err, buff)
		return nil, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send SendSflGetFreqNodeList err %s", err.Error())
		return nil, err
	}
	res := result.(*mavlink.SflFreqDetectNodeListResponse)

	logger.Info("-->End SendSflGetFreqNodeList")
	return res.FreqList, nil
}

func (d *Sfl) ReceiveSflGetHitPith() {
	logger.Info("-->into Receive Get Hit Pith")
	res := &mavlink.SflGetPitchResponse{}
	if err := d.UnmarshalPayloadSflHitPith(res); err != nil {
		logger.Errorf(err.Error())
		return
	}
	logger.Debugf("ReceiveSflGet Hit Pith 接收到Sfl信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflGetHitPith]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl) UnmarshalPayloadSflHitPith(data *mavlink.SflGetPitchResponse) error {
	deviceInfoLen := binary.Size(data.HitCnt)
	buff := &bytes.Buffer{}

	if err := binary.Write(buff, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, &data.HitCnt); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}

	start := mavlink.HeaderLen + deviceInfoLen
	end := d.MsgLen - mavlink.CrcLen
	if err := data.DeserializeDrone(d.Msg[start:end]); err != nil {
		return err
	}

	return nil
}

func (d *Sfl) UnmarshalPayloadSflGetGNSS(data *mavlink.SflGNSSGetResponse) error {
	buff := &bytes.Buffer{}
	start := mavlink.HeaderLen
	end := start + int(data.Size())
	logger.Debug("start: , end: ", start, end)
	logger.Debug("d.Msg[start:end] = ", d.Msg[start:end])
	if err := binary.Write(buff, binary.LittleEndian, d.Msg[start:end]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, data); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}
	logger.Debugf("ReceiveSfl UnmarshalPayloadSflGetGNSS 接收到Sfl信息：%#v", data)
	// if err := data.DeserializeDrone(d.Msg[start:end]); err != nil {
	// 	return err
	// }

	return nil
}

func (d *Sfl) UnmarshalPayloadSflSetGNSS(data *mavlink.SflGNSSSetResponse) error {
	buff := &bytes.Buffer{}
	start := mavlink.HeaderLen
	end := start + int(data.Size())
	logger.Debug("start: , end: ", start, end)
	logger.Debug("d.Msg[start:end] = ", d.Msg[start:end])
	if err := binary.Write(buff, binary.LittleEndian, d.Msg[start:end]); err != nil {
		return fmt.Errorf("UnmarshalPayload write buff err: %v", err)
	}
	if err := binary.Read(buff, binary.LittleEndian, data); err != nil {
		return fmt.Errorf("UnmarshalPayload read data err: %v", err)
	}
	logger.Debugf("ReceiveSfl UnmarshalPayloadSflSetGNSS 接收到Sfl信息：%#v", data)
	// if err := data.DeserializeDrone(d.Msg[start:end]); err != nil {
	// 	return err
	// }

	return nil
}

func (d *Sfl) ReceiveSflGetHitAngle() {
	logger.Info("-->into Receive Get Hit Angle")
	res := &mavlink.SflGetAngleResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveSfl Get Hit Angle 接收到Sfl信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflGetHitAngle]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl) ReceiveSflGetHitMode() {
	logger.Info("-->into Receive Get Hit Mode")
	res := &mavlink.SflGetHitModeResponse{}
	d.GetPacket(res)
	logger.Debugf("ReceiveSflGet Hit Mode 接收到Sfl信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflGetHitMode]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// SendSflSetWhite 发送设置Sfl白名单
func (d *Sfl) SendSflSetWhite(snList []mavlink.SflWhiteInfo) (int, error) {
	logger.Info("---> Send Sfl Set White")
	defer func() {
		if r := recover(); r != nil {
			logger.Error("Sfl Set White occurred:", r)
			return
		}
	}()
	req := mavlink.SflSetWhiteRequestAll{}
	whitelist := make([]mavlink.SflWhiteInfo, 0)
	for _, s := range snList {
		whitelist = append(whitelist, mavlink.SflWhiteInfo{Serial: s.Serial})
	}
	reqInfo := &mavlink.SflSetWhiteRequest{
		WhiteNum:  uint16(len(whitelist)),
		WhiteList: whitelist,
	}

	buff := req.Create(reqInfo)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.SflSetWhiteList]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflSetWhiteList, true, time.Millisecond*300)
		d.WaitTaskMap[mavlink.SflSetWhiteList] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("Send Sfl Set White is :[%v]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send Sfl Set White  err:[%v].Buff is [%v]", err, buff)
		return Fail, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send Sfl Set White  err %s", err.Error())
		return Fail, err
	}
	res := result.(*mavlink.SflSetWhiteResponse)

	logger.Info("-->End Set Sfl Set Alarm")
	return int(res.Status), nil
}

func SendDevWhiteListToSfl() {
	deviceInfo := &client.EquipListRes{}
	err := NewEquipList().List(context.Background(), &client.EquipListReq{}, deviceInfo)
	if err != nil {
		logger.Error("Get EquipList err: ", err)
	}
	//查白名单中的无人机，在Tracer侦测结果中添加无人机角色
	whiteList := &client.ListResAll{}
	err = NewWhiteList().ListAll(context.Background(), &client.ListReqAll{}, whiteList)
	if err != nil {
		logger.Error("Get whiteList err: ", err)
		return
	}
	logger.Info("Get EquipList is : ", whiteList.WhiteList)
	snList := make([]mavlink.SflWhiteInfo, 0)

	for _, all := range whiteList.WhiteList {
		if all.Role == FRIEND {
			var tempSn [32]byte
			copy(tempSn[:], all.Sn)
			snList = append(snList, mavlink.SflWhiteInfo{Serial: tempSn})
		}
	}
	for _, equip := range deviceInfo.Equips {
		if equip.Etype == "Sfl" {
			sflInfo := FindCacheDevice(equip.Sn, common.DEV_SFL)
			if sflInfo == nil {
				continue
			} else {
				dev := &Sfl{Device: sflInfo}
				dev.SendSflSetWhite(snList)
			}

		}
	}

}

// SflSendUpgradeF1
func (d *Sfl) SflSendUpgradeF1(fileName string, c2Ip string) (int32, error) {
	logger.Info("SflSendUpgradeF1 Start")

	req := &mavlink.SflUpdateF1Request{}
	buff := req.Create(fileName, c2Ip)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.SflIdUpgradeF1]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflIdUpgradeF1, true, 0)
		d.WaitTaskMap[mavlink.SflIdUpgradeF1] = manager
	}
	task := manager.AddTask(nil, nil)
	logger.Debugf("SflSendUpgradeF1 buff: %02X \n", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("SflSendUpgradeF1 发送写入固件数据信息失败: ", err)
		return 1, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("SflSendUpgradeF1 WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 1, checkNetConnErr
		}
		return 1, err
	}
	res := result.(*mavlink.SflUpdateF1Response)
	logger.Debugf("SflUpdateF1Response 获取写入固件数据信息结果：%#v", res)
	logger.Info("SflUpdateF1Response End")
	return int32(res.Status), nil
}

// ReceiveSflUpdateF1 获取请求固件升级响应
func (d *Sfl) ReceiveSflUpdateF1() {
	res := &mavlink.SflUpdateF1Response{}
	d.GetPacket(res)
	logger.Debugf("ReceiveSflUpdateF1 获取请求固件升级响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflIdUpgradeF1]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// SflSendUpgradeF2
func (d *Sfl) SflSendUpgradeF2() (int32, error) {
	logger.Info("SflSendUpgradeF2 Start")
	req := &mavlink.SflUpdateF2Request{}
	buff := req.Create()

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.SflIdUpgradeF2]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflIdUpgradeF2, true, time.Second*15)
		d.WaitTaskMap[mavlink.SflIdUpgradeF2] = manager
	}
	task := manager.AddTask(nil, nil)
	logger.Debugf("SflSendUpgradeF2 buff: %02X \n", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Error("SflSendUpgradeF2 发送写入固件数据信息失败: ", err)
		return -1, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("SflSendUpgradeF2 WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return -1, checkNetConnErr
		}
		return -1, err
	}
	res := result.(*mavlink.SflUpdateF2Response)
	logger.Debugf("SflUpdateF2Response 获取写入固件数据信息结果：%#v", res)
	logger.Info("SflUpdateF2Response End")
	return int32(res.Progress), nil
}

// ReceiveSflUpdateF2 获取请求固件升级响应
func (d *Sfl) ReceiveSflUpdateF2() {
	res := &mavlink.SflUpdateF2Response{}
	d.GetPacket(res)
	logger.Debugf("ReceiveSflUpdateF2 获取请求固件升级响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflIdUpgradeF2]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

// SflSendUpgradeF3
func (d *Sfl) SflSendUpgradeF3() (int32, error) {
	logger.Info("SflSendUpgradeF3 Start")

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.SflIdUpgradeF3]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflIdUpgradeF3, true, time.Second*60)
		d.WaitTaskMap[mavlink.SflIdUpgradeF3] = manager
	}
	task := manager.AddTask(nil, nil)

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("SflSendUpgradeF3 WaitTask Err %s", err.Error())
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			return 1, checkNetConnErr
		}
		return 1, err
	}
	res := result.(*mavlink.SflUpdateF3Response)
	logger.Debugf("SflUpdateF3Response 获取写入固件数据信息结果：%#v", res)
	logger.Info("SflUpdateF3Response End")
	return int32(res.UpgradeResult), nil
}

// ReceiveSflUpdateF3 获取请求固件升级响应
func (d *Sfl) ReceiveSflUpdateF3() {
	res := &mavlink.SflUpdateF3Response{}
	d.GetPacket(res)
	logger.Debugf("ReceiveSflUpdateF3 获取请求固件升级响应信息：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflIdUpgradeF3]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl) ReceiveSflSendNoiseData() {
	timeFreq := &mavlink.SflTimeFreqData{}
	err := timeFreq.Deserialize(d.Msg)
	if err != nil {
		logger.Error("timeFreq deserialize got err: %v", err)
		return
	}
	sn := ""
	idx := bytes.IndexByte(timeFreq.SnName[:], 0)
	if idx == -1 {
		idx = len(timeFreq.SnName)
	}
	sn = string(timeFreq.SnName[:idx])
	if timeFreq.FrameIdx == 0 {
		timeFreqMap.Reset(sn)
	}
	timeFreqMap.Write(sn, timeFreq.Data)
	logger.Infof("receive SflTimeFreqData, sn: %v, frameIdx: %v, frameNum: %v", sn, timeFreq.FrameIdx, timeFreq.FrameNum)
	if timeFreq.FrameIdx == timeFreq.FrameNum-1 {
		content := timeFreqMap.ReadAll(sn)
		logger.Infof("SflTimeFreqData content length: %v, sn: %v", len(content), sn)
		if len(content) != 768512 {
			logger.Errorf("SflTimeFreqData content length is not 768512, sn: %v", sn)
			return
		}
		arr := make([]int32, 0)
		for i, _ := range content {
			if i%2 == 0 {
				tmp := binary.LittleEndian.Uint16(content[i : i+2])
				arr = append(arr, int32(int16(tmp)))
			}
		}
		data := &client.SflTimeFreqData{
			Sn:   sn,
			Data: arr,
		}
		payload, _ := proto.Marshal(data)
		report := &client.ClientReport{
			MsgType: common.ClientMsgIdSFLFreqData,
			Data:    payload,
		}
		out, err := proto.Marshal(report)
		if err != nil {
			logger.Error("SflTimeFreqData marshal client report got error: %v", err)
			return
		}
		_ = mq.SflMsgBroker.Publish(mq.SflTopic, broker.NewMessage(out))
		logger.Infof("send SflTimeFreqData to client, sn: %v", sn)
	}
}

// ReceiveSflGetFreqList 接收 freq detect 节点列表
func (d *Sfl) ReceiveSflGetFreqList() {
	res := &mavlink.SflFreqDetectNodeListResponse{}
	if err := d.UnmarshalFreqDetectNodeList(res); err != nil {
		logger.Errorf("parse freq detect node list response fail, e: %v", err)
		return
	}
	logger.Debugf("receive Send FreqDetectNodeList：%+v", *res)
	manager, ok := d.WaitTaskMap[mavlink.SflGetFreqList]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl) UnmarshalFreqDetectNodeList(data *mavlink.SflFreqDetectNodeListResponse) error {
	buf := new(bytes.Buffer)
	if e := binary.Write(buf, binary.LittleEndian, d.Msg[mavlink.HeaderLen:]); e != nil {
		return fmt.Errorf("parse SflFreqDetectNodeListResponse fail, e: %v", e)
	}

	if e := binary.Read(buf, binary.LittleEndian, &data.FreqNums); e != nil {
		return fmt.Errorf("parse SflFreqDetectNodeListResponse.freqNums fail, e: %v", e)
	}

	if data.FreqNums <= 0 {
		return nil
	}

	start := mavlink.HeaderLen + binary.Size(data.FreqNums)
	end := d.MsgLen - mavlink.CrcLen
	buffer2 := new(bytes.Buffer)
	if e := binary.Write(buffer2, binary.LittleEndian, d.Msg[start:end]); e != nil {
		return fmt.Errorf("parse SflFreqDetectNodeListResponse fail, e: %v", e)
	}
	for i := 0; i < int(data.FreqNums); i++ {
		var freqValue uint32 = 0
		if err := binary.Read(buffer2, binary.LittleEndian, &freqValue); err != nil {
			return fmt.Errorf("parse freq node list value fail, e: %v", err)
		}
		data.FreqList = append(data.FreqList, freqValue)
	}
	return nil
}

// procCollectErrStatus 注销设备sn collection session, 上报错误
func (d *Sfl) procCollectErrStatus(sn string, errCode uint32) {
	if sn == "" {
		return
	}
	fileSz, receivedSz, fileName := sessionCollMng.GetFileParameters(sn)
	logger.Infof("filesz: %v, receivesz: %v, sn: %v", fileSz, receivedSz, sn)
	sessionCollMng.UnRegister(sn)
	d.reportCollectStatus(sn, ReportCollectStatusFail, fileName, receivedSz, fileSz, errCode)
}

// reportCollectStatus 上报数据收集状态
func (d *Sfl) reportCollectStatus(devSn string, status uint32, fName string, receiveFileSz uint32, totalFileSz uint32, errCode uint32) {
	if status != ReportCollectStatusFail {
		errCode = 0
	}
	equipModel, err := GetEquipBySn(devSn)
	name := devSn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	msgProto := &client.SflCollectDataReport{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        devSn,
			MsgType:   mavlink.SflSendFreqData,
			EquipType: int32(common.DEV_SFL),
		},

		Data: &client.SflCollectInfo{
			Status:          status,
			FileName:        fName,
			ReceiveFileSize: receiveFileSz,
			FileTotalSize:   totalFileSz,
			ErrCode:         errCode,
		},
	}
	if err == nil {
		msgProto.Header.ParentType = int32(equipModel.ParentType)
		msgProto.Header.ParentSn = equipModel.ParentSn
		msgProto.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msgProtoBin, e := proto.Marshal(msgProto)
	if e != nil {
		logger.Errorf("marshal collection status  fail, e: %v", e)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgIDSFLCollectData,
		Data:    msgProtoBin,
	}
	out, e := proto.Marshal(report)
	if e != nil {
		logger.Errorf("marshal report data fail, e: %v", e)
		return
	}
	e = mq.SflMsgBroker.Publish(mq.SflTopic, broker.NewMessage(out))
	if e != nil {
		logger.Errorf("push msg on topic: %v fail", mq.SflTopic)
		return
	}
	logger.Infof("send report, value: +%v", msgProto)
}

// ReceiveSflCollectData 转发数据收集
func (d *Sfl) ReceiveSflCollectData() {
	logger.Infof("receive sfl collect data")
	collectStatus := &mavlink.SflTimeFreqCollectReport{}

	// dev sn; 25 bytes
	readBegin := mavlink.HeaderLen
	offset := mavlink.DevSNLen
	readEnd := readBegin + offset
	err := mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, &collectStatus.SN, offset)
	devSn := ByteToString(collectStatus.SN[:])
	if devSn == "" {
		logger.Errorf("collect report dev sn is empty")
		return
	}
	d.updateStatus(devSn, 0)
	// status; 26 bytes
	readBegin = readEnd
	offset = 1
	readEnd = readBegin + offset
	err = mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, &collectStatus.Status, offset)
	logger.Debugf("sn: %v, status: %v", devSn, collectStatus.Status)

	if !sessionCollMng.IsBegin(devSn) {
		logger.Errorf("sn: %v not been triggered by client cmd; send stop cmd to history collect data.", devSn)
		d.closeCollect(devSn)
		return
	}

	sessionCollMng.UpdateTime(devSn)

	if collectStatus.Status == DEV_COLLECT_STATUS_ERR {

		var paramOne uint32 = 0
		readBegin = readEnd
		offset = 4
		readEnd = readBegin + offset
		err = mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, &paramOne, offset)

		logger.Infof("receive fail status, sn: %v, err code: %v", devSn, paramOne)

		d.procCollectErrStatus(devSn, paramOne)
		return
	}

	if !sessionCollMng.CheckCurrentReceiveStatus(devSn, int32(collectStatus.Status)) {
		logger.Errorf("sn: %v, receive status: %v not fit for cur status.", devSn, collectStatus.Status)
		return
	}

	if collectStatus.Status <= DEV_COLLECT_STATUS_GZIPING {
		procStatus := ReportCollectStatusIng
		if collectStatus.Status == DEV_COLLECT_STATUS_GZIPING {
			procStatus = ReportCollectGzip
		}
		fileSz, receivedSz, fileName := sessionCollMng.GetFileParameters(devSn)
		logger.Infof("filesz: %v, receivesz: %v, sn: %v", fileSz, receivedSz, devSn)
		d.reportCollectStatus(devSn, procStatus, fileName, receivedSz, fileSz, 0)
		return
	}

	// 开始上传，上传中，上传完成， 30 bytes
	var paramOne uint32 = 0
	readBegin = readEnd
	offset = 4
	readEnd = readBegin + offset
	err = mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, &paramOne, offset)

	//文件大小
	if collectStatus.Status == DEV_COLLECT_STATUS_UPLOAD_BEGIN {
		collectStatus.ParamOne = paramOne
		logger.Debugf("sn: %v, file size: %v", devSn, paramOne)
		sessionCollMng.UpdateFileSize(devSn, paramOne) // 记录文件大小

		fileSz, receivedSz, fileName := sessionCollMng.GetFileParameters(devSn)
		logger.Infof("filesz: %v, receivesz: %v, sn: %v", fileSz, receivedSz, devSn)
		d.reportCollectStatus(devSn, ReportCollectTraning, fileName, receivedSz, fileSz, 0)
		return
	}

	if collectStatus.Status == DEV_COLLECT_STATUS_UPLOAD_ING {
		// 最大分包数
		collectStatus.ParamOne = paramOne
		logger.Debugf("sn: %v, max package nums: %v", devSn, paramOne)

		// 分包序列号
		readBegin = readEnd
		offset = 4
		readEnd = readBegin + offset
		err = mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, &collectStatus.PkgIndex, offset)
		logger.Debugf("sn: %v, pkg index: %v", devSn, collectStatus.PkgIndex)

		// 发送数据长度
		readBegin = readEnd
		offset = 4
		readEnd = readBegin + offset
		err = mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, &collectStatus.DataLen, offset)
		logger.Debugf("sn: %v, pkg data len: %v", devSn, collectStatus.DataLen)
		sessionCollMng.UpdateReceiveFileSz(devSn, collectStatus.DataLen)

		// 数据内容
		readBegin = readEnd
		offset = int(collectStatus.DataLen)
		readEnd = readBegin + offset
		collectStatus.Data = make([]byte, offset)

		err = mavlink.Read(bytes.NewReader(d.Msg[readBegin:readEnd]), binary.LittleEndian, collectStatus.Data, offset)
		if err != nil {
			logger.Errorf("msg decode data pkg fail,sn: %v,e: %v", devSn, err)
			return
		}

		fileSz, receivedSz, fileName := sessionCollMng.GetFileParameters(devSn)
		logger.Infof("filesz: %v, receivesz: %v, sn: %v", fileSz, receivedSz, devSn)
		d.reportCollectStatus(devSn, ReportCollectTraning, fileName, receivedSz, fileSz, 0)
		err := sessionCollMng.WriteBuffToFile(devSn, collectStatus.Data)
		if err != nil {
			logger.Errorf("write data to buf fail, sn: %v, pkgIndex: %v, maxPkgNums: %v",
				devSn, collectStatus.PkgIndex, collectStatus.ParamOne)
			return
		}

		if collectStatus.PkgIndex < collectStatus.ParamOne-1 {
			logger.Debugf("is not full pkg, sn: %v, maxPkgNums: %v, curPkgIndex: %v, cur pkg len: %v",
				devSn, collectStatus.ParamOne, collectStatus.PkgIndex, collectStatus.DataLen)
			return
		}
		logger.Infof("receive complete package, sn: %v, cur pkgIndex: %v, maxPkgNums: %v",
			devSn, collectStatus.PkgIndex, collectStatus.ParamOne)
		return
	}

	if collectStatus.Status == DEV_COLLECT_STATUS_UPLOAD_END {
		logger.Infof("receive collect done : %v, sn: %v", DEV_COLLECT_STATUS_UPLOAD_END, devSn)
		d.receiveDonePkgProc(devSn)
	}
}

// receiveDonePkgProc 完整包后逻辑处理： 写文件，删除状态机
func (d *Sfl) receiveDonePkgProc(devSn string) {
	fileSz, receivedSz, fileName := sessionCollMng.GetFileParameters(devSn)
	logger.Infof("filesz: %v, receivesz: %v, sn: %v", fileSz, receivedSz, devSn)
	sessionCollMng.UnRegister(devSn)
	d.reportCollectStatus(devSn, ReportCollectStatusDone, fileName, receivedSz, fileSz, 0)
	logger.Info("--->End Receive tracer collection data")
}

// closeCollect 发送关闭收集收集
func (d *Sfl) closeCollect(sn string) (int32, error) {
	logger.Info("---> Send closeCollect: ", CollectDataToDevEnd)

	req := &mavlink.SflSetFreqCmdRequest{}
	buff := req.Create(CollectDataToDevEnd)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.SflGetFreqCmd]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflGetFreqCmd, true, 0)
		d.WaitTaskMap[mavlink.SflGetFreqCmd] = manager
	}
	task := manager.AddTask(nil, nil)
	logger.Debugf("Send Sfl closeCollect is :[% x]", buff)

	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("Send Sfl closeCollect err:[%v].Buff is [%v]", err, buff)
		manager.DeleteTask(task.TaskId)
		return 0, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("Send Sfl closeCollect err %s", err.Error())
		return 0, err
	}
	defer func() {
		sessionCollMng.UnRegister(sn)
	}()

	res := result.(*mavlink.TracerCollectResponse)

	logger.Info("-->End closeCollect")
	return int32(res.Status), nil
}

func (d *Sfl) ReceiveSflSendTimeFreq() {
	timeFreq := &mavlink.SflTimeFreqData{}
	err := timeFreq.Deserialize(d.Msg)
	if err != nil {
		logger.Error("timeFreq deserialize got err: %v", err)
		return
	}
	sn := ""
	idx := bytes.IndexByte(timeFreq.SnName[:], 0)
	if idx == -1 {
		idx = len(timeFreq.SnName)
	}
	sn = string(timeFreq.SnName[:idx])
	if timeFreq.FrameIdx == 0 {
		timeFreqMap.Reset(sn)
	}
	timeFreqMap.Write(sn, timeFreq.Data)
	logger.Infof("receive SflTimeFreqData, sn: %v, frameIdx: %v, frameNum: %v", sn, timeFreq.FrameIdx, timeFreq.FrameNum)
	if timeFreq.FrameIdx == timeFreq.FrameNum-1 {
		content := timeFreqMap.ReadAll(sn)
		logger.Infof("SflTimeFreqData content length: %v, sn: %v", len(content), sn)
		if len(content) != 76800 {
			logger.Errorf("SflTimeFreqData content length is not 768512, sn: %v", sn)
			return
		}
		arr := make([]int32, 0)
		for i, _ := range content {
			if i%2 == 0 {
				tmp := binary.LittleEndian.Uint16(content[i : i+2])
				arr = append(arr, int32(int16(tmp)))
			}
		}
		data := &client.SflTimeFreqData{
			Sn:   sn,
			Data: arr,
			Freq: timeFreq.Freq,
		}
		payload, _ := proto.Marshal(data)
		report := &client.ClientReport{
			MsgType: common.ClientMsgIDSFLTimeFreqData,
			Data:    payload,
		}
		out, err := proto.Marshal(report)
		if err != nil {
			logger.Error("SflTimeFreqData marshal client report got error: %v", err)
			return
		}
		_ = mq.SflMsgBroker.Publish(mq.SflTopic, broker.NewMessage(out))
		logger.Infof("send SflTimeFreqData to client, sn: %v", sn)
	}
}

func (d *Sfl) ReceiveSflSendTimeFreqD6() {
	timeFreq := &mavlink.SflTimeFreqDataD6{}
	err := timeFreq.Deserialize(d.Msg)
	if err != nil {
		logger.Error("timeFreq deserialize D6 got err: %v", err)
		return
	}
	sn := ""
	idx := bytes.IndexByte(timeFreq.SnName[:], 0)
	if idx == -1 {
		idx = len(timeFreq.SnName)
	}
	sn = string(timeFreq.SnName[:idx])
	if timeFreq.FrameIdx == 0 {
		timeFreqMap.Reset(sn)
	}
	timeFreqMap.Write(sn, timeFreq.Data)
	logger.Infof("receive SflTimeFreqDataD6, sn: %v, frameIdx: %v, frameNum: %v", sn, timeFreq.FrameIdx, timeFreq.FrameNum)
	if timeFreq.FrameIdx == timeFreq.FrameNum-1 {
		content := timeFreqMap.ReadAll(sn)
		logger.Infof("SflTimeFreqDataD6 content length: %v, sn: %v", len(content), sn)
		if len(content) != 76800 {
			logger.Errorf("SflTimeFreqDataD6 content length is not 77312, sn: %v", sn)
			return
		}
		arr := make([]int32, 0)
		for i, _ := range content {
			if i%2 == 0 {
				tmp := binary.LittleEndian.Uint16(content[i : i+2])
				arr = append(arr, int32(int16(tmp)))
			}
		}
		data := &client.SflTimeFreqDataD6{
			Sn:       sn,
			Freq:     timeFreq.Freq,
			TrackBws: timeFreq.TrackBws,
			TrackBwe: timeFreq.TrackBwe,
			Data:     arr,
		}
		payload, _ := proto.Marshal(data)
		report := &client.ClientReport{
			MsgType: common.ClientMsgIDSFLTimeFreqDataD6,
			Data:    payload,
		}
		out, err := proto.Marshal(report)
		if err != nil {
			logger.Error("SflTimeFreqDataD6 marshal client report got error: %v", err)
			return
		}
		_ = mq.SflMsgBroker.Publish(mq.SflTopic, broker.NewMessage(out))
		logger.Infof("send SflTimeFreqDataD6 to client, sn: %v", sn)
	}
}

func (d *Sfl) SendSflSetPosture(request *client.SflSetPostureRequest) (int, error) {
	logger.Info("-->into Send Sfl SetDevPosture  msg,req:", request)
	//获取开关机状态
	req := &mavlink.SflSetPostureRequest{}
	buff := req.Create(request)
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Send Sfl SetDevPosture info err: %v", err)
		return Fail, fmt.Errorf("request Send Sfl SetDevPosture info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SflSetDevPosture]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflSetDevPosture, true, 0)
		d.WaitTaskMap[mavlink.SflSetDevPosture] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("requestSend Sfl SetDevPosture info err: %v", checkNetConnErr)
			return Fail, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.SflSetPostureResponse)
	if !ok {
		return Fail, errors.New("response err type")
	}
	logger.Debug("response Send Sfl SetDevPosture result:%+v", *res)

	return int(res.Status), nil
}
func (d *Sfl) ReceiveSflSetPosture() {
	logger.Info("-->into Receive Sfl SetDevPosture")
	res := &mavlink.SflSetPostureResponse{}
	d.GetPacket(res)
	logger.Debugf("Sfl SetDevPosture Get ：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflSetDevPosture]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}

func (d *Sfl) SendSflGetPosture(request *client.SflGetPostureRequest) (*client.SflGetPostureResponse, error) {
	logger.Info("-->into Send Sfl GetPosture  msg,req:", request)
	//获取开关机状态
	req := &mavlink.SflGetPostureRequest{}
	buff := req.Create()
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("request Send Sfl GetPosture info err: %v", err)
		return nil, fmt.Errorf("request Send Sfl GetPosture info err: %v", err)
	}
	manager, ok := d.WaitTaskMap[mavlink.SflGetDevPosture]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflGetDevPosture, true, 0)
		d.WaitTaskMap[mavlink.SflGetDevPosture] = manager
	}

	result, err := manager.Wait()
	if err != nil {
		if checkNetConnErr := manager.CheckError(err, d.Device, CheckOnlineDuration); checkNetConnErr != nil {
			logger.Errorf("requestSend Sfl GetPosture info err: %v", checkNetConnErr)
			return nil, checkNetConnErr
		}
	}
	res, ok := result.(*mavlink.SflGetPostureResponse)
	if !ok {
		return nil, errors.New("response err type")
	}
	logger.Debug("response Send Sfl GetPosture result:%+v", *res)
	rsp := &client.SflGetPostureResponse{}
	rsp.Set = int32(res.Set)
	rsp.Pitch = res.Pitch
	rsp.Raw = res.Raw
	return rsp, nil
}
func (d *Sfl) ReceiveSflGetPosture() {
	logger.Info("-->into Receive Sfl GetPosture")
	res := &mavlink.SflGetPostureResponse{}
	d.GetPacket(res)
	logger.Debugf("Sfl GetPosture Get ：%#v", res)
	manager, ok := d.WaitTaskMap[mavlink.SflGetDevPosture]
	if ok {
		manager.CompletedTask(res, nil)
	}
	return
}
func (d *Sfl) ReciveEncryptDataSteam() {
	data := &mavlink.SflEncryptDataSteam{}
	err := data.Deserialize(d.Msg)
	if err != nil {
		logger.Error("data deserialize got err: %v", err)
		return
	}

	//注意：主流程不能被阻塞
	handleObj := getHandleDecryDataProcessSfl()
	handleObj.SendData(data)
	logger.Debugf("data = %+v", data)
	logger.Debugf("dev sn = %s", string(data.SnName[:]))
}

type SflDecryptDetectMsg struct {
	toDecryDataChan chan *mavlink.SflEncryptDataSteam
}

func (p *SflDecryptDetectMsg) SendData(data *mavlink.SflEncryptDataSteam) {
	select {
	case p.toDecryDataChan <- data:
	default:
		logger.Infof("[consumer toDecryDataChan too slow]. send to chan is block.")
	}

}

func (p *SflDecryptDetectMsg) GetData() *mavlink.SflEncryptDataSteam {
	return <-p.toDecryDataChan
}

// 通过调用 utils.SingletonFactory() 给 getHandleDecryDataProcess 变量进行赋值。
// 调用该函数 utils.SingletonFactory() 返回一个匿名函数， 并赋值给 getHandleDecryDataProcess，
// 通过 getHandleDecryDataProcess() 运行匿名函数并返回 *DecryptDetectMsg 对象,
// 多次调用 getHandleDecryDataProcess() 只会运行一次匿名函数，并返回第一次运行的 *DecryptDetectMsg 对象。
var getHandleDecryDataProcessSfl = utils.SingletonFactory(func(inParams *SflDecryptDetectMsg) {
	inParams.toDecryDataChan = make(chan *mavlink.SflEncryptDataSteam, 1024)
	go SflDecryptData(inParams)
})

// 1. 获取token(get url 方式)
// 2. 对data 使用token 解密(get url 方式)
// 3. 向设备 发送 0x4A 消息
func SflDecryptData(in *SflDecryptDetectMsg) {
	token, err := GetTracerCryptToken()
	if err != nil {
		logger.Error("get token err = ", err)
	} else {
		logger.Infof("decrypt_token: %v", token)
	}
	//
	for {
		RawData := in.GetData()
		logger.Debugf("RawData = %+v", RawData)
		dataA3 := RawData.DataA3
		data80 := RawData.Data80
		var snNullIndx int
		for snNullIndx = 0; snNullIndx < 25; snNullIndx++ {
			if RawData.SnName[snNullIndx] == 0 {
				break
			}
		}
		sn := string(RawData.SnName[:snNullIndx])
		uniquID := RawData.UniqueID

		dev := FindCacheDevice(sn, common.DEV_SFL)
		if dev == nil {
			logger.Debugf("sn = ", sn)
			logger.Debug("设备未在线")
			continue
		}

		{
			if token == "" {
				token, err = GetTracerCryptToken()
				if err != nil {
					logger.Error("repeated get token err = ", err)
				}
			}
			deDataA3, err, errCode := GetTracerDecrypt(token, dataA3)

			if err != nil {
				logger.Error("err = ", err)
				d := &Sfl{Device: dev}
				req := bean.SflDecryptSend{
					UniqueId: uniquID,
					Result:   uint32(errCode),
					JsonLen:  uint32(len(deDataA3)),
					JsonData: deDataA3,
				}
				logger.Debugf("req = %+v", req)
				_, err = d.SendSflDecryptData(&req)
				if err != nil {
					logger.Error("---->SendSflDecryptData err:", err)

				} else {
					logger.Debug("SendSflDecryptData OK...")
				}
			} else {
				deDataA3Len := len(deDataA3)
				d := &DroneID{Device: dev}
				req := bean.TracerDecryptSend{
					UniqueId: uniquID,
					Result:   0,
					JsonLen:  uint32(deDataA3Len),
					JsonData: deDataA3,
				}
				logger.Debugf("req = %+v", req)
				_, err = d.SendTracerDecryptData(&req)
				if err != nil {
					logger.Error("---->SendSflDecryptData err:", err)

				} else {
					logger.Debug("SendSflDecryptData OK...")
				}
			}

		}

		{
			if len(data80) == 0 {
				logger.Debug("pkg not contains dataA3,do not reponse")
			} else {
				deData80, err, errCode := GetTracerDecrypt(token, data80)
				if err != nil {
					logger.Error("err = ", err)
					d := &DroneID{Device: dev}
					req := bean.TracerDecryptSend{
						UniqueId: uniquID,
						Result:   uint32(errCode),
						JsonLen:  uint32(len(deData80)),
						JsonData: deData80,
					}
					logger.Debugf("req = %+v", req)
					_, err = d.SendTracerDecryptData(&req)
					if err != nil {
						logger.Error("---->GetSflDecrypt err:", err)

					}

				} else {
					deData80Len := len(deData80)
					d := &DroneID{Device: dev}
					req := bean.TracerDecryptSend{
						UniqueId: uniquID,
						Result:   0,
						JsonLen:  uint32(deData80Len),
						JsonData: deData80,
					}
					logger.Debugf("req = %+v", req)
					_, err = d.SendTracerDecryptData(&req)
					if err != nil {
						logger.Error("---->Send Sfl Set Alarm err:", err)

					}
				}
			}

		}

	}

}

// SendSflDecryptData 发送Sfl解密数据
func (d *Sfl) SendSflDecryptData(msg *bean.SflDecryptSend) (int, error) {
	logger.Info("---> SendTracerDecryptData ")
	req := &mavlink.SendSflDecryptDataRequest{}
	buff := req.Create(msg)

	// 先创建接受返回结果的任务
	manager, ok := d.WaitTaskMap[mavlink.SflDroneIdResultDecrytp]
	if !ok {
		manager = NewWaitTaskManager(mavlink.SflDroneIdResultDecrytp, true, 0)
		d.WaitTaskMap[mavlink.SflDroneIdResultDecrytp] = manager
	}
	task := manager.AddTask(nil, nil)

	logger.Debugf("SendSflDecryptDatais :[%+v]", buff)
	// 发送请求
	if _, err := d.Conn.Write(buff); err != nil {
		logger.Errorf("SendSflDecryptData err:[%v].Buff is [%v]", err, buff)
		return Fail, err
	}

	result, err := manager.WaitTask(task)
	if err != nil {
		logger.Errorf("SendSflDecryptData  err %s", err.Error())
		return Fail, err
	}
	res := result.(*mavlink.SendSflDecryptDataResponse)

	logger.Info("-->End SendSflDecryptData ", res)
	return 0, nil
}

func (d *Sfl) ReceiveDecryptDataResult() {
	res := &mavlink.SendSflDecryptDataResponse{}
	d.GetPacket(res)
	logger.Debug("ReceiveDecryptDataResult :%+v", *res)
	manager, ok := d.WaitTaskMap[mavlink.SflDroneIdResultDecrytp]
	if ok {
		manager.CompletedTask(res, nil)
	}
}

package handler

import (
	"context"
	"errors"
	"fmt"
	"net"
	"reflect"
	"strconv"
	"time"

	"adasgitlab.autel.com/tools/cuav_server/proto/mavlink"
	"adasgitlab.autel.com/tools/cuav_server/rpc/connmgr"

	"adasgitlab.autel.com/tools/cuav_plugin/broker"
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/slink_proto/slinkv1"
	"google.golang.org/protobuf/proto"

	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	iphelper "adasgitlab.autel.com/tools/cuav_server/entity/helper"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
	"adasgitlab.autel.com/tools/cuav_server/repo/utils"
	"adasgitlab.autel.com/tools/cuav_server/rpc/devicerpc"
	"adasgitlab.autel.com/tools/cuav_server/rpc/tcpserver"
)

var Sfl200FreqDirectHitMap = common.NewSfl200FreqDirectHitMap()

var Sfl200HeartSum uint8 = 0

type Sfl200 struct {
	*Device
	dt common.DeviceType
}

var _ DeviceIfer = (*Sfl200)(nil)

// SetDevice 要使用GetOnLineDev 接口，必须要给该设备实现 DeviceIfer 接口
func (tg *Sfl200) SetDevice(d *Device) {
	tg.Device = d
}

// HandleBroadCast 处理广播消息
func (d *Sfl200) HandleBroadCast(ctx context.Context, req interface{}) (*slinkv1.UdpBroadcastConfirmResponse, error) {
	v, ok := req.(*slinkv1.UdpBroadcastConfirmRequest)
	if !ok {
		logger.Errorf("HandleDiscovery convert UdpBroadcastConfirmRequest err")
		return nil, errors.New("HandleDiscovery convert UdpBroadcastConfirmRequest err")
	}
	logger.Errorf("HandleDiscovery UdpBroadcastConfirmRequest %+v", v.Format())

	//根据设备IP选择本地IP，作为回包信息回包
	udpAddr, ok := ctx.Value(common.UDPAddrCxtKey).(*net.UDPAddr)
	if !ok {
		logger.Errorf("ctx UdpRemoteAddr empty")
		return nil, errors.New("ctx UdpRemoteAddr empty")
	}
	matchIP := iphelper.MatchLocalIP(udpAddr.IP.To4().String())
	if matchIP == "" {
		logger.Errorf("MatchLocalIP empty remoteIP %s", udpAddr.IP.To4().String())
		return nil, errors.New("MatchLocalIP empty remoteIP")
	}
	matchPort, err := iphelper.GetFreeTCPPort()
	if err != nil {
		logger.Errorf("GetFreeTcpPort empty remoteip %s", udpAddr.IP.To4().String())
		return nil, errors.New("GetFreeTcpPort empty")
	}

	svr := tcpserver.TcpServerMgrInstance().GetServer(v.GetSn())
	if svr != nil {
		matchIP = svr.IP
		matchPort = svr.Port
	} else {
		server := tcpserver.New(tcpserver.WithIP(matchIP), tcpserver.WithPort(matchPort), tcpserver.WithSn(v.GetSn()))
		tcpserver.TcpServerMgrInstance().SetServer(v.GetSn(), server) //RadarTcpServerMap 可以使用这个。
		go server.Start()
	}
	rsp := &slinkv1.UdpBroadcastConfirmResponse{
		Sn:       v.Sn,
		Addr:     iphelper.IPV4(matchIP),
		Port:     uint16(matchPort),
		ConnType: 1,
	}
	return rsp, nil
}
func SendSfl200Heart() {
	ticker := time.NewTicker(time.Second * 1)
	defer ticker.Stop()
	for range ticker.C {
		logger.Info("SendSfl200Heart")

		DevStatusMap.Range(func(key, value interface{}) bool {
			logger.Info("SendSfl200Heart key:", key)
			dev := value.(*Device)
			if dev.DevType == common.DEV_SFL200 && dev.Status == common.DevOnline {
				reqMode := &Sfl200{
					Device: dev,
					dt:     common.DEV_SFL200,
				}
				reqMode.SendExtHeartbeat()
			}
			return true
		})
	}
}
func (d *Sfl200) SendExtHeartbeat() error {
	Sfl200HeartSum++
	if Sfl200HeartSum > 255 {
		Sfl200HeartSum = 0
	}
	req := &mavlink.Sfl200HeartbeatExtRequest{
		Sum: Sfl200HeartSum,
	}
	conn := connmgr.Instance().GetConn(d.Sn)
	reqBuff := req.CreateSfl200HeartbeatExt()
	if conn != nil {
		_, err := conn.Conn.Write(reqBuff)
		logger.Infof("Sfl200 c2发送心跳结果：%X", reqBuff)
		if err != nil {
			logger.Error("SendExtHeartbeat to Sfl200,sn:", d.Sn)
			return errors.New("SendExtHeartbeat to Sfl200,sn:" + d.Sn)
		}
	}
	return nil
}
func Sfl200OfflineReport(sn, remoteIp string) {
	CloseConnAndDelDevStatus(sn, int32(common.DEV_SFL200))

	dataInfo := &client.Sfl200SystemStatSocketInfo{
		Sfl200Sn: sn,
		IsOnline: common.DevOffline,
	}

	equipModel, err := GetEquipBySn(sn)
	name := sn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	msg := &client.Sfl200SystemStateInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        sn,
			EquipType: int32(common.DEV_SFL200),
			MsgType:   slinkv1.Sfl200UploadSystemStatData,
		},
		Data: dataInfo,
	}
	if err == nil {
		msg.Header.ParentType = int32(equipModel.ParentType)
		msg.Header.ParentSn = equipModel.ParentSn
		msg.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msgOut, err := proto.Marshal(msg)
	if err != nil {
		logger.Error("marshal msg err:", err)
		return
	}
	report := &client.ClientReport{
		MsgType: common.ClientMsgIDSfl200SystemStateData,
		Data:    msgOut,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}
	logger.Debug("Sfl200 is offline,sn:", sn)
	_ = mq.Sfl200MsgBroker.Publish(mq.Sfl200Topic, broker.NewMessage(out))
	//Sfl200离线事件上报
	err = NewEquipList().UpdateSfl200ParentSn(context.Background(), &client.UpdateSfl200ParentSnReq{Sfl200Sn: sn}, &client.UpdateSfl200ParentSnRes{})
	if err != nil {
		logger.Error("Update Sfl200 Status err: ", err)
	}
	go Sfl200OffLineEventReport(sn)
}

// Sfl200OffLineEventReport Sfl200离线事件上报
func Sfl200OffLineEventReport(sn string) {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_SFL200, sn)
	eventId := ""

	if cache, ok := DevStatusMapOnEvent.Load(cacheKey); ok {
		dev := cache.(*Device)
		eventId = utils.GetEventId(dev.SessionId)
	}
	DevStatusMapOnEvent.Delete(cacheKey)

	equipModel, err := GetEquipBySn(sn)
	name := sn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	dataInfo := &client.Sfl200SystemStateInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        sn,
			EquipType: int32(common.DEV_SFL200),
			MsgType:   common.Sfl200EventOffLine,
		},
		Data: &client.Sfl200SystemStatSocketInfo{
			Sfl200Sn: sn,
			IsOnline: common.DevOffline,
			EventId:  eventId,
		},
	}
	if err == nil {
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgSfl200StatusEventData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Info("Sfl200 Offline event report:", report)
}

func Sfl200HitOverEventReport(hitNode *common.SflHitEventInfo) {
	var (
		eventID = ""
		hitSucc = false
		hitOver = &common.SflHitEventInfo{}
	)

	cacheKey := GetSfl200HitCacheKey(hitNode.UavSn, hitNode.DroneName, hitNode.ProductType)
	if cache, ok := Sfl200HitOverMapOnEvent.Load(cacheKey); !ok {
		logger.Errorf("Sfl200HitOverEventReport key not exist: %s", cacheKey)
		return
	} else {
		if uav, ok := cache.(*common.SflHitEventInfo); !ok {
			logger.Errorf("Sfl200HitOverEventReport value type error: %+v", reflect.TypeOf(cache))
			return
		} else {
			eventID = utils.GetEventId(uav.SessionId)
			if time.Since(uav.DetectReportTime) > 3*time.Second {
				hitSucc = true
			}
		}
	}
	Sfl200HitOverMapOnEvent.Delete(cacheKey)

	equipModel, err := GetEquipBySn(hitNode.Sn)
	name := hitNode.Sn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	dataInfo := &client.SflHitStateInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        hitNode.Sn, // sfl200 sn
			EquipType: int32(common.DEV_SFL200),
		},
		Data: &client.GimbalCounterHitSocketInfo{
			SerialNum:      hitNode.UavSn,
			DroneName:      hitOver.DroneName,
			DroneLongitude: hitOver.DroneLongitude,
			DroneLatitude:  hitOver.DroneLatitude,
			DroneHeight:    hitOver.DroneHeight,
			DroneYawAngle:  hitOver.DroneYawAngle,
			EventId:        eventID,
		},
	}
	if err == nil {
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	if hitSucc == false {
		dataInfo.Header.MsgType = common.Sfl200EventHitFail
	} else {
		dataInfo.Header.MsgType = common.Sfl200EventHitSucc
	}

	logger.Infof("sfl200 hit over report: %v", dataInfo)
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgSfl200HitEventData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Infof("sfl200 hit status: %v, publish event report: %v", hitSucc, report)
}

// Sfl200DetectDisappearEventReport sfl200侦测消失事件上报
func Sfl200DetectDisappearEventReport(sn string) {
	cacheKey := fmt.Sprintf("%d_%s", common.DEV_SFL200, sn)
	eventId := ""

	if cache, ok := DevDetectMapOnEvent.Load(cacheKey); ok {
		detect := cache.(*DetectEvent)
		eventId = utils.GetEventId(detect.SessionId)
	} else {
		logger.Debugf("has not sfl200 detect disappear event report, sn: %s", sn)
		return
	}
	DevDetectMapOnEvent.Delete(cacheKey)

	equipModel, err := GetEquipBySn(sn)
	name := sn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	dataInfo := &client.SflDetectInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        sn,
			EquipType: int32(common.DEV_SFL200),
			MsgType:   common.Sfl200EventDetectDisAppear,
		},
		Data: &client.GimbalCounterDetectSocketInfo{
			Sn:      sn,
			EventId: eventId,
		},
	}
	if err == nil {
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgSFl200DetectEventData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}

	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Debugf("sfl200 detect disappear event report: %+v", report)
}

// Sfl200AgxDetectDisappearEventReport sfl200上报Agx侦测无人机消失事件
func Sfl200AgxDetectDisappearEventReport(sn string) {
	cacheKey := GetSfl200AgxDetectCacheKey(sn)
	eventId := ""
	cache, ok := DevDetectMapOnEvent.Load(cacheKey)
	if !ok {
		logger.Errorf("Sfl200AgxDetectDisappearEventReport key not exist: %v", cacheKey)
		return
	}

	dev, exist := cache.(*DetectEvent)
	if dev == nil || !exist {
		logger.Errorf("not exist sfl200 agx DetectEvent, cache key: %v", cacheKey)
		return
	}

	eventId = utils.GetEventId(dev.SessionId)
	// agx锁定事件上报
	sfl200AgxPtzLockEventReport(eventId, sn, dev)

	DevDetectMapOnEvent.Delete(cacheKey)

	equipModel, err := GetEquipBySn(sn)
	name := sn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}
	dataInfo := &client.AgxDetectInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        sn,
			EquipType: int32(common.DEV_SFL200),
			MsgType:   common.Sfl200AgxDetectDisappear,
		},
		EventId: eventId,
	}
	if err == nil {
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}
	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgSFl200AgxDetectEventData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}
	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Debugf("sfl200 agx detect disappear event report: %+v", dataInfo)
}

func sfl200AgxPtzLockEventReport(eventId, sn string, detectInfo *DetectEvent) {
	if detectInfo == nil {
		return
	}

	var (
		lockUavByPtz uint8 = 0
		msgType            = common.Sfl200AgxEventPtzLockUavFail
	)

	if detectInfo.Items != nil && len(detectInfo.Items) > 0 {
		lockUavByPtz = 1
		logger.Debugf("ptz lock uav succ, sn: %v", sn)
	}

	lockedItem := []*client.AgxPtzLockedItem{}
	if lockUavByPtz == 1 {
		msgType = common.Sfl200AgxEventPtzLockUavSucc

		for _, uav := range detectInfo.Items {
			if uav == nil {
				continue
			}
			lockedItem = append(lockedItem, &client.AgxPtzLockedItem{
				DroneName:  uav.DroneName,
				SerialNum:  strconv.FormatInt(int64(uav.ObjectId), 10),
				Longitude:  uav.Longitude,
				Latitude:   uav.Latitude,
				LockedTime: uav.LockedTime.UnixMilli(),
			})
		}
	}

	equipModel, err := GetEquipBySn(sn)
	name := sn
	if equipModel != nil && equipModel.Name != "" {
		name = equipModel.Name
	}

	dataInfo := &client.AgxPtzLockInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:      name,
			Sn:        sn,
			EquipType: int32(common.DEV_SFL200),
			MsgType:   int32(msgType),
		},
		Data:    lockedItem,
		EventId: eventId,
	}
	if err == nil {
		dataInfo.Header.ParentType = int32(equipModel.ParentType)
		dataInfo.Header.ParentSn = equipModel.ParentSn
		dataInfo.Header.IsIntegrated = equipModel.IsIntegrated
	}

	msg, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("marshal dataInfo err:", err)
		return
	}

	report := &client.ClientReport{
		MsgType: common.ClientMsgSFl200AgzPtzLockEventData,
		Data:    msg,
	}
	out, err := proto.Marshal(report)
	if err != nil {
		logger.Error("marshal report err:", err)
		return
	}
	_ = mq.EventReportBroker.Publish(mq.EventReportTopic, broker.NewMessage(out))
	logger.Debugf("sfl200 agx ptz lock event status: %+v,  report: %+v", lockUavByPtz, dataInfo)
}

func GetSfl200HitCacheKey(droneSn, droneName string, productType int32) string {
	hitCacheKey := fmt.Sprintf("%d_%d_%s_%s", common.DEV_SFL200, productType, droneSn, droneName)
	return hitCacheKey
}

func GetSfl200AgxDetectCacheKey(devSn string) string {
	return fmt.Sprintf("%d_%s_%s", common.DEV_SFL200, "agx", devSn)
}

// Sfl200SetWorkMode 设置工作模式
func (d *Sfl200) Sfl200SetWorkMode(req *client.Sfl200SetWorkModeRequest) (int32, error) {
	logger.Debug("--->Receive SetWork Mode,req:", req)
	devReq := &slinkv1.Sfl200SendSetWorkModeRequest{
		SysWorkMode: uint8(req.WorkMode),
	}

	deviceResp, err := devicerpc.Call(req.Sn, common.DEV_SFL200, slinkv1.Sfl200SendWorkModeSetting, devReq)
	if err != nil {
		logger.Errorf("Sfl200SetWorkModeRequest rpc callV2 error: %v", err)
		return Fail, err
	}
	result, ok := deviceResp.(*slinkv1.Sfl200SendSetWorkModeResponse)
	if !ok {
		logger.Errorf("Sfl200SetWorkModeRequest convert  error")
		return Fail, fmt.Errorf("Sfl200SetWorkModeRequest convert  error")
	}
	logger.Debugf("Sfl200SetWorkModeRequest response: %+v", result)
	return int32(result.Status), nil
}

// Sfl200GetWorkMode 获取工作模式
func (d *Sfl200) Sfl200GetWorkMode(req *client.Sfl200GetWorkModeRequest) (int32, error) {
	logger.Debug("--->Receive GetWork Mode,req:", req)
	devReq := &slinkv1.Sfl200SendGetWorkModeRequest{}

	deviceResp, err := devicerpc.Call(req.Sn, common.DEV_SFL200, slinkv1.Sfl200SendWorkModeGetting, devReq)
	if err != nil {
		logger.Errorf("Sfl200SendGetWorkModeRequest rpc callV2 error: %v", err)
		return Fail, err
	}
	result, ok := deviceResp.(*slinkv1.Sfl200SendGetWorkModeResponse)
	if !ok {
		logger.Errorf("Sfl200SendGetWorkModeRequest convert  error")
		return Fail, fmt.Errorf("Sfl200SendGetWorkModeRequest convert  error")
	}
	logger.Debugf("Sfl200SendGetWorkModeRequest response: %+v", result)
	return int32(result.SysWorkMode), nil
}

// Sfl200SetAutoHitConfig 自动察打模式指令参数配置
func (d *Sfl200) Sfl200SetAutoHitConfig(req *client.Sfl200SetAutoHitConfigRequest) (int32, error) {
	logger.Debug("--->Receive Set Auto Hit Config,req:", req)
	devReq := &slinkv1.Sfl200SendAutoFindHitSettingRequest{
		SysDZWType:  uint8(req.SysDzWType),
		SysDZPPDX:   uint8(req.SysDzPPdx),
		SysYPEnable: uint8(req.SysYPEnable),
		SysYPCdt1:   uint8(req.SysYPCdt1),
		SysYPCdt2:   uint8(req.SysYPCdt2),
		SysYPMtd:    uint8(req.SysYPMtd),
		SysCDWType:  uint8(req.SysCDWType),
		SysCDMType:  uint8(req.SysCDMType),
		SysCDWD1:    uint16(req.SysCdWD1),
		SysCDWD2:    uint16(req.SysCdWD2),
		SysCDWD3:    uint16(req.SysCdWD3),
		SysCDWT1:    uint16(req.SysCdWT1),
		SysCDWT2:    uint16(req.SysCdWT2),
		SysCDWT3:    uint16(req.SysCdWT3),
	}
	deviceResp, err := devicerpc.Call(req.Sn, common.DEV_SFL200, slinkv1.Sfl200SendAutoFindHitSetting, devReq)
	if err != nil {
		logger.Errorf("Sfl200SetAutoHitConfig rpc callV2 error: %v", err)
		return Fail, err
	}
	result, ok := deviceResp.(*slinkv1.Sfl200SendAutoFindHitSettingResponse)
	if !ok {
		logger.Errorf("Sfl200SetAutoHitConfig convert  error")
		return Fail, fmt.Errorf("Sfl200SetAutoHitConfig convert  error")
	}
	logger.Debugf("Sfl200SetAutoHitConfig response: %+v", result)
	return int32(result.Status), nil
}

// Sfl200GetAutoHitConfig 自动察打模式指令参数获取
func (d *Sfl200) Sfl200GetAutoHitConfig(req *client.Sfl200GetAutoHitConfigRequest) (*slinkv1.Sfl200SendAutoFindHitGetResponse, error) {
	logger.Debug("--->Receive Get Auto Hit Config,req:", req)
	var devReq = &slinkv1.Sfl200SendAutoFindHitGetRequest{}

	deviceResp, err := devicerpc.Call(req.Sn, common.DEV_SFL200, slinkv1.Sfl200SendAutoFindHitGet, devReq)
	if err != nil {
		logger.Errorf("Sfl200GetAutoHitConfig rpc callV2 error: %v", err)
		return nil, err
	}
	result, ok := deviceResp.(*slinkv1.Sfl200SendAutoFindHitGetResponse)
	if !ok {
		logger.Errorf("Sfl200GetAutoHitConfig convert  error")
		return nil, fmt.Errorf("Sfl200GetAutoHitConfig convert  error")
	}
	logger.Debugf("Sfl200GetAutoHitConfig response: %+v", result)
	return result, nil
}

// Sfl200PtzFollowUav 目标PTZ跟踪
func (d *Sfl200) Sfl200PtzFollowUav(req *client.Sfl200PtzFollowUavRequest) (int32, error) {
	logger.Debug("--->Receive Ptz Follow Uav,req:", req)
	var tempSn [32]byte
	for i, v := range []byte(req.DroneSn) {
		tempSn[i] = v
	}
	var devReq = &slinkv1.Sfl200SendPtzFollowUavRequest{
		Type:           uint8(req.Type),
		ObjId:          req.ObjId,
		DroneSn:        tempSn,
		Classification: uint32(req.Classification),
		Reserve:        0,
	}

	deviceResp, err := devicerpc.Call(req.Sn, common.DEV_SFL200, slinkv1.Sfl200SendPtzFollowUav, devReq)
	if err != nil {
		logger.Errorf("Sfl200PtzFollowUav rpc callV2 error: %v", err)
		return Fail, err
	}
	result, ok := deviceResp.(*slinkv1.Sfl200SendPtzFollowUavResponse)
	if !ok {
		logger.Errorf("Sfl200PtzFollowUav convert  error")
		return Fail, fmt.Errorf("Sfl200PtzFollowUav convert  error")
	}
	logger.Debugf("Sfl200PtzFollowUav response: %+v", result)
	return int32(result.Status), nil
}

// Sfl200DealUav 目标打击处置
func (d *Sfl200) Sfl200DealUav(req *client.Sfl200DealUavRequest) (int32, error) {
	logger.Debug("--->Receive Deal Uav,req:", req)
	var tempSn [32]byte
	for i, v := range []byte(req.DroneSn) {
		tempSn[i] = v
	}
	var devReq = &slinkv1.Sfl200SendHitUavRequest{
		Type:           uint8(req.Type),
		ObjId:          req.ObjId,
		DroneSn:        tempSn,
		Classification: uint32(req.Classification),
		Reserve:        0,
	}

	deviceResp, err := devicerpc.Call(req.Sn, common.DEV_SFL200, slinkv1.Sfl200SendHitDealUav, devReq)
	if err != nil {
		logger.Errorf("Sfl200DealUav rpc callV2 error: %v", err)
		return Fail, err
	}
	result, ok := deviceResp.(*slinkv1.Sfl200SendHitUavResponse)
	if !ok {
		logger.Errorf("Sfl200DealUav convert  error")
		return Fail, fmt.Errorf("Sfl200DealUav convert  error")
	}
	logger.Debugf("Sfl200DealUav response: %+v", result)
	return int32(result.Status), nil
}

// Sfl200FreqDirect 频谱目标定向
func (d *Sfl200) Sfl200FreqDirect(req *client.Sfl200FreqDirectRequest) (int32, error) {
	logger.Debug("--->Receive Freq Direct,req:", req)
	var tempSn [32]byte
	for i, v := range []byte(req.DroneSn) {
		tempSn[i] = v
	}
	var devReq = &slinkv1.Sfl200SendFreqDirectRequest{
		ProductType:        0,
		DroneName:          [25]uint8{},
		SerialNum:          tempSn,
		DroneLongitude:     int32(req.DroneLongitude * 1e7),
		DroneLatitude:      int32(req.DroneLatitude),
		DroneHeight:        int16(req.DroneHeight),
		DroneYawAngle:      int16(req.DroneYawAngle),
		DroneSpeed:         int16(req.DroneSpeed),
		DroneVerticalSpeed: int16(req.DroneVerticalSpeed),
		SpeedDirection:     uint8(req.SpeedDerection),
		DroneSailLongitude: int32(req.DroneSailLongitude),
		DroneSailLatitude:  int32(req.DroneSailLatitude),
		PilotLongitude:     int32(req.PilotLongitude),
		PilotLatitude:      int32(req.PilotLatitude),
		DroneHorizon:       int32(req.DroneHorizon),
		DronePitch:         int32(req.DronePitch),
		UFreq:              uint32(req.UFreq),
		UDistance:          uint16(req.UDistance),
		UDangerLevels:      uint16(req.UDangerLevels),
		UZC:                uint16(req.UZc),
		UDirStatus:         uint8(req.UDirStatus),
		UNumber:            uint16(req.UNumber),
		Reserve:            [48]uint8{},
	}

	deviceResp, err := devicerpc.Call(req.Sn, common.DEV_SFL200, slinkv1.Sfl200SendFreqDirect, devReq)
	if err != nil {
		logger.Errorf("Sfl200FreqDirect rpc callV2 error: %v", err)
		return Fail, err
	}
	result, ok := deviceResp.(*slinkv1.Sfl200SendFreqDirectResponse)
	if !ok {
		logger.Errorf("Sfl200FreqDirect convert  error")
		return Fail, fmt.Errorf("Sfl200FreqDirect convert  error")
	}
	logger.Debugf("Sfl200FreqDirect response: %+v", result)
	return int32(result.Status), nil
}

// Sfl200FreqDirectHit 频谱目标定向打击
func (d *Sfl200) Sfl200FreqDirectHit(req *client.Sfl200FreqDirectHitRequest) (int32, error) {
	logger.Debug("--->Receive Freq Direct Hit,req:", req)

	hitCmdDroneName := common.DeConstructDroneName(req.GetDroneName(), req.GetDroneSn())
	logger.Infof("drone Name: %v before hit cmd, drone name: %v after hit cmd", req.GetDroneName(), hitCmdDroneName)
	req.DroneName = hitCmdDroneName

	var tempSn [32]byte
	for i, v := range []byte(req.DroneSn) {
		tempSn[i] = v
	}
	var tempDroneName [25]byte
	for i, v := range []byte(req.DroneName) {
		tempDroneName[i] = v
	}
	if req.DroneHorizon == InvalidValue {
		req.DroneHorizon = InvalidValueInt32
	} else {
		req.DroneHorizon = req.DroneHorizon * DroneHorizonTion
	}
	if req.DronePitch == InvalidValue {
		req.DronePitch = InvalidValueInt32
	} else {
		req.DronePitch = req.DronePitch * DronePitch
	}
	var devReq = &slinkv1.Sfl200SendFreqDirectHitRequest{
		ProductType:        0,
		DroneName:          tempDroneName,
		SerialNum:          tempSn,
		DroneLongitude:     int32(req.DroneLongitude * DroneTion),
		DroneLatitude:      int32(req.DroneLatitude * DroneTion),
		DroneHeight:        int16(req.DroneHeight * DroneHeightTion),
		DroneYawAngle:      int16(req.DroneYawAngle * DroneYawTion),
		DroneSpeed:         int16(req.DroneSpeed * DroneSpeedTion),
		DroneVerticalSpeed: int16(req.DroneVerticalSpeed * DroneVerticalSpeedTion),
		SpeedDirection:     uint8(req.SpeedDerection * DroneSpeedTion),
		DroneSailLongitude: int32(req.DroneSailLongitude * DroneSailLongitudeTion),
		DroneSailLatitude:  int32(req.DroneSailLatitude * DroneSailLatitudeTion),
		PilotLongitude:     int32(req.PilotLongitude * DroneTion),
		PilotLatitude:      int32(req.PilotLatitude * DroneTion),
		DroneHorizon:       int32(req.DroneHorizon),
		DronePitch:         int32(req.DronePitch),
		UFreq:              uint32(req.UFreq * DetectFreqTion),
		UDistance:          uint16(req.UDistance),
		UDangerLevels:      uint16(req.UDangerLevels),
		UZC:                uint16(req.UZc),
		UDirStatus:         uint8(req.UDirStatus),
		UNumber:            uint16(req.UNumber),
		Reserve:            [48]uint8{},
	}

	deviceResp, err := devicerpc.Call(req.Sn, common.DEV_SFL200, slinkv1.Sfl200SendHitFreqDirect, devReq)
	if err != nil {
		logger.Errorf("Sfl200FreqDirectHit rpc callV2 error: %v", err)
		return Fail, err
	}
	result, ok := deviceResp.(*slinkv1.Sfl200SendFreqDirectHitResponse)
	if !ok {
		logger.Errorf("Sfl200FreqDirectHit convert  error")
		return Fail, fmt.Errorf("Sfl200FreqDirectHit convert  error")
	}
	logger.Debugf("Sfl200FreqDirectHit response: %+v", result)
	return int32(result.Status), nil
}

// Sfl200StartStopHit 开关打击
func (d *Sfl200) Sfl200StartStopHit(req *client.Sfl200StartStopHitRequest) (int32, error) {
	logger.Debug("--->Receive Start Stop Hit,req:", req)
	var devReq = &slinkv1.Sfl200SendStartStopHitRequest{
		StartStop: uint8(req.StartStopHit),
	}

	deviceResp, err := devicerpc.Call(req.Sn, common.DEV_SFL200, slinkv1.Sfl200SendManualStopOrStartHitUav, devReq)
	if err != nil {
		logger.Errorf("Sfl200StartStopHit rpc callV2 error: %v", err)
		return Fail, err
	}
	result, ok := deviceResp.(*slinkv1.Sfl200SendStartStopHitResponse)
	if !ok {
		logger.Errorf("Sfl200StartStopHit convert  error: deviceResp = %v", deviceResp)
		logger.Errorf("type error", reflect.TypeOf(deviceResp))
		return Fail, fmt.Errorf("Sfl200StartStopHit convert  error")
	}
	if req.StartStopHit == 0 {
		// 停止打击，清空map
		Sfl200FreqDirectHitMap.Clear()
	}
	logger.Debugf("Sfl200StartStopHit response: %+v", result)
	return int32(result.Status), nil
}

// Sfl200TurnSfl 转台手动控制
func (d *Sfl200) Sfl200TurnSfl(req *client.Sfl200TurnSflRequest) (int32, error) {
	logger.Debug("--->Receive Turn Sfl,req:", req)
	var devReq = &slinkv1.Sfl200SendTurnSflRequest{
		StartStop:  uint8(req.StartStop),
		HDirection: uint8(req.HDirection),
		HAngle:     req.HAngle,
		HSpeed:     uint16(req.HSpeed),
		VDirection: uint8(req.VDirection),
		VAngle:     req.VAngle,
		VSpeed:     uint16(req.VSpeed),
	}

	deviceResp, err := devicerpc.Call(req.Sn, common.DEV_SFL200, slinkv1.Sfl200SendTurnSfl, devReq)
	if err != nil {
		logger.Errorf("Sfl200TurnSfl rpc callV2 error: %v", err)
		return Fail, err
	}
	result, ok := deviceResp.(*slinkv1.Sfl200SendTurnSflResponse)
	if !ok {
		logger.Errorf("Sfl200TurnSfl convert  error")
		return Fail, fmt.Errorf("Sfl200TurnSfl convert  error")
	}
	logger.Debugf("Sfl200TurnSfl response: %+v", result)
	return int32(result.Status), nil
}

// Sfl200StartNsf4000 5.3.7　开启导航诱骗干扰
func (d *Sfl200) Sfl200StartNsf4000(req *client.Sfl200StartNsf4000Request) (int32, error) {
	logger.Debug("--->Receive Start Nsf4000,req:", req)
	var devReq = &slinkv1.Sfl200SendStartNSF4000Request{
		StartStop: uint8(req.StartStop),
		Type:      uint8(req.WorkType),
		Para1J:    req.Para1J,
		Para1W:    req.Para1W,
		Para1G:    req.Para1G,
		Para2Jd:   int16(req.Para2Jd),
		Para2Wd:   int16(req.Para2Wd),
		Para2Gd:   int16(req.Para2Gd),
		Para2Jv:   int16(req.Para2Jv),
		Para2Wv:   int16(req.Para2Wv),
		Para2Gv:   int16(req.Para2Gv),
		Para3JD:   int16(req.Para3JD),
		Para3WD:   int16(req.Para3WD),
		Para3GD:   int16(req.Para3GD),
		Para3H:    int16(req.Para3H),
		Para3V:    int16(req.Para3V),
		Para4J:    req.Para4J,
		Para4W:    req.Para4W,
		Para4G:    req.Para4G,
	}

	deviceResp, err := devicerpc.Call(req.Sn, common.DEV_SFL200, slinkv1.Sfl200StartNSF4000Work, devReq)
	if err != nil {
		logger.Errorf("Sfl200StartNsf4000 rpc callV2 error: %v", err)
		return Fail, err
	}
	result, ok := deviceResp.(*slinkv1.Sfl200SendStartNSF4000Response)
	if !ok {
		logger.Errorf("Sfl200StartNsf4000 convert  error")
		return Fail, fmt.Errorf("Sfl200StartNsf4000 convert  error")
	}
	logger.Debugf("Sfl200StartNsf4000 response: %+v", result)
	return int32(result.Status), nil
}

// Sfl200SystemWorkSetting 系统工作参数配置
func (d *Sfl200) Sfl200SystemWorkSetting(req *client.Sfl200SystemWorkSettingRequest) (int32, error) {
	logger.Debug("--->Receive System Work Setting,req:", req)
	var devReq = &slinkv1.Sfl200SendSystemWorkModeSetRequest{
		SysGBIMode:  uint8(req.SysGBIMode),
		SysGBJd:     req.SysGBJd,
		SysGBWd:     req.SysGBWd,
		SysGBGd:     req.SysGBGd,
		SysGBJTime1: uint16(req.SysGBJTime1),
		SysGBJTime2: uint16(req.SysGBJTime2),
		SysGBJTime3: uint16(req.SysGBJTime3),
		SysGBJMode:  uint8(req.SysGBJMode),
		SysGBJF0:    uint8(req.SysGBJF0),
		SysGBJF1:    uint8(req.SysGBJF1),
		SysGBJF2:    uint8(req.SysGBJF2),
		SysGBJF3:    uint8(req.SysGBJF3),
		SysGBJF4:    uint8(req.SysGBJF4),
		SysGBJF5:    uint8(req.SysGBJF5),
		SysGBJF6:    uint8(req.SysGBJF6),
		SysGBJF7:    0,
		SysGBJF8:    0,
		SysGBJF9:    0,
		SysGBJFpv1:  uint16(req.SysGBJFPV1),
		SysGBJFpv2:  uint16(req.SysGBJFPV2),
	}

	deviceResp, err := devicerpc.Call(req.Sn, common.DEV_SFL200, slinkv1.Sfl200SendSystemWorkModeSetting, devReq)
	if err != nil {
		logger.Errorf("Sfl200SystemWorkSetting rpc callV2 error: %v", err)
		return Fail, err
	}
	result, ok := deviceResp.(*slinkv1.Sfl200SendSystemWorkModeSetResponse)
	if !ok {
		logger.Errorf("Sfl200SystemWorkSetting convert  error")
		return Fail, fmt.Errorf("Sfl200SystemWorkSetting convert  error")
	}
	logger.Debugf("Sfl200SystemWorkSetting response: %+v", result)
	return int32(result.Status), nil
}

// Sfl200SystemWorkGet 系统工作参数获取
func (d *Sfl200) Sfl200SystemWorkGet(req *client.Sfl200SystemWorkGetRequest) (*slinkv1.Sfl200SendSystemWorkModeGetResponse, error) {
	logger.Debug("--->Receive System Work Get,req:", req)
	var devReq = &slinkv1.Sfl200SendSystemWorkModeGetRequest{}

	deviceResp, err := devicerpc.Call(req.Sn, common.DEV_SFL200, slinkv1.Sfl200SendSystemWorkModeGet, devReq)
	if err != nil {
		logger.Errorf("Sfl200SystemWorkGet rpc callV2 error: %v", err)
		return nil, err
	}
	result, ok := deviceResp.(*slinkv1.Sfl200SendSystemWorkModeGetResponse)
	if !ok {
		logger.Errorf("Sfl200SystemWorkGet convert  error")
		return nil, fmt.Errorf("Sfl200SystemWorkGet convert  error")
	}
	logger.Debugf("Sfl200SystemWorkGet response: %+v", result)
	return result, nil
}

// Sfl200GetVersionInfo 获取版本信息
func (d *Sfl200) Sfl200GetVersionInfo(req *client.Sfl200GetVersionRequest) (*slinkv1.Sfl200GetVersionResponse, error) {
	logger.Debug("--->Receive System version,req:", req)
	var devReq = &slinkv1.Sfl200GetVersionRequest{}

	deviceResp, err := devicerpc.Call(req.Sn, common.DEV_SFL200, slinkv1.Sfl200GetVersion, devReq)
	if err != nil {
		logger.Errorf("Sfl200GetVersionInfo rpc callV2 error: %v", err)
		return nil, err
	}
	result, ok := deviceResp.(*slinkv1.Sfl200GetVersionResponse)
	if !ok {
		logger.Errorf("Sfl200GetVersionInfo convert  error")
		return nil, fmt.Errorf("Sfl200GetVersionInfo convert  error")
	}
	logger.Debugf("Sfl200GetVersionInfo response: %+v", result)
	return result, nil
}

// Sfl200SendDevWhiteList 白名单给给设备
func Sfl200SendDevWhiteList() {
	deviceInfo := &client.EquipListRes{}
	err := NewEquipList().List(context.Background(), &client.EquipListReq{}, deviceInfo)
	if err != nil {
		logger.Error("Get EquipList err: ", err)
	}
	//查白名单中的无人机，在Tracer侦测结果中添加无人机角色
	whiteList := &client.ListResAll{}
	err = NewWhiteList().ListAll(context.Background(), &client.ListReqAll{}, whiteList)
	if err != nil {
		logger.Error("Get whiteList err: ", err)
		return
	}
	logger.Info("Get EquipList is : ", whiteList.WhiteList)
	snList := make([]slinkv1.Sfl200WhiteInfo, 0)

	for _, all := range whiteList.WhiteList {
		if all.Role == FRIEND {
			var tempSn [32]byte
			copy(tempSn[:], all.Sn)
			snList = append(snList, slinkv1.Sfl200WhiteInfo{Serial: tempSn})
		}
	}
	for _, equip := range deviceInfo.Equips {
		if equip.Etype == "Sfl200" {
			sflInfo := FindCacheDevice(equip.Sn, common.DEV_SFL200)
			if sflInfo == nil {
				continue
			} else {
				dev := &Sfl200{Device: sflInfo}
				dev.SendSfl200SetWhite(sflInfo.Sn, snList)
			}

		}
	}

}

// SendSfl200SetWhite 系统工作参数获取
func (d *Sfl200) SendSfl200SetWhite(sfl200Sn string, snList []slinkv1.Sfl200WhiteInfo) {
	logger.Debug("--->Receive Set White,req:", snList)
	var devReq = &slinkv1.Sfl200SendSetWhiteRequest{
		ToTalNum:  uint16(len(snList)),
		WhiteList: snList,
	}
	deviceResp, err := devicerpc.Call(sfl200Sn, common.DEV_SFL200, slinkv1.Sfl200SendWhiteSet, devReq)
	if err != nil {
		logger.Errorf("SendSfl200SetWhite rpc callV2 error: %v", err)
		return
	}
	result, ok := deviceResp.(*slinkv1.Sfl200SendSetWhiteResponse)
	if !ok {
		logger.Errorf("SendSfl200SetWhite convert  error")
		return
	}
	logger.Debugf("SendSfl200SetWhite response: %+v", result)
	return
}

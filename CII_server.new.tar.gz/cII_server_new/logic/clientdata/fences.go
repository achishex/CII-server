package clientdata

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	jsoniter "github.com/json-iterator/go"
	"go-micro.dev/v4/broker"
	"google.golang.org/protobuf/proto"

	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/rpc/webclient"
)

func reportSyncFences(event broker.Event) error {
	box := &client.ClientReport{}
	err := jsoniter.Unmarshal(event.Message().Body, box)
	if err != nil {
		logger.Error("fences sync data box unmarshal error: ", err)
		return err
	}
	buData := &client.FencesSyncInfo{
		Header: &client.EquipmentMessageBoxEntity{
			MsgType: box.MsgType,
		},
		Data: make([]*client.Fence, 0),
	}
	if err = jsoniter.Unmarshal(box.Data, &buData.Data); err != nil {
		logger.Errorf("fences sync data unmarshal error: %v")
		return err
	}
	logger.Debugf("fences sync data %+v", buData)
	buBuff, err := proto.Marshal(buData)
	if err != nil {
		logger.Errorf("Marshal FencesSyncInfo err %v", err)
		return err
	}
	out := &client.ClientReport{
		MsgType: common.ClientMsgFencesSyncData,
		Data:    buBuff,
	}
	data, err := proto.Marshal(out)
	if err != nil {
		logger.Errorf("ClientReport Marshal err %v", err)
		return err
	}
	if err := webclient.ClientMgrInstance().SendData(data); err != nil {
		logger.Errorf("topic %s SendData err %v", event.Topic(), err)
		return err
	}
	logger.Infof("topic %s SendData success", event.Topic())
	return nil
}

package clientdata

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"go-micro.dev/v4/broker"

	"adasgitlab.autel.com/tools/cuav_server/rpc/webclient"
)

// reportDPH110Msg 上报DPH110数据
func reportDPH110Msg(event broker.Event) error {
	if err := webclient.ClientMgrInstance().SendData(event.Message().Body); err != nil {
		logger.Errorf("topic %s SendData err %v", event.Topic(), err)
		return err
	}
	logger.Debugf("topic %s SendData success", event.Topic())
	return nil
}

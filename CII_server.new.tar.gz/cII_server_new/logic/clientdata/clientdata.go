package clientdata

import (
	"errors"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	jsoniter "github.com/json-iterator/go"
	"go-micro.dev/v4/broker"
	"google.golang.org/protobuf/proto"

	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/helper"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/proto/mavlink"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
	"adasgitlab.autel.com/tools/cuav_server/rpc/webclient"
)

var blockTrace = make(map[string]interface{})

// TranseData 传输数据
func TranseData() error {
	go func() {
		for {
			time.Sleep(5 * time.Second)
			for k, v := range blockTrace {
				logger.Warnf("blockTrace TranseData: %s, %v", k, v)
			}
		}
	}()
	brokers := map[string]*broker.Broker{
		mq.EquipmentStatusTopic:   &mq.EquipmentStatusBroker,
		mq.EquipMessageBoxTopic:   &mq.EquipMessageBoxBroker,
		mq.RadarTrackTopic:        &mq.RadarTrackBroker,
		mq.TracerDetectTopic:      &mq.TracerDetectBroker,
		mq.RadarPostureTopic:      &mq.RadarPostureBroker,
		mq.RadarBeamConfigTopic:   &mq.RadarBeamConfigBroker,
		mq.V2DroneIdTopic:         &mq.V2DroneIdBroker,
		mq.NSF4000Topic:           &mq.NSF4000Broker,
		mq.NSF4000TopicLLH:        &mq.NSF4000BrokerLLH,
		mq.GunHeartTopic:          &mq.GunHeartBroker,
		mq.GunDroneIdTopic:        &mq.GunDroneIdBroker,
		mq.RFURD360StatusTopic:    &mq.RFURDBroker,
		mq.RFURD360SpecturmTopic:  &mq.RFURDBroker,
		mq.RFURD360DroneInfoTopic: &mq.RFURDBroker,
		mq.SflTopic:               &mq.SflMsgBroker,
		mq.Sfl101Topic:            &mq.Sfl101MsgBroker,
		mq.SvhTopic:               &mq.SvhMsgBroker,
		mq.FpvTopic:               &mq.FpvMsgBroker,
		mq.AgxTopic:               &mq.AgxMsgBroker,
		mq.Sfl200Topic:            &mq.Sfl200MsgBroker,
		mq.GunsPlatformTopic:      &mq.GunsPlatformMsgBroker,
		mq.ReplayTransMsgTopic:    &mq.DataReplayMix,
		mq.SystemHeartTopic:       &mq.SystemHeartBroker,
		mq.FpvStopCmdTopic:        &mq.FpvVideoStopCmdBroker,
		mq.MiniGunStatusTopic:     &mq.MiniGunStatusReportBroker,
		mq.MiniGunHitTopic:        &mq.MiniGunHitReportBroker,
		mq.FencesSyncTopic:        &mq.FencesSyncBroker,
		mq.TracerLogExportTopic:   &mq.TracerLogExportBroker,
		mq.DPH110Topic:            &mq.DPH110Broker,
		mq.Sbp100Topic:            &mq.Sbp100Broker,
		mq.TracerGunTopic:         &mq.TracerGunBroker,
		mq.STP120Topic:            &mq.STP120Broker,
	}
	consumes := map[string]func(event broker.Event) error{
		mq.EquipmentStatusTopic:   reportDevStatus,
		mq.EquipMessageBoxTopic:   reportMsgBox,
		mq.RadarTrackTopic:        reportRadarTrack,
		mq.TracerDetectTopic:      reportTracerDetect,
		mq.RadarPostureTopic:      reportRadarPosture,
		mq.RadarBeamConfigTopic:   consumeMsg,
		mq.V2DroneIdTopic:         reportDroneIDStatus,
		mq.NSF4000Topic:           reportSpooferStatus,
		mq.NSF4000TopicLLH:        reportSpooferStatus,
		mq.GunHeartTopic:          consumeMsg,
		mq.GunDroneIdTopic:        consumeMsg,
		mq.RFURD360StatusTopic:    reportRFURD360Status,
		mq.RFURD360SpecturmTopic:  reportRFURD360Specturm,
		mq.RFURD360DroneInfoTopic: reportRFURD360DroneInfo,
		mq.SflTopic:               reportSflMsg,
		mq.Sfl101Topic:            reportSfl101Msg,
		mq.SvhTopic:               reportSvhMsg,
		mq.FpvTopic:               reportFpvMsg,
		mq.AgxTopic:               reportAgxMsg,
		mq.Sfl200Topic:            reportSfl200Msg,
		mq.GunsPlatformTopic:      reportGunsPlatformMsg,
		mq.ReplayTransMsgTopic:    reportReplayTranData,
		mq.SystemHeartTopic:       reportSystemHeart,
		mq.FpvStopCmdTopic:        reportFpvStopCmd,
		mq.MiniGunStatusTopic:     consumeMsg,
		mq.MiniGunHitTopic:        consumeMsg,
		mq.FencesSyncTopic:        reportSyncFences,
		mq.TracerLogExportTopic:   reportTracerLog,
		mq.DPH110Topic:            reportDPH110Msg,
		mq.Sbp100Topic:            reportSbp100Msg,
		mq.TracerGunTopic:         reportTracerGunMsg,
		mq.STP120Topic:            reportSTP120Msg,
	}
	for name, mq := range brokers {
		handler, ok := consumes[name]
		if !ok {
			logger.Errorf("broker name %s have no handler", name)
			continue
		}
		_, err := (*mq).Subscribe(name, func(event broker.Event) error {
			now := time.Now()
			finish := now
			ch := make(chan struct{})
			go func() {
				time.Sleep(5 * time.Second)
				<-ch
			}()
			go func() {
				ch <- struct{}{}
				close(ch)
				duration := finish.Sub(now)
				if duration > 10*time.Second {
					blockTrace[event.Topic()] = duration.Seconds()
				}
			}()
			err := handler(event)
			finish = time.Now()
			<-ch
			return err
		})
		if err != nil {
			logger.Errorf("broker name %s Subscribe err %v", name, err)
		}
	}
	return nil
}

// reportMsgBox ...
func reportMsgBox(event broker.Event) error {
	box := &common.EquipmentMessageBoxEntity{}
	err := jsoniter.Unmarshal(event.Message().Body, box)
	if err != nil {
		logger.Error("radar posture c box unmarshal error: ", err)
		return err
	}
	d, err := jsoniter.Marshal(box.Info)
	if err != nil {
		logger.Error("radar posture c remarshal error: ", err)
		return err
	}
	head := &client.EquipmentMessageBoxEntity{
		Sn:           box.Sn,
		Name:         box.Name,
		EquipType:    int32(box.EquipType),
		MsgType:      GetClientMsgID(common.DeviceType(box.EquipType), int32(box.MsgType)),
		ParentType:   int32(box.ParentType),
		ParentSn:     box.ParentSn,
		IsIntegrated: box.IsIntegrated,
	}
	routes := map[int32]func(head *client.EquipmentMessageBoxEntity, in []byte) ([]byte, error){
		handler.WsOtaPkgDownloadStatus:          convertOTAStatus,
		handler.WsDeviceUpdateStatus:            convertUpgradeStatus,
		mavlink.RadarIdPostureCalibrationResult: convertRadarPosture,
		mavlink.SendHitResult:                   convertHitResult,
		mavlink.ScreenHitResult:                 convertScreenHitResult,
		msgIDHistoryWifiConn:                    converRadarConn,
	}
	route, ok := routes[int32(box.MsgType)]
	if !ok {
		logger.Errorf("MsgType %d not support")
		return errors.New("MsgType not support")
	}
	data, err := route(head, d)
	if err != nil {
		logger.Errorf("convert data err %v", err)
		return err
	}
	if err := webclient.ClientMgrInstance().SendData(data); err != nil {
		logger.Errorf("topic %s SendData err %v", event.Topic(), err)
		return err
	}
	return nil
}

// reportDevStatus ...
func reportDevStatus(event broker.Event) error {
	box := &common.EquipmentMessageBoxEntity{}
	err := jsoniter.Unmarshal(event.Message().Body, box)
	if err != nil {
		logger.Error("radar status box unmarshal error: ", err)
		return err
	}
	d, err := jsoniter.Marshal(box.Info)
	if err != nil {
		logger.Error("radar status remarshal error: ", err)
		return err
	}
	status := &common.RadarStatusEntity{}
	err = jsoniter.Unmarshal(d, status)
	if err != nil {
		logger.Error("radar status unmarshal error: ", err)
		return err
	}
	isOnline := helper.TranBaseType[int32, int](status.IsOnline)
	dataInfo := &client.RadarStatusInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:         box.Name,
			Sn:           box.Sn,
			EquipType:    int32(box.EquipType),
			MsgType:      GetClientMsgID(common.DeviceType(box.EquipType), int32(box.MsgType)),
			ParentSn:     box.ParentSn,
			ParentType:   int32(box.ParentType),
			IsIntegrated: box.IsIntegrated,
		},
		Data: &client.RadarStatusEntity{
			Electricity: status.Electricity,
			Status:      int32(status.Status),
			IsOnline:    &isOnline,
			Ip:          status.Ip,
			SerialNum:   status.SerialNum,
			Faults:      status.Faults,
			SysStatus:   status.SysStatus,
			VersionType: status.VersionType,
		},
	}
	buData, err := proto.Marshal(dataInfo)
	if err != nil {
		logger.Error("RadarStatusInfo Marshal err %v", err)
		return err
	}
	out := &client.ClientReport{
		MsgType: GetClientMsgID(common.DeviceType(box.EquipType), int32(box.MsgType)),
		Data:    buData,
	}
	data, err := proto.Marshal(out)
	if err != nil {
		logger.Errorf("ClientReport Marshal err %v", err)
		return err
	}
	if err := webclient.ClientMgrInstance().SendQueue(data); err != nil {
		logger.Errorf("topic %s SendData err %v", event.Topic(), err)
		return err
	}
	logger.Debugf("radar state has reported, devInfo: %v", dataInfo)
	return nil
}

// consumeMsg ...
func consumeMsg(event broker.Event) error {
	logger.Debugf("topic %s SendData ", event.Topic())
	if err := webclient.ClientMgrInstance().SendData(event.Message().Body); err != nil {
		logger.Errorf("topic %s SendData err %v", event.Topic(), err)
		return err
	}
	return nil
}

// convertOTAStatus ...
func convertOTAStatus(head *client.EquipmentMessageBoxEntity, in []byte) ([]byte, error) {
	status := &handler.OtaFileDownloadStatus{}
	err := jsoniter.Unmarshal(in, status)
	if err != nil {
		logger.Error("download unmarshal error: ", err)
		return nil, err
	}
	otaData := client.OtaFileDownloadStatusInfo{
		Header: head,
		Data: &client.OtaFileDownloadStatus{
			Status:               int32(status.Status),
			DownloadedPercentage: int32(status.DownloadedPercentage),
			FileName:             status.FileName,
			ErrMsg:               status.ErrMsg,
			FallPath:             status.FallPath,
			Speed:                status.Speed,
			FileSize:             status.FileSize,
		},
	}
	buData, err := proto.Marshal(&otaData)
	if err != nil {
		logger.Errorf("Marshal OtaFileDownloadStatusInfo err %v", err)
		return nil, err
	}
	out := &client.ClientReport{
		MsgType: head.MsgType,
		Data:    buData,
	}
	data, err := proto.Marshal(out)
	if err != nil {
		logger.Errorf("ClientReport Marshal err %v", err)
		return nil, err
	}
	return data, nil
}

// convertUpgradeStatus ...
func convertUpgradeStatus(head *client.EquipmentMessageBoxEntity, in []byte) ([]byte, error) {
	status := &handler.UpgradeStatus{}
	err := jsoniter.Unmarshal(in, status)
	if err != nil {
		logger.Error("upgrade unmarshal error: ", err)
		return nil, err
	}
	buData, err := proto.Marshal(&client.UpgradeStatusInfo{
		Header: head,
		Data: &client.UpgradeStatus{
			Sn:          status.Sn,
			DeviceType:  status.DeviceType,
			Status:      status.Status,
			Permil:      status.Permil,
			PkgPathName: status.PkgPathName,
			ErrMsg:      status.ErrMsg,
		},
	})
	if err != nil {
		logger.Errorf("Marshal UpgradeStatusInfo err %v", err)
		return nil, err
	}
	out := &client.ClientReport{
		MsgType: head.MsgType,
		Data:    buData,
	}
	data, err := proto.Marshal(out)
	if err != nil {
		logger.Errorf("ClientReport Marshal err %v", err)
		return nil, err
	}
	return data, nil
}

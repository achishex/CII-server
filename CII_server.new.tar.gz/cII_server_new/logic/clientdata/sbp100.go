package clientdata

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"go-micro.dev/v4/broker"

	"adasgitlab.autel.com/tools/cuav_server/rpc/webclient"
)

func reportSbp100Msg(event broker.Event) error {
	if err := webclient.ClientMgrInstance().SendData(event.Message().Body); err != nil {
		logger.Errorf("topic %s SendData err %v", event.Topic(), err)
		return err
	}
	return nil
}

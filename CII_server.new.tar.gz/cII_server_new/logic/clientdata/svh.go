package clientdata

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/rpc/webclient"
	"go-micro.dev/v4/broker"
)

func reportSvhMsg(event broker.Event) error {
	if err := webclient.ClientMgrInstance().SendData(event.Message().Body); err != nil {
		logger.Errorf("topic %s SendData err %v", event.Topic(), err)
		return err
	}
	return nil
}

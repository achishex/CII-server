package clientdata

import (
	"errors"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	jsoniter "github.com/json-iterator/go"
	"go-micro.dev/v4/broker"
	"google.golang.org/protobuf/proto"

	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"adasgitlab.autel.com/tools/cuav_server/proto/mavlink"
	"adasgitlab.autel.com/tools/cuav_server/rpc/webclient"
)

// reportDroneIDStatus ...
func reportDroneIDStatus(event broker.Event) error {
	box := &common.EquipmentMessageBoxEntity{}
	err := jsoniter.Unmarshal(event.Message().Body, box)
	if err != nil {
		logger.Error("radar tracer box unmarshal error: ", err)
		return err
	}
	d, err := jsoniter.Marshal(box.Info)
	if err != nil {
		logger.Error("radar tracer remarshal error: ", err)
		return err
	}
	report := &mavlink.DroneIDReport{}
	err = jsoniter.Unmarshal(d, report)
	if err != nil {
		logger.Error("radar tracer unmarshal error: ", err)
		return err
	}
	buData, err := proto.Marshal(&client.DroneStatusInfo{
		Header: &client.EquipmentMessageBoxEntity{
			Name:         box.Name,
			Sn:           box.Sn,
			EquipType:    int32(box.EquipType),
			MsgType:      GetClientMsgID(common.DeviceType(box.EquipType), int32(box.MsgType)),
			ParentSn:     box.ParentSn,
			ParentType:   int32(box.ParentType),
			IsIntegrated: box.IsIntegrated,
		},
		Data: &client.DroneIDReport{
			TimeStamp:     report.TimeStamp,
			Electricity:   uint32(report.Electricity),
			Sn:            report.Sn,
			IsOnline:      int32(report.IsOnline),
			BatteryStatus: int32(report.BatteryStatus),
			WorkMode:      int32(report.WorkMode),
			WorkStatus:    int32(report.WorkStatus),
			Fault:         int32(report.Fault),
			AlarmLevel:    int32(report.AlarmLevel),
			BuzzerOn:      int32(report.BuzzerOn),
			VibrationOn:   int32(report.VibrationOn),
			StealthModeOn: int32(report.StealthModeOn),
			TracerType:    int32(report.TracerType),
		},
	})
	if err != nil {
		logger.Errorf("Marshal DroneStatusInfo err %v", err)
		return err
	}
	out := &client.ClientReport{
		MsgType: GetClientMsgID(common.DeviceType(box.EquipType), int32(box.MsgType)),
		Data:    buData,
	}
	data, err := proto.Marshal(out)
	if err != nil {
		logger.Errorf("ClientReport Marshal err %v", err)
		return err
	}
	if err := webclient.ClientMgrInstance().SendData(data); err != nil {
		logger.Errorf("topic %s SendData err %v", event.Topic(), err)
		return err
	}
	return nil
}

// reportTracerDetect ...
func reportTracerDetect(event broker.Event) error {
	box := &common.EquipmentMessageBoxEntity{}
	err := jsoniter.Unmarshal(event.Message().Body, box)
	if err != nil {
		logger.Error("Tracer Detect box unmarshal error: ", err)
		return err
	}
	d, err := jsoniter.Marshal(box.Info)
	if err != nil {
		logger.Error("Tracer Detect remarshal error: ", err)
		return err
	}
	head := &client.EquipmentMessageBoxEntity{
		Name:         box.Name,
		Sn:           box.Sn,
		EquipType:    int32(box.EquipType),
		MsgType:      GetClientMsgID(common.DeviceType(box.EquipType), int32(box.MsgType)),
		ParentSn:     box.ParentSn,
		ParentType:   int32(box.ParentType),
		IsIntegrated: box.IsIntegrated,
	}
	routes := map[int32]func(head *client.EquipmentMessageBoxEntity, in []byte) ([]byte, error){
		mavlink.TracerIdGetDetectRes:               convertTracerDetect,
		mavlink.TracerIdGetRemoteIdDetectRes:       convertRemoteDetect,
		mavlink.TracerIdGetFreqDetectRes:           convertFreqDetect,
		mavlink.TracerIdGetFreqDataRes:             convertFreqData,
		mavlink.TracerIdGetNoiseFloorDataRes:       convertNoiseFloorData,
		mavlink.TracerIdGetDronIdRemoteIdDetectRes: convertTracerDroneIdRemoteIdDetect,
		mavlink.TracerSGetNoiseBaseDataRes:         convertNoiseBaseFreqData,
	}
	route, ok := routes[int32(box.MsgType)]
	if !ok {
		logger.Errorf("MsgType %d not support")
		return errors.New("MsgType not support")
	}
	data, err := route(head, d)
	if err != nil {
		logger.Errorf("convert data err %v", err)
		return err
	}
	if err := webclient.ClientMgrInstance().SendData(data); err != nil {
		logger.Errorf("topic %s SendData err %v", event.Topic(), err)
		return err
	}
	return nil
}

// convertTracerDetect ...
func convertTracerDetect(head *client.EquipmentMessageBoxEntity, in []byte) ([]byte, error) {
	report := &mavlink.TracerDetectReport{}
	err := jsoniter.Unmarshal(in, report)
	if err != nil {
		logger.Error("TracerDetectReport unmarshal error: ", err)
		return nil, err
	}
	buData := &client.TracerDetectInfo{
		Header: head,
		Data: &client.TracerDetectReport{
			Sn:   head.Sn,
			Info: make([]*client.TracerDetectDescription, 0),
		},
	}
	for _, desc := range report.Description {
		buData.Data.Info = append(buData.Data.Info, &client.TracerDetectDescription{
			ProductType:        int32(desc.ProductType),
			DroneName:          desc.DroneName,
			SerialNum:          desc.SerialNum,
			DroneLongitude:     desc.DroneLongitude,
			DroneLatitude:      desc.DroneLatitude,
			DroneHeight:        desc.DroneHeight,
			DroneYawAngle:      desc.DroneYawAngle,
			DroneSpeed:         desc.DroneSpeed,
			DroneVerticalSpeed: desc.DroneVerticalSpeed,
			OperatorLongitude:  desc.OperatorLongitude,
			OperatorLatitude:   desc.OperatorLatitude,
			Freq:               desc.Freq,
			Distance:           int32(desc.Distance),
			DangerLevels:       int32(desc.DangerLevels),
			Role:               desc.Role,
			AlarmId:            desc.AlarmId,
			EventId:            desc.EventId,
			ScenesId:           desc.ScenesId,
			ThreatLevel:        desc.ThreatLevel,
		})
	}
	buBuff, err := proto.Marshal(buData)
	if err != nil {
		logger.Errorf("Marshal TracerDetectInfo err %v", err)
		return nil, err
	}
	out := &client.ClientReport{
		MsgType: head.MsgType,
		Data:    buBuff,
	}
	data, err := proto.Marshal(out)
	if err != nil {
		logger.Errorf("ClientReport Marshal err %v", err)
		return nil, err
	}
	return data, nil
}

// convertTracerDetect ...
func convertTracerDroneIdRemoteIdDetect(head *client.EquipmentMessageBoxEntity, in []byte) ([]byte, error) {
	report := &mavlink.TracerDronIdRemoteIdDetectReport{}
	err := jsoniter.Unmarshal(in, report)
	if err != nil {
		logger.Error("TracerDetectReport unmarshal error: ", err)
		return nil, err
	}
	buData := &client.TracerDroneIdRemoteIdDetectInfo{
		Header: head,
		Data: &client.TracerDroneIdRemoteIdDetectReport{
			Sn:                 head.Sn,
			BusinessDeviceType: report.BusinessDeviceType,
			Info:               make([]*client.TracerDroneIdRemoteIdDetectDescription, 0),
		},
	}
	for _, drone := range report.Description {
		buData.Data.Info = append(buData.Data.Info, &client.TracerDroneIdRemoteIdDetectDescription{
			Name:      drone.Name,
			SerialNum: drone.SerialNum,
			// Uuid:           drone.Uuid,
			Direction:      drone.Direction,
			Speed:          drone.Speed,
			VerticalSpeed:  drone.VerticalSpeed,
			Height:         drone.Height,
			Longitude:      drone.Longitude,
			Latitude:       drone.Latitude,
			PilotLongitude: drone.PilotLongitude,
			PilotLatitude:  drone.PilotLatitude,
			HomeLongitude:  drone.HomeLongitude,
			HomeLatitude:   drone.HomeLatitude,
			// RecordTime:                drone.RecordTime,
			AliveTime:            drone.AliveTime,
			TargetMask:           uint32(drone.TargetMask),
			TypeCodeRid:          uint32(drone.TypeCodeRid),
			SeqNumRid:            uint32(drone.SeqNumRid),
			ClassificationType:   uint32(drone.ClassificationType),
			OperationStatus:      uint32(drone.OperationStatus),
			OperatorLocationType: uint32(drone.OperatorLocationType),
			HeightType:           uint32(drone.HeightType),
			SignalFreqRid:        int32(drone.SignalFreqRid),
			SignalPowerRid:       uint32(drone.SignalPowerRid),
			TimestampRid:         drone.TimestampRid,
			ReserveRid:           drone.ReserveRid,
			TypeCodeDid:          uint32(drone.TypeCodeDid),
			SeqNumDid:            uint32(drone.SeqNumDid),
			Altitude:             drone.Altitude,
			SpeedX:               drone.SpeedX,
			SpeedY:               drone.SpeedY,
			SignalFreqDid:        drone.SignalFreqDid,
			SignalPowerDidCh1:    int32(drone.SignalPowerDidCh1),
			SignalPowerDidCh2:    int32(drone.SignalPowerDidCh2),
			GpsClock:             drone.GpsClock,
			ReserveDid:           drone.ReserveDid,
			Role:                 drone.Role,
			AlarmId:              drone.AlarmId,
			EventId:              drone.EventId,
			ThreatLevel:          drone.ThreatLevel,
			ScenesId:             drone.ScenesId,
		})
	}
	buBuff, err := proto.Marshal(buData)
	if err != nil {
		logger.Errorf("Marshal TracerDetectInfo err %v", err)
		return nil, err
	}
	out := &client.ClientReport{
		MsgType: head.MsgType,
		Data:    buBuff,
	}
	data, err := proto.Marshal(out)
	if err != nil {
		logger.Errorf("ClientReport Marshal err %v", err)
		return nil, err
	}
	return data, nil
}

// convertRemoteDetect ...
func convertRemoteDetect(head *client.EquipmentMessageBoxEntity, in []byte) ([]byte, error) {
	report := &mavlink.TracerRemoteDetectReport{}
	err := jsoniter.Unmarshal(in, report)
	if err != nil {
		logger.Error("TracerRemoteDetectReport unmarshal error: ", err)
		return nil, err
	}
	buData := &client.TracerRemoteDetectInfo{
		Header: head,
		Data: &client.TracerRemoteDetectReport{
			Sn:   head.Sn,
			Info: make([]*client.TracerRemoteDetectDescription, 0),
		},
	}
	for _, desc := range report.Description {
		buData.Data.Info = append(buData.Data.Info, &client.TracerRemoteDetectDescription{
			ProductType:         int32(desc.ProductType),
			DroneName:           desc.DroneName,
			SerialNum:           desc.SerialNum,
			DroneLongitude:      desc.DroneLongitude,
			DroneLatitude:       desc.DroneLatitude,
			DroneHeight:         desc.DroneHeight,
			DroneDirection:      desc.DroneDirection,
			DroneYawAngle:       desc.DroneYawAngle,
			DroneSpeed:          desc.DroneSpeed,
			DroneSpeedderection: int32(desc.DroneSpeedderection),
			DroneVerticalSpeed:  desc.DroneVerticalSpeed,
			OperatorLongitude:   desc.OperatorLongitude,
			OperatorLatitude:    desc.OperatorLatitude,
			Freq:                desc.Freq,
			Distance:            int32(desc.Distance),
			DangerLevels:        int32(desc.DangerLevels),
			Role:                desc.Role,
			AlarmId:             desc.AlarmId,
			EventId:             desc.EventId,
			ScenesId:            desc.ScenesId,
			ThreatLevel:         desc.ThreatLevel,
		})
	}
	buBuff, err := proto.Marshal(buData)
	if err != nil {
		logger.Errorf("MarshaMarshallFrom TracerRemoteDetectInfo err %v", err)
		return nil, err
	}
	out := &client.ClientReport{
		MsgType: head.MsgType,
		Data:    buBuff,
	}
	data, err := proto.Marshal(out)
	if err != nil {
		logger.Errorf("ClientReport Marshal err %v", err)
		return nil, err
	}
	return data, nil
}

// convertFreqDetect ...
func convertFreqDetect(head *client.EquipmentMessageBoxEntity, in []byte) ([]byte, error) {
	report := &mavlink.TracerFreqDetectReport{}
	err := jsoniter.Unmarshal(in, report)
	if err != nil {
		logger.Error("TracerFreqDetectReport unmarshal error: ", err)
		return nil, err
	}
	buData := &client.TracerFreqDetectInfo{
		Header: head,
		Data: &client.TracerFreqDetectReport{
			Sn:                 head.Sn,
			QxPower:            report.QxPower,
			DxPower:            report.DxPower,
			DxHorizon:          report.DxHorizon,
			StartAngle:         report.StartAngle,
			EndAngle:           report.EndAngle,
			OrientStatus:       int32(report.OrientStatus),
			BusinessDeviceType: int32(report.BusiDeviceType),
			Info:               make([]*client.TracerFreqDetectDescription, 0),
		},
	}

	for _, desc := range report.Description {
		buData.Data.Info = append(buData.Data.Info, &client.TracerFreqDetectDescription{
			UavNumber:     int32(desc.UavNumber),
			DroneName:     desc.DroneName,
			DroneHorizon:  desc.DroneHorizon,
			UFreq:         desc.UFreq,
			UDangerLevels: int32(desc.UDangerLevels),
			UMoving:       desc.UMoving,
			Dist:          desc.Dist,
			Recerve:       desc.Recerve,
			IsSptOrient:   int32(desc.IsSptOrient),
			OrientState:   int32(desc.OrientState),
			AmpMean:       desc.AmpMean,
			WifiMac:       desc.WifiMac,
		})
	}
	buBuff, err := proto.Marshal(buData)
	if err != nil {
		logger.Errorf("Marshal TracerFreqDetectInfo err %v", err)
		return nil, err
	}
	out := &client.ClientReport{
		MsgType: head.MsgType,
		Data:    buBuff,
	}
	data, err := proto.Marshal(out)
	if err != nil {
		logger.Errorf("ClientReport Marshal err %v", err)
		return nil, err
	}
	return data, nil
}

// convertFreqData ...
func convertFreqData(head *client.EquipmentMessageBoxEntity, in []byte) ([]byte, error) {
	report := &client.TracerSFreqDataReport{}
	err := jsoniter.Unmarshal(in, report)
	if err != nil {
		logger.Error("TracerFreqDetectReport unmarshal error: ", err)
		return nil, err
	}
	buData := &client.TracerFreqDataInfo{
		Header: head,
		Data: &client.TracerSFreqDataReport{
			Sn:   head.Sn,
			Info: make([]*client.TracerSFreqDataDescription, 0),
		},
	}
	for _, desc := range report.Info {
		buData.Data.Info = append(buData.Data.Info, &client.TracerSFreqDataDescription{
			AmpValue: desc.AmpValue,
		})
	}
	buBuff, err := proto.Marshal(buData)
	if err != nil {
		logger.Errorf("Marshal TracerSFreqDataReport err %v", err)
		return nil, err
	}
	out := &client.ClientReport{
		MsgType: head.MsgType,
		Data:    buBuff,
	}
	data, err := proto.Marshal(out)
	if err != nil {
		logger.Errorf("ClientReport Marshal err %v", err)
		return nil, err
	}
	return data, nil
}

// convertNoiseFloorData ...
func convertNoiseFloorData(head *client.EquipmentMessageBoxEntity, in []byte) ([]byte, error) {
	report := &client.TracerNoiseFloorDataReport{}
	err := jsoniter.Unmarshal(in, report)
	if err != nil {
		logger.Error("TracerNoiseFloorDetectReport unmarshal error: ", err)
		return nil, err
	}
	buData := &client.TracerNoiseFloorDataInfo{
		Header: head,
		Data: &client.TracerNoiseFloorDataReport{
			Sn:   head.Sn,
			Info: make([]*client.TracerNoiseFloorDataDescriptionCh, 0),
		},
	}
	for _, desc := range report.Info {
		buData.Data.Info = append(buData.Data.Info, &client.TracerNoiseFloorDataDescriptionCh{
			Ch1Val: desc.Ch1Val,
			Ch2Val: desc.Ch2Val,
		})
	}

	buBuff, err := proto.Marshal(buData)
	if err != nil {
		logger.Errorf("Marshal TracerNoiseFloorDataReport err %v", err)
		return nil, err
	}
	out := &client.ClientReport{
		MsgType: head.MsgType,
		Data:    buBuff,
	}
	data, err := proto.Marshal(out)
	if err != nil {
		logger.Errorf("ClientReport Marshal err %v", err)
		return nil, err
	}
	return data, nil
}

func convertNoiseBaseFreqData(head *client.EquipmentMessageBoxEntity, in []byte) ([]byte, error) {
	report := &client.NoiseBaseTracerSInfo{}
	err := jsoniter.Unmarshal(in, report)
	if err != nil {
		logger.Error("NoiseBaseTracerSInfo unmarshal error: ", err)
		return nil, err
	}

	buData := &client.TracerSNoiseBaseDataInfo{
		Header: head,
		Data: &client.NoiseBaseTracerSInfo{
			Sn:        report.Sn,
			Freq:      report.Freq,
			FreqStart: report.FreqStart,
			FreqEnd:   report.FreqEnd,
			FreqStep:  report.FreqStep,

			NoisePowerInfoItems: make([]*client.NoiseBasePowerInfo, 0),
		},
	}

	for _, desc := range report.NoisePowerInfoItems {
		buData.Data.NoisePowerInfoItems = append(buData.Data.NoisePowerInfoItems, &client.NoiseBasePowerInfo{
			MeanPower: desc.MeanPower,
			MaxPower:  desc.MaxPower,
		})
	}

	buBuff, err := proto.Marshal(buData)
	if err != nil {
		logger.Errorf("Marshal NoiseBaseTracerSInfo err %v", err)
		return nil, err
	}
	out := &client.ClientReport{
		MsgType: head.MsgType,
		Data:    buBuff,
	}
	data, err := proto.Marshal(out)
	if err != nil {
		logger.Errorf("ClientReport Marshal err %v", err)
		return nil, err
	}
	return data, nil
}

func reportTracerLog(event broker.Event) error {
	if err := webclient.ClientMgrInstance().SendData(event.Message().Body); err != nil {
		logger.Errorf("topic %s SendData err %v", event.Topic(), err)
		return err
	}
	return nil
}

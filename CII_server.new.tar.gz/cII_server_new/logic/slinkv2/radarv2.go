package slinkv2

import (
	"adasgitlab.autel.com/tools/slink_proto/slinkv1"
	"adasgitlab.autel.com/tools/slink_proto/slinkv2/generatecode/golang/bizproto"
	"adasgitlab.autel.com/tools/slink_proto/slinkv2/msgid"

	entity "adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/rpc/codec"
)

func init() {
	radarV2Track := &bizproto.RadarTrack{}
	codec.Instance().Register(entity.DEV_RADAR, codec.VersionTypeV2, msgid.RadarIdV2Track, radarV2Track)

	radarV2State := &bizproto.RadarState{}
	codec.Instance().Register(entity.DEV_RADAR, codec.VersionTypeV2, msgid.RadarIdV2State, radarV2State)

	radarV2SetConfig := &bizproto.RadarC2SetConfigRsp{}
	codec.Instance().Register(entity.DEV_RADAR, codec.VersionTypeV2, msgid.RadarV2SetConfig, radarV2SetConfig)

	radarV2GetConfig := &bizproto.RadarC2Config{}
	codec.Instance().Register(entity.DEV_RADAR, codec.VersionTypeV2, msgid.RadarV2GetConfig, radarV2GetConfig)

	// 以下是雷达OTA monkey patch
	radarResetSystemResponse := &slinkv1.RadarResetSystemResponse{}
	var _ slinkv1.Msg = radarResetSystemResponse
	codec.Instance().Register(entity.DEV_RADAR, codec.VersionTypeV2, slinkv1.RadarIdResetSystem, radarResetSystemResponse)

	getVersionInfoResponse := &slinkv1.GetVersionInfoResponse{}
	var _ slinkv1.Msg = getVersionInfoResponse

	codec.Instance().Register(entity.DEV_RADAR, codec.VersionTypeV2, slinkv1.RadarIdGetVersionInfo, getVersionInfoResponse)

	radarRequestUpgradeResponse := &slinkv1.RadarRequestUpgradeResponse{}
	var _ slinkv1.Msg = radarRequestUpgradeResponse
	codec.Instance().Register(entity.DEV_RADAR, codec.VersionTypeV2, slinkv1.RadarIdRequestUpgrade, radarRequestUpgradeResponse)

	radarSendUpdatePkgResponse := &slinkv1.RadarSendUpdatePkgResponse{}
	var _ slinkv1.Msg = radarSendUpdatePkgResponse
	codec.Instance().Register(entity.DEV_RADAR, codec.VersionTypeV2, slinkv1.RadarIdSendUpdatePkg, radarSendUpdatePkgResponse)

	radarVerifyImageResponse := &slinkv1.RadarVerifyImageResponse{}
	var _ slinkv1.Msg = radarVerifyImageResponse
	codec.Instance().Register(entity.DEV_RADAR, codec.VersionTypeV2, slinkv1.RadarIdVerifyImage, radarVerifyImageResponse)

	radarWriteUpdateDataResponse := &slinkv1.RadarWriteUpdateDataResponse{}
	var _ slinkv1.Msg = radarWriteUpdateDataResponse
	codec.Instance().Register(entity.DEV_RADAR, codec.VersionTypeV2, slinkv1.RadarIdWriteUpdateData, radarWriteUpdateDataResponse)

	radarGetUpdateWriteStatusResponse := &slinkv1.RadarGetUpdateWriteStatusResponse{}
	var _ slinkv1.Msg = radarGetUpdateWriteStatusResponse
	codec.Instance().Register(entity.DEV_RADAR, codec.VersionTypeV2, slinkv1.RadarIdGetUpdateWriteStatus, radarGetUpdateWriteStatusResponse)

	radarRunAppResponse := &slinkv1.RadarRunAppResponse{}
	var _ slinkv1.Msg = radarRunAppResponse
	codec.Instance().Register(entity.DEV_RADAR, codec.VersionTypeV2, slinkv1.RadarIdRunApp, radarRunAppResponse)

	// 雷达Mask相关
	radarMaskSetRsp := &bizproto.RadarC2SetMaskRsp{}
	codec.Instance().Register(entity.DEV_RADAR, codec.VersionTypeV2, msgid.RadarIdV2SetMask, radarMaskSetRsp)

	radarMaskGetRsp := &bizproto.RadarC2Mask{}
	codec.Instance().Register(entity.DEV_RADAR, codec.VersionTypeV2, msgid.RadarIdV2GetMask, radarMaskGetRsp)

	radarMaskReport := &bizproto.RadarC2Mask{}
	codec.Instance().Register(entity.DEV_RADAR, codec.VersionTypeV2, msgid.RadarIdV2Mask, radarMaskReport)
}

package slinkv2

import (
	entity "adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/rpc/codec"
	"adasgitlab.autel.com/tools/slink_proto/slinkv1"
)

func init() {
	sfl200AgxDetect := &slinkv1.Sfl200FusionDetect{}
	codec.Instance().Register(entity.DEV_SFL200, codec.VersionTypeV1, slinkv1.Sfl200UploadAgxDetect, sfl200AgxDetect)

	sfl200PtzData := &slinkv1.Sfl200PtzDate{}
	codec.Instance().Register(entity.DEV_SFL200, codec.VersionTypeV1, slinkv1.Sfl200UploadPtzData, sfl200PtzData)

	sfl200SflDetect := &slinkv1.Sfl200SflDetect{}
	codec.Instance().Register(entity.DEV_SFL200, codec.VersionTypeV1, slinkv1.Sfl200UploadSflDetect, sfl200SflDetect)

	sfl200SystemState := &slinkv1.Sfl200SystemState{}
	codec.Instance().Register(entity.DEV_SFL200, codec.VersionTypeV1, slinkv1.Sfl200UploadSystemStatData, sfl200SystemState)

	//
	sfl200WorkModeSetting := &slinkv1.Sfl200SendSetWorkModeResponse{}
	codec.Instance().Register(entity.DEV_SFL200, codec.VersionTypeV1, slinkv1.Sfl200SendWorkModeSetting, sfl200WorkModeSetting)

	sfl200WorkModeGetting := &slinkv1.Sfl200SendGetWorkModeResponse{}
	codec.Instance().Register(entity.DEV_SFL200, codec.VersionTypeV1, slinkv1.Sfl200SendWorkModeGetting, sfl200WorkModeGetting)

	sfl200AutoFindHitSetting := &slinkv1.Sfl200SendAutoFindHitSettingResponse{}
	codec.Instance().Register(entity.DEV_SFL200, codec.VersionTypeV1, slinkv1.Sfl200SendAutoFindHitSetting, sfl200AutoFindHitSetting)

	sfl200AutoFindHitGet := &slinkv1.Sfl200SendAutoFindHitGetResponse{}
	codec.Instance().Register(entity.DEV_SFL200, codec.VersionTypeV1, slinkv1.Sfl200SendAutoFindHitGet, sfl200AutoFindHitGet)

	sfl200PtzFollowUav := &slinkv1.Sfl200SendPtzFollowUavResponse{}
	codec.Instance().Register(entity.DEV_SFL200, codec.VersionTypeV1, slinkv1.Sfl200SendPtzFollowUav, sfl200PtzFollowUav)

	sfl200HitDealUav := &slinkv1.Sfl200SendHitUavResponse{}
	codec.Instance().Register(entity.DEV_SFL200, codec.VersionTypeV1, slinkv1.Sfl200SendHitDealUav, sfl200HitDealUav)

	sfl200FreqDirect := &slinkv1.Sfl200SendFreqDirectResponse{}
	codec.Instance().Register(entity.DEV_SFL200, codec.VersionTypeV1, slinkv1.Sfl200SendFreqDirect, sfl200FreqDirect)

	sfl200HitFreqDirect := &slinkv1.Sfl200SendFreqDirectHitResponse{}
	codec.Instance().Register(entity.DEV_SFL200, codec.VersionTypeV1, slinkv1.Sfl200SendHitFreqDirect, sfl200HitFreqDirect)

	sfl200ManualStopOrStartHitUav := &slinkv1.Sfl200SendStartStopHitResponse{}
	codec.Instance().Register(entity.DEV_SFL200, codec.VersionTypeV1, slinkv1.Sfl200SendManualStopOrStartHitUav, sfl200ManualStopOrStartHitUav)

	sfl200TurnSf := &slinkv1.Sfl200SendTurnSflResponse{}
	codec.Instance().Register(entity.DEV_SFL200, codec.VersionTypeV1, slinkv1.Sfl200SendTurnSfl, sfl200TurnSf)

	sfl200NSF4000Work := &slinkv1.Sfl200SendStartNSF4000Response{}
	codec.Instance().Register(entity.DEV_SFL200, codec.VersionTypeV1, slinkv1.Sfl200StartNSF4000Work, sfl200NSF4000Work)

	sfl200SystemWorkModeSetting := &slinkv1.Sfl200SendSystemWorkModeSetResponse{}
	codec.Instance().Register(entity.DEV_SFL200, codec.VersionTypeV1, slinkv1.Sfl200SendSystemWorkModeSetting, sfl200SystemWorkModeSetting)

	sfl200SystemWorkModeGet := &slinkv1.Sfl200SendSystemWorkModeGetResponse{}
	codec.Instance().Register(entity.DEV_SFL200, codec.VersionTypeV1, slinkv1.Sfl200SendSystemWorkModeGet, sfl200SystemWorkModeGet)

	sfl200GetVersion := &slinkv1.Sfl200GetVersionResponse{}
	codec.Instance().Register(entity.DEV_SFL200, codec.VersionTypeV1, slinkv1.Sfl200GetVersion, sfl200GetVersion)

	sfl200WhiteSet := &slinkv1.Sfl200SendSetWhiteResponse{}
	codec.Instance().Register(entity.DEV_SFL200, codec.VersionTypeV1, slinkv1.Sfl200SendWhiteSet, sfl200WhiteSet)
}

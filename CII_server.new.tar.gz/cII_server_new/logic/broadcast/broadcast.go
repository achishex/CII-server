package broadcast

import (
	"context"
	"errors"
	"net"
	"strings"

	"adasgitlab.autel.com/tools/cuav_server/repo/threading"

	"adasgitlab.autel.com/tools/slink_proto/slinkv1"
	"adasgitlab.autel.com/tools/slink_proto/slinkv2/generatecode/golang/bizproto"
	"adasgitlab.autel.com/tools/slink_proto/slinkv2/msgid"
	"go-micro.dev/v4/logger"

	"adasgitlab.autel.com/tools/cuav_server/entity/common"
	iphelper "adasgitlab.autel.com/tools/cuav_server/entity/helper"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/rpc/codec"
	"adasgitlab.autel.com/tools/cuav_server/rpc/tcpserver"
)

// HandlerBroadCast 设备组网广播处理
func HandlerBroadCast(ctx context.Context, req interface{}) (interface{}, error) {
	// 获取协议编解码类型
	protoType, ok := ctx.Value(common.ProtoTypeCxtKey).(uint32)
	if !ok {
		return nil, errors.New("ctx must exist ProtoTypeCxtKey")
	}
	if protoType == codec.SerializationTypeSlink {
		return handleDiscoverySlinkV1(ctx, req)
	}

	if protoType == codec.SerializationTypePB {
		return handleDiscoverySlinkV2(ctx, req, WithPreProcStartTcpServer(ctx, WithPostProcStartTcpServer(ctx, nil)))
	}
	return nil, nil
}

func handleDiscoverySlinkV1(ctx context.Context, req interface{}) (interface{}, error) {
	udpReq, ok := req.(*slinkv1.UdpBroadcastConfirmRequest)
	if !ok {
		logger.Errorf("HandleDiscovery convert UdpBroadcastConfirmRequest err")
		return nil, errors.New("HandleDiscovery convert UdpBroadcastConfirmRequest err")
	}
	logger.Debugf("recive UdpBroadcastConfirmRequest Protocol %d Sn %s DeviceType %d DeviceStatus %d Version %s ", udpReq.Protocol, udpReq.GetSn(), udpReq.DeviceType, udpReq.DeviceStatus, strings.TrimRight(string(udpReq.Version[:]), string(rune(0))))
	udpRsp := &slinkv1.UdpBroadcastConfirmResponse{}
	udpAddr, ok := ctx.Value(common.UDPAddrCxtKey).(*net.UDPAddr)
	if !ok {
		logger.Errorf("ctx UdpRemoteAddr empty")
		return nil, nil
	}
	dev := &handler.Device{
		UdpIp:     udpAddr.IP.String(),
		ProtoType: codec.SerializationTypeSlink,
	}
	logger.Debugf("UdpRemoteAddr addr %+v", udpAddr)
	var err error
	switch common.DeviceType(udpReq.DeviceType) {
	case common.DEV_RADAR:
		radar := &handler.Radar{
			Device: dev,
		}
		udpRsp, err = radar.HandleBroadCast(ctx, udpReq)
	case common.DEV_SCREEN:
		screen := &handler.Screen{
			Device: dev,
		}
		udpRsp, err = screen.HandleBroadCast(ctx, udpReq)
		break
	case common.DEV_V2DRONEID:
		tracer := &handler.DroneID{
			Device: dev,
		}
		udpRsp, err = tracer.HandleBroadCast(ctx, udpReq)
		break
	case common.DEV_FPV:
		fpv := &handler.Fpv{
			Device: dev,
		}
		udpRsp, err = fpv.HandleBroadCast(ctx, udpReq)
		break
	case common.DEV_SFL:
		sfl := &handler.Sfl{
			Device: dev,
		}
		udpRsp, err = sfl.HandleBroadCast(ctx, udpReq)
		break
	case common.DEV_AGX:
		agx := &handler.Agx{
			Device: dev,
		}
		udpRsp, err = agx.HandleBroadCast(ctx, udpReq)
		break

	case common.DEV_SPOOFER_MONITOR:
		sm := &handler.SpooferMonitor{
			Device: dev,
		}
		udpRsp, err = sm.HandleBroadCast(ctx, udpReq)
	case common.DEV_SFL200:
		sfl200 := &handler.Sfl200{
			Device: dev,
		}
		udpRsp, err = sfl200.HandleBroadCast(ctx, udpReq)
		break
	case common.DEV_HUNTER_PLATFORM:
		gunsPlatform := &handler.GunsPlatform{
			Device: dev,
		}
		udpRsp, err = gunsPlatform.HandleBroadCast(ctx, udpReq)
		break
	case common.DEV_SRP150:
		srp150 := &handler.Agx{
			Device: dev,
		}
		udpRsp, err = srp150.HandleBroadCast(ctx, udpReq)

	case common.DEV_SRP200:
		srp200 := &handler.Agx{
			Device: dev,
		}
		udpRsp, err = srp200.HandleBroadCast(ctx, udpReq)
	case common.DEV_SBP100:
		sbp100 := &handler.Agx{
			Device: dev,
		}
		udpRsp, err = sbp100.HandleBroadCast(ctx, udpReq)
	case common.DEV_TracerGun:
		tracerGun := &handler.TracerGun{
			Device: dev,
		}
		udpRsp, err = tracerGun.HandleBroadCast(ctx, udpReq)
	case common.DEV_SFL101:
		sfl101 := &handler.Sfl101{
			Device: dev,
		}
		udpRsp, err = sfl101.HandleBroadCast(ctx, udpReq)
	case common.DEV_SVH:
		svh := &handler.Svh{
			Device: dev,
		}
		udpRsp, err = svh.HandleBroadCast(ctx, udpReq)
	case common.DEV_STP120:
		stp120 := &handler.STP120{
			Device: dev,
		}
		udpRsp, err = stp120.HandleBroadCast(ctx, udpReq)
	default:
		logger.Errorf("not support device")
		break
	}
	if err != nil {
		return nil, err
	}
	return udpRsp, nil
}

type ProcStartTcpServer struct {
	PreStartTcpServer  []func(data any) error
	PostStartTcpServer []func(data any) error
	PackageProcess     func(tcpserver.PackageProc, context.Context, int, string, int, any)
}

func WithPreProcStartTcpServer(ctx context.Context, proc *ProcStartTcpServer) *ProcStartTcpServer {
	if proc == nil {
		proc = new(ProcStartTcpServer)
	}
	proc.PreStartTcpServer = append(proc.PreStartTcpServer, func(data any) error {
		v, ok := data.(*bizproto.UdpBroadcastConfirmReq)
		if !ok {
			logger.Errorf("HandleDiscovery convert UdpBroadcastConfirmRequest err")
			return errors.New("HandleDiscovery convert UdpBroadcastConfirmRequest err")
		}
		err := handler.GetDevStatusCheckHandle().MustCheckDevStatus(v.DeviceType, v.GetSn())
		if err != nil {
			logger.Errorf("check dev status fail, dev: %v, err: %v, sn: %v", v.DeviceType, err, v.GetSn())
			return err
		}
		return nil
	})
	return proc
}
func WithPostProcStartTcpServer(ctx context.Context, proc *ProcStartTcpServer) *ProcStartTcpServer {
	if proc == nil {
		proc = new(ProcStartTcpServer)
	}
	udpAddr, ok := ctx.Value(common.UDPAddrCxtKey).(*net.UDPAddr)
	if !ok {
		logger.Errorf("ctx UdpRemoteAddr empty")
		return proc
	}

	proc.PackageProcess = func(fn tcpserver.PackageProc, ctx context.Context, protoType int, sn string, index int, data any) {
		if protoType == int(codec.SerializationTypePB) {
			if handler.GetDevStatusCheckHandle().NeedParallelProcess(codec.SerializationTypePB, sn, data) {
				threading.GoSafe(func() {
					fn(ctx, sn, index, data)
				})
			} else {
				fn(ctx, sn, index, data)
			}
		}
		logger.Errorf("not support sink type: %v package process", protoType)
	}
	//
	proc.PostStartTcpServer = append(proc.PostStartTcpServer, func(data any) error {
		v, ok := data.(*bizproto.UdpBroadcastConfirmReq)
		if !ok {
			logger.Errorf("HandleDiscovery convert UdpBroadcastConfirmRequest err")
			return errors.New("HandleDiscovery convert UdpBroadcastConfirmRequest err")
		}

		err := handler.GetDevStatusCheckHandle().FetchDevVersionInfo(v.DeviceType, v.GetSn(), udpAddr.IP.String())
		if err != nil {
			logger.Errorf("fetch Dev version fail, dev: %v, err: %v, sn: %v", v.DeviceType, err, v.GetSn())
			return err
		}
		return nil
	})
	return proc
}

// handleDiscoverySlinkV2 待处理SlinkV2协议逻辑
func handleDiscoverySlinkV2(ctx context.Context, req interface{}, procHandles *ProcStartTcpServer) (interface{}, error) {
	v, ok := req.(*bizproto.UdpBroadcastConfirmReq)
	if !ok {
		logger.Errorf("HandleDiscovery convert UdpBroadcastConfirmRequest err")
		return nil, errors.New("HandleDiscovery convert UdpBroadcastConfirmRequest err")
	}
	//根据设备IP选择本地IP，作为回包信息回包
	udpAddr, ok := ctx.Value(common.UDPAddrCxtKey).(*net.UDPAddr)
	if !ok {
		logger.Errorf("ctx UdpRemoteAddr empty")
		return nil, nil
	}
	matchIP := iphelper.MatchLocalIP(udpAddr.IP.To4().String())
	if matchIP == "" {
		logger.Errorf("MatchLocalIP empty remoteIP %s", udpAddr.IP.To4().String())
		return nil, nil
	}
	matchPort, err := iphelper.GetFreeTCPPort()
	if err != nil {
		logger.Errorf("GetFreeTcpPort empty remoteip %s", udpAddr.IP.To4().String())
		return nil, nil
	}

	for _, preProc := range procHandles.PreStartTcpServer {
		if e := preProc(req); e != nil {
			logger.Errorf("proc before get tcp Server fail, dev: %v, err: %v, sn: %v", v.DeviceType, err, v.GetSn())
			return nil, err
		}
	}

	svr := tcpserver.TcpServerMgrInstance().GetServer(v.GetSn())
	if svr != nil {
		matchIP = svr.IP
		matchPort = svr.Port

	} else {
		server := tcpserver.New(tcpserver.WithIP(matchIP),
			tcpserver.WithPort(matchPort),
			tcpserver.WithSn(v.GetSn()),
			tcpserver.WithPkgParallelProc(procHandles.PackageProcess))

		tcpserver.TcpServerMgrInstance().SetServer(v.GetSn(), server) //RadarTcpServerMap 可以使用这个。
		go server.Start()
		//处理tcpServer创建后的附加逻辑
		for _, postProc := range procHandles.PostStartTcpServer {
			if e := postProc(req); e != nil {
				logger.Errorf("proc after get tcp server fail, dev: %v, e: %v, sn: %v", v.DeviceType, e, v.GetSn())
			}
		}
	}
	rsp := &bizproto.UdpBroadcastConfirmRsp{
		Sn:       v.Sn,
		Addr:     matchIP,
		Port:     uint32(matchPort),
		ConnType: 1,
	}
	return rsp, nil
}

func init() {
	broadcast_req := &slinkv1.UdpBroadcastConfirmRequest{}
	codec.Instance().Register(common.DEV_SCREEN, codec.VersionTypeV1, slinkv1.RadarUdpBroadcastResponse, broadcast_req)
	codec.Instance().Register(common.DEV_RADAR, codec.VersionTypeV1, slinkv1.RadarUdpBroadcastResponse, broadcast_req)
	codec.Instance().Register(common.DEV_V2DRONEID, codec.VersionTypeV1, slinkv1.RadarUdpBroadcastResponse, broadcast_req)
	codec.Instance().Register(common.DEV_SFL, codec.VersionTypeV1, slinkv1.RadarUdpBroadcastResponse, broadcast_req)
	codec.Instance().Register(common.DEV_AGX, codec.VersionTypeV1, slinkv1.RadarUdpBroadcastResponse, broadcast_req)
	codec.Instance().Register(common.DEV_FPV, codec.VersionTypeV1, slinkv1.RadarUdpBroadcastResponse, broadcast_req)
	codec.Instance().Register(common.DEV_SFL200, codec.VersionTypeV1, slinkv1.RadarUdpBroadcastResponse, broadcast_req)
	codec.Instance().Register(common.DEV_HUNTER_PLATFORM, codec.VersionTypeV1, slinkv1.RadarUdpBroadcastResponse, broadcast_req)
	codec.Instance().Register(common.DEV_SRP200, codec.VersionTypeV1, slinkv1.RadarUdpBroadcastResponse, broadcast_req)
	codec.Instance().Register(common.DEV_SBP100, codec.VersionTypeV1, slinkv1.RadarUdpBroadcastResponse, broadcast_req)
	codec.Instance().Register(common.DEV_TracerGun, codec.VersionTypeV1, slinkv1.RadarUdpBroadcastResponse, broadcast_req)
	codec.Instance().Register(common.DEV_SFL101, codec.VersionTypeV1, slinkv1.RadarUdpBroadcastResponse, broadcast_req)
	codec.Instance().Register(common.DEV_SVH, codec.VersionTypeV1, slinkv1.RadarUdpBroadcastResponse, broadcast_req)
	codec.Instance().Register(common.DEV_STP120, codec.VersionTypeV1, slinkv1.RadarUdpBroadcastResponse, broadcast_req)
	//
	broadcast_req_V2 := &bizproto.UdpBroadcastConfirmReq{}
	codec.Instance().Register(common.DEV_RADAR, codec.VersionTypeV2, msgid.BroadCastMessageResponseID, broadcast_req_V2)
}

package services

import (
	"context"
	"fmt"
	"os"
	"sync"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_plugin/registry/memory"
	"github.com/go-micro/plugins/v4/server/grpc"
	"go-micro.dev/v4"

	"adasgitlab.autel.com/tools/cuav_server/entity/config"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
)

func StartDbSvc(ctx context.Context, wg *sync.WaitGroup, stopChan chan int, dbFile string) {
	dbSvcServer(ctx, wg, dbFile)
	stopChan <- 1
}

// registerMetricHandles 统一框架注册 metric counter handle.
func registerMetricHandles() {
	handler.InitDroneIDCounter()
	handler.InitRadarCounter()
	handler.InitSflCounter()
	// add other metric handle init functions.
}
func dbSvcServer(ctx context.Context, wg *sync.WaitGroup, dbFile string) {
	// 初始化Broker
	mq.InitMemoryBroker()
	// 初始化数据库
	db.DBMonitor.SetFilePath(dbFile)
	if err := db.DBMonitor.OpenDB(); err != nil {
		logger.Errorf("init monitor db fail, e: %v", err)
		return
	}
	defer db.DBMonitor.CloseDB()
	//registerMetricHandles()

	conn, err := db.InitSqlite(dbFile)
	if err != nil {
		logger.Fatalf("InitSqlite err %v", err)
		return
	}
	defer conn.Close()
	// 订阅消息
	handler.Consume()

	// 启动服务
	srv := micro.NewService(
		micro.Server(grpc.NewServer(WithId("1"))),
		micro.Name(config.GetGlobalConfig().MicroSvc.DbSvc),
		micro.Version(config.GetGlobalConfig().MicroSvc.Version),
		micro.Registry(memory.NewRegistry()),
		micro.Address("127.0.0.1:0"),
		micro.AfterStart(func() error {
			wg.Done()
			return nil
		}),
		micro.AfterStop(func() error {
			logger.Info("dbSvc退出")
			return nil
		}),
		micro.Context(ctx),
	)
	srv.Init()
	handler.InitHandler(srv)
	if err := srv.Run(); err != nil {
		fmt.Fprintf(os.Stderr, "Error run dbSvc: %v\n", err)
	}
}

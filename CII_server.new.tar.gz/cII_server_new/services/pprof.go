package services

import (
	"os"
	"path/filepath"
	"runtime"
	"runtime/pprof"
	"runtime/trace"
	"sync"
	"time"
)

var (
	Prof = new(Profiler)
)

type Profiler struct {
	sync.Mutex
	running bool

	cpuFile   *os.File
	memFile   *os.File
	traceFile *os.File
}

func (p *Profiler) Start(path string) error {
	p.Lock()
	defer p.Unlock()

	if p.running {
		return nil
	}

	t := time.Now().Format("2006-01-02-15-04-05")
	cpuFile := filepath.Join(path, t+".cpu.pprof")
	memFile := filepath.Join(path, t+".mem.pprof")
	traceFile := filepath.Join(path, t+".trace.pprof")

	f1, err := os.Create(cpuFile)
	if err != nil {
		return err
	}

	f2, err := os.Create(memFile)
	if err != nil {
		return err
	}

	f3, err := os.Create(traceFile)
	if err != nil {
		return err
	}

	if err := pprof.StartCPUProfile(f1); err != nil {
		return err
	}

	if err := trace.Start(f3); err != nil {
		return err
	}

	p.cpuFile = f1
	p.memFile = f2
	p.traceFile = f3
	p.running = true

	return nil
}

func (p *Profiler) Stop() error {
	p.Lock()
	defer p.Unlock()

	if !p.running {
		return nil
	}

	pprof.StopCPUProfile()
	p.cpuFile.Close()
	runtime.GC()
	pprof.WriteHeapProfile(p.memFile)
	p.memFile.Close()
	trace.Stop()
	p.traceFile.Close()
	p.running = false
	p.cpuFile = nil
	p.memFile = nil
	p.traceFile = nil
	return nil
}

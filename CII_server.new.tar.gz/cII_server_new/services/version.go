package services

func LoadTagVersion() string {
	return "v1.1.10"
}

package services

import (
	"context"
	"fmt"
	"github.com/google/gops/agent"
	"os"
	"sync"
	"time"

	"adasgitlab.autel.com/tools/cuav_server/repo/dao/db"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_plugin/registry/memory"
	grpcc "github.com/go-micro/plugins/v4/client/grpc"
	"github.com/go-micro/plugins/v4/server/grpc"
	"go-micro.dev/v4"

	"adasgitlab.autel.com/tools/cuav_server/entity/config"
	"adasgitlab.autel.com/tools/cuav_server/entity/server"
	"adasgitlab.autel.com/tools/cuav_server/logic/broadcast"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	_ "adasgitlab.autel.com/tools/cuav_server/logic/report"
	_ "adasgitlab.autel.com/tools/cuav_server/logic/response"
	_ "adasgitlab.autel.com/tools/cuav_server/logic/slinkv2"
	"adasgitlab.autel.com/tools/cuav_server/logic/uploadcloud"
	"adasgitlab.autel.com/tools/cuav_server/repo/mq"
	"adasgitlab.autel.com/tools/cuav_server/rpc/discovery"
)

func StartDeviceCenter(ctx context.Context, wg *sync.WaitGroup, stopChan chan int) {
	deviceCenterServer(ctx, wg)
	stopChan <- 1
}

// StartSimpleTcpServer 不会停止服务直至接收总的进程退出信号
func StartSimpleTcpServer(ctx context.Context) {
	now := time.Now()
	for {
		if db.GetDB() == nil {
			time.Sleep(5 * time.Millisecond)
		} else {
			logger.Info("StartSimpleTcpServer already sleep %d ms", time.Since(now).Milliseconds())
			break
		}
		if time.Since(now) > 1*time.Second {
			logger.Info("timeout break: StartSimpleTcpServer already sleep %d ms", time.Since(now).Milliseconds())
			break
		}
	}
	//
	//tcpSrv := server.NewTcpServerWithOpt(config.GetGlobalConfig().Server.MiniGunTcpSvrIp,
	//	config.GetGlobalConfig().Server.MiniGunTcpSvrPort, handler.Handle, handler.BackendC2ToDev)
	//threading.GoSafe(func() {
	//	for {
	//		select {
	//		case <-ctx.Done():
	//			logger.Infof("service receive stop signal.")
	//			return
	//		default:
	//			logger.Infof("start min gun server")
	//			tcpSrv.Start()
	//			time.Sleep(1 * time.Second)
	//		}
	//	}
	//})
}
func runGops() {
	go func() {
		opts := agent.Options{
			ShutdownCleanup: true,
			Addr:            ":9905", /// 指定监听的 IP 地址和端口。:0 表示自动选择一个随机端口
		}
		// 启动 gops 代理
		if err := agent.Listen(opts); err != nil {
			fmt.Println("is err: ", err)
		} else {
			logger.Infof("run gops.")
		}
	}()
}
func deviceCenterServer(ctx context.Context, wg *sync.WaitGroup) {
	// 初始化Broker
	mq.InitMemoryBroker()
	// 启动服务
	// 需要先启动服务后再调用后续逻辑，因为逻辑中存在调用client情况，防止调用时client对象还会初始化
	tcpServer := server.NewTcpServer(8060, handler.Handle)
	go tcpServer.Start()
	//生成SN
	handler.GetC2Id()
	go handler.SetC2SN()
	// 自动组网
	discovery.Instance(discovery.WithHandler(broadcast.HandlerBroadCast)).Start()
	handler.RegisterDevOpsProc()
	go handler.GetUnionLatLonResHandle().Run()
	//启动设备检测
	handler.DeviceInit()
	//开启数据上云服务
	go uploadcloud.ConnectCloudPlatform()
	// 启动RF URD360
	go handler.StartUrdTCPConnection(config.GetGlobalConfig().Server.Urd360TcpIp, config.GetGlobalConfig().Server.Urd360TcpPort, "URD360")

	// 启动NSF4000
	//nsfCli := server.NewTcpClient("192.168.2.74:90", handler.NewControllerNSF4000(), true)
	nsfCli := server.NewTcpClient("192.168.2.74:1000", handler.NewControllerNSF4000("192.168.2.74"), true)
	go nsfCli.Run()

	nsfSSH100Cli := server.NewTcpClient("192.168.2.94:1000", handler.NewControllerNSF4000("192.168.2.94"), true)
	go nsfSSH100Cli.Run()

	nsf110Cli := server.NewTcpClient("192.168.2.84:1000", handler.NewControllerNSF4000("192.168.2.84"), true)
	go nsf110Cli.Run()

	nsfGxw := server.NewUdpNsf()
	dIp := config.GetGlobalConfig().Server.NsfgxwIp
	dPort := config.GetGlobalConfig().Server.NsfgxwPort
	dAddr := "192.168.10.230:9099"
	if len(dIp) != 0 && dPort != 0 {
		dAddr = fmt.Sprintf("%s:%d", dIp, dPort)
	}
	go nsfGxw.WithDevAddr(dAddr).WithPcAddr().WithHandler(handler.NewControllerNSFGXW()).Run()

	// 接入DPH110中程雷达
	dph110 := server.NewUdpDPH(handler.NewControllerDPH110())
	go dph110.Run()
	runGops()
	logger.Info("c2 backend version: ", LoadTagVersion())

	srv := micro.NewService(
		micro.Server(grpc.NewServer(WithId("1"))),
		micro.Client(grpcc.NewClient()),
		micro.Name("deviceCenter"),
		micro.Version("latest"),
		micro.Registry(memory.NewRegistry()),
		micro.Address("127.0.0.1:0"),
		micro.AfterStart(func() error {
			wg.Done()
			return nil
		}),
		micro.AfterStop(func() error {
			logger.Info("deviceCenter退出")
			return nil
		}),
		micro.Context(ctx),
	)
	srv.Init()
	// Client
	handler.InitMicroClient(srv)
	if err := srv.Run(); err != nil {
		fmt.Fprintf(os.Stderr, "Error run deviceCenter: %v\n", err)
	}
}

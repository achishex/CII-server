package services

import (
	"adasgitlab.autel.com/tools/cuav_server/api/webapi"
	"adasgitlab.autel.com/tools/cuav_server/entity/bean"
	"bytes"
	"context"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"sync"
	"time"

	"adasgitlab.autel.com/tools/cuav_plugin/config/file"
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/config"
	"adasgitlab.autel.com/tools/cuav_server/logic/clientdata"
	"adasgitlab.autel.com/tools/cuav_server/logic/handler"
	"adasgitlab.autel.com/tools/cuav_server/repo/cache"
	"adasgitlab.autel.com/tools/cuav_server/repo/utils"
	"adasgitlab.autel.com/tools/cuav_server/rpc/webclient"
	"adasgitlab.autel.com/tools/cuav_server/rpc/websocketsvr"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"github.com/gorilla/websocket"
	jsoniter "github.com/json-iterator/go"
)

var (
	NatsCancel    func()
	ServiceCancel func()
)

// SetSn app设置c2 sn
func SetSn(a string) {
	bean.C2Sn = a
}

// StartPlugins 集成至APP时前端调用启动
func StartPlugins(timeOffset int, cuavConfigFile string, dbfile string, natsConfigFile string, natsDataDir string, logSaveDir string) int {
	// 系统时间
	time.Local = time.FixedZone("Local", int(time.Hour.Seconds())*timeOffset)
	//初始化日志组件
	if err := logger.Init(cuavConfigFile, logSaveDir); err != nil {
		logger.Fatal("init log failed! errors info %s", err)
		return 1
	}
	// 读取配置
	cfg := file.NewConfig(cuavConfigFile)
	err := cfg.Init(config.GetGlobalConfig())
	if err != nil {
		logger.Fatal("初始化配置失败：", err)
		return 1
	}
	logger.Init(cuavConfigFile)

	webapi.ConfigDir = filepath.Dir(cuavConfigFile)
	// 初始化雪花算法节点
	utils.InitSnowFlakeNode(222)
	err = UpdateDBs(dbfile)
	if err != nil {
		logger.Fatal("数据库迁移失败", err)
		return 1
	}
	return 0
}

// StopPlugins 集成至APP时，前端控制停止
func StopPlugins() {
	return
}

// StartCuavServices 集成至APP时，前端启动服务
func StartCuavServices(logLevel string, logFlag bool, dbFile string) int {
	// 初始化缓存组件
	logger.Debug("Start CuavServices")
	dbPath := filepath.Dir(dbFile)
	cache.Init(dbPath)
	// 启动服务
	var ctx context.Context
	ctx, ServiceCancel = context.WithCancel(context.Background())
	stopChan := make(chan int, 1)
	var wg sync.WaitGroup
	wg.Add(3)
	go StartDbSvc(ctx, &wg, stopChan, dbFile)
	go StartDeviceCenter(ctx, &wg, stopChan)
	go StartWebApi(ctx, &wg, stopChan)
	logger.Debug("StartCuavServices ...")
	go func() {
		wg.Wait()
		stopChan <- 0
	}()
	ch := <-stopChan
	if ch != 0 {
		logger.Fatal("服务启动失败")
		return 1
	}
	if !StartStatisticSchedule(60) {
		logger.Fatal("定时数据统计任务启动失败")
		return -1
	}
	if StartEquipment() {
		logger.Debug("Start Over CuavServices")
		return 0
	}
	logger.Fatal("设备启动失败")
	return -1
}

// StopCuavServices 集成至APP时，前端停止服务
func StopCuavServices() {
	logger.Debug("Call StopCuavServices ...")
	if ServiceCancel != nil {
		ServiceCancel()
	}

	os.Exit(0)
}

// StartEquipment ...
func StartEquipment() bool {
	if err := handler.NewAppAgent().Start(context.Background(), nil, nil); err != nil {
		logger.Error("NewAppAgent Start err %v", err)
		return false
	}

	go func() {
		if err := clientdata.TranseData(); err != nil {
			logger.Error("client data TranseData err %v", err)
			return
		}

		routes := map[string]gin.HandlerFunc{
			"/ws/v1/messagebox": func(ctx *gin.Context) {
				upgrader := websocket.Upgrader{
					CheckOrigin: func(r *http.Request) bool { return true },
				}
				conn, err := upgrader.Upgrade(ctx.Writer, ctx.Request, nil)
				if err != nil {
					logger.Errorf("Failed to upgrade to websocket err %v", err)
					return
				}
				logger.Debugf("websocket conn remote ip: %s", conn.RemoteAddr().String())
				client := webclient.NewClient(webclient.WithConn(conn), webclient.WithClientID(uuid.New().String()), webclient.WithMessageType(websocket.BinaryMessage))
				if err := webclient.ClientMgrInstance().Register(client); err != nil {
					logger.Errorf("devi websocket store err %v", err)
					return
				}
				go client.Read()
				go client.Write()
			},
		}
		if err := websocketsvr.New(websocketsvr.WithIP(config.GetGlobalConfig().Server.WebsocketIp),
			websocketsvr.WithPort(9907), websocketsvr.WithWebHook(routes)).Start(); err != nil {
			logger.Error("New websocketsvr err %v", err)
			return
		}
	}()

	return true
}

type StartStatisticScheduleRequest struct {
	Period int32 `json:"period"`
}

type StartStatisticScheduleResponse struct {
	ErrorCode int    `json:"error_code"`
	Message   string `json:"message"`
	Status    int32  `json:"status"`
}

type Status struct {
	Status int32 `json:"status"`
}

func StartStatisticSchedule(period int32) bool {
	ssq := StartStatisticScheduleRequest{Period: period}
	buf, _ := jsoniter.Marshal(ssq)
	body := bytes.NewReader(buf)
	req, _ := http.NewRequest("POST", "http://"+config.GetGlobalConfig().Server.RestfulApiIp+":9901/statistic/schedule", body)
	req.Header.Set("Content-Type", "application/json")
	resp, err := http.DefaultClient.Do(req)
	if resp != nil {
		defer resp.Body.Close()
	}
	if err != nil {
		logger.Error("Timed data statistics interface request error:", err)
		return false
	}

	b, _ := io.ReadAll(resp.Body)
	var res StartStatisticScheduleResponse
	jsoniter.Unmarshal(b, &res)
	if res.ErrorCode == 0 {
		return true
	}
	return false
}

// StartProfiler 启动性能分析
func StartProfiler(path string) int {
	if err := Prof.Start(path); err != nil {
		logger.Error("启动pprof采集失败：", err)
		return 1
	}
	return 0
}

// StopProfiler 结束性能分析
func StopProfiler() {
	_ = Prof.Stop()
}

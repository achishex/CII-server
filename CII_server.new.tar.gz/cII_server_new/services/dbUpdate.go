package services

import (
	"adasgitlab.autel.com/tools/cuav_server/db"
	db1 "adasgitlab.autel.com/tools/cuav_server/repo/dao/db"
	"adasgitlab.autel.com/tools/cuav_server/repo/utils/threading"
	"database/sql"
	"errors"
)

func UpdateDb(dbFilePath string) error {
	database, err := db1.InitSqlite(dbFilePath)
	if err != nil {
		return err
	}
	err = db.Migrate(database)
	if err != nil {
		return err
	}

	//err = db.CreateDemoData(database)
	//if err != nil {
	//	logger.Error("CreateDemoData error", err)
	//}
	return nil
}

func UpdateDbForMonitorDb(dbFilePath string) error {
	database, err := sql.Open("sqlite3", dbFilePath)
	if err != nil {
		return err
	}
	err = db.Migrate(database)
	if err != nil {
		return err
	}

	//err = db.CreateDemoData(database)
	//if err != nil {
	//	logger.Error("CreateDemoData error", err)
	//}
	return nil
}

// UpdateDBs 更新所有的数据库
func UpdateDBs(dbFilePath string) error {
	p := db1.BuildMonitorDBPath(dbFilePath)
	if len(p) == 0 {
		return errors.New("get monitor db path is empty")
	}
	wg := threading.NewRoutineGroupWrap()
	wg.Run(func() {
		UpdateDbForMonitorDb(p)
	})

	wg.Run(func() {
		UpdateDb(dbFilePath)
	})
	return nil
}

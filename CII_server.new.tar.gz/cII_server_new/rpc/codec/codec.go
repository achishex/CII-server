package codec

import (
	"errors"
	"reflect"
	"sync"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"

	entity "adasgitlab.autel.com/tools/cuav_server/entity/common"
)

// 版本类型
const (
	VersionTypeV1    uint8  = 1
	VersionTypeV2    uint8  = 2
	VersionTypeV1Str string = "v1"
	VersionTypeV2Str string = "v2"
)

// Codec 编解码器
type Codec struct {
	mu       sync.Mutex
	cmdCoder map[entity.DeviceType]map[uint8]map[uint16]interface{}
}

var (
	codecInstance *Codec
	codecOnce     sync.Once
)

// Instance 单例
func Instance() *Codec {
	codecOnce.Do(func() {
		codecInstance = &Codec{
			cmdCoder: make(map[entity.DeviceType]map[uint8]map[uint16]interface{}),
		}
	})
	return codecInstance
}

// Register 注册命令字请求响应编解码
func (c *Codec) Register(deviceType entity.DeviceType, versionType uint8, cmd uint16, rsp interface{}) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.cmdCoder[deviceType] == nil {
		c.cmdCoder[deviceType] = make(map[uint8]map[uint16]interface{})
	}
	if c.cmdCoder[deviceType][versionType] == nil {
		c.cmdCoder[deviceType][versionType] = make(map[uint16]interface{})
	}
	c.cmdCoder[deviceType][versionType][cmd] = rsp
}

// Get 获取设备下命令字请求响应编解码
func (c *Codec) Get(deviceType entity.DeviceType, versionType uint8, cmd uint16) (interface{}, error) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if _, ok := c.cmdCoder[deviceType]; !ok {
		logger.Errorf("deviceType %d not register codec", deviceType)
		return nil, errors.New("deviceType not register codec")
	}
	if _, ok := c.cmdCoder[deviceType][versionType]; !ok {
		logger.Errorf("versionType %d not register codec", versionType)
		return nil, errors.New("versionType not register codec")
	}
	v, ok := c.cmdCoder[deviceType][versionType][cmd]
	if !ok {
		logger.Errorf("deviceType %d cmd %d not register codec", deviceType, cmd)
		return nil, errors.New("cmd not register codec")
	}
	rspCoder := reflect.TypeOf(v).Elem()
	if rspCoder.Kind() != reflect.Struct {
		logger.Errorf("deviceType %d cmd %d reflect rspCoder TypeOf not struct", deviceType, cmd)
		rspCoder = nil
	}
	return reflect.New(rspCoder).Interface().(interface{}), nil
}

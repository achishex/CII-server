package codec

import (
	"errors"

	"google.golang.org/protobuf/proto"
)

func init() {
	RegisterSerializer(SerializationTypePB, &SlinkV2Serialization{})
}

// SlinkV2Serialization SlinkV2解析器
type SlinkV2Serialization struct{}

// Marshal 编码
func (s *SlinkV2Serialization) Marshal(body interface{}) ([]byte, error) {
	msg, ok := body.(proto.Message)
	if !ok {
		return nil, errors.New("marshal fail: body not protobuf message")
	}
	return proto.Marshal(msg)
}

// Unmarshal 解码
func (s *SlinkV2Serialization) Unmarshal(data []byte, v interface{}) error {
	msg, ok := v.(proto.Message)
	if !ok {
		return errors.New("unmarshal fail: body not protobuf message")
	}
	return proto.Unmarshal(data, msg)
}

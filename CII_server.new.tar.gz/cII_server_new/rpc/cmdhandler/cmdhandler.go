package cmdhandler

import (
	"context"
	"errors"
	"sync"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"

	entity "adasgitlab.autel.com/tools/cuav_server/entity/common"
)

// CmdHandler 命令字回调函数
type CmdHandler func(ctx context.Context, sn string, rsp interface{}) (interface{}, error)

// CommandHandler 命令字回调函数映射
type CommandHandler struct {
	mu         sync.Mutex
	cmdHandler map[entity.DeviceType]map[uint16]CmdHandler
}

var (
	cmdHandlerInstance *CommandHandler
	cmdOnce            sync.Once
)

// Instance 命令字处理单例
func Instance() *CommandHandler {
	cmdOnce.Do(func() {
		cmdHandlerInstance = &CommandHandler{
			cmdHandler: make(map[entity.DeviceType]map[uint16]CmdHandler),
		}
	})
	return cmdHandlerInstance
}

// GetHandler 获取设备对应命令字的处理函数
func (c *CommandHandler) GetHandler(deviceType entity.DeviceType, cmd uint16) (CmdHandler, error) {
	c.mu.Lock()
	defer c.mu.Unlock()
	_, ok := c.cmdHandler[deviceType]
	if !ok {
		logger.Errorf("deviceType %d command not register", deviceType)
		return nil, errors.New("deviceType command not register")
	}
	handle, ok := c.cmdHandler[deviceType][cmd]
	if !ok {
		logger.Errorf("deviceType %d cmd %d command not register", deviceType, cmd)
		return nil, errors.New("command not register")
	}
	return handle, nil
}

// RegisterHandler 注册对应设备类型命令字处理函数
func (c *CommandHandler) RegisterHandler(deviceType entity.DeviceType, cmd uint16, handle CmdHandler) {
	c.mu.Lock()
	defer c.mu.Unlock()
	//logger.Debugf("RegisterHandler deviceType %d cmd %d handle %s", deviceType, cmd)
	if c.cmdHandler[deviceType] == nil {
		c.cmdHandler[deviceType] = make(map[uint16]CmdHandler)
	}
	c.cmdHandler[deviceType][cmd] = handle
}

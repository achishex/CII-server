package monitor

type TaskOp interface {
	StopTask()
}

// SkyFdMetricOps 发送数据 metric 对象接口
type SkyFdMetricOps interface {
	Unregister()
	GetCollector() any
	ReportByPush(tmOutMs ...int32) error
	ReportByAdd(tmOutMs ...int32) error
}

// SkyFdCounterVec ///////////////////////////////////////////////////////////////////////
// SkyFdCounterVec 参考定义： https://yunlzheng.gitbook.io/prometheus-book/parti-prometheus-ji-chu/promql/prometheus-metrics-types
// SkyFdCounterVec represents 计数器向量
// 一个累计类型的数据指标，它代表单调递增的计数器, 只增不减; prom & db implement this interface.
type SkyFdCounterVec interface {
	SkyFdMetricOps

	// Inc 在标签上递增值, labels 是由参数设置
	Inc(labels ...string)

	// Add 在标签上增加 v, labels 是由参数设置
	Add(v float64, labels ...string)
}

// SkyFdCounterVecWrapper 提供外部调用
type SkyFdCounterVecWrapper interface {
	TaskOp

	// Inc 在标签上递增值, labels 是由参数设置
	Inc(labels ...string)

	// Add 在标签上增加 v, labels 是由参数设置
	Add(v float64, labels ...string)
}

// SkyFdGaugeVec ///////////////////////////////////////////////////////////////////////
// SkyFdGaugeVec  represents a 量规向量.
// 标识任意上下波动数值的指标类型， 可增可减的仪表盘; prom & db implement this interface.
type SkyFdGaugeVec interface {
	SkyFdMetricOps

	// Set 标签上值设置 v, labels 是由参数设置
	Set(v float64, labels ...string)

	// Inc 标签上值递增, labels 是由参数设置
	Inc(labels ...string)

	// Dec 标签上值递减, labels 是由参数设置
	Dec(labels ...string)

	// Add 在标签上加v, labels 是由参数设置
	Add(v float64, labels ...string)

	// Sub 在标签上减值v, labels 是由参数设置
	Sub(v float64, labels ...string)
}

// SkyFdGaugeVecWrapper 提供外部调用
type SkyFdGaugeVecWrapper interface {
	TaskOp

	// Set 标签上值设置 v, labels 是由参数设置
	Set(v float64, labels ...string)

	// Inc 标签上值递增, labels 是由参数设置
	Inc(labels ...string)

	// Dec 标签上值递减, labels 是由参数设置
	Dec(labels ...string)

	// Add 在标签上加v, labels 是由参数设置
	Add(v float64, labels ...string)

	// Sub 在标签上减值v, labels 是由参数设置
	Sub(v float64, labels ...string)
}

// SkyFdHistogramVec ///////////////////////////////////////////////////////////////////////
// SkyFdHistogramVec  interface represents a 直方图向量.
// 用于： 统计和分析样本的分布情况， 将观测值划分成固定区间（桶）来记录数据分布情况，
// 适合处理长尾型数据或极端事件. 支持数据sum、count、quantile。 prom & db implement this interface.
type SkyFdHistogramVec interface {
	SkyFdMetricOps

	// Observe  在标签上增加观察值 v, labels 是由参数设置
	Observe(v int64, labels ...string)

	// ObserveFloat allow to Observe  v, labels 是由参数设置
	ObserveFloat(v float64, labels ...string)
}

// SkyFdHistogramVecWrapper 提供外部调用
type SkyFdHistogramVecWrapper interface {
	TaskOp

	// Observe  在标签上增加观察值 v, labels 是由参数设置
	Observe(v int64, labels ...string)

	// ObserveFloat allow to Observe  v, labels 是由参数设置
	ObserveFloat(v float64, labels ...string)
}

// SkyFdSummaryVec ///////////////////////////////////////////////////////////////////////
// SkyFdSummaryVec summary 向量， 过百分位数来确定桶的边界, 适合记录短周期内的数据变化
// 支持数据 sum、count、quantile; prom & db implement this interface.
type SkyFdSummaryVec interface {
	SkyFdMetricOps

	// Observe 在标签labels上增加监测值v, labels 是由参数设置
	Observe(v float64, labels ...string)
}

// SkyFdSummaryVecWrapper 提供外部调用
type SkyFdSummaryVecWrapper interface {
	TaskOp
	// Observe 在标签labels上增加监测值v, labels 是由参数设置
	Observe(v float64, labels ...string)
}

package discovery

import (
	"context"
	"fmt"
	"io"
	"net"
	"sync"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/slink_proto/slinkv1"
	"adasgitlab.autel.com/tools/slink_proto/slinkv2"
	"adasgitlab.autel.com/tools/slink_proto/slinkv2/generatecode/golang/bizproto"
	"adasgitlab.autel.com/tools/slink_proto/slinkv2/msgid"
	"google.golang.org/protobuf/proto"

	entity "adasgitlab.autel.com/tools/cuav_server/entity/common"
	iphelper "adasgitlab.autel.com/tools/cuav_server/entity/helper"
	"adasgitlab.autel.com/tools/cuav_server/rpc/codec"
)

var (
	maxReceiveSize         int    = 1024
	disCoveryServerPort    int    = 1810 // 服务端端口
	disCoveryBroadCastPort int    = 1800 // 广播端口
	slinkV1Proto           uint32 = 2    // SlinkV1协议广播
	slinkV2Proto           uint32 = 200  // SlinkV2协议广播
)

// Handler 回调处理函数
type Handler func(ctx context.Context, req interface{}) (interface{}, error)

// DisCovery 自动发现组网
type DisCovery struct {
	ip      string             //IP地址
	port    int                //端口，默认8100
	handler Handler            // 回调处理函数
	cancel  context.CancelFunc //UDP广播上下文取消函数
}

// Opt 可选参数项
type Opt func(d *DisCovery)

// WithIP 设置IP
func WithIP(ip string) Opt {
	return func(d *DisCovery) {
		d.ip = ip
	}
}

// WithPort 设置端口
func WithPort(port int) Opt {
	return func(d *DisCovery) {
		d.port = port
	}
}

// WithHandler 设置回调函数
func WithHandler(handler Handler) Opt {
	return func(d *DisCovery) {
		d.handler = handler
	}
}

var (
	discovery *DisCovery
	once      sync.Once
)

// Instance 获取单例自动发现实例
func Instance(opts ...Opt) *DisCovery {
	once.Do(func() {
		discovery = &DisCovery{
			ip:   "0.0.0.0",
			port: disCoveryServerPort,
		}
		for _, o := range opts {
			o(discovery)
		}
	})
	return discovery
}

// Start 启动自动发现
func (d *DisCovery) Start() {
	ctx, cancel := context.WithCancel(context.Background())
	d.cancel = cancel
	go d.startBC(ctx)
	go d.startServer(ctx)
}

// Stop 自动发现停止
func (d *DisCovery) Stop() {
	if d.cancel != nil {
		d.cancel()
	}
}

// Start 自动发现接收数据
func (d *DisCovery) startServer(ctx context.Context) {
	addr, err := net.ResolveUDPAddr("udp", fmt.Sprintf("%s:%d", d.ip, d.port))
	if err != nil {
		logger.Errorf("Resolve UDP Addr err: %v", err)
		return
	}
	conn, err := net.ListenUDP("udp", addr)
	if err != nil {
		logger.Errorf("udp server listen err:%v", err)
		return
	}
	defer conn.Close()
	logger.Debugf("udp listen conn addr %s:%d", d.ip, d.port)
	buff := make([]byte, 0)
	for {
		tmpBuffer := make([]byte, maxReceiveSize)
		n, addr, err := conn.ReadFromUDP(tmpBuffer)
		if err != nil {
			// 通常遇到的错误是连接中断或被关闭，用io.EOF表示
			if err == io.EOF {
				logger.Errorf("udp conn receive close: %v", conn.RemoteAddr())
				return
			}
			logger.Errorf("udp conn receive err: %v", err)
			return
		}

		logger.Debugf("udp read from [%s] buff[% x]", addr.String(), tmpBuffer[:n])
		buff = append(buff, tmpBuffer[:n]...)
		// SlinkV1/V2都不是，需要继续收包
		if !slinkv1.IsSlinkV1(buff) && !slinkv2.IsSlinkV2(buff) {
			continue
		}
		leftBuff := make([]byte, 0)
		if slinkv1.IsSlinkV1(buff) {
			leftBuff, err = d.handleSlinkV1(ctx, addr, conn, buff)
			if err != nil {
				logger.Errorf("HandleSlinkV1 err: %v", err)
			}
		}
		if slinkv2.IsSlinkV2(buff) {
			leftBuff, err = d.handleSlinkV2(ctx, addr, conn, buff)
			if err != nil {
				logger.Errorf("HandleSlinkV2 err: %v", err)
			}
		}
		buff = buff[:0]
		if len(leftBuff) > 0 {
			buff = append(buff, leftBuff...)
		}
	}
}

// startBC 启动UDP广播
func (d *DisCovery) startBC(ctx context.Context) {
	t := time.NewTicker(2 * time.Second)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
			localIPInfos, err := iphelper.GetLocalIPInfos()
			if err != nil {
				logger.Errorf("startBC GetLocalIPInfos err %v", err)
				continue
			}
			for _, ip := range localIPInfos {
				go func(ctx context.Context, localIp string, broadIp string) {
					d.sendBC(ctx, localIp, broadIp)
				}(ctx, ip.LocalIP, ip.BroadCastIP)
			}
		}
	}
}

// sendBC 发送UDP广播
func (d *DisCovery) sendBC(ctx context.Context, localIP, broadIP string) {
	buffs, err := d.getBCMsgs()
	if err != nil {
		logger.Errorf("getBCMsgs err %v", err)
		return
	}
	// 协议, 发送者,接收者
	conn, err := net.DialUDP("udp",
		&net.UDPAddr{
			IP: net.ParseIP(localIP),
		},
		&net.UDPAddr{
			IP:   net.ParseIP(broadIP),
			Port: disCoveryBroadCastPort,
		})
	if err != nil {
		logger.Errorf("sendBC DialUDP err %v", err)
		return
	}
	defer conn.Close()
	for _, buff := range buffs {
		if _, err = conn.Write(buff); err != nil {
			logger.Errorf("sendBC localIp %s broadIp %s write buff err %v", localIP, broadIP, err)
			return
		}
		logger.Debugf("sendBC buff[% X] Success", buff)
	}
	logger.Debugf("sendBC localIp %s broadIp %s Success", localIP, broadIP)
}

// getBCMsgs 获取SlinkV1、V2广播消息
func (d *DisCovery) getBCMsgs() ([][]byte, error) {
	buffs := make([][]byte, 0)
	// 构造SlinkV1广播协议
	res := slinkv1.UdpBroadCastMessage{
		Protocol: slinkV1Proto,
	}
	resBuff := res.Encode()
	header := slinkv1.NewMavHeader(slinkv1.WithSourceID(uint8(entity.DEV_C2_WIFI)), slinkv1.WithDestID(uint8(entity.DEV_BROADCAST)),
		slinkv1.WithMsgID(slinkv1.UdpBroadCastDiscoverMsgId), slinkv1.WithLen(uint16(len(resBuff))))
	bcPacket := &slinkv1.MavPacket{
		Header:  *header,
		PayLoad: resBuff,
	}
	buff, err := slinkv1.Encode(bcPacket)
	if err != nil {
		logger.Errorf("sendBC Encode err %v", err)
		return nil, err
	}
	buffs = append(buffs, buff)

	// 构造SlinkV2广播协议
	resV2 := &bizproto.UdpBroadcastMessage{
		Protocol: slinkV2Proto,
	}
	resBuffV2, err := proto.Marshal(resV2)
	if err != nil {
		logger.Errorf("UdpBroadcastMessage Marshal err %v", err)
		return nil, err
	}
	bcPacketV2 := &slinkv2.PacketV2{
		Header: *slinkv2.NewMavHeader(slinkv2.WithSourceID(uint8(entity.DEV_C2_WIFI)), slinkv2.WithDestID(uint8(entity.DEV_BROADCAST)),
			slinkv2.WithMsgID(msgid.BroadCastMessageID), slinkv2.WithLen(uint16(len(resBuffV2)))),
		PayLoad: resBuffV2,
	}
	buffV2, err := slinkv2.Encode(bcPacketV2)
	if err != nil {
		logger.Errorf("slinkv2 Encode err %v", err)
		return nil, err
	}
	buffs = append(buffs, buffV2)
	return buffs, nil
}

// handleSlinkV1 处理SlinkV1协议
func (d *DisCovery) handleSlinkV1(ctx context.Context, addr *net.UDPAddr, conn *net.UDPConn, buff []byte) ([]byte, error) {
	packets, leftBuff, err := slinkv1.ParseMavlinkBuff(buff)
	if err != nil {
		logger.Errorf("ParseMavlinkBuff err %v", err)
	}
	logger.Debugf("udp read from [%s] packets len:%d left buff len %d value % x", addr.String(), len(packets), len(leftBuff), leftBuff)
	for index, req := range packets {
		logger.Debugf("packet index %d value %+v", index, req)
		reqBody, err := codec.Instance().Get(entity.DeviceType(req.GetSourceID()), codec.VersionTypeV1, uint16(req.GetMsgID()))
		if err != nil {
			logger.Errorf("GetCodec err %v devtype %d cmd %d", err, req.GetSourceID(), req.GetMsgID())
			continue
		}
		logger.Debugf("DeivceHandle req head %+v data[% x]", req.Header, req.PayLoad)
		if reqBody == nil {
			logger.Errorf("devtype %d cmd %d RspCodec nil", req.GetSourceID(), req.GetMsgID())
			continue
		}
		if err := codec.Unmarshal(codec.SerializationTypeSlink, req.PayLoad, reqBody); err != nil {
			logger.Errorf("req Decode err %v", err)
			continue
		}
		// 上下文增加远程地址
		ctx := context.WithValue(ctx, entity.UDPAddrCxtKey, addr)
		// 上下文增加包头
		ctx = context.WithValue(ctx, entity.PacketHeadCxtKey, req.Header)
		// 协议编解码类型
		ctx = context.WithValue(ctx, entity.ProtoTypeCxtKey, codec.SerializationTypeSlink)
		rsp, err := d.handler(ctx, reqBody)
		if err != nil {
			logger.Errorf("req %v Handle err %v", req, err)
			continue
		}
		buRspBuff, err := codec.Marshal(codec.SerializationTypeSlink, rsp)
		if err != nil {
			logger.Errorf("buRsp Encode err")
			continue
		}
		packet := &slinkv1.MavPacket{
			Header: *(slinkv1.NewMavHeader(slinkv1.WithSourceID(uint8(entity.DEV_C2_WIFI)), slinkv1.WithDestID(req.GetSourceID()),
				slinkv1.WithLen(uint16(len(buRspBuff))), slinkv1.WithMsgID(slinkv1.UdpBroadCastConfirmRspMsgId))),
			PayLoad: buRspBuff,
		}
		rspBuff, err := slinkv1.Encode(packet)
		if err != nil {
			logger.Errorf("slinkv1 encode error %v", err)
			continue
		}
		// 发送bc固定端口
		addr.Port = disCoveryBroadCastPort
		// 发送响应
		if _, err = conn.WriteToUDP(rspBuff, addr); err != nil {
			logger.Errorf("conn Write to add[%s] buff[% x] err %v", addr.String(), buff, err)
			continue
		}
		logger.Debugf("conn [%s] write buff[% x] success", addr.String(), rspBuff)
	}
	return leftBuff, nil
}

// handleSlinkV2 处理SlinkV2协议
func (d *DisCovery) handleSlinkV2(ctx context.Context, addr *net.UDPAddr, conn *net.UDPConn, buff []byte) ([]byte, error) {
	packets, leftBuff, err := slinkv2.ParseMavlinkBuff(buff)
	if err != nil {
		logger.Errorf("ParseMavlinkBuff err %v", err)
	}
	logger.Debugf("udp read from [%s] packets len:%d left buff len %d value % x", addr.String(), len(packets), len(leftBuff), leftBuff)
	for index, req := range packets {
		logger.Debugf("packet index %d value %+v", index, req)
		reqBody, err := codec.Instance().Get(entity.DeviceType(req.GetSourceID()), codec.VersionTypeV2, uint16(req.GetMsgID()))
		if err != nil {
			logger.Errorf("GetCodec err %v devtype %d cmd %d", err, req.GetSourceID(), req.GetMsgID())
			continue
		}
		logger.Debugf("DeivceHandle req head %+v data[% x]", req.Header, req.PayLoad)
		if reqBody == nil {
			logger.Errorf("devtype %d cmd %d RspCodec nil", req.GetSourceID(), req.GetMsgID())
			continue
		}
		if err := codec.Unmarshal(codec.SerializationTypePB, req.PayLoad, reqBody); err != nil {
			logger.Errorf("req Decode err %v", err)
			continue
		}
		// 上下文增加远程地址
		ctx := context.WithValue(ctx, entity.UDPAddrCxtKey, addr)
		// 上下文增加包头
		ctx = context.WithValue(ctx, entity.PacketHeadCxtKey, req.Header)
		// 协议编解码类型
		ctx = context.WithValue(ctx, entity.ProtoTypeCxtKey, codec.SerializationTypePB)
		rsp, err := d.handler(ctx, reqBody)
		if err != nil {
			logger.Errorf("req %v Handle err %v", req, err)
			continue
		}
		buRspBuff, err := codec.Marshal(codec.SerializationTypePB, rsp)
		if err != nil {
			logger.Errorf("buRsp Encode err")
			continue
		}
		packet := &slinkv2.PacketV2{
			Header: *(slinkv2.NewMavHeader(slinkv2.WithSourceID(uint8(entity.DEV_C2_WIFI)), slinkv2.WithDestID(req.GetSourceID()),
				slinkv2.WithLen(uint16(len(buRspBuff))), slinkv2.WithMsgID(msgid.BroadCastConfirmRspMsgID))),
			PayLoad: buRspBuff,
		}
		rspBuff, err := slinkv2.Encode(packet)
		if err != nil {
			logger.Errorf("slinkv2 encode error %v", err)
			continue
		}
		if _, err = conn.WriteToUDP(rspBuff, addr); err != nil {
			logger.Errorf("conn Write to add[%s] buff[% x] err %v", addr.String(), buff, err)
			continue
		}
		logger.Debugf("conn [%s] write buff[% x] success", addr.String(), rspBuff)
	}
	return leftBuff, nil
}

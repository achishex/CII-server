package tcpserver

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/slink_proto/slinkv1"
	"adasgitlab.autel.com/tools/slink_proto/slinkv2"
	"context"
	"fmt"
	"io"
	"net"
	"strconv"
	"sync"

	entity "adasgitlab.autel.com/tools/cuav_server/entity/common"
	"adasgitlab.autel.com/tools/cuav_server/rpc/cmdhandler"
	"adasgitlab.autel.com/tools/cuav_server/rpc/codec"
	"adasgitlab.autel.com/tools/cuav_server/rpc/connmgr"
	"adasgitlab.autel.com/tools/cuav_server/rpc/task"
)

var (
	maxRecvSize        int = 1024 * 16
	tcpChannelPort     int = 8060
	tcpServerNormal    int = 1
	tcpServerNoDevConn int = 2
)

type PackageProc func(ctx context.Context, sn string, index int, data any)
type PkgProcessWrapper func(PackageProc, context.Context, int, string, int, any)

// TCPServer ...
type TCPServer struct {
	IP        string
	Port      int
	Sn        string   // 设备SN
	status    int      // 连接状态，无设备连接主动关闭
	ch        chan int // 检测连接状态channel
	PkgHandle PkgProcessWrapper
	pool      sync.Pool
}

// Opt ...
type Opt func(t *TCPServer)

// WithIP 设置IP
func WithIP(ip string) Opt {
	return func(t *TCPServer) {
		t.IP = ip
	}
}
func WithPkgParallelProc(handle PkgProcessWrapper) Opt {
	return func(t *TCPServer) {
		t.PkgHandle = handle
	}
}

// WithPort 设置端口
func WithPort(port int) Opt {
	return func(t *TCPServer) {
		t.Port = port
	}
}

// WithSn 设置Server对应的sn
func WithSn(sn string) Opt {
	return func(t *TCPServer) {
		t.Sn = sn
	}
}

// New 创建TCP服务端
func New(opts ...Opt) *TCPServer {
	server := &TCPServer{}
	for _, opt := range opts {
		opt(server)
	}
	//
	server.ch = make(chan int)
	server.InitBuf(maxRecvSize)
	return server
}

type ToReceiveBuf struct {
	buf []byte
}

func (bf *ToReceiveBuf) GetBuf() []byte {
	return bf.buf
}

func (t *TCPServer) InitBuf(bufLen int) {
	t.pool.New = func() any {
		return &ToReceiveBuf{
			buf: make([]byte, bufLen),
		}
	}
}

// Start 服务端启动
func (t *TCPServer) Start() {
	listener, err := net.Listen("tcp", t.ipString())
	if err != nil {
		logger.Errorf("tcp server listen err: %v", err)
		return
	}
	defer listener.Close()
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	logger.Debugf("tcp server start: %s", t.ipString())
	go func() {
		status := <-t.ch
		logger.Infof("recv close tcp server signal")
		if status == tcpServerNoDevConn {
			listener.Close()
		}
	}()
	t.status = tcpServerNormal
	for {
		conn, err := listener.Accept()
		if err != nil {
			logger.Errorf("tcp server accept err: %v, status: %v", err, t.status)
			if t.status != tcpServerNormal {
				return
			}
			break
		}
		logger.Debugf("tcp listen conn: %s", conn.RemoteAddr().String())
		// 设置设备对应的连接
		if err = connmgr.Instance().SetConn(t.Sn, &connmgr.DevConn{Conn: conn}); err != nil {
			logger.Errorf("sn %s SetConn err %v", t.Sn, err)
		}
		buff := make([]byte, 0)
		for {
			toRecBufItem := t.pool.Get().(*ToReceiveBuf)
			tmpBuff := toRecBufItem.GetBuf()

			n, err := conn.Read(tmpBuff)
			if err != nil {
				// 通常遇到的错误是连接中断或被关闭，用io.EOF表示
				if err == io.EOF {
					logger.Errorf("tcp conn receive close: %v", conn.RemoteAddr())
				} else {
					logger.Errorf("tcp conn receive err:%v", err)
				}
				if err := conn.Close(); err != nil {
					logger.Errorf("conn remote addr %s close err %v", conn.RemoteAddr().String(), err)
				}
				if err := connmgr.Instance().DelConn(t.Sn); err != nil {
					logger.Errorf("ConnectMgrInstance DelConn err %v", err)
				}
				t.pool.Put(toRecBufItem)
				break
			}
			if n <= 0 {
				t.pool.Put(toRecBufItem)
				continue
			}
			logger.Debugf("tcp recv from [%s] buff [% x]", conn.RemoteAddr().String(), tmpBuff[:n])
			buff = append(buff, tmpBuff[:n]...)
			// SlinkV1/V2都不是，需要继续收包
			if !slinkv1.IsSlinkV1(buff) && !slinkv2.IsSlinkV2(buff) {
				t.pool.Put(toRecBufItem)
				continue
			}
			//修改目的是： 没必要调用 make()创建一个空slice 用于接收其他函数返回的 slice
			var leftBuff []byte = nil
			if slinkv1.IsSlinkV1(buff) {
				leftBuff, err = t.handleSlinkV1(ctx, conn, buff)
				if err != nil {
					logger.Errorf("HandleSlinkV1 err: %v", err)
				}
			}
			//这里需要遍历两次确定是否v1/v2；兼容两种增加了负载，是否在组网时时协商好版本协议，tcp连接上就不需要再去版本版本？
			if slinkv2.IsSlinkV2(buff) {
				leftBuff, err = t.handleSlinkV2(ctx, conn, buff)
				if err != nil {
					logger.Errorf("HandleSlinkV2 err: %v", err)
				}
			}
			buff = buff[:0]
			if len(leftBuff) > 0 {
				buff = append(buff, leftBuff...)
			}

			t.pool.Put(toRecBufItem)
		}
	}
}

// Stop 服务端停止
func (t *TCPServer) Stop() {
	logger.Debugf("stop tcp: %s", t.ipString())
	if t.status != tcpServerNoDevConn {
		logger.Infof("send close tcp server, status: %v", t.status)
		t.status = tcpServerNoDevConn
		t.ch <- tcpServerNoDevConn
		close(t.ch)
		logger.Infof("close notify ch ok")
		// Todo:设备对应的连接是否需要关闭
	}
}

// handleSlinkV1 ...
func (t *TCPServer) handleSlinkV1(ctx context.Context, conn net.Conn, buff []byte) ([]byte, error) {
	packets, leftBuff, err := slinkv1.ParseMavlinkBuff(buff)
	if err != nil {
		logger.Errorf("slinkv1 ParseMavlinkBuff err %v", err)
	}
	logger.Debugf("tcp read from [%s] packets len:%d left buff len %d value % x", conn.RemoteAddr().String(), len(packets), len(leftBuff), leftBuff)
	for index, rsp := range packets {
		go func(sn string, index int, rsp *slinkv1.MavPacket) {
			logger.Debugf("handle packet index %d req head %+v data[% x]", index, rsp.Header, rsp.PayLoad)
			rspBody, err := codec.Instance().Get(entity.DeviceType(rsp.GetSourceID()), codec.VersionTypeV1, uint16(rsp.GetMsgID()))
			if err != nil {
				logger.Errorf("packet index %d GetCodec err %v devtype %d cmd %d", index, err, rsp.GetSourceID(), rsp.GetMsgID())
				return
			}
			if rspBody == nil {
				logger.Errorf("packet index %d devtype %d cmd %d RspCodec nil", index, rsp.GetSourceID(), rsp.GetMsgID())
				return
			}
			if err := codec.Unmarshal(codec.SerializationTypeSlink, rsp.PayLoad, rspBody); err != nil {
				logger.Errorf("req Decode err %v", err)
				return
			}
			handle, err := cmdhandler.Instance().GetHandler(entity.DeviceType(rsp.GetSourceID()), uint16(rsp.GetMsgID()))
			if err != nil {
				logger.Errorf("packet index %d Get cmd Handle err %v, header %+v", index, err, rsp.Header)
				return
			}
			buRsp, err := handle(ctx, sn, rspBody)
			if err != nil {
				logger.Errorf("packet index %d packet Handler err %v", index, err)
				return
			}
			if buRsp == nil {
				logger.Errorf("buRsp nil sn %s seq %d msgid %X task Finished", sn, rsp.GetSeq(), rsp.GetMsgID())
				return
			}

			t := task.NewTask(task.WithID(strconv.Itoa(int(rsp.GetSeq()))), task.WithResult(buRsp))
			if err := task.TaskMgrInstance().Finish(sn, uint16(rsp.GetMsgID()), t); err != nil {
				logger.Errorf("sn %s seq %d msgid %X task Finished", sn, rsp.GetSeq(), rsp.GetMsgID())
				return
			}
		}(t.Sn, index, rsp)
	}
	return leftBuff, nil
}

func (t *TCPServer) SinkV2PackageProcess(ctx context.Context, sn string, index int, data any) {
	var rsp *slinkv2.PacketV2 = data.(*slinkv2.PacketV2)
	if rsp == nil {
		return
	}

	logger.Debugf("handle packet index %d req head %+v data[% x]", index, rsp.Header, rsp.PayLoad)
	rspBody, err := codec.Instance().Get(entity.DeviceType(rsp.GetSourceID()), codec.VersionTypeV2, uint16(rsp.GetMsgID()))
	if err != nil {
		logger.Errorf("packet index %d GetCodec err %v devtype %d cmd %d", index, err, rsp.GetSourceID(), rsp.GetMsgID())
		return
	}
	if rspBody == nil {
		logger.Errorf("packet index %d devtype %d cmd %d RspCodec nil", index, rsp.GetSourceID(), rsp.GetMsgID())
		return
	}

	// 这里slink v2中居然处理slink v1的消息，是为了快速交付雷达ota升级bug
	// 雷达ota出现了 [slink v2 header] + [slink v1 payload]的杂揉实现， C2系统进行抖底处理
	// 目前有8个命令，详见 slinkv2/radarv2.go
	_, ok := rspBody.(slinkv1.Msg)
	if ok {
		if err := codec.Unmarshal(codec.SerializationTypeSlink, rsp.PayLoad, rspBody); err != nil {
			logger.Errorf("req Decode err %v", err)
			return
		}
	} else {
		if err := codec.Unmarshal(codec.SerializationTypePB, rsp.PayLoad, rspBody); err != nil {
			logger.Errorf("req Decode err %v", err)
			return
		}
	}
	handle, err := cmdhandler.Instance().GetHandler(entity.DeviceType(rsp.GetSourceID()), uint16(rsp.GetMsgID()))
	if err != nil {
		logger.Errorf("packet index %d Get cmd Handle err %v, header %+v", index, err, rsp.Header)
		return
	}
	buRsp, err := handle(ctx, sn, rspBody)
	if err != nil {
		logger.Errorf("packet index %d packet Handler err %v", index, err)
		return
	}
	if buRsp == nil {
		logger.Errorf("buRsp nil sn %s seq: %d msgid: 0X%X task Finished", sn, rsp.GetSeq(), rsp.GetMsgID())
		return
	}

	//monitoring.DevCounterMetricHandle.Inc(int(rsp.GetSourceID()), sn, fmt.Sprintf("%x", rsp.GetMsgID()))

	tsk := task.NewTask(task.WithID(strconv.Itoa(int(rsp.GetSeq()))), task.WithResult(buRsp))
	if err := task.TaskMgrInstance().Finish(sn, uint16(rsp.GetMsgID()), tsk); err != nil {
		logger.Errorf("sn %s seq: %d msgid: 0X%X task Finished", sn, rsp.GetSeq(), rsp.GetMsgID())
		return
	}
}

// handleSlinkV2 ...
func (t *TCPServer) handleSlinkV2(ctx context.Context, conn net.Conn, buff []byte) ([]byte, error) {
	packets, leftBuff, err := slinkv2.ParseMavlinkBuff(buff)
	if err != nil {
		logger.Errorf("slinkv2 ParseMavlinkBuff err %v", err)
	}
	logger.Debugf("tcp read from [%s] packets len:%d left buff len %d value % x", conn.RemoteAddr().String(), len(packets), len(leftBuff), leftBuff)

	for index, rsp := range packets {
		t.PkgHandle(t.SinkV2PackageProcess, ctx, int(codec.SerializationTypePB), t.Sn, index, rsp)
	}
	return leftBuff, nil
}

// ipString
func (t *TCPServer) ipString() string {
	return net.JoinHostPort(t.IP, fmt.Sprint(t.Port))
}

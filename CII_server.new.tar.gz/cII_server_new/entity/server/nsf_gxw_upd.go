package server

import (
	"encoding/json"
	"errors"
	"fmt"
	"net"
	"strconv"
	"strings"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/config"
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/ip"
)

var GnsfHeart bool

type UdpProcessor interface {
	Handle(dConn, pConn *net.UDPConn, ver, showIp string)
}
type UdpNSF struct {
	dConn     *net.UDPConn
	dAddr     string
	sMsg      []byte
	pConn     *net.UDPConn
	pAddr     string
	rMsg      []byte
	ctrl      UdpProcessor
	devNum    string
	dAddrShow string
}

func NewUdpNsf() *UdpNSF {
	dIp := config.GetGlobalConfig().Server.NsfgxwIp
	dPort := config.GetGlobalConfig().Server.NsfgxwPort
	dAddr := "192.168.10.230:9099"
	if len(dIp) != 0 && dPort != 0 {
		dAddr = fmt.Sprintf("%s:%d", dIp, dPort)
	}
	return &UdpNSF{
		dAddr:     dAddr,
		dAddrShow: dIp,
		// pAddr: "0.0.0.0:9098",
		pAddr: "192.168.10.20:9098",
	}
}

func (u *UdpNSF) getClientIp() (string, error) {
	// addrs, err := net.InterfaceAddrs()
	addrs, err := ip.InterfaceAddrs()

	if err != nil {
		return "", err
	}

	for _, address := range addrs {
		// 检查ip地址判断是否回环地址
		if ipnet, ok := address.(*net.IPNet); ok && !ipnet.IP.IsLoopback() {
			if ipnet.IP.To4() != nil {
				strIP := ipnet.IP.String()
				logger.Debug("strIP = ", strIP)
				if strings.Contains(strIP, "192.168.") {
					return strIP, nil
				}
			}

		}
	}

	return "", errors.New("Can not find the client ip address!")

}
func (u *UdpNSF) WithPcAddr() *UdpNSF {
	addr, err := u.getClientIp()
	logger.Debug("addr = ", addr)
	if err == nil {
		u.pAddr = fmt.Sprintf("%s:%d", addr, 9098)
	}
	return u
}
func (u *UdpNSF) WithHandler(p UdpProcessor) *UdpNSF {
	u.ctrl = p
	return u
}

func (u *UdpNSF) WithDevAddr(addr string) *UdpNSF {
	u.dAddr = addr
	return u
}

func (u *UdpNSF) Run() {
	defer func() {
		if err := recover(); err != nil {
			logger.Debug("udp nsf gxw run err:", err)
		}
	}()
	GnsfHeart = false
	var isBindaddr bool
	for {
		logger.Debug("try to start build connect..")
		var showIp string
		for {
			time.Sleep(1 * time.Second)
			logger.Info("Run connect NFSGXW,u.sAddr = ", u.dAddr)
			udpaddr, err := net.ResolveUDPAddr("udp", u.dAddr)
			if err != nil {
				logger.Error("ResolveUDPAddr, err:", err)
				continue
			}
			sconn, err := net.DialUDP("udp", nil, udpaddr)
			if err != nil {
				logger.Error("DialUDP, err:", err)
				continue
			}
			logger.Debug("dial nsf_gxw ok, sconn = ", sconn.LocalAddr().String(), " <-> ", sconn.RemoteAddr().String())
			u.dConn = sconn

			localIp, err := u.getClientIp()
			if err != nil {
				logger.Debug("err = ", err)
				continue
			}
			payload := u.updateIPPort619Fun("a57502fcdc4e7412", localIp, 9098)
			u.dConn.SetDeadline(time.Now().Add(3 * time.Second))
			n, err := u.dConn.Write([]byte(payload))
			if err != nil {
				logger.Debug("write err = ", err)
			}
			logger.Debug("payload = ", payload, ", n = ", n)
			readbuf := make([]byte, 4*1024)

			n, _, err = u.dConn.ReadFromUDP(readbuf)
			if err != nil {
				logger.Debug("err = ", err)
				continue
			}
			if n <= 0 {
				logger.Debug("n = ", n)
				continue
			}
			logger.Debug("readbuf = ", string(readbuf[:n]))
			sn := string(readbuf[47:63])
			logger.Debug("upload nsfgxw devnum = ", sn)
			u.devNum = sn

			logger.Debug("n = ", n)
			logger.Debug("paload = ", payload)

			//=======
			u.pAddr = fmt.Sprintf("%s:%d", localIp, 9098)
			logger.Debug("u.pAddr  = ", u.pAddr)
			addr, err := net.ResolveUDPAddr("udp", u.pAddr)
			if err != nil {
				logger.Debug("resolveudp err = ", err)
				continue
			}
			logger.Debug("add = ", addr)
			rconn, err := net.ListenUDP("udp", addr)
			if err != nil {
				logger.Debug("err = ", err)
				logger.Debug("err str = ", err.Error())
				logger.Debug("ListenUDP rconn ", rconn)
				if !isBindaddr {
					logger.Debug("first bind addr.")
					continue
				}

			}
			logger.Debug("ever bind addr.")
			isBindaddr = true
			if rconn != nil {
				u.pConn = rconn
			}

			// showIp = localIp
			break
		}
		logger.Debug("start rcv msg")
		payload := u.update631Fun()
		u.dConn.SetDeadline(time.Now().Add(3 * time.Second))
		n, err := u.dConn.Write([]byte(payload))
		if err != nil {
			logger.Debug("write err = ", err)
		}
		logger.Debug("payload = ", payload, ", n = ", n)
		readbuf := make([]byte, 4*1024)

		n, _, err = u.dConn.ReadFromUDP(readbuf)
		if err != nil {
			logger.Debug("err = ", err)
		}
		// logger.Debug("version = ",version)
		// ver := string(readbuf[20 : 20+6])
		versionMsg := nsfGXWVersion{}
		logger.Debug("versionMsg read buf = ", string(readbuf[:n]))
		dataLen, _ := strconv.Atoi(string(readbuf[2:6]))

		logger.Debug("data buf = ", string(readbuf[9:dataLen+9]))
		logger.Debug("dataLen = ", dataLen)
		err = json.Unmarshal(readbuf[9:dataLen+9], &versionMsg)
		if err != nil {
			logger.Debug("err umar json = ", err)
		}
		ver := versionMsg.SARMVer + "." + versionMsg.SFPGAVer
		// showIp := u.pAddr
		u.dConn.SetDeadline(time.Time{})
		showIp = u.dAddrShow
		time.Sleep(1 * time.Second)
		// if time.Since(GnsfHeart) > 2*time.Second {
		if !GnsfHeart {
			go u.ctrl.Handle(u.dConn, u.pConn, ver, showIp)
		}
		// }
		GnsfHeart = true
		u.keepAlive()
	}

}

func (u *UdpNSF) keepAlive() {
	defer func() {
		if r := recover(); r != nil {
			err := fmt.Errorf("panic: %v", r)
			logger.Error("panic:", err)
		}
	}()
	payload := u.update615Fun()
	_, err := u.dConn.Write([]byte(payload))
	if err != nil {
		logger.Debug("update615Fun write err = ", err)
		return
	}
	// readbuf := make([]byte, 4*1024)

	// n, _, err := u.dConn.ReadFromUDP(readbuf)
	// if err != nil {
	// 	logger.Debug("err = ", err)
	// }
	// logger.Debug("readbuf = ", string(readbuf[:n]))

	payload = u.update625Fun()
	_, err = u.dConn.Write([]byte(payload))
	if err != nil {
		logger.Debug("update625Fun write err = ", err)
	}

	// n, _, err = u.dConn.ReadFromUDP(readbuf)
	// if err != nil {
	// 	logger.Debug("err = ", err)
	// }
	// logger.Debug("readbuf = ", string(readbuf[:n]))

	payload = u.update626Fun()
	_, err = u.dConn.Write([]byte(payload))
	if err != nil {
		logger.Debug("update625Fun write err = ", err)
	}
	logger.Debug("626 payload = ", payload)

	// n, _, err = u.dConn.ReadFromUDP(readbuf)
	// if err != nil {
	// 	logger.Debug("err = ", err)
	// }
	// logger.Debug("readbuf = ", string(readbuf[:n]))

	ticker := time.NewTicker(1 * time.Second)
	logger.Debug("devNum = ", u.devNum)
	for range ticker.C {
		sDevNum := "47583301a36e59a5"

		payload = u.update600Fun(sDevNum)
		// payload = u.update600Fun(u.devNum)
		_, err := u.dConn.Write([]byte(payload))
		if err != nil {
			logger.Debug("update600Fun write err = ", err)
			return
		}
		logger.Debug("payload = ", payload)
		if !GnsfHeart {
			logger.Debug(" revice heart,time out", GnsfHeart)
			return
		}
		// n, _, err = u.dConn.ReadFromUDP(readbuf)
		// if err != nil {
		// 	logger.Debug("err = ", err)
		// }
		// logger.Debug("readbuf = ", string(readbuf[:n]))
	}

}

const (
	header = "FF"
)

type updateIPPort619 struct {
	SKey  string `json:"sKey"`
	SIP   string `json:"sIP"`
	IPort int    `json:"iPort"`
}

type update631 struct {
	SKey    string `json:"sKey"`
	SSysVer string `json:"sSysVer"`
}

func (u *UdpNSF) update631Fun() string {

	body := &update631{
		SKey:    "a57502fcdc4e7412",
		SSysVer: "SYSVER",
	}
	return u.formPkg(body, "631")
}

// 心跳检测开关
type update625 struct {
	SKey              string `json:"sKey"`
	ISwitchHeartParse int    `json:"iSwitchHeartParse"`
}

// 心跳检测开关
type update626 struct {
	SKey         string `json:"sKey"`
	IEmitOffTime int    `json:"iEmitOffTime"`
}

// 心跳检测开关
type update600 struct {
	SKey    string `json:"sKey"`
	SDevNum string `json:"sDevNum"`
	IState  int    `json:"iState"`
}
type update615 struct {
	SKey   string `json:"sKey"`
	ICycle int    `json:"iCycle"`
}

func (u *UdpNSF) update615Fun() string {

	body := &update615{
		SKey:   "a57502fcdc4e7412",
		ICycle: 1,
	}
	return u.formPkg(body, "615")
}
func (u *UdpNSF) updateIPPort619Fun(skey, sip string, port int) string {
	if skey == "" && sip == "" && port == 0 {
		skey = "a57502fcdc4e7412"
		sip = "192.168.10.8"
		port = 9098
	}

	body := &updateIPPort619{
		SKey:  skey,
		SIP:   sip,
		IPort: port,
	}
	return u.formPkg(body, "619")
}

func (u *UdpNSF) update625Fun() string {

	body := &update625{
		SKey:              "a57502fcdc4e7412",
		ISwitchHeartParse: 1,
	}
	return u.formPkg(body, "625")
}

func (u *UdpNSF) update626Fun() string {

	body := &update626{
		SKey:         "a57502fcdc4e7412",
		IEmitOffTime: 5,
	}
	return u.formPkg(body, "626")
}

func (u *UdpNSF) update600Fun(devNum string) string {

	body := &update600{
		SKey: "a57502fcdc4e7412",
		// SDevNum: devNum,
		SDevNum: "47583301a36e59a5",
		IState:  1,
	}
	return u.formPkg(body, "600")
}

func (u *UdpNSF) formPkg(v any, c string) string {
	data, err := json.Marshal(v)
	if err != nil {
		logger.Debug("data")
	}

	pkgLen := fmt.Sprintf("%04d", len(data))

	pkg := header + pkgLen + c + string(data)
	logger.Debug("pkg = ", pkg)
	return pkg
}

type nsfGXWVersion struct {
	SKey      string  `json:"sKey"`
	SDevNum   string  `json:"sDevNum"`
	IState    int     `json:"iState"`
	SARMVer   string  `json:"sARMVer"`
	SFPGAVer  string  `json:"sFPGAVer"`
	FCPUUsage float32 `json:"fCPUUsage"`
	IAuthInfo int     `json:"iAuthInfo"`
	SAuthCode string  `json:"sAuthCode"`
}

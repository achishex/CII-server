package server

import (
	"context"
	"fmt"
	"net"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
)

var (
	UdpBroadcastListenPort int = 1810
)

type UdpReceiveCallBack func(ctx context.Context, conn *net.UDPConn) error

type UdpServer struct {
	Address string
	Handle  UdpReceiveCallBack
}

func NewUdpServer(port int, handle UdpReceiveCallBack) *UdpServer {
	return &UdpServer{
		Address: fmt.Sprintf("0.0.0.0:%d", port),
		Handle:  handle,
	}
}

func (s *UdpServer) Start() {
	addr, err := net.ResolveUDPAddr("udp", s.Address)
	if err != nil {
		logger.Error("Resolve UDP Addr err:", err)
		return
	}
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	logger.Info("udp server start:", s.Address)
	conn, err := net.ListenUDP("udp", addr)
	if err != nil {
		logger.Error("udp server listen err:", err)
		return
	}
	defer conn.Close()
	logger.Info("udp listen conn:", s.Address)
	if err = s.Handle(ctx, conn); err != nil {
		logger.Errorf("Udp Handle err %v", err)
	}
}

func (s *UdpServer) Stop() {

}

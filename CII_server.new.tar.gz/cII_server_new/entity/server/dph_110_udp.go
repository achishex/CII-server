package server

import (
	"context"
	"fmt"
	"net"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"

	"adasgitlab.autel.com/tools/cuav_server/entity/config"
)

type UdpDPHProcessor interface {
	Handle(ctx context.Context, devIP string, pConn *net.UDPConn)
}

type UdpDPH struct {
	devConn *net.UDPConn //一体机
	devAddr string
	pConn   *net.UDPConn //显控
	pAddr   string
	ctrl    UdpDPHProcessor
	devIp   string //一体机IP
	ctx     context.Context
}

func NewUdpDPH(proc UdpDPHProcessor) *UdpDPH {
	//一体机
	devIp := config.GetGlobalConfig().Server.Udp110Ip
	devPort := config.GetGlobalConfig().Server.Udp110Port
	devAddr := "192.168.2.133:7000"
	if len(devIp) != 0 && devPort != 0 {
		devAddr = fmt.Sprintf("%s:%d", devIp, devPort)
	}
	//C2
	c2Ip := config.GetGlobalConfig().Server.C2110Ip
	c2Port := config.GetGlobalConfig().Server.C2110Port
	c2Addr := "192.168.2.132:8000"
	if len(c2Ip) != 0 && c2Port != 0 {
		c2Addr = fmt.Sprintf("%s:%d", c2Ip, c2Port)
	}
	return &UdpDPH{
		devAddr: devAddr,
		pAddr:   c2Addr,
		ctrl:    proc,
		devIp:   devIp,
	}
}

func (d *UdpDPH) Run() {
	defer func() {
		if err := recover(); err != nil {
			logger.Errorf("udp DPH run err: %v", err)
		}
	}()
	ctx, cancel := context.WithCancel(context.Background())
	d.ctx = ctx
	defer cancel()
	now := time.Now()
	errCount := 0
	for {
		//logger.Debug("try to connect DPH110...")
		//addr, err := net.ResolveUDPAddr("udp", d.devAddr)
		//if err != nil {
		//	logger.Errorf("Run ResolveUDPAddr devAddr err: %v", err)
		//	continue
		//}
		//devConn, err := net.DialUDP("udp", nil, addr)
		//if err != nil {
		//	logger.Errorf("Run DialUDP devAddr err: %v", err)
		//	continue
		//}
		//logger.Debug("connect DPH110 success", devConn.LocalAddr().String(), "<->", devConn.RemoteAddr().String())
		//d.devConn = devConn
		pAddr, err := net.ResolveUDPAddr("udp", d.pAddr)
		if err != nil {
			logger.Errorf("Run ResolveUDPAddr pAddr err: %v", err)
			continue
		}
		pConn, err := net.ListenUDP("udp", pAddr)
		if err != nil {
			if errCount == 0 {
				logger.Errorf("Run ListenUDP pAddr err: %v", err)
			}
			errCount++
			if time.Since(now) > time.Second*1 {
				now = time.Now()
				errCount = 0
			}
			continue
		}
		logger.Debug("listen DPH110 success", pConn.LocalAddr().String())
		d.pConn = pConn
		d.ctrl.Handle(ctx, d.devIp, d.pConn)
	}
}

package helper

import (
	"github.com/stretchr/testify/assert"
	"reflect"
	"testing"
)

func TestListFiles(t *testing.T) {
	type args struct {
		folderPath string
	}
	tests := []struct {
		name string
		args args
		want map[string]float64
	}{
		{
			name: "Case1",
			args: args{
				folderPath: "./",
			},
			want: map[string]float64{"filehelper.go": 3.0400390625, "filehelper_test.go": 2.220703125},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := ListFiles(tt.args.folderPath)
			for k, v := range got {
				if res, ok := tt.want[k]; ok {
					if int(res) != int(v) {
						t.Errorf("ListFiles() = %v, want %v", got, tt.want)
					}
				}
			}
		})
	}
}

func TestFindFileMoreDir(t *testing.T) {
	type args struct {
		root     string
		fileName string
	}
	tests := []struct {
		name    string
		args    args
		want    []string
		wantErr bool
	}{
		{
			name: "No file found",
			args: args{
				root:     "/path/to/directory",
				fileName: "unknown.txt",
			},
			want:    nil,
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := FindFileMoreDir(tt.args.root, tt.args.fileName)
			if (err != nil) != tt.wantErr {
				t.Errorf("FindFileMoreDir() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("FindFileMoreDir() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestCreateDirIfNotExist(t *testing.T) {
	type args struct {
		path string
	}
	tests := []struct {
		name    string
		args    args
		wantErr bool
	}{
		{
			name: "Case1",
			args: args{
				path: "/tmp/tmp.txt",
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if err := CreateDirIfNotExist(tt.args.path); (err != nil) != tt.wantErr {
				t.Errorf("CreateDirIfNotExist() error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

func TestFindfile(t *testing.T) {
	type args struct {
		path string
	}
	tests := []struct {
		name string
		args args
		want []string
	}{
		// {
		// 	name: "Case1",
		// 	args: args{
		// 		path: "./",
		// 	},
		// 	want: []string{"filehelper.go", "c2uuid.go", "filehelper_test.go"},
		// },
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := Findfile(tt.args.path); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("Findfile() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestClearSlice(t *testing.T) {
	x := []int{1, 2, 3, 4, 5}
	x = ClearSlice[int](x)
	assert.Equal(t, len(x), 0)
}

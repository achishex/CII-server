package helper

import (
	"context"
	"reflect"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
)

// TaskProcess 定时器任务的业务逻辑 实体需要实现的接口。
type TaskProcess interface {
	Process() error
}

// GeneralTaskTimer 定义个通用定时器任务
type GeneralTaskTimer struct {
	dur        time.Duration
	tk         *time.Ticker
	onceTask   TaskProcess
	taskName   string
	printIndex uint32
}

// InitTaskItems 定义一个初始化 GeneralTaskTimer类型的函数变量
type InitTaskItems func(*GeneralTaskTimer)

// RegisterTaskProcess 给业务方调用，注册业务在定时器任务中执行的逻辑。
func RegisterTaskProcess(p TaskProcess) InitTaskItems {
	return func(tmrTask *GeneralTaskTimer) {
		tmrTask.onceTask = p
		if reflect.TypeOf(p).Kind() == reflect.Ptr {
			tmrTask.taskName = reflect.ValueOf(p).Elem().Type().Name()
		} else {
			tmrTask.taskName = reflect.ValueOf(p).Type().Name()
		}
	}
}

// NewGeneralTaskTimer  waitTm format like: "1ms", "200ms", "1s"
// how to use, call: NewGeneralTaskTimer("100ms", RegisterTaskProcess(logic_proc_demo))
func NewGeneralTaskTimer(waitTm string, ops ...InitTaskItems) *GeneralTaskTimer {
	t, e := time.ParseDuration(waitTm)
	if e != nil {
		logger.Errorf("parse time fail, e: %v", e)
		return nil
	}
	v := &GeneralTaskTimer{
		dur:        t,
		tk:         time.NewTicker(t),
		printIndex: 0,
	}

	for _, op := range ops {
		op(v)
	}
	return v
}

// ResetTimeDur 重置定时器的时间间隔
func (gtt *GeneralTaskTimer) ResetTimeDur(waitTmStr string) {
	t, e := time.ParseDuration(waitTmStr)
	if e != nil {
		logger.Errorf("[ %v ] parse timer time fail, e: %v", e, gtt.taskName)
		return
	}
	if t == gtt.dur {
		gtt.printIndex = 0
		return
	}

	gtt.dur = t
	gtt.printIndex = 0
	logger.Infof("[ %v ] reset timer tm: %v, %v ", gtt.taskName, waitTmStr, gtt.dur)
	gtt.tk.Reset(gtt.dur)
}

// DoTask 定时器任务执行
func (gtt *GeneralTaskTimer) DoTask(ctx context.Context) {
	go func() {
		defer func() {
			gtt.tk.Stop()
			if e := recover(); e != nil {
				logger.Errorf("[ %v ] timer check panic, e: %v", e, gtt.taskName)
				return
			}
		}()

		for {
			select {
			case <-gtt.tk.C:
				gtt.onceTask.Process()
				if gtt.printIndex%100 == 0 {
					logger.Infof("[ %v ] run timer process on accumulative times 100  --->", gtt.taskName)
				}
				gtt.printIndex++

			case <-ctx.Done():
				logger.Infof("[ %v ] receive task timer stop, timer run nums: %v", gtt.taskName, gtt.printIndex+1)
				return
			}
		}
	}()

}

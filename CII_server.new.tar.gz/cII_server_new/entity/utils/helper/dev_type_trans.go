package helper

import (
	"adasgitlab.autel.com/tools/cuav_server/proto/client"
	"golang.org/x/exp/constraints"
)

const (
	DevTypeDescRadar    string = "radar"
	DevTypeDescTraceP   string = "traceP"
	DevTypeDescTracerS  string = "tracerS"
	DevTypeDescFpv      string = "Fpv"
	DevTypeDescRF       string = "RF"
	DevTypeDescSfl      string = "Sfl"
	DevTypeDescSpoofer  string = "Spoofer"
	DevTypeDescTracerRF string = "tracerRF"
	//
	DevTypeUnionTracer string = "DroneID"
	DevTracerPro       string = "tracerPro"
	DevTypeGunPlatform string = "GunPlatform"
	DevTypeTracerGun   string = "TracerGun"
	DevTypeDescSfl101  string = "Sfl101"
)

type DevTypStrEnumMap struct {
	StrToInt32Map map[string]int32
	Int32ToStrMap map[int32]string
}

var DevTypeMapsNode DevTypStrEnumMap

func init() {
	DevTypeMapsNode = DevTypStrEnumMap{
		StrToInt32Map: map[string]int32{
			DevTypeDescRadar:    int32(client.EnumDevTypeList_RadarDevTypeEnum),   //radar 雷达，
			DevTypeDescTraceP:   int32(client.EnumDevTypeList_TracerPDevTypeEnum), //tracerP
			DevTypeDescTracerS:  int32(client.EnumDevTypeList_TracerSDevTypeEnum), // EnumDevTypeList = 3 //tracerS
			DevTypeDescFpv:      int32(client.EnumDevTypeList_FpvDevTypeEnum),     //    EnumDevTypeList = 4 //fpv 车载FPV
			DevTypeDescRF:       int32(client.EnumDevTypeList_GunDevTypeEnum),     //     EnumDevTypeList = 5 //gun/screen 大枪（非云台）
			DevTypeDescSfl:      int32(client.EnumDevTypeList_SFLDevTypeEnum),     //    EnumDevTypeList = 6 //sfl 哨兵塔
			DevTypeDescSpoofer:  int32(client.EnumDevTypeList_SpooferDevTypeEnum), // EnumDevTypeList = 7 // dev_nsf4000  导航诱导
			DevTypeDescTracerRF: int32(client.EnumDevTypeList_UrdDevTypeEnum),     //    EnumDevTypeList = 8 //dev_urd360 坤雷RF
			DevTracerPro:        int32(client.EnumDevTypeList_TracerPro),
			DevTypeGunPlatform:  int32(client.EnumDevTypeList_GunCloud), //枪+云台
			DevTypeDescSfl101:   int32(client.EnumDevTypeList_Sfl101),
		},
	}
	DevTypeMapsNode.Int32ToStrMap = make(map[int32]string)
	for k, v := range DevTypeMapsNode.StrToInt32Map {
		DevTypeMapsNode.Int32ToStrMap[v] = k
	}
}

func DevTypeFromStrToInt(devTypeStr string) int32 {
	if v, ok := DevTypeMapsNode.StrToInt32Map[devTypeStr]; ok {
		return v
	}
	return 0
}

func DevTypeFromIntToStr(devTypeInt int32) string {
	if v, ok := DevTypeMapsNode.Int32ToStrMap[devTypeInt]; ok {
		return v
	}
	return ""
}

func TranBaseType[DstT constraints.Integer | constraints.Float,
	SrcT constraints.Integer | constraints.Float](src SrcT) DstT {
	return DstT(src)
}

func ClearSlice[T any](sliceData []T) []T {
	if sliceData == nil || len(sliceData) <= 0 {
		return []T{}
	}
	r := sliceData[:0]
	return r
}

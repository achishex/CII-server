package helper

import (
	"container/heap"
	"fmt"
)

type SkyFendPQItem[T any] struct {
	Value    T
	Priority int64
	Index    int32
}

func (i *SkyFendPQItem[T]) String() string {
	s := fmt.Sprintf("priority: %v, value: %v", i.Priority, i.Value)
	return s
}

type SkyFendPQ[T any] struct {
	Items []*SkyFendPQItem[T]
	//SafeLocker sync.Mutex
}

func (spq *SkyFendPQ[T]) Len() int {
	//spq.SafeLocker.Lock()
	//defer spq.SafeLocker.Unlock()

	return len(spq.Items)
}

func (spq *SkyFendPQ[T]) Less(i, j int) bool {
	//spq.SafeLocker.Lock()
	//defer spq.SafeLocker.Unlock()

	return spq.Items[i].Priority < spq.Items[j].Priority
}

func (spq *SkyFendPQ[T]) Swap(i, j int) {
	//spq.SafeLocker.Lock()
	//defer spq.SafeLocker.Unlock()
	spq.Items[i], spq.Items[j] = spq.Items[j], spq.Items[i]
	// fmt.Printf("len(spq.Items) = %d, i = %d, j = %d \n", len(spq.Items), i, j)
	// fmt.Printf("spq.Items[%d].Index = %d\n", i, spq.Items[i].Index)
	spq.Items[i].Index = int32(i)
	spq.Items[j].Index = int32(j)
}

func (spq *SkyFendPQ[T]) Push(dataGen any) {
	//spq.SafeLocker.Lock()
	//defer spq.SafeLocker.Unlock()

	data := dataGen.(*SkyFendPQItem[T])
	n := len(spq.Items)
	data.Index = int32(n)
	spq.Items = append(spq.Items, data)
}

func (spq *SkyFendPQ[T]) Pop() any {
	//spq.SafeLocker.Lock()
	//defer spq.SafeLocker.Unlock()

	o := spq.Items
	n := len(o)
	item := o[n-1]
	o[n-1] = nil // avoid memory leak
	item.Index = -1
	spq.Items = spq.Items[0 : n-1]
	return item
}

type SkyFendPQWrap[T any] struct {
	PqIn *SkyFendPQ[T]
}

func (sfp *SkyFendPQWrap[T]) Len() int {
	if sfp.PqIn == nil {
		return 0
	}
	return sfp.PqIn.Len()
}
func (sfp *SkyFendPQWrap[T]) Push(data *SkyFendPQItem[T]) {
	heap.Push(sfp.PqIn, data)
}
func (sfp *SkyFendPQWrap[T]) Pop() *SkyFendPQItem[T] {
	if sfp.PqIn.Len() <= 0 { //pop when len <=0 will cause out of range
		return nil
	}
	x := heap.Pop(sfp.PqIn)
	ret, ok := x.(*SkyFendPQItem[T])
	if !ok {
		return nil
	}
	return ret
}
func NewSkyFendWrap[T any]() *SkyFendPQWrap[T] {
	sfp := &SkyFendPQWrap[T]{
		PqIn: new(SkyFendPQ[T]),
	}
	heap.Init(sfp.PqIn)
	return sfp
}

// PopLesserPriority return items with priority less than or equal to p
func (sfp *SkyFendPQWrap[T]) PopLesserPriority(p int64) []*SkyFendPQItem[T] {
	if sfp == nil {
		return nil
	}
	if sfp.Len() <= 0 {
		return nil
	}
	var ret []*SkyFendPQItem[T]

	for {
		item := sfp.Pop()
		if item == nil {
			return ret
		}
		if item.Priority > p {
			sfp.Push(item)
			return ret
		}
		ret = append(ret, item)
	}
}

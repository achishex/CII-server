//go:build linux || android

package ip

import (
	"fmt"
	"net"
	"strconv"
	"strings"
	"syscall"
	"unsafe"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
)

// Workaround for github.com/golang/go/issues/40569
// (Calling net.InterfaceAddrs() fails on Android SDK 30)
//
//
// This relies on getifaddrs, which requires SDK 24 (Android 7.0 Nougat)

/*
#include <ifaddrs.h>
#include <arpa/inet.h>
#include <net/if.h>
*/
import "C"

// GetBroadcastAddress 返回本地地址及对应广播地址列表
func GetBroadcastAddress() ([]string, []string, error) {
	var localAddrs []string
	var broadcastAddrs []string
	interfaces, err := interfaces() // 获取所有网络接口
	if err != nil {
		return localAddrs, broadcastAddrs, err
	}

	for _, face := range interfaces {
		// 选择 已启用的、能广播的、非回环 的接口
		if (face.Flags & (net.FlagUp | net.FlagBroadcast | net.FlagLoopback)) == (net.FlagBroadcast | net.FlagUp) {
			addrs, err := face.getAddrs()
			if err != nil {
				return localAddrs, broadcastAddrs, err
			}
			for _, addr := range addrs {
				if ipNet, ok := addr.(*net.IPNet); ok {
					// 只取IPv4的
					if ipNet.IP.To4() != nil {
						// 用于存放广播地址字段（共4个字段）
						var fields net.IP
						for i := 0; i < 4; i++ {
							ipSec := ipNet.IP.To4()[i]
							maskSec := ipNet.Mask[i]
							//ip先按位与mask ,再或mask的反
							fields = append(fields, (ipSec&maskSec)|(^ipNet.Mask[i])) // 计算广播地址各个字段
						}
						broadAddr := fields.String()
						localAddrs = append(localAddrs, ipNet.IP.To4().String())
						broadcastAddrs = append(broadcastAddrs, broadAddr)
					}
				}
			}
		}
	}

	return localAddrs, broadcastAddrs, err
}

// GetLocalIp 根据对方ip获取对应本地ip
func GetLocalIp(remoteIp string) (string, error) {
	remoteArr := net.ParseIP(remoteIp).To4()
	if remoteArr == nil {
		logger.Error("ip 转换错误：", remoteIp)
		return "", fmt.Errorf("ip 转换错误: %s", remoteIp)
	}
	addrs, err := interfaceAddrs()
	if err != nil {
		logger.Error("获取ip地址错误：", err)
		return "", fmt.Errorf("获取ip地址错误: %v", err)
	}
	var ips string
	for _, address := range addrs {
		// 检查ip地址判断是否回环地址
		if ipNet, ok := address.(*net.IPNet); ok && !ipNet.IP.IsLoopback() {
			localArr := ipNet.IP.To4()
			if localArr != nil && len(localArr) > 0 {
				mask := ipNet.Mask
				if (remoteArr[0]&mask[0] == localArr[0]&mask[0]) &&
					(remoteArr[1]&mask[1] == localArr[1]&mask[1]) &&
					(remoteArr[2]&mask[2] == localArr[2]&mask[2]) && (remoteArr[3]&mask[3] == localArr[3]&mask[3]) {
					ips = ipNet.IP.String()
					return ips, nil
				}
			}
		}
	}
	return ips, nil
}

// GetFreeTcpPort gets a free tcp port.
func GetFreeTcpPort() (port int, err error) {
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		return 0, err
	}
	defer listener.Close()

	return listener.Addr().(*net.TCPAddr).Port, nil
}

// IPV4 字符串IP转换成IPv4
func IPV4(ip string) [4]uint8 {
	ips := net.ParseIP(ip)
	if ips == nil {
		logger.Errorf("invalid ip %s", ip)
		return [4]uint8{}
	}
	ipBytes := ips.To4()
	if ipBytes == nil {
		logger.Errorf("invalid ipv4 ip")
		return [4]uint8{}
	}
	var addr [4]uint8
	copy(addr[:], ipBytes)
	return addr
}

func interfaces() ([]inf, error) {
	var addr *C.struct_ifaddrs
	ret, err := C.getifaddrs(&addr)
	if ret != 0 {
		return nil, fmt.Errorf("getifaddrs: %w", err.(syscall.Errno))
	}
	defer C.freeifaddrs(addr)

	interfaces := make(map[string]inf)
	curr := addr

	var iface inf
	for {
		if curr == nil {
			break
		}

		iface = makeInterface(curr)

		// getifaddrs() returns a separate list entry for AF_INET and AF_INET6 addresses, but the
		// other fields are identical. Merge into a single entry as net.Interfaces() does.
		if existing, ok := interfaces[iface.Name]; ok {
			iface.addrs = append(iface.addrs, existing.addrs...)
		}

		// Replaces (potentially) existing with merged version
		interfaces[iface.Name] = iface

		// Advance to next item in linked list
		curr = curr.ifa_next
	}

	s := make([]inf, 0)
	for _, iface = range interfaces {
		s = append(s, iface)
	}
	return s, nil
}

func interfaceAddrs() ([]net.Addr, error) {
	var addr *C.struct_ifaddrs
	ret, err := C.getifaddrs(&addr)
	if ret != 0 {
		return nil, fmt.Errorf("getifaddrs: %w", err.(syscall.Errno))
	}
	defer C.freeifaddrs(addr)

	interfaces := make(map[string]inf)
	curr := addr

	var iface inf
	for {
		if curr == nil {
			break
		}

		iface = makeInterface(curr)

		// getifaddrs() returns a separate list entry for AF_INET and AF_INET6 addresses, but the
		// other fields are identical. Merge into a single entry as net.Interfaces() does.
		if existing, ok := interfaces[iface.Name]; ok {
			iface.addrs = append(iface.addrs, existing.addrs...)
		}

		// Replaces (potentially) existing with merged version
		interfaces[iface.Name] = iface

		// Advance to next item in linked list
		curr = curr.ifa_next
	}

	s := make([]net.Addr, 0)
	for _, iface = range interfaces {
		s = append(s, iface.addrs...)
	}
	return s, nil
}

type inf struct {
	net.Interface
	addrs []net.Addr
}

func (i *inf) getAddrs() ([]net.Addr, error) {
	return i.addrs, nil
}

func makeInterface(ifa *C.struct_ifaddrs) (i inf) {
	i.Name = C.GoString(ifa.ifa_name)
	i.Flags = linkFlags(uint32(ifa.ifa_flags))
	i.Index = index(ifa)
	i.addrs = []net.Addr{}

	// getifaddrs doesn't supply this, but it could be fetched via SIOCGIFMTU if needed
	i.MTU = 0

	// HardwareAddr (MAC) is not populated -- this whole package is needed because Android
	// locked down RTM_GETLINK to prevent access to the MAC. The rest of the Interface fields
	// were collateral damage.

	// Not all interfaces have an addr (e.g. VPNs)
	if ifa.ifa_addr == nil {
		return
	}

	var ip string
	var mask string
	family := int(ifa.ifa_addr.sa_family)
	switch family {
	case syscall.AF_INET:
		ip = sockaddr4(ifa.ifa_addr)
		mask = sockmask4(ifa.ifa_netmask)
	//case syscall.AF_INET6:
	//	ip = sockaddr6(ifa.ifa_addr)
	default:
		// Unsupported address family, omit the addr
		return
	}

	// Populate netmask (ifa.ifa_netmask) and IPv6 Zone.
	var m net.IPMask
	ms := strings.Split(mask, ".")
	if len(ms) >= 4 {
		a, _ := strconv.Atoi(ms[0])
		b, _ := strconv.Atoi(ms[1])
		c, _ := strconv.Atoi(ms[2])
		d, _ := strconv.Atoi(ms[3])
		m = net.IPv4Mask(byte(a), byte(b), byte(c), byte(d))
	}
	addr := net.IPNet{IP: net.ParseIP(ip), Mask: m}
	i.addrs = []net.Addr{&addr}

	return
}

func index(ifa *C.struct_ifaddrs) int {
	return int(C.if_nametoindex(ifa.ifa_name))
}

func sockaddr4(sockaddr *C.struct_sockaddr) string {
	var buf [C.INET_ADDRSTRLEN]byte
	addr := (*C.struct_sockaddr_in)(unsafe.Pointer(sockaddr))
	C.inet_ntop(
		syscall.AF_INET,
		unsafe.Pointer(&addr.sin_addr),
		(*C.char)(unsafe.Pointer(&buf[0])),
		C.socklen_t(len(buf)),
	)
	return stripNULL(string(buf[:]))
}

func sockmask4(sockaddr *C.struct_sockaddr) string {
	var buf [C.INET_ADDRSTRLEN]byte
	addr := (*C.struct_sockaddr_in)(unsafe.Pointer(sockaddr))
	C.inet_ntop(
		syscall.AF_INET,
		unsafe.Pointer(&addr.sin_addr),
		(*C.char)(unsafe.Pointer(&buf[0])),
		C.socklen_t(len(buf)),
	)
	return stripNULL(string(buf[:]))
}

func sockaddr6(sockaddr *C.struct_sockaddr) string {
	var buf [C.INET6_ADDRSTRLEN]byte
	addr := (*C.struct_sockaddr_in6)(unsafe.Pointer(sockaddr))
	C.inet_ntop(
		syscall.AF_INET6,
		unsafe.Pointer(&addr.sin6_addr),
		(*C.char)(unsafe.Pointer(&buf[0])),
		C.socklen_t(len(buf)),
	)
	return stripNULL(string(buf[:]))
}

func linkFlags(rawFlags uint32) net.Flags {
	var f net.Flags
	if rawFlags&syscall.IFF_UP != 0 {
		f |= net.FlagUp
	}
	if rawFlags&syscall.IFF_BROADCAST != 0 {
		f |= net.FlagBroadcast
	}
	if rawFlags&syscall.IFF_LOOPBACK != 0 {
		f |= net.FlagLoopback
	}
	if rawFlags&syscall.IFF_POINTOPOINT != 0 {
		f |= net.FlagPointToPoint
	}
	if rawFlags&syscall.IFF_MULTICAST != 0 {
		f |= net.FlagMulticast
	}
	return f
}

func stripNULL(s string) string {
	s, _, _ = strings.Cut(s, "\x00")
	return s
}

func InterfaceAddrs() ([]net.Addr, error) {
	var addr *C.struct_ifaddrs
	ret, err := C.getifaddrs(&addr)
	if ret != 0 {
		return nil, fmt.Errorf("getifaddrs: %w", err.(syscall.Errno))
	}
	defer C.freeifaddrs(addr)

	interfaces := make(map[string]inf)
	curr := addr

	var iface inf
	for {
		if curr == nil {
			break
		}

		iface = makeInterface(curr)

		// getifaddrs() returns a separate list entry for AF_INET and AF_INET6 addresses, but the
		// other fields are identical. Merge into a single entry as net.Interfaces() does.
		if existing, ok := interfaces[iface.Name]; ok {
			iface.addrs = append(iface.addrs, existing.addrs...)
		}

		// Replaces (potentially) existing with merged version
		interfaces[iface.Name] = iface

		// Advance to next item in linked list
		curr = curr.ifa_next
	}

	s := make([]net.Addr, 0)
	for _, iface = range interfaces {
		s = append(s, iface.addrs...)
	}
	return s, nil
}

package ota

import (
	"encoding/json"
	"errors"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	utils "adasgitlab.autel.com/tools/cuav_server/entity/utils/panic"
)

// GetOtaPreSignDownloadUrl 获取ota升级包下载地址
func GetOtaPreSignDownloadUrl(postUrl, fileKey, rangeHeader string) (*PreSignUrlResp, error) {
	defer utils.HandlePanic()
	req := &GetOtaPreSignDownloadUrlReq{
		FileKey:     fileKey,
		RangeHeader: rangeHeader,
	}
	response, err := SendJsonPostReq(req, postUrl)
	if err != nil {
		logger.Errorf("err client.Do:%v \n", err)
		return nil, err
	}

	defer response.Body.Close()
	rsp := Response{}
	if err := json.NewDecoder(response.Body).Decode(&rsp); err != nil {
		logger.Errorf("err json.NewDecoder:%v \n", err)
		return nil, err
	}
	if rsp.Code != 0 {
		return nil, errors.New(rsp.Msg)
	}
	dataStr, err := json.Marshal(rsp.Data)
	if err != nil {
		logger.Errorf("err json.Marshal:%v \n", err)
		return nil, err
	}
	var data PreSignUrlResp
	if err = json.Unmarshal(dataStr, &data); err != nil {
		logger.Errorf("err json.Unmarshal(dataStr, &data):%v \n", err)
		return nil, err
	}

	return &data, nil
}

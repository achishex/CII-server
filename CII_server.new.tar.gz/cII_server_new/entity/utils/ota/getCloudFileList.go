package ota

import (
	"encoding/json"
	"errors"
	"os"
	"path/filepath"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	utils "adasgitlab.autel.com/tools/cuav_server/entity/utils/panic"
)

// GetOtaCloudFileList 获取ota升级包下载地址
func GetOtaCloudFileList(path string, deviceType int32, testSet int32, area int32, snList []string) (*GetOtaCloudFileListResult, error) {
	defer utils.HandlePanic()
	logger.Infof("get cloud file list, devType: %v", deviceType)
	fileType := FileTypeOtaPkg
	if testSet == 1 {
		fileType = TestFileTypeOtaPkg
	}

	req := &FileListReq{
		FileType:   int8(fileType),
		DeviceType: int8(deviceType),
	}
	var result GetOtaCloudFileListResult
	// 尝试从云端获取升级列表
	url := ""

	if area == 1 {
		url = AbroadGetCloudFileListUrl
	} else {
		url = GetCloudFileListUrl
	}
	response, err := SendJsonPostReq(req, url)
	if err != nil {
		// 获取不到从本地缓存获取列表
		if len(CloudOtaFileCacheList) > 0 {
			result.List = CloudOtaFileCacheList
			return &result, nil
		}
		data, err := os.ReadFile(filepath.Join(path, "/cache/list.json"))
		if err != nil {
			logger.Error("GetOtaCloudFileList readFile error")
			return nil, err
		}
		err = json.Unmarshal(data, &CloudOtaFileCacheList)
		if err != nil {
			logger.Error("GetOtaCloudFileList unmarshal json file error")
			return nil, err
		}
		result.List = CloudOtaFileCacheList
		for _, p := range result.List {
			//CloudOtaFileMap[p.FileName] = p
			SetCloudOtaFilePackage(p.FileName, p)

		}
		logger.Debug("get Local list.json :", result)
		return &result, nil
	}

	defer response.Body.Close()
	rsp := Response{}
	if err := json.NewDecoder(response.Body).Decode(&rsp); err != nil {
		//logger.Errorf("err json.NewDecoder:%v \n", err)
		//return nil, err
		// 获取不到从本地缓存获取列表
		if len(CloudOtaFileCacheList) > 0 {
			result.List = CloudOtaFileCacheList
			return &result, nil
		}
		data, err := os.ReadFile(filepath.Join(path, "/cache/list.json"))
		if err != nil {
			logger.Error("GetOtaCloudFileList readFile error")
			return nil, err
		}
		err = json.Unmarshal(data, &CloudOtaFileCacheList)
		if err != nil {
			logger.Error("GetOtaCloudFileList unmarshal json file error")
			return nil, err
		}
		result.List = CloudOtaFileCacheList
		for _, p := range result.List {
			//CloudOtaFileMap[p.FileName] = p
			SetCloudOtaFilePackage(p.FileName, p)

		}
		logger.Debug("get Local list.json :", result)
		return &result, nil
	}
	if rsp.Code != 0 {
		return nil, errors.New(rsp.Msg)
	}
	dataStr, err := json.Marshal(rsp.Data)
	if err != nil {
		logger.Errorf("err json.Marshal:%v \n", err)
		return nil, err
	}

	if err = json.Unmarshal(dataStr, &result); err != nil {
		logger.Errorf("err json.Unmarshal(dataStr, &result):%v \n", err)
		return nil, err
	}

	var result1 GetOtaCloudFileListResult

	url1 := ""
	if area == 1 {
		url1 = AbroadVersionSn
	} else {
		url1 = VersionSn
	}
	var resultversion GetOtaCloudVersionSnResult
	responseversion, err := SendJsonPostReq("", url1)
	if err != nil {
		logger.Error("Post version sn err:", err)
		return nil, err
	}
	defer responseversion.Body.Close()
	rspversion := Response{}
	if err := json.NewDecoder(responseversion.Body).Decode(&rspversion); err != nil {
		logger.Errorf("err NewDecoder:%v \n", err)
		return nil, err
	}
	if rsp.Code != 0 {
		return nil, err
	}
	dataStrVersion, err := json.Marshal(rspversion.Data)
	if err != nil {
		logger.Errorf("err json.Marshal:%v \n", err)
		return nil, err
	}

	if err = json.Unmarshal(dataStrVersion, &resultversion); err != nil {
		logger.Errorf("err json.Unmarshal(dataStr, &result):%v \n", err)
		return nil, err
	}
	var isexist bool
	for _, verInfo := range resultversion.VersionSnList {
		for _, sn := range snList {
			if verInfo.DeviceSn == sn {
				result1 = result
				isexist = true
			}
		}
	}
	pkgInfo := make([]Package, 0)
	if !isexist {
		for _, p := range result.List {
			add := true
			for _, v := range resultversion.VersionSnList {
				if v.VersionName == p.FileName {
					add = false
				}
			}
			if add {
				pkgInfo = append(pkgInfo, p)
			}
		}
		result1.List = pkgInfo
		result1.Page = result.Page
		result1.PageSize = result.PageSize
		result1.Total = result.Total
	}

	if len(result1.List) > 0 {
		CloudOtaFileCacheList = result1.List
		for _, p := range result1.List {
			//CloudOtaFileMap[p.FileName] = p
			SetCloudOtaFilePackage(p.FileName, p)
		}
		CacheLocal(result1.List, path, "/cache/", "list.json")
	}
	logger.Debug("get cloud list.json :", result1)
	SaveVersionSn(area, path)
	return &result1, nil
}

func SaveVersionSn(area int32, path string) {
	url := ""
	if area == 1 {
		url = AbroadVersionSn
	} else {
		url = VersionSn
	}
	var result GetOtaCloudVersionSnResult
	response, err := SendJsonPostReq("", url)
	if err != nil {
		logger.Error("Post version sn err:", err)
		return
	}
	defer response.Body.Close()
	rsp := Response{}
	if err := json.NewDecoder(response.Body).Decode(&rsp); err != nil {
		logger.Errorf("err NewDecoder:%v \n", err)
		return
	}
	if rsp.Code != 0 {
		return
	}
	dataStr, err := json.Marshal(rsp.Data)
	if err != nil {
		logger.Errorf("err json.Marshal:%v \n", err)
		return
	}

	if err = json.Unmarshal(dataStr, &result); err != nil {
		logger.Errorf("err json.Unmarshal(dataStr, &result):%v \n", err)
		return
	}
	logger.Debug("version sn result:", result.VersionSnList)
	CacheLocal(result.VersionSnList, path, "/cache/", "versionSn.json")
}

// GetOtaCloudFileListUpgrade 获取ota升级包信息列表
func GetOtaCloudFileListUpgrade(pkgPath string, deviceType int32) (*GetOtaCloudFileListResult, error) {
	//pkgPath = DefaultOtaPkgPath
	defer utils.HandlePanic()
	logger.Info("get cloud file list:", deviceType)
	fileType := FileTypeOtaPkg

	req := &FileListReq{
		FileType:   int8(fileType),
		DeviceType: int8(deviceType),
	}
	var result GetOtaCloudFileListResult
	// 尝试从云端获取升级列表
	response, err := SendJsonPostReq(req, GetCloudFileListUrl)
	if err != nil {
		// 获取不到从本地缓存获取列表
		if len(CloudOtaFileCacheList) > 0 {
			result.List = CloudOtaFileCacheList
			return &result, nil
		}
		data, err := os.ReadFile(filepath.Join(pkgPath, "/cache/list.json"))
		if err != nil {
			logger.Error("GetOtaCloudFileList readFile error")
			return nil, err
		}
		err = json.Unmarshal(data, &CloudOtaFileCacheList)
		if err != nil {
			logger.Error("GetOtaCloudFileList unmarshal json file error")
			return nil, err
		}
		result.List = CloudOtaFileCacheList
		for _, p := range result.List {
			//CloudOtaFileMap[p.FileName] = p
			SetCloudOtaFilePackage(p.FileName, p)

		}
		logger.Debug("get Local list.json :", result)
		return &result, nil
	}

	defer response.Body.Close()
	rsp := Response{}
	if err := json.NewDecoder(response.Body).Decode(&rsp); err != nil {
		//logger.Errorf("err json.NewDecoder:%v \n", err)
		//return nil, err
		// 获取不到从本地缓存获取列表
		if len(CloudOtaFileCacheList) > 0 {
			result.List = CloudOtaFileCacheList
			return &result, nil
		}
		data, err := os.ReadFile(filepath.Join(pkgPath, "/cache/list.json"))
		if err != nil {
			logger.Error("GetOtaCloudFileList readFile error")
			return nil, err
		}
		err = json.Unmarshal(data, &CloudOtaFileCacheList)
		if err != nil {
			logger.Error("GetOtaCloudFileList unmarshal json file error")
			return nil, err
		}
		result.List = CloudOtaFileCacheList
		for _, p := range result.List {
			//CloudOtaFileMap[p.FileName] = p
			SetCloudOtaFilePackage(p.FileName, p)

		}
		logger.Debug("get Local list.json :", result)
		return &result, nil
	}
	if rsp.Code != 0 {
		return nil, errors.New(rsp.Msg)
	}
	dataStr, err := json.Marshal(rsp.Data)
	if err != nil {
		logger.Errorf("err json.Marshal:%v \n", err)
		return nil, err
	}

	if err = json.Unmarshal(dataStr, &result); err != nil {
		logger.Errorf("err json.Unmarshal(dataStr, &result):%v \n", err)
		return nil, err
	}

	if len(result.List) > 0 {
		CloudOtaFileCacheList = result.List
		for _, p := range result.List {
			//CloudOtaFileMap[p.FileName] = p
			SetCloudOtaFilePackage(p.FileName, p)
		}
		CacheLocal(result.List, pkgPath, "/cache/", "list.json")
	}
	logger.Debug("get cloud list.json :", result)
	return &result, nil
}

// GetOtaCloudFileVersionSnList 获取ota升级包固定SN表
func GetOtaCloudFileVersionSnList(pkgPath string) (*GetOtaCloudVersionSnResult, error) {
	//pkgPath = DefaultOtaPkgPath
	defer utils.HandlePanic()
	var result GetOtaCloudVersionSnResult
	var cloudList = make([]VersionSnListRsp, 0)
	// 尝试从云端获取升级列表
	data, err := os.ReadFile(filepath.Join(pkgPath, "/cache/versionSn.json"))
	if err != nil {
		logger.Error("GetOtaCloudVersionSnResult readFile error")
		return nil, err
	}
	err = json.Unmarshal(data, &cloudList)
	if err != nil {
		logger.Error("GetOtaCloudVersionSnResult unmarshal json file error")
		return nil, err
	}
	result.VersionSnList = cloudList
	logger.Debug("get Local list.json :", result)
	return &result, nil

}

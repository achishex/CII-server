package bean

type LicenseTime struct {
	Id             int32  `json:"id"`
	LicenseNowTime string `json:"license_now_time"`
}

func (LicenseTime) TableName() string {
	return "license_time"
}

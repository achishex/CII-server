package bean

type Fences struct {
	ID                int64   `gorm:"primary_key;auto_increment" json:"id"`
	Name              string  `json:"name"`
	AreaType          int32   `json:"area_type"`
	Perimeter         float64 `json:"perimeter"`
	Area              float64 `json:"area"`
	IsCloud           bool    `json:"is_cloud"`
	IsDelete          bool    `json:"is_delete"`
	TbCode            string  `json:"tb_code"`
	CentroidLongitude float64 `json:"centroid_longitude"`
	CentroidLatitude  float64 `json:"centroid_latitude"`
	Geometry          string  `json:"geometry"`
	Color             string  `json:"color"`
	CreateTime        string  `json:"create_time"`
	UpdateTime        string  `json:"update_time"`
	DeleteTime        string  `json:"delete_time"`
	FenceType         int32   `json:"fence_type"` //围栏区类型0:多边形 1:矩形 2:椭圆
	XRadius           float64 `json:"x_radius"`   //x轴半径
	YRadius           float64 `json:"y_radius"`   //y轴半径
}

func (Fences) TableName() string {
	return "fences"
}

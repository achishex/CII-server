package bean

import "adasgitlab.autel.com/tools/cuav_server/entity/common"

type SFL101ReplayDetectData struct {
	Id                 int32   `json:"id"`
	Sn                 string  `json:"sn"` //sfl101 sn
	ProductType        int32   `json:"product_type"`
	DroneName          string  `json:"drone_name"`
	SerialNum          string  `json:"serial_num"`
	DroneLongitude     float64 `json:"drone_longitude"`
	DroneLatitude      float64 `json:"drone_latitude"`
	DroneHeight        float64 `json:"drone_height"`
	DroneYawAngle      float64 `json:"drone_yaw_angle"`
	DroneSpeed         float64 `json:"drone_speed"`
	DroneVerticalSpeed float64 `json:"drone_vertical_speed"`
	SpeedDirection     int32   `json:"speed_direction"`
	DroneSailLongitude float64 `json:"drone_sail_longitude"`
	DroneSailLatitude  float64 `json:"drone_sail_latitude"`
	PilotLongitude     float64 `json:"pilot_longitude"`
	PilotLatitude      float64 `json:"pilot_latitude"`
	DroneHorizon       float64 `json:"drone_horizon"`
	DronePitch         float64 `json:"drone_pitch"`
	UFreq              float64 `json:"freq"`
	UDistance          int32   `json:"distance"`
	UDangerLevels      int32   `json:"danger_levels"`
	Role               int32   `json:"role"`
	OnceSeq            int64   `json:"once_seq"`                  // OnceSeq 是一次的序列号。不同序列号下有多条记录标识多个无人机。
	CreateTime         int64   `json:"create_time"  gorm:"index"` //创建时间戳格式  "2006-01-02 15:04:05.000"  // 对应的时间格式
	UDirStatus         int32   `json:"u_dir_status"`              // 新增定向状态 0：非定向状态 1：定向中 2：定向成功 其他：保留
	IdType             int32   `json:"id_type"`                   //无人机的类型 0:频谱 1：droneID 2:RemoteID 3: droneID & RemoteID
}

func (SFL101ReplayDetectData) GetTableName(sn string) string {
	return common.BuildDetectTableName(sn)
}

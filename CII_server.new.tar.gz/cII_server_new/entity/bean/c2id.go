package bean

// monkey patch for uuid
var C2Sn string

type C2Id struct {
	Id       int32  `json:"id"`
	C2Id     string `json:"c2_id"`
	Sid      string `json:"sid"`
	Tid      string `json:"tid"`
	Domain   string `json:"domain"`    // 注册域名
	SiteName string `json:"site_name"` // 绑定站点名称
	Token    string `json:"token"`
}

func (C2Id) TableName() string {
	return "c2_id"
}

type C2IdPlus struct {
	ID       int32  `json:"id"`
	C2Id     string `json:"c2_id"`
	Sid      string `json:"sid"`
	Tid      string `json:"tid"`
	Domain   string `json:"domain"`    // 注册域名
	SiteName string `json:"site_name"` // 绑定站点名称
	Token    string `json:"token"`
	BindTime string `json:"bind_time"`
	SiteID   int64  `json:"site_id"`
}

package bean

type Alarm struct {
	ID          int64   `gorm:"primary_key;auto_increment" json:"id"` //主键ID
	DroneSn     string  `json:"drone_sn"`                             //目标sn
	DroneObjId  int64   `json:"drone_obj_id"`                         //目标id
	EventId     int64   `json:"event_id"`                             //事件ID
	FenceId     int64   `json:"fence_id"`                             //围栏区ID
	Distance    float64 `json:"distance"`                             //目标距离围栏区的最短距离
	ThreatLevel int32   `json:"threat_level"`                         //威胁等级，高（80-100分）、中（50-79分）、低（1-49分），0无威胁
	CreateTime  string  `json:"create_time"`                          //告警开始时间
	ScenesId    int32   `json:"scenes_id"`                            //场景ID 1-未设置围栏区 2-用户已设置预警区但未设核心区 3-用户已设置核心区但未设预警区 4-用户已设置预警区和核心区
}

func (Alarm) TableName() string {
	return "alarm"
}

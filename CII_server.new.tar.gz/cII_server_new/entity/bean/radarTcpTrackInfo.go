package bean

type RadarTcpTrackInfo struct {
	Id           int    `json:"id"`
	Uid          int64  `json:"uid"`
	Sn           string `json:"sn"`
	Reserved     uint8  `json:"reserved"`
	TrackObjNum  uint8  `json:"track_obj_num"`
	TrackTwsNum  uint8  `json:"track_tws_num"`
	TrackTasNum  uint8  `json:"track_tas_num"`
	TrackObjByte uint8  `json:"track_obj_byte"`
	ReceivedTime int64  `json:"received_time"`
}

func (RadarTcpTrackInfo) TableName() string {
	return "radar_tcp_track_info"
}

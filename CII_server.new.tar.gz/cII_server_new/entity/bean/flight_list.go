package bean

type FlightList struct {
	Id            int32   `json:"id"`
	DroneName     string  `json:"drone_name"`
	Vendor        string  `json:"vendor"`
	Freq          float64 `json:"freq"`
	DevType       int32   `json:"dev_type"`
	SerialNum     string  `json:"serial_num"`
	BeginTime     string  `json:"begin_time"`
	EndTime       string  `json:"end_time"`
	DurationTime  float64 `json:"duration_time"`
	Height        float64 `json:"height"`
	Protocol      string  `json:"protocol"`
	DroneYawAngle float64 `json:"drone_yaw_angle"`
}

func (FlightList) TableName() string {
	return "flight_list"
}

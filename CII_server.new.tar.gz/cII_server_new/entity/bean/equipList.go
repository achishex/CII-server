package bean

import (
	"crypto/sha256"
	"encoding/hex"
)

type EquipList struct {
	Id             int    `json:"id"`
	Reverse        string `json:"reverse"`
	TerminalId     string `json:"terminal_id"` //sn用来作为设备id
	Etype          string `json:"etype"`
	TcpPort        int    `json:"tcp_port"`
	UdpPort        int    `json:"udp_port"`
	Ip             string `json:"ip"`
	CrtTime        string `json:"crt_time"`
	Status         string `json:"status"` //在线、离线、故障
	UpdateTime     string `json:"update_time"`
	Vendor         string `json:"vendor"`
	Frequency      string `json:"frequency"`
	Model          string `json:"model"`
	Protocol       string `json:"protocol"`
	Name           string `json:"name"`
	Content        string `json:"content"`
	SubType        string `json:"sub_type"`
	LocalIp        string `json:"local_ip"`
	LocalUdpPort   int    `json:"local_udp_port"`
	Sn             string `json:"sn"`
	IsEnable       int    `json:"is_enable"`       //1-启用，2-禁用
	IsOnline       int    `json:"is_online"`       //1-在线 2-离线
	RadarRelevance int    `json:"radar_relevance"` //雷达归属
	DevVersion     string `json:"dev_version"`     //设备版本
	ScanRadius     int    `json:"scan_radius"`     //添加扫描半径
	ParentSn       string `json:"parent_sn"`       //父设备SN
	SubDevType     int    `json:"sub_dev_type"`    //子设备类型
	ParentType     int    `json:"parent_type"`     //父设备类型
	IsIntegrated   int32  `json:"is_integrated"`   //是否时一体化设备，0-非一体化，1-一体化
	VersionType    int32  `json:"version_type"`    //区分雷达T5,T6, 1-T5，2-T6
}

var (
	GupdateEquipListNotify = make(chan bool, 256)
)

func (EquipList) TableName() string {
	return "equip_list"
}

type EquipListBackUp EquipList

func (EquipListBackUp) TableName() string {
	return "equip_list_backup"
}
func CalculateID(sn string) string {
	// 使用 SHA256 哈希函数
	hash := sha256.New()
	hash.Write([]byte(sn))
	// 将哈希值转换为十六进制字符串
	id := hex.EncodeToString(hash.Sum(nil))
	// 取十位字符
	id = id[:10]
	return id
}

package bean

type NavyGunSpooferLog struct {
	Id                      int     `json:"id"`
	Sn                      string  `json:"sn"`
	DevDescription          string  `json:"dev_description"`
	DevCloseTime            int64   `json:"dev_close_time"`
	DevOpenTime             int64   `json:"dev_open_time"`
	DetectUavs              string  `json:"detect_uavs"`
	InterferenceSignalStart int64   `json:"interference_signal_start"` //诱骗开始时间
	InterferenceSignalStop  int64   `json:"interference_signal_stop"`  //诱骗结束时间
	EventId                 int64   `json:"event_id"`
	EventDescription        string  `json:"event_description"`
	Longitude               float64 `json:"longitude"`
	Latitude                float64 `json:"latitude"`
	CreateTime              int64   `json:"create_time"`
}

func (NavyGunSpooferLog) GetTableName() string {
	return "navy_blader_spoofer_log"
}

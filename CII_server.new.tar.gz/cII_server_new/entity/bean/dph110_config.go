package bean

type DPH110Config struct {
	Id              int64   `json:"id"`
	Sn              string  `json:"sn"`                //设备sn
	Longitude       float64 `json:"longitude"`         //经度
	Latitude        float64 `json:"latitude"`          //纬度
	Altitude        float64 `json:"altitude"`          //高度
	Heading         float64 `json:"heading"`           //方位角
	Pitching        float64 `json:"pitching"`          //俯仰角
	Rolling         float64 `json:"rolling"`           //横滚角
	EleScanCenter   float32 `json:"ele_scan_center"`   //俯仰扫描中心位置(°)
	EleScanScope    float32 `json:"ele_scan_scope"`    //俯仰扫描范围(°)
	AziScanCenter   float32 `json:"azi_scan_center"`   //方位扫描中心位置(°)
	AziScanScope    float32 `json:"azi_scan_scope"`    //方位扫描范围(°)
	RadarScanRadius int32   `json:"radar_scan_radius"` //扫描范围 (m) 默认1500m
	FilterLevel     int32   `json:"filter_level"`      //滤波等级
	FChannel        int32   `json:"f_channel"`         //频分通道	1 2 3 4
	TChannel        int32   `json:"t_channel"`         //时分通道
}

func (DPH110Config) TableName() string {
	return "dph110_config"
}

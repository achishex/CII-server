package bean

import (
	"adasgitlab.autel.com/tools/cuav_server/entity/common"
)

const (
	FreqDetectUavHasNot = 0
	FreqDetectUavHas    = 1
)

type TracerReplayDetect struct {
	Id                int     `json:"id"`
	Sn                string  `json:"sn"` //设备sn
	OperatorLongitude float64 `json:"operator_longitude"`
	OperatorLatitude  float64 `json:"operator_latitude"`
	Freq              float64 `json:"freq"`
	Distance          float64 `json:"distance"`
	DangerLevels      int     `json:"danger_levels"` //危险等级
	Role              int     `json:"role"`          //1-敌军 2-友军 3-未知 4-中立     批量导入为2友军
	DroneName         string  `json:"drone_name"`
	SerialNum         string  `json:"serial_num"`
	DroneLongitude    float64 `json:"drone_longitude"`
	DroneLatitude     float64 `json:"drone_latitude"`
	DroneHeight       float64 `json:"drone_height"`
	DroneSpeed        float64 `json:"drone_speed"` //速度
	DroneYawAngle     float64 `json:"drone_yaw_angle"`
	DetectSrcType     int32   `json:"detect_type"` //检测无人机设备的类型, remoteID:1, droneID: 2

	QxPower      float64 `json:"qx_power"`      //全向功率
	DxPower      float64 `json:"dx_power"`      //定向功率
	DxHorizon    float64 `json:"dx_horizon"`    //定向天线水平角(0.01°)
	DroneHorizon float64 `json:"drone_horizon"` //lsb 目标水平角（0.01°），无效值0x7fffffff

	OnceSeq int64 `json:"once_seq"` // OnceSeq 是一次的序列号。不同序列号下有多条记录标识多个无人机。
	HasUav  int32 `json:"has_uav"`  //主要是为了识别 QxPower/DxPower/DxHorizon 和空 uav, 如果没有uav也要存这条包含前面字段的记录。 0: not has, 1: has

	HomeLongitude        float64 `json:"homeLongitude"`        // 无人机返航点经度 (deg)
	HomeLatitude         float64 `json:"homeLatitude"`         // 无人机返航点纬度 (deg)
	AliveTime            uint32  `json:"aliveTime"`            //无人机生命周期 (ms) 1
	TargetMask           uint16  `json:"targetMask"`           // 后续目标信息字段来源掩码
	TypeCodeRid          uint16  `json:"typeCodeRid"`          // 无人机RemoteID类型码
	SeqNumRid            uint16  `json:"seqNumRid"`            // 无人机RemoteID信号序号
	ClassificationType   uint8   `json:"classificationType"`   // 无人机等级分类归属区域及取值
	OperationStatus      uint8   `json:"operationStatus"`      // 无人机运行状态
	OperatorLocationType uint8   `json:"operatorLocationType"` // 无人机操作员的位置类型及取值
	HeightType           uint8   `json:"heightType"`           //无人机高度类型： 0：基于起飞地的高度 1：基于AGL高度
	SignalFreqRid        uint32  `json:"signalFreqRid"`        // 无人机RemoteID信号频率(MHz)
	SignalPowerRid       int16   `json:"signalPowerRid"`       // 无人机RemoteID天线信号强度 (dBm)
	NoisePowerRid        int16   `json:"noisePowerRid"`        // 无人机RemoteID天线噪声强度 (dBm)
	TimestampRid         uint32  `json:"timestampRid"`         // 无人机RemoteID时间戳
	TypeCodeDid          uint16  `json:"typeCodeDid"`          // 无人机DroneID类型码
	SeqNumDid            uint16  `json:"seqNumDid"`            // 无人机DroneID信号序号
	Altitude             float64 `json:"altitude"`             // 无人机海拔高度 (m)
	SpeedX               float64 `json:"speedX"`               // 无人机X方向速度 (m/s)
	SpeedY               float64 `json:"speedY"`               // 无人机Y方向速度 (m/s)
	SignalFreqDid        uint32  `json:"signalFreqDid"`        // 无人机DroneID信号频率(MHz)
	SignalPowerDidCh1    int16   `json:"signalPowerDidCh1"`    // 无人机DroneID信号强度(dBm),通道1
	SignalPowerDidCh2    int16   `json:"signalPowerDidCh2"`    // 无人机DroneID信号强度(dBm)，通道2
	GpsClock             uint64  `json:"gpsClock"`             // 无人机GPS时间戳

	CreateTime int64 `json:"create_time"  gorm:"index"` //创建时间戳格式  "2006-01-02 15:04:05.000"  // 对应的时间格式
}

func (TracerReplayDetect) TableName() string {
	return "tracer_replay_detect"
}

func (TracerReplayDetect) GetTableName(sn string) string {
	return common.BuildDetectTableName(sn)
}

type TracerSReplaySysConfigData struct {
	Id          int     `json:"id"`
	Sn          string  `json:"sn"`
	C2Longitude float64 `json:"c2_longitude"`
	C2Latitude  float64 `json:"c2_latitude"`
	CreateTime  int64   `json:"create_time"  gorm:"index"` //创建时间戳格式  "2006-01-02 15:04:05.000"  // 对应的时间格式
}

func (TracerSReplaySysConfigData) TableName(sn string) string {
	return common.BuildSysCfgTabName(sn)
}

package bean

import "adasgitlab.autel.com/tools/cuav_server/entity/common"

type FpvReplayDetectData struct {
	Id        int     `json:"id"`
	Sn        string  `json:"sn"`
	QxPower   float64 `json:"qx_power"`   //全向功率
	DxPower   float64 `json:"dx_power"`   //定向功率
	DxHorizon float64 `json:"dx_horizon"` //定向天线水平角(0.01°)
	//
	UavNumber     int32   `json:"uav_number"`                //无人机编号
	DroneName     string  `json:"drone_name"`                //无人机品牌+机型
	DroneHorizon  float64 `json:"drone_horizon"`             //lsb 目标水平角（0.01°），无效值0x7fffffff
	UFreq         float64 `json:"freq"`                      //频率
	UDangerLevels int32   `json:"danger_levels"`             //危险等级
	CreateTime    int64   `json:"create_time"  gorm:"index"` //创建时间戳格式  "2006-01-02 15:04:05.000"  // 对应的时间格式
}

func (FpvReplayDetectData) GetTableName(sn string) string {
	return common.BuildDetectTableName(sn)
}

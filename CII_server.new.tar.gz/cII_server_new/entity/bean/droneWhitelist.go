package bean

import "time"

type DroneWhiteList struct {
	ID        int32     `json:"id"`
	Vendor    string    `json:"vendor"`
	Model     string    `json:"model"`
	Frequency string    `json:"frequency"`
	Sn        string    `json:"sn"`
	Role      int32     `json:"role"`
	UserName  string    `json:"user_name"`  // 白名单录入者名称(用户C2账户名或用户个人昵称)
	Usage     int32     `json:"usage"`      // 1, 政府:2, 安防: 3, 私人活动:4, 其他: 200; 无人机用途记录(警用、政府、安防、私人活动、其他)
	UsageDesc string    `json:"usage_desc"` // 无人机用途记录(警用、政府、安防、私人活动、其他)
	Remarks   string    `json:"remarks"`    // 标记为白名单无人机的原因/背景
	CreatedAt time.Time `json:"create_at"`
	UpdatedAt time.Time `json:"update_at"`
}

func (DroneWhiteList) TableName() string {
	return "drone_white_list"
}

type WhiteListLog struct {
	ID        int32     `json:"id"`
	Vendor    string    `json:"vendor"`
	Model     string    `json:"model"`
	Frequency string    `json:"frequency"`
	Sn        string    `json:"sn"`
	Role      int32     `json:"role"`
	UserName  string    `json:"user_name"`  // 白名单录入者名称(用户C2账户名或用户个人昵称)
	Usage     int32     `json:"usage"`      // 1, 政府:2, 安防: 3, 私人活动:4, 其他: 200; 无人机用途记录(警用、政府、安防、私人活动、其他)
	UsageDesc string    `json:"usage_desc"` // 无人机用途记录(警用、政府、安防、私人活动、其他)
	Remarks   string    `json:"remarks"`    // 标记为白名单无人机的原因/背景
	CreatedAt time.Time `json:"create_at"`
	UpdatedAt time.Time `json:"update_at"`
}

func (WhiteListLog) TableName() string {
	return "delete_whitelist_log"
}

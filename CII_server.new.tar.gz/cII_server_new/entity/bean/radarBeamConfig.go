package bean

type RadarBeamConfig struct {
	Id            int32   `json:"id"`
	AziScanScope  float64 `json:"azi_scan_scope"`
	AziScanCenter float64 `json:"azi_scan_center"`
	EleScanCenter float64 `json:"ele_scan_center"`
	EleScanScope  float64 `json:"ele_scan_scope"`
	ScanRadius    int32   `json:"scan_radius"`
}

func (r *RadarBeamConfig) TableName() string {
	return "radar_beam_config"
}

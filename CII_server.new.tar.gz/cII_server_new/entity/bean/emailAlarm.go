package bean

type EmailAlarm struct {
	Id          int32  `json:"id"`
	IsAlarm     bool   `json:"is_alarm"`
	Email       string `json:"email"`
	EmailSwitch bool   `json:"email_switch"`
	Language    int32  `json:"language"` //0英文  1中文  2俄文
	Sfl100      bool   `json:"sfl100"`
	Sfl200      bool   `json:"sfl200"`
	Tracer      bool   `json:"tracer"`
	Radar       bool   `json:"radar"`
	Srp150      bool   `json:"srp150"`
	Srp100      bool   `json:"srp100"`
}

func (EmailAlarm) TableName() string {
	return "email_alarm"
}

package bean

type TokenResponse struct {
	Success bool   `json:"success"`
	Msg     string `json:"msg"`
	Data    struct {
		Token  string   `json:"token"`
		Orders []string `json:"orders"`
	} `json:"data"`
}

type TracerDecryptSend struct {
	UniqueId uint64 `json:"uniqueId"`
	Result   uint32 `json:"result"`
	JsonLen  uint32 `json:"jsonLen"`
	JsonData string `json:"jsonData"`
}
type SflDecryptSend struct {
	UniqueId uint64 `json:"uniqueId"`
	Result   uint32 `json:"result"`
	JsonLen  uint32 `json:"jsonLen"`
	JsonData string `json:"jsonData"`
}

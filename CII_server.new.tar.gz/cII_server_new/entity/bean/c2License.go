package bean

import (
	"errors"
	"os"
	"runtime"
	"time"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/utils/helper"
	"github.com/denisbrodbeck/machineid"
	"github.com/hashicorp/go-version"
	"gopkg.in/yaml.v2"
)

type C2License struct {
	LicenseId   string `json:"license_id"`
	MacAddr     string `json:"mac_addr"`
	StartTime   string `json:"start_time"`
	StopTime    string `json:"stop_time"`
	LastTime    string `json:"last_time"`
	Expires     int32  `json:"expires"`      //有效时间
	LicenseType string `json:"license_type"` //1正式版 2试用版  3测试版
	UserName    string `json:"user_name"`    //用户名称
	UserPhone   string `json:"user_phone"`   //用户电话
	UserEmail   string `json:"user_email"`   //用户电子邮件

}

func (C2License) TableName() string {
	return "c2_license"
}

// AvlidDate : //可使用时间
// UserTotalNum : //用户总量
// DeviceTotalNum : //设备总量
// Modules :[]  // 模块列表
// IsBindDevice: //是否限定绑定设备
// version: //后端软件版本，低版本（ 版本号<=1.0.0.107 ）仅先支持用于license的主机使用两年

type licenseMsg struct {
	Version        string   `yaml:"version"`
	ID             string   `yaml:"id"`
	AvlidDate      string   `yaml:"avlidDate"`
	UserTotalNum   string   `yaml:"userTotalNum"`
	DeviceTotalNum string   `yaml:"deviceTotalNum"`
	Modules        []string `yaml:"modules"`
	IsBindDevice   int      `yaml:"isBindDevice"`
}

const (
	licensePath = "license/license"
	encryptKey  = "skyfendCUASC2OSS"
	baselineVer = "1.0.0.107"
)
const (
	NoLicenseCode      int32 = 1015
	InvalidLicenseCode int32 = 1016
	ExpiredLicenseCode int32 = 1017
	NoLicense                = "license not exist"
	InvalidLicense           = "license is invalid"
	ExpiredLicense           = "expired license"
)

func newLicense() *licenseMsg {
	return &licenseMsg{}
}

// LicenseInvalidTime ...
func LicenseInvalidTime() (string, error) {
	l := newLicense()
	detail, err := l.check()
	if err != nil {
		return "", err
	}
	if detail == nil {
		return "", nil
	}
	logger.Debugf("License AvlidDate = ", detail.AvlidDate)
	return detail.AvlidDate, nil
}

// LicenseCheck ...
func LicenseCheck() error {

	l := newLicense()
	_, err := l.check()

	return err
}

func (m licenseMsg) check() (*licenseMsg, error) {
	osName := runtime.GOOS
	if osName != "windows" && osName != "linux" {
		logger.Debug("License check not supported int this operation system, system := ", osName)
		return nil, nil
	}

	fd, err := os.Open(licensePath)
	defer fd.Close()
	if err != nil {
		logger.Errorf("error opening file,error: ", err)
		return nil, errors.New(NoLicense)
	}
	fileInfo, err := fd.Stat()
	if err != nil {
		logger.Errorf("error getting file information,error: ", err)
		return nil, errors.New(NoLicense)
	}

	buf := make([]byte, fileInfo.Size())
	_, err = fd.Read(buf)
	if err != nil {
		logger.Errorf("error reading file,error: ", err)
		return nil, errors.New(InvalidLicense)
	}

	deBuf, err := helper.Decrypt(string(buf), []byte(encryptKey))
	if err != nil {
		logger.Errorf("error Decrypt file,error: ", err)
		return nil, errors.New(InvalidLicense)
	}
	logger.Debug("license msg : ", deBuf)

	y2struct := licenseMsg{}
	err = yaml.Unmarshal(deBuf, &y2struct)
	if err != nil {
		logger.Errorf("error Decrypt file,error: ", err)
		return nil, errors.New(InvalidLicense)
	}

	liceVersion, err := version.NewVersion(y2struct.Version)
	if err != nil {
		logger.Errorf("error new liceVersion: ", err)
		return nil, errors.New(InvalidLicense)
	}

	baselineVersion, err := version.NewVersion(baselineVer)
	if err != nil {
		logger.Errorf("error new nowVersion: ", err)
		return nil, errors.New(InvalidLicense)
	}

	if baselineVersion.LessThan(liceVersion) {
		logger.Errorf("%s (baselineVersion) is less than %s (liceVersion)", baselineVersion, liceVersion)
	}
	id, err := machineid.ID()
	if err != nil {
		logger.Errorf("Error generating machine,err : ", err)
	}
	if id != y2struct.ID {
		logger.Errorf("error license ID : ", y2struct.ID)
		return &y2struct, errors.New(InvalidLicense)
	}
	// currentTime := time.Now()
	licenseEndTime, err := time.Parse("2006-01-02 15:04:05", y2struct.AvlidDate)
	if err != nil {
		logger.Errorf("Error parsing time:", err)
		return nil, errors.New(InvalidLicense)
	}
	currentTime, err := time.Parse("2006-01-02 15:04:05", time.Now().Format("2006-01-02 15:04:05"))
	if currentTime.After(licenseEndTime) {
		logger.Errorf("license expiration")
		return &y2struct, errors.New(ExpiredLicense)
	}

	return &y2struct, nil
}

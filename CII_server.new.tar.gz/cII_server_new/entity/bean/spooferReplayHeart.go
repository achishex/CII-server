package bean

import "adasgitlab.autel.com/tools/cuav_server/entity/common"

type SpooferReplayHeartData struct {
	Id          int     `json:"id"`
	Sn          string  `json:"sn"`
	IsOnline    int     `json:"is_online"`   //1:在线
	IsWorking   int     `json:"is_working"`  //工作状态： 1：工作中，2：未工作
	GpsStatus   int     `json:"gps_status"`  //定位状态 1:已定位  2：未定位
	Ephemeris   int     `json:"ephemeris"`   //星历    1:以获取  2:未获取
	TimeSync    int     `json:"time_sync"`   //时间同步状态  1:已同步  2:未同步
	Longititude float64 `json:"longititude"` //经度
	Latitude    float64 `json:"latitude"`    //纬度
	Height      float64 `json:"height"`
	MsgType     int32   `json:"msgType"`                   //消息类型 适配不同的回放数据，方便存库
	CreateTime  int64   `json:"create_time"  gorm:"index"` //创建时间戳格式  "2006-01-02 15:04:05.000"  // 对应的时间格式

}

func (SpooferReplayHeartData) GetTableName(sn string) string {
	return common.BuildHeartTableName(sn)
}

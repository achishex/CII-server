package bean

type TracerSOrientLog struct {
	Id          int    `json:"id"`
	Sn          string `json:"sn"`
	DroneNumber uint32 `json:"drone_number"`
	DroneName   string `json:"drone_name"`
	Freq        uint32 `json:"freq"`        //mHz
	Azimuth     int32  `json:"azimuth"`     //水平角
	CreateTime  int64  `json:"create_time"` //毫秒
	UpdateTime  int64  `json:"update_time"` //毫秒
	Status      int32  `json:"status"`      // 1: 开始定向且无人机， 2: 定向无人机
}

func (TracerSOrientLog) TableName() string {
	return "tracerS_orientation_detect_drone"
}

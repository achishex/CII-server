package bean

type Sfl101DetectInfo struct {
	Id           int32   `json:"id"`
	Sn           string  `json:"sn"`
	Vendor       string  `json:"vendor"`
	DetectTime   int64   `json:"detect_time"`
	HitTime      int64   `json:"hit_time"`
	CounterTime  int64   `json:"counter_time"`
	Freq         float64 `json:"freq"`
	Direction    int64   `json:"direction"`
	PilotLongLat string  `json:"pilot_long_lat"`
	DroneHeight  float64 `json:"drone_height"`
	UDirStatus   int32   `json:"u_dir_status"` //新增定向状态 0:非定向状态 1：定向中 2：定向成功 其他：保留
	DevType      int32   `json:"dev_type"`
}

func (Sfl101DetectInfo) TableName() string {
	return "sfl101_detect_info"
}

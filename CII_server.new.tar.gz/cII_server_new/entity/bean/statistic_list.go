package bean

type StatisticList struct {
	Id           int32   `json:"id"`
	FlyCount     int32   `json:"fly_count"`
	AvgFlyTime   float64 `json:"avg_fly_time"`
	AvgFlyHeight float64 `json:"avg_fly_height"`
	LastTime     int64   `json:"last_time"`
}

func (StatisticList) TableName() string {
	return "statistic_list"
}

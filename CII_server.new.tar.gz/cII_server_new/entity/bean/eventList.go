package bean

type AutelEventList struct {
	Id        int32   `json:"id"`
	Eid       string  `json:"eid"`
	Vendor    string  `json:"vendor"`
	Model     string  `json:"model"`
	BeginTime string  `json:"begin_time"`
	EndTime   string  `json:"end_time"`
	Duration  float64 `json:"duration"`  // 单位：分钟
	Altitude  float64 `json:"altitude"`  // 单位：米
	Frequency float64 `json:"frequency"` // 单位：GHz
	Protocol  string  `json:"protocol"`
	Status    int8    `json:"status"` // -1事件结束，1事件开始
	Source    int8    `json:"source"` // 1雷达，2枪，3Tracer
	ObjId     uint32  `json:"obj_id"`
	SerialNum string  `json:"serial_num"`
}

func (AutelEventList) TableName() string {
	return "event_list"
}

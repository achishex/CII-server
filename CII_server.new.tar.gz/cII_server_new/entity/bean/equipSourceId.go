package bean

type EquipSourceId struct {
	Id         int    `json:"id"`
	Sn         string `json:"sn"`
	SourceId   int32  `json:"source_id"`
	CreateTime string `json:"create_time"`
	UpdateTime string `json:"update_time"`
}

func (EquipSourceId) TableName() string {
	return "equip_source_id"
}

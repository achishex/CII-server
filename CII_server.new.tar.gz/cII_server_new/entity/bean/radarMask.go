package bean

type RadarMask struct {
	Sn             string `json:"sn"`               //雷达sn
	AllDelete      bool   `json:"all_delete"`       //是否全部删除 0-否 1-是
	Masks          string `json:"masks"`            //筛选层
	AllDeleteValue int32  `json:"all_delete_value"` //0失效 1生效
}

func (RadarMask) TableName() string {
	return "radar_mask"
}

//go:build !(linux || android)

package iphelper

import (
	"net"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
)

// IPInfo 本地IP地址信息
type IPInfo struct {
	LocalIP     string //本地IP地址
	BroadCastIP string //本地IP地址对应的广播地址
}

// GetLocalIPInfos 获取所有本地网口IP地址
func GetLocalIPInfos() ([]IPInfo, error) {
	interfaces, err := net.Interfaces()
	if err != nil {
		logger.Error("Get local interfaces err %v", err)
		return nil, err
	}
	localIPInfos := []IPInfo{}
	for _, netIF := range interfaces {
		if (netIF.Flags & (net.FlagUp | net.FlagBroadcast | net.FlagLoopback)) == (net.FlagBroadcast | net.FlagUp) {
			addrs, err := netIF.Addrs()
			if err != nil {
				logger.Error("get net interface addr %+v err %v", netIF, err)
				continue
			}
			for _, addr := range addrs {
				if ipNet, ok := addr.(*net.IPNet); ok {
					if ipNet.IP.To4() != nil {
						broadcast := make(net.IP, len(ipNet.IP.To4()))
						for i := 0; i < len(ipNet.IP.To4()); i++ {
							broadcast[i] = ipNet.IP.To4()[i] | ^ipNet.Mask[i]
						}
						localIPInfos = append(localIPInfos, IPInfo{
							LocalIP:     ipNet.IP.To4().String(),
							BroadCastIP: broadcast.String(),
						})
					}
				}
			}
		}
	}
	return localIPInfos, nil
}

// MatchLocalIP 根据输入的IP匹配本地中相同网段的ip
func MatchLocalIP(ip string) string {
	interfaces, err := net.Interfaces()
	if err != nil {
		logger.Error("Get local interfaces err %v", err)
		return ""
	}
	for _, netIF := range interfaces {
		if (netIF.Flags & (net.FlagUp | net.FlagBroadcast | net.FlagLoopback)) == (net.FlagBroadcast | net.FlagUp) {
			addrs, err := netIF.Addrs()
			if err != nil {
				logger.Error("get net interface addr %+v err %v", netIF, err)
				continue
			}
			for _, addr := range addrs {
				if ipNet, ok := addr.(*net.IPNet); ok {
					if ipNet.IP.To4() != nil {
						if ipNet.Contains(net.ParseIP(ip)) {
							return ipNet.IP.To4().String()
						}
					}
				}
			}
		}
	}
	return ""
}

// GetFreeTCPPort 获取本地可用端口
func GetFreeTCPPort() (int, error) {
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		return 0, err
	}
	defer listener.Close()
	return listener.Addr().(*net.TCPAddr).Port, nil
}

// IPV4 字符串IP转换成IPv4
func IPV4(ip string) [4]uint8 {
	ips := net.ParseIP(ip)
	if ips == nil {
		logger.Error("invalid ip %s", ip)
		return [4]uint8{}
	}
	ipBytes := ips.To4()
	if ipBytes == nil {
		logger.Error("invalid ipv4 ip")
		return [4]uint8{}
	}
	var addr [4]uint8
	copy(addr[:], ipBytes)
	return addr
}

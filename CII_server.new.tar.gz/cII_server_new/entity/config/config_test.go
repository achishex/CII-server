package config

import (
	"reflect"
	"testing"
)

func TestGetGlobalConfig(t *testing.T) {
	tests := []struct {
		name string
		want *GlobalConfig
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := GetGlobalConfig(); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("GetGlobalConfig() = %v, want %v", got, tt.want)
			}
		})
	}
}

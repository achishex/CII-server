package common

import (
	"fmt"
	"testing"
)

func TestDroneName(t *testing.T) {
	{
		droneName := "DJI Mavic Air 2"
		serialNum := "15813N3BK1L012012G"
		reportProtoDroneName := ConstructDroneName(droneName, serialNum, 123456)
		t.Logf("protoDroneName: %s", reportProtoDroneName)

		downCmdDroneName := DeConstructDroneName(reportProtoDroneName, serialNum)
		if droneName != downCmdDroneName {
			t.Logf("down cmd drone name is not eq, srcLen: %v, dstLen: %v", len(droneName), len(downCmdDroneName))
			//
		} else {
			t.Logf("down cmd drone is eq: %v", downCmdDroneName)
		}
		t.Logf("downCmdDroneName: %s", downCmdDroneName)
	}

	{
		fmt.Println("-------")
		droneName := "DJI Mavic Air 2 "
		serialNum := "123"
		reportProtoDroneName := ConstructDroneName(droneName, serialNum, 0)
		t.Logf("protoDroneName: %s.", reportProtoDroneName)

		downCmdDroneName := DeConstructDroneName(reportProtoDroneName, serialNum)
		if droneName != downCmdDroneName {
			t.Logf("down cmd drone name is not eq, srcLen: %v, dstLen: %v", len(droneName), len(downCmdDroneName))
		} else {
			t.Logf("down cmd drone is eq: %v.", downCmdDroneName)
		}
		t.Logf("downCmdDroneName: %s.", downCmdDroneName)
	}

	{
		fmt.Println("-------")
		droneName := "DJI Mavic Air 2"
		serialNum := ""
		reportProtoDroneName := ConstructDroneName(droneName, serialNum, 123)
		t.Logf("protoDroneName: %s", reportProtoDroneName)

		downCmdDroneName := DeConstructDroneName(reportProtoDroneName, serialNum)
		if droneName != downCmdDroneName {
			t.Logf("down cmd drone name is not eq, srcLen: %v, dstLen: %v", len(droneName), len(downCmdDroneName))
		} else {
			t.Logf("down cmd drone is eq: %v", droneName)
		}
		t.Logf("downCmdDroneName: %s", downCmdDroneName)
	}

	{
		fmt.Println("------------")
		reportProtoDroneName := "DJI Mavic Air 2"
		serialNum := ""
		downCmdDroneName := DeConstructDroneName(reportProtoDroneName, serialNum)
		if reportProtoDroneName != downCmdDroneName {
			t.Logf("down cmd drone name is not eq, srcLen: %v, dstLen: %v", len(reportProtoDroneName), len(downCmdDroneName))
			//
		} else {
			t.Logf("down cmd drone is eq: %v", reportProtoDroneName)
		}
		t.Logf("downCmdDroneName: %s", downCmdDroneName)
	}
}

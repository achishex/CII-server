package common

import (
	"fmt"
	"strconv"
	"strings"
	"sync"
	"time"
)

type DeviceType uint8 //设备类型
func (d *DeviceType) ToString() string {
	return "deviceType: " + strconv.Itoa(int(*d))
}

const (
	//反制枪
	DEV_AEAG DeviceType = 1
	//屏幕
	DEV_SCREEN DeviceType = 2
	//雷达
	DEV_RADAR DeviceType = 3
	//PC端服务
	DEV_PC DeviceType = 4
	//C2 蓝牙
	DEV_C2_BLE DeviceType = 5
	//C2 WiFi
	DEV_C2_WIFI DeviceType = 6
	//C2 droneID
	DEV_V2DRONEID DeviceType = 7
	// DEV_URD360 Urd360
	DEV_URD360 DeviceType = 8
	//NSF4000 cheater
	DEV_NSF4000 DeviceType = 9
	//小枪
	Dev_Blader DeviceType = 10

	//C2_Sfl 云台
	DEV_SFL DeviceType = 11
	//C2_AGX_雷达融合平台
	DEV_AGX DeviceType = 12
	//Sfl200
	DEV_SFL200 DeviceType = 13
	//枪+云台
	DEV_HUNTER_PLATFORM DeviceType = 14

	//DPH110 中程雷达
	DEV_DPH110 DeviceType = 16

	//中程雷视
	DEV_SRP200 = 17

	//激光雷达(agx)
	DEV_SBP100 = 18

	//激光雷达(单独)
	DEV_LASER = 19

	// 0x14(20) 预留
	//...

	//tracer+枪
	DEV_TracerGun = 0x15

	//新车载FPV  DEV_SVH
	DEV_SVH = 0x16

	//C2_Fpv 车载
	DEV_FPV DeviceType = 0x17

	//spoofer 电量监测设备
	DEV_SPOOFER_MONITOR DeviceType = 0x18

	//SFL移动式
	DEV_SFL101 DeviceType = 0x19
	// 固定式 p+s 新设备
	DEV_STP120 = 0x20

	//SRP150 雷视便携
	DEV_SRP150 DeviceType = 0x0F

	//广播模式
	DEV_BROADCAST DeviceType = 255
)

// RadarModeType 雷达模式
type RadarModeType uint32

const (
	RESET                  RadarModeType = 1 //系统复位
	RESTORE                RadarModeType = 2 //恢复出厂设置
	STATUSREPORTPERIOD     RadarModeType = 3 //设置状态上报周期(默认100ms)
	TARGETREPORTPERIOD     RadarModeType = 4 //设置目标上报周期(默认100ms)
	AUTOPOSTURECALIBRATION RadarModeType = 5 //自动标定姿态信息
	REALTIMEPOSTURE        RadarModeType = 6 //使用实时姿态信息
	STARTDETECT            RadarModeType = 7 //雷达开始侦测
	ENDDETECT              RadarModeType = 8 //雷达结束侦测
)

const (
	RadarV1Detecting = 2
	RadarV2Detecting = 4

	//sfl200
	Sfl200EventOnLine            = 2000
	Sfl200EventOffLine           = 2001
	Sfl200EventHitSucc           = 2002
	Sfl200EventHitFail           = 2002
	Sfl200EventDetectAppear      = 2003
	Sfl200EventDetectDisAppear   = 2004
	Sfl200AgxDetectAppear        = 2005
	Sfl200AgxDetectDisappear     = 2006
	Sfl200AgxEventPtzLockUavFail = 2007
	Sfl200AgxEventPtzLockUavSucc = 2008
)

// DeviceType:
// 设备类型
// 0x01: 近程雷达
// 0x02: 近程PTZ
// 0x04: tracerP
// 0x05: 无线电设备
// 0x06：哨兵塔
// 0x07：
// 0x08：中程雷达
// 0x09：中程PTZ
var SubDevTYpeToEtypeMap = map[uint8]string{
	1: "radar",
	4: "DroneID",
	6: "Sfl",
	8: "Dph110",
}

const (
	TracerP       = 1
	TracerS       = 2
	TracerMax4T   = 3
	TracerMachine = 4
	TracerSFL     = 5
	TracerFPV     = 6
)
const (
	UnknowOs byte = 0
	Android  byte = 1
	Linux    byte = 2
	Windows  byte = 3
)
const (
	MaxReceiveSize = 1024
)

const (
	DevOnline  = 0 //设备在线
	DevOffline = 1 //设备离线
)

const (
	DeviceEnable    = 1 //设备启用
	DeviceDisenable = 2 //设备禁用
)

const (
	ProtoTypeSlink = 1
	ProtoTypeJson  = 2
	ProtoTypeProto = 3
)

type CtxKey string

const (
	// UDPAddrCxtKey 远程IP地址上下文Key
	UDPAddrCxtKey CtxKey = "UDPRemoteAddr"
	// PacketHeadCxtKey 包头上下文Key
	PacketHeadCxtKey CtxKey = "PacketHead"
	// ProtoTypeCxtKey 协议类型
	ProtoTypeCxtKey CtxKey = "ProtoType"
)
const (
	TracerWGetVersion = "1.0.51"
)

type EquipmentStatusEntity struct {
	Name      string      `json:"name"` //名称
	Sn        string      `json:"sn"`   //sn
	Info      interface{} `json:"info"`
	EquipType int         `json:"equip_type"` //设备类型
	MsgType   int         `json:"msg_type"`   //消息类型
}

type EquipmentMessageBoxEntity struct {
	Name         string      `json:"name"` //名称
	Sn           string      `json:"sn"`   //sn
	Info         interface{} `json:"info"`
	EquipType    int         `json:"equip_type"`    //设备类型
	MsgType      int         `json:"msg_type"`      //消息类型
	ParentType   int         `json:"parent_type"`   //父设备类型
	ParentSn     string      `json:"parent_sn"`     //父设备sn
	IsIntegrated int32       `json:"is_integrated"` //是否是一体化设备 0-非一体化 1-一体化
}

type Uav struct {
	Name           [20]byte
	UFreq          uint32
	UDistance      uint16
	UDangerLevels  uint16
	DroneLongitude uint32
	DroneLatitude  uint32
	DroneAltitude  uint16
}

type UavReport struct {
	Name           string  `json:"name"`
	UFreq          uint32  `json:"u_freq"`
	UDistance      uint16  `json:"u_distance"`
	UDangerLevels  uint16  `json:"u_danger_levels"`
	DroneLongitude float64 `json:"drone_longitude"`
	DroneLatitude  float64 `json:"drone_latitude"`
	DroneAltitude  uint16  `json:"drone_altitude"`
}

type GunStatusReport struct {
	Sn             string  `json:"sn"`
	ScreenStatus   uint8   `json:"screen_status"`
	Electricity    uint8   `json:"electricity"`
	SignalStrength uint8   `json:"signal_strength"`
	WorkStatus     uint8   `json:"work_status"`
	AlarmLevel     uint8   `json:"alarm_level"`
	HitFreq        uint8   `json:"hit_freq"`
	DetectFreq     uint32  `json:"detect_freq"`
	X              uint16  `json:"x"`
	Y              uint16  `json:"y"`
	Z              uint16  `json:"z"`
	GunLongitude   float64 `json:"gun_longitude"`
	GunLatitude    float64 `json:"gun_latitude"`
	GunAltitude    uint16  `json:"gun_altitude"`
	SatellitesNum  uint16  `json:"satellites_num"`
	GunDirection   uint16  `json:"gun_direction"`
	TimeStamp      uint32  `json:"time_stamp"`
	UUAVNum        uint8   `json:"uuav_num"`
	IsOnline       int     `json:"is_online"`
}

type AeagHeartbeatReport struct {
	Heartbeat *GunStatusReport `json:"heartbeat"`
	Uavs      []*UavReport     `json:"uavs"`
}

type IpAddr struct {
	Ip   string `json:"ip"`
	Port int    `json:"port"`
}

type RadarStatusEntity struct {
	Electricity   int32    `json:"electricity"` //电量
	Status        int      `json:"status"`      //系统状态0：正常工作	1：待机
	IsOnline      int      `json:"is_online"`
	Ip            string   `json:"ip"`             //ip地址
	SerialNum     string   `json:"serial_num"`     //序列号
	Faults        []string `json:"faults"`         //故障信息
	SysStatus     int32    `json:"sys_status"`     //系统消息
	EventId       string   `json:"event_id"`       //添加事件id
	DPH110Version string   `json:"dph110_version"` //一体机版本号
	VersionType   int32    `json:"version_type"`   //1-雷达T5, 2-雷达T6
}
type DbRawAutelRadarPlotTrackBodyEntity struct {
	Obj_id            uint32  `json:"obj_id"`
	HeaderUid         int64   `json:"header_uid"`
	Azimuth           float64 `json:"azimuth"`
	Obj_dist_interpol float64 `json:"obj_dist_interpol"`
	Elevation         float64 `json:"elevation"`
	Velocity          float64 `json:"velocity"`
	Doppler_chn       int16   `json:"doppler_chn"`
	Mag               float64 `json:"mag"`
	Ambiguous         int16   `json:"ambiguous"`
	Classification    int16   `json:"classification"`
	Classfy_prob      float64 `json:"classfy_prob"`
	ExistingProb      float32 `json:"existing_prob"`
	Abs_vel           float64 `json:"abs_vel"`
	Orientation_angle float64 `json:"orientation_angle"`
	Alive             uint16  `json:"alive"`
	Tws_tas_flag      uint16  `json:"tws_tas_flag"`
	X                 float64 `json:"x"`
	Y                 float64 `json:"y"`
	Z                 float64 `json:"z"`
	VX                float64 `json:"vx"`
	VY                float64 `json:"vy"`
	VZ                float64 `json:"vz"`
	AX                float64 `json:"ax"`
	AY                float64 `json:"ay"`
	AZ                float64 `json:"az"`
	X_variance        float64 `json:"x_variance"`
	Y_variance        float64 `json:"y_variance"`
	Z_variance        float64 `json:"z_variance"`
	Vx_variance       float64 `json:"vx_variance"`
	Vy_variance       float64 `json:"vy_variance"`
	Vz_variance       float64 `json:"vz_variance"`
	Ax_variance       float64 `json:"ax_variance"`
	Ay_variance       float64 `json:"ay_variance"`
	Az_variance       float64 `json:"az_variance"`
	State_type        int16   `json:"state_type"`
	Motion_type       int16   `json:"motion_type"`
	Forcast_frame_num int16   `json:"forcast_frame_num"`
	Association_num   int16   `json:"association_num"`
	Assoc_bit0        uint32  `json:"assoc_bit0"`
	Assoc_bit1        uint32  `json:"assoc_bit1"`
	Reserve           uint16  `json:"reserve"`
	Reserved2         uint16  `json:"reserved2"`
	Crc               uint16  `json:"crc"`
	Create_time       string  `json:"create_time"`
	Vendor            string  `json:"vendor"`
	Frequency         string  `json:"frequency"`
	Model             string  `json:"model"`
	Is_whitelist      bool    `json:"is_whitelist"`
	Level             int     `json:"level"`
	Longitude         float64 `json:"longitude"` //无人机经度
	Latitude          float64 `json:"latitude"`  //无人机纬度
	//Distance          float64 `json:"distance"`
	AlarmId     string `json:"alarm_id"`     //告警ID
	ThreatLevel int32  `json:"threat_level"` //威胁等级，高（80-100分）、中（50-79分）、低（1-49分），0-无威胁
	ScenesId    int32  `json:"scenes_id"`    //场景 1-无围栏区， 2-预警区， 3-核心区， 4-核心区+预警区
	EventId     string `json:"event_id"`     //事件ID，同一个无人机威胁等级发生变化，事件ID不变
	DroneName   string `json:"drone_name"`   //无人机名称
}

type RadarUploadPostureEntity struct {
	Reserved     uint8   `json:"reserved"`
	Heading      float64 `json:"heading"`   //航线角度
	Pitching     float64 `json:"pitching"`  //纵摇角度
	Rolling      float64 `json:"rolling"`   //横滚角度
	Longitude    float64 `json:"longitude"` //
	Latitude     float64 `json:"latitude"`  //
	Altitude     float64 `json:"altitude"`
	VelocityNavi float64 `json:"velocity_navi"` //导航速度（m/s）
	//TargetTimeMark      [6]uint16 `json:"target_time_mark"`       //目标时标
	SigProcRelativeTime float64 `json:"sig_proc_relative_time"` //目标时标（绝对时间）
}

type DeviceEventEntity struct {
	Id         int    `json:"id"`
	DeviceType int    `json:"device_type"`
	Sn         string `json:"sn"`
	MsgId      uint8  `json:"msg_id"`
	Request    string `json:"request"`
	Response   string `json:"response"`
	Remark     string `json:"remark"`
	CreateTime int    `json:"create_time"`
}

type ScreenHitStatusEntity struct {
	WorkStatus uint8           `json:"work_status"` //枪工作状态 0x00: 侦测模式（打击结束) 0x01: 打击中
	DroneNum   uint8           `json:"drone_num"`   //打击的无人机个数
	Uavs       []*HitUavEntity `json:"uavs"`
}

type HitUavEntity struct {
	ObjId          uint8  `json:"obj_id"`       //	无人机唯一标识
	ProductType    uint8  `json:"product_type"` //	无人机类型
	DroneName      string `json:"drone_name"`   //无人机名称
	SerialNum      string `json:"serial_num"`
	DroneLongitude int32  `json:"drone_longitude"` //LSB无人机经度(/1e7/pi*180)
	DroneLatitude  int32  `json:"drone_latitude"`  //LSB无人机纬度(/1e7/pi*180)
	DroneHeight    int16  `json:"drone_height"`    //LSB无人机相对地面高度(0.1m)
}

type ScreenHeartBeatEntity struct {
	Id             int                    `json:"id"`
	HeaderId       int64                  `json:"header_id"`
	TimeStamp      uint32                 `json:"timeStamp"`
	ScreenStatus   uint8                  `json:"screenStatus"`
	Electricity    uint8                  `json:"electricity"`
	SignalStrength uint8                  `json:"signalStrength"`
	WorkStatus     uint8                  `json:"workStatus"`
	AlarmLevel     uint8                  `json:"alarmLevel"`
	HitFreq        uint8                  `json:"hitFreq"`
	DetectFreq     uint32                 `json:"detectFreq"`
	X              uint16                 `json:"x"`
	Y              uint16                 `json:"y"`
	Z              uint16                 `json:"z"`
	GunLongitude   float64                `json:"gunLongitude"`
	GunLatitude    float64                `json:"gunLatitude"`
	GunAltitude    int32                  `json:"gunAltitude"`
	SatellitesNum  uint16                 `json:"satellitesNum"`
	GunDirection   float64                `json:"gunDirection"`
	ReHitTime      uint16                 `json:"reHitTime,omitempty"`
	HitTime        uint16                 `json:"hitTime,omitempty"`
	UDroneNum      uint8                  `json:"uDroneNum"`
	Elevation      float64                `json:"elevation"`
	IsOnline       int                    `json:"is_online"`
	Info           []ScreenHeartUavEntity `json:"info"`
}

type ScreenHeartUavEntity struct {
	ProductType        int     `json:"productType"`
	DroneName          string  `json:"droneName"`
	SerialNum          string  `json:"serialNum"`
	DroneLongitude     float64 `json:"droneLongitude"`
	DroneLatitude      float64 `json:"droneLatitude"`
	DroneHeight        float64 `json:"droneHeight"`
	DroneYawAngle      float64 `json:"droneYawAngle"`
	DroneSpeed         float64 `json:"droneSpeed"`
	DroneVerticalSpeed float64 `json:"droneVerticalSpeed"`
	PilotLongitude     float64 `json:"pilotLongitude"`
	PilotLatitude      float64 `json:"pilotLatitude"`
	DroneHorizon       float64 `json:"droneHorizon,omitempty"`
	DronePitch         float64 `json:"dronePitch,omitempty"`
	UFreq              float64 `json:"uFreq"`
	UDistance          int     `json:"uDistance"`
	UDangerLevels      int     `json:"uDangerLevels"`
}

type ReportEntity struct {
	ReportTime time.Time
	Queue      *EquipmentMessageBoxEntity
	Lock       sync.Mutex
	LimitRate  int64 //限素（毫秒）
}

type DeviceDiscoverEntity struct {
	Sn         string `json:"sn"`
	DeviceName string `json:"device_name"`
	Company    string `json:"company"`
	DeviceType string `json:"device_type"`
	Version    string `json:"version"`
}

// ConstructDroneName 协议无人机名称=机型+SN后4位数，频谱的无人机名称=机型+uNumber
func ConstructDroneName(namePrefix, sn string, uNumber uint32) string {
	if sn != "" {
		snLength := len(sn)
		if snLength >= 4 {
			snSuffix := sn[snLength-4:]
			return fmt.Sprintf("%s#%s", namePrefix, snSuffix)
		} else {
			return namePrefix
		}
	}
	return fmt.Sprintf("%s#%d", namePrefix, uNumber)
}

// DeConstructDroneName srcDroneName 是拼接后的无人机名称， sn是无人机序列号， 返回未拼接的无人机名称
func DeConstructDroneName(srcDroneName, sn string) string {
	if snLen := len(sn); snLen > 0 {
		if snLen < 4 {
			return srcDroneName
		}

		index := strings.LastIndex(srcDroneName, "#")
		if index == -1 {
			return srcDroneName
		}
		return srcDroneName[0:index]
	}

	index := strings.LastIndex(srcDroneName, "#")
	if index == -1 {
		return srcDroneName
	}
	return srcDroneName[0:index]
}

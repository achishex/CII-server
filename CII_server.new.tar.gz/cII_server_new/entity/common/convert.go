package common

import (
	"fmt"
	"math"
	"strconv"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
)

const (
	metersPerDegree float64 = 111319.9
	//赤道半径（WGS84椭球）
	equatorRadius = 6378137.0
	//极半径（WGS84椭球）
	polarRadius = 6356752.314245
	// WGS84 扁率
	flattening = 1 / 298.257223563
)

type Coord3D struct {
	X, Y, Z float64
}

func ConvertToLatLon(longitude, latitude float64, coord Coord3D) (float64, float64) {
	//X轴对应北方向，Y轴对应西方向
	lat := latitude + (coord.X / metersPerDegree)
	lon := longitude - (coord.Y / (metersPerDegree * math.Cos(math.Pi*latitude/180.0)))

	return lon, lat
}

// 中程雷达特殊处理
func ConvertToLatLonDPH110(longitude, latitude float64, coord Coord3D) (float64, float64) {
	lat := latitude + (coord.X / metersPerDegree)
	lon := longitude + (coord.Y / (metersPerDegree * math.Cos(math.Pi*latitude/180.0)))

	return lon, lat
}

func CuaDistance(lat1, lon1, lat2, lon2 float64) float64 {
	var R float64 = 6371000 // Earth radius in meters
	var temp1 = lat1 * math.Pi / 180
	var temp2 = lat2 * math.Pi / 180
	var temp3 = (lat2 - lat1) * math.Pi / 180
	var temp4 = (lon2 - lon1) * math.Pi / 180

	var a = math.Sin(temp3/2)*math.Sin(temp3/2) +
		math.Cos(temp1)*math.Cos(temp2)*
			math.Sin(temp4/2)*math.Sin(temp4/2)
	var c = 2 * math.Atan2(math.Sqrt(a), math.Sqrt(1-a))

	var distance = R * c // in meters

	return distance
}

func Decimal(value float64, prec int) float64 {
	var err error
	value, err = strconv.ParseFloat(strconv.FormatFloat(value, 'f', prec, 64), 64)
	if err != nil {
		logger.Error("Decimal error:", err)
		return 0
	}
	return value
}

// RoundFloat 保留小数点后8位，不足补充0， 超过四舍五入
func RoundFloat(num float64) float64 {
	rounded := math.Round(num*math.Pow10(8)) / math.Pow10(8)
	formatted := fmt.Sprintf("%.8f", rounded)

	f, err := strconv.ParseFloat(formatted, 64)
	if err != nil {
		logger.Error("RoundFloat error:", err)
		return 0
	}
	return f
}

func ConvertToUint32(slice []uint16) []uint32 {
	var result []uint32
	for _, value := range slice {
		result = append(result, uint32(value))
	}
	return result
}

type LatLng struct {
	Latitude  float64
	Longitude float64
}

// Vincenty 是一个假设的结构体，用于调用 offset 方法
type Vincenty struct{}

// Offset 方法模拟 Vincenty 的 offset 方法
func (v *Vincenty) Offset(from LatLng, distanceInMeter, bearing float64) (LatLng, error) {
	const equatorialRadius = equatorRadius

	latitude := degToRadian(from.Latitude)
	longitude := degToRadian(from.Longitude)
	sinAlpha1 := math.Sin(bearing)
	cosAlpha1 := math.Cos(bearing)

	tanU1 := (1 - flattening) * math.Tan(latitude)
	cosU1 := 1 / math.Sqrt((1 + tanU1*tanU1))
	sinU1 := tanU1 * cosU1

	sigma1 := math.Atan2(tanU1, cosAlpha1)
	sinAlpha := cosU1 * sinAlpha1
	cosSqAlpha := 1 - sinAlpha*sinAlpha
	dfUSq := cosSqAlpha *
		(equatorialRadius*equatorialRadius - polarRadius*polarRadius) /
		(polarRadius * polarRadius)
	a := 1 +
		dfUSq/16384*(4096+dfUSq*(-768+dfUSq*(320-175*dfUSq)))
	b := dfUSq / 1024 * (256 + dfUSq*(-128+dfUSq*(74-47*dfUSq)))

	var sigma = distanceInMeter / (polarRadius * a)
	var sigmaP = 2 * math.Pi

	var sinSigma, cosSigma, cos2SigmaM, deltaSigma float64
	var maxIterations = 200

	cos2SigmaM = math.Cos(2*sigma1 + sigma)
	sinSigma = math.Sin(sigma)
	cosSigma = math.Cos(sigma)
	deltaSigma = b *
		sinSigma *
		(cos2SigmaM +
			b/
				4*
				(cosSigma*(-1+2*cos2SigmaM*cos2SigmaM)-
					b/
						6*
						cos2SigmaM*
						(-3+4*sinSigma*sinSigma)*
						(-3+4*cos2SigmaM*cos2SigmaM)))
	sigmaP = sigma
	sigma = distanceInMeter/(polarRadius*a) + deltaSigma

	maxIterations--
	for math.Abs(sigma-sigmaP) > 1e-12 && maxIterations > 0 {
		cos2SigmaM = math.Cos(2*sigma1 + sigma)
		sinSigma = math.Sin(sigma)
		cosSigma = math.Cos(sigma)
		deltaSigma = b *
			sinSigma *
			(cos2SigmaM +
				b/
					4*
					(cosSigma*(-1+2*cos2SigmaM*cos2SigmaM)-
						b/
							6*
							cos2SigmaM*
							(-3+4*sinSigma*sinSigma)*
							(-3+4*cos2SigmaM*cos2SigmaM)))
		sigmaP = sigma
		sigma = distanceInMeter/(polarRadius*a) + deltaSigma
		maxIterations--
	}

	if maxIterations == 0 {
		msg := fmt.Sprintf("offset calculation failed to converge after %d iterations", maxIterations)
		logger.Error(msg)
		return LatLng{}, fmt.Errorf(msg)
	}

	tmp := sinU1*sinSigma - cosU1*cosSigma*cosAlpha1
	lat2 := math.Atan2(sinU1*cosSigma+cosU1*sinSigma*cosAlpha1,
		(1-flattening)*math.Sqrt(sinAlpha*sinAlpha+tmp*tmp))

	lambda := math.Atan2(
		sinSigma*sinAlpha1, cosU1*cosSigma-sinU1*sinSigma*cosAlpha1)
	c :=
		flattening / 16 * cosSqAlpha * (4 + flattening*(4-3*cosSqAlpha))
	l := lambda -
		(1-c)*
			flattening*
			sinAlpha*
			(sigma+
				c*
					sinSigma*
					(cos2SigmaM+
						c*cosSigma*(-1+2*cos2SigmaM*cos2SigmaM)))

	var lon2 = longitude + l
	// print("LA ${radianToDeg(lat2)}, LO ${radianToDeg(lon2)}");

	if lon2 > math.Pi {
		lon2 = lon2 - 2*math.Pi
	}
	if lon2 < -1*math.Pi {
		lon2 = lon2 + 2*math.Pi
	}

	return LatLng{
		Latitude:  RadianToDegree(lat2),
		Longitude: RadianToDegree(lon2),
	}, nil
}

// GetLatLngByXY 根据地图中心点和偏移量计算新的经纬度
// notice: x对应侦测数据y，y对应侦测数据x
func GetLatLngByXY(mapCenter LatLng, x, y float64) (LatLng, error) {
	distance := math.Sqrt(math.Pow(x, 2) + math.Pow(y, 2))

	// 根据 xy 计算与y轴的夹角度数
	radian := math.Atan2(x, y)

	vincenty := &Vincenty{}
	res, err := vincenty.Offset(mapCenter, distance, radian)

	// if (res.Longitude == 0 && res.Latitude == 0) {
	//   debugPrint('getLatLngByXY error: $x, $y, $distance, $radian')
	// }

	return res, err
}

// degToRadian 将角度转换为弧度
func degToRadian(deg float64) float64 {
	return deg * (math.Pi / 180.0)
}

// RadianToDegree 将弧度转换为角度
func RadianToDegree(rad float64) float64 {
	return rad * (180.0 / math.Pi)
}

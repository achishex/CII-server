package common

import (
	"fmt"
	"sync"
	"time"

	"adasgitlab.autel.com/tools/cuav_server/proto/client"
)

type File struct {
	Name     string
	FilePath string
}
type FileMapSet struct {
	FileMap map[uint32]File
	mutex   sync.RWMutex
}

func NewFileMapSet() *FileMapSet {
	return &FileMapSet{
		FileMap: make(map[uint32]File),
		mutex:   sync.RWMutex{},
	}
}

func (s *FileMapSet) Set(k uint32, name string, filePath string) uint32 {
	s.mutex.Lock()
	defer s.mutex.Unlock()
	s.FileMap[k] = File{name, filePath}
	return k
}

func (s *FileMapSet) Get(k uint32) (*File, bool) {
	s.mutex.RLock()
	defer s.mutex.RUnlock()

	file, ok := s.FileMap[k]
	if !ok {
		return nil, false
	}
	return &file, true
}

func (s *FileMapSet) Del(k uint32) {
	s.mutex.Lock()
	defer s.mutex.Unlock()

	delete(s.FileMap, k)
}

type SflHitEventInfo struct {
	Sn               string // 设备sn
	UavSn            string //无人机sn
	ProductType      int32
	HitOverTime      time.Time // 打击结束时间，ms
	SessionId        int64
	DetectReportTime time.Time
	DroneName        string
	DroneLongitude   float64
	DroneLatitude    float64
	DroneHeight      float64
	DroneYawAngle    float64
}
type SflDetectInfo struct {
	Sn           string  //无人机sn
	Vendor       string  //厂商
	DetectTime   int64   //探测时间
	HitTime      int64   //打击时间
	CounterTime  int64   //反制时长
	Freq         float64 //频率
	Direction    int64   //方位
	PilotLongLat string  //飞手/返航点经纬度
	LastTime     int64   //最近一次出现时间
	UDirStatus   int32   //新增定向状态 0：非定向状态 1：定向中 2：定向成功 其他：保留
}
type SflDetectInfoMapSet struct {
	SnMap map[string]SflDetectInfo
	mutex sync.RWMutex
}

func NewSflDetectInfoMap() *SflDetectInfoMapSet {
	return &SflDetectInfoMapSet{
		SnMap: make(map[string]SflDetectInfo),
		mutex: sync.RWMutex{},
	}
}
func (s *SflDetectInfoMapSet) UpdateHitTime(sn string, hitTime int64) bool {
	s.mutex.Lock()
	defer s.mutex.Unlock()

	dev, ok := s.SnMap[sn]
	if !ok {
		return false
	}

	dev.HitTime = hitTime
	s.SnMap[sn] = dev

	return true
}
func (s *SflDetectInfoMapSet) Set(sn string, vendor string, detectTime, hitTime, countTime int64,
	freq float64, direction int64, pilot string, lastTime int64, uDirStatus int32) string {
	s.mutex.Lock()
	defer s.mutex.Unlock()
	s.SnMap[sn] = SflDetectInfo{sn, vendor, detectTime, hitTime, countTime,
		freq, direction, pilot, lastTime, uDirStatus}
	return sn
}

func (s *SflDetectInfoMapSet) Get(sn string) (*SflDetectInfo, bool) {
	s.mutex.RLock()
	defer s.mutex.RUnlock()

	dev, ok := s.SnMap[sn]
	if !ok {
		return nil, false
	}
	return &dev, true
}
func (s *SflDetectInfoMapSet) GetAll() map[string]SflDetectInfo {
	s.mutex.RLock()
	defer s.mutex.RUnlock()

	snMapCopy := make(map[string]SflDetectInfo, len(s.SnMap))
	for k, v := range s.SnMap {
		snMapCopy[k] = v
	}
	return snMapCopy
}
func (s *SflDetectInfoMapSet) Clear() {
	s.mutex.Lock()
	defer s.mutex.Unlock()

	for k := range s.SnMap {
		delete(s.SnMap, k)
	}
}
func (s *SflDetectInfoMapSet) Del(k string) {
	s.mutex.Lock()
	defer s.mutex.Unlock()

	delete(s.SnMap, k)
}

type Sfl200FreqDirectHitSet struct {
	UavMap map[string]map[string]SflHitEventInfo
	mutex  sync.RWMutex
}

func NewSfl200FreqDirectHitMap() *Sfl200FreqDirectHitSet {
	return &Sfl200FreqDirectHitSet{
		UavMap: make(map[string]map[string]SflHitEventInfo),
		mutex:  sync.RWMutex{},
	}
}

func (s *Sfl200FreqDirectHitSet) Set(req *client.Sfl200FreqDirectHitRequest) {
	s.mutex.Lock()
	defer s.mutex.Unlock()
	if _, ok := s.UavMap[req.Sn]; !ok {
		s.UavMap[req.Sn] = make(map[string]SflHitEventInfo)
	}
	s.UavMap[req.Sn][s.getDroneKey(req.DroneName, req.DroneSn)] = SflHitEventInfo{
		Sn:             req.GetSn(),
		UavSn:          req.GetDroneSn(),
		DroneName:      req.GetDroneName(),
		DroneLongitude: float64(req.GetDroneLongitude() * 1e7),
		DroneLatitude:  float64(req.GetDroneLatitude()),
		DroneHeight:    float64(req.GetDroneHeight()),
		DroneYawAngle:  float64(req.GetDroneYawAngle()),
	}
}

func (s *Sfl200FreqDirectHitSet) UpdateHitOverTime(devSn, droneName string, hitOverTime int64) bool {
	s.mutex.Lock()
	defer s.mutex.Unlock()

	if _, ok := s.UavMap[devSn]; !ok {
		return false
	}
	dev, ok := s.UavMap[devSn][droneName]
	if !ok {
		return false
	}
	dev.HitOverTime = time.UnixMilli(hitOverTime)
	s.UavMap[devSn][droneName] = dev
	return true
}

func (s *Sfl200FreqDirectHitSet) Get(devSn, droneName, droneSn string) (*SflHitEventInfo, bool) {
	s.mutex.RLock()
	defer s.mutex.RUnlock()

	if _, ok := s.UavMap[devSn]; !ok {
		return nil, false
	}
	dev, ok := s.UavMap[devSn][s.getDroneKey(droneName, droneSn)]
	if !ok {
		return nil, false
	}
	return &dev, true
}
func (s *Sfl200FreqDirectHitSet) GetAll(devSn string) (map[string]SflHitEventInfo, bool) {
	s.mutex.RLock()
	defer s.mutex.RUnlock()

	UavMapCopy := make(map[string]SflHitEventInfo)
	if droneMap, ok := s.UavMap[devSn]; !ok {
		return nil, false
	} else {
		for k, v := range droneMap {
			UavMapCopy[k] = v
		}
	}
	return UavMapCopy, true
}
func (s *Sfl200FreqDirectHitSet) Clear() {
	s.mutex.Lock()
	defer s.mutex.Unlock()

	for k := range s.UavMap {
		delete(s.UavMap, k)
	}
}
func (s *Sfl200FreqDirectHitSet) Del(k string) {
	s.mutex.Lock()
	defer s.mutex.Unlock()

	delete(s.UavMap, k)
}

func (s *Sfl200FreqDirectHitSet) getDroneKey(droneName, droneSn string) string {
	return fmt.Sprintf("%s%s%s", droneName, "-", droneSn)
}

type RadarReplaySn struct {
	Sn      string
	IsStore bool
}

type RadarReplaySnMapSet struct {
	SnMap map[string]RadarReplaySn
	mutex sync.RWMutex
}

func NewRadarReplaySnMapSet() *RadarReplaySnMapSet {
	return &RadarReplaySnMapSet{
		SnMap: make(map[string]RadarReplaySn),
		mutex: sync.RWMutex{},
	}
}

func (s *RadarReplaySnMapSet) Set(k string, sn string, IsStore bool) string {
	s.mutex.Lock()
	defer s.mutex.Unlock()
	s.SnMap[k] = RadarReplaySn{sn, IsStore}
	return k
}

func (s *RadarReplaySnMapSet) Get(k string) (*RadarReplaySn, bool) {
	s.mutex.RLock()
	defer s.mutex.RUnlock()

	dev, ok := s.SnMap[k]
	if !ok {
		return nil, false
	}
	return &dev, true
}
func (s *RadarReplaySnMapSet) GetAll() map[string]RadarReplaySn {
	s.mutex.RLock()
	defer s.mutex.RUnlock()

	snMapCopy := make(map[string]RadarReplaySn, len(s.SnMap))
	for k, v := range s.SnMap {
		snMapCopy[k] = v
	}
	return snMapCopy
}
func (s *RadarReplaySnMapSet) Clear() {
	s.mutex.Lock()
	defer s.mutex.Unlock()

	for k := range s.SnMap {
		delete(s.SnMap, k)
	}
}
func (s *RadarReplaySnMapSet) Del(k string) {
	s.mutex.Lock()
	defer s.mutex.Unlock()

	delete(s.SnMap, k)
}

type DevNFS struct {
	Sn     string
	Status int
}

type DevNFSMapSet struct {
	Status map[string]DevNFS
	mutex  sync.RWMutex
}

func NewDeviceNFSMapSet() *DevNFSMapSet {
	return &DevNFSMapSet{
		Status: make(map[string]DevNFS),
		mutex:  sync.RWMutex{},
	}
}

func (s *DevNFSMapSet) Set(sn string, status int) string {
	s.mutex.Lock()
	defer s.mutex.Unlock()
	s.Status[sn] = DevNFS{sn, status}
	return sn
}

func (s *DevNFSMapSet) Get(k string) (*DevNFS, bool) {
	s.mutex.RLock()
	defer s.mutex.RUnlock()

	dev, ok := s.Status[k]
	if !ok {
		return nil, false
	}
	return &dev, true
}
func (s *DevNFSMapSet) GetAll() map[string]DevNFS {
	s.mutex.RLock()
	defer s.mutex.RUnlock()

	snMapCopy := make(map[string]DevNFS, len(s.Status))
	for k, v := range s.Status {
		snMapCopy[k] = v
	}
	return snMapCopy
}
func (s *DevNFSMapSet) Clear() {
	s.mutex.Lock()
	defer s.mutex.Unlock()

	for k := range s.Status {
		delete(s.Status, k)
	}
}
func (s *DevNFSMapSet) Del(k string) {
	s.mutex.Lock()
	defer s.mutex.Unlock()

	delete(s.Status, k)
}

type Sfl101HitEventInfo struct {
	Sn               string // 设备sn
	UavSn            string //无人机sn
	ProductType      int32
	HitOverTime      time.Time // 打击结束时间，ms
	SessionId        int64
	DetectReportTime time.Time
	DroneName        string
	DroneLongitude   float64
	DroneLatitude    float64
	DroneHeight      float64
	DroneYawAngle    float64
}
type Sfl101DetectInfo struct {
	Sn           string  //无人机sn
	Vendor       string  //厂商
	DetectTime   int64   //探测时间
	HitTime      int64   //打击时间
	CounterTime  int64   //反制时长
	Freq         float64 //频率
	Direction    int64   //方位
	PilotLongLat string  //飞手/返航点经纬度
	LastTime     int64   //最近一次出现时间
	UDirStatus   int32   //新增定向状态 0：非定向状态 1：定向中 2：定向成功 其他：保留
}
type Sfl101DetectInfoMapSet struct {
	SnMap map[string]Sfl101DetectInfo
	mutex sync.RWMutex
}

func NewSfl101DetectInfoMap() *Sfl101DetectInfoMapSet {
	return &Sfl101DetectInfoMapSet{
		SnMap: make(map[string]Sfl101DetectInfo),
		mutex: sync.RWMutex{},
	}
}
func (s *Sfl101DetectInfoMapSet) UpdateHitTime(sn string, hitTime int64) bool {
	s.mutex.Lock()
	defer s.mutex.Unlock()

	dev, ok := s.SnMap[sn]
	if !ok {
		return false
	}

	dev.HitTime = hitTime
	s.SnMap[sn] = dev

	return true
}
func (s *Sfl101DetectInfoMapSet) Set(sn string, vendor string, detectTime, hitTime, countTime int64,
	freq float64, direction int64, pilot string, lastTime int64, uDirStatus int32) string {
	s.mutex.Lock()
	defer s.mutex.Unlock()
	s.SnMap[sn] = Sfl101DetectInfo{sn, vendor, detectTime, hitTime, countTime,
		freq, direction, pilot, lastTime, uDirStatus}
	return sn
}

func (s *Sfl101DetectInfoMapSet) Get(sn string) (*Sfl101DetectInfo, bool) {
	s.mutex.RLock()
	defer s.mutex.RUnlock()

	dev, ok := s.SnMap[sn]
	if !ok {
		return nil, false
	}
	return &dev, true
}
func (s *Sfl101DetectInfoMapSet) GetAll() map[string]Sfl101DetectInfo {
	s.mutex.RLock()
	defer s.mutex.RUnlock()

	snMapCopy := make(map[string]Sfl101DetectInfo, len(s.SnMap))
	for k, v := range s.SnMap {
		snMapCopy[k] = v
	}
	return snMapCopy
}
func (s *Sfl101DetectInfoMapSet) Clear() {
	s.mutex.Lock()
	defer s.mutex.Unlock()

	for k := range s.SnMap {
		delete(s.SnMap, k)
	}
}
func (s *Sfl101DetectInfoMapSet) Del(k string) {
	s.mutex.Lock()
	defer s.mutex.Unlock()

	delete(s.SnMap, k)
}

type Nsf4000MapInfo struct {
	IsStartGoroutine bool   `json:"isStartGoroutine"`          //是否调已经启动过数据同步
	Sn               string `json:"sn,omitempty"`              //设备标识
	Enable           bool   `json:"enable,omitempty"`          //功能开关 true:开启   false:关闭
	WorkMode         int32  `json:"workMode,omitempty"`        //工作模式 1：主动防御 2：区域拒止 3：定向驱离
	Radius           int32  `json:"radius,omitempty"`          //防御区半径
	Angle            int32  `json:"angle,omitempty"`           //诱导角度  0/90/180/270   0正北，90正东  1  向上  -1向下
	EnableStartTime  int64  `json:"enableStartTime,omitempty"` //记录操作时长(enable_true_time - enable_false_time )
	NsfIsWorking     bool   `json:"nsfIsWorking,omitempty"`
	OldVol           int
	OldCurr          int
	NewVol           int
	NewCurr          int
	Status           int //获取到手动自检信息
	OldNewStatus     int //是新还是旧状态 2:旧
}
type Nsf4000MapInfoSet struct {
	SnMap map[string]Nsf4000MapInfo
	mutex sync.RWMutex
}

func NewNsf4000MapInfo() *Nsf4000MapInfoSet {
	return &Nsf4000MapInfoSet{
		SnMap: make(map[string]Nsf4000MapInfo),
		mutex: sync.RWMutex{},
	}
}

func (s *Nsf4000MapInfoSet) Set(sn string, nsf4000MapInfo Nsf4000MapInfo) string {
	if nsf4000MapInfo.Radius == 0 {
		nsf4000MapInfo.Radius = 500
	}
	s.mutex.Lock()
	defer s.mutex.Unlock()
	s.SnMap[sn] = Nsf4000MapInfo{
		IsStartGoroutine: nsf4000MapInfo.IsStartGoroutine,
		Sn:               sn,
		Enable:           nsf4000MapInfo.Enable,
		WorkMode:         nsf4000MapInfo.WorkMode,
		Radius:           nsf4000MapInfo.Radius,
		Angle:            nsf4000MapInfo.Angle,
		EnableStartTime:  nsf4000MapInfo.EnableStartTime,
		NsfIsWorking:     nsf4000MapInfo.NsfIsWorking,
		OldVol:           nsf4000MapInfo.OldVol,
		OldCurr:          nsf4000MapInfo.OldCurr,
		NewVol:           nsf4000MapInfo.NewVol,
		NewCurr:          nsf4000MapInfo.NewCurr,
		Status:           nsf4000MapInfo.Status,
		OldNewStatus:     nsf4000MapInfo.OldNewStatus,
	}
	return sn
}

func (s *Nsf4000MapInfoSet) Get(sn string) (*Nsf4000MapInfo, bool) {
	s.mutex.RLock()
	defer s.mutex.RUnlock()

	dev, ok := s.SnMap[sn]
	if !ok {
		return nil, false
	}
	return &dev, true
}
func (s *Nsf4000MapInfoSet) GetAll() map[string]Nsf4000MapInfo {
	s.mutex.RLock()
	defer s.mutex.RUnlock()

	snMapCopy := make(map[string]Nsf4000MapInfo, len(s.SnMap))
	for k, v := range s.SnMap {
		snMapCopy[k] = v
	}
	return snMapCopy
}
func (s *Nsf4000MapInfoSet) Clear() {
	s.mutex.Lock()
	defer s.mutex.Unlock()

	for k := range s.SnMap {
		delete(s.SnMap, k)
	}
}
func (s *Nsf4000MapInfoSet) Del(k string) {
	s.mutex.Lock()
	defer s.mutex.Unlock()

	delete(s.SnMap, k)
}

type Nsf4000WorkingInfo struct {
	Sn           string `json:"sn,omitempty"` //设备标识
	NsfIsWorking bool   `json:"nsfIsWorking,omitempty"`
}
type Nsf4000MapWorkingInfoSet struct {
	SnMap map[string]Nsf4000WorkingInfo
	mutex sync.RWMutex
}

func NewNsf4000WorkingInfo() *Nsf4000MapWorkingInfoSet {
	return &Nsf4000MapWorkingInfoSet{
		SnMap: make(map[string]Nsf4000WorkingInfo),
		mutex: sync.RWMutex{},
	}
}

func (s *Nsf4000MapWorkingInfoSet) Set(sn string, nsf4000MapInfo Nsf4000WorkingInfo) string {
	s.mutex.Lock()
	defer s.mutex.Unlock()
	s.SnMap[sn] = Nsf4000WorkingInfo{
		Sn:           sn,
		NsfIsWorking: nsf4000MapInfo.NsfIsWorking,
	}
	return sn
}

func (s *Nsf4000MapWorkingInfoSet) Get(sn string) (*Nsf4000WorkingInfo, bool) {
	s.mutex.RLock()
	defer s.mutex.RUnlock()
	dev, ok := s.SnMap[sn]
	if !ok {
		return nil, false
	}
	return &dev, true
}
func (s *Nsf4000MapWorkingInfoSet) GetAll() map[string]Nsf4000WorkingInfo {
	s.mutex.RLock()
	defer s.mutex.RUnlock()

	snMapCopy := make(map[string]Nsf4000WorkingInfo, len(s.SnMap))
	for k, v := range s.SnMap {
		snMapCopy[k] = v
	}
	return snMapCopy
}
func (s *Nsf4000MapWorkingInfoSet) Clear() {
	s.mutex.Lock()
	defer s.mutex.Unlock()

	for k := range s.SnMap {
		delete(s.SnMap, k)
	}
}
func (s *Nsf4000MapWorkingInfoSet) Del(k string) {
	s.mutex.Lock()
	defer s.mutex.Unlock()

	delete(s.SnMap, k)
}

type Nsf4000GselfStatusMapInfo struct {
	Sn           string `json:"sn,omitempty"` //设备标识
	OldVol       int
	OldCurr      int
	NewVol       int
	NewCurr      int
	Status       int //获取到手动自检信息
	OldNewStatus int //是新还是旧状态 2:旧
}
type Nsf4000GselfStatusMapInfoSet struct {
	SnMap map[string]Nsf4000GselfStatusMapInfo
	mutex sync.RWMutex
}

func NewNsf4000GselfStatusMapInfo() *Nsf4000GselfStatusMapInfoSet {
	return &Nsf4000GselfStatusMapInfoSet{
		SnMap: make(map[string]Nsf4000GselfStatusMapInfo),
		mutex: sync.RWMutex{},
	}
}

func (s *Nsf4000GselfStatusMapInfoSet) Set(sn string, nsf4000MapInfo Nsf4000GselfStatusMapInfo) string {
	s.mutex.Lock()
	defer s.mutex.Unlock()
	currInfo, exists := s.SnMap[sn]
	if !exists { // 如果当前不存在，则初始化结构体
		currInfo = Nsf4000GselfStatusMapInfo{
			Sn: sn,
		}
	}
	// 逐字段检查并更新
	if nsf4000MapInfo.OldVol != 0 {
		currInfo.OldVol = nsf4000MapInfo.OldVol
	}
	if nsf4000MapInfo.OldCurr != 0 {
		currInfo.OldCurr = nsf4000MapInfo.OldCurr
	}
	if nsf4000MapInfo.NewVol != 0 {
		currInfo.NewVol = nsf4000MapInfo.NewVol
	}
	if nsf4000MapInfo.NewCurr != 0 {
		currInfo.NewCurr = nsf4000MapInfo.NewCurr
	}
	if nsf4000MapInfo.Status != 0 {
		currInfo.Status = nsf4000MapInfo.Status
	}

	s.SnMap[sn] = currInfo
	return sn
}

func (s *Nsf4000GselfStatusMapInfoSet) Get(sn string) (*Nsf4000GselfStatusMapInfo, bool) {
	s.mutex.RLock()
	defer s.mutex.RUnlock()

	dev, ok := s.SnMap[sn]
	if !ok {
		return nil, false
	}
	return &dev, true
}
func (s *Nsf4000GselfStatusMapInfoSet) GetAll() map[string]Nsf4000GselfStatusMapInfo {
	s.mutex.RLock()
	defer s.mutex.RUnlock()

	snMapCopy := make(map[string]Nsf4000GselfStatusMapInfo, len(s.SnMap))
	for k, v := range s.SnMap {
		snMapCopy[k] = v
	}
	return snMapCopy
}
func (s *Nsf4000GselfStatusMapInfoSet) Clear() {
	s.mutex.Lock()
	defer s.mutex.Unlock()

	for k := range s.SnMap {
		delete(s.SnMap, k)
	}
}
func (s *Nsf4000GselfStatusMapInfoSet) Del(k string) {
	s.mutex.Lock()
	defer s.mutex.Unlock()

	delete(s.SnMap, k)
}

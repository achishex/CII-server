package common

import logger "adasgitlab.autel.com/tools/cuav_plugin/log"

// equip_list 设备类型目前是通过获取到的 etype 字符串名来判断是那类设备
const (
	Drone          = "DroneID" //TracerP TracerS
	DroneTracerS   = "TracerS"
	DroneTracerP   = "TracerP"
	Radar          = "radar"
	Sfl            = "Sfl"
	FPV            = "Fpv"
	NSF400         = "Spoofer"
	TracerRFurd360 = "tracerRF"
	Agx            = "Agx"
	Sfl200         = "Sfl200"
	Blader         = "Blader"
	RF             = "RF"
	DPH110         = "Dph110" //中程雷达
	GunsCloud      = "GunPlatform"
	SRP150         = "SRP150"
	SRP200         = "Srp200"
	TracerGun      = "TracerGun"
	SBP100         = "SBP100"
	SVH100         = "SVH"
	SFL101         = "Sfl101"
	STP120         = "Stp120"
)

// 定义CameraType类型
type CameraType int32

// 定义CameraType的可能值
const (
	Infrared     CameraType = iota // 0: 红外
	VisibleLight                   // 1: 可见光
	ScaleLens                      // 2: 捕获镜头
	TrackingLens                   // 3: 跟踪镜头
	BlockLens                      // 4: 跟踪抠图
)

var spooferSubDevTypeToName = map[int64]string{
	0: "SSH100",
	1: "SSH110",
	2: "SSH130",
}

var tracerSubDevTypeToName = map[int64]string{
	0:  "Tracer", //兼容老设备未上报子设备类型
	1:  "STP100",
	2:  "STS100",
	3:  "MAX4T",
	4:  "STA100",
	5:  "SFL100",
	6:  "SEH100",
	7:  "SFL110",
	8:  "RRFD",
	9:  "STC100",
	10: "STS120",
}

var sflSubDevTypeToName = map[int64]string{
	0: "SFL100",
	1: "SFL110",
}

const (
	DroneName          = "Tracer"
	RadarName          = "SDH100"
	SflName            = "哨兵塔SFL"
	FPVName            = "SVH100"
	NSF400Name         = "Spoofer"
	TracerRFurd360Name = "TracerRFurd360"
	AgxName            = "SRP100"
	Sfl200Name         = "SFL200"
	BladerName         = "SPS100"
	RFName             = "SHH100"
	DPH110Name         = "DPH110"
	GunsPlatformName   = "SHP100"
	SRP150Name         = "SRP150"
	SRP200Name         = "SRP200"
	SBP100Name         = "SBP100"
	TracerGunName      = "TracerGun"
	SVHName            = "SVH100"
	SFL101Name         = "SFL101"
	STP120Name         = "STP120"
)

func GetDevNameFromEtype(eType string, subDevType int64) string {
	var devName string
	switch eType {
	case Drone:
		if name, ok := tracerSubDevTypeToName[subDevType]; ok {
			devName = name
		}
	case Radar:
		devName = RadarName
	case Sfl:
		if name, ok := sflSubDevTypeToName[subDevType]; ok {
			devName = name
		}
	case NSF400:
		if name, ok := spooferSubDevTypeToName[subDevType]; ok {
			devName = name
		}
	case TracerRFurd360:
		devName = TracerRFurd360Name
	case Agx:
		devName = AgxName
	case SRP150:
		devName = SRP150Name
	case Sfl200:
		devName = Sfl200Name
	case Blader:
		devName = BladerName
	case RF:
		devName = RFName
	case DPH110:
		devName = DPH110Name
	case GunsCloud:
		devName = GunsPlatformName
	case SRP200:
		devName = SRP200Name
	case SBP100:
		devName = SBP100Name
	case TracerGun:
		devName = TracerGunName
	case SVH100:
		devName = SVHName
	case SFL101:
		devName = SFL101Name
	case STP120:
		devName = STP120Name
	default:
		logger.Error("etype not supported,etype :", eType)
		devName = "unknown"
	}
	return devName
}

package common

import (
	"strings"
	"time"
)

const (
	TimeStFormatOnTabName string = "20060102"
)

func getTime(tms ...time.Time) time.Time {
	formatTm := time.Now()
	if len(tms) > 0 {
		formatTm = tms[0]
	}
	return formatTm
}

const (
	DetectSqlTbName    = "detect"
	PostureSqlTbName   = "posture"
	HeartSqlTbName     = "heart"
	SyscfgSqlTbName    = "syscfg"
	HitstatusSqlTbName = "hitstatus"
	InduceSqlTbName    = "induce"
	SpectrumSqlTbName  = "spectrum"
)

// BuildDetectTableName 格式是： sn_detect_20231208
func BuildDetectTableName(sn string, tms ...time.Time) string {
	formatTm := getTime(tms...)
	items := []string{sn, DetectSqlTbName, formatTm.Format(TimeStFormatOnTabName)}
	return strings.Join(items, "_")
}

// BuildPostureTableName 格式是： sn_posture_20231208
func BuildPostureTableName(sn string, tms ...time.Time) string {
	formatTm := getTime(tms...)
	items := []string{sn, PostureSqlTbName, formatTm.Format(TimeStFormatOnTabName)}
	return strings.Join(items, "_")
}

// BuildHeartTableName 格式是： sn_heart_20231208
func BuildHeartTableName(sn string, tms ...time.Time) string {
	formatTm := getTime(tms...)
	items := []string{sn, HeartSqlTbName, formatTm.Format(TimeStFormatOnTabName)}
	return strings.Join(items, "_")
}

func BuildSysCfgTabName(sn string, tms ...time.Time) string {
	formatTm := getTime(tms...)
	items := []string{sn, SyscfgSqlTbName, formatTm.Format(TimeStFormatOnTabName)}
	return strings.Join(items, "_")
}

// BuildHitStatusTableName 格式是： sn_hitstatus_20231208
func BuildHitStatusTableName(sn string, tms ...time.Time) string {
	formatTm := getTime(tms...)
	items := []string{sn, HitstatusSqlTbName, formatTm.Format(TimeStFormatOnTabName)}
	return strings.Join(items, "_")
}

func BuildInduceTabName(sn string, tms ...time.Time) string {
	formatTm := getTime(tms...)
	items := []string{sn, InduceSqlTbName, formatTm.Format(TimeStFormatOnTabName)}
	return strings.Join(items, "_")
}

func BuildSpectrumTabName(sn string, tms ...time.Time) string {
	formatTm := getTime(tms...)
	items := []string{sn, SpectrumSqlTbName, formatTm.Format(TimeStFormatOnTabName)}
	return strings.Join(items, "_")
}

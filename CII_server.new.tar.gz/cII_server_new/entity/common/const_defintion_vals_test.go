package common

import (
	"fmt"
	"github.com/denisbrodbeck/machineid"
	"testing"
	"time"
)

func TestBuildHeartTableName(t *testing.T) {
	want := fmt.Sprintf("%s%s%s", "123", "_heart_", time.Now().Format(TimeStFormatOnTabName))
	ret := BuildHeartTableName("123")
	if want != ret {
		t.Error("ret = ", ret)
	}
}

func TestMachineID(t *testing.T) {
	id, _ := machineid.ID()
	t.Logf("id: %v", id)
}

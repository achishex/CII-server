package common

import (
	"crypto/hmac"
	"crypto/md5"
	"crypto/sha256"
	"encoding/hex"
)

// ComputeMD5 ...
func ComputeMD5(s string) string {
	hash := md5.Sum([]byte(s))
	return hex.EncodeToString(hash[:])
}

// sha256加密
func Sha256Encrypt(message, secret []byte) string {
	h := hmac.New(sha256.New, secret)
	h.Write(message)
	hmacResult := h.Sum(nil)
	return hex.EncodeToString(hmacResult)
}

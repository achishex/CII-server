package common

// SmoothingQueue 结构体代表队列
type SmoothingQueue struct {
	dataX  []float64
	dataY  []float64
	dataZ  []float64
	size   int
	weight []float64
}

// NewSmoothingQueue 函数用于创建一个指定大小的队列
func NewSmoothingQueue(size int) *SmoothingQueue {
	weight := make([]float64, size)
	temp := 1.0
	for i := 9; i >= 0; i-- {
		weight[i] = temp
		temp = temp - 0.1
	}

	return &SmoothingQueue{
		dataX:  make([]float64, 0, size),
		dataY:  make([]float64, 0, size),
		dataZ:  make([]float64, 0, size),
		weight: weight,
		size:   size,
	}
}

// Enqueue 方法用于将元素加入队列
func (q *SmoothingQueue) Enqueue(valX, valY, valZ float64) {
	if len(q.dataX) >= q.size {
		// 队列已满，移除最早加入的元素
		q.dataX = q.dataX[1:]
		q.dataY = q.dataY[1:]
		q.dataZ = q.dataZ[1:]
	}

	q.dataX = append(q.dataX, valX)
	q.dataY = append(q.dataY, valY)
	q.dataZ = append(q.dataZ, valZ)
}

// CalculateAverage 方法用于计算队列中元素的平均值
func (q *SmoothingQueue) CalculateAverage() (float64, float64, float64) {
	sumX := 0.0
	sumY := 0.0
	sumZ := 0.0
	totalWeight := 0.0

	for i := 0; i < len(q.dataX); i++ {
		sumX = sumX + q.dataX[i]*q.weight[i]
		sumY = sumY + q.dataY[i]*q.weight[i]
		sumZ = sumZ + q.dataZ[i]*q.weight[i]
		totalWeight = totalWeight + q.weight[i]
	}

	averageX := sumX / totalWeight
	averageY := sumY / totalWeight
	averageZ := sumZ / totalWeight

	return averageX, averageY, averageZ
}

func (q *SmoothingQueue) Length() int {
	return len(q.dataX)
}

type SmoothingQueueMap struct {
	queues map[uint16]*SmoothingQueue
}

func NewSmoothingQueueMap() *SmoothingQueueMap {
	return &SmoothingQueueMap{
		queues: make(map[uint16]*SmoothingQueue),
	}
}

func (m *SmoothingQueueMap) AddQueue(key uint16, size int) {
	queue := NewSmoothingQueue(size)
	m.queues[key] = queue
}

func (m *SmoothingQueueMap) Enqueue(key uint16, valX, valY, valZ float64) {
	queue, ok := m.queues[key]
	if ok {
		queue.Enqueue(valX, valY, valZ)
	}
}

func (m *SmoothingQueueMap) CalculateAverage(key uint16) (float64, float64, float64) {
	queue, ok := m.queues[key]
	if ok {
		return queue.CalculateAverage()
	}
	return 0.0, 0.0, 0.0
}

func (m *SmoothingQueueMap) Length(key uint16) int {
	queue, ok := m.queues[key]
	if ok {
		return queue.Length()
	}
	return 0
}

func (m *SmoothingQueueMap) Contains(key uint16) bool {
	_, ok := m.queues[key]
	return ok
}

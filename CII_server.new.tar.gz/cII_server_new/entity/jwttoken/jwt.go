// Package jwttoken JWT(JSON Web Tokens) 是一种用于在网络应用之间传递信息的安全方式
package jwttoken

import (
	"strconv"
	"time"

	"adasgitlab.autel.com/tools/cuav_server/entity/config"
	"github.com/dgrijalva/jwt-go"
)

type customClaims struct {
	jwt.StandardClaims
}

// TokenOutPut ...
type TokenOutPut struct {
	AccessToken string `json:"access_token"`
	ExpiresIn   int    `json:"expires_in"`
	TokenType   string `json:"token_type"`
}

// CreateToken 创建Token
func CreateToken(GuardName string, ID int64) (TokenOutPut, error) {
	config := config.GetGlobalConfig()
	token := jwt.NewWithClaims(
		jwt.SigningMethodHS256,
		customClaims{
			StandardClaims: jwt.StandardClaims{
				ExpiresAt: time.Now().Unix() + config.Jwt.Ttl,
				Id:        strconv.Itoa(int(ID)),
				Issuer:    GuardName, // It is used to distinguish tokens issued by different clients in the middleware to avoid cross-end use of tokens
				NotBefore: time.Now().Unix() - 1000,
			},
		},
	)
	tokenStr, _ := token.SignedString([]byte(config.Jwt.Secret))
	tokenData := TokenOutPut{
		tokenStr,
		int(config.Jwt.Ttl),
		config.Jwt.TokenType,
	}
	return tokenData, nil
}

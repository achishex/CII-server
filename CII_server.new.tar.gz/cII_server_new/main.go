package main

import "C"

import (
	"adasgitlab.autel.com/tools/cuav_server/api/webapi"
	"context"
	"fmt"
	"os"
	"os/signal"
	"path/filepath"
	"sync"
	"time"

	"adasgitlab.autel.com/tools/cuav_plugin/config/file"
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/entity/config"
	"adasgitlab.autel.com/tools/cuav_server/repo/cache"
	"adasgitlab.autel.com/tools/cuav_server/repo/utils"
	"adasgitlab.autel.com/tools/cuav_server/services"
)

//export StartPlugins
func StartPlugins(timeOffset int, cuavConfigFile string, dbfile string, natsConfigFile string, natsDataDir string, logSaveDir string) int {
	return services.StartPlugins(timeOffset, cuavConfigFile, dbfile, natsConfigFile, natsDataDir, logSaveDir)
}

//export StopPlugins
func StopPlugins() {
	services.StopPlugins()
}

//export StartCuavServices
func StartCuavServices(logLevel string, logFlag bool, dbFile string) int {
	return services.StartCuavServices(logLevel, logFlag, dbFile)
}

//export StopCuavServices
func StopCuavServices() {
	services.StopCuavServices()
}

//export StartProfiler
func StartProfiler(path string) int {
	return services.StartProfiler(path)
}

//export StopProfiler
func StopProfiler() {
	services.StopProfiler()
}

func main() {
	// 日志设置
	cuavConfigFile := "config/cuav-config.yaml"
	logFilePath := filepath.Dir(cuavConfigFile)
	if err := logger.Init(cuavConfigFile, "log/log"); err != nil {
		panic(err)
	}
	webapi.ConfigDir = logFilePath
	// 读取配置
	cfg := file.NewConfig(cuavConfigFile)
	err := cfg.Init(config.GetGlobalConfig())
	if err != nil {
		fmt.Println("初始化配置失败：", err)
		return
	}
	logger.Debug("配置信息：", config.GetGlobalConfig().TracerSn)
	dbFilePath := "config/cuav.db"
	err = services.UpdateDBs(dbFilePath)
	if err != nil {
		fmt.Println("数据库升级失败: ", err)
		return
	}
	// 初始化雪花算法节点
	utils.InitSnowFlakeNode(111)
	// 初始化缓存组件
	cache.Init("./")
	// 启动服务
	t := time.Now()
	ctx := context.Background()
	stopChan2 := make(chan int, 1)
	var wg sync.WaitGroup
	wg.Add(3)
	go services.StartDbSvc(ctx, &wg, stopChan2, dbFilePath)
	go services.StartDeviceCenter(ctx, &wg, stopChan2)
	go services.StartWebApi(ctx, &wg, stopChan2)

	logKafkaConf := config.Global.LogKafka
	if logKafkaConf.SyncSwitch {
		// 开启监听日志文件并将日志同步到kafka
		go services.StartSyncLogSrv(logFilePath, logKafkaConf.Addr, logKafkaConf.LogTopic, ctx)
	}
	go func() {
		wg.Wait()
		stopChan2 <- 0
	}()
	ch2 := <-stopChan2
	if ch2 != 0 {
		fmt.Println("服务启动失败")
		return
	}
	if !services.StartStatisticSchedule(60) {
		logger.Fatal("定时数据统计任务启动失败")
		return
	}
	if !services.StartEquipment() {
		fmt.Println("启动设备失败： ", time.Since(t))
		select {}
	}
	utils.CheckC2BackendRes()

	fmt.Println("启动成功： ", time.Since(t))
	sig := make(chan os.Signal, 1)
	signal.Notify(sig, os.Interrupt, os.Kill)
	<-sig
}

package db

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"adasgitlab.autel.com/tools/cuav_server/db/demo"
	"database/sql"
	"embed"
	"github.com/pressly/goose/v3"
)

//go:embed migrations
var fs embed.FS

// 以下sql变更仅仅为了兼容历史变更，后续不应该再变动
var historyPatches = []patch{
	// 0048_add_c2_lat_lng_to_system_config.sql
	{
		VersionId: 48,
		TableName: "system_config",
		Columns:   []string{"c2_longitude", "c2_latitude"},
	},
	// 0049_add_radar_relevance_to_equi_list.sql
	{
		VersionId: 49,
		TableName: "equip_list",
		Columns:   []string{"radar_relevance"},
	},
	// 0050_add_attrs_to_nsf4000.sql
	{
		VersionId: 50,
		TableName: "nsf4000_config",
		Columns:   []string{"defense_longitude", "defense_latitude", "area_stop_longitude", "area_stop_latitude"},
	},
	// 0051_add_dev_version_to_equip_list.sql
	{
		VersionId: 51,
		TableName: "equip_list",
		Columns:   []string{"dev_version"},
	},
	// 0052_add_drone_height_to_sfl_detect_info.sql
	{
		VersionId: 52,
		TableName: "sfl_detect_info",
		Columns:   []string{"drone_height"},
	},
	// 0053_add_attrs_to_drone_white_list.sql
	{
		VersionId: 53,
		TableName: "drone_white_list",
		Columns:   []string{"user_name", "usage", "usage_desc", "remarks"},
	},
	// 0054_add_u_dir_status_to_sfl_detect_list.sql
	{
		//ALTER TABLE sfl_detect_info ADD COLUMN u_dir_status integer;
		VersionId: 54,
		TableName: "sfl_detect_info",
		Columns:   []string{"u_dir_status"},
	},
	// 0055_add_system_status_to_radar_tcp_heart.sql
	{
		VersionId: 55,
		TableName: "radar_tcp_heart",
		Columns:   []string{"sys_status"},
	},
	// 0056_add_scan_radius_to_equip_list.sql
	{
		VersionId: 56,
		TableName: "equip_list",
		Columns:   []string{"scan_radius"},
	},
	// 0057_add_parent_sn_to_equip_list.sql
	{
		VersionId: 57,
		TableName: "equip_list",
		Columns:   []string{"parent_sn"},
	},
	{
		VersionId: 65,
		TableName: "system_config",
		Columns:   []string{"height"},
	},
}

type patch struct {
	VersionId int
	TableName string
	Columns   []string
}

// Migrate 根据migrations文件中的sql文件的up内容，结合数据库中goose_db_version中迁移记录，进行齐次迁移
// 请注意
// 1.仅仅使用sqlite支持的sql语法
// 2.保持goose对sql文件名作为顺序版本名称的约定
// 3.仅作表结构和少量必须自举数据的管理，大量数据插入请用其他方式管理
func Migrate(db *sql.DB) error {
	goose.SetBaseFS(fs)

	if err := goose.SetDialect("sqlite3"); err != nil {
		return err
	}

	err := goose.Up(db, "migrations", goose.WithAllowMissing())
	if err == nil {
		return nil
	} else {
		logger.Warnf("old migration failed: %s", err)
	}

	// C2项目以前的数据迁移是一个原始轮子，2024.04.18迁移到goose
	// 由于sqlite 缺失 ADD COLUMN IF NOT EXIST 这类语法的支持，这导致
	// 这次迁移到goose需要额外的处理逻辑实现兼容历史的迁移记录
	err = applyHistoryPatches(db)
	if err != nil {
		return err
	}

	// 处理完历史兼容的迁移后再跑一次，二次确认ok
	return goose.Up(db, "migrations", goose.WithAllowMissing())
}

// Reset 重置数据库，过程为删除所有表数据表结构（sql文件的down语句），然后重新创建新的表结构（sql文件中的up语句）
// 没有包含动态数据表（那些设备类的表）
func Reset(db *sql.DB) error {
	goose.SetBaseFS(fs)

	if err := goose.SetDialect("sqlite3"); err != nil {
		return err
	}

	return goose.Reset(db, "migrations")
}

// CreateDemoData 创建演示的Demo数据, 主要包括radar_tcp_heart/radar_tcp_posture_info/
// radar_tcp_track_info/radar_tcp_track_target 这四个表数据。插入demo数据采用 是否存在历史数据以及"INSERT OR IGNORE"
// 保持齐次性。
// 该demo数据灵活性较差，后期引入高级demo方案后可以移除此代码
func CreateDemoData(db *sql.DB) error {
	sqlStr := `SELECT count(id) FROM radar_tcp_heart WHERE sn = 'radar0000000000'`
	var count int
	err := db.QueryRow(sqlStr).Scan(&count)
	if err != nil {
		return err
	}
	if count > 0 {
		return nil
	}
	_, err = db.Exec(demo.DemoSql)
	return err
}

func applyHistoryPatches(db *sql.DB) error {
	for _, aPatch := range historyPatches {
		for _, column := range aPatch.Columns {
			found, err := isExistColumnOfTable(db, aPatch.TableName, column)
			if err != nil {
				return err
			}
			if found {
				err = manualMarkOk(db, aPatch.VersionId)
				if err != nil {
					return err
				}
			} else {
				_ = goose.Up(db, "migrations")
			}
		}
	}
	return nil
}

func isExistColumnOfTable(db *sql.DB, tableName, columnName string) (bool, error) {
	sqlStr := `SELECT COUNT(*) FROM pragma_table_info(?) WHERE name = ?;`
	result, err := db.Query(sqlStr, tableName, columnName)
	if err != nil {
		return false, err
	}
	defer result.Close()
	for result.Next() {
		var count int
		if err := result.Scan(&count); err != nil {
			return false, err
		}
		if count == 1 {
			return true, nil
		} else {
			return false, nil
		}
	}

	return false, nil
}

func manualMarkOk(db *sql.DB, versionId int) error {
	sqlStr := `INSERT INTO goose_db_version (version_id, is_applied) SELECT ?, 1 WHERE NOT EXISTS (SELECT * FROM goose_db_version WHERE version_id = ?)`
	_, err := db.Exec(sqlStr, versionId, versionId)
	return err
}

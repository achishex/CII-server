package db

import (
	"adasgitlab.autel.com/tools/cuav_server/db/testdata"
	"adasgitlab.autel.com/tools/cuav_server/test"
	"database/sql"
	_ "github.com/mattn/go-sqlite3"
	"testing"
)

func TestMigrate(t *testing.T) {
	// Mock 日志
	test.LoggerMock()
	type args struct {
		db *sql.DB
	}
	tests := []struct {
		name    string
		args    args
		wantErr bool
	}{
		{
			name: "a totally new db",
			args: args{
				db: func() *sql.DB {
					db, _ := sql.Open("sqlite3", ":memory:")
					return db
				}(),
			},
			wantErr: false,
		},
		{
			name: "from version 1.0.0 to goose",
			args: args{
				db: func() *sql.DB {
					return historyDb("1_0_0_schema.sql")
				}(),
			},
			wantErr: false,
		},
		{
			name: "from version 1.0.1 to goose",
			args: args{
				db: func() *sql.DB {
					return historyDb("1_0_1_schema.sql")
				}(),
			},
			wantErr: false,
		},
		{
			name: "from version 1.0.2 to goose",
			args: args{
				db: func() *sql.DB {
					return historyDb("1_0_2_schema.sql")
				}(),
			},
			wantErr: false,
		},
		{
			name: "from version 1.0.3 to goose",
			args: args{
				db: func() *sql.DB {
					return historyDb("1_0_3_schema.sql")
				}(),
			},
			wantErr: false,
		},
		{
			name: "from version 1.0.4 to goose",
			args: args{
				db: func() *sql.DB {
					return historyDb("1_0_4_schema.sql")
				}(),
			},
			wantErr: false,
		},
		{
			name: "from version 1.0.5 to goose",
			args: args{
				db: func() *sql.DB {
					return historyDb("1_0_5_schema.sql")
				}(),
			},
			wantErr: false,
		},
		{
			name: "from version 1.0.6 to goose",
			args: args{
				db: func() *sql.DB {
					return historyDb("1_0_6_schema.sql")
				}(),
			},
			wantErr: false,
		},
		{
			name: "from version 1.0.7 to goose",
			args: args{
				db: func() *sql.DB {
					return historyDb("1_0_7_schema.sql")
				}(),
			},
			wantErr: false,
		},
		{
			name: "from version 1.0.8 to goose",
			args: args{
				db: func() *sql.DB {
					return historyDb("1_0_8_schema.sql")
				}(),
			},
			wantErr: false,
		},
		{
			name: "from version 1.0.9 to goose",
			args: args{
				db: func() *sql.DB {
					return historyDb("1_0_9_schema.sql")
				}(),
			},
			wantErr: false,
		},
		{
			name: "from version 1.0.10 to goose",
			args: args{
				db: func() *sql.DB {
					return historyDb("1_0_10_schema.sql")
				}(),
			},
			wantErr: false,
		},
		{
			name: "from version 1.0.11 to goose",
			args: args{
				db: func() *sql.DB {
					return historyDb("1_0_11_schema.sql")
				}(),
			},
			wantErr: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			defer tt.args.db.Close()
			if err := Migrate(tt.args.db); (err != nil) != tt.wantErr {
				t.Errorf("Migrate() error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

func historyDb(schemaName string) *sql.DB {
	db, err := sql.Open("sqlite3", ":memory:")
	if err != nil {
		panic(err)
	}
	schema, err := testdata.DbSchemas.ReadFile("1_0_0_schema.sql")
	if err != nil {
		panic(err)
	}
	_, err = db.Exec(string(schema))
	if err != nil {
		panic(err)
	}
	return db
}

func TestReset(t *testing.T) {
	type args struct {
		db *sql.DB
	}
	tests := []struct {
		name    string
		args    args
		wantErr bool
	}{
		{
			name: "reset a latest db",
			args: args{
				db: func() *sql.DB {
					db, _ := sql.Open("sqlite3", ":memory:")
					err := Migrate(db)
					if err != nil {
						panic(err)
					}
					return db
				}(),
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			defer tt.args.db.Close()
			if err := Reset(tt.args.db); (err != nil) != tt.wantErr {
				t.Errorf("Reset() error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

func TestCreateDemoData(t *testing.T) {
	type args struct {
		db *sql.DB
	}
	tests := []struct {
		name    string
		args    args
		wantErr bool
	}{
		{
			name: "create demo data for a latest db",
			args: args{
				db: func() *sql.DB {
					db, _ := sql.Open("sqlite3", ":memory:")
					err := Migrate(db)
					if err != nil {
						panic(err)
					}
					return db
				}(),
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			defer tt.args.db.Close()
			if err := CreateDemoData(tt.args.db); (err != nil) != tt.wantErr {
				t.Errorf("CreateDemoData() error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

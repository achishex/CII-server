package demo

import _ "embed"

//go:embed demo_data.sql
var DemoSql string

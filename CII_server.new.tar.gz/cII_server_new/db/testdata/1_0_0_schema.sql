CREATE TABLE IF NOT EXISTS "autel_radar_adc"
(
    "id"                integer NOT NULL,
    "info_sycn"         integer,
    "info_type"         integer,
    "info_length"       integer,
    "frame_id"          integer,
    "crt_time"          text(30),
    "terminal_id"       integer,
    "terminal_type"     integer,
    "sub_terminal_type" integer,
    "info_version"      integer,
    "reserved1"         integer,
    "length"            integer,
    "type"              integer,
    "raw_data"          integer,
    "reserved2"         integer,
    "crc"               integer,
    "timestamp"         integer,
    CONSTRAINT "radar_adc_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "autel_radar_carry_platform"
(
    "id"                integer NOT NULL,
    "info_sycn"         integer,
    "info_type"         integer,
    "info_length"       integer,
    "frame_id"          integer,
    "crt_time"          text(30),
    "terminal_id"       integer,
    "terminal_type"     integer,
    "sub_terminal_type" integer,
    "info_version"      integer,
    "reserved1"         integer,
    "heading"           real,
    "pitching"          real,
    "rolling"           real,
    "longitude"         real,
    "latitude"          real,
    "altitude"          real,
    "velocity_navi"     real,
    "target_time_mark"  integer,
    "sig_relative_time" real,
    "reserve"           integer,
    "reserved2"         integer,
    "crc"               integer,
    "timestamp"         integer,
    CONSTRAINT "radar_carry_platform_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "autel_radar_plot_track_body"
(
    "id"                integer NOT NULL,
    "obj_id"            integer,
    "header_uid"        integer,
    "azimuth"           real,
    "obj_dist_interpol" real,
    "elevation"         real,
    "velocity"          real,
    "doppler_chn"       integer,
    "mag"               real,
    "ambiguous"         integer,
    "classification"    integer,
    "classfy_prob"      real,
    "existing_prob"     real,
    "abs_vel"           real,
    "orientation_angle" real,
    "alive"             integer,
    "tws_tas_flag"      integer,
    "x"                 real,
    "y"                 real,
    "z"                 real,
    "vx"                real,
    "vy"                real,
    "vz"                real,
    "ax"                real,
    "ay"                real,
    "az"                real,
    "x_variance"        real,
    "y_variance"        real,
    "z_variance"        real,
    "vx_variance"       real,
    "vy_variance"       real,
    "vz_variance"       real,
    "ax_variance"       real,
    "ay_variance"       real,
    "az_variance"       real,
    "state_type"        integer,
    "motion_type"       integer,
    "forcast_frame_num" integer,
    "association_num"   integer,
    "assoc_bit0"        integer,
    "assoc_bit1"        integer,
    "reserve"           integer,
    "reserved2"         integer,
    "crc"               integer,
    "create_time"       text(6),
    "vendor"            text(255),
    "frequency"         text(255),
    "model"             text(255),
    "is_whitelist"      text(5),
    CONSTRAINT "radar_plot_track_body_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "autel_radar_plot_track_header"
(
    "id"                 integer NOT NULL,
    "info_sync"          integer,
    "info_type"          integer,
    "info_length"        integer,
    "frame_id"           integer,
    "crt_time"           text(30),
    "terminal_id"        integer,
    "terminal_type"      integer,
    "sub_terminal_type"  integer,
    "info_version"       integer,
    "reserved1"          integer,
    "track_obj_num"      integer,
    "track_tws_num"      integer,
    "track_tas_num"      integer,
    "track_obj_byte"     integer,
    "track_tws_tas_flag" integer,
    "reserved"           integer,
    "timestamp"          integer,
    "update_header_id"   integer,
    uid                  int,
    CONSTRAINT "radar_plot_track_header_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "autel_radar_point_track_body"
(
    "id"                integer NOT NULL,
    "obj_id"            integer,
    "point_header_id"   integer,
    "azimuth"           real,
    "obj_dist_interpol" real,
    "elevation"         real,
    "velocity"          real,
    "doppler_chn"       integer,
    "mag"               real,
    "obj_confidence"    real    NOT NULL,
    "ambiguous"         integer,
    "classification"    integer,
    "classfy_prob"      real,
    "cohesion_ok_flag"  integer,
    "cohesion_pnt_num"  integer,
    "cohesion_beam_num" integer,
    "azi_beam_id"       integer,
    "ele_beam_id"       integer,
    "reserved"          integer,
    "reserved2"         integer,
    "crc"               integer,
    CONSTRAINT "radar_point_track_body_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "autel_radar_point_track_header"
(
    "id"                 integer NOT NULL,
    "info_sycn"          integer,
    "info_type"          integer,
    "info_length"        integer,
    "frame_id"           integer,
    "crt_time"           text(30),
    "terminal_id"        integer,
    "terminal_type"      integer,
    "sub_terminal_type"  integer,
    "info_version"       integer,
    "reserved1"          integer,
    "detect_obj_num"     integer,
    "detect_obj_byte"    integer,
    "track_tws_tas_flag" integer,
    "reserved"           integer,
    "timestamp"          integer,
    "update_header_id"   integer,
    CONSTRAINT "radar_point_track_header_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "autel_radar_setting"
(
    "id"                      integer NOT NULL,
    "info_sycn"               integer,
    "info_type"               integer,
    "info_length"             integer,
    "frame_id"                integer,
    "crt_time"                text(30),
    "terminal_id"             integer,
    "terminal_type"           integer,
    "sub_terminal_type"       integer,
    "info_version"            integer,
    "reserved1"               integer,
    "tr_switch_ctrl"          text(20),
    "work_mode"               integer,
    "work_wave_code"          text(20),
    "work_freq_code"          integer,
    "prf_period"              integer,
    "accu_num"                integer,
    "noise_coef"              real,
    "clutter_coef"            real,
    "cfar_coef"               real,
    "focus_range_min"         integer,
    "focus_range_max"         integer,
    "clutter_curve_num"       integer,
    "lobe_comp_coef"          real,
    "cohesion_vel_thre"       integer,
    "cohesion_rgn_thre"       integer,
    "clutter_map_switch"      integer,
    "clutter_map_update_coef" integer,
    "azi_calc_slope"          integer,
    "azi_calc_phase"          integer,
    "ele_calc_slope"          integer,
    "ele_calc_phase"          integer,
    "azi_scan_center"         integer,
    "azi_scan_scope"          integer,
    "ele_scan_center"         integer,
    "ele_scan_scope"          integer,
    "coherent_detect_switch"  integer,
    "reserve"                 integer,
    "reserved2"               integer,
    "crc"                     integer,
    "data_from"               integer,
    "timestamp"               integer,
    CONSTRAINT "radar_setting_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "autel_radar_statu"
(
    "id"                integer NOT NULL,
    "info_sync"         integer,
    "info_type"         integer,
    "info_length"       integer,
    "frame_id"          integer,
    "crt_time"          text(6),
    "terminal_id"       integer,
    "terminal_type"     integer,
    "sub_terminal_type" integer,
    "info_version"      integer,
    "reserved1"         integer,
    "is_fail_flag"      integer,
    "fail_bit_data1"    integer,
    "fail_bit_data2"    integer,
    "battery_power"     real,
    "reserve"           integer,
    "reserved2"         integer,
    "crc"               integer,
    "timestamp"         integer,
    "udp_header_uid"    integer,
    CONSTRAINT "radar_fault_statu_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "autel_radar_udp_header"
(
    "id"                    integer NOT NULL,
    "packet_flag"           integer,
    "total_packet_num"      integer,
    "packet_length"         integer,
    "send_info_count"       integer,
    "terminal_type"         integer,
    "sub_terminal_type"     integer,
    "info_type"             integer,
    "info_packet_num"       integer,
    "cur_info_packet_order" integer,
    "reserved"              integer,
    "uid"                   integer,
    CONSTRAINT "radar_udp_header_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "autel_radar_wave_control"
(
    "id"                         integer NOT NULL,
    "info_sycn"                  integer,
    "info_type"                  integer,
    "info_length"                integer,
    "frame_id"                   integer,
    "crt_time"                   text(30),
    "terminal_id"                integer,
    "terminal_type"              integer,
    "sub_terminal_type"          integer,
    "info_version"               integer,
    "reserved1"                  integer,
    "azi_beam_id"                integer,
    "ele_beam_id"                integer,
    "azi_beam_sin"               real,
    "ele_beam_sin"               real,
    "tas_beam_total"             integer,
    "tas_beam_cnt_cur"           integer,
    "tas_obj_id"                 integer,
    "tas_obj_filter_num"         integer,
    "tas_obj_range"              integer,
    "sample_pnt_start"           integer,
    "sample_pnt_depth"           integer,
    "beam_switch_time"           integer,
    "whole_space_scan_cycle_cnt" integer,
    "track_tws_tas_flag"         integer,
    "reserve"                    integer,
    "reserved2"                  integer,
    "crc"                        integer,
    "timestamp"                  integer,
    CONSTRAINT "radar_wave_control_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "equip_source_id"
(
    "id"          INTEGER NOT NULL,
    "sn"          TEXT    NOT NULL,
    "source_id"   INTEGER NOT NULL,
    "create_time" TEXT    NOT NULL,
    "update_time" TEXT    NOT NULL,
    CONSTRAINT "equip_source_id_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "event_list"
(
    "id"         integer NOT NULL,
    "eid"        text    NOT NULL,
    "vendor"     text,
    "model"      text,
    "begin_time" text,
    "end_time"   text,
    "duration"   real,
    "altitude"   real,
    "frequency"  real,
    "protocol"   text,
    "status"     integer NOT NULL, -- -1事件结束，1事件开始
    "source"     integer NOT NULL, -- 1雷达，2枪
    "obj_id"     integer,
    "serial_num" text,
    CONSTRAINT "event_list_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "log"
(
    "id"       integer NOT NULL,
    "user_id"  integer,
    "type"     integer,
    "command"  integer,
    "lastip"   text(20),
    "os"       text(20),
    "osvesion" text(30),
    "crt_time" text(30),
    "reserve"  text,
    CONSTRAINT "log_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "remote_alarm"
(
    "id"         integer NOT NULL,
    "phone"      text,
    "email"      text,
    "open"       integer,
    "alarm_time" integer,
    CONSTRAINT "remote_alarm_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "role"
(
    "id"          integer NOT NULL,
    "name"        text(20),
    "status"      text(5),
    "crt_time"    text(30),
    "update_time" text(30),
    "remark"      text(50),
    CONSTRAINT "role_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "sms"
(
    "id"         integer NOT NULL,
    "phone"      text,
    "request_id" text,
    "message"    text,
    "biz_id"     text,
    "code"       text,
    CONSTRAINT "sms_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "track_waveforms"
(
    "id"                      integer NOT NULL,
    "waveform"                text(20),
    "max_distance_target"     real,
    "max_target_time_delay"   real,
    "signal_bandwidth"        integer,
    "sampl_points"            integer,
    "sampl_window_time"       real,
    "sweep_fallback_time"     real,
    "effective_bandwidth"     real,
    "modulation_period"       real,
    "pulse_repetition_period" real,
    "differential_beat_echo"  real,
    "wave_dwell_time"         real,
    CONSTRAINT "track_waveforms_pkey" PRIMARY KEY ("id")
);
CREATE TABLE device_comm_log
(
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    device_type INTEGER,
    sn          TEXT,
    msg_id      INTEGER,
    request     TEXT,
    response    TEXT,
    remark      TEXT,
    create_time INTEGER
);
CREATE TABLE IF NOT EXISTS "hour_constants"
(
    "id"   INTEGER PRIMARY KEY AUTOINCREMENT,
    "time" text NOT NULL
);
CREATE TABLE IF NOT EXISTS "log_status"
(
    "id"     integer PRIMARY KEY AUTOINCREMENT NOT NULL,
    "sn"     text                              NOT NULL,
    "status" integer                           NOT NULL,
    "path"   text                              NOT NULL,
    "proid"  integer                           NOT NULL,
    CONSTRAINT "log_status_unique" UNIQUE ("sn")
);
CREATE TABLE IF NOT EXISTS "log_cloud_status"
(
    "id"     integer PRIMARY KEY  NOT NULL,
    "path"   text             NOT NULL,
    "status" integer          NOT NULL,
    "proid"  integer          NOT NULL,

    CONSTRAINT "log_cloud_status_unique" UNIQUE ("id")
);
CREATE TABLE IF NOT EXISTS "c2_license"
(
    "license_id"   text PRIMARY KEY NOT NULL,
    "mac_addr"     text             NOT NULL,
    "start_time"   text             NOT NULL,
    "stop_time"    text             NOT NULL,
    "last_time"    text             NOT NULL,
    "expires"      integer          NOT NULL,
    "license_type" text             NOT NULL,
    "user_name"    text             NOT NULL,
    "user_phone"   text             NOT NULL,
    "user_email"   text             NOT NULL,
    CONSTRAINT "c2_license_unique" UNIQUE ("license_id")
);
CREATE TABLE IF NOT EXISTS "drone_white_list"
(
    "id"        integer PRIMARY KEY AUTOINCREMENT NOT NULL,
    "vendor"    text                              NOT NULL,
    "model"     text                              NOT NULL,
    "frequency" text                              NOT NULL,
    "sn"        text                              NOT NULL,
    "role"      integer                           NOT NULL,
    created_at  timestamp                         not null,
    updated_at  timestamp                         not null,
    CONSTRAINT "drone_white_list_unique" UNIQUE ("sn")
);
CREATE TABLE gun_tcp_heart
(
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    header_id       INTEGER,
    time_stamp      INTEGER,
    screen_status   INTEGER,
    electricity     INTEGER,
    signal_strength INTEGER,
    work_status     INTEGER,
    alarm_level     INTEGER,
    hit_freq        INTEGER,
    detect_freq     INTEGER,
    x               INTEGER,
    y               INTEGER,
    z               INTEGER,
    gun_longitude   real,
    gun_latitude    real,
    gun_altitude    INTEGER,
    satellites_num  INTEGER,
    gun_direction   real,
    elevation       real,
    u_drone_num     INTEGER,
    received_time   INTEGER
);
CREATE INDEX gun_tcp_heart_header_id_index ON gun_tcp_heart (header_id);
CREATE TABLE gun_tcp_heart_uav
(
    id                   INTEGER PRIMARY KEY AUTOINCREMENT,
    header_id            INTEGER,
    product_type         INTEGER,
    drone_name           TEXT,
    serial_num           TEXT,
    drone_longitude      real,
    drone_latitude       real,
    drone_height         real,
    drone_yaw_angle      real,
    drone_speed          real,
    drone_vertical_speed real,
    pilot_longitude      real,
    pilot_latitude       real,
    u_freq               real,
    u_distance           INTEGER,
    u_danger_levels      INTEGER
);
CREATE INDEX gun_tcp_heart_uav_header_id_index ON gun_tcp_heart_uav (header_id);
CREATE TABLE tracer_tcp_heart
(
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    header_id       INTEGER,
    time_stamp      INTEGER,
    screen_status   INTEGER,
    electricity     INTEGER,
    signal_strength INTEGER,
    work_status     INTEGER,
    alarm_level     INTEGER,
    hit_freq        INTEGER,
    detect_freq     INTEGER,
    elevation       real,
    gun_longitude   real,
    gun_latitude    real,
    gun_altitude    INTEGER,
    satellites_num  INTEGER,
    gun_direction   real,
    sn              TEXT,
    u_drone_num     INTEGER,
    received_time   INTEGER
);
CREATE INDEX tracer_tcp_heart_header_id_index ON tracer_tcp_heart (header_id);
CREATE TABLE tracer_tcp_heart_uav
(
    id                   INTEGER PRIMARY KEY AUTOINCREMENT,
    header_id            INTEGER,
    product_type         INTEGER,
    drone_name           TEXT,
    serial_num           TEXT,
    drone_longitude      real,
    drone_latitude       real,
    drone_height         real,
    drone_yaw_angle      real,
    drone_speed          real,
    drone_vertical_speed real,
    operator_longitude   real,
    operator_latitude    real,
    drone_horizon        real,
    drone_pitch          real,
    freq                 real,
    distance             INTEGER,
    danger_levels        INTEGER,
    waypoint_longitude   real,
    waypoint_latitude    real
);
CREATE INDEX tracer_tcp_heart_uav_header_id_index ON tracer_tcp_heart_uav (header_id);
CREATE TABLE IF NOT EXISTS "user_base"
(
    "id"                 integer NOT NULL,
    "role"               text(20),
    "name"               text(20),
    "nick_name"          text(20),
    "gender"             text(5),
    "mobile"             text(20),
    "email"              text(20),
    "crt_time"           text(30),
    "push_token"         text(20),
    "password"           text(20),
    "update_time"        text(30),
    "updater"            text(20),
    "is_delete"          text(5),
    "last_sms_time"      text(30),
    "daily_send_times"   integer,
    CONSTRAINT "user_base_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "log_id"
(
    "id"   integer PRIMARY KEY NOT NULL,
    "log_id"     text             NOT NULL,
    CONSTRAINT "log_id_unique" UNIQUE ("log_id")
);
CREATE TABLE IF NOT EXISTS "equip_list"
(
    "id"             integer  NOT NULL,
    "reverse"        varchar,
    "terminal_id"    text(32) NOT NULL,
    "etype"          text(10),
    "tcp_port"       integer,
    "udp_port"       integer,
    "ip"             text(255),
    "crt_time"       text(30),
    "status"         text(255),
    "update_time"    text(30),
    "frequency"      TEXT,
    "model"          TEXT,
    "protocol"       TEXT,
    "vendor"         TEXT,
    "name"           text(255),
    "connect_str"    text(255),
    "content"        text(255),
    "sub_type"       varchar,
    "local_ip"       varchar,
    "local_udp_port" int,
    "is_enable"      INTEGER  NOT NULL DEFAULT (1),
    "sn"             TEXT     NOT NULL UNIQUE,
    "is_online"      INTEGER  NOT NULL,
    CONSTRAINT "equip_list_pkey" PRIMARY KEY ("id")
);
CREATE TABLE tracer_detect_info
(
    id                   INTEGER PRIMARY KEY AUTOINCREMENT,
    detect_id            INTEGER,
    product_type         INTEGER,
    drone_name           TEXT,
    serial_num           TEXT,
    drone_longitude      real,
    drone_latitude       real,
    drone_height         real,
    drone_yaw_angle      real,
    drone_speed          real,
    drone_vertical_speed real,
    operator_longitude   real,
    operator_latitude    real,
    freq                 real,
    distance             INTEGER,
    danger_levels        INTEGER,
    received_time        INTEGER
);
CREATE TABLE IF NOT EXISTS "dev_date_schedule"
(
    "id"          integer PRIMARY KEY AUTOINCREMENT NOT NULL,
    "sn"          text,
    "date"        text(8),
    "information" integer,

    CONSTRAINT "dev_date_schedule_unique" UNIQUE ("id")
);
CREATE TABLE IF NOT EXISTS "date_markers"
(
    "id"         integer PRIMARY KEY AUTOINCREMENT NOT NULL,
    "time_stamp"  text    not null,
    "level"      integer not null,
    "tips"       text,
    "creat_time" integer,

    CONSTRAINT "date_markers_unique" UNIQUE ("id")
);
CREATE TABLE radar_tcp_posture_info
(
    id                     INTEGER PRIMARY KEY AUTOINCREMENT,
    sn                     TEXT,
    reserved               INTEGER,
    heading                REAL,
    pitching               REAL,
    rolling                REAL,
    longitude              REAL,
    latitude               REAL,
    altitude               REAL,
    velocity_navi          REAL,
    sig_proc_relative_time REAL
);
CREATE TABLE radar_tcp_heart
(
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    sn          TEXT,
    electricity INTEGER,
    status      INTEGER,
    is_online   INTEGER,
    ip          TEXT,
    serial_num  TEXT
);
CREATE TABLE IF NOT EXISTS "radar_tcp_track_target"
(
    "id"                integer PRIMARY KEY AUTOINCREMENT,
    "sn"                TEXT,
    "obj_id"            integer,
    "header_uid"        INTEGER,
    "azimuth"           real,
    "obj_dist_interpol" real,
    "elevation"         real,
    "velocity"          real,
    "doppler_chn"       integer,
    "mag"               real,
    "ambiguous"         integer,
    "classification"    integer,
    "classfy_prob"      real,
    "existing_prob"     real,
    "abs_vel"           real,
    "orientation_angle" real,
    "alive"             integer,
    "tws_tas_flag"      integer,
    "x"                 real,
    "y"                 real,
    "z"                 real,
    "vx"                real,
    "vy"                real,
    "vz"                real,
    "ax"                real,
    "ay"                real,
    "az"                real,
    "x_variance"        real,
    "y_variance"        real,
    "z_variance"        real,
    "vx_variance"       real,
    "vy_variance"       real,
    "vz_variance"       real,
    "ax_variance"       real,
    "ay_variance"       real,
    "az_variance"       real,
    "state_type"        integer,
    "motion_type"       integer,
    "forcast_frame_num" integer,
    "association_num"   integer,
    "assoc_bit0"        integer,
    "assoc_bit1"        integer,
    "reserve"           integer,
    "reserved2"         integer,
    "crc"               integer,
    "create_time"       text(6),
    "vendor"            text(255),
    "frequency"         text(255),
    "model"             text(255),
    "is_whitelist"      text(5)
);
CREATE INDEX radar_tcp_track_target_header_uid_index ON radar_tcp_track_target (header_uid);
CREATE TABLE radar_tcp_track_info
(
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    uid            INTEGER,
    sn             TEXT,
    reserved       INTEGER,
    track_obj_num  INTEGER,
    track_tws_num  INTEGER,
    track_tas_num  INTEGER,
    track_obj_byte INTEGER,
    received_time  INTEGER
);
CREATE INDEX radar_tcp_track_info_uid_index ON radar_tcp_track_info (uid);
CREATE TABLE IF NOT EXISTS "system_config"
(
    "id"             integer NOT NULL,
    "longitude"      real,
    "latitude"       real,
    "heading"        integer,
    "arch"           integer,
    "terminal_id"    text(255),
    "etype"          text(50),
    "warning_radius" real,
    "counter_radius" real,
    "fence_radius"   real,
    "scanner_radius" real,
    "height"         real,
    CONSTRAINT "system_config_pkey" PRIMARY KEY ("id")
);

package testdata

import "embed"

// 历史APP携带的sqlite db文件
// 下载地址如下 （下面仅仅是1.0.11版本，其他版本类推）
// https://adasgitlab.autel.com/tools/cuas_app/-/blob/release/1.0.11/plugin/cuas_server/android/src/main/assets/cuav.db
// 上述db文件约57MB，测试仅仅针对schema测试，可以用以下命令转换 `sqlite3 cuav.db ".schema --nosys" > 1_0_11_schema.sql`

//go:embed *.sql
var DbSchemas embed.FS

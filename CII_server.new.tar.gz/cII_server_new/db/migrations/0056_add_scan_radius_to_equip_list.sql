
-- +goose Up
ALTER TABLE equip_list ADD COLUMN scan_radius integer;


-- 1.0.0.17 版本引入

-- +goose Down
ALTER TABLE equip_list DROP COLUMN scan_radius;

-- +goose Up
-- +goose StatementBegin
ALTER TABLE system_config ADD COLUMN height real DEFAULT 0.0;
INSERT OR IGNORE INTO system_config (id, longitude, latitude, heading, arch, terminal_id, etype, warning_radius, counter_radius,
                           fence_radius, scanner_radius, height)
VALUES (1, -180, -180, 180, 60, '1', '28', 3000.0, 500.0, 200.0, 900.0, 250);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
-- +goose StatementEnd

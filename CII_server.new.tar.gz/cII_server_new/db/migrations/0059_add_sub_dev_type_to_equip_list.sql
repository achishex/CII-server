-- +goose Up
-- +goose StatementBegin
ALTER TABLE equip_list ADD COLUMN sub_dev_type integer DEFAULT 0;
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
ALTER TABLE equip_list DROP COLUMN sub_dev_type ;
-- +goose StatementEnd


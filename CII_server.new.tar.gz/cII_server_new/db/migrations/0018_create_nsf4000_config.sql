-- +goose Up
CREATE TABLE IF NOT EXISTS  "nsf4000_config"
(
    "id"                     integer PRIMARY KEY AUTOINCREMENT NOT NULL,
    "sn"                     text NOT NULL,
    "radius"                 integer,
    "power"                  integer,
    "defense_level_speed"    integer,
    "defense_vertical_speed" integer,
    "longitude"              real,
    "latitude"               real,
    "height"                 integer,
    "drive_level_speed"      integer,
    "drive_vertical_speed"   integer,
    CONSTRAINT "nsf4000_config_unique" UNIQUE ("sn")
);

-- +goose Down
DROP TABLE  IF EXISTS "nsf4000_config";

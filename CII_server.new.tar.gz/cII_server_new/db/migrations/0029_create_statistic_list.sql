-- +goose Up
CREATE TABLE IF NOT EXISTS  "statistic_list"
(
    "id"        integer PRIMARY KEY AUTOINCREMENT NOT NULL,
    "fly_count" integer,
    "last_time" integer,

    CONSTRAINT "statistic_list" UNIQUE ("id")
);

INSERT OR IGNORE INTO statistic_list (id, fly_count, last_time)
VALUES (1, 0, 0);

-- +goose Down
DROP TABLE  IF EXISTS "statistic_list";

-- +goose Up
CREATE TABLE IF NOT EXISTS  "autel_radar_udp_header"
(
    "id"                    integer NOT NULL,
    "packet_flag"           integer,
    "total_packet_num"      integer,
    "packet_length"         integer,
    "send_info_count"       integer,
    "terminal_type"         integer,
    "sub_terminal_type"     integer,
    "info_type"             integer,
    "info_packet_num"       integer,
    "cur_info_packet_order" integer,
    "reserved"              integer,
    "uid"                   integer,
    CONSTRAINT "radar_udp_header_pkey" PRIMARY KEY ("id")
);


-- +goose Down
DROP TABLE  IF EXISTS "autel_radar_udp_header";

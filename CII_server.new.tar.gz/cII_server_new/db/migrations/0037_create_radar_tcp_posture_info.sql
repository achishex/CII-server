-- +goose Up
CREATE TABLE IF NOT EXISTS  radar_tcp_posture_info
(
    id                     INTEGER PRIMARY KEY AUTOINCREMENT,
    sn                     TEXT,
    reserved               INTEGER,
    heading                REAL,
    pitching               REAL,
    rolling                REAL,
    longitude              REAL,
    latitude               REAL,
    altitude               REAL,
    velocity_navi          REAL,
    sig_proc_relative_time REAL
);

-- radar_tcp_heart

-- +goose Down
DROP TABLE  IF EXISTS "radar_tcp_posture_info";

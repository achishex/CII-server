-- +goose Up
-- +goose StatementBegin
ALTER TABLE email_alarm ADD COLUMN language integer DEFAULT 0;
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
ALTER TABLE email_alarm DROP COLUMN language ;

-- +goose StatementEnd
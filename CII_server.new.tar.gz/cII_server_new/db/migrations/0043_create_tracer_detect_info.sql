-- +goose Up
CREATE TABLE IF NOT EXISTS  tracer_detect_info
(
    id                   INTEGER PRIMARY KEY AUTOINCREMENT,
    detect_id            INTEGER,
    product_type         INTEGER,
    drone_name           TEXT,
    serial_num           TEXT,
    drone_longitude      real,
    drone_latitude       real,
    drone_height         real,
    drone_yaw_angle      real,
    drone_speed          real,
    drone_vertical_speed real,
    operator_longitude   real,
    operator_latitude    real,
    freq                 real,
    distance             INTEGER,
    danger_levels        INTEGER,
    received_time        INTEGER
);

CREATE  INDEX  IF NOT EXISTS tracer_tcp_heart_uav_header_id_index ON tracer_tcp_heart_uav (header_id);

-- device_comm_log

-- +goose Down
DROP TABLE  IF EXISTS "tracer_detect_info";

-- +goose Up
CREATE TABLE IF NOT EXISTS  "dev_date_schedule"
(
    "id"          integer PRIMARY KEY AUTOINCREMENT NOT NULL,
    "sn"          text,
    "date"        text(8),
    "information" integer,

    CONSTRAINT "dev_date_schedule_unique" UNIQUE ("id")
);


-- 

-- +goose Down
DROP TABLE  IF EXISTS "dev_date_schedule";

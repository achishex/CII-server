-- +goose Up
CREATE TABLE IF NOT EXISTS  "tracers_orientation_detect_drone"
(
    "id"                integer NOT NULL,
    "sn"                text, -- 检测设备tracerS sn
    "drone_number"      integer, -- 无人机编号
    "drone_name"        text,     --- 无人机名称
    "freq"              integer, -- mhz
    "azimuth"           integer, -- 方位角
    "create_time"       integer, -- 创建时间
    "update_time"       integer,
    "status"            integer, -- 1: 开始定向且未定向到无人机， 2：已经定向无人机
    CONSTRAINT "radar_adc_pkey" PRIMARY KEY ("id")
);
CREATE  INDEX  IF NOT EXISTS orientation_detect_drone_index ON tracers_orientation_detect_drone(drone_number, drone_name, freq);


-- +goose Down
DROP TABLE  IF EXISTS "tracers_orientation_detect_drone";

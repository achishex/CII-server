-- +goose Up
CREATE TABLE IF NOT EXISTS  "autel_radar_statu"
(
    "id"                integer NOT NULL,
    "info_sync"         integer,
    "info_type"         integer,
    "info_length"       integer,
    "frame_id"          integer,
    "crt_time"          text(6),
    "terminal_id"       integer,
    "terminal_type"     integer,
    "sub_terminal_type" integer,
    "info_version"      integer,
    "reserved1"         integer,
    "is_fail_flag"      integer,
    "fail_bit_data1"    integer,
    "fail_bit_data2"    integer,
    "battery_power"     real,
    "reserve"           integer,
    "reserved2"         integer,
    "crc"               integer,
    "timestamp"         integer,
    "udp_header_uid"    integer,
    CONSTRAINT "radar_fault_statu_pkey" PRIMARY KEY ("id")
);


-- +goose Down
DROP TABLE  IF EXISTS "autel_radar_statu";

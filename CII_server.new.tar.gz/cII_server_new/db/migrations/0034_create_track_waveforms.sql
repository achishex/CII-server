-- +goose Up
CREATE TABLE IF NOT EXISTS  "track_waveforms"
(
    "id"                      integer NOT NULL,
    "waveform"                text(20),
    "max_distance_target"     real,
    "max_target_time_delay"   real,
    "signal_bandwidth"        integer,
    "sampl_points"            integer,
    "sampl_window_time"       real,
    "sweep_fallback_time"     real,
    "effective_bandwidth"     real,
    "modulation_period"       real,
    "pulse_repetition_period" real,
    "differential_beat_echo"  real,
    "wave_dwell_time"         real,
    CONSTRAINT "track_waveforms_pkey" PRIMARY KEY ("id")
);

-- radar_tcp_track_info

-- +goose Down
DROP TABLE  IF EXISTS "track_waveforms";

-- +goose Up
CREATE TABLE IF NOT EXISTS  gun_tcp_heart_uav
(
    id                   INTEGER PRIMARY KEY AUTOINCREMENT,
    header_id            INTEGER,
    product_type         INTEGER,
    drone_name           TEXT,
    serial_num           TEXT,
    drone_longitude      real,
    drone_latitude       real,
    drone_height         real,
    drone_yaw_angle      real,
    drone_speed          real,
    drone_vertical_speed real,
    pilot_longitude      real,
    pilot_latitude       real,
    u_freq               real,
    u_distance           INTEGER,
    u_danger_levels      INTEGER
);

CREATE  INDEX  IF NOT EXISTS gun_tcp_heart_uav_header_id_index ON gun_tcp_heart_uav (header_id);

-- tracer_tcp_heart

-- +goose Down
DROP TABLE  IF EXISTS "gun_tcp_heart_uav";

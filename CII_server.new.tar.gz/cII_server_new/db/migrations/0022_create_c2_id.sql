-- +goose Up
CREATE TABLE IF NOT EXISTS  "c2_id"
(
    "id"    integer PRIMARY KEY NOT NULL,
    "c2_id" text                NOT NULL,
    CONSTRAINT "c2_id_unique" UNIQUE ("c2_id")
);
-- 1.0.0.2  版本引入的变更



-- +goose Down
DROP TABLE  IF EXISTS "c2_id";

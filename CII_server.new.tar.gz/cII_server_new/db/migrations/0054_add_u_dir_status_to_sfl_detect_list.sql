
-- +goose Up
ALTER TABLE sfl_detect_info ADD COLUMN u_dir_status integer;


-- 1.0.0.15 版本引入

-- +goose Down
ALTER TABLE sfl_detect_info DROP COLUMN u_dir_status;

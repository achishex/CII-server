-- +goose Up
CREATE TABLE IF NOT EXISTS  device_comm_log
(
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    device_type INTEGER,
    sn          TEXT,
    msg_id      INTEGER,
    request     TEXT,
    response    TEXT,
    remark      TEXT,
    create_time INTEGER
);


-- +goose Down
DROP TABLE  IF EXISTS "device_comm_log";

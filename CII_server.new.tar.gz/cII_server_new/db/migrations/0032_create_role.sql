-- +goose Up
CREATE TABLE IF NOT EXISTS  "role"
(
    "id"          integer NOT NULL,
    "name"        text(20),
    "status"      text(5),
    "crt_time"    text(30),
    "update_time" text(30),
    "remark"      text(50),
    CONSTRAINT "role_pkey" PRIMARY KEY ("id")
);


-- +goose Down
DROP TABLE  IF EXISTS "role";

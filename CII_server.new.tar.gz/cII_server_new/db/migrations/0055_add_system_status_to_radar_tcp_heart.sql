
-- +goose Up
ALTER TABLE radar_tcp_heart ADD COLUMN sys_status integer;


-- 1.0.0.16 版本引入

-- +goose Down
ALTER TABLE radar_tcp_heart DROP COLUMN sys_status;

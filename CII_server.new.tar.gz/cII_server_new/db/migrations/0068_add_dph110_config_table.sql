-- +goose Up
CREATE TABLE IF NOT EXISTS "dph110_config"
(
    id INTEGER PRIMARY KEY,
    sn TEXT UNIQUE NOT NULL, --设备sn
    longitude real, -- 经度
    latitude real, --维度
    altitude real, --高度
    heading real, -- 方位角
    pitching real, --俯仰角
    rolling real, -- 横滚角
    ele_scan_center real, -- 俯仰扫描中心位置(°)
    ele_scan_scope real, -- 俯仰扫描范围(°)
    azi_scan_center real, -- 方位扫描中心位置(°)
    azi_scan_scope real, -- 方位扫描范围(°)
    radar_scan_radius INTEGER, --扫描范围 (m) 默认6000m
    filter_level INTEGER, --滤波等级
    f_channel INTEGER, --频分通道
    t_channel INTEGER --时分通道
);

-- +goose Down
DROP TABLE  IF EXISTS "dph110_config";

-- +goose Up
-- +goose StatementBegin
ALTER TABLE equip_list ADD COLUMN parent_type integer DEFAULT 0;
ALTER TABLE equip_list ADD COLUMN is_integrated INTEGER DEFAULT 0; -- 0-非一体化，1-一体化
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
ALTER TABLE equip_list DROP COLUMN parent_type ;
ALTER TABLE equip_list DROP COLUMN is_integrated ;
-- +goose StatementEnd
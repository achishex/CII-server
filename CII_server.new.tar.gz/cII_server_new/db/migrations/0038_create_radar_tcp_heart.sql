-- +goose Up
CREATE TABLE IF NOT EXISTS  radar_tcp_heart
(
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    sn          TEXT,
    electricity INTEGER,
    status      INTEGER,
    is_online   INTEGER,
    ip          TEXT,
    serial_num  TEXT
);

-- +goose Down
DROP TABLE  IF EXISTS "radar_tcp_heart";

-- +goose Up
CREATE TABLE IF NOT EXISTS  "record_list"
(
    "id"                integer PRIMARY KEY AUTOINCREMENT NOT NULL,
    "dev_type"          integer,
    "detect_table_name" text NOT NULL UNIQUE,
    CONSTRAINT "record_list" UNIQUE ("id")
);

-- +goose Down
DROP TABLE  IF EXISTS "record_list";

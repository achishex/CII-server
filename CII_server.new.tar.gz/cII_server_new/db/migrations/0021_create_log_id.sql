-- +goose Up
CREATE TABLE IF NOT EXISTS  "log_id"
(
    "id"     integer PRIMARY KEY NOT NULL,
    "log_id" text                NOT NULL,
    CONSTRAINT "log_id_unique" UNIQUE ("log_id")
);


-- +goose Down
DROP TABLE  IF EXISTS "log_id";

-- +goose Up
CREATE TABLE IF NOT EXISTS  "c2_license"
(
    "license_id"   text PRIMARY KEY NOT NULL,
    "mac_addr"     text             NOT NULL,
    "start_time"   text             NOT NULL,
    "stop_time"    text             NOT NULL,
    "last_time"    text             NOT NULL,
    "expires"      integer          NOT NULL,
    "license_type" text             NOT NULL,
    "user_name"    text             NOT NULL,
    "user_phone"   text             NOT NULL,
    "user_email"   text             NOT NULL,
    CONSTRAINT "c2_license_unique" UNIQUE ("license_id")
);


-- +goose Down
DROP TABLE  IF EXISTS "c2_license";

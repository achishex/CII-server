-- +goose Up
CREATE TABLE IF NOT EXISTS  "equip_source_id"
(
    "id"          INTEGER NOT NULL,
    "sn"          TEXT    NOT NULL,
    "source_id"   INTEGER NOT NULL,
    "create_time" TEXT    NOT NULL,
    "update_time" TEXT    NOT NULL,
    CONSTRAINT "equip_source_id_pkey" PRIMARY KEY ("id")
);


-- +goose Down
DROP TABLE  IF EXISTS "equip_source_id";

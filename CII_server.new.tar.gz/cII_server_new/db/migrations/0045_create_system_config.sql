-- +goose Up

CREATE TABLE IF NOT EXISTS  "system_config"
(
    "id"             integer NOT NULL,
    "longitude"      real,
    "latitude"       real,
    "heading"        integer,
    "arch"           integer,
    "terminal_id"    text(255),
    "etype"          text(50),
    "warning_radius" real,
    "counter_radius" real,
    "fence_radius"   real,
    "scanner_radius" real,
    CONSTRAINT "system_config_pkey" PRIMARY KEY ("id")
);



-- +goose Down
DROP TABLE  IF EXISTS "system_config";

-- +goose Up
ALTER TABLE system_config ADD COLUMN c2_longitude real DEFAULT 0.0;
ALTER TABLE system_config ADD COLUMN c2_latitude real DEFAULT 0.0;
UPDATE system_config SET c2_longitude = -180.0, c2_latitude = -180.0 WHERE id = 1;

-- 1.0.0.3 版本引入


-- +goose Down

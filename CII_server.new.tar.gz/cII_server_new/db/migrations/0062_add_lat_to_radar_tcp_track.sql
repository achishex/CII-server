-- +goose Up
-- +goose StatementBegin
ALTER TABLE radar_tcp_track_target ADD COLUMN longitude REAL;
ALTER TABLE radar_tcp_track_target ADD COLUMN latitude REAL;
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
ALTER TABLE radar_tcp_track_target DROP COLUMN longitude;
ALTER TABLE radar_tcp_track_target DROP COLUMN latitude;
-- +goose StatementEnd

-- +goose Up
-- +goose StatementBegin
ALTER TABLE radar_mask ADD COLUMN all_delete_value integer DEFAULT 0;
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
ALTER TABLE radar_mask DROP COLUMN all_delete_value ;

-- +goose StatementEnd
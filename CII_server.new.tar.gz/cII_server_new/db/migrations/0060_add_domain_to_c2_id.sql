-- +goose Up
-- +goose StatementBegin
ALTER TABLE c2_id ADD COLUMN domain string DEFAULT "";
ALTER TABLE c2_id ADD COLUMN site_name string DEFAULT "";
ALTER TABLE c2_id ADD COLUMN sid text;
ALTER TABLE c2_id ADD COLUMN tid text;
ALTER TABLE c2_id ADD COLUMN token text;
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
alter table c2_id drop column domain;
alter table c2_id drop column site_name;
alter table c2_id drop column sid;
alter table c2_id drop column tid;
alter table c2_id drop column token;
-- +goose StatementEnd

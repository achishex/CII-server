-- +goose Up
-- +goose StatementBegin
CREATE TABLE IF NOT EXISTS "fences"
(
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL, --名称
    area_type INTEGER, -- 1-预警区 2-核心区
    perimeter real, --周长
    area real, --面积
    tb_code string, -- 标识同步来源，未使用
    centroid_longitude real, --中心点经度
    centroid_latitude real, --中心点纬度
    geometry TEXT NOT NULL, --经纬度信息
    is_cloud INTEGER NOT NULL CHECK (is_cloud IN (0, 1)), -- 是否是云端同步 0-APP 1-云端同步
    is_delete INTEGER NOT NULL CHECK (is_delete IN (0, 1)), --是否删除 0-否 1-是
    color TEXT NOT NULL, --面颜色
    create_time text(30), -- 创建时间
    update_time text(30), -- 更新时间
    delete_time text(30) -- 删除时间
);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
DROP TABLE  IF EXISTS "fences";
-- +goose StatementEnd

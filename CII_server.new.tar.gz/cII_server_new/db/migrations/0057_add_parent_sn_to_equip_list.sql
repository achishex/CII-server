-- +goose Up
-- +goose StatementBegin
ALTER TABLE equip_list ADD COLUMN parent_sn string DEFAULT "";
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
ALTER TABLE equip_list DROP COLUMN parent_sn ;
-- +goose StatementEnd

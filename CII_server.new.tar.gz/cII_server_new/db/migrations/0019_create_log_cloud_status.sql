-- +goose Up
CREATE TABLE IF NOT EXISTS  "log_cloud_status"
(
    "id"     integer PRIMARY KEY NOT NULL,
    "path"   text                NOT NULL,
    "status" integer             NOT NULL,
    "proid"  integer             NOT NULL,

    CONSTRAINT "log_cloud_status_unique" UNIQUE ("id")
);

-- +goose Down
DROP TABLE  IF EXISTS "log_cloud_status";

-- +goose Up
ALTER TABLE equip_list ADD COLUMN radar_relevance int DEFAULT 0;

-- 1.0.0.7版本引入

-- +goose Down



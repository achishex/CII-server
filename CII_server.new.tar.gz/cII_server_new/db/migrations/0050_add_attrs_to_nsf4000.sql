-- +goose Up
ALTER TABLE nsf4000_config ADD COLUMN defense_longitude real DEFAULT 0.0;
ALTER TABLE nsf4000_config ADD COLUMN defense_latitude real DEFAULT 0.0;
ALTER TABLE nsf4000_config ADD COLUMN area_stop_longitude real DEFAULT 0.0;
ALTER TABLE nsf4000_config ADD COLUMN area_stop_latitude real DEFAULT 0.0;

-- 1.0.0.9版本引入

-- +goose Down
ALTER TABLE nsf4000_config DROP COLUMN defense_longitude;
ALTER TABLE nsf4000_config DROP COLUMN defense_latitude;
ALTER TABLE nsf4000_config DROP COLUMN area_stop_longitude;
ALTER TABLE nsf4000_config DROP COLUMN area_stop_latitude;
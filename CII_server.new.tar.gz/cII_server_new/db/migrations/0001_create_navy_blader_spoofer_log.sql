-- +goose Up
CREATE TABLE IF NOT EXISTS "navy_blader_spoofer_log"
(
    "id"                        INTEGER PRIMARY KEY AUTOINCREMENT,
    "sn"                        text NOT NULL, --设备编号
    "dev_description"           string,        --设备描述
    "dev_close_time"            integer,       -- 设备关机时间,毫秒
    "dev_open_time"             integer,       -- 设备开机时间，毫秒, 上面是设备相关的信息
    "detect_uavs"               string,        -- 侦测无人机列表
    "interference_signal_start" integer,       --干扰信号发射时间
    "interference_signal_stop"  integer,       -- 干扰信号停止时间
    "event_id"                  integer,       -- 事件id
    "event_description"         string,        -- 事件描述，比如打击开始，打击结束
    "longitude"                 real,          -- 事件发生的经纬度
    "latitude"                  real,          -- 事件发生的经纬度
    "create_time"               integer        -- 每条记录时间，毫秒
);

-- +goose Down
DROP TABLE IF EXISTS "navy_blader_spoofer_log";

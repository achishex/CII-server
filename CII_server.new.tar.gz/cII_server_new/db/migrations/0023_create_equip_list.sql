-- +goose Up
CREATE TABLE IF NOT EXISTS  "equip_list"
(
    "id"              integer NOT NULL,
    "reverse"         varchar,
    "terminal_id"     text(32) NOT NULL,
    "etype"           text(10),
    "tcp_port"        integer,
    "udp_port"        integer,
    "ip"              text(255),
    "crt_time"        text(30),
    "status"          text(255),
    "update_time"     text(30),
    "frequency"       TEXT,
    "model"           TEXT,
    "protocol"        TEXT,
    "vendor"          TEXT,
    "name"            text(255),
    "connect_str"     text(255),
    "content"         text(255),
    "sub_type"        varchar,
    "local_ip"        varchar,
    "local_udp_port"  int,
    "is_enable"       INTEGER NOT NULL DEFAULT (1),
    "sn"              TEXT    NOT NULL UNIQUE,
    "is_online"       INTEGER NOT NULL,
    CONSTRAINT "equip_list_pkey" PRIMARY KEY ("id")
);



-- +goose Down
DROP TABLE  IF EXISTS "equip_list";

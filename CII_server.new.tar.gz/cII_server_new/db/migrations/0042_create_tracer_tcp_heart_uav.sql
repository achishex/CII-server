-- +goose Up
CREATE TABLE IF NOT EXISTS  tracer_tcp_heart_uav
(
    id                   INTEGER PRIMARY KEY AUTOINCREMENT,
    header_id            INTEGER,
    product_type         INTEGER,
    drone_name           TEXT,
    serial_num           TEXT,
    drone_longitude      real,
    drone_latitude       real,
    drone_height         real,
    drone_yaw_angle      real,
    drone_speed          real,
    drone_vertical_speed real,
    operator_longitude   real,
    operator_latitude    real,
    drone_horizon        real,
    drone_pitch          real,
    freq                 real,
    distance             INTEGER,
    danger_levels        INTEGER,
    waypoint_longitude   real,
    waypoint_latitude    real
);


-- tracer_tcp_heart_uav

-- +goose Down
DROP TABLE  IF EXISTS "tracer_tcp_heart_uav";

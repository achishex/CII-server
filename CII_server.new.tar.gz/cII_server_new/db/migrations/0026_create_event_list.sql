-- +goose Up
CREATE TABLE IF NOT EXISTS  "event_list"
(
    "id"         integer NOT NULL,
    "eid"        text    NOT NULL,
    "vendor"     text,
    "model"      text,
    "begin_time" text,
    "end_time"   text,
    "duration"   real,
    "altitude"   real,
    "frequency"  real,
    "protocol"   text,
    "status"     integer NOT NULL, -- -1事件结束，1事件开始
    "source"     integer NOT NULL, -- 1雷达，2枪
    "obj_id"     integer,
    "serial_num" text,
    CONSTRAINT "event_list_pkey" PRIMARY KEY ("id")
);


-- +goose Down
DROP TABLE  IF EXISTS "event_list";

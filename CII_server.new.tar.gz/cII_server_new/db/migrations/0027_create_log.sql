-- +goose Up
CREATE TABLE IF NOT EXISTS  "log"
(
    "id"       integer NOT NULL,
    "user_id"  integer,
    "type"     integer,
    "command"  integer,
    "lastip"   text(20),
    "os"       text(20),
    "osvesion" text(30),
    "crt_time" text(30),
    "reserve"  text,
    CONSTRAINT "log_pkey" PRIMARY KEY ("id")
);

-- +goose Down
DROP TABLE  IF EXISTS "log";

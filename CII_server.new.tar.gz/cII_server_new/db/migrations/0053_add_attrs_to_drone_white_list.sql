
-- +goose Up
ALTER TABLE drone_white_list  ADD COLUMN user_name text;
ALTER TABLE drone_white_list  ADD COLUMN usage integer;
ALTER TABLE drone_white_list  ADD COLUMN usage_desc text;
ALTER TABLE drone_white_list  ADD COLUMN remarks text;


-- 1.0.0.11 版本引入

-- +goose Down
ALTER TABLE drone_white_list  DROP COLUMN user_name;
ALTER TABLE drone_white_list  DROP COLUMN usage;
ALTER TABLE drone_white_list  DROP COLUMN usage_desc;
ALTER TABLE drone_white_list  DROP COLUMN remarks;
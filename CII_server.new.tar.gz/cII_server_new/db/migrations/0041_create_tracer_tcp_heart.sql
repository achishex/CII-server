-- +goose Up
CREATE TABLE IF NOT EXISTS  tracer_tcp_heart
(
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    header_id       INTEGER,
    time_stamp      INTEGER,
    screen_status   INTEGER,
    electricity     INTEGER,
    signal_strength INTEGER,
    work_status     INTEGER,
    alarm_level     INTEGER,
    hit_freq        INTEGER,
    detect_freq     INTEGER,
    elevation       real,
    gun_longitude   real,
    gun_latitude    real,
    gun_altitude    INTEGER,
    satellites_num  INTEGER,
    gun_direction   real,
    sn              TEXT,
    u_drone_num     INTEGER,
    received_time   INTEGER
);

CREATE  INDEX  IF NOT EXISTS tracer_tcp_heart_header_id_index ON tracer_tcp_heart (header_id);

-- tracer_tcp_heart_uav

-- +goose Down
DROP TABLE  IF EXISTS "tracer_tcp_heart";

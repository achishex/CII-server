-- +goose Up
CREATE TABLE IF NOT EXISTS  "autel_radar_wave_control"
(
    "id"                         integer NOT NULL,
    "info_sycn"                  integer,
    "info_type"                  integer,
    "info_length"                integer,
    "frame_id"                   integer,
    "crt_time"                   text(30),
    "terminal_id"                integer,
    "terminal_type"              integer,
    "sub_terminal_type"          integer,
    "info_version"               integer,
    "reserved1"                  integer,
    "azi_beam_id"                integer,
    "ele_beam_id"                integer,
    "azi_beam_sin"               real,
    "ele_beam_sin"               real,
    "tas_beam_total"             integer,
    "tas_beam_cnt_cur"           integer,
    "tas_obj_id"                 integer,
    "tas_obj_filter_num"         integer,
    "tas_obj_range"              integer,
    "sample_pnt_start"           integer,
    "sample_pnt_depth"           integer,
    "beam_switch_time"           integer,
    "whole_space_scan_cycle_cnt" integer,
    "track_tws_tas_flag"         integer,
    "reserve"                    integer,
    "reserved2"                  integer,
    "crc"                        integer,
    "timestamp"                  integer,
    CONSTRAINT "radar_wave_control_pkey" PRIMARY KEY ("id")
);


-- +goose Down
DROP TABLE  IF EXISTS "autel_radar_wave_control";

-- +goose Up
-- +goose StatementBegin
ALTER TABLE radar_tcp_track_target ADD COLUMN drone_name string DEFAULT ""; ---无人机名称
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
ALTER TABLE radar_tcp_track_target DROP COLUMN drone_name ;
-- +goose StatementEnd
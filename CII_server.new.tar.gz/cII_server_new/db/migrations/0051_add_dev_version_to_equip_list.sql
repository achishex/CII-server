
-- +goose Up
ALTER TABLE equip_list ADD COLUMN dev_version int DEFAULT "";


-- 1.0.0.10 版本引入

-- +goose Down
ALTER TABLE equip_list DROP COLUMN dev_version;

-- +goose Up
CREATE TABLE IF NOT EXISTS  "sms"
(
    "id"         integer NOT NULL,
    "phone"      text,
    "request_id" text,
    "message"    text,
    "biz_id"     text,
    "code"       text,
    CONSTRAINT "sms_pkey" PRIMARY KEY ("id")
);


-- +goose Down
DROP TABLE  IF EXISTS "sms";

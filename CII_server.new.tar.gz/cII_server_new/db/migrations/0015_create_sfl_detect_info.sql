-- +goose Up
CREATE TABLE IF NOT EXISTS  "sfl_detect_info"
(
    "id"             integer PRIMARY KEY AUTOINCREMENT NOT NULL,
    "sn"             text not null,
    "vendor"         text,
    "detect_time"    integer,
    "hit_time"       integer,
    "counter_time"   integer,
    "freq"           integer,
    "direction"      integer,
    "pilot_long_lat" text,
    CONSTRAINT "sfl_detect_info_unique" UNIQUE ("id")
);



-- +goose Down
DROP TABLE  IF EXISTS "sfl_detect_info";

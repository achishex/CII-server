-- +goose Up
-- +goose StatementBegin
ALTER TABLE c2_id ADD COLUMN bind_time TEXT;
ALTER TABLE c2_id ADD COLUMN site_id integer;
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
alter table c2_id drop column bind_time;
alter table c2_id drop column site_id;
-- +goose StatementEnd

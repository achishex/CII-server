-- +goose Up
CREATE TABLE IF NOT EXISTS  "autel_radar_point_track_body"
(
    "id"                integer NOT NULL,
    "obj_id"            integer,
    "point_header_id"   integer,
    "azimuth"           real,
    "obj_dist_interpol" real,
    "elevation"         real,
    "velocity"          real,
    "doppler_chn"       integer,
    "mag"               real,
    "obj_confidence"    real    NOT NULL,
    "ambiguous"         integer,
    "classification"    integer,
    "classfy_prob"      real,
    "cohesion_ok_flag"  integer,
    "cohesion_pnt_num"  integer,
    "cohesion_beam_num" integer,
    "azi_beam_id"       integer,
    "ele_beam_id"       integer,
    "reserved"          integer,
    "reserved2"         integer,
    "crc"               integer,
    CONSTRAINT "radar_point_track_body_pkey" PRIMARY KEY ("id")
);


-- +goose Down
DROP TABLE  IF EXISTS "autel_radar_point_track_body";

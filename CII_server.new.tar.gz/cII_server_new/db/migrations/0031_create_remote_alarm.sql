-- +goose Up
CREATE TABLE IF NOT EXISTS  "remote_alarm"
(
    "id"         integer NOT NULL,
    "phone"      text,
    "email"      text,
    "open"       integer,
    "alarm_time" integer,
    CONSTRAINT "remote_alarm_pkey" PRIMARY KEY ("id")
);


INSERT OR IGNORE INTO remote_alarm (id, phone, email, "open", "alarm_time")VALUES (1, '', '', 0, 0);

-- +goose Down
DROP TABLE  IF EXISTS "remote_alarm";

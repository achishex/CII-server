-- +goose Up
CREATE TABLE IF NOT EXISTS "email_alarm"
(
    id INTEGER PRIMARY KEY,
    is_alarm INTEGER NOT NULL DEFAULT 0, -- 是否开启告警
    email_switch INTEGER NOT NULL DEFAULT 0, -- 是否开启邮件告警
    email text, -- 邮箱地址
    sfl100 INTEGER NOT NULL DEFAULT 0, -- 是否开启SFL告警
    sfl200 INTEGER NOT NULL DEFAULT 0, -- 是否开启SFL200告警
    tracer INTEGER NOT NULL DEFAULT 0, -- 是否开启tracer告警
    radar INTEGER NOT NULL DEFAULT 0, -- 是否开启雷达告警
    srp150 INTEGER NOT NULL DEFAULT 0, -- 是否开启SRP150告警
    srp100 INTEGER NOT NULL DEFAULT 0 -- 是否开启SRP100告警
);

INSERT OR IGNORE INTO email_alarm (id, is_alarm, email_switch,email, sfl100, sfl200, tracer, radar, srp150, srp100)
VALUES (1, 0,0, '', 0,0,0,0,0,0);
-- +goose Down
DROP TABLE  IF EXISTS "email_alarm";

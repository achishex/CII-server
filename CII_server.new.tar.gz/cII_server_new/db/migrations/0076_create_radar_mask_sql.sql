-- +goose Up
CREATE TABLE IF NOT EXISTS  "radar_mask"
(
    "sn"         text UNIQUE NOT NULL, --雷达sn
    "all_delete" INTEGER NOT NULL CHECK (all_delete IN (0, 1)), --是否删除全部mask 0-否 1-是
    "masks" text --筛选层
);


-- +goose Down
DROP TABLE  IF EXISTS "radar_mask";

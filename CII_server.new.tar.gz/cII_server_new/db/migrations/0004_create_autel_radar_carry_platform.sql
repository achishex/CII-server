-- +goose Up
CREATE TABLE IF NOT EXISTS  "autel_radar_carry_platform"
(
    "id"                integer NOT NULL,
    "info_sycn"         integer,
    "info_type"         integer,
    "info_length"       integer,
    "frame_id"          integer,
    "crt_time"          text(30),
    "terminal_id"       integer,
    "terminal_type"     integer,
    "sub_terminal_type" integer,
    "info_version"      integer,
    "reserved1"         integer,
    "heading"           real,
    "pitching"          real,
    "rolling"           real,
    "longitude"         real,
    "latitude"          real,
    "altitude"          real,
    "velocity_navi"     real,
    "target_time_mark"  integer,
    "sig_relative_time" real,
    "reserve"           integer,
    "reserved2"         integer,
    "crc"               integer,
    "timestamp"         integer,
    CONSTRAINT "radar_carry_platform_pkey" PRIMARY KEY ("id")
);


-- +goose Down
DROP TABLE  IF EXISTS "autel_radar_carry_platform";

-- +goose Up
-- +goose StatementBegin
ALTER TABLE sfl_detect_info ADD COLUMN dev_type integer DEFAULT 0;
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
ALTER TABLE sfl_detect_info DROP COLUMN dev_type ;
-- +goose StatementEnd

-- +goose Up
CREATE TABLE IF NOT EXISTS  "drone_white_list"
(
    "id"        integer PRIMARY KEY AUTOINCREMENT NOT NULL,
    "vendor"    text      NOT NULL,
    "model"     text      NOT NULL,
    "frequency" text      NOT NULL,
    "sn"        text      NOT NULL,
    "role"      integer   NOT NULL,
    created_at  timestamp not null,
    updated_at  timestamp not null,
    CONSTRAINT "drone_white_list_unique" UNIQUE ("sn")
);



-- +goose Down
DROP TABLE  IF EXISTS "drone_white_list";

-- +goose Up
-- +goose StatementBegin
CREATE TABLE IF NOT EXISTS "alarm"
(
    id INTEGER PRIMARY KEY,
    drone_sn  TEXT, --目标sn
    drone_obj_id INTEGER, -- 目标ID
    event_id INTEGER, --告警事件ID
    fence_id INTEGER, --围栏区ID
    distance real, -- 无人机距离围栏区或者距离C2的距离
    threat_level INTEGER NOT NULL DEFAULT 0, --威胁等级，高（80-100分）、中（50-79分）、低（1-49分），0无威胁
    create_time TEXT, -- 告警开始时间
    UNIQUE (drone_sn, drone_obj_id, threat_level, event_id)
);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
DROP TABLE  IF EXISTS "alarm";
-- +goose StatementEnd

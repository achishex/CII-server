-- +goose Up
CREATE TABLE IF NOT EXISTS  "radar_beam_config"
(
    "id"               integer NOT NULL,
    "azi_scan_scope"   real,
    "azi_scan_center"  real,
    "ele_scan_center"  real,
    "ele_scan_scope"   real,
    "scan_radius"      integer,
    CONSTRAINT "radar_beam_config_pkey" PRIMARY KEY ("id")
    );


-- 插入默认值
INSERT OR IGNORE INTO radar_beam_config (id, azi_scan_scope, azi_scan_center, ele_scan_center, ele_scan_scope, scan_radius) VALUES (1, 88, 0, 0, 40, 1500);

-- +goose Down
DROP TABLE  IF EXISTS "radar_beam_config";

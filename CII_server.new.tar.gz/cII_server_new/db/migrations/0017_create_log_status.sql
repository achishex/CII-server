-- +goose Up
CREATE TABLE IF NOT EXISTS  "log_status"
(
    "id"     integer PRIMARY KEY AUTOINCREMENT NOT NULL,
    "sn"     text    NOT NULL,
    "status" integer NOT NULL,
    "path"   text    NOT NULL,
    "proid"  integer NOT NULL,
    CONSTRAINT "log_status_unique" UNIQUE ("sn")
);


-- +goose Down
DROP TABLE  IF EXISTS "log_status";

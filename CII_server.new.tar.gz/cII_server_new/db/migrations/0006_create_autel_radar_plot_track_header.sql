-- +goose Up
CREATE TABLE IF NOT EXISTS  "autel_radar_plot_track_header"
(
    "id"                 integer NOT NULL,
    "info_sync"          integer,
    "info_type"          integer,
    "info_length"        integer,
    "frame_id"           integer,
    "crt_time"           text(30),
    "terminal_id"        integer,
    "terminal_type"      integer,
    "sub_terminal_type"  integer,
    "info_version"       integer,
    "reserved1"          integer,
    "track_obj_num"      integer,
    "track_tws_num"      integer,
    "track_tas_num"      integer,
    "track_obj_byte"     integer,
    "track_tws_tas_flag" integer,
    "reserved"           integer,
    "timestamp"          integer,
    "update_header_id"   integer,
    uid                  int,
    CONSTRAINT "radar_plot_track_header_pkey" PRIMARY KEY ("id")
);


-- +goose Down
DROP TABLE  IF EXISTS "autel_radar_plot_track_header";

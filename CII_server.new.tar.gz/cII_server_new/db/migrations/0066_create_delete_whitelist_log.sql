-- +goose Up
CREATE TABLE IF NOT EXISTS  "delete_whitelist_log"
(
    "id"        integer PRIMARY KEY AUTOINCREMENT NOT NULL,
    "vendor"    text      NOT NULL,
    "model"     text      NOT NULL,
    "frequency" text      NOT NULL,
    "sn"        text      NOT NULL,
    "role"      integer   NOT NULL,
    created_at  timestamp not null,
    updated_at  timestamp not null,
    user_name text ,
    usage integer ,
    usage_desc text ,
    remarks text ,
    CONSTRAINT "delete_whitelist_log_unique" UNIQUE ("sn")
);



-- +goose Down
DROP TABLE  IF EXISTS "delete_whitelist_log";

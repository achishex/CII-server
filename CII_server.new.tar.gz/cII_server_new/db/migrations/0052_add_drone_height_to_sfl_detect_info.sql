
-- +goose Up
ALTER TABLE sfl_detect_info ADD COLUMN drone_height REAL;


-- 1.0.0.11 版本引入

-- +goose Down
ALTER TABLE sfl_detect_info DROP COLUMN drone_height;
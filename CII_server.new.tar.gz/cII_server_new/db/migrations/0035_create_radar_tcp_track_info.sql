-- +goose Up
CREATE TABLE IF NOT EXISTS  radar_tcp_track_info
(
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    uid            INTEGER,
    sn             TEXT,
    reserved       INTEGER,
    track_obj_num  INTEGER,
    track_tws_num  INTEGER,
    track_tas_num  INTEGER,
    track_obj_byte INTEGER,
    received_time  INTEGER
);

CREATE  INDEX  IF NOT EXISTS radar_tcp_track_info_uid_index ON radar_tcp_track_info (uid);

-- radar_tcp_track_target

-- +goose Down
DROP TABLE  IF EXISTS "radar_tcp_track_info";

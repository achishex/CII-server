-- +goose Up
-- +goose StatementBegin
ALTER TABLE fences ADD COLUMN fence_type integer DEFAULT 0;
ALTER TABLE fences ADD COLUMN y_radius REAL;
ALTER TABLE fences ADD COLUMN x_radius REAL ;
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
ALTER TABLE fences DROP COLUMN fence_type ;
ALTER TABLE fences DROP COLUMN y_radius ;
ALTER TABLE fences DROP COLUMN x_radius ;
-- +goose StatementEnd
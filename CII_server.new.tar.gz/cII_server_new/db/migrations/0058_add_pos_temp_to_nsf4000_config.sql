-- +goose Up
-- +goose StatementBegin
ALTER TABLE nsf4000_config ADD COLUMN pos_temp integer DEFAULT 1;
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
ALTER TABLE nsf4000_config DROP COLUMN pos_temp ;
-- +goose StatementEnd

-- +goose Up
-- +goose StatementBegin
ALTER TABLE alarm ADD COLUMN scenes_id integer DEFAULT 0;
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
ALTER TABLE alarm DROP COLUMN scenes_id ;
-- +goose StatementEnd
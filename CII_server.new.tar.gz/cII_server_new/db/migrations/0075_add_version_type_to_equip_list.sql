-- +goose Up
-- +goose StatementBegin
ALTER TABLE equip_list ADD COLUMN version_type integer; ---1-雷达T5 2-雷达T6
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
ALTER TABLE equip_list DROP COLUMN version_type ;
-- +goose StatementEnd
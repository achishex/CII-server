-- +goose Up
ALTER TABLE nsf4000_config ADD COLUMN x real DEFAULT 0.0;
ALTER TABLE nsf4000_config ADD COLUMN y real DEFAULT 0.0;
-- 1.0.0.9版本引入

-- +goose Down
ALTER TABLE nsf4000_config DROP COLUMN x;
ALTER TABLE nsf4000_config DROP COLUMN y;

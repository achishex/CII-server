-- +goose Up
CREATE TABLE IF NOT EXISTS  "hour_constants"
(
    "id"   INTEGER PRIMARY KEY AUTOINCREMENT,
    "time" text NOT NULL UNIQUE
);

-- 依赖time unique约束
INSERT OR IGNORE INTO hour_constants (time) VALUES ('00');
INSERT OR IGNORE INTO hour_constants (time) VALUES ('01');
INSERT OR IGNORE INTO hour_constants (time) VALUES ('02');
INSERT OR IGNORE INTO hour_constants (time) VALUES ('03');
INSERT OR IGNORE INTO hour_constants (time) VALUES ('04');
INSERT OR IGNORE INTO hour_constants (time) VALUES ('05');
INSERT OR IGNORE INTO hour_constants (time) VALUES ('06');
INSERT OR IGNORE INTO hour_constants (time) VALUES ('07');
INSERT OR IGNORE INTO hour_constants (time) VALUES ('08');
INSERT OR IGNORE INTO hour_constants (time) VALUES ('09');
INSERT OR IGNORE INTO hour_constants (time) VALUES ('10');
INSERT OR IGNORE INTO hour_constants (time) VALUES ('11');
INSERT OR IGNORE INTO hour_constants (time) VALUES ('12');
INSERT OR IGNORE INTO hour_constants (time) VALUES ('13');
INSERT OR IGNORE INTO hour_constants (time) VALUES ('14');
INSERT OR IGNORE INTO hour_constants (time) VALUES ('15');
INSERT OR IGNORE INTO hour_constants (time) VALUES ('16');
INSERT OR IGNORE INTO hour_constants (time) VALUES ('17');
INSERT OR IGNORE INTO hour_constants (time) VALUES ('18');
INSERT OR IGNORE INTO hour_constants (time) VALUES ('19');
INSERT OR IGNORE INTO hour_constants (time) VALUES ('20');
INSERT OR IGNORE INTO hour_constants (time) VALUES ('21');
INSERT OR IGNORE INTO hour_constants (time) VALUES ('22');
INSERT OR IGNORE INTO hour_constants (time) VALUES ('23');


-- +goose Down
DROP TABLE  IF EXISTS "hour_constants";

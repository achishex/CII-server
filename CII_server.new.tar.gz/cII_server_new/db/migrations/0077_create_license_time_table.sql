-- +goose Up
CREATE TABLE IF NOT EXISTS  "license_time"
(
    "id"                     integer PRIMARY KEY NOT NULL,
    "license_now_time" text
);

-- 插入默认值
INSERT OR IGNORE INTO license_time (id, license_now_time) VALUES (1, "");

-- +goose Down
DROP TABLE  IF EXISTS "license_time";
-- +goose Up
CREATE TABLE IF NOT EXISTS  "radar_tcp_track_target"
(
    "id"                integer PRIMARY KEY AUTOINCREMENT,
    "sn"                TEXT,
    "obj_id"            integer,
    "header_uid"        INTEGER,
    "azimuth"           real,
    "obj_dist_interpol" real,
    "elevation"         real,
    "velocity"          real,
    "doppler_chn"       integer,
    "mag"               real,
    "ambiguous"         integer,
    "classification"    integer,
    "classfy_prob"      real,
    "existing_prob"     real,
    "abs_vel"           real,
    "orientation_angle" real,
    "alive"             integer,
    "tws_tas_flag"      integer,
    "x"                 real,
    "y"                 real,
    "z"                 real,
    "vx"                real,
    "vy"                real,
    "vz"                real,
    "ax"                real,
    "ay"                real,
    "az"                real,
    "x_variance"        real,
    "y_variance"        real,
    "z_variance"        real,
    "vx_variance"       real,
    "vy_variance"       real,
    "vz_variance"       real,
    "ax_variance"       real,
    "ay_variance"       real,
    "az_variance"       real,
    "state_type"        integer,
    "motion_type"       integer,
    "forcast_frame_num" integer,
    "association_num"   integer,
    "assoc_bit0"        integer,
    "assoc_bit1"        integer,
    "reserve"           integer,
    "reserved2"         integer,
    "crc"               integer,
    "create_time"       text(6),
    "vendor"            text(255),
    "frequency"         text(255),
    "model"             text(255),
    "is_whitelist"      text(5)
);

CREATE  INDEX  IF NOT EXISTS radar_tcp_track_target_header_uid_index ON radar_tcp_track_target (header_uid);

-- radar_tcp_posture_info

-- +goose Down
DROP TABLE  IF EXISTS "radar_tcp_track_target";

-- +goose Up
CREATE TABLE IF NOT EXISTS  "user_base"
(
    "id"               integer NOT NULL,
    "role"             text(20),
    "name"             text(20) NOT NULL UNIQUE,
    "nick_name"        text(20),
    "gender"           text(5),
    "mobile"           text(20),
    "email"            text(20),
    "crt_time"         text(30),
    "push_token"       text(20),
    "password"         text(20), -- 在1.0.0.4版本前，密码是明文保存，1.0.0.4之后加密保存
    "update_time"      text(30),
    "updater"          text(20),
    "is_delete"        text(5),
    "last_sms_time"    text(30),
    "daily_send_times" integer,
    CONSTRAINT "user_base_pkey" PRIMARY KEY ("id")
);


-- 1.0.0.0 版本引入
INSERT OR IGNORE INTO user_base (id, "role", name, nick_name, gender, mobile, email, crt_time, push_token, password, update_time,
                       updater, is_delete)
VALUES (1, '1', 'demo', 'xiaoming', 'f', '', '995570953@qq.com', '2022-10-19 20:39:33.1471407', 'fsdf8787dfs', 'fae0b27c451c728867a567e8c1bb4e53',
        '2022-11-18 15:56:29.6270324', NULL, '0');

-- //1.0.0.4 版本引入, 依赖name unique约束实现齐次性
INSERT OR IGNORE INTO user_base ("role", "name", "nick_name", "gender", "mobile", "email", "crt_time", "push_token", "password", "update_time", "updater", "is_delete", "last_sms_time", "daily_send_times") 
VALUES ('1', 'admin', 'Administrator', 'f', '', '', '2022-10-19 20:39:33.1471407', 'fsdf8787dfs', '21232f297a57a5a743894a0e4a801fc3', '2022-11-18 15:56:29.6270324', NULL, 0, NULL, NULL);

-- //1.0.0.12 版本引入
UPDATE "user_base" SET  "role"='1', "nick_name"='xiaoming', "gender"='f', "mobile"='', "email"='995570953@qq.com', "crt_time"='2022-10-19 20:39:33.1471407', "push_token"='fsdf8787dfs', "password"='fae0b27c451c728867a567e8c1bb4e53', "update_time"='2022-11-18 15:56:29.6270324', "updater"=1, "is_delete"=0, "last_sms_time"=NULL, "daily_send_times"=NULL WHERE ("name"='demo');

-- //1.0.0.12 版本引入
UPDATE "user_base" SET  "role"='1', "nick_name"='Administrator', "gender"='f', "mobile"='', "email"='', "crt_time"='2022-10-19 20:39:33.1471407', "push_token"='fsdf8787dfs', "password"='21232f297a57a5a743894a0e4a801fc3', "update_time"='2022-11-18 15:56:29.6270324', "updater"=0, "is_delete"=0, "last_sms_time"=NULL, "daily_send_times"=NULL WHERE ("name"='admin');


-- 1.0.0.14 版本引入 , 依赖name unique约束实现齐次性
INSERT OR IGNORE INTO user_base ("role", "name", "nick_name", "gender", "mobile", "email", "crt_time", "push_token", "password", "update_time", "updater", "is_delete", "last_sms_time", "daily_send_times")
VALUES ('3', 'skyfend', 'Administrator', 'f', '', '', '2022-10-19 20:39:33.1471407', 'fsdf8787dfs', '9003eb40beecf6eff4abd492fd07dcb4', '2022-11-18 15:56:29.6270324', NULL, 0, NULL, NULL);




-- +goose Down
DROP TABLE  IF EXISTS "user_base";

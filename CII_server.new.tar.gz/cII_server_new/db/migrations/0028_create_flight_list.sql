-- +goose Up
CREATE TABLE IF NOT EXISTS  "flight_list"
(
    "id"              integer PRIMARY KEY AUTOINCREMENT NOT NULL,
    "drone_name"      text,
    "vendor"          text,
    "freq"            real,
    "dev_type"        integer,
    "serial_num"      text,
    "begin_time"      real,
    "end_time"        real,
    "duration_time"   real,
    "height"          real,
    "protocol"        text,
    "drone_yaw_angle" real,
    CONSTRAINT "flight_list" UNIQUE ("id")
);

-- +goose Down
DROP TABLE  IF EXISTS "flight_list";

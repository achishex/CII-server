-- +goose Up
CREATE TABLE IF NOT EXISTS  gun_tcp_heart
(
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    header_id       INTEGER,
    time_stamp      INTEGER,
    screen_status   INTEGER,
    electricity     INTEGER,
    signal_strength INTEGER,
    work_status     INTEGER,
    alarm_level     INTEGER,
    hit_freq        INTEGER,
    detect_freq     INTEGER,
    x               INTEGER,
    y               INTEGER,
    z               INTEGER,
    gun_longitude   real,
    gun_latitude    real,
    gun_altitude    INTEGER,
    satellites_num  INTEGER,
    gun_direction   real,
    elevation       real,
    u_drone_num     INTEGER,
    received_time   INTEGER
);

CREATE  INDEX  IF NOT EXISTS gun_tcp_heart_header_id_index ON gun_tcp_heart (header_id);

-- gun_tcp_heart_uav

-- +goose Down
DROP TABLE  IF EXISTS "gun_tcp_heart";

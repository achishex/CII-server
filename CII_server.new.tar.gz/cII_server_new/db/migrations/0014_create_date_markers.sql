-- +goose Up
CREATE TABLE IF NOT EXISTS  "date_markers"
(
    "id"         integer PRIMARY KEY AUTOINCREMENT NOT NULL,
    "time_stamp" text    not null,
    "level"      integer not null,
    "tips"       text,
    "creat_time" integer,

    CONSTRAINT "date_markers_unique" UNIQUE ("id")
);
-- sfl_detect_info  云台侦测、打击信息

-- +goose Down
DROP TABLE  IF EXISTS "date_markers";
